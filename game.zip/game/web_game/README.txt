WEB GAME — FOLDER & CARA MENJALANKAN
====================================

web_game/
├── dev_panel/                         Source Developer Panel
├── harvest_in_the_great_valley/       Source game
├── tools/
│   ├── bun/                           Bun portable
│   └── runtime/                       Config, HTTPS lokal, log, cache
├── data/
│   ├── data_game/                     Data dan modul game
│   └── data_dev_panel/                Data dan modul Dev Panel
├── launcher.bat                       Launcher Windows
└── launcher.ps1                       Launcher Windows/Linux (PowerShell 7)

Windows: jalankan launcher.bat
Linux:   pwsh ./launcher.ps1

Menu [1] menjalankan Game Server HTTPS. Menu [2] hanya membuka halaman Dev Panel setelah server aktif; akses panel tetap bergantung pada login akun Owner/Developer di dalam game.

Junction Windows / symbolic link Linux menghubungkan node_modules pada source ke data/data_game/node_modules dan data/data_dev_panel/node_modules.

HTTPS lokal memakai sertifikat lokal/self-signed. Untuk HTTPS publik tepercaya, gunakan domain DNS publik dan reverse proxy/CA yang sesuai; IP detection tidak menjamin sertifikat publik tepercaya.
