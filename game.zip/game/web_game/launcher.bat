@echo off
setlocal
cd /d "%~dp0"
where pwsh >nul 2>nul
if %errorlevel%==0 (
  pwsh -STA -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher.ps1"
) else (
  powershell -STA -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher.ps1"
)
if errorlevel 1 pause
endlocal
