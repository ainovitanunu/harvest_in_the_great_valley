HARVEST IN THE GREAT VALLEY — CLEAN GAME SOURCE WORKSPACE
=========================================================
Folder ini hanya untuk modul & entrypoint game yang bersih.
Seluruh data ter-generate otomatis (database dunia, save terenkripsi, log, dan secrets)
disimpan terpisah di:
  - web_game\data\data_game\
  - web_game\data\data_game\game_secrets\   (TIDAK BOLEH dibagikan ke publik/Git/AI)

Jalankan game melalui:
  web_game\launcher.bat  (atau  web_game\launcher.ps1)
