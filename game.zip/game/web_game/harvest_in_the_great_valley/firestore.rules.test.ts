/**
 * Security Rules Verification Suite (Dirty Dozen Adversarial Payloads)
 * Documents expected PERMISSION_DENIED outcomes for Harvest in the Great Valley.
 */
export const DIRTY_DOZEN_PAYLOADS = [
  { name: 'Unauthenticated read /users/userA', path: '/users/userA', op: 'get', auth: null, expected: 'PERMISSION_DENIED' },
  { name: 'Cross-user read /users/userB as userA', path: '/users/userB', op: 'get', auth: { uid: 'userA', email_verified: true }, expected: 'PERMISSION_DENIED' },
  { name: 'Cross-user write /users/userB/farmSaves/main', path: '/users/userB/farmSaves/main', op: 'create', auth: { uid: 'userA', email_verified: true }, expected: 'PERMISSION_DENIED' },
  { name: 'Unverified email write /users/userA', path: '/users/userA', op: 'create', auth: { uid: 'userA', email_verified: false }, expected: 'PERMISSION_DENIED' },
  { name: 'Identity spoofing uid=userB on /users/userA', path: '/users/userA', op: 'create', payload: { uid: 'userB' }, expected: 'PERMISSION_DENIED' },
  { name: 'Ghost field injection isAdmin=true', path: '/users/userA', op: 'update', payload: { isAdmin: true }, expected: 'PERMISSION_DENIED' },
  { name: 'Oversized avatarName > 32 chars', path: '/users/userA', op: 'create', payload: { avatarName: 'A'.repeat(33) }, expected: 'PERMISSION_DENIED' },
  { name: 'Negative gold balance', path: '/users/userA', op: 'update', payload: { gold: -100 }, expected: 'PERMISSION_DENIED' },
  { name: 'Oversized userId > 128 chars', path: `/users/${'x'.repeat(129)}`, op: 'get', expected: 'PERMISSION_DENIED' },
  { name: 'Client-forged updatedAt string', path: '/users/userA', op: 'create', payload: { updatedAt: '2026-01-01T00:00:00Z' }, expected: 'PERMISSION_DENIED' },
  { name: 'Version rollback on farmSaves', path: '/users/userA/farmSaves/main', op: 'update', payload: { version: 1 }, existing: { version: 5 }, expected: 'PERMISSION_DENIED' },
  { name: 'Delete leaderboard entry', path: '/leaderboard/userB', op: 'delete', auth: { uid: 'userA', email_verified: true }, expected: 'PERMISSION_DENIED' },
] as const;
