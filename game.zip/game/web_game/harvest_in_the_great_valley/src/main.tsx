import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { DevPanel } from '@dev-panel/DevPanel';
import { localizationManager } from './game/localizationManager';
import { themeManager } from './game/themeManager';
import './index.css';

// Initialize global theme & localization managers before first paint
themeManager.init();
localizationManager.init();

const pathname = typeof window !== 'undefined' ? window.location.pathname : '/';
const isDevPanelRoute =
  pathname === '/dev-panel' ||
  pathname.startsWith('/dev-panel/') ||
  pathname === '/dev-dashboard' ||
  pathname.startsWith('/dev-dashboard/');

createRoot(document.getElementById('root')!).render(isDevPanelRoute ? <DevPanel /> : <App />);
