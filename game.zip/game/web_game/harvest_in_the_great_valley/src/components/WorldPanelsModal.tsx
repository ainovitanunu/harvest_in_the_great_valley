import React, { useEffect, useState } from 'react';
import {
  Award,
  Bell,
  BookOpen,
  Briefcase,
  Calendar,
  Camera,
  Clock,
  Gamepad2,
  Globe,
  Heart,
  Home,
  Keyboard,
  LogOut,
  Search,
  Settings,
  Share2,
  Sparkles,
  Store,
  Trophy,
  Users,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  DEVELOPER_DEBUG_MODE,
  PAYMENT_METHODS,
} from '../game/data/gameRuntimeConfig';
import {
  BAG_UPGRADE_DIAMOND_COSTS,
  DEFAULT_KEYBINDINGS,
  ITEMS,
  MAX_BAG_UPGRADES,
  OUTFIT_CATALOG,
  getMaxBagSlots,
} from '../game/data/itemsAndCrops';
import { NPCS, NPC_MAP, getFriendshipTier, getNpcRoutineSlot } from '../game/data/npcs';
import {
  ACHIEVEMENTS,
  CUSTOMIZATION_DIAMOND_COST,
  DAYS_PER_SEASON,
  DIAMOND_PACKAGES,
  FESTIVALS,
  QUESTS,
  REAL_DAYS_PER_SEASON,
  SEASON_DAYS,
  SEASONS_ORDER,
  ZONE_LABELS,
  getBarnCapacity,
  getCoopCapacity,
  getDaysInSeason,
  getIncubatorCount,
} from '../game/data/worldConfig';
import { xpRequiredForLevel } from '../game/progression';
import { t } from '../game/i18n';
import type {
  AnimalState,
  DailyMission,
  FarmJobOffer,
  FarmJobTaskType,
  FarmPlotState,
  GameStats,
  IAPTransaction,
  InventorySlot,
  KeyBindings,
  Language,
  LeaderboardRecord,
  MarketplaceCategory,
  MarketState,
  NPCRelationshipState,
  NotificationSettings,
  P2PMarketListing,
  PlayerProfile,
  Season,
  TransactionRecord,
  WorldZoneId,
} from '../game/types';
import {
  fetchIAPHistory,
  fetchMyTransactionHistory,
  fetchOnlinePlayers,
  fetchOpenFarmJobs,
  fetchP2PMarketListings,
  fetchServerLeaderboard,
  purchaseDiamonds,
} from '../services/multiplayerClient';
import { DraggableWindow } from './DraggableWindow';

export type BukuTab =
  | 'calendar'
  | 'npcs'
  | 'missions'
  | 'jobs'
  | 'p2p_market'
  | 'leaderboard'
  | 'multiplayer'
  | 'iap'
  | 'profile';

export type WorldPanelTab = BukuTab | 'settings';

interface WorldPanelsModalProps {
  mode: 'buku' | 'settings';
  language?: Language;
  initialTab?: BukuTab;
  profile: PlayerProfile;
  animalsCount: number;
  animals?: AnimalState[];
  inventory?: InventorySlot[];
  p2pListings?: P2PMarketListing[];
  farmPlots?: Record<string, FarmPlotState>;
  farmJobs?: FarmJobOffer[];
  season: Season;
  day: number;
  year: number;
  hour: number;
  isRainy: boolean;
  stats: GameStats;
  unlockedAchievements: string[];
  dailyMissions: DailyMission[];
  completedQuests: string[];
  npcRelationships: Record<string, NPCRelationshipState>;
  currentZone: WorldZoneId;
  visitingFarmOwnerId: string | null;
  notifSettings: NotificationSettings;
  muted: boolean;
  keyBindings: KeyBindings;
  gamepadStatus: { connected: boolean; name?: string };
  marketState: MarketState | null;
  taxBuckets: Record<number, number>;
  onClaimTaxReward: () => Promise<void>;
  onBuyBagUpgrade: () => void;
  onBuyBagUpgradeGold?: () => void;
  onBuyDiamondItem: (itemId: string) => void;
  onBuyOutfit: (outfitId: string) => void;
  onCreateP2PListing?: (payload: {
    slotIndex?: number;
    itemId: string;
    itemName: string;
    category: MarketplaceCategory;
    quantity: number;
    diamondPrice: number;
    description: string;
  }) => Promise<boolean>;
  onBuyP2PListing?: (listing: P2PMarketListing) => Promise<boolean>;
  onCancelP2PListing?: (listing: P2PMarketListing) => Promise<boolean>;
  onOpenStyleStudio?: () => void;
  onUpdateKeyBindings: (next: KeyBindings) => void;
  onClaimMission: (missionId: string) => void;
  onCreateFarmJob?: (tasks: FarmJobTaskType[], wageGold: number, cropCount: number, animalCount: number) => void;
  onAcceptFarmJob?: (job: FarmJobOffer) => void;
  onCancelFarmJob?: (jobId: string) => void;
  onCompleteFarmJob?: (jobId: string) => void;
  onVisitFarm: (ownerUid: string, ownerName: string) => void;
  onReturnHome: () => void;
  onResetToHome: () => void;
  onExitGame: () => void;
  onDiamondDelta: (delta: number) => void;
  onToggleNotif: (key: keyof NotificationSettings) => void;
  onToggleMute: () => void;
  onCaptureScreenshot: () => string;
  paymentMethods?: { googlePlayBilling: boolean; duitku: boolean };
  liveDebugMode?: boolean;
  onClose: () => void;
}

const RESET_HOME_COOLDOWN_MS = 10 * 60 * 1000;

const KEY_LABELS: Array<[keyof KeyBindings, string]> = [
  ['forward', 'Move Forward'],
  ['backward', 'Move Backward'],
  ['left', 'Turn / Move Left'],
  ['right', 'Turn / Move Right'],
  ['dash', 'Dash'],
  ['sprint', 'Sprint'],
  ['jump', 'Jump'],
  ['social', 'Talk / Private Chat'],
  ['execute', 'Execute Tool / Shop'],
  ['inventory', 'Open Bag (Inventory)'],
  ['chat', 'Open Chat'],
  ['toolSlot1', 'Tool Shortcut 1'],
  ['toolSlot2', 'Tool Shortcut 2'],
  ['toolSlot3', 'Tool Shortcut 3'],
  ['toolSlot4', 'Tool Shortcut 4'],
  ['toolSlot5', 'Tool Shortcut 5'],
  ['toolSlot6', 'Tool Shortcut 6'],
];

function prettyKeyCode(code: string): string {
  if (!code) return '-';
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  if (code === 'ShiftLeft' || code === 'ShiftRight') return 'Shift';
  return code;
}

export const WorldPanelsModal: React.FC<WorldPanelsModalProps> = ({
  mode,
  language = 'en',
  initialTab = 'calendar',
  profile,
  animalsCount,
  animals = [],
  inventory = [],
  p2pListings: liveP2pListings = [],
  farmPlots = {},
  farmJobs = [],
  season,
  day,
  year,
  hour,
  isRainy,
  stats,
  unlockedAchievements,
  dailyMissions,
  completedQuests,
  npcRelationships,
  visitingFarmOwnerId,
  notifSettings,
  muted,
  keyBindings,
  gamepadStatus,
  marketState,
  taxBuckets,
  onClaimTaxReward,
  onBuyBagUpgrade,
  onBuyDiamondItem,
  onBuyOutfit,
  onCreateP2PListing,
  onBuyP2PListing,
  onCancelP2PListing,
  onOpenStyleStudio,
  onUpdateKeyBindings,
  onClaimMission,
  onCreateFarmJob,
  onAcceptFarmJob,
  onCancelFarmJob,
  onCompleteFarmJob,
  onVisitFarm,
  onReturnHome,
  onResetToHome,
  onExitGame,
  onDiamondDelta,
  onToggleNotif,
  onToggleMute,
  onCaptureScreenshot,
  paymentMethods,
  liveDebugMode,
  onClose,
}) => {
  const [tab, setTab] = useState<BukuTab>(initialTab);
  const [jobSubmenu, setJobSubmenu] = useState<'hire' | 'accept'>('hire');
  const [p2pSubmenu, setP2pSubmenu] = useState<'buy' | 'sell' | 'history'>('buy');
  const [p2pCategoryFilter, setP2pCategoryFilter] = useState<string>('all');
  const [p2pSearch, setP2pSearch] = useState('');
  const [fetchedP2P, setFetchedP2P] = useState<P2PMarketListing[]>([]);
  const [myTransactions, setMyTransactions] = useState<TransactionRecord[]>([]);
  const [sellMode, setSellMode] = useState<'inventory' | 'service'>('inventory');
  const [sellSlotIndex, setSellSlotIndex] = useState<number>(-1);
  const [sellCategory, setSellCategory] = useState<MarketplaceCategory>('crops');
  const [sellQty, setSellQty] = useState<number>(1);
  const [sellPrice, setSellPrice] = useState<number>(10);
  const [sellServiceTitle, setSellServiceTitle] = useState('');
  const [sellDescription, setSellDescription] = useState('');
  const [p2pStatusMsg, setP2pStatusMsg] = useState('');
  const [calSeason, setCalSeason] = useState<Season>(season);
  const [lbCategory, setLbCategory] = useState('totalWealth');
  const [leaderboard, setLeaderboard] = useState<LeaderboardRecord[]>([]);
  const [onlinePlayers, setOnlinePlayers] = useState<
    Array<{
      clientId: string;
      uid: string;
      avatarName: string;
      farmName: string;
      zone: WorldZoneId;
      farmOwnerId: string;
      level: number;
      spousePlayerName?: string | null;
    }>
  >([]);
  const [fetchedJobs, setFetchedJobs] = useState<FarmJobOffer[]>([]);
  const [jobWage, setJobWage] = useState(500);
  const [jobTasks, setJobTasks] = useState<FarmJobTaskType[]>(['water_crops', 'feed_cow', 'feed_sheep', 'feed_horse', 'feed_dog']);
  const effectivePaymentMethods = paymentMethods || PAYMENT_METHODS;
  const effectiveDebugMode = liveDebugMode ?? DEVELOPER_DEBUG_MODE;
  const [iapProvider, setIapProvider] = useState<'google_play' | 'duitku'>(
    effectivePaymentMethods.googlePlayBilling ? 'google_play' : 'duitku'
  );
  const [iapHistory, setIapHistory] = useState<IAPTransaction[]>([]);
  const [iapMsg, setIapMsg] = useState('');
  const [screenshotUrl, setScreenshotUrl] = useState<string | null>(null);
  const [npcFilter, setNpcFilter] = useState<string>('All');
  const [nowMs, setNowMs] = useState(() => Date.now());
  const [remappingKey, setRemappingKey] = useState<keyof KeyBindings | null>(null);
  const [claimingTax, setClaimingTax] = useState(false);

  useEffect(() => {
    setTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (mode !== 'buku') return;
    if (tab === 'leaderboard') {
      fetchServerLeaderboard(lbCategory).then(setLeaderboard).catch(() => {});
    } else if (tab === 'multiplayer') {
      fetchOnlinePlayers().then(setOnlinePlayers).catch(() => {});
    } else if (tab === 'iap') {
      fetchIAPHistory(profile.uid).then(setIapHistory).catch(() => {});
    } else if (tab === 'jobs') {
      fetchOpenFarmJobs().then(setFetchedJobs).catch(() => {});
    } else if (tab === 'p2p_market') {
      fetchP2PMarketListings(p2pCategoryFilter, p2pSearch).then(setFetchedP2P).catch(() => {});
      fetchMyTransactionHistory().then(setMyTransactions).catch(() => {});
    }
  }, [mode, tab, lbCategory, profile.uid, p2pCategoryFilter, p2pSearch]);

  useEffect(() => {
    if (effectivePaymentMethods.googlePlayBilling && !effectivePaymentMethods.duitku && iapProvider !== 'google_play') {
      setIapProvider('google_play');
    } else if (!effectivePaymentMethods.googlePlayBilling && effectivePaymentMethods.duitku && iapProvider !== 'duitku') {
      setIapProvider('duitku');
    }
  }, [effectivePaymentMethods.googlePlayBilling, effectivePaymentMethods.duitku, iapProvider]);

  useEffect(() => {
    if (mode !== 'settings') return;
    setNowMs(Date.now());
    const id = window.setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(id);
  }, [mode]);

  useEffect(() => {
    if (!remappingKey) return;
    const onCaptureKey = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.code === 'Escape') {
        setRemappingKey(null);
        return;
      }
      onUpdateKeyBindings({ ...keyBindings, [remappingKey]: e.code });
      setRemappingKey(null);
    };
    window.addEventListener('keydown', onCaptureKey, { capture: true });
    return () => window.removeEventListener('keydown', onCaptureKey, { capture: true });
  }, [remappingKey, keyBindings, onUpdateKeyBindings]);

  const cooldownRemainingMs = Math.max(0, RESET_HOME_COOLDOWN_MS - (nowMs - (profile.lastResetHomeAt || 0)));
  const cooldownMin = Math.floor(cooldownRemainingMs / 60000);
  const cooldownSec = Math.floor((cooldownRemainingMs % 60000) / 1000);

  const handleBuyDiamonds = async (pkgId: string) => {
    const res = await purchaseDiamonds(profile.uid, iapProvider, pkgId);
    if (res.ok && res.transaction) {
      onDiamondDelta(res.transaction.diamondAmount);
      setIapHistory((prev) => [res.transaction!, ...prev]);
      setIapMsg(`✅ Success! +${res.transaction.diamondAmount} Diamonds (${res.transaction.transactionId})`);
    } else {
      setIapMsg(`❌ ${res.error || 'Transaction failed'}`);
    }
  };

  const handleShare = async () => {
    const dataUrl = screenshotUrl || onCaptureScreenshot();
    setScreenshotUrl(dataUrl);
    const summaryText = `🌾 ${profile.avatarName} at ${profile.farmName} (Lv.${profile.level}) — Harvest in the Great Valley! Harvests: ${stats.cropsHarvested}, Gold: ${profile.gold} G, Achievements: ${unlockedAchievements.length}/${ACHIEVEMENTS.length}.`;
    try {
      if (navigator.share) {
        const res = await fetch(dataUrl);
        const blob = await res.blob();
        const file = new File([blob], 'great-valley-farm.png', { type: 'image/png' });
        await navigator.share({ title: 'Harvest in the Great Valley', text: summaryText, files: [file] });
        return;
      }
    } catch {
      // fallback download
    }
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = 'great-valley-screenshot.png';
    a.click();
  };

  const BUKU_TABS: Array<{ id: BukuTab; label: string; icon: React.ReactNode }> = [
    { id: 'calendar', label: language === 'id' ? 'Kalender' : 'Calendar', icon: <Calendar className="w-3.5 h-3.5" /> },
    { id: 'npcs', label: language === 'id' ? 'Warga (25)' : 'Villagers (25)', icon: <Users className="w-3.5 h-3.5" /> },
    { id: 'missions', label: language === 'id' ? 'Misi' : 'Missions', icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: 'jobs', label: t(language, 'hud.jobs'), icon: <Briefcase className="w-3.5 h-3.5" /> },
    { id: 'p2p_market', label: language === 'id' ? 'Pasar P2P 💎' : 'P2P Market 💎', icon: <Store className="w-3.5 h-3.5" /> },
    { id: 'leaderboard', label: language === 'id' ? 'Peringkat' : 'Rankings', icon: <Trophy className="w-3.5 h-3.5" /> },
    { id: 'multiplayer', label: language === 'id' ? 'Kunjungi Kebun' : 'Visit Farms', icon: <Globe className="w-3.5 h-3.5" /> },
    { id: 'iap', label: 'Diamonds', icon: <Award className="w-3.5 h-3.5" /> },
    { id: 'profile', label: language === 'id' ? 'Profil' : 'Profile', icon: <Camera className="w-3.5 h-3.5" /> },
  ];

  const P2P_CATEGORIES: Array<{ id: MarketplaceCategory; en: string; idLabel: string }> = [
    { id: 'tools', en: 'Tools', idLabel: 'Alat (Tools)' },
    { id: 'medicine', en: 'Medicine', idLabel: 'Obat-obatan' },
    { id: 'food', en: 'Food', idLabel: 'Makanan' },
    { id: 'jewelry', en: 'Jewelry', idLabel: 'Perhiasan' },
    { id: 'services', en: 'Services', idLabel: 'Jasa' },
    { id: 'crops', en: 'Crops & Seeds', idLabel: 'Hasil Panen & Bibit' },
    { id: 'materials', en: 'Materials', idLabel: 'Material & Tambang' },
    { id: 'other', en: 'Other', idLabel: 'Lainnya' },
  ];

  const allP2PListings = (liveP2pListings.length > 0 ? liveP2pListings : fetchedP2P).filter((l) => {
    if (l.status !== 'active') return false;
    if (p2pCategoryFilter !== 'all' && l.category !== p2pCategoryFilter) return false;
    if (p2pSearch.trim()) {
      const q = p2pSearch.trim().toLowerCase();
      return (
        l.itemName.toLowerCase().includes(q) ||
        l.description.toLowerCase().includes(q) ||
        l.sellerName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const tradeableInventorySlots = inventory
    .map((slot, idx) => ({ slot, idx, def: ITEMS[slot.itemId] }))
    .filter(({ slot, def }) => Boolean(def) && slot.quantity > 0 && slot.diamondTradeable === true);

  const allJobs = farmJobs.length > 0 ? farmJobs : fetchedJobs;
  const plotCountForJob = Object.values(farmPlots).filter((p) => p.tilled && !p.watered).length || Object.values(farmPlots).filter((p) => p.tilled).length;
  const cowCount = animals.filter((a) => a.type === 'cow').length;
  const sheepCount = animals.filter((a) => a.type === 'sheep').length;
  const horseCount = animals.filter((a) => a.type === 'horse').length;
  const dogCount = animals.filter((a) => a.type === 'dog').length;

  const selectedCropUnits = jobTasks.includes('water_crops') ? plotCountForJob : 0;
  const selectedAnimalUnits =
    (jobTasks.includes('feed_cow') ? cowCount : 0) +
    (jobTasks.includes('feed_sheep') ? sheepCount : 0) +
    (jobTasks.includes('feed_horse') ? horseCount : 0) +
    (jobTasks.includes('feed_dog') ? dogCount : 0);
  const computedTotalUnits = Math.max(1, selectedCropUnits + selectedAnimalUnits);

  const toggleJobTask = (task: FarmJobTaskType) => {
    setJobTasks((prev) => (prev.includes(task) ? prev.filter((x) => x !== task) : [...prev, task]));
  };

  const bagUpgrades = profile.bagUpgrades || 0;
  const maxBagSlots = getMaxBagSlots(bagUpgrades);
  const nextBagCost = bagUpgrades < MAX_BAG_UPGRADES ? BAG_UPGRADE_DIAMOND_COSTS[bagUpgrades] : null;
  const anyPaymentGatewayEnabled = Boolean(effectivePaymentMethods.googlePlayBilling || effectivePaymentMethods.duitku);

  const exclusiveDiamondItems = ['item_valley_phone', 'item_miracle_fertilizer', 'item_royal_elixir', 'item_golden_ring']
    .map((id) => ITEMS[id])
    .filter(Boolean);

  return (
    <DraggableWindow
      windowId={mode === 'settings' ? 'settings_panel' : 'world_panel'}
      title={mode === 'settings' ? 'Game Settings' : 'Great Valley Almanac & Book'}
      icon={
        mode === 'settings' ? (
          <Settings className="w-5 h-5 text-[#f5cc74]" />
        ) : (
          <BookOpen className="w-5 h-5 text-[#f5cc74]" />
        )
      }
      widthClass={mode === 'settings' ? 'w-[min(94vw,660px)]' : 'w-[min(95vw,860px)]'}
      headerAccent={mode === 'settings' ? 'oak' : 'walnut'}
      onClose={onClose}
    >
      <div className="flex flex-col text-[#2b1a0e]">
        {mode === 'buku' && (
          <div className="px-4 py-2.5 bg-[#efe2c6] border-b border-[#d3bc92] flex flex-wrap gap-1.5">
            {BUKU_TABS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border cursor-pointer ${
                  tab === t.id
                    ? 'bg-[#f2cf7e] border-[#b8711e] text-[#3c2310]'
                    : 'bg-[#fffaf0] border-[#d3bc92] text-[#5c3c22] hover:bg-[#f9f1df]'
                }`}
              >
                {t.icon}
                <span>{t.label}</span>
              </button>
            ))}
          </div>
        )}

        <div className="p-4 sm:p-5 space-y-4">
          {mode === 'buku' && tab === 'calendar' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-sm font-extrabold">
                  Current Date: Year {year} · {season} Day {day}/{getDaysInSeason(season)}
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {SEASONS_ORDER.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setCalSeason(s)}
                      className={`px-3 py-1 rounded-xl text-xs font-extrabold border cursor-pointer ${
                        calSeason === s ? 'bg-[#3a6b2c] text-white border-[#214417]' : 'bg-[#fffaf0] border-[#d3bc92]'
                      }`}
                    >
                      {s} ({SEASON_DAYS[s]})
                    </button>
                  ))}
                </div>
              </div>

              <div className="rounded-xl bg-[#efe2c6] border border-[#d3bc92] px-3 py-2 text-xs font-bold text-[#4b2d16]">
                ⏱️ Calendar: 🌸 Spring 31 · ☀️ Summer 31 · 🍂 Autumn 30 · ❄️ Winter 28 (120 Days/Year · ~{REAL_DAYS_PER_SEASON} Real Days/Season · 1 Day ≈ 11h 12m).
              </div>

              <div className="grid grid-cols-5 sm:grid-cols-6 gap-2">
                {Array.from({ length: getDaysInSeason(calSeason) }, (_, i) => i + 1).map((d) => {
                  const fest = FESTIVALS.find((f) => f.season === calSeason && f.day === d);
                  const bdays = NPCS.filter((n) => n.birthday.season === calSeason && n.birthday.day === d);
                  const isToday = calSeason === season && d === day;
                  return (
                    <div
                      key={d}
                      className={`rounded-xl border-2 p-2 min-h-[68px] text-xs flex flex-col justify-between ${
                        isToday
                          ? 'border-[#3a6b2c] bg-[#dcecd1]'
                          : fest
                            ? 'border-[#d98a2b] bg-[#fae8c4]'
                            : 'border-[#d3bc92] bg-[#fffaf0]'
                      }`}
                    >
                      <span className="font-black tabular-nums">{d}</span>
                      <div className="space-y-0.5 text-[10px] font-bold">
                        {fest && <div className="text-[#9e5316] truncate">🎪 {fest.name}</div>}
                        {bdays.map((b) => (
                          <div key={b.id} className="text-[#9e3b24] truncate">
                            🎂 {b.name}
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="grid sm:grid-cols-2 gap-3">
                {FESTIVALS.filter((f) => f.season === calSeason).map((f) => (
                  <div key={f.id} className="rounded-2xl border border-[#d3bc92] bg-[#fffaf0] p-3">
                    <div className="font-extrabold text-sm text-[#9e5316]">
                      🎪 {f.name} — {f.season} Day {f.day}
                    </div>
                    <p className="text-xs text-[#5c3c22] mt-1">{f.description}</p>
                    <div className="text-[11px] font-bold text-[#3a6b2c] mt-1">
                      Location: {ZONE_LABELS[f.locationZone]} · Host: {NPC_MAP[f.hostNpcId]?.name}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {mode === 'buku' && tab === 'npcs' && (
            <div className="space-y-3">
              <div className="flex flex-wrap gap-1.5">
                {['All', 'Village Leaders', 'Merchants', 'Specialists', 'Romance Candidates', 'Children', 'Mysterious'].map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setNpcFilter(cat)}
                    className={`px-2.5 py-1 rounded-xl text-xs font-bold border cursor-pointer ${
                      npcFilter === cat ? 'bg-[#3a6b2c] text-white border-[#214417]' : 'bg-[#fffaf0] border-[#d3bc92]'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              <div className="grid sm:grid-cols-2 gap-3">
                {NPCS.filter((n) => npcFilter === 'All' || n.category === npcFilter).map((npc) => {
                  const rel = npcRelationships[npc.id];
                  const slot = getNpcRoutineSlot(npc, hour, isRainy, false, undefined, profile.spouseId);
                  return (
                    <div key={npc.id} className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-3.5 flex gap-3">
                      <div
                        className="w-11 h-11 rounded-2xl flex items-center justify-center text-white font-black text-lg shrink-0"
                        style={{ backgroundColor: npc.appearance.outfitColor }}
                      >
                        {npc.name[0]}
                      </div>
                      <div className="min-w-0 flex-1 space-y-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-extrabold text-sm">{npc.name}</span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-lg bg-[#efe2c6]">
                            {npc.profession}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#5c3c22] line-clamp-2">{npc.description}</p>
                        <div className="flex flex-wrap items-center gap-2 text-[11px] font-bold">
                          <span className="text-[#3a6b2c]">
                            FP {rel?.friendshipPoints || 50}/1000 ({getFriendshipTier(rel?.friendshipPoints || 50)})
                          </span>
                          {npc.isMarriageCandidate && (
                            <span className="text-[#9e3b24] flex items-center gap-0.5">
                              <Heart className="w-3 h-3 fill-[#c8432b] text-[#c8432b]" /> {rel?.heartLevel || 0}/10
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-[#784820] font-semibold">
                          📍 {ZONE_LABELS[slot.zone]} — {slot.label}
                        </div>
                        <div className="text-[10px] text-[#6e4624]">
                          🎂 {npc.birthday.season} {npc.birthday.day} · 🎁{' '}
                          {language === 'id'
                            ? 'Barang favorit: Rahasia (temukan lewat hadiah)'
                            : 'Favorite gifts: Secret (discover by gifting)'}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {mode === 'buku' && tab === 'missions' && (
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2.5">
                <h3 className="font-extrabold text-xs uppercase tracking-wider text-[#6e4624]">
                  Daily Missions (Gold Rewards)
                </h3>
                {dailyMissions.map((m) => {
                  const done = m.progress >= m.target;
                  return (
                    <div key={m.id} className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-sm">{m.title}</span>
                        <span className="text-xs font-black tabular-nums text-[#784820]">
                          {Math.min(m.progress, m.target)}/{m.target}
                        </span>
                      </div>
                      <p className="text-xs text-[#5c3c22]">{m.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-[#3a6b2c]">
                          Reward: +{m.rewardGold} G
                        </span>
                        <button
                          type="button"
                          disabled={!done || m.claimed}
                          onClick={() => onClaimMission(m.id)}
                          className="px-3 py-1 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#cbbca3] text-white text-xs font-extrabold cursor-pointer"
                        >
                          {m.claimed ? 'Claimed' : done ? 'Claim Gold' : 'In Progress'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="space-y-2.5">
                <h3 className="font-extrabold text-xs uppercase tracking-wider text-[#6e4624]">
                  Villager Story Quests
                </h3>
                {QUESTS.map((q) => {
                  const isDone = completedQuests.includes(q.id);
                  return (
                    <div
                      key={q.id}
                      className={`rounded-2xl border-2 p-3 ${
                        isDone ? 'border-[#8db07b] bg-[#e7f1df]' : 'border-[#d3bc92] bg-[#fffaf0]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-extrabold text-sm">{q.title}</span>
                        <span className="text-[11px] font-bold text-[#3a6b2c]">
                          {isDone ? '✅ Completed' : `Meet ${NPC_MAP[q.npcId]?.name}`}
                        </span>
                      </div>
                      <p className="text-xs text-[#5c3c22] mt-1">{q.description}</p>
                      <div className="text-[11px] font-bold text-[#784820] mt-1">
                        Reward: {q.rewardGold} G · +{q.rewardFriendship} FP
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {mode === 'buku' && tab === 'jobs' && (
            <div className="space-y-4">
              {/* 2 Clean Submenus: Hire Worker (Sewa Pekerja) vs Accept Job (Terima Kerja) */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setJobSubmenu('hire')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-extrabold border-2 cursor-pointer transition-colors ${
                    jobSubmenu === 'hire'
                      ? 'bg-[#3a6b2c] text-white border-[#1f4416]'
                      : 'bg-[#fffaf0] text-[#5c3c22] border-[#d3bc92] hover:bg-[#efe2c6]'
                  }`}
                >
                  📋 {t(language, 'jobs.hireTab')}
                </button>
                <button
                  type="button"
                  onClick={() => setJobSubmenu('accept')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-extrabold border-2 cursor-pointer transition-colors ${
                    jobSubmenu === 'accept'
                      ? 'bg-[#0284c7] text-white border-[#075985]'
                      : 'bg-[#fffaf0] text-[#5c3c22] border-[#d3bc92] hover:bg-[#efe2c6]'
                  }`}
                >
                  💼 {t(language, 'jobs.acceptTab')} ({allJobs.filter((j) => j.employerUid !== profile.uid).length})
                </button>
              </div>

              {jobSubmenu === 'hire' && (
                <div className="space-y-4">
                  {/* Offer a Farm Job Card */}
                  <div className="rounded-2xl border-2 border-[#7a4b26] bg-[#fffaf0] p-4 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <h3 className="font-extrabold text-sm text-[#3c2310]">{t(language, 'jobs.offerJob')}</h3>
                        <p className="text-[11px] text-[#5c3c22]">{t(language, 'jobs.progressRule')}</p>
                      </div>
                      <div className="text-xs font-black text-[#3a6b2c] bg-[#e7f1df] px-3 py-1 rounded-lg border border-[#96b884]">
                        {selectedCropUnits} {language === 'id' ? 'petak' : 'plots'} + {selectedAnimalUnits}{' '}
                        {language === 'id' ? 'ternak' : 'livestock'} = {computedTotalUnits}{' '}
                        {language === 'id' ? 'unit' : 'units'}
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
                      {(
                        [
                          ['water_crops', `${t(language, 'jobs.waterCrops')} (${plotCountForJob})`],
                          ['feed_cow', `${t(language, 'jobs.feedCow')} (${cowCount})`],
                          ['feed_sheep', `${t(language, 'jobs.feedSheep')} (${sheepCount})`],
                          ['feed_horse', `${t(language, 'jobs.feedHorse')} (${horseCount})`],
                          ['feed_dog', `${t(language, 'jobs.feedDog')} (${dogCount})`],
                        ] as const
                      ).map(([taskId, label]) => (
                        <label
                          key={taskId}
                          className={`flex items-center gap-2 rounded-xl border px-3 py-2 text-xs font-bold cursor-pointer ${
                            jobTasks.includes(taskId)
                              ? 'bg-[#dcecd1] border-[#3a6b2c] text-[#1f4416]'
                              : 'bg-[#f9f3e4] border-[#d3bc92] text-[#5c3c22]'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={jobTasks.includes(taskId)}
                            onChange={() => toggleJobTask(taskId)}
                            className="accent-[#3a6b2c]"
                          />
                          <span>{label}</span>
                        </label>
                      ))}
                    </div>

                    <div className="flex flex-wrap items-end gap-3 pt-1">
                      <div className="w-44">
                        <label className="block text-[11px] font-extrabold text-[#5c3c22] mb-1">
                          {t(language, 'jobs.wage')}
                        </label>
                        <input
                          type="number"
                          min={10}
                          max={Math.max(10, profile.gold)}
                          step={50}
                          value={jobWage}
                          onChange={(e) => setJobWage(Math.max(10, Number(e.target.value) || 10))}
                          className="w-full rounded-xl border border-[#bfa070] bg-white px-3 py-1.5 text-sm font-black tabular-nums"
                        />
                      </div>
                      <button
                        type="button"
                        disabled={jobTasks.length === 0 || profile.gold < jobWage || !onCreateFarmJob}
                        onClick={() => {
                          if (!onCreateFarmJob) return;
                          onCreateFarmJob(jobTasks, jobWage, selectedCropUnits, selectedAnimalUnits);
                        }}
                        className="px-4 py-2 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#cbbca3] text-white text-xs font-extrabold cursor-pointer"
                      >
                        💼 {t(language, 'jobs.postJob')} ({jobWage.toLocaleString()} G)
                      </button>
                    </div>
                  </div>

                  {/* My Posted Jobs */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-extrabold uppercase tracking-wider text-[#6e4624]">
                      {language === 'id' ? 'Lowongan Pekerjaan Kebun Saya' : 'My Posted Farm Jobs'}
                    </h4>
                    {allJobs.filter((j) => j.employerUid === profile.uid).length === 0 && (
                      <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-3 text-xs text-center text-[#6e4624]">
                        {language === 'id'
                          ? 'Anda belum memasang lowongan kerja hari ini.'
                          : 'You have not posted any farm jobs yet.'}
                      </div>
                    )}
                    {allJobs
                      .filter((j) => j.employerUid === profile.uid)
                      .map((job) => {
                        const pct = Math.min(100, Math.round((job.completedTaskIds.length / Math.max(1, job.totalUnits)) * 100));
                        return (
                          <div key={job.id} className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-3.5 space-y-2">
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <div>
                                <div className="font-extrabold text-sm">🏡 {job.farmName}</div>
                                <div className="text-[11px] font-bold text-[#5c3c22]">
                                  {job.tasks.join(', ')} · {job.cropCount} crops + {job.animalCount} animals = {job.totalUnits} units
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="text-sm font-black text-[#3a6b2c] tabular-nums">💰 {job.wageGold.toLocaleString()} G</div>
                                <div className="text-[10px] font-bold text-[#784820]">
                                  {job.status === 'open'
                                    ? language === 'id'
                                      ? 'Menunggu Pekerja'
                                      : 'Waiting for Worker'
                                    : `${language === 'id' ? 'Dikerjakan' : 'Working'}: ${job.workerName} (${pct}%)`}
                                </div>
                              </div>
                            </div>
                            <div className="flex justify-end gap-2">
                              {job.status === 'open' && onCancelFarmJob && (
                                <button
                                  type="button"
                                  onClick={() => onCancelFarmJob(job.id)}
                                  className="px-3.5 py-1.5 rounded-xl bg-[#a63424] hover:bg-[#822518] text-white text-xs font-extrabold cursor-pointer"
                                >
                                  {language === 'id' ? 'Batalkan' : 'Cancel'}
                                </button>
                              )}
                              {job.status === 'in_progress' && onCompleteFarmJob && (
                                <button
                                  type="button"
                                  onClick={() => onCompleteFarmJob(job.id)}
                                  className="px-3.5 py-1.5 rounded-xl bg-[#0284c7] hover:bg-[#0369a1] text-white text-xs font-extrabold cursor-pointer"
                                >
                                  {t(language, 'jobs.finishClaim')} ({pct}%)
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
              )}

              {jobSubmenu === 'accept' && (
                <div className="space-y-2.5">
                  <div className="rounded-xl bg-[#e0f2fe] border border-[#7dd3fc] px-3 py-2 text-xs font-bold text-[#0c4a6e]">
                    {t(language, 'jobs.progressRule')}
                  </div>
                  {allJobs.filter((j) => j.employerUid !== profile.uid).length === 0 && (
                    <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-5 text-xs text-center text-[#6e4624]">
                      {t(language, 'jobs.noJobs')}
                    </div>
                  )}
                  {allJobs
                    .filter((j) => j.employerUid !== profile.uid)
                    .map((job) => {
                      const pct = Math.min(100, Math.round((job.completedTaskIds.length / Math.max(1, job.totalUnits)) * 100));
                      const isMyActiveWork = job.workerUid === profile.uid;
                      return (
                        <div key={job.id} className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-3.5 space-y-2">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div>
                              <div className="font-extrabold text-sm">
                                🏡 {job.farmName}{' '}
                                <span className="text-xs font-semibold text-[#6e4624]">({job.employerName})</span>
                              </div>
                              <div className="text-[11px] font-bold text-[#5c3c22]">
                                {job.tasks.join(', ')} · {job.cropCount} crops + {job.animalCount} animals = {job.totalUnits} units
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-sm font-black text-[#3a6b2c] tabular-nums">
                                💰 {job.wageGold.toLocaleString()} G
                              </div>
                              <div className="text-[10px] font-bold text-[#784820]">
                                {job.status === 'open'
                                  ? language === 'id'
                                    ? 'Tersedia'
                                    : 'Available'
                                  : `${language === 'id' ? 'Dikerjakan' : 'Working'}: ${job.workerName} (${pct}%)`}
                              </div>
                            </div>
                          </div>

                          {job.status === 'in_progress' && (
                            <div className="h-2 rounded-full bg-[#efe2c6] overflow-hidden">
                              <div className="h-full bg-[#3a6b2c]" style={{ width: `${pct}%` }} />
                            </div>
                          )}

                          <div className="flex flex-wrap items-center justify-end gap-2">
                            {job.status === 'open' && onAcceptFarmJob && (
                              <button
                                type="button"
                                onClick={() => {
                                  onAcceptFarmJob(job);
                                  onClose();
                                }}
                                className="px-3.5 py-1.5 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] text-white text-xs font-extrabold cursor-pointer"
                              >
                                {t(language, 'jobs.acceptJob')}
                              </button>
                            )}
                            {job.status === 'in_progress' && isMyActiveWork && onCompleteFarmJob && (
                              <button
                                type="button"
                                onClick={() => onCompleteFarmJob(job.id)}
                                className="px-3.5 py-1.5 rounded-xl bg-[#0284c7] hover:bg-[#0369a1] text-white text-xs font-extrabold cursor-pointer"
                              >
                                {t(language, 'jobs.finishClaim')} ({pct}% → {Math.round((job.wageGold * pct) / 100).toLocaleString()} G)
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          )}

          {mode === 'buku' && tab === 'p2p_market' && (
            <div className="space-y-4">
              {/* Strict Diamond-Only Ecosystem Notice */}
              <div className="rounded-2xl border-2 border-[#0284c7] bg-[#e0f2fe] px-3.5 py-2.5 text-xs text-[#0c4a6e] flex flex-wrap items-center justify-between gap-2">
                <div>
                  <div className="font-extrabold">💎 {t(language, 'market.p2pTitle')}</div>
                  <div className="text-[11px] font-semibold">
                    {language === 'id'
                      ? 'Jual-beli antar pemain menggunakan Berlian (Diamond) seperti pasar dunia nyata. Barang berharga Copper/Gold hanya dijual oleh NPC di desa!'
                      : 'Real-world virtual P2P Marketplace between farmers using Diamonds ONLY. All Gold/Copper items are sold exclusively at village NPCs!'}
                  </div>
                </div>
                <span className="font-black text-sm tabular-nums shrink-0">
                  💎 {DEVELOPER_DEBUG_MODE ? '∞' : profile.diamond.toLocaleString()}
                </span>
              </div>

              {/* Submenu tabs: Buy / Sell / My Listings & History */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setP2pSubmenu('buy')}
                  className={`py-2 px-2 rounded-xl text-xs font-extrabold border-2 cursor-pointer ${
                    p2pSubmenu === 'buy'
                      ? 'bg-[#0284c7] text-white border-[#075985]'
                      : 'bg-[#fffaf0] text-[#5c3c22] border-[#d3bc92]'
                  }`}
                >
                  🛍️ {t(language, 'market.buyDiamond')} ({allP2PListings.length})
                </button>
                <button
                  type="button"
                  onClick={() => setP2pSubmenu('sell')}
                  className={`py-2 px-2 rounded-xl text-xs font-extrabold border-2 cursor-pointer ${
                    p2pSubmenu === 'sell'
                      ? 'bg-[#3a6b2c] text-white border-[#1f4416]'
                      : 'bg-[#fffaf0] text-[#5c3c22] border-[#d3bc92]'
                  }`}
                >
                  🏷️ {t(language, 'market.sellDiamond')}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setP2pSubmenu('history');
                    fetchMyTransactionHistory().then(setMyTransactions).catch(() => {});
                  }}
                  className={`py-2 px-2 rounded-xl text-xs font-extrabold border-2 cursor-pointer ${
                    p2pSubmenu === 'history'
                      ? 'bg-[#784820] text-white border-[#4b2d16]'
                      : 'bg-[#fffaf0] text-[#5c3c22] border-[#d3bc92]'
                  }`}
                >
                  📜 {language === 'id' ? 'Riwayat & Lapakku' : 'My Listings & History'}
                </button>
              </div>

              {p2pStatusMsg && (
                <div className="rounded-xl bg-[#e7f1df] border border-[#96b884] px-3 py-2 text-xs font-bold text-[#1f4416]">
                  {p2pStatusMsg}
                </div>
              )}

              {/* BUY WITH DIAMONDS */}
              {p2pSubmenu === 'buy' && (
                <div className="space-y-3">
                  <div className="flex flex-wrap gap-2 items-center">
                    <div className="relative flex-1 min-w-[180px]">
                      <Search className="w-3.5 h-3.5 text-[#6e4624] absolute left-2.5 top-1/2 -translate-y-1/2" />
                      <input
                        value={p2pSearch}
                        onChange={(e) => setP2pSearch(e.target.value)}
                        placeholder={language === 'id' ? 'Cari barang, jasa, atau penjual...' : 'Search item, service, or seller...'}
                        className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-[#bfa070] bg-[#fffaf0] text-xs font-semibold"
                      />
                    </div>
                    <select
                      value={p2pCategoryFilter}
                      onChange={(e) => setP2pCategoryFilter(e.target.value)}
                      className="rounded-xl border border-[#bfa070] bg-[#fffaf0] px-2.5 py-1.5 text-xs font-bold"
                    >
                      <option value="all">{language === 'id' ? 'Semua Kategori' : 'All Categories'}</option>
                      {P2P_CATEGORIES.map((c) => (
                        <option key={c.id} value={c.id}>
                          {language === 'id' ? c.idLabel : c.en}
                        </option>
                      ))}
                    </select>
                  </div>

                  {allP2PListings.length === 0 ? (
                    <div className="rounded-2xl border border-[#d3bc92] bg-[#fffaf0] p-6 text-center text-xs text-[#6e4624]">
                      {language === 'id'
                        ? 'Belum ada barang atau jasa yang dijual pemain di kategori ini.'
                        : 'No player items or services listed in this category yet.'}
                    </div>
                  ) : (
                    <div className="grid sm:grid-cols-2 gap-2.5">
                      {allP2PListings.map((listing) => {
                        const isMine = listing.sellerUid === profile.uid;
                        const def = ITEMS[listing.itemId];
                        const catObj = P2P_CATEGORIES.find((c) => c.id === listing.category);
                        const canAfford = DEVELOPER_DEBUG_MODE || profile.diamond >= listing.diamondPrice;
                        return (
                          <div
                            key={listing.id}
                            className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-3 flex flex-col justify-between gap-2"
                          >
                            <div className="space-y-1">
                              <div className="flex items-start justify-between gap-2">
                                <div className="font-extrabold text-sm flex items-center gap-1.5 min-w-0">
                                  <span>{def?.iconEmoji || (listing.category === 'services' ? '🤝' : '📦')}</span>
                                  <span className="truncate">{listing.itemName}</span>
                                  {listing.quantity > 1 && (
                                    <span className="text-xs text-[#6e4624]">x{listing.quantity}</span>
                                  )}
                                </div>
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-lg bg-[#efe2c6] shrink-0">
                                  {catObj ? (language === 'id' ? catObj.idLabel : catObj.en) : listing.category}
                                </span>
                              </div>
                              <p className="text-xs text-[#4b2d16] bg-[#f9f3e4] rounded-lg px-2 py-1.5 border border-[#e6d5b8]">
                                {listing.description || (language === 'id' ? 'Tidak ada keterangan.' : 'No description.')}
                              </p>
                              <div className="text-[10px] font-bold text-[#6e4624]">
                                {language === 'id' ? 'Penjual' : 'Seller'}: <strong>{listing.sellerName}</strong>
                              </div>
                            </div>
                            <div className="flex items-center justify-between gap-2 pt-1 border-t border-[#efe2c6]">
                              <span className="text-sm font-black text-[#0369a1] tabular-nums">
                                <span className="block">Market {listing.diamondPrice.toLocaleString()} 💎</span>
                                <span className="block text-[9px] font-bold text-[#6e4624]">Base {(listing.baseDiamondPrice ?? listing.diamondPrice).toLocaleString()} 💎</span>
                              </span>
                              {isMine ? (
                                <button
                                  type="button"
                                  onClick={async () => {
                                    if (!onCancelP2PListing) return;
                                    const ok = await onCancelP2PListing(listing);
                                    if (ok) {
                                      setP2pStatusMsg(language === 'id' ? 'Lapak dibatalkan.' : 'Listing cancelled.');
                                      fetchP2PMarketListings(p2pCategoryFilter, p2pSearch).then(setFetchedP2P).catch(() => {});
                                    }
                                  }}
                                  className="px-3 py-1.5 rounded-xl bg-[#a63424] hover:bg-[#822518] text-white text-xs font-extrabold cursor-pointer"
                                >
                                  {language === 'id' ? 'Tarik Lapak' : 'Cancel'}
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  disabled={!canAfford || !onBuyP2PListing}
                                  onClick={async () => {
                                    if (!onBuyP2PListing) return;
                                    const ok = await onBuyP2PListing(listing);
                                    if (ok) {
                                      setP2pStatusMsg(
                                        language === 'id'
                                          ? `✅ Berhasil membeli ${listing.itemName} seharga 💎 ${listing.diamondPrice}!`
                                          : `✅ Purchased ${listing.itemName} for 💎 ${listing.diamondPrice}!`
                                      );
                                      fetchP2PMarketListings(p2pCategoryFilter, p2pSearch).then(setFetchedP2P).catch(() => {});
                                    }
                                  }}
                                  className="px-3 py-1.5 rounded-xl bg-[#0284c7] hover:bg-[#0369a1] disabled:bg-[#cbbca3] text-white text-xs font-extrabold cursor-pointer disabled:cursor-not-allowed"
                                >
                                  {language === 'id' ? 'Beli 💎' : 'Buy 💎'}
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* SELL FOR DIAMONDS */}
              {p2pSubmenu === 'sell' && (
                <form
                  className="rounded-2xl border-2 border-[#7a4b26] bg-[#fffaf0] p-4 space-y-3"
                  onSubmit={async (e) => {
                    e.preventDefault();
                    if (!onCreateP2PListing) return;
                    if (sellMode === 'inventory') {
                      const chosen = tradeableInventorySlots.find((s) => s.idx === sellSlotIndex) || tradeableInventorySlots[0];
                      if (!chosen) return;
                      const qty = Math.max(1, Math.min(chosen.slot.quantity, sellQty));
                      const ok = await onCreateP2PListing({
                        slotIndex: chosen.idx,
                        itemId: chosen.slot.itemId,
                        itemName: chosen.def.name,
                        category: sellCategory,
                        quantity: qty,
                        diamondPrice: Math.max(1, sellPrice),
                        description: sellDescription.trim() || `${chosen.def.name} x${qty}`,
                      });
                      if (ok) {
                        setP2pStatusMsg(
                          language === 'id'
                            ? `✅ ${chosen.def.name} x${qty} berhasil dijual di Pasar P2P!`
                            : `✅ Listed ${chosen.def.name} x${qty} on the P2P Marketplace!`
                        );
                        setSellDescription('');
                        setP2pSubmenu('buy');
                        fetchP2PMarketListings(p2pCategoryFilter, p2pSearch).then(setFetchedP2P).catch(() => {});
                      }
                    } else {
                      if (!sellServiceTitle.trim()) return;
                      const ok = await onCreateP2PListing({
                        itemId: `service_${Date.now()}`,
                        itemName: sellServiceTitle.trim(),
                        category: 'services',
                        quantity: 1,
                        diamondPrice: Math.max(1, sellPrice),
                        description: sellDescription.trim() || sellServiceTitle.trim(),
                      });
                      if (ok) {
                        setP2pStatusMsg(
                          language === 'id'
                            ? `✅ Jasa "${sellServiceTitle.trim()}" berhasil diposting!`
                            : `✅ Service "${sellServiceTitle.trim()}" listed!`
                        );
                        setSellServiceTitle('');
                        setSellDescription('');
                        setP2pSubmenu('buy');
                        fetchP2PMarketListings(p2pCategoryFilter, p2pSearch).then(setFetchedP2P).catch(() => {});
                      }
                    }
                  }}
                >
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setSellMode('inventory')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border cursor-pointer ${
                        sellMode === 'inventory'
                          ? 'bg-[#3a6b2c] text-white border-[#1f4416]'
                          : 'bg-[#efe2c6] text-[#5c3c22] border-[#d3bc92]'
                      }`}
                    >
                      📦 {language === 'id' ? 'Jual Barang dari Tas' : 'Sell Inventory Item'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSellMode('service');
                        setSellCategory('services');
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border cursor-pointer ${
                        sellMode === 'service'
                          ? 'bg-[#0284c7] text-white border-[#075985]'
                          : 'bg-[#efe2c6] text-[#5c3c22] border-[#d3bc92]'
                      }`}
                    >
                      🤝 {language === 'id' ? 'Tawarkan Jasa' : 'Offer a Service'}
                    </button>
                  </div>

                  {sellMode === 'inventory' ? (
                    tradeableInventorySlots.length === 0 ? (
                      <div className="rounded-xl bg-[#fae1da] border border-[#d49689] p-3 text-xs font-bold text-[#751d11]">
                        {language === 'id'
                          ? 'Belum ada item bertanda 💎 Tradeable di tas Anda. Panen/kumpulkan item untuk mendapatkan item yang memenuhi syarat jual Diamond (diatur persentasenya oleh Developer).'
                          : 'No 💎 Diamond-tradeable items in your bag yet. Harvest or gather items to roll Diamond trade eligibility!'}
                      </div>
                    ) : (
                      <div className="grid sm:grid-cols-2 gap-2.5">
                        <div>
                          <label className="block text-[11px] font-extrabold mb-1">
                            {language === 'id' ? 'Pilih Item (💎 Tradeable)' : 'Select Item (💎 Tradeable)'}
                          </label>
                          <select
                            value={
                              tradeableInventorySlots.some((s) => s.idx === sellSlotIndex)
                                ? sellSlotIndex
                                : tradeableInventorySlots[0].idx
                            }
                            onChange={(e) => setSellSlotIndex(Number(e.target.value))}
                            className="w-full rounded-xl border border-[#bfa070] bg-white px-2.5 py-1.5 text-xs font-bold"
                          >
                            {tradeableInventorySlots.map(({ slot, idx, def }) => (
                              <option key={`${slot.itemId}_${idx}`} value={idx}>
                                {def.iconEmoji} {def.name} (x{slot.quantity}) 💎
                              </option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="block text-[11px] font-extrabold mb-1">
                            {language === 'id' ? 'Kategori Barang' : 'Category'}
                          </label>
                          <select
                            value={sellCategory}
                            onChange={(e) => setSellCategory(e.target.value as MarketplaceCategory)}
                            className="w-full rounded-xl border border-[#bfa070] bg-white px-2.5 py-1.5 text-xs font-bold"
                          >
                            {P2P_CATEGORIES.map((c) => (
                              <option key={c.id} value={c.id}>
                                {language === 'id' ? c.idLabel : c.en}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    )
                  ) : (
                    <div>
                      <label className="block text-[11px] font-extrabold mb-1">
                        {language === 'id' ? 'Nama Jasa yang Ditawarkan' : 'Service Title'}
                      </label>
                      <input
                        required
                        maxLength={48}
                        value={sellServiceTitle}
                        onChange={(e) => setSellServiceTitle(e.target.value)}
                        placeholder={language === 'id' ? 'cth. Jasa Bantu Panen & Siram Kebun' : 'e.g. Premium Farm Watering & Care Service'}
                        className="w-full rounded-xl border border-[#bfa070] bg-white px-3 py-1.5 text-xs font-bold"
                      />
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2.5">
                    {sellMode === 'inventory' && (
                      <div>
                        <label className="block text-[11px] font-extrabold mb-1">
                          {language === 'id' ? 'Jumlah' : 'Quantity'}
                        </label>
                        <input
                          type="number"
                          min={1}
                          max={
                            (
                              tradeableInventorySlots.find((s) => s.idx === sellSlotIndex) ||
                              tradeableInventorySlots[0]
                            )?.slot.quantity || 1
                          }
                          value={sellQty}
                          onChange={(e) => setSellQty(Math.max(1, Number(e.target.value) || 1))}
                          className="w-full rounded-xl border border-[#bfa070] bg-white px-3 py-1.5 text-xs font-black"
                        />
                      </div>
                    )}
                    <div>
                      <label className="block text-[11px] font-extrabold mb-1">
                        {language === 'id' ? 'Base Price (💎 Berlian)' : 'Base Price (💎 Diamonds)'}
                      </label>
                      <input
                        type="number"
                        min={1}
                        max={999999}
                        value={sellPrice}
                        onChange={(e) => setSellPrice(Math.max(1, Number(e.target.value) || 1))}
                        className="w-full rounded-xl border border-[#bfa070] bg-white px-3 py-1.5 text-xs font-black"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-extrabold mb-1">
                      {language === 'id' ? 'Keterangan / Deskripsi Penjual' : 'Seller Description (Keterangan)'}
                    </label>
                    <textarea
                      rows={2}
                      maxLength={200}
                      value={sellDescription}
                      onChange={(e) => setSellDescription(e.target.value)}
                      placeholder={
                        language === 'id'
                          ? 'Tuliskan kualitas barang, lokasi COD, atau detail jasa Anda...'
                          : 'Describe item quality, bundle details, or service terms...'
                      }
                      className="w-full rounded-xl border border-[#bfa070] bg-white px-3 py-1.5 text-xs font-medium"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={
                      !onCreateP2PListing ||
                      (sellMode === 'inventory' && tradeableInventorySlots.length === 0) ||
                      (sellMode === 'service' && !sellServiceTitle.trim())
                    }
                    className="w-full py-2.5 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#cbbca3] text-white text-xs font-extrabold cursor-pointer disabled:cursor-not-allowed"
                  >
                    🏷️ {language === 'id' ? `Pasang Base Price (💎 ${sellPrice})` : `Set Base Price (💎 ${sellPrice})`}
                  </button>
                </form>
              )}

              {/* MY TRANSACTION HISTORY */}
              {p2pSubmenu === 'history' && (
                <div className="space-y-2.5">
                  <div className="text-xs font-extrabold uppercase text-[#6e4624]">
                    🔐 {language === 'id' ? 'Riwayat Transaksi Terenkripsi Anda' : 'Your Encrypted Transaction History'} ({myTransactions.length})
                  </div>
                  {myTransactions.length === 0 ? (
                    <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-4 text-center text-xs text-[#6e4624]">
                      {language === 'id' ? 'Belum ada transaksi tercatat.' : 'No transactions recorded yet.'}
                    </div>
                  ) : (
                    myTransactions.map((tx) => (
                      <div
                        key={tx.id}
                        className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-xs"
                      >
                        <div>
                          <div className="font-extrabold">
                            {tx.itemName || tx.type} {tx.quantity ? `x${tx.quantity}` : ''}
                          </div>
                          <div className="text-[10px] text-[#6e4624]">
                            {tx.buyerName} {tx.sellerName ? `← ${tx.sellerName}` : ''} ·{' '}
                            {new Date(tx.timestamp).toLocaleString()}
                          </div>
                        </div>
                        <span className="font-black text-[#0369a1] tabular-nums">
                          {tx.currency === 'diamond' ? '💎' : '💰'} {tx.amount.toLocaleString()}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          )}

          {mode === 'buku' && tab === 'leaderboard' && (
            <div className="space-y-3">
              {/* Gold and Diamond tax pools */}
              <div className="rounded-2xl border-2 border-[#c59a45] bg-[#fae8c4] p-3.5 flex flex-wrap items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="text-xs font-black uppercase tracking-wider text-[#6e4624]">
                    Great Valley Economy Tax Pool
                  </div>
                  <div className="text-sm font-extrabold text-[#3c2310]">
                    Gold Tax Pool: {marketState ? marketState.taxPool.toLocaleString() : 0} G · Diamond Tax Pool: {marketState ? (marketState.taxPoolDiamond || 0).toLocaleString() : 0} 💎
                  </div>
                  <div className="text-[11px] font-bold text-[#5c3c22]">
                    🥇 Rank #1 (50%): {taxBuckets[1] || 0} G · 🥈 #2 (30%): {taxBuckets[2] || 0} G · 🥉 #3 (20%): {taxBuckets[3] || 0} G
                  </div>
                </div>
                <button
                  type="button"
                  disabled={claimingTax}
                  onClick={async () => {
                    setClaimingTax(true);
                    try {
                      await onClaimTaxReward();
                    } finally {
                      setClaimingTax(false);
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#cbbca3] text-white text-xs font-extrabold cursor-pointer shrink-0"
                >
                  {claimingTax ? 'Checking...' : '🏆 Claim Tax Dividend'}
                </button>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {[
                  ['totalWealth', 'Total Wealth'],
                  ['farmingLevel', 'Farming Level'],
                  ['cropsHarvested', 'Crops Harvested'],
                  ['animalsCount', 'Livestock Count'],
                  ['fishCaught', 'Fish Caught'],
                  ['achievementsCount', 'Achievements'],
                  ['villageReputation', 'Village Reputation'],
                ].map(([key, label]) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setLbCategory(key)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border cursor-pointer ${
                      lbCategory === key ? 'bg-[#3a6b2c] text-white border-[#214417]' : 'bg-[#fffaf0] border-[#d3bc92]'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>

              <div className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] overflow-hidden">
                {leaderboard.map((row, idx) => (
                  <div
                    key={row.uid}
                    className={`px-4 py-2.5 flex items-center justify-between border-b border-[#efe2c6] last:border-b-0 ${
                      row.uid === profile.uid ? 'bg-[#e7f1df]' : ''
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-7 h-7 rounded-full bg-[#f2cf7e] text-[#4b2d16] font-black text-xs flex items-center justify-center">
                        #{idx + 1}
                      </span>
                      <div>
                        <div className="font-extrabold text-sm">
                          {row.avatarName} <span className="text-xs font-semibold text-[#6e4624]">({row.farmName})</span>
                        </div>
                        <div className="text-[11px] text-[#5c3c22]">Lv.{row.farmingLevel} · Harvested {row.cropsHarvested}</div>
                      </div>
                    </div>
                    <div className="font-black text-sm tabular-nums text-[#3a6b2c]">
                      {String(row[lbCategory as keyof LeaderboardRecord] ?? 0)}
                    </div>
                  </div>
                ))}
                {leaderboard.length === 0 && (
                  <div className="p-6 text-center text-xs text-[#6e4624]">Loading Great Valley rankings...</div>
                )}
              </div>
            </div>
          )}

          {mode === 'buku' && tab === 'multiplayer' && (
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-[#efe2c6] border-2 border-[#c59a45] p-3">
                <div className="text-xs font-bold text-[#4b2d16]">
                  {visitingFarmOwnerId
                    ? 'You are currently visiting another player’s homestead!'
                    : 'Live Multiplayer Sync: Meet fellow farmers in Village Square or visit their farms.'}
                </div>
                {visitingFarmOwnerId && (
                  <button
                    type="button"
                    onClick={() => {
                      onReturnHome();
                      onClose();
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-[#3a6b2c] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Home className="w-3.5 h-3.5" /> Return to My Farm
                  </button>
                )}
              </div>

              <div className="space-y-2">
                {onlinePlayers.map((p) => (
                  <div key={p.clientId} className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-3 flex items-center justify-between gap-2">
                    <div>
                      <div className="font-extrabold text-sm">
                        {p.avatarName} {p.uid === profile.uid && '(You)'}
                        {p.spousePlayerName && (
                          <span className="ml-2 text-[10px] px-2 py-0.5 rounded-lg bg-[#fae1da] text-[#9e3b24]">
                            💍 {p.spousePlayerName}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-[#5c3c22]">
                        🏡 {p.farmName} · 📍 {ZONE_LABELS[p.zone] || p.zone} · Lv.{p.level}
                      </div>
                    </div>
                    {p.uid !== profile.uid && (
                      <button
                        type="button"
                        onClick={() => {
                          onVisitFarm(p.uid, p.farmName);
                          onClose();
                        }}
                        className="px-3.5 py-2 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] text-white text-xs font-extrabold cursor-pointer"
                      >
                        Visit Farm
                      </button>
                    )}
                  </div>
                ))}
                {onlinePlayers.length <= 1 && (
                  <div className="rounded-2xl border border-[#d3bc92] bg-[#fffaf0] p-4 text-xs text-center text-[#6e4624]">
                    Open a second browser tab to this URL to play live multiplayer with another farmer!
                  </div>
                )}
              </div>
            </div>
          )}

          {mode === 'buku' && tab === 'iap' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-[#efe2c6] p-3 border border-[#d3bc92]">
                <div>
                  <div className="text-sm font-extrabold">
                    💎 Diamond Balance: {effectiveDebugMode ? 'Unlimited (∞)' : profile.diamond.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-[#5c3c22]">
                    {t(language, 'market.npcCopperNote')}
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  {anyPaymentGatewayEnabled && <span className="font-bold">Method:</span>}
                  {effectivePaymentMethods.googlePlayBilling && (
                    <button
                      type="button"
                      onClick={() => setIapProvider('google_play')}
                      className={`px-3 py-1 rounded-xl font-bold border cursor-pointer ${
                        iapProvider === 'google_play' ? 'bg-[#3a6b2c] text-white border-[#214417]' : 'bg-[#fffaf0] border-[#d3bc92]'
                      }`}
                    >
                      Google Play Billing
                    </button>
                  )}
                  {effectivePaymentMethods.duitku && (
                    <button
                      type="button"
                      onClick={() => setIapProvider('duitku')}
                      className={`px-3 py-1 rounded-xl font-bold border cursor-pointer ${
                        iapProvider === 'duitku' ? 'bg-[#784820] text-white border-[#4b2d16]' : 'bg-[#fffaf0] border-[#d3bc92]'
                      }`}
                    >
                      Duitku Payment
                    </button>
                  )}
                  {!anyPaymentGatewayEnabled && (
                    <span className="px-2.5 py-1 rounded-lg bg-[#fae1da] text-[#751d11] font-extrabold text-[11px]">
                      {language === 'id' ? 'Metode Pembayaran Dimatikan Sementara' : 'Payment Methods Temporarily Disabled'}
                    </span>
                  )}
                </div>
              </div>

              {iapMsg && <div className="rounded-xl bg-[#e7f1df] border border-[#96b884] px-3 py-2 text-xs font-bold">{iapMsg}</div>}

              {/* Diamond-Only Bag Expansions + Exclusive Diamond Items */}
              <div className="rounded-2xl border-2 border-[#7a4b26] bg-[#fffaf0] p-3.5 space-y-2.5">
                <div className="text-xs font-extrabold uppercase tracking-wider text-[#6e4624]">
                  Diamond Bag Upgrades &amp; Specialty Perks
                </div>

                <div className="rounded-xl border border-[#d3bc92] bg-[#efe2c6]/60 p-3 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="font-extrabold text-sm">
                      🎒 Expand Bag Capacity +6 Slots ({bagUpgrades}/{MAX_BAG_UPGRADES})
                    </div>
                    <div className="text-[11px] text-[#5c3c22]">
                      Current capacity: {maxBagSlots} slots (up to 90 slots across 11 upgrades).
                    </div>
                  </div>
                  {nextBagCost !== null ? (
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        disabled={!effectiveDebugMode && profile.diamond < nextBagCost}
                        onClick={onBuyBagUpgrade}
                        className="px-3 py-2 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#cbbca3] text-white text-xs font-extrabold cursor-pointer disabled:cursor-not-allowed"
                      >
                        Upgrade (💎 {nextBagCost})
                      </button>
                    </div>
                  ) : (
                    <span className="px-3 py-1 rounded-lg bg-[#e7f1df] text-[#23481a] text-xs font-black">
                      ✅ Max Bag Capacity (90)
                    </span>
                  )}
                </div>

                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                  {exclusiveDiamondItems.map((item) => {
                    const isOwnedPhone = item.id === 'item_valley_phone' && Boolean(profile.hasPhone);
                    const liveDiamondPrice = marketState?.prices?.[item.id]?.diamondPrice ?? (item.diamondPrice || 99);
                    return (
                      <div key={item.id} className="rounded-xl border border-[#d3bc92] bg-[#f9f3e4] p-3 flex flex-col justify-between gap-2">
                        <div>
                          <div className="text-2xl">{item.iconEmoji}</div>
                          <div className="font-extrabold text-xs mt-1">{item.name}</div>
                          <p className="text-[10px] text-[#5c3c22] mt-0.5">{item.description}</p>
                        </div>
                        <button
                          type="button"
                          disabled={isOwnedPhone || (!effectiveDebugMode && profile.diamond < liveDiamondPrice)}
                          onClick={() => onBuyDiamondItem(item.id)}
                          className="w-full py-1.5 rounded-lg bg-[#8a4d22] hover:bg-[#6e3e19] disabled:bg-[#cbbca3] text-white text-xs font-extrabold cursor-pointer disabled:cursor-not-allowed"
                        >
                          {isOwnedPhone ? '✅ Owned' : `Buy 💎 ${liveDiamondPrice}`}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Wardrobe Outfits & Character Customization */}
              <div className="rounded-2xl border-2 border-[#7a4b26] bg-[#fffaf0] p-3.5 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="text-xs font-extrabold uppercase tracking-wider text-[#6e4624]">
                    👕 Specialty Wardrobe Outfits &amp; Style Studio
                  </div>
                  {onOpenStyleStudio && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenStyleStudio();
                      }}
                      className="px-3 py-1 rounded-lg bg-[#0284c7] hover:bg-[#0369a1] text-white text-[11px] font-extrabold cursor-pointer"
                    >
                      ✨ {t(language, 'style.studioTitle')} (💎 {CUSTOMIZATION_DIAMOND_COST})
                    </button>
                  )}
                </div>
                <div className="grid sm:grid-cols-2 gap-2.5">
                  {OUTFIT_CATALOG.filter((o) => o.diamondPrice > 0).map((outfit) => {
                    const owned = (profile.unlockedOutfits || []).includes(outfit.id);
                    return (
                      <div key={outfit.id} className="rounded-xl border border-[#d3bc92] bg-[#f9f3e4] p-2.5 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-lg border border-[#7a4b26] shrink-0 flex flex-col overflow-hidden">
                            <div className="flex-1" style={{ backgroundColor: outfit.shirtColor }} />
                            <div className="flex-1" style={{ backgroundColor: outfit.pantsColor }} />
                          </div>
                          <div className="min-w-0">
                            <div className="font-extrabold text-xs truncate">{outfit.name}</div>
                            <div className="text-[10px] text-[#5c3c22] line-clamp-1">{outfit.description}</div>
                          </div>
                        </div>
                        <button
                          type="button"
                          disabled={owned || profile.diamond < outfit.diamondPrice}
                          onClick={() => onBuyOutfit(outfit.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-[#0284c7] hover:bg-[#0369a1] disabled:bg-[#96b884] text-white text-[11px] font-extrabold shrink-0 cursor-pointer disabled:cursor-not-allowed"
                        >
                          {owned ? 'Owned' : `💎 ${outfit.diamondPrice}`}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Diamond Top-Up Packages (Strictly Gated by live paymentMethods toggles) */}
              {anyPaymentGatewayEnabled ? (
                <div className="grid sm:grid-cols-3 gap-3">
                  {DIAMOND_PACKAGES.map((pkg) => (
                    <div key={pkg.id} className="rounded-2xl border-2 border-[#c59a45] bg-[#fffaf0] p-4 text-center space-y-2">
                      <div className="text-3xl">💎</div>
                      <div className="font-extrabold text-sm">{pkg.name}</div>
                      <div className="text-lg font-black text-[#784820]">{pkg.diamonds} Diamonds</div>
                      <button
                        type="button"
                        onClick={() => handleBuyDiamonds(pkg.id)}
                        className="w-full py-2 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] text-white text-xs font-extrabold cursor-pointer"
                      >
                        Purchase {pkg.priceLabel}
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="rounded-2xl border-2 border-[#d49689] bg-[#fae1da]/80 p-4 text-center text-xs font-extrabold text-[#751d11]">
                  {t(language, 'shop.paymentsDisabledNotice')}
                </div>
              )}

              <div className="space-y-2">
                <h4 className="text-xs font-extrabold uppercase text-[#6e4624]">Purchase History &amp; Receipts</h4>
                {iapHistory.map((tx) => (
                  <div key={tx.transactionId} className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] px-3 py-2 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-extrabold">{tx.transactionId}</span> · +{tx.diamondAmount} 💎 ({tx.provider})
                    </div>
                    <span className="font-bold text-[#3a6b2c]">Completed</span>
                  </div>
                ))}
                {iapHistory.length === 0 && (
                  <div className="text-xs text-[#6e4624]">No Diamond purchases recorded yet.</div>
                )}
              </div>
            </div>
          )}

          {mode === 'buku' && tab === 'profile' && (
            <div className="space-y-4">
              <div className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <h3 className="text-lg font-extrabold">
                    {profile.avatarName} — {profile.farmName}
                  </h3>
                  <div className="text-xs font-bold text-[#5c3c22]">
                    Level {profile.level} ({profile.xp}/{xpRequiredForLevel(profile.level)} XP) · Joy: {Math.round(profile.fun)}% · Birthday: {profile.birthday}
                  </div>
                  <div className="text-xs font-bold text-[#784820]">
                    🏡 House Lv.{profile.houseLevel}/3 · 🐄 Barn Lv.{profile.barnLevel || 1}/3 ({animals.filter((a) => a.type === 'cow' || a.type === 'sheep').length}/{getBarnCapacity(profile.barnLevel || 1)} troughs{profile.hasCheeseMaker ? ' · 🧀 Cheese Maker' : ''}) · 🐔 Coop Lv.{profile.coopLevel || 1}/3 ({animals.filter((a) => a.type === 'chicken').length}/{getCoopCapacity(profile.coopLevel || 1)} troughs · {getIncubatorCount(profile.coopLevel || 1)} Incubator{getIncubatorCount(profile.coopLevel || 1) > 1 ? 's' : ''})
                  </div>
                  <div className="text-xs text-[#3a6b2c] font-bold">
                    {profile.spousePlayerName
                      ? `💍 Married to Player: ${profile.spousePlayerName}`
                      : profile.spouseId
                        ? `💍 Married to Villager: ${NPC_MAP[profile.spouseId]?.name}`
                        : 'Status: Single'}{' '}
                    · Livestock: {animalsCount}
                  </div>
                  <div className="text-xs text-[#5c3c22] pt-1">
                    Harvested: {stats.cropsHarvested} · Fish Caught: {stats.fishCaught} · Gifts Given: {stats.giftsGiven}
                  </div>
                </div>
                <div className="flex flex-col gap-2 shrink-0">
                  {onOpenStyleStudio && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenStyleStudio();
                      }}
                      className="px-4 py-2 rounded-xl bg-[#0284c7] hover:bg-[#0369a1] text-white font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Sparkles className="w-4 h-4" /> {t(language, 'style.studioTitle')} (💎 {CUSTOMIZATION_DIAMOND_COST})
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={handleShare}
                    className="px-4 py-2 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] text-white font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Share2 className="w-4 h-4" /> Share Homestead Screenshot
                  </button>
                </div>
              </div>

              {/* Livestock Registry showing Animal Name, Birthday, Needs, Health & Emotion */}
              {animals.length > 0 && (
                <div className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-3.5 space-y-2">
                  <div className="text-xs font-extrabold uppercase tracking-wider text-[#6e4624]">
                    🐾 {language === 'id' ? 'Daftar Hewan Ternak, Kesehatan & Emosi' : 'Livestock Registry, Health & Emotions'} ({animals.length})
                  </div>
                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    {animals.map((a) => {
                      const emoji =
                        a.type === 'chicken' ? '🐔' : a.type === 'cow' ? '🐄' : a.type === 'sheep' ? '🐑' : a.type === 'horse' ? '🐎' : '🐕';
                      const hungerVal = Math.round(a.hunger ?? (a.fedToday ? 100 : 55));
                      const energyVal = Math.round(a.energy ?? 85);
                      const happyVal = Math.round(a.happiness ?? Math.min(100, Math.round((a.affection / 255) * 100)));
                      const healthVal = Math.round(a.health ?? (a.isSick ? 30 : 100));
                      const emoLabel =
                        language === 'id'
                          ? { happy: '😊 Senang', relaxed: '😌 Santai', scared: '😨 Takut', hungry: '🍽️ Lapar', sleepy: '😴 Ngantuk', stressed: '😣 Stres', sick: '🤒 Sakit' }[a.emotion || (a.isSick ? 'sick' : 'happy')]
                          : { happy: '😊 Happy', relaxed: '😌 Relaxed', scared: '😨 Scared', hungry: '🍽️ Hungry', sleepy: '😴 Sleepy', stressed: '😣 Stressed', sick: '🤒 Sick' }[a.emotion || (a.isSick ? 'sick' : 'happy')];
                      return (
                        <div
                          key={a.id}
                          className={`rounded-xl border px-3 py-2 text-xs space-y-1 ${
                            a.isSick ? 'border-[#dc2626] bg-[#fef2f2]' : 'border-[#d3bc92] bg-[#f9f3e4]'
                          }`}
                        >
                          <div className="font-extrabold flex items-center justify-between gap-1">
                            <span className="truncate">{emoji} {a.name}</span>
                            <span className={`text-[10px] font-black shrink-0 ${a.isSick ? 'text-[#b91c1c]' : 'text-[#3a6b2c]'}`}>
                              {a.isSick ? (language === 'id' ? '🤒 SAKIT' : '🤒 SICK') : emoLabel}
                            </span>
                          </div>
                          <div className="text-[10px] text-[#6e4624] font-semibold">
                            🎂 {language === 'id' ? 'Ultah' : 'B-day'}: {a.birthday || 'Spring 1'}
                            {a.bornYear ? ` (Yr ${a.bornYear})` : ''} · {a.fedToday ? (language === 'id' ? '✅ Sudah Makan' : '✅ Fed') : (language === 'id' ? '🍽️ Belum Makan' : '🍽️ Unfed')}
                          </div>
                          <div className="grid grid-cols-2 gap-x-2 gap-y-0.5 text-[10px] font-bold text-[#4b2d16]">
                            <span>🍖 {language === 'id' ? 'Lapar' : 'Hunger'}: {hungerVal}%</span>
                            <span>⚡ {language === 'id' ? 'Energi' : 'Energy'}: {energyVal}%</span>
                            <span>💛 {language === 'id' ? 'Bahagia' : 'Happy'}: {happyVal}%</span>
                            <span className={healthVal < 50 ? 'text-[#b91c1c]' : 'text-[#214617]'}>
                              ❤️ {language === 'id' ? 'Sehat' : 'Health'}: {healthVal}%
                            </span>
                          </div>
                          {a.isSick && (
                            <div className="text-[10px] font-extrabold text-[#b91c1c]">
                              💊 {language === 'id' ? 'Beri Obat Hewan (Klinik / Peternakan)!' : 'Use Animal Medicine (Clinic / Ranch)!'}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {screenshotUrl && (
                <img src={screenshotUrl} alt="Farm Screenshot" className="w-full max-h-52 object-cover rounded-2xl border-2 border-[#bfa070]" />
              )}

              <div className="grid sm:grid-cols-2 gap-2.5">
                {ACHIEVEMENTS.map((ach) => {
                  const unlocked = unlockedAchievements.includes(ach.id);
                  return (
                    <div
                      key={ach.id}
                      className={`rounded-2xl border-2 p-3 flex items-center gap-3 ${
                        unlocked ? 'border-[#d98a2b] bg-[#fae8c4]' : 'border-[#d3bc92] bg-[#fffaf0] opacity-75'
                      }`}
                    >
                      <span className="text-2xl">{ach.icon}</span>
                      <div>
                        <div className="font-extrabold text-sm">{ach.title}</div>
                        <div className="text-xs text-[#5c3c22]">{ach.description}</div>
                        <div className="text-[11px] font-bold text-[#3a6b2c]">
                          {unlocked ? '✅ Unlocked' : `Reward: +${ach.rewardGold} G`}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {mode === 'settings' && (
            <div className="space-y-4">
              {/* Reset to Home (teleports INSIDE private farmhouse) */}
              <div className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-4 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="font-extrabold text-sm flex items-center gap-1.5">
                      <Home className="w-4 h-4 text-[#3a6b2c]" /> Reset to Home (Teleport Indoors)
                    </h3>
                    <p className="text-xs text-[#5c3c22] mt-0.5">
                      Teleports your character directly <strong>INSIDE your private Farmhouse</strong>. 10-minute cooldown between uses.
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={cooldownRemainingMs > 0}
                    onClick={() => {
                      onResetToHome();
                      onClose();
                    }}
                    className="px-4 py-2 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#cbbca3] disabled:text-[#5c4e3e] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed shrink-0"
                  >
                    <Clock className="w-3.5 h-3.5" />
                    {cooldownRemainingMs > 0
                      ? `Wait ${String(cooldownMin).padStart(2, '0')}:${String(cooldownSec).padStart(2, '0')}`
                      : 'Reset to Home'}
                  </button>
                </div>
              </div>

              {/* Custom Keybindings */}
              <div className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-sm flex items-center gap-1.5">
                    <Keyboard className="w-4 h-4 text-[#784820]" /> Custom Keybindings &amp; Tool Shortcuts
                  </h3>
                  <button
                    type="button"
                    onClick={() => onUpdateKeyBindings({ ...DEFAULT_KEYBINDINGS })}
                    className="px-2.5 py-1 rounded-lg bg-[#efe2c6] hover:bg-[#e5d3b0] border border-[#bfa070] text-[11px] font-bold cursor-pointer"
                  >
                    Reset Defaults
                  </button>
                </div>

                <div className="grid sm:grid-cols-2 gap-2">
                  {KEY_LABELS.map(([field, label]) => {
                    const isListening = remappingKey === field;
                    return (
                      <div key={field} className="flex items-center justify-between rounded-xl bg-[#f9f3e4] border border-[#d3bc92] px-3 py-1.5 text-xs">
                        <span className="font-bold text-[#4b2d16]">{label}</span>
                        <button
                          type="button"
                          onClick={() => setRemappingKey(isListening ? null : field)}
                          className={`px-2.5 py-1 rounded-lg font-black text-[11px] border cursor-pointer ${
                            isListening
                              ? 'bg-[#d98a2b] text-white border-[#9e5316]'
                              : 'bg-[#fffaf0] text-[#2b1a0e] border-[#bfa070]'
                          }`}
                        >
                          {isListening ? 'Press Any Key...' : prettyKeyCode(keyBindings[field] || '')}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Gamepad / Joystick Support */}
              <div className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-sm flex items-center gap-1.5">
                    <Gamepad2 className="w-4 h-4 text-[#3a6b2c]" /> Gamepad / Controller Support
                  </h3>
                  <span
                    className={`px-2.5 py-0.5 rounded-lg text-[11px] font-extrabold ${
                      gamepadStatus.connected ? 'bg-[#dcecd1] text-[#23481a]' : 'bg-[#efe2c6] text-[#6e4624]'
                    }`}
                  >
                    {gamepadStatus.connected ? '🟢 Connected' : '⚪ Standby'}
                  </span>
                </div>
                <p className="text-xs text-[#5c3c22]">
                  {gamepadStatus.connected
                    ? `Active controller: ${gamepadStatus.name || 'Gamepad'}`
                    : 'Plug in any USB or Bluetooth controller and press a button. Left Stick: Move · Right Stick: Camera · A: Execute (F) · X: Talk (E) · Y: Bag · B: Chat · LB/RB: Sprint.'}
                </p>
              </div>

              {/* Audio & Notifications */}
              <div className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold">Sound Effects, Footsteps &amp; Cozy Music</span>
                  <button
                    type="button"
                    onClick={onToggleMute}
                    className="px-3 py-1.5 rounded-xl bg-[#efe2c6] border border-[#bfa070] text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    {muted ? <VolumeX className="w-4 h-4 text-[#a63424]" /> : <Volume2 className="w-4 h-4 text-[#3a6b2c]" />}
                    {muted ? 'Muted' : 'Enabled'}
                  </button>
                </div>

                <div className="pt-2 border-t border-[#efe2c6] space-y-2">
                  <h4 className="font-extrabold text-xs flex items-center gap-1.5 text-[#6e4624]">
                    <Bell className="w-3.5 h-3.5 text-[#b8711e]" /> Notifications
                  </h4>
                  {(
                    [
                      ['dailyMissions', 'Daily Missions'],
                      ['achievements', 'New Achievements'],
                      ['rewards', 'Harvests & Rewards'],
                      ['specialEvents', 'Festivals & Special Events'],
                      ['multiplayer', 'Multiplayer Alerts'],
                    ] as const
                  ).map(([k, label]) => (
                    <label key={k} className="flex items-center justify-between text-xs font-semibold cursor-pointer">
                      <span>{label}</span>
                      <input
                        type="checkbox"
                        checked={notifSettings[k]}
                        onChange={() => onToggleNotif(k)}
                        className="w-4 h-4 accent-[#3a6b2c]"
                      />
                    </label>
                  ))}
                </div>
              </div>

              {/* Exit Game Button at Bottom of Settings */}
              <div className="rounded-2xl border-2 border-[#d49689] bg-[#fae1da]/60 p-4 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="font-extrabold text-sm text-[#751d11]">Save &amp; Exit to Title Screen</h3>
                  <p className="text-xs text-[#5c3c22]">
                    Saves your farm progress locally and to Cloud Save before returning to the main menu.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={onExitGame}
                  className="px-4 py-2.5 rounded-xl bg-[#a63424] hover:bg-[#822518] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shrink-0 border-b-2 border-[#5c160c]"
                >
                  <LogOut className="w-4 h-4" /> Exit Game
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </DraggableWindow>
  );
};
