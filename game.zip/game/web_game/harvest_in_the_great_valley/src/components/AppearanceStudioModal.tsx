import React, { useState } from 'react';
import { Palette, Sparkles } from 'lucide-react';
import { HAIR_COLORS_CATALOG, HAIR_STYLES_CATALOG } from '../game/data/hairstyles';
import { CUSTOMIZATION_DIAMOND_COST } from '../game/data/worldConfig';
import { t } from '../game/i18n';
import type { AvatarConfig, Language } from '../game/types';
import { DraggableWindow } from './DraggableWindow';

export const AVATAR_SKIN_COLORS = ['#fde2c8', '#fcd5b5', '#e6b18a', '#c68b59', '#8d5524', '#5c3818'];
export const AVATAR_EYE_COLORS = ['#292524', '#1d4ed8', '#15803d', '#9333ea', '#b45309', '#be123c', '#0284c7'];
export const AVATAR_HAIR_COLORS = HAIR_COLORS_CATALOG.map((c) => c.hex);
export const AVATAR_OUTFIT_COLORS = ['#3a6b2c', '#9e3b24', '#c8832b', '#2563eb', '#4b5563', '#2f6b56', '#7c3aed', '#be185d', '#eab308', '#f8fafc'];
export const AVATAR_PANTS_COLORS = ['#1e3a8a', '#3f2e21', '#334155', '#365314', '#581c87', '#7c2d12', '#111827', '#92400e'];

export const HAIR_OPTIONS = HAIR_STYLES_CATALOG;

export const SHIRT_OPTIONS: Array<{ value: NonNullable<AvatarConfig['shirtStyle']>; en: string; id: string }> = [
  { value: 'none', en: 'None (Bare)', id: 'Polos (Tanpa Baju)' },
  { value: 'tunic', en: 'Field Tunic', id: 'Kaos / Tunik' },
  { value: 'overalls', en: 'Farmer Overalls', id: 'Overall Petani' },
  { value: 'vest', en: 'Work Vest', id: 'Rompi Kerja' },
  { value: 'sweater', en: 'Knit Sweater', id: 'Sweter Rajut' },
  { value: 'hoodie', en: 'Cozy Hoodie', id: 'Hoodie Santai' },
  { value: 'flannel', en: 'Plaid Flannel', id: 'Kemeja Flanel' },
  { value: 'jacket', en: 'Explorer Jacket', id: 'Jaket Petualang' },
  { value: 'apron', en: 'Baker Apron', id: 'Celemek Masak' },
  { value: 'kimono', en: 'Festival Kimono', id: 'Kimono Festival' },
  { value: 'polo', en: 'Valley Polo', id: 'Kaos Polo' },
];

export const PANTS_OPTIONS: Array<{ value: NonNullable<AvatarConfig['pantsStyle']>; en: string; id: string }> = [
  { value: 'none', en: 'None (Bare)', id: 'Polos (Tanpa Celana)' },
  { value: 'trousers', en: 'Field Trousers', id: 'Celana Panjang' },
  { value: 'denim', en: 'Denim Jeans', id: 'Celana Jeans' },
  { value: 'shorts', en: 'Work Shorts', id: 'Celana Pendek' },
  { value: 'skirt', en: 'Flared Skirt', id: 'Rok Lebar' },
  { value: 'cargos', en: 'Cargo Pants', id: 'Celana Kargo' },
  { value: 'capri', en: 'Capri Crops', id: 'Celana 3/4' },
  { value: 'pleated_skirt', en: 'Pleated Skirt', id: 'Rok Lipit' },
  { value: 'leggings', en: 'Fitted Leggings', id: 'Legging' },
  { value: 'boots_pants', en: 'Riding Boots & Breeches', id: 'Celana & Sepatu Bot' },
];

export const HAT_OPTIONS: Array<{ value: AvatarConfig['hatStyle']; en: string; id: string }> = [
  { value: 'none', en: 'None', id: 'Tanpa Topi' },
  { value: 'farmer_cap', en: 'Farmer Cap', id: 'Topi Petani' },
  { value: 'straw_hat', en: 'Straw Sunhat', id: 'Topi Jerami' },
  { value: 'flower_clip', en: 'Flower Clip', id: 'Jepit Bunga' },
  { value: 'wizard_hat', en: 'Wizard Hat', id: 'Topi Penyihir' },
  { value: 'cowboy_hat', en: 'Ranch Cowboy Hat', id: 'Topi Koboi' },
  { value: 'beanie', en: 'Knit Beanie', id: 'Kupluk Rajut' },
  { value: 'beret', en: 'Artist Beret', id: 'Baret Seniman' },
  { value: 'crown', en: 'Royal Crown', id: 'Mahkota Emas' },
  { value: 'chef_hat', en: 'Master Chef Hat', id: 'Topi Koki' },
  { value: 'sun_visor', en: 'Garden Sun Visor', id: 'Topi Visor' },
];

export const ACCESSORY_OPTIONS: Array<{ value: AvatarConfig['accessory']; en: string; id: string }> = [
  { value: 'none', en: 'None', id: 'Polos' },
  { value: 'bandana', en: 'Bandana', id: 'Bandana' },
  { value: 'scarf', en: 'Scarf', id: 'Syal' },
  { value: 'glasses', en: 'Glasses', id: 'Kacamata' },
  { value: 'bowtie', en: 'Bowtie', id: 'Dasi Kupu-kupu' },
  { value: 'sunglasses', en: 'Sunglasses', id: 'Kacamata Hitam' },
];

interface AppearanceStudioModalProps {
  language: Language;
  currentAvatar: AvatarConfig;
  diamonds: number;
  debugMode?: boolean;
  onApplyCustomAppearance: (nextAvatar: AvatarConfig) => void;
  onClose: () => void;
}

export const AppearanceStudioModal: React.FC<AppearanceStudioModalProps> = ({
  language,
  currentAvatar,
  diamonds,
  debugMode = false,
  onApplyCustomAppearance,
  onClose,
}) => {
  const [draft, setDraft] = useState<AvatarConfig>({ ...currentAvatar });
  const [hairFilter, setHairFilter] = useState<'all' | 'male' | 'female'>('all');
  const cost = CUSTOMIZATION_DIAMOND_COST;
  const canAfford = debugMode || diamonds >= cost;

  const update = (patch: Partial<AvatarConfig>) => setDraft((prev) => ({ ...prev, ...patch }));

  const filteredHairs = HAIR_STYLES_CATALOG.filter(
    (h) => hairFilter === 'all' || h.gender === hairFilter || h.gender === 'unisex'
  );
  const selectedHairDef = HAIR_STYLES_CATALOG.find((h) => h.value === draft.hairStyle);
  const selectedHairColorDef = HAIR_COLORS_CATALOG.find((c) => c.hex === draft.hairColor);

  return (
    <DraggableWindow
      windowId="appearance_studio"
      title={t(language, 'style.studioTitle')}
      icon={<Palette className="w-5 h-5 text-[#f5cc74]" />}
      widthClass="w-[min(95vw,620px)]"
      headerAccent="walnut"
      onClose={onClose}
    >
      <div className="p-4 space-y-3.5 text-[#2b1a0e]">
        <div className="rounded-xl border border-[#d3bc92] bg-[#efe2c6] px-3 py-2 text-xs font-bold flex items-center justify-between gap-2">
          <span>
            {language === 'id'
              ? `Ubah rambut (${HAIR_STYLES_CATALOG.length} gaya), baju, celana, topi, aksesoris & warna (${cost} Berlian per perubahan).`
              : `Customize your hair (${HAIR_STYLES_CATALOG.length} styles), shirt, pants, hat, accessory & colors (${cost} Diamonds).`}
          </span>
          <span className="text-[#0369a1] font-black shrink-0 tabular-nums">
            💎 {debugMode ? '∞' : diamonds.toLocaleString()}
          </span>
        </div>

        {/* Gender */}
        <div className="grid grid-cols-2 gap-2">
          {(['male', 'female'] as const).map((g) => (
            <button
              key={g}
              type="button"
              onClick={() => update({ gender: g })}
              className={`py-1.5 px-3 rounded-xl border-2 text-xs font-extrabold cursor-pointer ${
                draft.gender === g
                  ? 'border-[#3a6b2c] bg-[#dcecd1] text-[#1f4416]'
                  : 'border-[#d3bc92] bg-[#fffaf0] text-[#5c3c22]'
              }`}
            >
              {g === 'male' ? t(language, 'create.male') : t(language, 'create.female')}
            </button>
          ))}
        </div>

        {/* Hair Style Selector with Gender Filter & Description */}
        <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-3 space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <label className="text-[11px] font-extrabold">
              {t(language, 'create.hairstyle')} ({filteredHairs.length})
            </label>
            <div className="flex gap-1">
              {(
                [
                  ['all', language === 'id' ? 'Semua' : 'All'],
                  ['male', language === 'id' ? 'Pria' : "Men's"],
                  ['female', language === 'id' ? 'Wanita' : "Women's"],
                ] as const
              ).map(([flt, label]) => (
                <button
                  key={flt}
                  type="button"
                  onClick={() => setHairFilter(flt)}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold border cursor-pointer ${
                    hairFilter === flt
                      ? 'bg-[#3a6b2c] text-white border-[#214417]'
                      : 'bg-[#efe2c6] text-[#5c3c22] border-[#d3bc92]'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
          <select
            value={draft.hairStyle}
            onChange={(e) => update({ hairStyle: e.target.value as AvatarConfig['hairStyle'] })}
            className="w-full rounded-lg border border-[#bfa070] bg-white px-2.5 py-1.5 text-xs font-bold"
          >
            {filteredHairs.map((o) => (
              <option key={o.value} value={o.value}>
                {language === 'id' ? o.id : o.en}
              </option>
            ))}
          </select>
          {selectedHairDef && (
            <p className="text-[10px] text-[#6e4624]">
              {language === 'id' ? selectedHairDef.descId : selectedHairDef.descEn}
            </p>
          )}
        </div>

        {/* Hat, Shirt, Pants Selectors */}
        <div className="grid sm:grid-cols-3 gap-2.5">
          <div>
            <label className="text-[11px] font-extrabold block mb-1">{t(language, 'create.hat')}</label>
            <select
              value={draft.hatStyle}
              onChange={(e) => update({ hatStyle: e.target.value as AvatarConfig['hatStyle'] })}
              className="w-full rounded-lg border border-[#bfa070] bg-[#fffaf0] px-2.5 py-1.5 text-xs font-bold"
            >
              {HAT_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{language === 'id' ? o.id : o.en}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-[11px] font-extrabold block mb-1">{t(language, 'create.shirt')}</label>
            <select
              value={draft.shirtStyle || 'overalls'}
              onChange={(e) => update({ shirtStyle: e.target.value as AvatarConfig['shirtStyle'] })}
              className="w-full rounded-lg border border-[#bfa070] bg-[#fffaf0] px-2.5 py-1.5 text-xs font-bold"
            >
              {SHIRT_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{language === 'id' ? o.id : o.en}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-[11px] font-extrabold block mb-1">{t(language, 'create.pants')}</label>
            <select
              value={draft.pantsStyle || 'trousers'}
              onChange={(e) => update({ pantsStyle: e.target.value as AvatarConfig['pantsStyle'] })}
              className="w-full rounded-lg border border-[#bfa070] bg-[#fffaf0] px-2.5 py-1.5 text-xs font-bold"
            >
              {PANTS_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{language === 'id' ? o.id : o.en}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Accessories */}
        <div>
          <label className="text-[11px] font-extrabold block mb-1">{t(language, 'create.accessory')}</label>
          <div className="flex flex-wrap gap-1.5">
            {ACCESSORY_OPTIONS.map((o) => (
              <button
                key={o.value}
                type="button"
                onClick={() => update({ accessory: o.value })}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border cursor-pointer ${
                  draft.accessory === o.value
                    ? 'bg-[#3a6b2c] text-white border-[#214417]'
                    : 'bg-[#fffaf0] text-[#5c3c22] border-[#d3bc92]'
                }`}
              >
                {language === 'id' ? o.id : o.en}
              </button>
            ))}
          </div>
        </div>

        {/* Color Swatches */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 rounded-xl bg-[#efe2c6] p-3 border border-[#d3bc92]">
          <div className="col-span-full">
            <div className="flex items-center justify-between text-[10px] font-bold mb-1">
              <span>{t(language, 'create.hairColor')} ({HAIR_COLORS_CATALOG.length})</span>
              <span className="text-[#8a4d22]">
                {selectedHairColorDef
                  ? language === 'id'
                    ? selectedHairColorDef.nameId
                    : selectedHairColorDef.nameEn
                  : draft.hairColor}
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {HAIR_COLORS_CATALOG.map((c) => (
                <button
                  key={c.hex}
                  type="button"
                  title={language === 'id' ? c.nameId : c.nameEn}
                  onClick={() => update({ hairColor: c.hex })}
                  style={{ backgroundColor: c.hex }}
                  className={`w-5 h-5 rounded-full border-2 cursor-pointer ${
                    draft.hairColor === c.hex ? 'border-[#2b1a0e] scale-110 ring-1 ring-[#f5cc74]' : 'border-white'
                  }`}
                />
              ))}
            </div>
          </div>
          <div>
            <span className="text-[10px] font-bold block mb-1">{t(language, 'create.skinTone')}</span>
            <div className="flex flex-wrap gap-1">
              {AVATAR_SKIN_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => update({ skinColor: c })}
                  style={{ backgroundColor: c }}
                  className={`w-5 h-5 rounded-full border-2 cursor-pointer ${draft.skinColor === c ? 'border-[#2b1a0e] ring-1 ring-[#f5cc74]' : 'border-white'}`}
                />
              ))}
            </div>
          </div>
          <div>
            <span className="text-[10px] font-bold block mb-1">{t(language, 'create.eyeColor')}</span>
            <div className="flex flex-wrap gap-1">
              {AVATAR_EYE_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => update({ eyeColor: c })}
                  style={{ backgroundColor: c }}
                  className={`w-5 h-5 rounded-full border-2 cursor-pointer ${draft.eyeColor === c ? 'border-[#2b1a0e] ring-1 ring-[#f5cc74]' : 'border-white'}`}
                />
              ))}
            </div>
          </div>
          <div>
            <span className="text-[10px] font-bold block mb-1">{t(language, 'create.shirtColor')}</span>
            <div className="flex flex-wrap gap-1">
              {AVATAR_OUTFIT_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => update({ outfitColor: c })}
                  style={{ backgroundColor: c }}
                  className={`w-5 h-5 rounded-full border-2 cursor-pointer ${draft.outfitColor === c ? 'border-[#2b1a0e] ring-1 ring-[#f5cc74]' : 'border-white'}`}
                />
              ))}
            </div>
          </div>
          <div>
            <span className="text-[10px] font-bold block mb-1">{t(language, 'create.pantsColor')}</span>
            <div className="flex flex-wrap gap-1">
              {AVATAR_PANTS_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => update({ pantsColor: c })}
                  style={{ backgroundColor: c }}
                  className={`w-5 h-5 rounded-full border-2 cursor-pointer ${draft.pantsColor === c ? 'border-[#2b1a0e] ring-1 ring-[#f5cc74]' : 'border-white'}`}
                />
              ))}
            </div>
          </div>
        </div>

        <button
          type="button"
          disabled={!canAfford}
          onClick={() => {
            onApplyCustomAppearance(draft);
            onClose();
          }}
          className="w-full py-2.5 rounded-xl bg-[#0284c7] hover:bg-[#0369a1] disabled:bg-[#cbd5e1] text-white font-extrabold text-sm flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed"
        >
          <Sparkles className="w-4 h-4" />
          <span>{t(language, 'style.applyCost')} ({debugMode ? 'DEV FREE' : `💎 ${cost}`})</span>
        </button>
      </div>
    </DraggableWindow>
  );
};
