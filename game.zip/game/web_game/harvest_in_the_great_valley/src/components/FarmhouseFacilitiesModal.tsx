import React, { useState } from 'react';
import { ArrowLeftRight, CheckCircle2, Heart, Package, Shirt, Snowflake, Sparkles, Tv, Wrench } from 'lucide-react';
import { CROPS, ITEMS, OUTFIT_CATALOG } from '../game/data/itemsAndCrops';
import { FESTIVALS } from '../game/data/worldConfig';
import type { InventorySlot, MarketState, Season, Weather } from '../game/types';
import type { MarriageProposalPayload } from '../services/multiplayerClient';
import { DraggableWindow } from './DraggableWindow';

// === 1. FARMHOUSE TV MODAL ===
interface FarmhouseTVModalProps {
  season: Season;
  day: number;
  weather: Weather;
  marketState: MarketState | null;
  onClose: () => void;
}

export const FarmhouseTVModal: React.FC<FarmhouseTVModalProps> = ({
  season,
  day,
  weather,
  marketState,
  onClose,
}) => {
  const [channel, setChannel] = useState<'weather' | 'tips' | 'market'>('weather');

  const tomorrowWeather: Weather =
    season === 'Winter' && (day * 7) % 10 < 4
      ? 'Snowy'
      : season !== 'Winter' && (day * 7) % 10 < 2
        ? 'Rainy'
        : 'Sunny';

  const upcomingFest = FESTIVALS.find((f) => f.season === season && f.day >= day);
  const seasonalCrops = Object.values(CROPS)
    .filter((c) => c.seasons.includes(season))
    .map((c) => c.name)
    .join(', ');

  const marketList = marketState
    ? Object.values(marketState.prices)
        .filter((p) => ITEMS[p.itemId])
        .sort((a, b) => b.multiplier - a.multiplier)
    : [];

  return (
    <DraggableWindow
      windowId="farmhouse_tv"
      title="Great Valley Family Television"
      icon={<Tv className="w-5 h-5 text-[#f5cc74]" />}
      widthClass="w-[min(94vw,560px)]"
      headerAccent="walnut"
      onClose={onClose}
    >
      <div className="p-4 space-y-3.5 text-[#2b1a0e]">
        <div className="flex flex-wrap gap-1.5">
          <button
            type="button"
            onClick={() => setChannel('weather')}
            className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border cursor-pointer ${
              channel === 'weather' ? 'bg-[#f2cf7e] border-[#b8711e] text-[#3c2310]' : 'bg-[#efe2c6] border-[#d3bc92]'
            }`}
          >
            ☀️ Ch.1 Weather Forecast
          </button>
          <button
            type="button"
            onClick={() => setChannel('tips')}
            className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border cursor-pointer ${
              channel === 'tips' ? 'bg-[#f2cf7e] border-[#b8711e] text-[#3c2310]' : 'bg-[#efe2c6] border-[#d3bc92]'
            }`}
          >
            🌱 Ch.2 Farming Almanac
          </button>
          <button
            type="button"
            onClick={() => setChannel('market')}
            className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border cursor-pointer ${
              channel === 'market' ? 'bg-[#f2cf7e] border-[#b8711e] text-[#3c2310]' : 'bg-[#efe2c6] border-[#d3bc92]'
            }`}
          >
            📈 Ch.3 Market & Tax Pool
          </button>
        </div>

        {channel === 'weather' && (
          <div className="rounded-2xl border-2 border-[#7a4b26] bg-[#fffaf0] p-4 space-y-2.5">
            <div className="text-sm font-extrabold text-[#4b2d16]">
              Great Valley Weather Forecast — {season} Day {day}
            </div>
            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div className="rounded-xl bg-[#efe2c6] p-3 border border-[#d3bc92]">
                <div className="font-bold text-[#6e4624]">Today’s Weather</div>
                <div className="text-base font-black mt-0.5">
                  {weather === 'Rainy' ? '🌧️ Rainy' : weather === 'Snowy' ? '❄️ Snowy' : '☀️ Sunny'}
                </div>
                <div className="text-[11px] text-[#5c3c22] mt-1">
                  {weather === 'Rainy'
                    ? 'Rain automatically waters your planted crops today!'
                    : 'Great weather for tending fields and visiting Village Square.'}
                </div>
              </div>
              <div className="rounded-xl bg-[#e7f1df] p-3 border border-[#96b884]">
                <div className="font-bold text-[#23481a]">Tomorrow’s Outlook</div>
                <div className="text-base font-black mt-0.5">
                  {tomorrowWeather === 'Rainy' ? '🌧️ Likely Rain' : tomorrowWeather === 'Snowy' ? '❄️ Light Snow' : '☀️ Clear & Warm'}
                </div>
                <div className="text-[11px] text-[#274b1e] mt-1">
                  {upcomingFest
                    ? `Upcoming festival: ${upcomingFest.name} (Day ${upcomingFest.day})`
                    : 'No festivals scheduled in the coming days.'}
                </div>
              </div>
            </div>
          </div>
        )}

        {channel === 'tips' && (
          <div className="rounded-2xl border-2 border-[#7a4b26] bg-[#fffaf0] p-4 space-y-2 text-xs leading-relaxed">
            <div className="text-sm font-extrabold text-[#3a6b2c]">
              Show: “Great Valley Homestead Almanac”
            </div>
            <p>
              <strong>{season} Crops:</strong> {seasonalCrops || 'Starfrost Fruit (Nyra)’s all-season arcane seed'}.
            </p>
            <p>
              <strong>🍎 Homestead Apple Tree:</strong> Bears sweet apples during <strong>Summer</strong> &amp;{' '}
              <strong>Autumn</strong>! (Protected homestead event tree — cannot be chopped down.)
            </p>
            <p>
              <strong>🐝 Spring Beehive:</strong> Planting at least 1 Tulip or Sunflower during <strong>Spring</strong>{' '}
              draws wild bees to produce Pure Honey daily!
            </p>
            <p>
              <strong>⛏️ Cave &amp; Lumber:</strong> Chop wild forest trees for Hardwood Timber and mine ore inside
              Whispering Mountain Cave to upgrade your Farmhouse, Barn, and Chicken Coop to Lv.3!
            </p>
          </div>
        )}

        {channel === 'market' && (
          <div className="rounded-2xl border-2 border-[#7a4b26] bg-[#fffaf0] p-4 space-y-2.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-sm">Live Supply &amp; Demand Ticker</span>
              <span className="px-2.5 py-0.5 rounded-lg bg-[#f2cf7e] font-black text-[#4b2d16]">
                Gold Tax Pool: {marketState ? marketState.taxPool.toLocaleString() : 0} G · Diamond Tax Pool: {marketState ? (marketState.taxPoolDiamond || 0).toLocaleString() : 0} 💎
              </span>
            </div>
            <p className="text-[11px] text-[#5c3c22]">
              Supply & Demand shifts global market prices. Selling transactions apply progressive Gold/Diamond tax based on player development.
              Leaderboard Dividend Pool.
            </p>
            <div className="max-h-44 overflow-y-auto space-y-1.5 pr-1">
              {marketList.slice(0, 10).map((entry) => {
                const item = ITEMS[entry.itemId];
                if (!item) return null;
                return (
                  <div key={entry.itemId} className="flex items-center justify-between rounded-xl bg-[#efe2c6] px-3 py-1.5">
                    <span className="font-bold">
                      {item.iconEmoji} {item.name}
                    </span>
                    <span className="font-black tabular-nums">
                      {entry.trend === 'up' ? '📈' : entry.trend === 'down' ? '📉' : '➖'}{' '}
                      {(entry.multiplier * 100).toFixed(0)}% (Sell {entry.sellPrice} G)
                    </span>
                  </div>
                );
              })}
              {marketList.length === 0 && (
                <div className="text-center py-4 text-[#6e4624]">Connecting to market server...</div>
              )}
            </div>
          </div>
        )}
      </div>
    </DraggableWindow>
  );
};

// === 2. FARMHOUSE FRIDGE & TOOLBOX STORAGE MODAL ===
interface FarmhouseStorageModalProps {
  kind: 'fridge' | 'toolbox';
  inventory: InventorySlot[];
  storageItems: InventorySlot[];
  maxBagSlots: number;
  onDeposit: (itemId: string) => void;
  onWithdraw: (itemId: string) => void;
  onClose: () => void;
}

export const FarmhouseStorageModal: React.FC<FarmhouseStorageModalProps> = ({
  kind,
  inventory,
  storageItems,
  maxBagSlots,
  onDeposit,
  onWithdraw,
  onClose,
}) => {
  const isFridge = kind === 'fridge';
  const eligibleBag = inventory.filter((slot) => {
    const def = ITEMS[slot.itemId];
    if (!def) return false;
    return isFridge ? Boolean(def.isFoodStorable) : def.category === 'Tools';
  });

  return (
    <DraggableWindow
      windowId={`storage_${kind}`}
      title={isFridge ? 'Farmhouse Refrigerator' : 'Homestead Toolbox'}
      icon={isFridge ? <Snowflake className="w-5 h-5 text-[#d7f0ff]" /> : <Wrench className="w-5 h-5 text-[#f5cc74]" />}
      widthClass="w-[min(95vw,680px)]"
      headerAccent={isFridge ? 'moss' : 'oak'}
      onClose={onClose}
    >
      <div className="p-4 space-y-3 text-[#2b1a0e]">
        <div className="rounded-xl bg-[#efe2c6] border border-[#d3bc92] px-3 py-2 text-xs font-bold flex items-center justify-between">
          <span>
            {isFridge
              ? '❄️ Store harvested fruits, vegetables, fish, eggs, milk, and meals to keep your bag light.'
              : '🧰 Store spare farm tools inside your Farmhouse Toolbox.'}
          </span>
          <span className="tabular-nums text-[#3a6b2c]">
            Bag: {inventory.length}/{maxBagSlots}
          </span>
        </div>

        <div className="grid md:grid-cols-2 gap-3">
          <div className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-3 space-y-2">
            <div className="text-xs font-extrabold uppercase tracking-wider text-[#6e4624] flex items-center gap-1.5">
              <Package className="w-3.5 h-3.5" /> From Your Bag (Click to Store)
            </div>
            <div className="max-h-60 overflow-y-auto space-y-1.5 pr-1">
              {eligibleBag.map((slot) => {
                const def = ITEMS[slot.itemId];
                return (
                  <button
                    key={slot.itemId}
                    type="button"
                    onClick={() => onDeposit(slot.itemId)}
                    className="w-full flex items-center justify-between rounded-xl border border-[#d3bc92] bg-[#f9f3e4] hover:bg-[#dcecd1] px-2.5 py-2 text-xs font-bold cursor-pointer"
                  >
                    <span className="flex items-center gap-2 truncate">
                      <span className="text-lg">{def.iconEmoji}</span>
                      <span className="truncate">{def.name}</span>
                      {slot.quantity > 1 && <span className="text-[#6e4624]">x{slot.quantity}</span>}
                    </span>
                    <span className="text-[#3a6b2c] font-extrabold shrink-0 flex items-center gap-1">
                      Store <ArrowLeftRight className="w-3 h-3" />
                    </span>
                  </button>
                );
              })}
              {eligibleBag.length === 0 && (
                <div className="py-8 text-center text-xs text-[#6e4624]">
                  {isFridge ? 'No storable food in your bag.' : 'No tools in your bag.'}
                </div>
              )}
            </div>
          </div>

          <div className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-3 space-y-2">
            <div className="text-xs font-extrabold uppercase tracking-wider text-[#6e4624]">
              {isFridge ? '❄️ Fridge Contents' : '🧰 Toolbox Contents'} (Click to Take)
            </div>
            <div className="max-h-60 overflow-y-auto space-y-1.5 pr-1">
              {storageItems.map((slot) => {
                const def = ITEMS[slot.itemId];
                if (!def) return null;
                return (
                  <button
                    key={slot.itemId}
                    type="button"
                    onClick={() => onWithdraw(slot.itemId)}
                    className="w-full flex items-center justify-between rounded-xl border border-[#d3bc92] bg-[#f9f3e4] hover:bg-[#fae8c4] px-2.5 py-2 text-xs font-bold cursor-pointer"
                  >
                    <span className="flex items-center gap-2 truncate">
                      <span className="text-lg">{def.iconEmoji}</span>
                      <span className="truncate">{def.name}</span>
                      {slot.quantity > 1 && <span className="text-[#6e4624]">x{slot.quantity}</span>}
                    </span>
                    <span className="text-[#9e5316] font-extrabold shrink-0">Take to Bag</span>
                  </button>
                );
              })}
              {storageItems.length === 0 && (
                <div className="py-8 text-center text-xs text-[#6e4624]">
                  {isFridge ? 'Your fridge is currently empty.' : 'Your toolbox is currently empty.'}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </DraggableWindow>
  );
};

// === 3. FARMHOUSE WARDROBE MODAL ===
interface FarmhouseWardrobeModalProps {
  unlockedOutfits: string[];
  equippedOutfitId: string;
  diamonds: number;
  onEquipOutfit: (outfitId: string) => void;
  onUnlockOutfit: (outfitId: string) => void;
  onOpenStyleStudio?: () => void;
  onClose: () => void;
}

export const FarmhouseWardrobeModal: React.FC<FarmhouseWardrobeModalProps> = ({
  unlockedOutfits,
  equippedOutfitId,
  diamonds,
  onEquipOutfit,
  onUnlockOutfit,
  onOpenStyleStudio,
  onClose,
}) => {
  return (
    <DraggableWindow
      windowId="farmhouse_wardrobe"
      title="Farmhouse Oak Wardrobe"
      icon={<Shirt className="w-5 h-5 text-[#f5cc74]" />}
      widthClass="w-[min(94vw,540px)]"
      headerAccent="walnut"
      onClose={onClose}
    >
      <div className="p-4 space-y-3 text-[#2b1a0e]">
        <div className="rounded-xl border border-[#d3bc92] bg-[#efe2c6] px-3 py-2 text-xs font-bold flex flex-wrap items-center justify-between gap-2">
          <span>Change your farmer outfit or customize hair, clothes &amp; hats with Diamonds.</span>
          <span className="text-[#0369a1] font-black">💎 {diamonds.toLocaleString()}</span>
        </div>

        {onOpenStyleStudio && (
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenStyleStudio();
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-[#0284c7] hover:bg-[#0369a1] text-white text-xs font-extrabold flex items-center justify-center gap-2 cursor-pointer shadow"
          >
            <Sparkles className="w-4 h-4" />
            <span>Open Full Character Style Studio (Hair, Shirt, Pants, Hat · 💎 10)</span>
          </button>
        )}

        <div className="space-y-2 max-h-[58vh] overflow-y-auto pr-1">
          {OUTFIT_CATALOG.map((outfit) => {
            const unlocked = outfit.diamondPrice === 0 || unlockedOutfits.includes(outfit.id);
            const equipped = equippedOutfitId === outfit.id;
            return (
              <div
                key={outfit.id}
                className={`rounded-2xl border-2 p-3 flex items-center justify-between gap-3 ${
                  equipped
                    ? 'border-[#3a6b2c] bg-[#e9f5df]'
                    : 'border-[#d3bc92] bg-[#fffaf0]'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-11 h-11 rounded-xl border border-[#7a4b26] shrink-0 flex flex-col overflow-hidden">
                    <div className="flex-1" style={{ backgroundColor: outfit.shirtColor }} />
                    <div className="h-2" style={{ backgroundColor: outfit.accentColor }} />
                    <div className="flex-1" style={{ backgroundColor: outfit.pantsColor }} />
                  </div>
                  <div className="min-w-0">
                    <div className="font-extrabold text-sm truncate">{outfit.name}</div>
                    <div className="text-[11px] text-[#5c3c22]">{outfit.description}</div>
                  </div>
                </div>

                {equipped ? (
                  <span className="px-3 py-1.5 rounded-xl bg-[#3a6b2c] text-white text-xs font-extrabold flex items-center gap-1 shrink-0">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Wearing
                  </span>
                ) : unlocked ? (
                  <button
                    type="button"
                    onClick={() => onEquipOutfit(outfit.id)}
                    className="px-3.5 py-2 rounded-xl bg-[#4b2d16] hover:bg-[#341f0f] text-white text-xs font-extrabold cursor-pointer shrink-0"
                  >
                    Wear Outfit
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={diamonds < outfit.diamondPrice}
                    onClick={() => onUnlockOutfit(outfit.id)}
                    className="px-3.5 py-2 rounded-xl bg-[#0284c7] hover:bg-[#0369a1] disabled:bg-[#cbd5e1] text-white text-xs font-extrabold cursor-pointer disabled:cursor-not-allowed shrink-0"
                  >
                    Unlock 💎 {outfit.diamondPrice}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </DraggableWindow>
  );
};

// === 4. PLAYER-TO-PLAYER MARRIAGE PROPOSAL MODAL ===
interface MarriageProposalModalProps {
  proposal: MarriageProposalPayload;
  onRespond: (accepted: boolean) => void;
}

export const MarriageProposalModal: React.FC<MarriageProposalModalProps> = ({
  proposal,
  onRespond,
}) => {
  const itemDef = ITEMS[proposal.itemId];
  return (
    <DraggableWindow
      windowId="marriage_proposal"
      title="Player Marriage Proposal"
      icon={<Heart className="w-5 h-5 text-[#f5cc74] fill-[#f5cc74]" />}
      widthClass="w-[min(92vw,440px)]"
      headerAccent="walnut"
      zIndexClass="z-40"
      onClose={() => onRespond(false)}
    >
      <div className="p-5 space-y-4 text-center text-[#2b1a0e]">
        <div className="text-4xl">{itemDef?.iconEmoji || '💍'}</div>
        <div className="space-y-1.5">
          <h3 className="text-base font-extrabold text-[#4b2d16]">
            {proposal.fromName} is proposing marriage to you!
          </h3>
          <p className="text-xs text-[#5c3c22]">
            Owner of <strong>{proposal.fromFarmName}</strong> offers the{' '}
            <strong>{itemDef?.name || 'Unity Gold Ring'}</strong> and wishes to build a shared life in Great Valley.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <button
            type="button"
            onClick={() => onRespond(false)}
            className="py-2.5 rounded-xl bg-[#e5d3b0] hover:bg-[#d3bc92] text-[#4b2d16] font-extrabold text-xs cursor-pointer"
          >
            Politely Decline
          </button>
          <button
            type="button"
            onClick={() => onRespond(true)}
            className="py-2.5 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] text-white font-extrabold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Sparkles className="w-4 h-4" /> Accept Proposal!
          </button>
        </div>
      </div>
    </DraggableWindow>
  );
};
