import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Clock,
  Cloud,
  Compass,
  Globe,
  LogOut,
  Palette,
  Play,
  RotateCcw,
  RotateCw,
  Settings,
  ShieldAlert,
  Sparkles,
  Trash2,
  UserCheck,
  UserPlus,
  WifiOff,
} from 'lucide-react';
import { HAIR_COLORS_CATALOG } from '../game/data/hairstyles';
import { REGISTRATION_NAME_CONFIG, pickRandomFromPool } from '../game/data/registrationNames';
import { DAYS_PER_SEASON } from '../game/data/worldConfig';
import { t, translateSeason } from '../game/i18n';
import { localizationManager, SUPPORTED_LANGUAGES } from '../game/localizationManager';
import { themeManager } from '../game/themeManager';
import type { AvatarConfig, CharacterRosterEntry, Gender, Language, Season, SocialProviderId, ThemeMode } from '../game/types';
import type { SavedSessionSummary } from '../services/firebaseService';
import {
  fetchNakamaProviders,
  type NakamaSocialAccount,
  type NakamaSocialProviderInfo,
} from '../services/nakamaAuthService';
import {
  ACCESSORY_OPTIONS,
  AVATAR_EYE_COLORS,
  AVATAR_OUTFIT_COLORS,
  AVATAR_PANTS_COLORS,
  AVATAR_SKIN_COLORS,
  HAIR_OPTIONS,
  HAT_OPTIONS,
  PANTS_OPTIONS,
  SHIRT_OPTIONS,
} from './AppearanceStudioModal';

interface TitleScreenProps {
  hasExistingSave: boolean;
  savedSession: SavedSessionSummary;
  firebaseUserEmail: string | null;
  socialAccount: NakamaSocialAccount | null;
  characterRoster: CharacterRosterEntry[];
  guestDurationMinutes: number;
  isOnline: boolean;
  language: Language;
  initialAvatar: AvatarConfig;
  initialProfile: {
    avatarName: string;
    farmName: string;
    birthdaySeason: Season;
    birthdayDay: number;
    dogName?: string;
    horseName?: string;
  };
  onSignInGoogle: () => Promise<void>;
  onSignInSocialProvider: (provider: SocialProviderId) => Promise<void>;
  onGuestQuickPlay: () => void;
  onSelectCharacter: (character: CharacterRosterEntry) => void;
  onScheduleDeleteCharacter: (characterId: string) => Promise<void>;
  onCancelDeleteCharacter: (characterId: string) => Promise<void>;
  onSwitchAccount?: () => Promise<void>;
  onLogout?: () => Promise<void>;
  onDeleteAccount?: (confirmEmail: string) => Promise<void>;
  onOpenSettings: () => void;
  onQuickLanguageToggle: () => void;
  theme?: ThemeMode;
  onChangeTheme?: (next: ThemeMode) => void;
  onChangeLanguage?: (next: Language) => void;
  onAvatarPreviewChange: (avatar: AvatarConfig) => void;
  onCreationPreviewMode: (enabled: boolean) => void;
  onStartGame: (data: {
    isNewGame: boolean;
    avatarName: string;
    farmName: string;
    birthday: string;
    dogName: string;
    horseName: string;
    avatarConfig: AvatarConfig;
  }) => void;
}

const SKIN_COLORS = AVATAR_SKIN_COLORS;
const EYE_COLORS = AVATAR_EYE_COLORS;
const OUTFIT_COLORS = AVATAR_OUTFIT_COLORS;
const PANTS_COLORS = AVATAR_PANTS_COLORS;

const BARE_BASE_AVATAR: AvatarConfig = {
  gender: 'male',
  skinColor: '#fcd5b5',
  eyeColor: '#292524',
  hairStyle: 'none',
  hairColor: '#6b3e1b',
  shirtStyle: 'none',
  pantsStyle: 'none',
  outfitColor: '#3a6b2c',
  pantsColor: '#1e3a8a',
  hatStyle: 'none',
  accessory: 'none',
};

function formatDeletionCountdown(executeAt: number, nowMs: number, language: Language): string {
  const diff = Math.max(0, executeAt - nowMs);
  const days = Math.floor(diff / (24 * 60 * 60 * 1000));
  const hours = Math.floor((diff % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
  const mins = Math.floor((diff % (60 * 60 * 1000)) / (60 * 1000));
  return language === 'id' ? `${days}h ${hours}j ${mins}m` : `${days}d ${hours}h ${mins}m`;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  firebaseUserEmail,
  socialAccount,
  characterRoster,
  guestDurationMinutes,
  isOnline,
  language,
  theme = 'cozy',
  onChangeTheme,
  onChangeLanguage,
  initialProfile,
  onSignInSocialProvider,
  onGuestQuickPlay,
  onSelectCharacter,
  onScheduleDeleteCharacter,
  onCancelDeleteCharacter,
  onLogout,
  onDeleteAccount,
  onOpenSettings,
  onQuickLanguageToggle,
  onAvatarPreviewChange,
  onCreationPreviewMode,
  onStartGame,
}) => {
  const [step, setStep] = useState<'title' | 'create'>('title');
  const [avatarConfig, setAvatarConfig] = useState<AvatarConfig>({ ...BARE_BASE_AVATAR });
  const [avatarName, setAvatarName] = useState(
    () => initialProfile.avatarName || pickRandomFromPool(REGISTRATION_NAME_CONFIG.farmerNames, 'Arka')
  );
  const [farmName, setFarmName] = useState(
    () => initialProfile.farmName || pickRandomFromPool(REGISTRATION_NAME_CONFIG.farmNames, 'Great Valley Farm')
  );
  const [bSeason, setBSeason] = useState<Season>(initialProfile.birthdaySeason);
  const [bDay, setBDay] = useState(Math.max(1, Math.min(DAYS_PER_SEASON, initialProfile.birthdayDay)));
  const [dogName, setDogName] = useState(
    () => initialProfile.dogName || pickRandomFromPool(REGISTRATION_NAME_CONFIG.dogNames, 'Biscuit')
  );
  const [horseName, setHorseName] = useState(
    () => initialProfile.horseName || pickRandomFromPool(REGISTRATION_NAME_CONFIG.horseNames, 'Maple')
  );
  const [hairFilter, setHairFilter] = useState<'all' | 'male' | 'female'>('all');
  const [authLoading, setAuthLoading] = useState<SocialProviderId | 'logout' | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [providers, setProviders] = useState<NakamaSocialProviderInfo[]>([]);
  const [maxSlots, setMaxSlots] = useState(5);
  const [graceDays, setGraceDays] = useState(3);
  const [pendingDeleteChar, setPendingDeleteChar] = useState<CharacterRosterEntry | null>(null);
  const [charActionBusyId, setCharActionBusyId] = useState<string | null>(null);
  const [nowTick, setNowTick] = useState(() => Date.now());
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteEmailInput, setDeleteEmailInput] = useState('');
  const [deletePhraseInput, setDeletePhraseInput] = useState('');
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  useEffect(() => {
    let active = true;
    void fetchNakamaProviders().then((info) => {
      if (!active) return;
      setProviders(info.providers);
      setMaxSlots(info.maxCharactersPerAccount);
      setGraceDays(info.graceDeletionDays);
    });
    const tick = window.setInterval(() => setNowTick(Date.now()), 30_000);
    return () => {
      active = false;
      window.clearInterval(tick);
    };
  }, []);

  useEffect(() => {
    onCreationPreviewMode(step === 'create');
    if (step === 'create') {
      const bare: AvatarConfig = { ...BARE_BASE_AVATAR };
      setAvatarConfig(bare);
      onAvatarPreviewChange(bare);
    }
    return () => onCreationPreviewMode(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  const updateAvatar = (patch: Partial<AvatarConfig>) => {
    setAvatarConfig((prev) => {
      const next = { ...prev, ...patch };
      onAvatarPreviewChange(next);
      return next;
    });
  };

  const handleGenderSwitch = (g: Gender) => {
    updateAvatar({ gender: g });
  };

  const handleSocialProviderClick = async (provider: SocialProviderId) => {
    setAuthError(null);
    setAuthLoading(provider);
    try {
      await onSignInSocialProvider(provider);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : `Failed to sign in with ${provider}`);
    } finally {
      setAuthLoading(null);
    }
  };

  if (step === 'create') {
    return (
      <div className="fixed inset-0 z-20 pointer-events-none flex flex-col md:flex-row items-stretch justify-between p-4 sm:p-6 gap-4 overflow-y-auto">
        {/* Left: Live 3D Chibi Avatar Viewport */}
        <div className="md:flex-1 flex flex-col justify-between pointer-events-none min-h-[210px]">
          <div className="pointer-events-auto self-start flex items-center gap-2">
            <button
              type="button"
              onClick={() => setStep('title')}
              className="gv-pill px-4 py-2 rounded-xl text-xs font-bold cursor-pointer hover:brightness-95"
            >
              ← {t(language, 'create.back')}
            </button>
          </div>

          <div className="gv-pill self-start md:self-center mb-2 rounded-xl px-4 py-2 text-xs font-semibold flex items-center gap-2">
            <RotateCw className="w-3.5 h-3.5" style={{ color: 'var(--hv-pill-accent)' }} />
            <span>{t(language, 'create.dragHint')}</span>
          </div>
        </div>

        {/* Right: Independent Character & Homestead Creation Panel */}
        <div className="gv-window pointer-events-auto w-full md:w-[515px] shrink-0 self-center overflow-hidden">
          <div data-accent="walnut" className="gv-window-header px-5 py-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#f5cc74]" />
              <h2 className="font-display text-lg font-bold tracking-tight">{t(language, 'create.title')}</h2>
            </div>
            <button
              type="button"
              onClick={onQuickLanguageToggle}
              className="px-2.5 py-1 rounded-lg bg-black/25 hover:bg-black/35 text-[11px] font-bold text-white cursor-pointer"
            >
              {language.toUpperCase()}
            </button>
          </div>

          <form
            className="p-5 space-y-3.5 max-h-[82vh] overflow-y-auto"
            onSubmit={(e) => {
              e.preventDefault();
              onStartGame({
                isNewGame: true,
                avatarName: avatarName.trim() || 'Valley Farmer',
                farmName: farmName.trim() || 'Great Valley Farm',
                birthday: `${bSeason} ${bDay}`,
                dogName: dogName.trim() || 'Biscuit',
                horseName: horseName.trim() || 'Maple',
                avatarConfig,
              });
            }}
          >
            {/* Gender (Independent) */}
            <div>
              <label className="block text-[11px] font-extrabold uppercase tracking-wider text-[#6e4624] mb-1.5">
                {t(language, 'create.gender')}
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => handleGenderSwitch('male')}
                  className={`rounded-xl border-2 py-2 px-3 text-left transition-colors cursor-pointer ${
                    avatarConfig.gender === 'male'
                      ? 'border-[#3a6b2c] bg-[#dcecd1] text-[#1f4416]'
                      : 'border-[#d3bc92] bg-[#fffaf0] text-[#5c3c22] hover:bg-[#f2e6cf]'
                  }`}
                >
                  <div className="text-sm font-extrabold">{t(language, 'create.male')}</div>
                </button>
                <button
                  type="button"
                  onClick={() => handleGenderSwitch('female')}
                  className={`rounded-xl border-2 py-2 px-3 text-left transition-colors cursor-pointer ${
                    avatarConfig.gender === 'female'
                      ? 'border-[#9e3b24] bg-[#fae1da] text-[#6d2211]'
                      : 'border-[#d3bc92] bg-[#fffaf0] text-[#5c3c22] hover:bg-[#f2e6cf]'
                  }`}
                >
                  <div className="text-sm font-extrabold">{t(language, 'create.female')}</div>
                </button>
              </div>
            </div>

            {/* Independent Bare-to-Dressed Appearance Controls */}
            <div className="rounded-xl bg-[#efe2c6] p-3.5 space-y-3 border border-[#d3bc92]">
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <span className="text-[11px] font-bold block mb-1">{t(language, 'create.skinTone')}</span>
                  <div className="flex flex-wrap gap-1.5">
                    {SKIN_COLORS.map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => updateAvatar({ skinColor: c })}
                        style={{ backgroundColor: c }}
                        className={`w-5 h-5 rounded-full border-2 cursor-pointer ${
                          avatarConfig.skinColor === c ? 'border-[#2b1a0e] scale-110 ring-2 ring-[#f5cc74]' : 'border-white'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <div>
                  <span className="text-[11px] font-bold block mb-1">{t(language, 'create.eyeColor')}</span>
                  <div className="flex flex-wrap gap-1.5">
                    {EYE_COLORS.map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => updateAvatar({ eyeColor: c })}
                        style={{ backgroundColor: c }}
                        className={`w-5 h-5 rounded-full border-2 cursor-pointer ${
                          avatarConfig.eyeColor === c ? 'border-[#2b1a0e] scale-110 ring-2 ring-[#f5cc74]' : 'border-white'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Hair (with Gender Filter + Description) & Hat */}
              <div className="space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-1.5">
                  <span className="text-[11px] font-bold">
                    {t(language, 'create.hairstyle')} (
                    {
                      HAIR_OPTIONS.filter(
                        (h) => hairFilter === 'all' || h.gender === hairFilter || h.gender === 'unisex'
                      ).length
                    }
                    )
                  </span>
                  <div className="flex gap-1">
                    {(
                      [
                        ['all', language === 'id' ? 'Semua' : 'All'],
                        ['male', language === 'id' ? 'Pria' : "Men's"],
                        ['female', language === 'id' ? 'Wanita' : "Women's"],
                      ] as const
                    ).map(([flt, label]) => (
                      <button
                        key={flt}
                        type="button"
                        onClick={() => setHairFilter(flt)}
                        className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold border cursor-pointer ${
                          hairFilter === flt
                            ? 'bg-[#3a6b2c] text-white border-[#214417]'
                            : 'bg-[#fffaf0] text-[#5c3c22] border-[#d3bc92]'
                        }`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <select
                      value={avatarConfig.hairStyle}
                      onChange={(e) => updateAvatar({ hairStyle: e.target.value as AvatarConfig['hairStyle'] })}
                      className="w-full rounded-lg border border-[#bfa070] bg-[#fffaf0] px-2.5 py-1.5 text-xs font-bold"
                    >
                      {HAIR_OPTIONS.filter(
                        (h) => hairFilter === 'all' || h.gender === hairFilter || h.gender === 'unisex'
                      ).map((opt) => (
                        <option key={opt.value} value={opt.value}>
                          {language === 'id' ? opt.id : opt.en}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <select
                      aria-label={t(language, 'create.hat')}
                      value={avatarConfig.hatStyle}
                      onChange={(e) => updateAvatar({ hatStyle: e.target.value as AvatarConfig['hatStyle'] })}
                      className="w-full rounded-lg border border-[#bfa070] bg-[#fffaf0] px-2.5 py-1.5 text-xs font-bold"
                    >
                      {HAT_OPTIONS.map((opt) => (
                        <option key={opt.value} value={opt.value}>
                          🎩 {language === 'id' ? opt.id : opt.en}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                {(() => {
                  const chosen = HAIR_OPTIONS.find((h) => h.value === avatarConfig.hairStyle);
                  return chosen ? (
                    <div className="text-[10px] font-semibold text-[#6e4624]">
                      {language === 'id' ? chosen.descId : chosen.descEn}
                    </div>
                  ) : null;
                })()}
              </div>

              {/* Independent Shirt & Pants Style */}
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <span className="text-[11px] font-bold block mb-1">{t(language, 'create.shirt')} ({SHIRT_OPTIONS.length})</span>
                  <select
                    value={avatarConfig.shirtStyle || 'none'}
                    onChange={(e) => updateAvatar({ shirtStyle: e.target.value as AvatarConfig['shirtStyle'] })}
                    className="w-full rounded-lg border border-[#bfa070] bg-[#fffaf0] px-2.5 py-1.5 text-xs font-bold"
                  >
                    {SHIRT_OPTIONS.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {language === 'id' ? opt.id : opt.en}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <span className="text-[11px] font-bold block mb-1">{t(language, 'create.pants')} ({PANTS_OPTIONS.length})</span>
                  <select
                    value={avatarConfig.pantsStyle || 'none'}
                    onChange={(e) => updateAvatar({ pantsStyle: e.target.value as AvatarConfig['pantsStyle'] })}
                    className="w-full rounded-lg border border-[#bfa070] bg-[#fffaf0] px-2.5 py-1.5 text-xs font-bold"
                  >
                    {PANTS_OPTIONS.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {language === 'id' ? opt.id : opt.en}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Hair Color (Full 15-color palette with named trend colors) */}
              <div>
                <div className="flex items-center justify-between text-[10px] font-bold mb-1">
                  <span>{t(language, 'create.hairColor')}</span>
                  <span className="text-[#8a4d22]">
                    {(() => {
                      const c = HAIR_COLORS_CATALOG.find((x) => x.hex === avatarConfig.hairColor);
                      return c ? (language === 'id' ? c.nameId : c.nameEn) : avatarConfig.hairColor;
                    })()}
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {HAIR_COLORS_CATALOG.map((c) => (
                    <button
                      key={c.hex}
                      type="button"
                      title={language === 'id' ? c.nameId : c.nameEn}
                      onClick={() => updateAvatar({ hairColor: c.hex })}
                      style={{ backgroundColor: c.hex }}
                      className={`w-5 h-5 rounded-full border cursor-pointer ${
                        avatarConfig.hairColor === c.hex
                          ? 'border-[#2b1a0e] scale-110 ring-1 ring-[#f5cc74]'
                          : 'border-white'
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Shirt & Pants Colors */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-[10px] font-bold block mb-1">{t(language, 'create.shirtColor')}</span>
                  <div className="flex flex-wrap gap-1">
                    {OUTFIT_COLORS.map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => updateAvatar({ outfitColor: c })}
                        style={{ backgroundColor: c }}
                        className={`w-4 h-4 rounded-full border cursor-pointer ${
                          avatarConfig.outfitColor === c ? 'border-[#2b1a0e] scale-110 ring-1 ring-[#f5cc74]' : 'border-white'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <div>
                  <span className="text-[10px] font-bold block mb-1">{t(language, 'create.pantsColor')}</span>
                  <div className="flex flex-wrap gap-1">
                    {PANTS_COLORS.map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => updateAvatar({ pantsColor: c })}
                        style={{ backgroundColor: c }}
                        className={`w-4 h-4 rounded-full border cursor-pointer ${
                          avatarConfig.pantsColor === c ? 'border-[#2b1a0e] scale-110 ring-1 ring-[#f5cc74]' : 'border-white'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Accessory */}
              <div>
                <span className="text-[11px] font-bold block mb-1">{t(language, 'create.accessory')}</span>
                <div className="flex flex-wrap gap-1.5">
                  {ACCESSORY_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => updateAvatar({ accessory: opt.value })}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border cursor-pointer ${
                        avatarConfig.accessory === opt.value
                          ? 'bg-[#3a6b2c] text-white border-[#214417]'
                          : 'bg-[#fffaf0] text-[#5c3c22] border-[#d3bc92]'
                      }`}
                    >
                      {language === 'id' ? opt.id : opt.en}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Farmer Name & Farm Name (with Editable Registration Name Pool Randomizer) */}
            <div className="grid sm:grid-cols-2 gap-2.5">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-extrabold">{t(language, 'create.farmerName')}</label>
                  <button
                    type="button"
                    onClick={() => setAvatarName(pickRandomFromPool(REGISTRATION_NAME_CONFIG.farmerNames, 'Arka'))}
                    className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-[#e8d5b2] hover:bg-[#dfc392] text-[#4b2d16] cursor-pointer"
                    title={language === 'id' ? 'Acak nama petani' : 'Random farmer name'}
                  >
                    🎲
                  </button>
                </div>
                <input
                  required
                  maxLength={32}
                  value={avatarName}
                  onChange={(e) => setAvatarName(e.target.value)}
                  className="w-full rounded-xl border border-[#cfa976] bg-[#fffaf0] px-3 py-1.5 text-sm font-semibold focus:outline-none focus:border-[#3a6b2c]"
                  placeholder="Arka"
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-extrabold">{t(language, 'create.farmName')}</label>
                  <button
                    type="button"
                    onClick={() => setFarmName(pickRandomFromPool(REGISTRATION_NAME_CONFIG.farmNames, 'Great Valley Farm'))}
                    className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-[#e8d5b2] hover:bg-[#dfc392] text-[#4b2d16] cursor-pointer"
                    title={language === 'id' ? 'Acak nama peternakan' : 'Random farm name'}
                  >
                    🎲
                  </button>
                </div>
                <input
                  required
                  maxLength={32}
                  value={farmName}
                  onChange={(e) => setFarmName(e.target.value)}
                  className="w-full rounded-xl border border-[#cfa976] bg-[#fffaf0] px-3 py-1.5 text-sm font-semibold focus:outline-none focus:border-[#3a6b2c]"
                  placeholder="Great Valley Farm"
                />
              </div>
            </div>

            {/* Birthday Season & Date */}
            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="text-[11px] font-extrabold block mb-1">{t(language, 'create.birthdaySeason')}</label>
                <select
                  value={bSeason}
                  onChange={(e) => setBSeason(e.target.value as Season)}
                  className="w-full rounded-xl border border-[#cfa976] bg-[#fffaf0] px-3 py-1.5 text-xs font-bold"
                >
                  {(['Spring', 'Summer', 'Autumn', 'Winter'] as Season[]).map((s) => (
                    <option key={s} value={s}>
                      {translateSeason(language, s)}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[11px] font-extrabold block mb-1">
                  {t(language, 'create.birthdayDay')} (1–{DAYS_PER_SEASON})
                </label>
                <input
                  type="number"
                  min={1}
                  max={DAYS_PER_SEASON}
                  value={bDay}
                  onChange={(e) => setBDay(Math.max(1, Math.min(DAYS_PER_SEASON, Number(e.target.value) || 1)))}
                  className="w-full rounded-xl border border-[#cfa976] bg-[#fffaf0] px-3 py-1.5 text-xs font-bold"
                />
              </div>
            </div>

            {/* Future Dog Name & Horse Name */}
            <div className="grid sm:grid-cols-2 gap-2.5">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-extrabold">🐕 {t(language, 'create.dogName')}</label>
                  <button
                    type="button"
                    onClick={() => setDogName(pickRandomFromPool(REGISTRATION_NAME_CONFIG.dogNames, 'Biscuit'))}
                    className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-[#e8d5b2] hover:bg-[#dfc392] text-[#4b2d16] cursor-pointer"
                    title={language === 'id' ? 'Acak nama anjing' : 'Random dog name'}
                  >
                    🎲
                  </button>
                </div>
                <input
                  required
                  maxLength={20}
                  value={dogName}
                  onChange={(e) => setDogName(e.target.value)}
                  className="w-full rounded-xl border border-[#cfa976] bg-[#fffaf0] px-3 py-1.5 text-sm font-semibold focus:outline-none focus:border-[#3a6b2c]"
                  placeholder="Biscuit"
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-extrabold">🐎 {t(language, 'create.horseName')}</label>
                  <button
                    type="button"
                    onClick={() => setHorseName(pickRandomFromPool(REGISTRATION_NAME_CONFIG.horseNames, 'Maple'))}
                    className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-[#e8d5b2] hover:bg-[#dfc392] text-[#4b2d16] cursor-pointer"
                    title={language === 'id' ? 'Acak nama kuda' : 'Random horse name'}
                  >
                    🎲
                  </button>
                </div>
                <input
                  required
                  maxLength={20}
                  value={horseName}
                  onChange={(e) => setHorseName(e.target.value)}
                  className="w-full rounded-xl border border-[#cfa976] bg-[#fffaf0] px-3 py-1.5 text-sm font-semibold focus:outline-none focus:border-[#3a6b2c]"
                  placeholder="Maple"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] text-[#fef9ed] font-extrabold text-sm sm:text-base shadow-lg border-b-4 border-[#1f3b16] flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <Play className="w-5 h-5 fill-current" />
              {t(language, 'create.begin')}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-20 flex flex-col justify-between pointer-events-none">
      {/* Theme-aware atmospheric vignette for crisp readability over the live 3D valley */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: 'var(--hv-title-scrim)' }}
      />

      {/* Top Navigation Utility Bar (Strictly Unified Global Theme, Zero Dev Panel Links) */}
      <header className="relative z-10 flex flex-wrap items-center justify-between gap-2 px-5 py-4 sm:px-8 sm:py-5 pointer-events-auto">
        <div className="gv-pill px-3 py-1.5 rounded-xl flex items-center gap-2 text-xs font-bold">
          {isOnline ? <Cloud className="w-4 h-4 text-emerald-500" /> : <WifiOff className="w-4 h-4 text-amber-500" />}
          <span>{isOnline ? t(language, 'title.cloudReady') : t(language, 'title.offlineMode')}</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Global Theme Switcher (Follow System + Cozy + Light + Dark + Seasonal) */}
          <label className="gv-pill px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer">
            <Palette className="w-3.5 h-3.5 shrink-0" style={{ color: 'var(--hv-pill-accent)' }} />
            <select
              aria-label="Global Theme"
              value={theme === 'farmhouse' ? 'cozy' : theme}
              onChange={(e) => {
                const next = e.target.value as ThemeMode;
                themeManager.setTheme(next);
                onChangeTheme?.(next);
              }}
              className="bg-transparent text-xs font-bold focus:outline-none cursor-pointer"
              style={{ color: 'var(--hv-pill-text)' }}
            >
              <option value="system" style={{ backgroundColor: 'var(--hv-surface)', color: 'var(--hv-text)' }}>
                {language === 'id' ? 'Sistem' : 'System'}
              </option>
              <option value="cozy" style={{ backgroundColor: 'var(--hv-surface)', color: 'var(--hv-text)' }}>
                Cozy
              </option>
              <option value="light" style={{ backgroundColor: 'var(--hv-surface)', color: 'var(--hv-text)' }}>
                {language === 'id' ? 'Terang' : 'Light'}
              </option>
              <option value="dark" style={{ backgroundColor: 'var(--hv-surface)', color: 'var(--hv-text)' }}>
                {language === 'id' ? 'Gelap' : 'Dark'}
              </option>
              <option value="seasonal" style={{ backgroundColor: 'var(--hv-surface)', color: 'var(--hv-text)' }}>
                {language === 'id' ? 'Musiman' : 'Seasonal'}
              </option>
            </select>
          </label>

          {/* Bilingual Language Switcher (English & Bahasa Indonesia Only) */}
          <label className="gv-pill px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer">
            <Globe className="w-3.5 h-3.5 shrink-0" style={{ color: 'var(--hv-pill-accent)' }} />
            <select
              aria-label="Global Language"
              value={language}
              onChange={(e) => {
                const next = e.target.value as Language;
                localizationManager.setLanguage(next);
                if (onChangeLanguage) {
                  onChangeLanguage(next);
                } else {
                  onQuickLanguageToggle();
                }
              }}
              className="bg-transparent text-xs font-bold focus:outline-none cursor-pointer"
              style={{ color: 'var(--hv-pill-text)' }}
            >
              {SUPPORTED_LANGUAGES.map((l) => (
                <option
                  key={l.code}
                  value={l.code}
                  style={{ backgroundColor: 'var(--hv-surface)', color: 'var(--hv-text)' }}
                >
                  {l.flag} {l.nativeName}
                </option>
              ))}
            </select>
          </label>

          {socialAccount && (
            <div className="gv-pill px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span className="max-w-[160px] truncate">{socialAccount.displayName}</span>
              <span
                className="text-[9px] uppercase px-1.5 py-0.5 rounded font-black"
                style={{ backgroundColor: 'var(--hv-surface-alt)', color: 'var(--hv-text)' }}
              >
                {socialAccount.provider}
              </span>
            </div>
          )}
        </div>
      </header>

      {/* Center Hero + Guest / Nakama Social Login / Character Roster */}
      <main className="relative z-10 flex flex-col items-center text-center px-4 sm:px-6 my-auto pointer-events-auto overflow-y-auto max-h-[82vh] py-2">
        <div className="flex items-center gap-2 text-[#f5cc74] text-xs font-bold uppercase tracking-[0.28em] mb-2">
          <Compass className="w-4 h-4" />
          <span>{language === 'id' ? 'Simulasi Pertanian 3D Multiplayer' : '3D Multiplayer Farming Simulation'}</span>
        </div>

        <h1 className="font-display text-3xl sm:text-5xl md:text-6xl font-black tracking-tight text-[#fef9ed] drop-shadow-[0_6px_28px_rgba(15,10,5,0.75)] leading-[1.04]">
          Harvest in the
          <span className="block text-[#f5cc74] mt-0.5">Great Valley</span>
        </h1>

        <p className="mt-2.5 max-w-xl text-xs sm:text-sm text-[#f7eedc]/90 font-medium leading-relaxed drop-shadow">
          {t(language, 'title.subtitle')}
        </p>

        {authError && (
          <div className="mt-3 w-full max-w-[440px] rounded-xl bg-red-950/90 border border-red-400/60 px-3.5 py-2 text-xs font-bold text-red-100 flex items-center gap-2 text-left">
            <AlertTriangle className="w-4 h-4 shrink-0 text-red-300" />
            <span>{authError}</span>
          </div>
        )}

        {/* STATE B: Signed in via Nakama Social -> Character Roster List (Strictly Unified Global Theme) */}
        {socialAccount ? (
          <div className="gv-title-card mt-5 w-full max-w-[470px] p-4 text-left space-y-3">
            <div
              className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b"
              style={{ borderColor: 'var(--hv-border-soft)' }}
            >
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-black truncate">{socialAccount.displayName}</span>
                  <span className="gv-btn-primary px-1.5 py-0.5 rounded text-[9px] font-black uppercase">
                    {socialAccount.provider}
                  </span>
                </div>
                <div className="text-[11px] truncate" style={{ color: 'var(--hv-title-card-muted)' }}>
                  {language === 'id'
                    ? `Daftar Karakter (${characterRoster.length}/${maxSlots}) · Nakama Social`
                    : `Registered Characters (${characterRoster.length}/${maxSlots}) · Nakama Social`}
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                {onLogout && (
                  <button
                    type="button"
                    disabled={authLoading !== null}
                    onClick={async () => {
                      setAuthLoading('logout');
                      try {
                        await onLogout();
                      } finally {
                        setAuthLoading(null);
                      }
                    }}
                    className="px-2.5 py-1.5 rounded-lg text-[11px] font-bold border flex items-center gap-1 cursor-pointer hover:brightness-95"
                    style={{
                      backgroundColor: 'var(--hv-surface-alt)',
                      borderColor: 'var(--hv-border-soft)',
                      color: 'var(--hv-text)',
                    }}
                  >
                    <LogOut className="w-3 h-3" style={{ color: 'var(--hv-pill-accent)' }} />
                    <span>{t(language, 'auth.logout')}</span>
                  </button>
                )}
              </div>
            </div>

            {characterRoster.length === 0 ? (
              <div
                className="rounded-xl border p-4 text-center space-y-2.5"
                style={{ backgroundColor: 'var(--hv-surface-card)', borderColor: 'var(--hv-border-soft)' }}
              >
                <div className="text-sm font-black">
                  {language === 'id'
                    ? 'Belum ada karakter terdaftar di akun sosial ini'
                    : 'No characters registered on this social account yet'}
                </div>
                <p className="text-[11px]" style={{ color: 'var(--hv-title-card-muted)' }}>
                  {language === 'id'
                    ? 'Buat karakter petani pertamamu sekarang untuk menyimpan progres permanen di cloud.'
                    : 'Create your first farmer character to store permanent progress on this social account.'}
                </p>
                <button
                  type="button"
                  onClick={() => setStep('create')}
                  className="gv-btn-primary w-full py-2.5 px-4 rounded-xl font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{language === 'id' ? 'Buat Karakter Baru' : 'Create New Character'}</span>
                </button>
              </div>
            ) : (
              <div className="space-y-2 max-h-[240px] overflow-y-auto pr-0.5">
                {characterRoster.map((char) => {
                  const isDeleting = Boolean(char.deletionExecuteAt && char.deletionExecuteAt > nowTick);
                  const busy = charActionBusyId === char.characterId;
                  return (
                    <div
                      key={char.characterId}
                      className="rounded-xl border p-3 flex flex-col gap-2"
                      style={
                        isDeleting
                          ? { backgroundColor: 'rgba(127, 29, 29, 0.16)', borderColor: '#ef4444' }
                          : { backgroundColor: 'var(--hv-surface-card)', borderColor: 'var(--hv-border-soft)' }
                      }
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-xl border-2 flex items-center justify-center text-base font-black text-white shadow shrink-0"
                          style={{
                            backgroundColor: char.avatarConfig?.outfitColor || '#3a6b2c',
                            borderColor: 'var(--hv-accent)',
                          }}
                        >
                          {(char.avatarName || 'F')[0].toUpperCase()}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span className="text-sm font-black truncate">{char.avatarName}</span>
                            <span className="text-[10px] font-bold" style={{ color: 'var(--hv-accent)' }}>
                              Lv.{char.level}
                            </span>
                          </div>
                          <div className="text-[11px] font-semibold truncate" style={{ color: 'var(--hv-title-card-muted)' }}>
                            🏡 {char.farmName} · {translateSeason(language, char.season)} {char.day}, {language === 'id' ? 'Thn' : 'Yr'} {char.year}
                          </div>
                          <div className="text-[10px] font-bold" style={{ color: 'var(--hv-accent)' }}>
                            💰 {char.gold.toLocaleString()} G · 💎 {char.diamond.toLocaleString()}
                          </div>
                        </div>

                        {!isDeleting && (
                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => onSelectCharacter(char)}
                              className="gv-btn-primary px-3 py-2 rounded-lg text-xs font-black flex items-center gap-1 cursor-pointer"
                            >
                              <Play className="w-3.5 h-3.5 fill-current" />
                              <span>{language === 'id' ? 'Main' : 'Play'}</span>
                            </button>
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => setPendingDeleteChar(char)}
                              title={language === 'id' ? 'Jadwalkan hapus karakter (3 hari)' : 'Schedule character deletion (3 days)'}
                              className="p-2 rounded-lg bg-[#b91c1c] hover:bg-[#991b1b] text-white cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>

                      {isDeleting && char.deletionExecuteAt && (
                        <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-red-950/85 border border-red-400/60 px-2.5 py-1.5">
                          <div className="text-[11px] font-bold text-red-100 flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                            <span>
                              {language === 'id'
                                ? `Terhapus permanen dalam ${formatDeletionCountdown(char.deletionExecuteAt, nowTick, language)}`
                                : `Permanent deletion in ${formatDeletionCountdown(char.deletionExecuteAt, nowTick, language)}`}
                            </span>
                          </div>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={async () => {
                              setCharActionBusyId(char.characterId);
                              try {
                                await onCancelDeleteCharacter(char.characterId);
                              } finally {
                                setCharActionBusyId(null);
                              }
                            }}
                            className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-[#1c1108] text-[11px] font-black flex items-center gap-1 cursor-pointer"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>{language === 'id' ? 'Batalkan Hapus' : 'Cancel Delete'}</span>
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                disabled={characterRoster.length >= maxSlots}
                onClick={() => setStep('create')}
                className="py-2.5 px-3 rounded-xl disabled:opacity-50 font-extrabold text-xs border flex items-center justify-center gap-1.5 cursor-pointer disabled:cursor-not-allowed hover:brightness-95"
                style={{
                  backgroundColor: 'var(--hv-surface-alt)',
                  borderColor: 'var(--hv-border-soft)',
                  color: 'var(--hv-text)',
                }}
              >
                <UserPlus className="w-3.5 h-3.5" style={{ color: 'var(--hv-pill-accent)' }} />
                <span>{language === 'id' ? 'Buat Karakter Baru' : 'New Character'}</span>
              </button>
              <button
                type="button"
                onClick={onOpenSettings}
                className="py-2.5 px-3 rounded-xl font-bold text-xs border flex items-center justify-center gap-1.5 cursor-pointer hover:brightness-95"
                style={{
                  backgroundColor: 'var(--hv-surface-card)',
                  borderColor: 'var(--hv-border-soft)',
                  color: 'var(--hv-text)',
                }}
              >
                <Settings className="w-3.5 h-3.5" style={{ color: 'var(--hv-pill-accent)' }} />
                <span>{t(language, 'title.settings')}</span>
              </button>
            </div>

            {firebaseUserEmail && onDeleteAccount && (
              <div className="pt-1 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    setDeleteEmailInput('');
                    setDeletePhraseInput('');
                    setDeleteError(null);
                    setDeleteModalOpen(true);
                  }}
                  className="text-[10px] font-bold text-rose-500 hover:text-rose-400 underline cursor-pointer"
                >
                  {t(language, 'auth.deleteAccount')}
                </button>
              </div>
            )}
          </div>
        ) : (
          /* STATE A: Guest Instant Entry + Nakama Social Login (Strictly Unified Global Theme) */
          <div className="mt-5 w-full max-w-[420px] flex flex-col gap-3">
            {/* Instant Guest Play (Follows global theme primary button & badge rules) */}
            <button
              type="button"
              onClick={onGuestQuickPlay}
              className="gv-btn-primary w-full py-3.5 px-5 rounded-2xl shadow-xl flex flex-col items-center justify-center gap-0.5 cursor-pointer hover:scale-[1.01]"
            >
              <div className="flex items-center gap-2 font-extrabold text-base">
                <Sparkles className="w-5 h-5 text-[#f5cc74]" />
                <span>{language === 'id' ? 'Masuk sebagai Guest (Langsung Main)' : 'Play as Guest (Instant Entry)'}</span>
              </div>
              <span className="text-[10px] font-semibold opacity-90">
                {language === 'id'
                  ? `Identitas acak · Batas ${guestDurationMinutes} menit · Data sementara (terhapus saat reload)`
                  : `Random identity · ${guestDurationMinutes}-min auto-logout · Temporary (clears on reload)`}
              </span>
            </button>

            {/* Nakama Social Login Gateway (Google, Steam, Apple) */}
            <div className="gv-title-card p-3.5 space-y-2 text-left">
              <div className="flex items-center justify-between px-0.5">
                <span className="text-[11px] font-black uppercase tracking-wider" style={{ color: 'var(--hv-pill-accent)' }}>
                  {language === 'id' ? 'Masuk dengan Sosial Media (Nakama)' : 'Social Sign-In (Nakama Interface)'}
                </span>
                <span className="text-[10px] font-bold" style={{ color: 'var(--hv-title-card-muted)' }}>
                  {language === 'id' ? 'Multi-Karakter' : 'Multi-Character'}
                </span>
              </div>

              <div className="grid grid-cols-1 gap-2">
                {(providers.length > 0
                  ? providers
                  : [
                      { id: 'google' as const, name: 'Google', configured: true, available: true, detectedOnDevice: true, protocol: 'Nakama Google', hint: 'Google OAuth' },
                      { id: 'steam' as const, name: 'Steam', configured: true, available: true, detectedOnDevice: true, protocol: 'Nakama Steam', hint: 'Steam OpenID 2.0' },
                      { id: 'apple' as const, name: 'Apple', configured: true, available: true, detectedOnDevice: true, protocol: 'Nakama Apple', hint: 'Apple Sign-In' },
                    ]
                ).map((p) =>
                  p.id === 'steam' ? (
                    <a
                      key={p.id}
                      href="/api/nakama/auth/steam/start"
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => void handleSocialProviderClick('steam')}
                      className="w-full py-2.5 px-4 rounded-xl font-extrabold text-xs border flex items-center justify-between transition-colors hover:brightness-95"
                      style={{
                        backgroundColor: 'var(--hv-surface-card)',
                        borderColor: 'var(--hv-border-soft)',
                        color: 'var(--hv-text)',
                      }}
                    >
                      <span className="flex items-center gap-2">
                        <span className="text-sm">🎮</span>
                        <span>{language === 'id' ? 'Masuk dengan Steam' : 'Sign in with Steam'}</span>
                      </span>
                      <span className="text-[10px] font-bold" style={{ color: 'var(--hv-pill-accent)' }}>
                        {p.hint}
                      </span>
                    </a>
                  ) : (
                    <button
                      key={p.id}
                      type="button"
                      disabled={authLoading !== null}
                      onClick={() => void handleSocialProviderClick(p.id)}
                      className="w-full py-2.5 px-4 rounded-xl font-extrabold text-xs border flex items-center justify-between cursor-pointer transition-colors disabled:opacity-60 hover:brightness-95"
                      style={{
                        backgroundColor: 'var(--hv-surface-card)',
                        borderColor: 'var(--hv-border-soft)',
                        color: 'var(--hv-text)',
                      }}
                    >
                      <span className="flex items-center gap-2">
                        <span className="text-sm">{p.id === 'google' ? '🔵' : ''}</span>
                        <span>
                          {authLoading === p.id
                            ? '...'
                            : language === 'id'
                              ? `Masuk dengan ${p.name}`
                              : `Sign in with ${p.name}`}
                        </span>
                      </span>
                      <span className="text-[10px] font-bold opacity-75">{p.hint}</span>
                    </button>
                  )
                )}
              </div>
            </div>

            <button
              type="button"
              onClick={onOpenSettings}
              className="gv-pill w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer hover:brightness-95"
            >
              <Settings className="w-3.5 h-3.5" style={{ color: 'var(--hv-pill-accent)' }} />
              <span>{t(language, 'title.settings')}</span>
            </button>
          </div>
        )}
      </main>

      {/* 3-Day Scheduled Character Deletion Confirmation Modal */}
      {pendingDeleteChar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 pointer-events-auto">
          <div className="w-full max-w-[430px] rounded-2xl border-2 border-[#b91c1c] bg-[#f7eedc] text-[#2b1a0e] shadow-2xl overflow-hidden">
            <div className="bg-[#7f1d1d] text-[#fef2f2] px-5 py-3.5 flex items-center gap-2 border-b-2 border-[#fca5a5]/40">
              <Trash2 className="w-5 h-5 text-[#fca5a5]" />
              <h3 className="font-display text-base font-black">
                {language === 'id' ? 'Konfirmasi Hapus Karakter' : 'Confirm Character Deletion'}
              </h3>
            </div>
            <div className="p-5 space-y-3.5">
              <div className="rounded-xl bg-[#fef2f2] border border-[#fca5a5] p-3 text-xs font-semibold text-[#7f1d1d] leading-relaxed">
                {language === 'id'
                  ? `Karakter "${pendingDeleteChar.avatarName}" (${pendingDeleteChar.farmName}) akan dijadwalkan untuk dihapus permanen. Proses penghapusan resmi memakan waktu ${graceDays} hari (72 jam). Selama masa tunggu ${graceDays} hari, Anda dapat membatalkan penghapusan kapan saja.`
                  : `Character "${pendingDeleteChar.avatarName}" (${pendingDeleteChar.farmName}) will be scheduled for permanent deletion. Official deletion takes ${graceDays} days (72 hours), during which you can cancel deletion at any time.`}
              </div>
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPendingDeleteChar(null)}
                  className="px-4 py-2 rounded-xl bg-[#efe2c6] hover:bg-[#e5d3b0] border border-[#bfa070] text-xs font-extrabold text-[#4b2d16] cursor-pointer"
                >
                  {t(language, 'auth.cancel')}
                </button>
                <button
                  type="button"
                  disabled={charActionBusyId === pendingDeleteChar.characterId}
                  onClick={async () => {
                    const targetId = pendingDeleteChar.characterId;
                    setCharActionBusyId(targetId);
                    try {
                      await onScheduleDeleteCharacter(targetId);
                      setPendingDeleteChar(null);
                    } finally {
                      setCharActionBusyId(null);
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-[#b91c1c] hover:bg-[#991b1b] text-white text-xs font-extrabold cursor-pointer"
                >
                  {language === 'id' ? `Jadwalkan Hapus (${graceDays} Hari)` : `Schedule Delete (${graceDays} Days)`}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Hardened Permanent Account Deletion Modal */}
      {deleteModalOpen && firebaseUserEmail && onDeleteAccount && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 pointer-events-auto">
          <div className="w-full max-w-[440px] rounded-2xl border-2 border-[#b91c1c] bg-[#f7eedc] text-[#2b1a0e] shadow-2xl overflow-hidden">
            <div className="bg-[#7f1d1d] text-[#fef2f2] px-5 py-3.5 flex items-center gap-2 border-b-2 border-[#fca5a5]/40">
              <ShieldAlert className="w-5 h-5 text-[#fca5a5]" />
              <h3 className="font-display text-base font-black">{t(language, 'auth.deleteTitle')}</h3>
            </div>
            <div className="p-5 space-y-3.5">
              <div className="rounded-xl bg-[#fef2f2] border border-[#fca5a5] p-3 text-xs font-semibold text-[#7f1d1d] leading-relaxed">
                {t(language, 'auth.deleteWarning')}
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-extrabold text-[#4b2d16]">
                  {t(language, 'auth.enterEmailLabel')}
                </label>
                <div className="text-[11px] font-bold text-[#6e4624] mb-1">{firebaseUserEmail}</div>
                <input
                  type="email"
                  value={deleteEmailInput}
                  onChange={(e) => setDeleteEmailInput(e.target.value)}
                  placeholder={firebaseUserEmail}
                  className="w-full rounded-xl border border-[#cfa976] bg-[#fffaf0] px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#b91c1c]"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-extrabold text-[#4b2d16]">
                  {t(language, 'auth.enterPhraseLabel')}
                </label>
                <input
                  type="text"
                  value={deletePhraseInput}
                  onChange={(e) => setDeletePhraseInput(e.target.value)}
                  placeholder={t(language, 'auth.confirmPhrase')}
                  className="w-full rounded-xl border border-[#cfa976] bg-[#fffaf0] px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#b91c1c]"
                />
              </div>

              {deleteError && (
                <div className="rounded-lg bg-[#fee2e2] border border-[#f87171] px-3 py-2 text-xs font-bold text-[#991b1b] flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{deleteError}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDeleteModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-[#efe2c6] hover:bg-[#e5d3b0] border border-[#bfa070] text-xs font-extrabold text-[#4b2d16] cursor-pointer"
                >
                  {t(language, 'auth.cancel')}
                </button>
                <button
                  type="button"
                  disabled={
                    deleteBusy ||
                    deleteEmailInput.trim().toLowerCase() !== firebaseUserEmail.trim().toLowerCase() ||
                    deletePhraseInput.trim().toUpperCase() !== t(language, 'auth.confirmPhrase').toUpperCase()
                  }
                  onClick={async () => {
                    setDeleteError(null);
                    setDeleteBusy(true);
                    try {
                      await onDeleteAccount(deleteEmailInput.trim());
                      setDeleteModalOpen(false);
                    } catch (err) {
                      setDeleteError(err instanceof Error ? err.message : 'Failed to verify and delete account.');
                    } finally {
                      setDeleteBusy(false);
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-[#b91c1c] hover:bg-[#991b1b] disabled:bg-[#d6b7b2] text-white text-xs font-extrabold cursor-pointer disabled:cursor-not-allowed"
                >
                  {deleteBusy ? '...' : t(language, 'auth.reauthButton')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Subtle Control Legend */}
      <footer className="relative z-10 px-6 py-4 text-center pointer-events-none">
        <p className="text-xs font-semibold text-[#f7eedc]/85 tracking-wide drop-shadow">
          {t(language, 'title.controlsHint')}
        </p>
      </footer>
    </div>
  );
};
