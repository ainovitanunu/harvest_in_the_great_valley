import React from 'react';
import { DoorOpen, Lock, ShieldAlert, Unlock } from 'lucide-react';
import { DraggableWindow } from './DraggableWindow';

interface DoorAccessModalProps {
  buildingKind: 'farmhouse' | 'barn' | 'coop' | 'stable';
  isInside: boolean;
  isOwner: boolean;
  isHiredWorker?: boolean;
  isLocked: boolean;
  animalsCount: number;
  pastureAnimalsCount: number;
  onEnterOrExit: () => void;
  onToggleLock: (nextLocked: boolean) => void;
  onMoveAnimalsLocation?: (location: 'barn' | 'coop' | 'stable' | 'pasture') => void;
  onClose: () => void;
}

export const DoorAccessModal: React.FC<DoorAccessModalProps> = ({
  buildingKind,
  isInside,
  isOwner,
  isHiredWorker = false,
  isLocked,
  animalsCount,
  pastureAnimalsCount,
  onEnterOrExit,
  onToggleLock,
  onMoveAnimalsLocation,
  onClose,
}) => {
  const title =
    buildingKind === 'farmhouse'
      ? 'Private Farmhouse Door'
      : buildingKind === 'coop'
        ? 'Chicken Coop Door'
        : buildingKind === 'stable'
          ? 'Horse Stable Door'
          : 'Cattle & Sheep Barn Door';

  const shortName =
    buildingKind === 'farmhouse'
      ? 'Farmhouse'
      : buildingKind === 'coop'
        ? 'Chicken Coop'
        : buildingKind === 'stable'
          ? 'Horse Stable'
          : 'Livestock Barn';

  const canEnter = isOwner || !isLocked || (isHiredWorker && buildingKind !== 'farmhouse');

  return (
    <DraggableWindow
      windowId="door_access"
      title={title}
      icon={isLocked ? <Lock className="w-4 h-4 text-[#f5cc74]" /> : <Unlock className="w-4 h-4 text-[#a7df8e]" />}
      widthClass="w-[min(92vw,420px)]"
      headerAccent={buildingKind === 'farmhouse' ? 'moss' : 'oak'}
      onClose={onClose}
    >
      <div className="p-4 space-y-3.5 text-[#2b1a0e]">
        <div className="rounded-xl border-2 border-[#d3bc92] bg-[#fffaf0] p-3 text-xs leading-relaxed">
          <div className="font-extrabold text-sm mb-1 flex items-center gap-1.5">
            {isLocked ? (
              <>
                <Lock className="w-4 h-4 text-[#a63424]" />
                <span>Status: Auto-Lock Enabled</span>
              </>
            ) : (
              <>
                <Unlock className="w-4 h-4 text-[#356b26]" />
                <span>Status: Door Unlocked</span>
              </>
            )}
          </div>
          <p className="text-[#5c3c22]">
            {buildingKind === 'farmhouse'
              ? isLocked
                ? 'Auto-lock active: visiting players cannot enter or exit your private farmhouse.'
                : 'Door unlocked: friends visiting your farm may step inside your home.'
              : isLocked
                ? isHiredWorker && !isOwner
                  ? `Work contract active: you are authorized to enter this ${shortName} to tend livestock.`
                  : `Auto-lock active: animals remain safely inside your ${shortName}, and visitors cannot enter.`
                : `${shortName} unlocked: animals may graze in the pasture and visitors may enter.`}
          </p>
        </div>

        {/* Enter / Exit Option */}
        <button
          type="button"
          disabled={!canEnter}
          onClick={() => {
            onEnterOrExit();
            onClose();
          }}
          className="w-full py-2.5 px-4 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#b8ab96] disabled:text-[#5c4e3e] text-[#fef9ed] font-extrabold text-sm border-b-3 border-[#213f18] flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed"
        >
          <DoorOpen className="w-4 h-4" />
          {!canEnter
            ? 'Locked by Farm Owner'
            : isInside
              ? 'Open & Step Outside'
              : `Open & Enter ${shortName}`}
        </button>

        {/* Owner Lock Options */}
        {isOwner ? (
          <div className="space-y-2 pt-1 border-t border-[#d8c39b]">
            <div className="text-[11px] font-extrabold uppercase tracking-wider text-[#6e4624]">
              Private Door Security
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onToggleLock(false)}
                className={`py-2 px-3 rounded-xl border-2 text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer ${
                  !isLocked
                    ? 'bg-[#d9ebc9] border-[#3a6b2c] text-[#214617]'
                    : 'bg-[#fffaf0] border-[#d3bc92] text-[#5c3c22] hover:bg-[#f2e6cf]'
                }`}
              >
                <Unlock className="w-3.5 h-3.5" />
                Unlock Door
              </button>
              <button
                type="button"
                onClick={() => onToggleLock(true)}
                className={`py-2 px-3 rounded-xl border-2 text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer ${
                  isLocked
                    ? 'bg-[#f8d7d0] border-[#a63424] text-[#751d11]'
                    : 'bg-[#fffaf0] border-[#d3bc92] text-[#5c3c22] hover:bg-[#f2e6cf]'
                }`}
              >
                <Lock className="w-3.5 h-3.5" />
                Auto-Lock
              </button>
            </div>

            {buildingKind !== 'farmhouse' && animalsCount > 0 && onMoveAnimalsLocation && (
              <div className="pt-2 space-y-1.5">
                <div className="text-[11px] font-bold text-[#5c3c22]">
                  {buildingKind === 'coop'
                    ? 'Chickens'
                    : buildingKind === 'stable'
                      ? 'Horses'
                      : 'Cows & Sheep'}
                  : {animalsCount} total ({animalsCount - pastureAnimalsCount} indoors, {pastureAnimalsCount} in pasture)
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    disabled={isLocked}
                    onClick={() => onMoveAnimalsLocation('pasture')}
                    className="py-1.5 px-2.5 rounded-lg bg-[#d98a2b] hover:bg-[#bc731d] disabled:bg-[#cbbca3] text-white text-xs font-bold cursor-pointer disabled:cursor-not-allowed"
                  >
                    Let Out to Pasture
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      onMoveAnimalsLocation(
                        buildingKind === 'coop' ? 'coop' : buildingKind === 'stable' ? 'stable' : 'barn'
                      )
                    }
                    className="py-1.5 px-2.5 rounded-lg bg-[#6b4423] hover:bg-[#523218] text-white text-xs font-bold cursor-pointer"
                  >
                    Bring Inside {shortName}
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="rounded-xl bg-[#efe2c6] px-3 py-2 text-[11px] font-bold text-[#6e4624] flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 shrink-0 text-[#a63424]" />
            <span>Only the farm owner can change lock settings for this building.</span>
          </div>
        )}
      </div>
    </DraggableWindow>
  );
};
