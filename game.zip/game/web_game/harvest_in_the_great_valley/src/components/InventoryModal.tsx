import React, { useState } from 'react';
import { Backpack, Hand, HandMetal, PlusCircle, Trash2 } from 'lucide-react';
import {
  DEFAULT_KEYBINDINGS,
  DEFAULT_TOOL_SHORTCUTS,
  ITEMS,
  MAX_BAG_UPGRADES,
} from '../game/data/itemsAndCrops';
import type { InventorySlot, ItemCategory, KeyBindings } from '../game/types';
import { DraggableWindow } from './DraggableWindow';

interface InventoryModalProps {
  slots: InventorySlot[];
  maxSlots: number;
  bagUpgrades: number;
  nextUpgradeCost: number | null;
  nextUpgradeGoldCost: number | null;
  gold: number;
  diamond: number;
  debugMode?: boolean;
  equippedItemId: string | null;
  toolShortcuts?: string[];
  keyBindings?: KeyBindings;
  onSetEquippedItem: (itemId: string | null) => void;
  onSetToolShortcut?: (slotIdx: number, itemId: string) => void;
  onUseConsumable: (index: number) => void;
  onReorderSlots: (fromIdx: number, toIdx: number) => void;
  onDiscard: (index: number) => void;
  onUpgradeBag?: () => void;
  onUpgradeBagGold?: () => void;
  autoGiveEnabled?: boolean;
  onToggleAutoGive?: () => void;
  onClose: () => void;
}

const CATEGORIES: Array<{ id: 'All' | ItemCategory; label: string; emoji: string }> = [
  { id: 'All', label: 'All', emoji: '🧺' },
  { id: 'Tools', label: 'Tools', emoji: '⛏️' },
  { id: 'Seeds', label: 'Seeds', emoji: '🌱' },
  { id: 'Crops', label: 'Crops', emoji: '🥕' },
  { id: 'Livestock', label: 'Livestock', emoji: '🐮' },
  { id: 'Materials', label: 'Materials', emoji: '🪨' },
  { id: 'Other', label: 'Other', emoji: '🍯' },
];

function shortKeyLabel(code?: string): string {
  if (!code) return '?';
  if (code.startsWith('Digit')) return code.slice(5);
  if (code.startsWith('Key')) return code.slice(3);
  return code.slice(0, 3).toUpperCase();
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  slots,
  maxSlots,
  bagUpgrades,
  nextUpgradeCost,
  nextUpgradeGoldCost,
  gold,
  diamond,
  debugMode = false,
  equippedItemId,
  toolShortcuts = DEFAULT_TOOL_SHORTCUTS,
  keyBindings = DEFAULT_KEYBINDINGS,
  onSetEquippedItem,
  onSetToolShortcut,
  onUseConsumable,
  onReorderSlots,
  onDiscard,
  onUpgradeBag,
  autoGiveEnabled = true,
  onToggleAutoGive,
  onClose,
}) => {
  const [activeCat, setActiveCat] = useState<'All' | ItemCategory>('All');
  const [tradeFilter, setTradeFilter] = useState<'all' | 'diamond' | 'normal'>('all');
  const [selectedIdx, setSelectedIdx] = useState<number>(0);
  const [dragFromIdx, setDragFromIdx] = useState<number | 'master' | null>(null);
  const [masterHover, setMasterHover] = useState(false);

  const filteredEntries = slots
    .map((slot, originalIndex) => ({ slot, originalIndex, def: ITEMS[slot.itemId] }))
    .filter((entry) => {
      if (!entry.def) return false;
      if (activeCat !== 'All' && entry.def.category !== activeCat) return false;
      if (tradeFilter === 'diamond' && !entry.slot.diamondTradeable) return false;
      if (tradeFilter === 'normal' && entry.slot.diamondTradeable) return false;
      return true;
    });

  const selectedSlot = slots[selectedIdx];
  const selectedDef = selectedSlot ? ITEMS[selectedSlot.itemId] : null;
  const masterSlot = equippedItemId ? slots.find((s) => s.itemId === equippedItemId) : null;
  const masterDef = equippedItemId ? ITEMS[equippedItemId] : null;

  const shortcutKeyLabels = [
    shortKeyLabel(keyBindings.toolSlot1),
    shortKeyLabel(keyBindings.toolSlot2),
    shortKeyLabel(keyBindings.toolSlot3),
    shortKeyLabel(keyBindings.toolSlot4),
    shortKeyLabel(keyBindings.toolSlot5),
    shortKeyLabel(keyBindings.toolSlot6),
  ];

  // Build exact maxSlots boxes when in "All" tab (so empty boxes always appear cleanly!)
  const allBoxIndices = Array.from({ length: maxSlots }, (_, i) => i);

  return (
    <DraggableWindow
      windowId="inventory"
      title={`Farm Pack (${slots.length}/${maxSlots} Slots)`}
      icon={<Backpack className="w-5 h-5 text-[#f5cc74]" />}
      widthClass="w-[min(94vw,780px)]"
      headerAccent="oak"
      onClose={onClose}
    >
      <div className="p-4 space-y-3.5 text-[#2b1a0e]">
        {/* 1 MASTER HAND SLOT */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setMasterHover(true);
          }}
          onDragLeave={() => setMasterHover(false)}
          onDrop={(e) => {
            e.preventDefault();
            setMasterHover(false);
            if (typeof dragFromIdx === 'number') {
              const dragged = slots[dragFromIdx];
              if (dragged) onSetEquippedItem(dragged.itemId);
            }
            setDragFromIdx(null);
          }}
          className={`rounded-2xl border-3 p-3 flex flex-wrap items-center justify-between gap-3 transition-colors ${
            masterHover
              ? 'border-[#3a6b2c] bg-[#dcecd1]'
              : 'border-[#c59a45] bg-[#efe2c6]'
          }`}
        >
          <div className="flex items-center gap-3">
            <div
              draggable={Boolean(masterDef)}
              onDragStart={() => setDragFromIdx('master')}
              onDragEnd={() => setDragFromIdx(null)}
              className="w-14 h-14 rounded-2xl border-2 border-[#7a4b26] bg-[#fffaf0] flex items-center justify-center text-3xl shadow-inner cursor-grab active:cursor-grabbing shrink-0"
              title={masterDef ? `${masterDef.name} (Equipped)` : 'Master Hand Slot (Empty)'}
            >
              {masterDef ? masterDef.iconEmoji : <Hand className="w-6 h-6 text-[#9e8662]" />}
            </div>
            <div>
              <div className="text-[11px] font-black uppercase tracking-wider text-[#6e4624]">
                Master Hand Slot (Avatar Right Hand)
              </div>
              {masterDef ? (
                <div className="text-sm font-extrabold text-[#2b1a0e]">
                  Holding: {masterDef.name}{' '}
                  {masterSlot && masterSlot.quantity > 1 ? `(x${masterSlot.quantity})` : ''}
                </div>
              ) : (
                <div className="text-sm font-extrabold text-[#5c3c22]">
                  Empty Hand — Avatar walks freely without holding tools
                </div>
              )}
              <div className="text-[11px] text-[#6e4624]">
                Drag &amp; drop or <strong>double-click</strong> any item below to equip/unequip in your Master Hand Slot.
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {onToggleAutoGive && (
              <button
                type="button"
                onClick={onToggleAutoGive}
                title="When ON, pressing E near an NPC while holding an item gives it automatically. When OFF, pressing E lets you choose Talk or Give."
                className={`px-3 py-2 rounded-xl text-xs font-extrabold border-2 flex items-center gap-2 cursor-pointer transition-colors ${
                  autoGiveEnabled
                    ? 'bg-[#3a6b2c] border-[#214417] text-white'
                    : 'bg-[#fffaf0] border-[#bfa070] text-[#4b2d16]'
                }`}
              >
                <span>🎁 Auto-Give [E]:</span>
                <span className="px-1.5 py-0.5 rounded bg-black/20 text-[10px] font-black">
                  {autoGiveEnabled ? 'ON' : 'OFF'}
                </span>
              </button>
            )}
            {masterDef && (
              <button
                type="button"
                onClick={() => onSetEquippedItem(null)}
                className="px-3.5 py-2 rounded-xl bg-[#a63424] hover:bg-[#822518] text-white text-xs font-extrabold border-b-2 border-[#5c160c] flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                <HandMetal className="w-3.5 h-3.5" />
                Unequip / Empty Hand
              </button>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-[185px_1fr] gap-3.5">
          {/* Left Category Tabs + Bag Capacity Upgrades */}
          <div className="flex md:flex-col gap-1.5 overflow-x-auto pb-1">
            {CATEGORIES.map((cat) => {
              const active = activeCat === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setActiveCat(cat.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl font-extrabold text-xs border-2 transition-colors whitespace-nowrap cursor-pointer ${
                    active
                      ? 'bg-[#f2cf7e] border-[#b8711e] text-[#3c2310]'
                      : 'bg-[#efe2c6] border-[#d3bc92] text-[#5c3c22] hover:bg-[#e5d3b0]'
                  }`}
                >
                  <span>{cat.emoji}</span>
                  <span>{cat.label}</span>
                </button>
              );
            })}

            <div className="hidden md:flex flex-col gap-1.5 mt-auto p-2.5 rounded-xl bg-[#efe2c6] border border-[#d3bc92]">
              <div className="flex items-center justify-between font-extrabold text-xs">
                <span>🧺 Capacity</span>
                <span className="tabular-nums">
                  {slots.length}/{maxSlots}
                </span>
              </div>
              <div className="text-[10px] text-[#6e4624] font-bold">
                Upgrades: {bagUpgrades}/{MAX_BAG_UPGRADES} (+6 slots each)
              </div>
              {onUpgradeBag && nextUpgradeCost !== null && (
                <button
                  type="button"
                  onClick={onUpgradeBag}
                  disabled={!debugMode && diamond < nextUpgradeCost}
                  className="w-full py-1.5 px-2 rounded-lg bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#cbbca3] disabled:text-[#5c4e3e] text-white text-[10px] font-extrabold flex items-center justify-center gap-1 cursor-pointer disabled:cursor-not-allowed"
                >
                  <PlusCircle className="w-3 h-3" /> +6 (💎 {nextUpgradeCost})
                </button>
              )}
            </div>
          </div>

          {/* Right Drag & Drop Slot Grid & 6 Tool Shortcuts */}
          <div className="flex flex-col gap-3">
            {/* 6-Slot Quick-Swap Bar on Top inside Tools tab */}
            {activeCat === 'Tools' && (
              <div className="rounded-2xl border-2 border-[#c59a45] bg-[#fae8c4]/70 p-2.5 space-y-1.5">
                <div className="flex items-center justify-between text-[11px] font-extrabold text-[#4b2d16]">
                  <span>⚡ 6 Quick-Swap Tool Shortcuts (Remappable in Settings)</span>
                  <span className="text-[10px] text-[#6e4624]">Drag a tool here or click to equip</span>
                </div>
                <div className="grid grid-cols-6 gap-1.5">
                  {Array.from({ length: 6 }, (_, i) => {
                    const shortcutItemId = toolShortcuts[i];
                    const sDef = shortcutItemId ? ITEMS[shortcutItemId] : null;
                    const isEquipped = Boolean(shortcutItemId && equippedItemId === shortcutItemId);
                    const ownsTool = Boolean(shortcutItemId && slots.some((s) => s.itemId === shortcutItemId));
                    return (
                      <button
                        key={i}
                        type="button"
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={(e) => {
                          e.preventDefault();
                          if (typeof dragFromIdx === 'number' && onSetToolShortcut) {
                            const dragged = slots[dragFromIdx];
                            const dDef = dragged ? ITEMS[dragged.itemId] : null;
                            if (dragged && dDef?.category === 'Tools') {
                              onSetToolShortcut(i, dragged.itemId);
                            }
                          }
                          setDragFromIdx(null);
                        }}
                        onClick={() => {
                          if (!shortcutItemId || !ownsTool) return;
                          onSetEquippedItem(isEquipped ? null : shortcutItemId);
                        }}
                        title={sDef ? `[${shortcutKeyLabels[i]}] ${sDef.name}` : `Shortcut ${i + 1}`}
                        className={`relative aspect-square rounded-xl border-2 flex flex-col items-center justify-center p-1 cursor-pointer transition-transform ${
                          isEquipped
                            ? 'border-[#3a6b2c] bg-[#dcecd1] ring-2 ring-[#96b884]'
                            : 'border-[#bfa070] bg-[#fffaf0] hover:border-[#784820]'
                        }`}
                      >
                        <span className="absolute top-0.5 left-1 text-[9px] font-black px-1 rounded bg-[#4b2d16] text-[#fef7e6]">
                          {shortcutKeyLabels[i]}
                        </span>
                        <span className={`text-xl leading-none ${ownsTool ? '' : 'opacity-30'}`}>
                          {sDef?.iconEmoji || '➖'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Stack Type Filter: Separate Diamond-Tradeable vs Normal Stacks */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
              <div className="flex items-center gap-1">
                {(
                  [
                    ['all', 'All Stacks'],
                    ['diamond', '💎 Diamond P2P'],
                    ['normal', '🪙 Normal'],
                  ] as const
                ).map(([flt, label]) => (
                  <button
                    key={flt}
                    type="button"
                    onClick={() => setTradeFilter(flt)}
                    className={`px-2.5 py-1 rounded-lg font-extrabold border cursor-pointer transition-colors ${
                      tradeFilter === flt
                        ? flt === 'diamond'
                          ? 'bg-[#0284c7] text-white border-[#0369a1]'
                          : 'bg-[#3a6b2c] text-white border-[#214417]'
                        : 'bg-[#fffaf0] text-[#5c3c22] border-[#d3bc92] hover:bg-[#f2e5cb]'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
              <span className="text-[10px] font-bold text-[#6e4624]">
                Double-click item = Equip Hand
              </span>
            </div>

            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                if (dragFromIdx === 'master') {
                  onSetEquippedItem(null);
                  setDragFromIdx(null);
                }
              }}
              className="grid grid-cols-4 sm:grid-cols-6 gap-2 max-h-[240px] overflow-y-auto p-1.5 rounded-xl bg-[#efe2c6]/60 border border-[#d8c39b]"
            >
              {activeCat === 'All' && tradeFilter === 'all'
                ? allBoxIndices.map((slotIndex) => {
                    const slot = slots[slotIndex];
                    const def = slot ? ITEMS[slot.itemId] : null;
                    const isSelected = slotIndex === selectedIdx;
                    const isEquipped = Boolean(slot && equippedItemId === slot.itemId);

                    if (!slot || !def) {
                      return (
                        <div
                          key={`empty_${slotIndex}`}
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            if (dragFromIdx === 'master') {
                              onSetEquippedItem(null);
                            } else if (typeof dragFromIdx === 'number' && dragFromIdx < slots.length) {
                              const targetIdx = Math.min(slots.length - 1, slotIndex);
                              if (dragFromIdx !== targetIdx) {
                                onReorderSlots(dragFromIdx, targetIdx);
                                setSelectedIdx(targetIdx);
                              }
                            }
                            setDragFromIdx(null);
                          }}
                          className="aspect-square rounded-xl border-2 border-dashed border-[#cbb58b] bg-[#f7eedc]/50 flex items-center justify-center text-[10px] font-bold text-[#b8a381]"
                        >
                          {slotIndex + 1}
                        </div>
                      );
                    }

                    return (
                      <button
                        key={`${slot.itemId}_${slotIndex}`}
                        type="button"
                        draggable
                        onDragStart={() => setDragFromIdx(slotIndex)}
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          if (dragFromIdx === 'master') {
                            onSetEquippedItem(null);
                          } else if (typeof dragFromIdx === 'number' && dragFromIdx !== slotIndex) {
                            onReorderSlots(dragFromIdx, slotIndex);
                            setSelectedIdx(slotIndex);
                          }
                          setDragFromIdx(null);
                        }}
                        onDragEnd={() => setDragFromIdx(null)}
                        onClick={() => setSelectedIdx(slotIndex)}
                        onDoubleClick={() => {
                          setSelectedIdx(slotIndex);
                          onSetEquippedItem(isEquipped ? null : slot.itemId);
                        }}
                        title={`${def.name}${slot.diamondTradeable ? ' (💎 Diamond Tradeable)' : ''} — Double-click to equip`}
                        className={`relative aspect-square rounded-xl border-2 flex flex-col items-center justify-center p-1 transition-transform cursor-grab active:cursor-grabbing ${
                          isSelected
                            ? 'border-[#3a6b2c] bg-[#fffaf0] ring-2 ring-[#96b884] scale-[1.03]'
                            : slot.diamondTradeable
                              ? 'border-[#38bdf8] bg-[#f0f9ff] hover:border-[#0284c7]'
                              : 'border-[#d3bc92] bg-[#f9f3e4] hover:border-[#8a5a32]'
                        }`}
                      >
                        <span className="text-2xl sm:text-3xl leading-none select-none">{def.iconEmoji}</span>
                        {slot.diamondTradeable && (
                          <span
                            className="absolute bottom-0.5 left-1 text-[10px] leading-none"
                            title="Diamond P2P Tradeable"
                          >
                            💎
                          </span>
                        )}
                        {slot.toolLevel && slot.toolLevel > 1 && (
                          <span className="absolute top-1 left-1 text-[9px] font-black text-[#784820]">
                            Lv{slot.toolLevel}
                          </span>
                        )}
                        {isEquipped && (
                          <span className="absolute top-0.5 right-0.5 text-[8px] font-black px-1 rounded bg-[#3a6b2c] text-white">
                            Held
                          </span>
                        )}
                        {slot.quantity > 1 && (
                          <span className="absolute bottom-0.5 right-1.5 text-[11px] font-black text-[#2b1a0e] tabular-nums">
                            {slot.quantity}
                          </span>
                        )}
                      </button>
                    );
                  })
                : filteredEntries.map(({ slot, originalIndex, def }) => {
                    const isSelected = originalIndex === selectedIdx;
                    const isEquipped = equippedItemId === slot.itemId;
                    return (
                      <button
                        key={`${slot.itemId}_${originalIndex}`}
                        type="button"
                        draggable
                        onDragStart={() => setDragFromIdx(originalIndex)}
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          if (dragFromIdx === 'master') {
                            onSetEquippedItem(null);
                          } else if (typeof dragFromIdx === 'number' && dragFromIdx !== originalIndex) {
                            onReorderSlots(dragFromIdx, originalIndex);
                            setSelectedIdx(originalIndex);
                          }
                          setDragFromIdx(null);
                        }}
                        onDragEnd={() => setDragFromIdx(null)}
                        onClick={() => setSelectedIdx(originalIndex)}
                        onDoubleClick={() => {
                          setSelectedIdx(originalIndex);
                          onSetEquippedItem(isEquipped ? null : slot.itemId);
                        }}
                        title={`${def.name}${slot.diamondTradeable ? ' (💎 Diamond Tradeable)' : ''} — Double-click to equip`}
                        className={`relative aspect-square rounded-xl border-2 flex flex-col items-center justify-center p-1 transition-transform cursor-grab active:cursor-grabbing ${
                          isSelected
                            ? 'border-[#3a6b2c] bg-[#fffaf0] ring-2 ring-[#96b884] scale-[1.03]'
                            : slot.diamondTradeable
                              ? 'border-[#38bdf8] bg-[#f0f9ff] hover:border-[#0284c7]'
                              : 'border-[#d3bc92] bg-[#f9f3e4] hover:border-[#8a5a32]'
                        }`}
                      >
                        <span className="text-2xl sm:text-3xl leading-none select-none">{def.iconEmoji}</span>
                        {slot.diamondTradeable && (
                          <span
                            className="absolute bottom-0.5 left-1 text-[10px] leading-none"
                            title="Diamond P2P Tradeable"
                          >
                            💎
                          </span>
                        )}
                        {slot.toolLevel && slot.toolLevel > 1 && (
                          <span className="absolute top-1 left-1 text-[9px] font-black text-[#784820]">
                            Lv{slot.toolLevel}
                          </span>
                        )}
                        {isEquipped && (
                          <span className="absolute top-0.5 right-0.5 text-[8px] font-black px-1 rounded bg-[#3a6b2c] text-white">
                            Held
                          </span>
                        )}
                        {slot.quantity > 1 && (
                          <span className="absolute bottom-0.5 right-1.5 text-[11px] font-black text-[#2b1a0e] tabular-nums">
                            {slot.quantity}
                          </span>
                        )}
                      </button>
                    );
                  })}

              {activeCat !== 'All' && filteredEntries.length === 0 && (
                <div className="col-span-full py-10 text-center text-xs font-bold text-[#6e4624]">
                  No items in the {activeCat} category yet.
                </div>
              )}
            </div>

            {selectedDef && selectedSlot ? (
              <div className="rounded-2xl border-2 border-[#d3bc92] bg-[#efe2c6] p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-[#fffaf0] border-2 border-[#bfa070] flex items-center justify-center text-2xl shrink-0">
                    {selectedDef.iconEmoji}
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-extrabold text-sm">{selectedDef.name}</h3>
                      {selectedDef.sellPrice > 0 && (
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded-lg bg-[#f2cf7e] text-[#4b2d16]">
                          Resell {selectedDef.sellPrice.toLocaleString()} G
                        </span>
                      )}
                      {selectedSlot.diamondTradeable ? (
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded-lg bg-[#d9eefc] text-[#0c4a6e] border border-[#38bdf8]">
                          💎 Diamond P2P Stack
                        </span>
                      ) : (
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded-lg bg-[#f2e5cb] text-[#6e4624] border border-[#d3bc92]">
                          🪙 Normal Stack
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-[#5c3c22] mt-0.5">{selectedDef.description}</p>
                    {selectedSlot.durability !== undefined && selectedSlot.maxDurability && (
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[11px] font-bold text-[#5c3c22]">Durability</span>
                        <div className="w-24 h-2 rounded-full bg-[#dfd1b5] overflow-hidden border border-[#bfa070]">
                          <div
                            className="h-full bg-[#468c32]"
                            style={{ width: `${(selectedSlot.durability / selectedSlot.maxDurability) * 100}%` }}
                          />
                        </div>
                        <span className="text-[11px] font-bold tabular-nums">
                          {selectedSlot.durability}/{selectedSlot.maxDurability}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  {selectedDef.category !== 'Tools' && (
                    <button
                      type="button"
                      onClick={() => onDiscard(selectedIdx)}
                      className="p-2 rounded-xl bg-[#a63424] hover:bg-[#822518] text-white cursor-pointer"
                      title="Discard Item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                  {selectedDef.staminaRestore && (
                    <button
                      type="button"
                      onClick={() => onUseConsumable(selectedIdx)}
                      className="px-3.5 py-2 rounded-xl bg-[#d98a2b] hover:bg-[#b8711e] text-white font-extrabold text-xs cursor-pointer"
                    >
                      Eat (+{selectedDef.staminaRestore}⚡)
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      if (equippedItemId === selectedSlot.itemId) {
                        onSetEquippedItem(null);
                      } else {
                        onSetEquippedItem(selectedSlot.itemId);
                      }
                    }}
                    className={`px-4 py-2 rounded-xl font-extrabold text-xs cursor-pointer ${
                      equippedItemId === selectedSlot.itemId
                        ? 'bg-[#6b4423] hover:bg-[#503218] text-white'
                        : 'bg-[#3a6b2c] hover:bg-[#2d5422] text-white'
                    }`}
                  >
                    {equippedItemId === selectedSlot.itemId ? 'Unequip Hand' : 'Equip in Master Slot'}
                  </button>
                </div>
              </div>
            ) : (
              <div className="rounded-2xl border-2 border-[#d3bc92] bg-[#efe2c6] p-3 text-center text-xs font-semibold text-[#6e4624]">
                Select an item or drag it into your Master Hand Slot above.
              </div>
            )}
          </div>
        </div>
      </div>
    </DraggableWindow>
  );
};
