import React from 'react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message || 'An unexpected system error occurred.' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen w-full bg-[#fef7e6] flex items-center justify-center p-6 text-[#452715]">
          <div className="max-w-md w-full rounded-3xl border-4 border-[#d9b88c] bg-[#fffaf0] p-6 shadow-2xl">
            <h2 className="text-xl font-bold text-[#9a3412] mb-2">Oops! Great Valley Needs a Refresh</h2>
            <p className="text-sm text-[#6b4423] mb-4 break-words">{this.state.message}</p>
            <button
              onClick={() => window.location.reload()}
              className="px-5 py-2.5 rounded-xl bg-[#2563eb] text-white font-semibold hover:bg-[#1d4ed8] transition-colors cursor-pointer"
            >
              Reload Game
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
