import React, { useEffect, useRef, useState } from 'react';
import {
  Backpack,
  BarChart3,
  BookOpen,
  ChevronDown,
  ChevronUp,
  Cloud,
  CloudLightning,
  CloudRain,
  Hand,
  Heart,
  Lock,
  MessageSquare,
  Mic,
  MicOff,
  Minimize2,
  PhoneOff,
  Pencil,
  RefreshCw,
  Settings,
  Smartphone,
  Smile,
  Snowflake,
  Sun,
  User,
  Video,
  VideoOff,
  Volume2,
  WifiOff,
} from 'lucide-react';
import { DEFAULT_KEYBINDINGS, ITEMS } from '../game/data/itemsAndCrops';
import {
  DEFAULT_MOBILE_GAMEPAD_LAYOUT,
  MOBILE_CONTROLS_CONFIG,
  createEmptySalesStats,
} from '../game/data/gameRuntimeConfig';
import { getDaysInSeason, ZONE_LABELS } from '../game/data/worldConfig';
import { t, translateSeason, translateWeather } from '../game/i18n';
import { xpRequiredForLevel } from '../game/progression';
import type {
  AnimalState,
  CustomMobileGamepadLayout,
  FarmJobOffer,
  FestivalDef,
  FloatingChatBubble,
  GameStats,
  KeyBindings,
  Language,
  MobileControlsConfig,
  NpcEmotion,
  PlayerProfile,
  Season,
  VideoCallConfig,
  Weather,
  WorldSpeechBubble,
  WorldZoneId,
} from '../game/types';
import type { FloatingTag, NearbyPrompt, PlayerHeadAnchor } from '../game/three/GameEngine';
import type { CallStateSnapshot, DeviceProfile } from '../services/callManager';
import { DraggableWindow } from './DraggableWindow';

const EMOTION_EMOJI: Record<NpcEmotion, string> = {
  neutral: '💬',
  happy: '😊',
  tired: '🥱',
  sad: '😔',
  angry: '😠',
  nervous: '😰',
  excited: '🤩',
};

const LiveVideoStream: React.FC<{
  stream: MediaStream | null;
  muted?: boolean;
  className?: string;
}> = ({ stream, muted = false, className = '' }) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    if (el.srcObject !== stream) {
      el.srcObject = stream;
    }
    const tryPlay = () => {
      void el.play().catch(() => {});
    };
    if (stream) {
      tryPlay();
      el.addEventListener('loadedmetadata', tryPlay);
      return () => el.removeEventListener('loadedmetadata', tryPlay);
    }
  }, [stream]);

  return <video ref={videoRef} autoPlay playsInline muted={muted} className={className} />;
};

const RemoteAudioSink: React.FC<{
  stream: MediaStream;
  unlockNonce: number;
  onAutoplayBlocked: () => void;
}> = ({ stream, unlockNonce, onAutoplayBlocked }) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  useEffect(() => {
    const el = audioRef.current;
    if (!el) return;
    if (el.srcObject !== stream) {
      el.srcObject = stream;
    }
    el.muted = false;
    el.volume = 1.0;
    const playNow = () => {
      const p = el.play();
      if (p && typeof p.catch === 'function') {
        p.catch(() => onAutoplayBlocked());
      }
    };
    playNow();
    el.addEventListener('loadedmetadata', playNow);
    return () => el.removeEventListener('loadedmetadata', playNow);
  }, [stream, unlockNonce, onAutoplayBlocked]);

  return <audio ref={audioRef} autoPlay playsInline className="hidden" />;
};

interface GameHUDProps {
  language?: Language;
  season: Season;
  day: number;
  year: number;
  hour: number;
  minute: number;
  weather: Weather;
  gold: number;
  diamond: number;
  debugMode?: boolean;
  stamina: number;
  maxStamina: number;
  fun: number;
  level: number;
  xp: number;
  zone: WorldZoneId;
  visitingFarmName: string | null;
  onlineCount: number;
  isCloudSynced: boolean;
  isOnline: boolean;
  equippedItemId: string | null;
  nearbyPrompt: NearbyPrompt | null;
  floatingTags: FloatingTag[];
  headAnchors?: PlayerHeadAnchor[];
  chatBubbles?: FloatingChatBubble[];
  callState?: CallStateSnapshot;
  activeJob?: FarmJobOffer | null;
  activeFestival?: FestivalDef | null;
  currentUid?: string;
  toastMessage: string | null;
  keyBindings?: KeyBindings;
  deviceProfile?: DeviceProfile;
  mobileMode?: boolean;
  mobileControlsConfig?: MobileControlsConfig;
  customGamepadLayout?: CustomMobileGamepadLayout;
  mobileSprintActive?: boolean;
  showSelfCameraInCall?: boolean;
  videoCallConfig?: VideoCallConfig;
  profile?: PlayerProfile;
  renameDisplayNameCost?: number;
  canRenameDisplayName?: boolean;
  onRenameDisplayName?: (nextName: string) => Promise<void>;
  animals?: AnimalState[];
  stats?: GameStats;
  guestRemainingSec?: number | null;
  onToggleMobileMode?: () => void;
  onExitMobileMode?: () => void;
  onOpenInventory: () => void;
  onOpenBuku: () => void;
  onOpenSettings: () => void;
  onOpenDiamondShop: () => void;
  onToggleChat: () => void;
  onToggleMic?: () => void;
  onToggleCam?: () => void;
  onFlipCam?: () => void;
  onLeaveCall?: () => void;
  onCompleteActiveJob?: (jobId: string) => void;
  onTriggerAction: (mode: 'social' | 'execute') => void;
  onJump?: () => void;
  onJumpRelease?: () => void;
  onDash?: () => void;
  onSprintToggle?: () => void;
  onTouchMove: (x: number, y: number) => void;
  worldSpeechBubbles?: WorldSpeechBubble[];
  npcChoicePopover?: {
    npcId: string;
    npcName: string;
    heldItemName: string;
    heldItemEmoji: string;
  } | null;
  onNpcChoiceTalk?: (npcId: string) => void;
  onNpcChoiceGive?: (npcId: string) => void;
  onCloseNpcChoice?: () => void;
  fishingBar?: {
    active: boolean;
    phase: 'casting' | 'waiting' | 'bite' | 'reeling';
    cursorPct: number;
    zoneStartPct: number;
    zoneWidthPct: number;
    strikesHit: number;
    strikesRequired: number;
  } | null;
  onFishingStrike?: () => void;
  onFishingCancel?: () => void;
  caveLevel?: number;
}

function formatKeyBadge(code: string): string {
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  if (code === 'Space') return 'SPC';
  if (code === 'ShiftLeft' || code === 'ShiftRight') return 'SHF';
  return code.slice(0, 4).toUpperCase();
}

export const GameHUD: React.FC<GameHUDProps> = ({
  language = 'en',
  season,
  day,
  year,
  hour,
  minute,
  weather,
  gold,
  diamond,
  debugMode = false,
  stamina,
  maxStamina,
  fun,
  level,
  xp,
  zone,
  visitingFarmName,
  onlineCount,
  isCloudSynced,
  isOnline,
  equippedItemId,
  nearbyPrompt,
  floatingTags,
  headAnchors = [],
  chatBubbles = [],
  callState,
  activeJob = null,
  activeFestival = null,
  currentUid = '',
  toastMessage,
  keyBindings = DEFAULT_KEYBINDINGS,
  deviceProfile,
  mobileMode = false,
  mobileControlsConfig,
  customGamepadLayout,
  mobileSprintActive = false,
  showSelfCameraInCall = false,
  videoCallConfig,
  profile,
  renameDisplayNameCost = 250,
  canRenameDisplayName = false,
  onRenameDisplayName,
  animals = [],
  stats,
  guestRemainingSec = null,
  onToggleMobileMode,
  onExitMobileMode,
  onOpenInventory,
  onOpenBuku,
  onOpenSettings,
  onOpenDiamondShop,
  onToggleChat,
  onToggleMic,
  onToggleCam,
  onFlipCam,
  onLeaveCall,
  onCompleteActiveJob,
  onTriggerAction,
  onJump,
  onJumpRelease,
  onDash,
  onSprintToggle,
  onTouchMove,
  worldSpeechBubbles = [],
  npcChoicePopover = null,
  onNpcChoiceTalk,
  onNpcChoiceGive,
  onCloseNpcChoice,
  fishingBar = null,
  onFishingStrike,
  onFishingCancel,
  caveLevel = 1,
}) => {
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [detailTab, setDetailTab] = useState<'profile' | 'animals' | 'sales'>('profile');
  const [isEditingDisplayName, setIsEditingDisplayName] = useState(false);
  const [displayNameDraft, setDisplayNameDraft] = useState('');
  const [renameBusy, setRenameBusy] = useState(false);
  const [renameError, setRenameError] = useState<string | null>(null);
  const [knobOffset, setKnobOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [joystickActive, setJoystickActive] = useState(false);
  const [pressedAction, setPressedAction] = useState<string | null>(null);
  const joystickRef = React.useRef<HTMLDivElement>(null);
  const joystickPointer = React.useRef<number | null>(null);
  const mobileCtrl = mobileControlsConfig || MOBILE_CONTROLS_CONFIG;
  const triggerPressFeedback = (id: string) => {
    setPressedAction(id);
    window.setTimeout(() => setPressedAction((prev) => (prev === id ? null : prev)), 180);
  };
  const updateJoystick = (clientX: number, clientY: number) => {
    const el = joystickRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const radius = Math.min(rect.width, rect.height) * 0.36;
    const dx = clientX - (rect.left + rect.width / 2);
    const dy = clientY - (rect.top + rect.height / 2);
    const len = Math.hypot(dx, dy);
    const scale = len > radius ? radius / len : 1;
    const clampedX = dx * scale;
    const clampedY = dy * scale;
    setKnobOffset({ x: clampedX, y: clampedY });
    onTouchMove(Math.max(-1, Math.min(1, clampedX / radius)), Math.max(-1, Math.min(1, clampedY / radius)));
  };
  const resetJoystick = () => {
    joystickPointer.current = null;
    setJoystickActive(false);
    setKnobOffset({ x: 0, y: 0 });
    onTouchMove(0, 0);
  };

  const WeatherIcon =
    weather === 'Stormy'
      ? CloudLightning
      : weather === 'Rainy' || weather === 'LightRain' || weather === 'HeavyRain'
        ? CloudRain
        : weather === 'Snowy'
          ? Snowflake
          : weather === 'Cloudy' || weather === 'Foggy'
            ? Cloud
            : Sun;
  const heldDef = equippedItemId ? ITEMS[equippedItemId] : null;
  const xpNeeded = xpRequiredForLevel(level);
  const xpPct = Math.min(100, Math.max(0, (xp / xpNeeded) * 100));
  const funPct = Math.min(100, Math.max(0, fun));
  const stamPct = Math.min(100, Math.max(0, (stamina / Math.max(1, maxStamina)) * 100));

  const socialKeyLabel = formatKeyBadge(keyBindings.social);
  const executeKeyLabel = formatKeyBadge(keyBindings.execute);

  const isTouchCapable = Boolean(deviceProfile?.isPhone || deviceProfile?.kind === 'mobile' || deviceProfile?.hasTouch);
  const showMobileControls = mobileMode;

  const salesStats = stats?.salesStats || createEmptySalesStats();
  const SEASONS_ORDER: Season[] = ['Spring', 'Summer', 'Autumn', 'Winter'];
  const ANIMAL_GROUPS: Array<{ type: AnimalState['type']; emoji: string; labelEn: string; labelId: string }> = [
    { type: 'dog', emoji: '🐕', labelEn: 'Dog', labelId: 'Anjing' },
    { type: 'horse', emoji: '🐎', labelEn: 'Horse', labelId: 'Kuda' },
    { type: 'chicken', emoji: '🐔', labelEn: 'Chickens', labelId: 'Ayam' },
    { type: 'cow', emoji: '🐄', labelEn: 'Cows', labelId: 'Sapi' },
    { type: 'sheep', emoji: '🐑', labelEn: 'Sheep', labelId: 'Domba' },
  ];

  const anchorMap = new Map<string, PlayerHeadAnchor>();
  for (const a of headAnchors) {
    anchorMap.set(a.uid, a);
  }

  // Remote callers whose 3D head is NOT currently visible in the same zone (fallback PIP in top-right)
  const offscreenCallers =
    callState?.inCall
      ? callState.participants.filter((p) => {
          if (p.uid === currentUid) return false;
          const anchor = anchorMap.get(p.uid);
          return !anchor || !anchor.visible;
        })
      : [];

  const menuButtons: Array<{
    key: string;
    label: string;
    icon: React.ReactNode;
    onClick: () => void;
    tone: string;
  }> = [
    { key: 'chat', label: t(language, 'hud.chat'), icon: <MessageSquare className="w-3.5 h-3.5 shrink-0" />, onClick: onToggleChat, tone: 'bg-[#b8711e] hover:bg-[#965a14] text-[#fef7e6]' },
    { key: 'bag', label: t(language, 'hud.bag'), icon: <Backpack className="w-3.5 h-3.5 shrink-0" />, onClick: onOpenInventory, tone: 'bg-[#784820] hover:bg-[#5c3616] text-[#fef7e6]' },
    { key: 'menu', label: t(language, 'hud.book'), icon: <BookOpen className="w-3.5 h-3.5 shrink-0" />, onClick: onOpenBuku, tone: 'bg-[#3a6b2c] hover:bg-[#2d5422] text-[#fef7e6]' },
    { key: 'settings', label: t(language, 'hud.settings'), icon: <Settings className="w-3.5 h-3.5 shrink-0" />, onClick: onOpenSettings, tone: 'bg-[#4b382a] hover:bg-[#36271d] text-[#fef7e6]' },
  ];

  const activeJobPct = activeJob
    ? Math.min(100, Math.round((activeJob.completedTaskIds.length / Math.max(1, activeJob.totalUnits)) * 100))
    : 0;

  const [audioBlocked, setAudioBlocked] = useState(false);
  const [audioUnlockNonce, setAudioUnlockNonce] = useState(0);

  const goldDisplay = debugMode ? '∞' : `${gold.toLocaleString()} G`;
  const diamondDisplay = debugMode ? '∞' : diamond.toLocaleString();
  const speakingSet = new Set(callState?.speakingUids || []);
  const callParticipantMap = new Map(
    (callState?.inCall ? callState.participants : []).map((p) => [p.uid, p] as const)
  );

  return (
    <div className="fixed inset-0 z-20 pointer-events-none select-none overflow-hidden">
      {/* Always-mounted cross-device remote audio sinks (works off-screen, across zones, and on iOS/Android!) */}
      {callState?.inCall &&
        Object.entries(callState.remoteStreams).map(([uid, stream]) => (
          <RemoteAudioSink
            key={`audio_sink_${uid}`}
            stream={stream}
            unlockNonce={audioUnlockNonce}
            onAutoplayBlocked={() => setAudioBlocked(true)}
          />
        ))}
      {/* Proximity-Only Floating NPC & Remote Player Nameplates */}
      {floatingTags.map((tag) => (
        <div
          key={tag.id}
          style={{ left: tag.x, top: tag.y }}
          className="absolute -translate-x-1/2 -translate-y-full pointer-events-none"
        >
          <div
            className={`px-2.5 py-0.5 rounded-lg text-[10px] font-extrabold whitespace-nowrap shadow ${
              tag.kind === 'player'
                ? 'bg-[#355e2b] text-[#fef9ed] border border-[#e5c17d]'
                : 'bg-[#f7eedc]/95 text-[#2b1a0e] border border-[#7a4b26]'
            }`}
          >
            {tag.label}
          </div>
        </div>
      ))}

      {/* Floating In-Game Chat Bubbles ABOVE Speakers' Heads (Strict owner binding: Player A -> above Player A, Player B -> above Player B!) */}
      {chatBubbles.map((bubble) => {
        if (bubble.isPrivate && bubble.senderId !== currentUid && bubble.targetId !== currentUid) {
          return null;
        }
        const anchor = anchorMap.get(bubble.senderId);
        if (!anchor || !anchor.visible) return null;
        const callMember = callParticipantMap.get(bubble.senderId);
        const isInVideoCall = Boolean(callMember && (callMember.camOn || (anchor.isLocal && callState?.camOn)));
        const isInVoiceCall = Boolean(callMember && !isInVideoCall);
        const isActivelySpeaking = speakingSet.has(bubble.senderId);
        const hasCallOverlayAbove = Boolean(callMember);
        return (
          <div
            key={bubble.id}
            style={{
              left: anchor.x,
              top: anchor.y - (isInVideoCall ? 124 : hasCallOverlayAbove ? 62 : 26),
            }}
            className="absolute -translate-x-1/2 -translate-y-full pointer-events-none max-w-[230px] z-25"
          >
            <div
              className={`px-3 py-1.5 rounded-2xl text-[11px] font-bold shadow-lg border-2 break-words leading-snug ${
                bubble.isPrivate
                  ? 'bg-[#4b1d17] text-[#fef2f2] border-[#f59e0b]'
                  : 'bg-[#fffaf0]/95 text-[#2b1a0e] border-[#7a4b26]'
              }`}
            >
              <div className="flex items-center gap-1 text-[9px] font-black uppercase tracking-wide opacity-90 mb-0.5">
                {bubble.isPrivate && <Lock className="w-2.5 h-2.5 text-[#f5cc74] shrink-0" />}
                {isInVideoCall && <Video className="w-3 h-3 text-[#0284c7] shrink-0" />}
                {isInVoiceCall && (
                  <Volume2
                    className={`w-3 h-3 shrink-0 ${isActivelySpeaking ? 'text-[#16a34a] animate-pulse' : 'text-[#65a30d]'}`}
                  />
                )}
                <span className="truncate">{bubble.senderName}</span>
                {bubble.isPrivate && <span>· Private</span>}
              </div>
              <div>{bubble.text}</div>
            </div>
            <div
              className={`w-2.5 h-2.5 rotate-45 mx-auto -mt-1.5 border-r-2 border-b-2 ${
                bubble.isPrivate
                  ? 'bg-[#4b1d17] border-[#f59e0b]'
                  : 'bg-[#fffaf0] border-[#7a4b26]'
              }`}
            />
          </div>
        );
      })}

      {/* Overhead Speech & Thought Bubbles for NPCs, Signboards & Players (Strictly anchored ONLY to their actual speaker/object!) */}
      {worldSpeechBubbles.map((sb) => {
        const anchor = anchorMap.get(sb.anchorId);
        // Strict ownership: NEVER fall back to screen center or another player if the true speaker is off-screen!
        if (!anchor || !anchor.visible) return null;
        const isSign = sb.kind === 'sign';
        const isPlayer = sb.kind === 'player';
        const isThought = Boolean(sb.isThought);
        const callMember = isPlayer ? callParticipantMap.get(sb.anchorId) : undefined;
        const isVideoCallMember = Boolean(callMember && (callMember.camOn || (anchor.isLocal && callState?.camOn)));
        const isVoiceCallMember = Boolean(callMember && !isVideoCallMember);
        const isSpeakingNow = speakingSet.has(sb.anchorId);
        const topOffset = isVideoCallMember ? 124 : callMember ? 62 : 26;
        const badgeIcon = isSign
          ? '🪧'
          : isThought
            ? '💭'
            : sb.emotion
              ? EMOTION_EMOJI[sb.emotion]
              : isPlayer
                ? '✨'
                : '💬';

        return (
          <div
            key={sb.id}
            style={{ left: anchor.x, top: anchor.y - topOffset }}
            className="absolute -translate-x-1/2 -translate-y-full pointer-events-none max-w-[270px] z-25"
          >
            <div
              className={`px-3 py-2 text-[11px] font-bold shadow-xl border-2 break-words leading-snug ${
                isThought ? 'rounded-3xl border-dashed' : 'rounded-2xl'
              } ${
                isSign
                  ? 'bg-[#f7eedc]/95 text-[#2b1a0e] border-[#8b5a2b]'
                  : isPlayer
                    ? 'bg-[#fef3c7]/95 text-[#451a03] border-[#d97706]'
                    : isThought
                      ? 'bg-[#f8fafc]/92 text-[#334155] border-[#64748b]'
                      : 'bg-[#fffaf0]/95 text-[#2b1a0e] border-[#3a6b2c]'
              }`}
            >
              <div className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wide text-[#6e4624] mb-0.5">
                {isVideoCallMember ? (
                  <Video className="w-3 h-3 text-[#0284c7] shrink-0" />
                ) : isVoiceCallMember ? (
                  <Volume2
                    className={`w-3 h-3 shrink-0 ${isSpeakingNow ? 'text-[#16a34a] animate-pulse' : 'text-[#65a30d]'}`}
                  />
                ) : (
                  <span>{badgeIcon}</span>
                )}
                <span className="truncate">{sb.speakerName}</span>
              </div>
              <div className={isThought ? 'italic text-[#334155]' : 'text-[#2b1a0e]'}>{sb.text}</div>
            </div>
            {isThought ? (
              <div className="flex flex-col items-center -mt-0.5 gap-0.5">
                <div className="w-2 h-2 rounded-full bg-[#f8fafc] border border-[#64748b]" />
                <div className="w-1.5 h-1.5 rounded-full bg-[#f8fafc] border border-[#64748b]" />
              </div>
            ) : (
              <div
                className={`w-3 h-3 rotate-45 mx-auto -mt-1.5 border-r-2 border-b-2 ${
                  isSign
                    ? 'bg-[#f7eedc] border-[#8b5a2b]'
                    : isPlayer
                      ? 'bg-[#fef3c7] border-[#d97706]'
                      : 'bg-[#fffaf0] border-[#3a6b2c]'
                }`}
              />
            )}
          </div>
        );
      })}

      {/* Compact NPC Talk vs Give Choice Popover (when Auto-Give is OFF and holding a non-tool item) */}
      {npcChoicePopover && (() => {
        const anchor = anchorMap.get(`npc:${npcChoicePopover.npcId}`);
        if (!anchor || !anchor.visible) return null;
        return (
          <div
            style={{ left: anchor.x, top: anchor.y - 26 }}
            className="absolute -translate-x-1/2 -translate-y-full pointer-events-auto z-40"
          >
            <div className="rounded-2xl border-2 border-[#7a4b26] bg-[#fffaf0] text-[#2b1a0e] shadow-2xl p-2 space-y-1.5 min-w-[205px]">
              <div className="flex items-center justify-between gap-2 px-1">
                <span className="text-[11px] font-black text-[#4b2d16] truncate">{npcChoicePopover.npcName}</span>
                {onCloseNpcChoice && (
                  <button
                    type="button"
                    onClick={onCloseNpcChoice}
                    className="text-[10px] font-black px-1.5 py-0.5 rounded bg-[#efe2c6] hover:bg-[#e5d3b0] text-[#4b2d16] cursor-pointer"
                  >
                    ✕
                  </button>
                )}
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => onNpcChoiceTalk?.(npcChoicePopover.npcId)}
                  className="px-2.5 py-1.5 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] text-white text-[11px] font-extrabold cursor-pointer"
                >
                  💬 {language === 'id' ? 'Bicara' : 'Talk'}
                </button>
                <button
                  type="button"
                  onClick={() => onNpcChoiceGive?.(npcChoicePopover.npcId)}
                  className="px-2.5 py-1.5 rounded-xl bg-[#d97706] hover:bg-[#b45309] text-white text-[11px] font-extrabold cursor-pointer truncate"
                >
                  {npcChoicePopover.heldItemEmoji} {language === 'id' ? 'Beri' : 'Give'}
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Overhead Voice & Video Call Bubbles — strictly showing remote callers' video in Chat Bubble by default */}
      {callState?.inCall &&
        callState.participants.map((participant) => {
          const isLocalCaller = participant.uid === currentUid;
          if (isLocalCaller) return null;
          const anchor = anchorMap.get(participant.uid);
          if (!anchor || !anchor.visible) return null;
          const stream = callState.remoteStreams[participant.uid] || null;
          const camActive = participant.camOn;
          const micActive = participant.micOn;
          const hasLiveVideo = Boolean(stream && camActive && stream.getVideoTracks().length > 0);
          const isVideoCall = camActive || callState.mode === 'video';
          const isSpeakingNow = speakingSet.has(participant.uid);

          return (
            <div
              key={`head_call_${participant.uid}`}
              style={{ left: anchor.x, top: anchor.y - 16 }}
              className="absolute -translate-x-1/2 -translate-y-full pointer-events-none z-22"
            >
              {hasLiveVideo ? (
                <div className="flex flex-col items-center">
                  <div
                    className={`w-30 h-26 rounded-2xl overflow-hidden border-2 bg-slate-950 shadow-2xl relative ${
                      isSpeakingNow ? 'border-emerald-400 ring-2 ring-emerald-400/40' : 'border-sky-400/90'
                    }`}
                  >
                    {/* Always muted on video tag because RemoteAudioSink handles clean single-source audio playback */}
                    <LiveVideoStream stream={stream} muted className="w-full h-full object-cover" />
                    <div className="absolute top-1 left-1 px-1.5 py-0.5 rounded-md bg-slate-950/90 text-sky-300 flex items-center gap-1 text-[8px] font-black">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span>LIVE</span>
                    </div>
                    <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/65 to-transparent px-1.5 py-1 text-[9px] font-extrabold text-white flex items-center justify-between gap-1">
                      <span className="truncate">{participant.avatarName}</span>
                      {micActive ? (
                        <Volume2 className={`w-2.5 h-2.5 shrink-0 ${isSpeakingNow ? 'text-emerald-400 animate-pulse' : 'text-emerald-200'}`} />
                      ) : (
                        <MicOff className="w-2.5 h-2.5 text-rose-400 shrink-0" />
                      )}
                    </div>
                  </div>
                  <div className="w-2.5 h-2.5 rotate-45 -mt-1.5 bg-slate-950 border-r-2 border-b-2 border-sky-400/90" />
                </div>
              ) : (
                <div className="flex flex-col items-center">
                  <div
                    className={`px-2.5 py-1 rounded-2xl border-2 text-[#fef9ed] text-[10px] font-extrabold shadow-lg flex items-center gap-1.5 ${
                      isSpeakingNow
                        ? 'bg-[#166534] border-[#4ade80]'
                        : isVideoCall
                          ? 'bg-[#0c4a6e] border-[#38bdf8]'
                          : 'bg-[#244418] border-[#f5cc74]'
                    }`}
                  >
                    {isVideoCall ? (
                      <Video className="w-3.5 h-3.5 text-[#7dd3fc] shrink-0" />
                    ) : (
                      <Volume2
                        className={`w-3.5 h-3.5 shrink-0 ${
                          !micActive
                            ? 'text-[#fca5a5] opacity-70'
                            : isSpeakingNow
                              ? 'text-[#4ade80] animate-pulse'
                              : 'text-[#bbf7d0]'
                        }`}
                      />
                    )}
                    <span className="max-w-[110px] truncate">{participant.avatarName}</span>
                    {!micActive && <MicOff className="w-2.5 h-2.5 text-[#fca5a5] shrink-0" />}
                  </div>
                  <div
                    className={`w-2.5 h-2.5 rotate-45 -mt-1.5 border-r-2 border-b-2 ${
                      isSpeakingNow
                        ? 'bg-[#166534] border-[#4ade80]'
                        : isVideoCall
                          ? 'bg-[#0c4a6e] border-[#38bdf8]'
                          : 'bg-[#244418] border-[#f5cc74]'
                    }`}
                  />
                </div>
              )}
            </div>
          );
        })}

      {/* TOP-RIGHT: Compact Mode Switch Button, Guest Timer & Modern Call Controls (strictly unified with Global Theme) */}
      <div className="fixed top-2.5 right-2.5 z-30 pointer-events-none flex flex-col items-end gap-2">
        <div className="flex items-center justify-end gap-2 pointer-events-auto">
          {typeof guestRemainingSec === 'number' && guestRemainingSec >= 0 && (
            <div
              className={`h-9 px-3 rounded-xl text-[11px] font-black flex items-center gap-1.5 whitespace-nowrap ${
                guestRemainingSec <= 300 ? 'gv-pill-warn animate-pulse' : 'gv-pill'
              }`}
              title={
                language === 'id'
                  ? 'Sesi akun Guest sementara. Data tidak disimpan saat reload dan akan logout otomatis saat waktu habis.'
                  : 'Temporary Guest session. Progress resets on reload and auto-logs out when timer expires.'
              }
            >
              <span>⏳</span>
              <span>
                Guest {String(Math.floor(guestRemainingSec / 60)).padStart(2, '0')}:
                {String(Math.floor(guestRemainingSec % 60)).padStart(2, '0')}
              </span>
            </div>
          )}
          {(isTouchCapable || mobileMode) && (onToggleMobileMode || onExitMobileMode) && (
            <button
              type="button"
              onClick={() => {
                if (mobileMode && onExitMobileMode) {
                  onExitMobileMode();
                } else if (onToggleMobileMode) {
                  onToggleMobileMode();
                }
              }}
              title={t(language, 'hud.switchMode')}
              aria-label={t(language, 'hud.switchMode')}
              className="gv-pill h-9 px-3 rounded-xl text-[11px] font-black flex items-center gap-1.5 cursor-pointer whitespace-nowrap hover:brightness-95"
            >
              {mobileMode ? (
                <Minimize2 className="w-3.5 h-3.5 shrink-0" style={{ color: 'var(--hv-pill-accent)' }} />
              ) : (
                <Smartphone className="w-3.5 h-3.5 shrink-0" style={{ color: 'var(--hv-pill-accent)' }} />
              )}
              <span>{t(language, 'hud.switchMode')}</span>
            </button>
          )}
        </div>

        {/* Modern Video/Voice Call Mini-Dock + Optional Top-Right Self-Camera PIP */}
        {callState?.inCall && (
          <div className="pointer-events-auto flex flex-col items-end gap-2 max-w-[260px]">
            <div className="gv-title-card px-3 py-2 space-y-1.5">
              <div className="flex items-center justify-between gap-2 text-[10px] font-bold text-slate-300">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>
                    {callState.mode === 'video' ? 'Video Call' : 'Voice Call'} · {callState.participants.length}
                  </span>
                </span>
                {callState.mode === 'video' && (
                  <span className="px-1.5 py-0.5 rounded bg-white/10 font-mono text-[9px] text-sky-300">
                    {videoCallConfig ? `${videoCallConfig.height}p · ${videoCallConfig.fps}fps` : '240p · 30fps'}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5">
                {onToggleMic && (
                  <button
                    type="button"
                    onClick={onToggleMic}
                    className={`p-2 rounded-xl cursor-pointer transition-colors ${
                      callState.micOn ? 'bg-emerald-600 hover:bg-emerald-500 text-white' : 'bg-rose-600 hover:bg-rose-500 text-white'
                    }`}
                    title={callState.micOn ? 'Mute Mic' : 'Unmute Mic'}
                  >
                    {callState.micOn ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
                  </button>
                )}
                {onToggleCam && (
                  <button
                    type="button"
                    onClick={onToggleCam}
                    className={`p-2 rounded-xl cursor-pointer transition-colors ${
                      callState.camOn ? 'bg-sky-600 hover:bg-sky-500 text-white' : 'bg-slate-700 hover:bg-slate-600 text-slate-200'
                    }`}
                    title={callState.camOn ? 'Turn Off Video' : 'Turn On Video'}
                  >
                    {callState.camOn ? <Video className="w-3.5 h-3.5" /> : <VideoOff className="w-3.5 h-3.5" />}
                  </button>
                )}
                {onFlipCam && callState.camOn && (
                  <button
                    type="button"
                    onClick={onFlipCam}
                    className="p-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white cursor-pointer transition-colors"
                    title={language === 'id' ? 'Putar Kamera Depan/Belakang' : 'Flip Front/Back Camera'}
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                )}
                {onLeaveCall && (
                  <button
                    type="button"
                    onClick={onLeaveCall}
                    className="px-2.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-black flex items-center gap-1 cursor-pointer transition-colors"
                    title={t(language, 'chat.endCall')}
                  >
                    <PhoneOff className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {audioBlocked && (
              <button
                type="button"
                onClick={() => {
                  setAudioBlocked(false);
                  setAudioUnlockNonce((n) => n + 1);
                }}
                className="px-2.5 py-1.5 rounded-xl bg-[#d97706] hover:bg-[#b45309] text-white text-[10px] font-black shadow-lg flex items-center gap-1.5 cursor-pointer"
              >
                <Volume2 className="w-3.5 h-3.5 animate-pulse" />
                <span>{language === 'id' ? 'Aktifkan Audio Panggilan' : 'Tap to Enable Call Audio'}</span>
              </button>
            )}

            {/* Self-Camera Preview in Top-Right: Hidden by default, toggled via Settings */}
            {showSelfCameraInCall && callState.localStream && callState.camOn && (
              <div className="w-28 h-20 rounded-2xl overflow-hidden border-2 border-sky-400/80 bg-slate-950 shadow-2xl relative">
                <LiveVideoStream stream={callState.localStream} muted className="w-full h-full object-cover" />
                <div className="absolute top-1 left-1 px-1.5 py-0.5 rounded bg-black/65 text-[8px] font-black text-sky-300">
                  SELF
                </div>
                <span className="absolute bottom-0.5 left-1.5 text-[9px] font-bold text-white drop-shadow">
                  {language === 'id' ? 'Kamera Saya' : 'You'}
                </span>
              </div>
            )}

            {offscreenCallers.map((p) => {
              const stream = callState.remoteStreams[p.uid] || null;
              const isSpeakingOff = speakingSet.has(p.uid);
              return (
                <div
                  key={`pip_${p.uid}`}
                  className={`w-28 h-22 rounded-xl overflow-hidden border-2 bg-[#1c1917] shadow-lg relative flex items-center justify-center ${
                    isSpeakingOff ? 'border-[#4ade80]' : 'border-[#f5cc74]'
                  }`}
                >
                  {stream && p.camOn ? (
                    <LiveVideoStream stream={stream} muted className="w-full h-full object-cover" />
                  ) : (
                    <div className="flex flex-col items-center gap-1 text-[#fef7e6]">
                      <Volume2 className={`w-4 h-4 ${isSpeakingOff ? 'text-[#4ade80] animate-pulse' : 'text-[#f5cc74]'}`} />
                      <div className="text-[10px] font-extrabold truncate max-w-[96px]">{p.avatarName}</div>
                    </div>
                  )}
                  <div className="absolute bottom-0 inset-x-0 bg-black/65 px-1.5 py-0.5 text-[9px] font-bold text-white truncate">
                    {p.avatarName} ({language === 'id' ? 'Zona lain' : 'Other zone'})
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* TOP-LEFT: Unified Farmer Info + 4 Menu Buttons Module + Notifications Underneath */}
      <div className="fixed top-2.5 left-2.5 z-20 flex flex-col items-stretch gap-1.5 pointer-events-none w-[min(304px,calc(100vw-20px))]">
        <div className="gv-hud-module pointer-events-auto rounded-2xl border-2 border-[#7a4b26] bg-[#f7eedc]/95 shadow-xl text-[#2b1a0e] overflow-hidden">
          {/* Top Half: Clickable Farmer Info Summary (toggles detailed profile/animals/sales window) */}
          <div
            role="button"
            tabIndex={0}
            onClick={() => setDetailsOpen((prev) => !prev)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                setDetailsOpen((prev) => !prev);
              }
            }}
            title={t(language, 'hud.clickForDetails')}
            className="px-3 py-2 space-y-1.5 cursor-pointer hover:bg-black/5 transition-colors select-none"
          >
            {/* Row 1: Season/Day/Clock + Weather + Level + Chevron */}
            <div className="flex items-center justify-between gap-1.5 text-[11px] font-extrabold">
              <div className="flex items-center gap-1 min-w-0">
                <span className="px-1.5 py-0.5 rounded-md bg-[#f2cf7e] border border-[#c59a45] text-[#452715] truncate">
                  {translateSeason(language, season)} {day}/{getDaysInSeason(season)} · Y{year}
                </span>
                <span className="tabular-nums opacity-90 shrink-0">
                  {String(hour).padStart(2, '0')}:{String(minute).padStart(2, '0')}
                </span>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <WeatherIcon className="w-3.5 h-3.5 text-[#c87d1a]" />
                <span className="px-1.5 py-0.5 rounded-md bg-[#e2ecd8] border border-[#8db07b] text-[#23481a] text-[10px] font-black">
                  Lv.{level}
                </span>
                {detailsOpen ? <ChevronUp className="w-3.5 h-3.5 opacity-75" /> : <ChevronDown className="w-3.5 h-3.5 opacity-75" />}
              </div>
            </div>

            {/* Row 2: Farmer Name + Gold + Clickable Diamond Shop Button */}
            <div className="flex items-center justify-between gap-2 text-xs font-black tabular-nums">
              <span className="truncate text-[11px] font-extrabold">
                {profile?.avatarName || 'Farmer'}
              </span>
              <div className="flex items-center gap-1.5 shrink-0">
                <span>💰 {goldDisplay}</span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenDiamondShop();
                  }}
                  title={language === 'id' ? 'Klik untuk buka Toko Diamond' : 'Click to open Diamond Shop'}
                  className="px-1.5 py-0.5 rounded-md bg-sky-500/15 hover:bg-sky-500/30 border border-sky-500/40 text-[#0369a1] dark:text-sky-300 font-black transition cursor-pointer flex items-center gap-0.5"
                >
                  <span>💎</span>
                  <span>{diamondDisplay}</span>
                </button>
              </div>
            </div>

            {/* Row 3: Stamina, Joy & XP Bars */}
            <div className="grid grid-cols-3 gap-1.5 text-[9px] font-bold">
              <div>
                <div className="flex justify-between mb-0.5">
                  <span className="text-[#2e5e21]">⚡ {t(language, 'hud.stamina')}</span>
                  <span className="tabular-nums">{stamina}</span>
                </div>
                <div className="h-1.5 rounded-full bg-[#dfd1b5] overflow-hidden border border-[#bfa070]">
                  <div className="h-full bg-[#468c32] transition-all duration-150" style={{ width: `${stamPct}%` }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-0.5">
                  <span className="text-[#9e5316] flex items-center gap-0.5">
                    <Smile className="w-2.5 h-2.5" /> {t(language, 'hud.joy')}
                  </span>
                  <span className="tabular-nums">{Math.round(funPct)}%</span>
                </div>
                <div className="h-1.5 rounded-full bg-[#dfd1b5] overflow-hidden border border-[#bfa070]">
                  <div className="h-full bg-[#d98a2b] transition-all duration-150" style={{ width: `${funPct}%` }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-0.5">
                  <span className="opacity-85">✨ {t(language, 'hud.xp')}</span>
                  <span className="tabular-nums">{xp}/{xpNeeded}</span>
                </div>
                <div className="h-1.5 rounded-full bg-[#dfd1b5] overflow-hidden border border-[#bfa070]">
                  <div className="h-full bg-[#8a5a32] transition-all duration-150" style={{ width: `${xpPct}%` }} />
                </div>
              </div>
            </div>

            {/* Row 4: Held Tool + Zone + Online Indicator */}
            <div className="flex items-center justify-between gap-2 text-[10px] font-bold opacity-85 pt-0.5 border-t border-[#d3bc92]/70">
              <span className="truncate flex items-center gap-1">
                <Hand className="w-3 h-3 text-[#784820] shrink-0" />
                {heldDef ? `${heldDef.iconEmoji} ${heldDef.name}` : t(language, 'hud.emptyHand')}
              </span>
              <span className="truncate max-w-[118px]">
                📍{' '}
                {visitingFarmName
                  ? visitingFarmName
                  : zone === 'int_cave'
                    ? `Cave Lv.${caveLevel}`
                    : ZONE_LABELS[zone]}
              </span>
              <span className="flex items-center gap-0.5 shrink-0">
                {isOnline ? (
                  <Cloud className={`w-3 h-3 ${isCloudSynced ? 'text-[#3a6b2c]' : 'text-[#b8711e]'}`} />
                ) : (
                  <WifiOff className="w-3 h-3 text-[#a63424]" />
                )}
                {isOnline ? onlineCount : t(language, 'hud.offline')}
              </span>
            </div>
          </div>

          {/* Bottom Half (Seamless Integrated Bar): 4 Unified Menu Buttons */}
          <div className="border-t-2 border-[#c89d54]/70 bg-black/5 px-1.5 py-1.5">
            <div className="grid grid-cols-4 gap-1">
              {menuButtons.map((btn) => (
                <button
                  key={btn.key}
                  type="button"
                  onClick={btn.onClick}
                  title={btn.label}
                  aria-label={btn.label}
                  className={`flex flex-col items-center justify-center gap-0.5 px-1 py-1.5 rounded-lg text-[10px] font-extrabold leading-tight shadow-sm transition active:scale-95 cursor-pointer ${btn.tone}`}
                >
                  {btn.icon}
                  <span className="truncate max-w-full">{btn.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Notifications & Active Status Docked Cleanly Underneath Unified Info+Menu */}
        {toastMessage && (
          <div className="pointer-events-auto w-full px-3 py-1.5 rounded-xl bg-[#3c2310]/95 text-[#fef2c2] text-[11px] font-extrabold shadow-lg border border-[#c89d54] leading-snug">
            {toastMessage}
          </div>
        )}

        {activeFestival && (
          <div className="pointer-events-auto rounded-xl border border-[#d97706] bg-[#fffbeb]/95 px-2.5 py-1 shadow text-[#78350f] w-full">
            <div className="flex items-center justify-between gap-1 text-[10px] font-black">
              <span className="truncate">🎪 {activeFestival.name}</span>
              <span className="shrink-0 px-1 py-0.5 rounded bg-[#fde68a] text-[#92400e] text-[9px]">
                {hour >= (activeFestival.startHour ?? 10) && hour <= (activeFestival.endHour ?? 18)
                  ? 'LIVE'
                  : `${activeFestival.startHour ?? 10}:00`}
              </span>
            </div>
          </div>
        )}

        {activeJob && (
          <div className="pointer-events-auto rounded-xl border border-[#0284c7] bg-[#f0f9ff]/95 px-2.5 py-1.5 shadow text-[#0c4a6e] space-y-1 w-full">
            <div className="flex items-center justify-between text-[10px] font-extrabold">
              <span className="truncate">💼 {activeJob.farmName}</span>
              <span className="tabular-nums">{activeJobPct}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-[#bae6fd] overflow-hidden">
              <div className="h-full bg-[#0284c7] transition-all" style={{ width: `${activeJobPct}%` }} />
            </div>
            {onCompleteActiveJob && (
              <button
                type="button"
                onClick={() => onCompleteActiveJob(activeJob.id)}
                className="w-full py-0.5 rounded-md bg-[#0284c7] hover:bg-[#0369a1] text-white text-[10px] font-extrabold cursor-pointer"
              >
                {t(language, 'jobs.finishClaim')} ({activeJob.completedTaskIds.length}/{activeJob.totalUnits})
              </button>
            )}
          </div>
        )}
      </div>

      {/* Draggable Detailed Farmer Profile, Animal Happiness & Seasonal Sales Window */}
      {detailsOpen && (
        <DraggableWindow
          windowId="player_details"
          title={t(language, 'hud.playerDetails')}
          icon={<User className="w-4 h-4 text-[#f5cc74]" />}
          widthClass="w-[min(94vw,520px)]"
          defaultOffset={{ x: -160, y: -90 }}
          headerAccent="walnut"
          zIndexClass="z-30"
          onClose={() => setDetailsOpen(false)}
        >
          <div className="p-3.5 space-y-3 text-[#2b1a0e] max-h-[75vh] overflow-y-auto">
            {/* 3 Detail Tabs */}
            <div className="grid grid-cols-3 gap-1.5">
              {(
                [
                  ['profile', t(language, 'details.profileTab'), <User key="u" className="w-3.5 h-3.5" />],
                  ['animals', t(language, 'details.animalsTab'), <Heart key="h" className="w-3.5 h-3.5" />],
                  ['sales', t(language, 'details.salesTab'), <BarChart3 key="b" className="w-3.5 h-3.5" />],
                ] as const
              ).map(([tabId, label, icon]) => (
                <button
                  key={tabId}
                  type="button"
                  onClick={() => setDetailTab(tabId)}
                  className={`px-2.5 py-2 rounded-xl text-[11px] font-extrabold flex items-center justify-center gap-1.5 border cursor-pointer transition-colors ${
                    detailTab === tabId
                      ? 'bg-[#3a6b2c] text-[#fef9ed] border-[#214417]'
                      : 'bg-[#efe2c6] text-[#4b2d16] border-[#d3bc92] hover:bg-[#e5d3b0]'
                  }`}
                >
                  {icon}
                  <span className="truncate">{label}</span>
                </button>
              ))}
            </div>

            {detailTab === 'profile' && (
              <div className="space-y-2.5">
                <div className="rounded-xl bg-[#efe2c6] border border-[#d3bc92] p-3 grid grid-cols-2 gap-2 text-xs">
                  <div className="col-span-2 rounded-lg border border-[#d3bc92] bg-[#f8efd9] p-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <div className="text-[10px] font-bold text-[#6e4624]">{language === 'id' ? 'Nama Karakter' : 'Display Name'}</div>
                      <button
                        type="button"
                        disabled={!canRenameDisplayName || renameBusy}
                        onClick={() => {
                          setDisplayNameDraft(profile?.avatarName || '');
                          setRenameError(null);
                          setIsEditingDisplayName((value) => !value);
                        }}
                        title={language === 'id' ? 'Ganti nama dengan Diamond' : 'Change name with Diamonds'}
                        className="p-1.5 rounded-lg border border-[#c7a978] bg-[#efe2c6] text-[#6e4624] hover:bg-[#e5d3b0] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    {!isEditingDisplayName ? (
                      <div className="font-black text-sm mt-1 break-words">{profile?.avatarName || 'Farmer'}</div>
                    ) : (
                      <div className="mt-2 space-y-2">
                        <input
                          autoFocus
                          value={displayNameDraft}
                          maxLength={32}
                          onChange={(event) => setDisplayNameDraft(event.target.value)}
                          placeholder={language === 'id' ? 'Masukkan nama baru' : 'Enter new Display Name'}
                          className="w-full rounded-lg border border-[#c7a978] bg-[#fffaf0] px-2.5 py-2 text-sm font-bold text-[#2b1a0e] outline-none focus:ring-2 focus:ring-[#b8711e]"
                        />
                        {renameError && <div className="text-[10px] font-bold text-red-700">{renameError}</div>}
                        <div className="flex items-center justify-between gap-2">
                          <button
                            type="button"
                            onClick={() => { setIsEditingDisplayName(false); setRenameError(null); }}
                            className="px-3 py-2 rounded-lg border border-[#c7a978] bg-[#efe2c6] text-[#5c3c22] text-xs font-extrabold cursor-pointer"
                          >
                            {language === 'id' ? 'Batal' : 'Cancel'}
                          </button>
                          <button
                            type="button"
                            disabled={renameBusy || !displayNameDraft.trim() || displayNameDraft.trim() === (profile?.avatarName || '') || !canRenameDisplayName || diamond < renameDisplayNameCost}
                            onClick={async () => {
                              if (!onRenameDisplayName) return;
                              setRenameBusy(true);
                              setRenameError(null);
                              try {
                                await onRenameDisplayName(displayNameDraft.trim());
                                setIsEditingDisplayName(false);
                              } catch (error) {
                                setRenameError(error instanceof Error ? error.message : 'Name change failed');
                              } finally {
                                setRenameBusy(false);
                              }
                            }}
                            className="px-3 py-2 rounded-lg bg-[#3a6b2c] hover:bg-[#2d5422] text-white text-xs font-black cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                          >
                            {renameBusy ? '...' : <>OK · {renameDisplayNameCost.toLocaleString()} 💎</>}
                          </button>
                        </div>
                        {diamond < renameDisplayNameCost && (
                          <div className="text-[10px] font-bold text-red-700">{language === 'id' ? 'Diamond tidak mencukupi.' : 'Not enough Diamonds.'}</div>
                        )}
                      </div>
                    )}
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-[#6e4624]">{language === 'id' ? 'Nama Kebun' : 'Farm Name'}</div>
                    <div className="font-black text-sm">{profile?.farmName || 'Great Valley Farm'}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-[#6e4624]">{language === 'id' ? 'Gender' : 'Gender'}</div>
                    <div className="font-extrabold capitalize">{profile?.avatarConfig?.gender || 'male'}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-[#6e4624]">{language === 'id' ? 'Ulang Tahun' : 'Birthday'}</div>
                    <div className="font-extrabold">
                      {profile?.birthday || `${translateSeason(language, 'Spring')} 1`}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-[#6e4624]">🐕 {language === 'id' ? 'Nama Anjing' : 'Dog Name'}</div>
                    <div className="font-extrabold">{profile?.dogName || 'Kuro'}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-[#6e4624]">🐎 {language === 'id' ? 'Nama Kuda' : 'Horse Name'}</div>
                    <div className="font-extrabold">{profile?.horseName || 'Pony'}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-[#6e4624]">💍 {language === 'id' ? 'Pasangan' : 'Spouse'}</div>
                    <div className="font-extrabold">
                      {profile?.spousePlayerName || profile?.spouseId || (language === 'id' ? 'Belum Menikah' : 'Single')}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-[#6e4624]">📱 {language === 'id' ? 'Valley Phone' : 'Valley Phone'}</div>
                    <div className="font-extrabold">
                      {profile?.hasPhone ? (language === 'id' ? 'Aktif (Voice & Video)' : 'Owned (Voice & Video)') : (language === 'id' ? 'Belum Dimiliki' : 'Not Owned')}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="rounded-xl bg-[#fffaf0] border border-[#d3bc92] p-2">
                    <div className="text-[10px] font-bold text-[#6e4624]">{language === 'id' ? 'Rumah' : 'House'}</div>
                    <div className="font-black">Lv.{profile?.houseLevel ?? 1}</div>
                  </div>
                  <div className="rounded-xl bg-[#fffaf0] border border-[#d3bc92] p-2">
                    <div className="text-[10px] font-bold text-[#6e4624]">{language === 'id' ? 'Kandang Sapi' : 'Barn'}</div>
                    <div className="font-black">Lv.{profile?.barnLevel ?? 1}</div>
                  </div>
                  <div className="rounded-xl bg-[#fffaf0] border border-[#d3bc92] p-2">
                    <div className="text-[10px] font-bold text-[#6e4624]">{language === 'id' ? 'Kandang Ayam' : 'Coop'}</div>
                    <div className="font-black">Lv.{profile?.coopLevel ?? 1}</div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-[#fffaf0] border border-[#d3bc92] px-3 py-2 text-xs font-black tabular-nums">
                  <span>💰 {debugMode ? 'Unlimited (∞)' : `${gold.toLocaleString()} G`}</span>
                  <button
                    type="button"
                    onClick={() => {
                      setDetailsOpen(false);
                      onOpenDiamondShop();
                    }}
                    className="text-[#8a4d22] hover:underline cursor-pointer"
                  >
                    💎 {debugMode ? 'Unlimited (∞)' : diamond.toLocaleString()}
                  </button>
                  <span className="flex items-center gap-1 text-[11px] font-bold text-[#5c3c22]">
                    <WeatherIcon className="w-3.5 h-3.5 text-[#c87d1a]" />
                    {translateWeather(language, weather)}
                  </span>
                </div>
              </div>
            )}

            {detailTab === 'animals' && (
              <div className="space-y-2.5">
                {ANIMAL_GROUPS.map((grp) => {
                  const list = animals.filter((a) => a.type === grp.type);
                  const avgHappiness =
                    list.length > 0
                      ? Math.round(
                          list.reduce(
                            (s, a) => s + Math.max(0, Math.min(100, a.happiness ?? Math.min(100, a.affection))),
                            0
                          ) / list.length
                        )
                      : 0;
                  const maxLabel = grp.type === 'dog' || grp.type === 'horse' ? `${list.length}/1` : `${list.length}`;
                  return (
                    <div key={grp.type} className="rounded-xl bg-[#fffaf0] border border-[#d3bc92] p-2.5 space-y-1.5">
                      <div className="flex items-center justify-between text-xs font-extrabold">
                        <span>
                          {grp.emoji} {language === 'id' ? grp.labelId : grp.labelEn} ({maxLabel})
                        </span>
                        <span className="tabular-nums text-[#3a6b2c]">
                          {list.length > 0 ? `${avgHappiness}% ❤️` : (language === 'id' ? 'Belum ada' : 'None yet')}
                        </span>
                      </div>
                      <div className="h-2 rounded-full bg-[#e6d7b8] overflow-hidden border border-[#cbb286]">
                        <div className="h-full bg-[#e05d44] transition-all" style={{ width: `${avgHappiness}%` }} />
                      </div>
                      {list.length > 0 && (
                        <div className="grid sm:grid-cols-2 gap-1.5 pt-1">
                          {list.map((a) => {
                            const hungerVal = Math.round(a.hunger ?? (a.fedToday ? 100 : 55));
                            const healthVal = Math.round(a.health ?? (a.isSick ? 30 : 100));
                            const happyVal = Math.round(a.happiness ?? Math.min(100, a.affection));
                            return (
                              <div
                                key={a.id}
                                className={`rounded-lg border px-2 py-1.5 text-[10px] space-y-0.5 ${
                                  a.isSick ? 'bg-[#fef2f2] border-[#dc2626]' : 'bg-[#f7eedc] border-[#d9c39b]'
                                }`}
                              >
                                <div className="flex items-center justify-between gap-1">
                                  <span className="font-black truncate">{a.name}</span>
                                  <span className={`font-black tabular-nums shrink-0 ${a.isSick ? 'text-[#b91c1c]' : 'text-[#9e3020]'}`}>
                                    {a.isSick ? (language === 'id' ? '🤒 SAKIT' : '🤒 SICK') : `${happyVal}%`}
                                  </span>
                                </div>
                                <div className="text-[9px] text-[#6e4624]">
                                  {a.birthday ? `🎂 ${a.birthday}` : ''}
                                  {a.fedToday ? ' · 🌾' : ''}
                                  {a.brushedToday ? ' · 🪥' : ''}
                                  {` · 🍖${hungerVal}% · ❤️${healthVal}%`}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {detailTab === 'sales' && (
              <div className="space-y-3">
                {/* Ledger 1: Market Sales (Gold) */}
                <div className="rounded-xl bg-[#fffaf0] border-2 border-[#d9a441] p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-[#784820]">
                      🪙 {t(language, 'details.marketGoldTitle')}
                    </span>
                    <span className="text-xs font-black text-[#9a5c14] tabular-nums">
                      {salesStats.marketGoldTotalQty.toLocaleString()} item · {salesStats.marketGoldTotalRevenue.toLocaleString()} G
                    </span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-[11px]">
                    {SEASONS_ORDER.map((s) => {
                      const b = salesStats.marketGoldBySeason[s] || { qty: 0, revenue: 0 };
                      return (
                        <div key={`mg_${s}`} className="rounded-lg bg-[#f7eedc] border border-[#d3bc92] p-2">
                          <div className="font-extrabold text-[#5c3c22]">{translateSeason(language, s)}</div>
                          <div className="font-black tabular-nums">{b.qty.toLocaleString()} item</div>
                          <div className="text-[10px] font-bold text-[#9a5c14] tabular-nums">{b.revenue.toLocaleString()} G</div>
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex items-center justify-between pt-1 border-t border-[#e5d3b0] text-xs font-black">
                    <span>{t(language, 'details.totalSold')} (Market)</span>
                    <span className="tabular-nums text-[#9a5c14]">
                      {salesStats.marketGoldTotalQty.toLocaleString()} item · 💰 {salesStats.marketGoldTotalRevenue.toLocaleString()} G
                    </span>
                  </div>
                </div>

                {/* Ledger 2: Player-to-Player Sales (Diamond) */}
                <div className="rounded-xl bg-[#f0f9ff] border-2 border-[#38bdf8] p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-[#0c4a6e]">
                      💎 {t(language, 'details.p2pDiamondTitle')}
                    </span>
                    <span className="text-xs font-black text-[#0369a1] tabular-nums">
                      {salesStats.p2pDiamondTotalQty.toLocaleString()} item · {salesStats.p2pDiamondTotalRevenue.toLocaleString()} 💎
                    </span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-[11px]">
                    {SEASONS_ORDER.map((s) => {
                      const b = salesStats.p2pDiamondBySeason[s] || { qty: 0, revenue: 0 };
                      return (
                        <div key={`pd_${s}`} className="rounded-lg bg-white border border-[#bae6fd] p-2">
                          <div className="font-extrabold text-[#0369a1]">{translateSeason(language, s)}</div>
                          <div className="font-black tabular-nums">{b.qty.toLocaleString()} item</div>
                          <div className="text-[10px] font-bold text-[#0284c7] tabular-nums">{b.revenue.toLocaleString()} 💎</div>
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex items-center justify-between pt-1 border-t border-[#bae6fd] text-xs font-black text-[#0c4a6e]">
                    <span>{t(language, 'details.totalSold')} (P2P User)</span>
                    <span className="tabular-nums text-[#0284c7]">
                      {salesStats.p2pDiamondTotalQty.toLocaleString()} item · 💎 {salesStats.p2pDiamondTotalRevenue.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </DraggableWindow>
      )}

      {/* Minimal In-World Fishing 3-Strike Green-Zone Bar (ZERO info popup, NO luck/wait stats shown!) */}
      {fishingBar?.active && (
        <div
          className={`fixed left-1/2 -translate-x-1/2 z-40 pointer-events-auto flex flex-col items-center gap-2 ${
            showMobileControls ? 'bottom-40' : 'bottom-16'
          }`}
        >
          {fishingBar.phase === 'bite' || fishingBar.phase === 'reeling' ? (
            <div className="w-[min(88vw,340px)] rounded-2xl border-2 border-[#f5cc74] bg-[#1e1b18]/92 px-3.5 py-2.5 shadow-2xl space-y-2">
              <div className="flex items-center justify-between text-[11px] font-black text-[#fef7e6]">
                <span className="flex items-center gap-1.5">
                  <span>🎣</span>
                  <span>{language === 'id' ? 'Ikan Menyambar! Tekan SPACE' : 'Fish Bite! Press SPACE'}</span>
                </span>
                <div className="flex items-center gap-1">
                  {Array.from({ length: fishingBar.strikesRequired }, (_, idx) => (
                    <span
                      key={idx}
                      className={`w-2.5 h-2.5 rounded-full border ${
                        idx < fishingBar.strikesHit
                          ? 'bg-[#22c55e] border-[#86efac]'
                          : 'bg-white/15 border-white/40'
                      }`}
                    />
                  ))}
                </div>
              </div>
              <div className="relative h-5 rounded-full bg-[#334155] border border-white/25 overflow-hidden">
                <div
                  className="absolute inset-y-0 bg-[#22c55e] border-x border-[#bbf7d0]"
                  style={{
                    left: `${fishingBar.zoneStartPct}%`,
                    width: `${fishingBar.zoneWidthPct}%`,
                  }}
                />
                <div
                  className="absolute top-0 bottom-0 w-2 -ml-1 rounded-full bg-[#fde047] shadow-[0_0_8px_#fde047]"
                  style={{ left: `${fishingBar.cursorPct}%` }}
                />
              </div>
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => onFishingStrike?.()}
                  className="flex-1 py-1.5 rounded-xl bg-[#22c55e] hover:bg-[#16a34a] text-[#052e16] font-black text-xs cursor-pointer"
                >
                  [SPACE] {language === 'id' ? 'Tarik Kail!' : 'Strike Now!'}
                </button>
                <button
                  type="button"
                  onClick={() => onFishingCancel?.()}
                  className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 font-bold text-[11px] cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => onFishingCancel?.()}
              className="px-3 py-1 rounded-xl bg-[#1e1b18]/80 border border-[#c89d54]/70 text-[#fef7e6] text-[11px] font-bold shadow cursor-pointer"
            >
              🎣 {language === 'id' ? 'Menunggu sambaran... (gerak / klik untuk batal)' : 'Waiting for a bite... (move / click to cancel)'}
            </button>
          )}
        </div>
      )}

      {/* Separated Contextual Action Prompts */}
      {nearbyPrompt && !fishingBar?.active && (
        <div
          className={`fixed left-1/2 -translate-x-1/2 pointer-events-auto flex flex-wrap items-center justify-center gap-2 ${
            showMobileControls ? 'bottom-36' : 'bottom-6'
          }`}
        >
          {nearbyPrompt.social && (
            <button
              type="button"
              onClick={() => onTriggerAction('social')}
              className="px-3.5 py-2 rounded-2xl bg-[#683e1f] hover:bg-[#4b2d16] text-[#fef7e6] text-xs font-extrabold shadow-lg border-2 border-[#e5c17d] flex items-center gap-2 cursor-pointer"
            >
              <span className="px-1.5 py-0.5 rounded bg-[#f2cf7e] text-[#3c2310] text-[10px] font-black">
                {socialKeyLabel}
              </span>
              <span>{nearbyPrompt.social.label}</span>
            </button>
          )}
          {nearbyPrompt.execute && (
            <button
              type="button"
              onClick={() => onTriggerAction('execute')}
              className="px-3.5 py-2 rounded-2xl bg-[#3a6b2c] hover:bg-[#2d5422] text-[#fef7e6] text-xs font-extrabold shadow-lg border-2 border-[#e5c17d] flex items-center gap-2 cursor-pointer"
            >
              <span className="px-1.5 py-0.5 rounded bg-[#f7eedc] text-[#214417] text-[10px] font-black">
                {executeKeyLabel}
              </span>
              <span>{nearbyPrompt.execute.label}</span>
            </button>
          )}
        </div>
      )}

      {/* Customizable Mobile Virtual Analog Thumbstick & Proportional Action Controls */}
      {showMobileControls && (() => {
        const activeLayout: CustomMobileGamepadLayout =
          customGamepadLayout || mobileCtrl.defaultLayout || DEFAULT_MOBILE_GAMEPAD_LAYOUT;
        const scaleMult = Math.max(0.75, Math.min(1.4, mobileCtrl.buttonScale || 1));
        const elems = activeLayout.elements;
        const analogCfg = elems.analog;
        const jumpCfg = elems.jump;
        const sprintCfg = elems.sprint;
        const actionCfg = elems.action;
        const toolCfg = elems.tool;
        const interactCfg = elems.interact;
        const analogSize = Math.round(
          Math.max(
            mobileCtrl.minAnalogSizePx || 88,
            Math.min(mobileCtrl.maxAnalogSizePx || 180, (analogCfg.sizePx || mobileCtrl.joystickSizePx || 124) * scaleMult)
          )
        );
        const btnSize = (raw: number) =>
          Math.round(
            Math.max(
              mobileCtrl.minButtonSizePx || 38,
              Math.min(mobileCtrl.maxButtonSizePx || 96, raw * scaleMult)
            )
          );

        return (
          <>
            {/* Analog Thumbstick */}
            {analogCfg.visible !== false && (
              <div
                ref={joystickRef}
                style={{
                  left: `${analogCfg.xPct}%`,
                  top: `${analogCfg.yPct}%`,
                  width: `${analogSize}px`,
                  height: `${analogSize}px`,
                  opacity: analogCfg.opacity ?? 0.88,
                  transform: 'translate(-50%, -50%)',
                }}
                className={`fixed z-40 pointer-events-auto rounded-full border-2 shadow-2xl touch-none select-none transition-colors ${
                  joystickActive
                    ? 'border-[#f5cc74] bg-[#24160b]/60 ring-4 ring-[#f5cc74]/25'
                    : 'border-[#e5c17d]/85 bg-[#24160b]/40'
                }`}
                onPointerDown={(e) => {
                  joystickPointer.current = e.pointerId;
                  setJoystickActive(true);
                  e.currentTarget.setPointerCapture(e.pointerId);
                  updateJoystick(e.clientX, e.clientY);
                }}
                onPointerMove={(e) => {
                  if (joystickPointer.current === e.pointerId) updateJoystick(e.clientX, e.clientY);
                }}
                onPointerUp={(e) => {
                  if (joystickPointer.current !== e.pointerId) return;
                  resetJoystick();
                }}
                onPointerCancel={(e) => {
                  if (joystickPointer.current !== e.pointerId) return;
                  resetJoystick();
                }}
                onLostPointerCapture={() => {
                  resetJoystick();
                }}
              >
                <div className="absolute inset-2.5 rounded-full border border-dashed border-[#f5cc74]/40 pointer-events-none" />
                <div
                  style={{
                    transform: `translate(${knobOffset.x}px, ${knobOffset.y}px)`,
                  }}
                  className={`absolute left-1/2 top-1/2 -ml-5 -mt-5 w-10 h-10 rounded-full border-2 shadow-lg pointer-events-none transition-transform duration-75 ${
                    joystickActive
                      ? 'bg-[#f5cc74] border-[#3d2412] scale-105'
                      : 'bg-[#d9a95b]/90 border-[#4b2d16]'
                  }`}
                />
              </div>
            )}

            {/* Interact Button (Talk / E) */}
            {interactCfg.visible !== false && (
              <button
                type="button"
                style={{
                  left: `${interactCfg.xPct}%`,
                  top: `${interactCfg.yPct}%`,
                  width: `${btnSize(interactCfg.sizePx)}px`,
                  height: `${btnSize(interactCfg.sizePx)}px`,
                  opacity: interactCfg.opacity ?? 0.92,
                  transform: `translate(-50%, -50%)${pressedAction === 'social' ? ' scale(0.9)' : ''}`,
                }}
                onPointerDown={(e) => {
                  e.preventDefault();
                  triggerPressFeedback('social');
                  onTriggerAction('social');
                }}
                className={`fixed z-40 pointer-events-auto touch-none select-none rounded-full bg-[#683e1f]/95 text-[#fef7e6] font-black text-xs shadow-lg border-2 border-[#e5c17d] transition-transform flex items-center justify-center ${
                  pressedAction === 'social' ? 'ring-4 ring-[#f5cc74]/60' : ''
                }`}
              >
                {socialKeyLabel}
              </button>
            )}

            {/* Action Button (Execute / F) */}
            {actionCfg.visible !== false && (
              <button
                type="button"
                style={{
                  left: `${actionCfg.xPct}%`,
                  top: `${actionCfg.yPct}%`,
                  width: `${btnSize(actionCfg.sizePx)}px`,
                  height: `${btnSize(actionCfg.sizePx)}px`,
                  opacity: actionCfg.opacity ?? 0.92,
                  transform: `translate(-50%, -50%)${pressedAction === 'execute' ? ' scale(0.9)' : ''}`,
                }}
                onPointerDown={(e) => {
                  e.preventDefault();
                  triggerPressFeedback('execute');
                  onTriggerAction('execute');
                }}
                className={`fixed z-40 pointer-events-auto touch-none select-none rounded-full bg-[#3a6b2c]/95 text-[#fef7e6] font-black text-xs shadow-lg border-2 border-[#e5c17d] transition-transform flex items-center justify-center ${
                  pressedAction === 'execute' ? 'ring-4 ring-[#86efac]/60' : ''
                }`}
              >
                {executeKeyLabel}
              </button>
            )}

            {/* Sprint Button */}
            {onSprintToggle && sprintCfg.visible !== false && (
              <button
                type="button"
                style={{
                  left: `${sprintCfg.xPct}%`,
                  top: `${sprintCfg.yPct}%`,
                  width: `${btnSize(sprintCfg.sizePx)}px`,
                  height: `${btnSize(sprintCfg.sizePx)}px`,
                  opacity: sprintCfg.opacity ?? 0.92,
                  transform: `translate(-50%, -50%)${pressedAction === 'sprint' ? ' scale(0.9)' : mobileSprintActive ? ' scale(1.05)' : ''}`,
                }}
                onPointerDown={(e) => {
                  e.preventDefault();
                  triggerPressFeedback('sprint');
                  onSprintToggle();
                }}
                className={`fixed z-40 pointer-events-auto touch-none select-none rounded-full font-black text-[10px] shadow-xl border-2 transition-all flex items-center justify-center ${
                  mobileSprintActive
                    ? 'bg-[#15803d] text-white border-[#86efac] ring-4 ring-[#4ade80]/50'
                    : 'bg-[#4b382a]/90 text-[#fef7e6] border-[#d3bc92]'
                }`}
              >
                {t(language, 'hud.btnRun')}
              </button>
            )}

            {/* Tool / Dash Button */}
            {onDash && toolCfg.visible !== false && (
              <button
                type="button"
                style={{
                  left: `${toolCfg.xPct}%`,
                  top: `${toolCfg.yPct}%`,
                  width: `${btnSize(toolCfg.sizePx)}px`,
                  height: `${btnSize(toolCfg.sizePx)}px`,
                  opacity: toolCfg.opacity ?? 0.92,
                  transform: `translate(-50%, -50%)${pressedAction === 'dash' ? ' scale(0.9)' : ''}`,
                }}
                onPointerDown={(e) => {
                  e.preventDefault();
                  triggerPressFeedback('dash');
                  onDash();
                }}
                className={`fixed z-40 pointer-events-auto touch-none select-none rounded-full bg-[#286b9b]/95 text-white font-black text-[10px] shadow-xl border-2 border-[#a9d8ef] transition-transform flex items-center justify-center ${
                  pressedAction === 'dash' ? 'ring-4 ring-sky-300/70 brightness-125' : ''
                }`}
              >
                {t(language, 'hud.btnDash')}
              </button>
            )}

            {/* Jump Button */}
            {onJump && jumpCfg.visible !== false && (
              <button
                type="button"
                style={{
                  left: `${jumpCfg.xPct}%`,
                  top: `${jumpCfg.yPct}%`,
                  width: `${btnSize(jumpCfg.sizePx)}px`,
                  height: `${btnSize(jumpCfg.sizePx)}px`,
                  opacity: jumpCfg.opacity ?? 0.94,
                  transform: `translate(-50%, -50%)${pressedAction === 'jump' ? ' scale(0.9)' : ''}`,
                }}
                onPointerDown={(e) => {
                  e.preventDefault();
                  triggerPressFeedback('jump');
                  onJump();
                }}
                onPointerUp={() => {
                  onJumpRelease?.();
                }}
                onPointerCancel={() => {
                  onJumpRelease?.();
                }}
                className={`fixed z-40 pointer-events-auto touch-none select-none rounded-full bg-[#b8711e]/95 text-[#fef7e6] font-black text-[11px] shadow-xl border-2 border-[#f5cc74] transition-transform flex items-center justify-center ${
                  pressedAction === 'jump' ? 'ring-4 ring-amber-300/75 brightness-125' : ''
                }`}
              >
                {t(language, 'hud.btnJump')}
              </button>
            )}
          </>
        );
      })()}
    </div>
  );
};
