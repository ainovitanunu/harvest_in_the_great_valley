import React, { useRef, useState } from 'react';
import { Move, RotateCcw, Save, Sliders, Trash2 } from 'lucide-react';
import type {
  CustomMobileGamepadLayout,
  Language,
  MobileControlElementId,
  MobileControlsConfig,
  MobileGamepadPreset,
} from '../game/types';
import { DEFAULT_MOBILE_GAMEPAD_LAYOUT } from '../game/data/gameRuntimeConfig';
import { DraggableWindow } from './DraggableWindow';

interface MobileGamepadEditorProps {
  language: Language;
  layout: CustomMobileGamepadLayout;
  presets: MobileGamepadPreset[];
  boundsConfig: MobileControlsConfig;
  onSaveLayout: (layout: CustomMobileGamepadLayout) => void;
  onSavePresets: (presets: MobileGamepadPreset[]) => void;
  onClose: () => void;
}

const ELEMENT_META: Record<
  MobileControlElementId,
  { label: string; short: string; color: string; isAnalog?: boolean }
> = {
  analog: { label: 'Analog Joystick', short: 'ANALOG', color: '#475569', isAnalog: true },
  jump: { label: 'Jump', short: 'Jump', color: '#d97706' },
  sprint: { label: 'Sprint / Run', short: 'Run', color: '#334155' },
  action: { label: 'Action (F)', short: 'F', color: '#16a34a' },
  tool: { label: 'Tool / Dash', short: 'Tool', color: '#0284c7' },
  interact: { label: 'Interact (E)', short: 'E', color: '#78350f' },
};

const BUILTIN_PRESETS: MobileGamepadPreset[] = [
  {
    id: 'builtin_default',
    name: 'Default Ergonomic',
    layout: DEFAULT_MOBILE_GAMEPAD_LAYOUT,
  },
  {
    id: 'builtin_compact',
    name: 'Compact Screen',
    layout: {
      presetName: 'Compact Screen',
      elements: {
        analog: { xPct: 12, yPct: 79, sizePx: 108, opacity: 0.82 },
        jump: { xPct: 91, yPct: 83, sizePx: 58, opacity: 0.88 },
        sprint: { xPct: 76, yPct: 86, sizePx: 46, opacity: 0.82 },
        tool: { xPct: 83, yPct: 85, sizePx: 46, opacity: 0.85 },
        interact: { xPct: 82, yPct: 72, sizePx: 46, opacity: 0.85 },
        action: { xPct: 91, yPct: 70, sizePx: 48, opacity: 0.88 },
      },
    },
  },
  {
    id: 'builtin_lefthand',
    name: 'Left-Handed Mirror',
    layout: {
      presetName: 'Left-Handed Mirror',
      elements: {
        analog: { xPct: 86, yPct: 76, sizePx: 126, opacity: 0.88 },
        jump: { xPct: 9, yPct: 81, sizePx: 68, opacity: 0.94 },
        sprint: { xPct: 26, yPct: 85, sizePx: 54, opacity: 0.9 },
        tool: { xPct: 18, yPct: 83, sizePx: 54, opacity: 0.92 },
        interact: { xPct: 19, yPct: 68, sizePx: 54, opacity: 0.92 },
        action: { xPct: 9, yPct: 66, sizePx: 56, opacity: 0.94 },
      },
    },
  },
];

export const MobileGamepadEditor: React.FC<MobileGamepadEditorProps> = ({
  language,
  layout,
  presets,
  boundsConfig,
  onSaveLayout,
  onSavePresets,
  onClose,
}) => {
  const stageRef = useRef<HTMLDivElement>(null);
  const [draft, setDraft] = useState<CustomMobileGamepadLayout>(() => ({
    presetName: layout.presetName || 'Custom',
    elements: {
      analog: { ...layout.elements.analog },
      jump: { ...layout.elements.jump },
      sprint: { ...layout.elements.sprint },
      action: { ...layout.elements.action },
      tool: { ...layout.elements.tool },
      interact: { ...layout.elements.interact },
    },
  }));
  const [selectedId, setSelectedId] = useState<MobileControlElementId>('analog');
  const [presetInput, setPresetInput] = useState('');
  const [draggingId, setDraggingId] = useState<MobileControlElementId | null>(null);

  const minAnalog = boundsConfig.minAnalogSizePx ?? 88;
  const maxAnalog = boundsConfig.maxAnalogSizePx ?? 176;
  const minBtn = boundsConfig.minButtonSizePx ?? 42;
  const maxBtn = boundsConfig.maxButtonSizePx ?? 96;

  const isSelectedAnalog = selectedId === 'analog';
  const minSize = isSelectedAnalog ? minAnalog : minBtn;
  const maxSize = isSelectedAnalog ? maxAnalog : maxBtn;
  const sel = draft.elements[selectedId];

  const updateSelected = (patch: Partial<typeof sel>) => {
    setDraft((prev) => ({
      ...prev,
      elements: {
        ...prev.elements,
        [selectedId]: {
          ...prev.elements[selectedId],
          ...patch,
        },
      },
    }));
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!draggingId || !stageRef.current) return;
    const rect = stageRef.current.getBoundingClientRect();
    const xPct = Math.max(5, Math.min(95, ((e.clientX - rect.left) / rect.width) * 100));
    const yPct = Math.max(12, Math.min(92, ((e.clientY - rect.top) / rect.height) * 100));
    setDraft((prev) => ({
      ...prev,
      elements: {
        ...prev.elements,
        [draggingId]: {
          ...prev.elements[draggingId],
          xPct: Math.round(xPct * 10) / 10,
          yPct: Math.round(yPct * 10) / 10,
        },
      },
    }));
  };

  const handleApplyPreset = (p: MobileGamepadPreset) => {
    setDraft({
      presetName: p.name,
      elements: {
        analog: { ...p.layout.elements.analog },
        jump: { ...p.layout.elements.jump },
        sprint: { ...p.layout.elements.sprint },
        action: { ...p.layout.elements.action },
        tool: { ...p.layout.elements.tool },
        interact: { ...p.layout.elements.interact },
      },
    });
  };

  const handleSaveCustomPreset = () => {
    const cleanName = presetInput.trim() || `Custom ${presets.length + 1}`;
    const nextPreset: MobileGamepadPreset = {
      id: `custom_${Date.now()}`,
      name: cleanName,
      layout: {
        presetName: cleanName,
        elements: { ...draft.elements },
      },
    };
    onSavePresets([...presets, nextPreset]);
    setDraft((prev) => ({ ...prev, presetName: cleanName }));
    setPresetInput('');
  };

  const handleResetDefault = () => {
    const base = boundsConfig.defaultLayout || DEFAULT_MOBILE_GAMEPAD_LAYOUT;
    setDraft({
      presetName: base.presetName || 'Default',
      elements: {
        analog: { ...base.elements.analog },
        jump: { ...base.elements.jump },
        sprint: { ...base.elements.sprint },
        action: { ...base.elements.action },
        tool: { ...base.elements.tool },
        interact: { ...base.elements.interact },
      },
    });
  };

  const isId = language === 'id';

  return (
    <DraggableWindow
      windowId="mobile_gamepad_editor"
      centerOnMount
      title={isId ? 'Pengaturan Layout Gamepad Mobile' : 'Mobile Gamepad Layout Editor'}
      icon={<Sliders className="w-4 h-4 text-[#f5cc74]" />}
      widthClass="w-[min(95vw,760px)]"
      headerAccent="walnut"
      zIndexClass="z-[70]"
      onClose={onClose}
    >
      <div className="p-4 space-y-3 select-none" style={{ color: 'var(--hv-text)' }}>
        {/* Action Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="text-xs font-semibold opacity-85 flex items-center gap-1.5">
            <Move className="w-3.5 h-3.5" style={{ color: 'var(--hv-accent)' }} />
            <span>
              {isId
                ? 'Seret analog & tombol pada pratinjau layar di bawah, lalu simpan.'
                : 'Drag the analog stick & buttons on the screen preview below, then save.'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleResetDefault}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border cursor-pointer"
              style={{
                backgroundColor: 'var(--hv-surface-alt)',
                borderColor: 'var(--hv-border-soft)',
                color: 'var(--hv-text)',
              }}
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
            <button
              type="button"
              onClick={() => {
                onSaveLayout(draft);
                onClose();
              }}
              className="gv-btn-primary flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-extrabold cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{isId ? 'Simpan Layout' : 'Save Layout'}</span>
            </button>
          </div>
        </div>

        {/* Interactive Scaled Screen Preview Stage */}
        <div
          ref={stageRef}
          onPointerMove={handlePointerMove}
          onPointerUp={() => setDraggingId(null)}
          onPointerCancel={() => setDraggingId(null)}
          className="relative w-full aspect-[16/9] min-h-[240px] max-h-[340px] rounded-xl border-2 overflow-hidden touch-none"
          style={{
            borderColor: 'var(--hv-border)',
            backgroundColor: 'var(--hv-app-bg)',
            backgroundImage:
              'linear-gradient(to right, rgba(148,163,184,0.14) 1px, transparent 1px), linear-gradient(to bottom, rgba(148,163,184,0.14) 1px, transparent 1px)',
            backgroundSize: '32px 32px',
          }}
        >
          <div
            className="absolute top-2 left-2.5 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded pointer-events-none"
            style={{ backgroundColor: 'var(--hv-pill-bg)', color: 'var(--hv-pill-text)' }}
          >
            {isId ? 'Pratinjau Layar 16:9' : '16:9 Screen Preview'}
          </div>

          {(Object.keys(ELEMENT_META) as MobileControlElementId[]).map((id) => {
            const item = draft.elements[id];
            const meta = ELEMENT_META[id];
            const isSelected = selectedId === id;
            const previewSize = Math.round(item.sizePx * 0.62);
            return (
              <div
                key={id}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  (e.currentTarget as HTMLDivElement).setPointerCapture(e.pointerId);
                  setSelectedId(id);
                  setDraggingId(id);
                }}
                style={{
                  position: 'absolute',
                  left: `${item.xPct}%`,
                  top: `${item.yPct}%`,
                  width: `${previewSize}px`,
                  height: `${previewSize}px`,
                  transform: 'translate(-50%, -50%)',
                  opacity: item.opacity,
                  backgroundColor: meta.isAnalog ? 'rgba(30, 41, 59, 0.72)' : meta.color,
                  border: isSelected ? '3px solid #facc15' : '2px solid rgba(255,255,255,0.75)',
                  boxShadow: isSelected ? '0 0 0 5px rgba(250, 204, 21, 0.28)' : '0 4px 12px rgba(0,0,0,0.32)',
                }}
                className="rounded-full flex flex-col items-center justify-center cursor-grab active:cursor-grabbing text-white font-bold select-none"
              >
                {meta.isAnalog ? (
                  <div
                    className="rounded-full bg-amber-400/95 border-2 border-white flex items-center justify-center text-[9px] font-extrabold text-slate-900"
                    style={{
                      width: `${Math.round(previewSize * 0.44)}px`,
                      height: `${Math.round(previewSize * 0.44)}px`,
                    }}
                  >
                    JOY
                  </div>
                ) : (
                  <span className="text-[10px] tracking-wide">{meta.short}</span>
                )}
              </div>
            );
          })}
        </div>

        {/* Selected Control Inspector */}
        <div
          className="rounded-xl border p-3 space-y-2.5"
          style={{
            backgroundColor: 'var(--hv-surface-card)',
            borderColor: 'var(--hv-border-soft)',
          }}
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-extrabold uppercase tracking-wide">
                {ELEMENT_META[selectedId].label}
              </span>
              <span className="text-[11px] opacity-75 tabular-nums">
                ({Math.round(sel.xPct)}%, {Math.round(sel.yPct)}%)
              </span>
            </div>
            <div className="flex flex-wrap gap-1">
              {(Object.keys(ELEMENT_META) as MobileControlElementId[]).map((id) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setSelectedId(id)}
                  className="px-2 py-0.5 rounded-md text-[11px] font-bold border cursor-pointer transition-colors"
                  style={{
                    backgroundColor: selectedId === id ? 'var(--hv-accent)' : 'var(--hv-surface-alt)',
                    borderColor: selectedId === id ? 'var(--hv-accent-strong)' : 'var(--hv-border-soft)',
                    color: selectedId === id ? '#ffffff' : 'var(--hv-text)',
                  }}
                >
                  {ELEMENT_META[id].short}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <label className="flex flex-col gap-1">
              <div className="flex justify-between font-bold">
                <span>{isId ? 'Ukuran' : 'Size'}</span>
                <span className="tabular-nums">{Math.round(sel.sizePx)} px</span>
              </div>
              <input
                type="range"
                min={minSize}
                max={maxSize}
                step={2}
                value={Math.max(minSize, Math.min(maxSize, sel.sizePx))}
                onChange={(e) => updateSelected({ sizePx: Number(e.target.value) })}
                className="accent-amber-600 cursor-pointer"
              />
            </label>

            <label className="flex flex-col gap-1">
              <div className="flex justify-between font-bold">
                <span>{isId ? 'Transparansi' : 'Opacity'}</span>
                <span className="tabular-nums">{Math.round(sel.opacity * 100)}%</span>
              </div>
              <input
                type="range"
                min={25}
                max={100}
                step={5}
                value={Math.round(sel.opacity * 100)}
                onChange={(e) => updateSelected({ opacity: Number(e.target.value) / 100 })}
                className="accent-amber-600 cursor-pointer"
              />
            </label>
          </div>

          {/* Preset Bar */}
          <div
            className="pt-2.5 border-t flex flex-wrap items-center gap-1.5"
            style={{ borderColor: 'var(--hv-border-soft)' }}
          >
            <span className="text-[11px] font-extrabold opacity-80 mr-1">Presets:</span>
            {[...BUILTIN_PRESETS, ...presets].map((p) => (
              <div key={p.id} className="inline-flex items-center gap-0.5">
                <button
                  type="button"
                  onClick={() => handleApplyPreset(p)}
                  className="px-2 py-1 rounded-md text-[11px] font-bold border cursor-pointer transition-colors"
                  style={{
                    backgroundColor: draft.presetName === p.name ? 'var(--hv-accent)' : 'var(--hv-surface-alt)',
                    color: draft.presetName === p.name ? '#ffffff' : 'var(--hv-text)',
                    borderColor: 'var(--hv-border-soft)',
                  }}
                >
                  {p.name}
                </button>
                {!p.id.startsWith('builtin_') && (
                  <button
                    type="button"
                    onClick={() => onSavePresets(presets.filter((x) => x.id !== p.id))}
                    className="p-1 text-rose-500 hover:text-rose-400 cursor-pointer"
                    title={isId ? 'Hapus preset' : 'Delete preset'}
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>
            ))}
            <div className="flex items-center gap-1 ml-auto">
              <input
                type="text"
                value={presetInput}
                onChange={(e) => setPresetInput(e.target.value)}
                placeholder={isId ? 'Nama preset...' : 'Preset name...'}
                className="px-2 py-1 rounded-md text-[11px] border w-28"
                style={{
                  backgroundColor: 'var(--hv-surface-alt)',
                  borderColor: 'var(--hv-border-soft)',
                  color: 'var(--hv-text)',
                }}
              />
              <button
                type="button"
                onClick={handleSaveCustomPreset}
                className="gv-btn-primary px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer"
              >
                + {isId ? 'Simpan' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </DraggableWindow>
  );
};
