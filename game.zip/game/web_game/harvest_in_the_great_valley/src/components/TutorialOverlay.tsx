import React from 'react';
import { ChevronRight, SkipForward } from 'lucide-react';

export const TUTORIAL_STEPS = [
  {
    title: '1. Welcome to Great Valley!',
    body: 'Move with WASD or Arrow keys, press Space to Jump, and hold left-mouse drag to rotate your camera freely (camera smoothly centers behind you if steering left/right).',
  },
  {
    title: '2. 24-Slot Bag, Master Slot & 1–6 Shortcuts',
    body: 'Press I or click Bag to open your 24-slot pack. Drag tools or seeds into the Master Hand Slot, clear it to walk empty-handed, or press 1–6 to quick-swap tools!',
  },
  {
    title: '3. Natural Farm Clearing, Mining & Fishing',
    body: 'Clear wild weeds (Sickle), roots/saplings/trees (Axe), and rocks (Hammer) on your farm—unattended weeds grow into full trees! Mine ore in Mountain Cave or fish at the River Dock & Ocean Pier.',
  },
  {
    title: '4. Village Social (E), Upgrades & Marriage',
    body: 'Press E near villagers to chat/gift or open Private Chat with other players. Visit Oliver to upgrade Farmhouse, Barn & Coop to Lv.3 before proposing!',
  },
];

interface TutorialOverlayProps {
  step: number;
  onNext: () => void;
  onSkip: () => void;
}

export const TutorialOverlay: React.FC<TutorialOverlayProps> = ({ step, onNext, onSkip }) => {
  const item = TUTORIAL_STEPS[step];
  if (!item) return null;

  return (
    <div className="fixed top-3 right-3 z-30 max-w-xs w-full rounded-2xl border-3 border-[#c59a45] bg-[#f7eedc] p-4 shadow-xl text-[#2b1a0e]">
      <div className="flex items-center justify-between mb-1">
        <span className="text-[11px] font-black uppercase tracking-wider text-[#9e5316]">
          Farmer’s Guide ({step + 1}/{TUTORIAL_STEPS.length})
        </span>
        <button
          type="button"
          onClick={onSkip}
          className="text-[11px] font-bold text-[#6e4624] hover:text-[#2b1a0e] flex items-center gap-1 cursor-pointer"
        >
          <SkipForward className="w-3 h-3" /> Skip
        </button>
      </div>
      <h3 className="font-extrabold text-sm mb-1">{item.title}</h3>
      <p className="text-xs text-[#5c3c22] leading-relaxed mb-3">{item.body}</p>
      <button
        type="button"
        onClick={onNext}
        className="w-full py-2 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] text-white font-bold text-xs flex items-center justify-center gap-1 cursor-pointer"
      >
        {step >= TUTORIAL_STEPS.length - 1 ? 'Start Farming!' : 'Next'}
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
};
