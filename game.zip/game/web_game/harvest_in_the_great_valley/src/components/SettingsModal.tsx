import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Bell,
  Clock,
  Gamepad2,
  Globe,
  Home,
  Keyboard,
  Laptop,
  LogOut,
  Monitor,
  Palette,
  Settings,
  ShieldAlert,
  Smartphone,
  Sparkles,
  Trash2,
  UserCheck,
  Video,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { DEFAULT_KEYBINDINGS } from '../game/data/itemsAndCrops';
import { DEFAULT_MOBILE_GAMEPAD_LAYOUT, MOBILE_CONTROLS_CONFIG } from '../game/data/gameRuntimeConfig';
import { t } from '../game/i18n';
import { localizationManager, SUPPORTED_LANGUAGES } from '../game/localizationManager';
import { themeManager } from '../game/themeManager';
import type {
  CameraPovMode,
  CustomMobileGamepadLayout,
  DeviceControlMode,
  GameSettings,
  GraphicsQuality,
  KeyBindings,
  Language,
  MobileControlsConfig,
  MobileGamepadPreset,
  NotificationSettings,
  ThemeMode,
} from '../game/types';
import type { DeviceProfile } from '../services/callManager';
import { DraggableWindow } from './DraggableWindow';
import { MobileGamepadEditor } from './MobileGamepadEditor';

interface SettingsModalProps {
  settings: GameSettings;
  keyBindings: KeyBindings;
  gamepadStatus: { connected: boolean; name?: string };
  deviceProfile?: DeviceProfile;
  mobileControlsConfig?: MobileControlsConfig;
  firebaseUserEmail?: string | null;
  isInGame?: boolean;
  notifSettings?: NotificationSettings;
  lastResetHomeAt?: number;
  onUpdateSettings: (next: GameSettings) => void;
  onUpdateKeyBindings: (next: KeyBindings) => void;
  onToggleNotif?: (key: keyof NotificationSettings) => void;
  onResetToHome?: () => void;
  onExitGame?: () => void;
  onLogout?: () => Promise<void>;
  onDeleteAccount?: (confirmEmail: string) => Promise<void>;
  onClose: () => void;
}

const RESET_HOME_COOLDOWN_MS = 10 * 60 * 1000;

const KEY_LABELS: Array<[keyof KeyBindings, string, string]> = [
  ['forward', 'Move Forward', 'Jalan Maju'],
  ['backward', 'Move Backward', 'Jalan Mundur'],
  ['left', 'Move Left', 'Geser Kiri'],
  ['right', 'Move Right', 'Geser Kanan'],
  ['sprint', 'Run / Sprint (Default: Shift)', 'Lari / Sprint (Default: Shift)'],
  ['dash', 'Dash (Default: R)', 'Dash (Default: R)'],
  ['jump', 'Jump', 'Lompat'],
  ['social', 'Talk / Private Chat', 'Bicara / Chat Privat'],
  ['execute', 'Execute Tool / Shop', 'Gunakan Alat / Toko'],
  ['inventory', 'Open Bag', 'Buka Tas'],
  ['chat', 'Open Chat', 'Buka Chat'],
  ['openMenu', 'Open Menu / Book', 'Buka Menu / Buku'],
  ['openSettings', 'Open Settings', 'Buka Pengaturan'],
  ['toolSlot1', 'Tool Shortcut 1', 'Pintasan Alat 1'],
  ['toolSlot2', 'Tool Shortcut 2', 'Pintasan Alat 2'],
  ['toolSlot3', 'Tool Shortcut 3', 'Pintasan Alat 3'],
  ['toolSlot4', 'Tool Shortcut 4', 'Pintasan Alat 4'],
  ['toolSlot5', 'Tool Shortcut 5', 'Pintasan Alat 5'],
  ['toolSlot6', 'Tool Shortcut 6', 'Pintasan Alat 6'],
];

function prettyKeyCode(code: string): string {
  if (!code) return '-';
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  if (code === 'ShiftLeft' || code === 'ShiftRight') return 'Shift';
  return code;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  keyBindings,
  gamepadStatus,
  deviceProfile,
  mobileControlsConfig = MOBILE_CONTROLS_CONFIG,
  firebaseUserEmail,
  isInGame = false,
  notifSettings,
  lastResetHomeAt = 0,
  onUpdateSettings,
  onUpdateKeyBindings,
  onToggleNotif,
  onResetToHome,
  onExitGame,
  onLogout,
  onDeleteAccount,
  onClose,
}) => {
  const lang = settings.language;
  const [section, setSection] = useState<'controls' | 'audio' | 'graphics' | 'theme' | 'language'>('controls');
  const [remappingKey, setRemappingKey] = useState<keyof KeyBindings | null>(null);
  const [gamepadEditorOpen, setGamepadEditorOpen] = useState(false);
  const [nowMs, setNowMs] = useState(() => Date.now());
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteEmailInput, setDeleteEmailInput] = useState('');
  const [deletePhraseInput, setDeletePhraseInput] = useState('');
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [accountBusy, setAccountBusy] = useState(false);

  useEffect(() => {
    if (!isInGame) return;
    const id = window.setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(id);
  }, [isInGame]);

  useEffect(() => {
    if (!remappingKey) return;
    const onCaptureKey = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.code === 'Escape') {
        setRemappingKey(null);
        return;
      }
      onUpdateKeyBindings({ ...keyBindings, [remappingKey]: e.code });
      setRemappingKey(null);
    };
    window.addEventListener('keydown', onCaptureKey, { capture: true });
    return () => window.removeEventListener('keydown', onCaptureKey, { capture: true });
  }, [remappingKey, keyBindings, onUpdateKeyBindings]);

  const cooldownRemainingMs = Math.max(0, RESET_HOME_COOLDOWN_MS - (nowMs - lastResetHomeAt));
  const cooldownMin = Math.floor(cooldownRemainingMs / 60000);
  const cooldownSec = Math.floor((cooldownRemainingMs % 60000) / 1000);

  const setAudio = (patch: Partial<GameSettings['audio']>) => {
    onUpdateSettings({
      ...settings,
      audio: { ...settings.audio, ...patch },
    });
  };

  const setGraphics = (patch: Partial<GameSettings['graphics']>) => {
    onUpdateSettings({
      ...settings,
      graphics: { ...settings.graphics, ...patch },
    });
  };

  const applyQualityPreset = (quality: GraphicsQuality) => {
    if (quality === 'low') {
      setGraphics({
        quality,
        shadows: false,
        dynamicShadows: false,
        realTimeLighting: false,
        globalIllumination: false,
        realTimeGI: false,
        rayTracing: false,
        pathTracing: false,
        renderScale: 0.75,
        weatherParticles: false,
      });
    } else if (quality === 'medium') {
      setGraphics({
        quality,
        shadows: true,
        dynamicShadows: true,
        realTimeLighting: true,
        globalIllumination: true,
        realTimeGI: false,
        rayTracing: false,
        pathTracing: false,
        renderScale: 0.88,
        weatherParticles: true,
      });
    } else if (quality === 'high') {
      setGraphics({
        quality,
        shadows: true,
        dynamicShadows: true,
        realTimeLighting: true,
        globalIllumination: true,
        realTimeGI: true,
        rayTracing: false,
        pathTracing: false,
        renderScale: 1.0,
        weatherParticles: true,
      });
    } else {
      setGraphics({
        quality: 'ultra',
        shadows: true,
        dynamicShadows: true,
        realTimeLighting: true,
        globalIllumination: true,
        realTimeGI: true,
        rayTracing: true,
        pathTracing: true,
        renderScale: 1.0,
        weatherParticles: true,
      });
    }
  };

  const setLanguage = (language: Language) => {
    localizationManager.setLanguage(language);
    onUpdateSettings({ ...settings, language });
  };

  const setTheme = (theme: ThemeMode) => {
    themeManager.setTheme(theme);
    onUpdateSettings({ ...settings, theme });
  };

  const setDeviceControlMode = (deviceControlMode: DeviceControlMode) => {
    onUpdateSettings({ ...settings, deviceControlMode });
  };

  const rawTheme: ThemeMode = settings.theme || themeManager.getTheme() || 'system';
  const currentTheme: ThemeMode = rawTheme === 'farmhouse' ? 'cozy' : rawTheme;
  const resolvedNow = themeManager.resolveTheme(currentTheme);
  const currentControlMode: DeviceControlMode = settings.deviceControlMode || 'auto';

  const tabs: Array<{ id: 'controls' | 'audio' | 'graphics' | 'theme' | 'language'; label: string; icon: React.ReactNode }> = [
    { id: 'controls', label: t(lang, 'settings.controls'), icon: <Keyboard className="w-4 h-4" /> },
    { id: 'audio', label: t(lang, 'settings.audio'), icon: <Volume2 className="w-4 h-4" /> },
    { id: 'graphics', label: t(lang, 'settings.graphics'), icon: <Monitor className="w-4 h-4" /> },
    { id: 'theme', label: t(lang, 'settings.theme'), icon: <Palette className="w-4 h-4" /> },
    { id: 'language', label: t(lang, 'settings.language'), icon: <Globe className="w-4 h-4" /> },
  ];

  const themeChoices: Array<{
    id: ThemeMode;
    title: string;
    descEn: string;
    descId: string;
    swatches: [string, string, string];
  }> = [
    {
      id: 'system',
      title: lang === 'id' ? 'Ikuti Sistem (Otomatis)' : 'Follow System (Auto)',
      descEn: `Follows your OS Light/Dark appearance strictly across all screens (active: ${resolvedNow}).`,
      descId: `Mengikuti tema Terang/Gelap perangkat di seluruh layar game termasuk login & timer Guest (aktif: ${resolvedNow === 'dark' ? 'Gelap' : 'Terang'}).`,
      swatches: ['#0f172a', '#ffffff', '#0284c7'],
    },
    {
      id: 'cozy',
      title: lang === 'id' ? 'Cozy (Kehangatan Desa)' : 'Cozy Farmhouse',
      descEn: 'Warm rustic parchment & timber palette crafted for Great Valley.',
      descId: 'Palet kayu hangat & perkamen khas Great Valley yang nyaman.',
      swatches: ['#3d2412', '#f7eedc', '#3a6b2c'],
    },
    {
      id: 'light',
      title: t(lang, 'settings.themeLight'),
      descEn: 'Crisp bright daylight surfaces with high contrast across every screen.',
      descId: 'Tampilan terang siang hari yang bersih dan kontras tinggi di seluruh layar.',
      swatches: ['#1e293b', '#ffffff', '#16a34a'],
    },
    {
      id: 'dark',
      title: t(lang, 'settings.themeDark'),
      descEn: 'Comfortable low-glare dark mode for evening farming across every panel.',
      descId: 'Mode malam gelap yang nyaman di mata di seluruh halaman & menu.',
      swatches: ['#0f172a', '#1e293b', '#22c55e'],
    },
    {
      id: 'seasonal',
      title: lang === 'id' ? 'Seasonal (Ikut Musim)' : 'Seasonal Dynamic',
      descEn: 'Automatically shifts colors to match Spring, Summer, Autumn, or Winter.',
      descId: 'Warna seluruh antarmuka berubah otomatis mengikuti musim Spring, Summer, Autumn, Winter.',
      swatches: ['#d97706', '#fef3c7', '#15803d'],
    },
  ];

  return (
    <DraggableWindow
      windowId="settings"
      centerOnMount
      title={t(lang, 'settings.title')}
      icon={<Settings className="w-5 h-5 text-[#f5cc74]" />}
      widthClass="w-[min(94vw,680px)]"
      headerAccent="walnut"
      zIndexClass="z-50"
      onClose={onClose}
    >
      {/* Section Tabs */}
      <div className="px-4 py-2.5 bg-[#efe2c6] border-b border-[#d3bc92] flex flex-wrap gap-1.5">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setSection(tab.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border cursor-pointer transition-colors ${
              section === tab.id
                ? 'bg-[#3a6b2c] text-[#fef9ed] border-[#214417]'
                : 'bg-[#fffaf0] text-[#5c3c22] border-[#d3bc92] hover:bg-[#f4e8d0]'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Body */}
      <div className="p-5 max-h-[72vh] overflow-y-auto space-y-4">
          {section === 'controls' && (
            <div className="space-y-4">
              {/* Strict Hardware & Screen Detection + Manual Mobile Mode Switch */}
              <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-3.5 space-y-3 text-xs">
                {deviceProfile && (
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#e5d3b0]">
                    <div className="space-y-0.5">
                      <span className="font-extrabold flex items-center gap-1.5 text-[#3d2412]">
                        {deviceProfile.isPhone ? (
                          <Smartphone className="w-4 h-4 text-[#3a6b2c]" />
                        ) : (
                          <Laptop className="w-4 h-4 text-[#3a6b2c]" />
                        )}
                        {deviceProfile.isPhone
                          ? lang === 'id'
                            ? 'Perangkat Terdeteksi: Handphone / Layar Sentuh'
                            : 'Detected Device: Mobile Phone / Touch'
                          : lang === 'id'
                            ? 'Perangkat Terdeteksi: Komputer / Desktop PC'
                            : 'Detected Device: Desktop Computer / PC'}
                      </span>
                      <div className="text-[10px] font-semibold text-[#6e4624]">
                        {deviceProfile.detectionReason} · {lang === 'id' ? 'Akurasi' : 'Confidence'}: {deviceProfile.detectionConfidence.toUpperCase()}
                      </div>
                    </div>
                    <span className="text-[11px] font-bold text-[#6e4624] tabular-nums">
                      {deviceProfile.width}×{deviceProfile.height} ({deviceProfile.orientation})
                    </span>
                  </div>
                )}

                <div className="space-y-1.5">
                  <div className="font-extrabold text-[#3d2412] flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-[#b8711e]" />
                    {t(lang, 'settings.mobileModeTitle')}
                  </div>
                  <p className="text-[11px] text-[#5c3c22]">
                    {lang === 'id'
                      ? 'Jika layar perangkat tidak terdeteksi otomatis, pilih Mode Mobile untuk langsung masuk Fullscreen + Analog. Gunakan tombol "Keluar Mobile" di pojok kanan atas untuk kembali ke mode browser biasa.'
                      : 'If auto-detection misses your screen, select Mobile Mode to enter Fullscreen + Analog controls. Tap "Exit Mobile" at top-right anytime to return to normal browser view.'}
                  </p>
                  <div className="grid sm:grid-cols-3 gap-2 pt-1">
                    {(
                      [
                        ['auto', t(lang, 'settings.modeAuto')],
                        ['mobile', t(lang, 'settings.modeMobile')],
                        ['desktop', t(lang, 'settings.modeDesktop')],
                      ] as const
                    ).map(([modeId, label]) => (
                      <button
                        key={modeId}
                        type="button"
                        onClick={() => setDeviceControlMode(modeId)}
                        className={`px-2.5 py-2 rounded-xl text-[11px] font-extrabold border cursor-pointer transition-colors ${
                          currentControlMode === modeId
                            ? 'bg-[#3a6b2c] text-[#fef9ed] border-[#214417]'
                            : 'bg-[#efe2c6] text-[#4b2d16] border-[#d3bc92] hover:bg-[#e5d3b0]'
                        }`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Custom Mobile Gamepad Editor Launcher */}
                <div className="pt-2.5 border-t border-[#e5d3b0] flex flex-wrap items-center justify-between gap-2">
                  <div className="space-y-0.5">
                    <div className="font-extrabold text-[#3d2412] flex items-center gap-1.5">
                      <Gamepad2 className="w-3.5 h-3.5 text-[#3a6b2c]" />
                      <span>{lang === 'id' ? 'Custom Mobile Gamepad Layout' : 'Custom Mobile Gamepad Layout'}</span>
                    </div>
                    <p className="text-[11px] text-[#5c3c22]">
                      {lang === 'id'
                        ? 'Geser posisi, ubah ukuran & transparansi Analog, Jump, Sprint, Action, Tool, dan Interact serta simpan preset sendiri.'
                        : 'Drag position, resize & adjust transparency of Analog, Jump, Sprint, Action, Tool, and Interact with custom presets.'}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setGamepadEditorOpen(true)}
                    className="px-3.5 py-2 rounded-xl bg-[#b8711e] hover:bg-[#965a14] text-[#fef7e6] text-xs font-extrabold cursor-pointer shrink-0 shadow"
                  >
                    {lang === 'id' ? '🎛️ Atur Layout Gamepad' : '🎛️ Customize Gamepad'}
                  </button>
                </div>
              </div>

              {/* Camera POV Mode (Lock vs Free) & Video Call Self-Camera Preview */}
              <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-3.5 space-y-3 text-xs">
                <div className="space-y-1.5">
                  <div className="font-extrabold text-[#3d2412] flex items-center justify-between gap-2">
                    <span>📷 {t(lang, 'settings.cameraPovTitle')}</span>
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-[#efe2c6] text-[#5c3c22]">
                      {(settings.povMode || 'lock') === 'lock' ? 'Lock' : 'Free'}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#5c3c22]">{t(lang, 'settings.cameraPovDesc')}</p>
                  <div className="grid grid-cols-2 gap-2 pt-0.5">
                    {(
                      [
                        ['lock', t(lang, 'settings.cameraPovLock')],
                        ['free', t(lang, 'settings.cameraPovFree')],
                      ] as Array<[CameraPovMode, string]>
                    ).map(([modeId, label]) => (
                      <button
                        key={modeId}
                        type="button"
                        onClick={() => onUpdateSettings({ ...settings, povMode: modeId })}
                        className={`px-3 py-2 rounded-xl text-[11px] font-extrabold border cursor-pointer transition-colors ${
                          (settings.povMode || 'lock') === modeId
                            ? 'bg-[#3a6b2c] text-[#fef9ed] border-[#214417]'
                            : 'bg-[#efe2c6] text-[#4b2d16] border-[#d3bc92] hover:bg-[#e5d3b0]'
                        }`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                <label className="flex items-start justify-between gap-3 pt-2.5 border-t border-[#e5d3b0] cursor-pointer">
                  <div className="space-y-0.5">
                    <div className="font-extrabold text-[#3d2412] flex items-center gap-1.5">
                      <Video className="w-3.5 h-3.5 text-[#0284c7]" />
                      <span>{t(lang, 'settings.selfCamPreviewTitle')}</span>
                    </div>
                    <p className="text-[11px] text-[#5c3c22] leading-snug">
                      {t(lang, 'settings.selfCamPreviewDesc')}
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={Boolean(settings.showSelfCameraInCall)}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, showSelfCameraInCall: e.target.checked })
                    }
                    className="mt-1 w-4 h-4 accent-[#0284c7] shrink-0 cursor-pointer"
                  />
                </label>
              </div>

              <div className="flex items-center justify-between">
                <h3 className="text-sm font-extrabold text-[#3d2412]">{t(lang, 'settings.controls')}</h3>
                <button
                  type="button"
                  onClick={() => onUpdateKeyBindings({ ...DEFAULT_KEYBINDINGS })}
                  className="px-3 py-1.5 rounded-lg bg-[#efe2c6] hover:bg-[#e5d3b0] border border-[#bfa070] text-xs font-bold cursor-pointer"
                >
                  {t(lang, 'settings.resetDefaults')}
                </button>
              </div>

              <div className="grid sm:grid-cols-2 gap-2">
                {KEY_LABELS.map(([field, labelEn, labelId]) => {
                  const isListening = remappingKey === field;
                  return (
                    <div
                      key={field}
                      className="flex items-center justify-between rounded-xl bg-[#fffaf0] border border-[#d3bc92] px-3 py-2 text-xs"
                    >
                      <span className="font-bold text-[#4b2d16]">{lang === 'id' ? labelId : labelEn}</span>
                      <button
                        type="button"
                        onClick={() => setRemappingKey(isListening ? null : field)}
                        className={`px-2.5 py-1 rounded-lg font-black text-[11px] border cursor-pointer ${
                          isListening
                            ? 'bg-[#d98a2b] text-white border-[#9e5316]'
                            : 'bg-[#efe2c6] text-[#2b1a0e] border-[#bfa070]'
                        }`}
                      >
                        {isListening ? t(lang, 'settings.pressKey') : prettyKeyCode(keyBindings[field] || '')}
                      </button>
                    </div>
                  );
                })}
              </div>

              <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-3.5 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-xs flex items-center gap-1.5">
                    <Gamepad2 className="w-4 h-4 text-[#3a6b2c]" />
                    {lang === 'id' ? 'Dukungan Gamepad / Controller' : 'Gamepad / Controller Support'}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-md text-[11px] font-extrabold ${
                      gamepadStatus.connected ? 'bg-[#dcecd1] text-[#23481a]' : 'bg-[#efe2c6] text-[#6e4624]'
                    }`}
                  >
                    {gamepadStatus.connected
                      ? lang === 'id'
                        ? 'Terhubung'
                        : 'Connected'
                      : lang === 'id'
                        ? 'Siaga'
                        : 'Standby'}
                  </span>
                </div>
                <p className="text-[11px] text-[#5c3c22]">
                  {gamepadStatus.connected
                    ? gamepadStatus.name || 'Controller'
                    : lang === 'id'
                      ? 'Hubungkan controller USB/Bluetooth. Stik Kiri: Gerak · Stik Kanan: Kamera · A: Lompat · X: Aksi · Y: Bicara · LB/RB: Lari.'
                      : 'Connect any USB or Bluetooth controller. Left Stick: Move · Right Stick: Camera · A: Jump · X: Action · Y: Talk · LB/RB: Run.'}
                </p>
              </div>
            </div>
          )}

          {section === 'audio' && (
            <div className="space-y-4">
              <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-extrabold">{t(lang, 'settings.muteAll')}</span>
                  <button
                    type="button"
                    onClick={() => setAudio({ muted: !settings.audio.muted })}
                    className="px-3.5 py-1.5 rounded-xl bg-[#efe2c6] border border-[#bfa070] text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
                  >
                    {settings.audio.muted ? (
                      <VolumeX className="w-4 h-4 text-[#a63424]" />
                    ) : (
                      <Volume2 className="w-4 h-4 text-[#3a6b2c]" />
                    )}
                    {settings.audio.muted
                      ? lang === 'id'
                        ? 'Dibisukan'
                        : 'Muted'
                      : lang === 'id'
                        ? 'Aktif'
                        : 'Active'}
                  </button>
                </div>

                {(
                  [
                    ['masterVolume', t(lang, 'settings.masterVol')],
                    ['sfxVolume', t(lang, 'settings.sfxVol')],
                    ['musicVolume', t(lang, 'settings.musicVol')],
                  ] as const
                ).map(([field, label]) => (
                  <label key={field} className="block space-y-1.5">
                    <div className="flex justify-between text-xs font-bold text-[#4b2d16]">
                      <span>{label}</span>
                      <span className="tabular-nums">{Math.round(settings.audio[field] * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={Math.round(settings.audio[field] * 100)}
                      onChange={(e) => setAudio({ [field]: Number(e.target.value) / 100 })}
                      className="w-full accent-[#3a6b2c] cursor-pointer"
                    />
                  </label>
                ))}
              </div>
            </div>
          )}

          {section === 'graphics' && (
            <div className="space-y-4">
              <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-4 space-y-4">
                <div>
                  <span className="block text-xs font-extrabold text-[#4b2d16] mb-2">
                    {t(lang, 'settings.quality')}
                  </span>
                  <div className="grid grid-cols-4 gap-2">
                    {(
                      [
                        ['low', t(lang, 'settings.qualityLow')],
                        ['medium', t(lang, 'settings.qualityMedium')],
                        ['high', t(lang, 'settings.qualityHigh')],
                        ['ultra', t(lang, 'settings.qualityUltra')],
                      ] as const
                    ).map(([q, label]) => (
                      <button
                        key={q}
                        type="button"
                        onClick={() => applyQualityPreset(q)}
                        className={`py-2 rounded-xl text-xs font-extrabold border cursor-pointer ${
                          settings.graphics.quality === q
                            ? 'bg-[#3a6b2c] text-white border-[#214417]'
                            : 'bg-[#efe2c6] text-[#4b2d16] border-[#d3bc92]'
                        }`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 6 Advanced Real-Time Lighting & Rendering Technologies */}
                <div className="space-y-2 pt-1 border-t border-[#e5d3b0]">
                  <div className="text-[11px] font-black uppercase tracking-wider text-[#6e4624] flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#b8711e]" />
                    {lang === 'id' ? 'Detail Pencahayaan & Rendering Lanjutan' : 'Advanced Lighting & Rendering Detail'}
                  </div>

                  {(
                    [
                      [
                        'realTimeLighting',
                        Boolean(settings.graphics.realTimeLighting ?? settings.graphics.quality !== 'low'),
                        t(lang, 'settings.realTimeLighting'),
                        t(lang, 'settings.realTimeLightingDesc'),
                      ],
                      [
                        'dynamicShadows',
                        Boolean(settings.graphics.dynamicShadows ?? settings.graphics.shadows),
                        t(lang, 'settings.dynamicShadows'),
                        t(lang, 'settings.dynamicShadowsDesc'),
                      ],
                      [
                        'globalIllumination',
                        Boolean(settings.graphics.globalIllumination ?? settings.graphics.quality !== 'low'),
                        t(lang, 'settings.globalIllumination'),
                        t(lang, 'settings.globalIlluminationDesc'),
                      ],
                      [
                        'realTimeGI',
                        Boolean(
                          settings.graphics.realTimeGI ??
                            (settings.graphics.quality === 'high' || settings.graphics.quality === 'ultra')
                        ),
                        t(lang, 'settings.realTimeGI'),
                        t(lang, 'settings.realTimeGIDesc'),
                      ],
                      [
                        'rayTracing',
                        Boolean(settings.graphics.rayTracing),
                        t(lang, 'settings.rayTracing'),
                        t(lang, 'settings.rayTracingDesc'),
                      ],
                      [
                        'pathTracing',
                        Boolean(settings.graphics.pathTracing),
                        t(lang, 'settings.pathTracing'),
                        t(lang, 'settings.pathTracingDesc'),
                      ],
                    ] as const
                  ).map(([field, checked, title, desc]) => (
                    <label
                      key={field}
                      className="flex items-start justify-between gap-3 rounded-xl border border-[#e5d3b0] bg-[#f9f3e4] px-3 py-2.5 cursor-pointer hover:bg-[#f2e6cf] transition-colors"
                    >
                      <div className="space-y-0.5">
                        <div className="text-xs font-extrabold text-[#2b1a0e]">{title}</div>
                        <div className="text-[10px] font-medium text-[#6e4624] leading-snug">{desc}</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={(e) => {
                          const val = e.target.checked;
                          if (field === 'dynamicShadows') {
                            setGraphics({ dynamicShadows: val, shadows: val });
                          } else {
                            setGraphics({ [field]: val });
                          }
                        }}
                        className="mt-1 w-4 h-4 accent-[#3a6b2c] shrink-0"
                      />
                    </label>
                  ))}
                </div>

                <label className="flex items-center justify-between text-xs font-bold cursor-pointer pt-1 border-t border-[#e5d3b0]">
                  <span>{t(lang, 'settings.weatherFx')}</span>
                  <input
                    type="checkbox"
                    checked={settings.graphics.weatherParticles}
                    onChange={(e) => setGraphics({ weatherParticles: e.target.checked })}
                    className="w-4 h-4 accent-[#3a6b2c]"
                  />
                </label>

                <label className="block space-y-1.5">
                  <div className="flex justify-between text-xs font-bold text-[#4b2d16]">
                    <span>{t(lang, 'settings.renderScale')}</span>
                    <span className="tabular-nums">{Math.round(settings.graphics.renderScale * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={60}
                    max={100}
                    step={5}
                    value={Math.round(settings.graphics.renderScale * 100)}
                    onChange={(e) => setGraphics({ renderScale: Number(e.target.value) / 100 })}
                    className="w-full accent-[#3a6b2c] cursor-pointer"
                  />
                </label>
              </div>
            </div>
          )}

          {section === 'theme' && (
            <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-4 space-y-3">
              <div>
                <div className="text-sm font-extrabold text-[#3d2412]">{t(lang, 'settings.theme')}</div>
                <p className="text-[11px] text-[#5c3c22]">
                  {lang === 'id'
                    ? 'Tema ini berlaku independen khusus untuk akun Anda.'
                    : 'Your chosen UI theme applies independently to your player profile.'}
                </p>
              </div>
              <div className="grid sm:grid-cols-2 gap-2.5">
                {themeChoices.map((choice) => {
                  const active = currentTheme === choice.id;
                  return (
                    <button
                      key={choice.id}
                      type="button"
                      onClick={() => setTheme(choice.id)}
                      className={`p-3 rounded-xl border-2 text-left cursor-pointer space-y-1.5 transition-colors ${
                        active
                          ? 'border-[#3a6b2c] bg-[#dcecd1] text-[#1f4416]'
                          : 'border-[#d3bc92] bg-[#f9f3e4] text-[#4b2d16] hover:bg-[#efe2c6]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-extrabold">{choice.title}</span>
                        <span className="flex items-center gap-1">
                          {choice.swatches.map((hex) => (
                            <span
                              key={hex}
                              className="w-3.5 h-3.5 rounded-full border border-black/25"
                              style={{ backgroundColor: hex }}
                            />
                          ))}
                        </span>
                      </div>
                      <p className="text-[11px] opacity-85">{lang === 'id' ? choice.descId : choice.descEn}</p>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {section === 'language' && (
            <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-4 space-y-3">
              <div>
                <div className="text-sm font-extrabold text-[#3d2412]">{t(lang, 'settings.language')}</div>
                <p className="text-[11px] text-[#5c3c22]">
                  {lang === 'id'
                    ? 'Seluruh antarmuka, dialog NPC, quest, notifikasi, dan pengaturan langsung berubah realtime.'
                    : 'All UI, NPC dialogues, quests, notifications, and settings switch in real time.'}
                </p>
              </div>
              <div className="grid sm:grid-cols-2 gap-2.5">
                {SUPPORTED_LANGUAGES.map((item) => {
                  const active = lang === item.code;
                  return (
                    <button
                      key={item.code}
                      type="button"
                      onClick={() => setLanguage(item.code)}
                      className={`p-3 rounded-xl border-2 text-left cursor-pointer transition-colors ${
                        active
                          ? 'border-[#3a6b2c] bg-[#dcecd1] text-[#1f4416]'
                          : 'border-[#d3bc92] bg-[#f9f3e4] text-[#4b2d16] hover:bg-[#efe2c6]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-extrabold">
                          {item.flag} {item.nativeName}
                        </span>
                        <span className="text-[10px] font-black uppercase px-1.5 py-0.5 rounded bg-black/10">
                          {item.code}
                        </span>
                      </div>
                      <div className="text-[11px] opacity-80 mt-0.5">{item.englishName}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* In-Game Only Utilities */}
          {isInGame && (
            <div className="pt-2 border-t border-[#d3bc92] space-y-3">
              {notifSettings && onToggleNotif && (
                <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-3.5 space-y-2">
                  <div className="text-xs font-extrabold flex items-center gap-1.5 text-[#6e4624]">
                    <Bell className="w-3.5 h-3.5 text-[#b8711e]" />
                    {lang === 'id' ? 'Notifikasi Dalam Game' : 'In-Game Notifications'}
                  </div>
                  <div className="grid sm:grid-cols-2 gap-2">
                    {(
                      [
                        ['dailyMissions', lang === 'id' ? 'Misi Harian' : 'Daily Missions'],
                        ['achievements', lang === 'id' ? 'Pencapaian' : 'Achievements'],
                        ['rewards', lang === 'id' ? 'Panen & Hadiah' : 'Harvests & Rewards'],
                        ['specialEvents', lang === 'id' ? 'Festival & Acara' : 'Festivals & Events'],
                        ['multiplayer', lang === 'id' ? 'Info Multiplayer' : 'Multiplayer Alerts'],
                      ] as const
                    ).map(([k, label]) => (
                      <label key={k} className="flex items-center justify-between text-xs font-semibold cursor-pointer">
                        <span>{label}</span>
                        <input
                          type="checkbox"
                          checked={notifSettings[k]}
                          onChange={() => onToggleNotif(k)}
                          className="w-4 h-4 accent-[#3a6b2c]"
                        />
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {onResetToHome && (
                <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-3.5 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="text-xs font-extrabold flex items-center gap-1.5">
                      <Home className="w-4 h-4 text-[#3a6b2c]" />
                      {lang === 'id' ? 'Teleport Pulang ke Rumah' : 'Reset to Home (Teleport Indoors)'}
                    </div>
                    <div className="text-[11px] text-[#5c3c22]">
                      {lang === 'id'
                        ? 'Kembali langsung ke dalam rumah pertanian (jeda 10 menit).'
                        : 'Teleports directly inside your private Farmhouse (10-min cooldown).'}
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={cooldownRemainingMs > 0}
                    onClick={() => {
                      onResetToHome();
                      onClose();
                    }}
                    className="px-3.5 py-2 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#cbbca3] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Clock className="w-3.5 h-3.5" />
                    {cooldownRemainingMs > 0
                      ? `${String(cooldownMin).padStart(2, '0')}:${String(cooldownSec).padStart(2, '0')}`
                      : lang === 'id'
                        ? 'Pulang'
                        : 'Reset to Home'}
                  </button>
                </div>
              )}

              {onExitGame && (
                <div className="rounded-xl border border-[#d49689] bg-[#fae1da]/60 p-3.5 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="text-xs font-extrabold text-[#751d11]">
                      {lang === 'id' ? 'Simpan & Keluar ke Menu Utama' : 'Save & Exit to Title Screen'}
                    </div>
                    <div className="text-[11px] text-[#5c3c22]">
                      {lang === 'id'
                        ? 'Menyimpan progres lokal & Cloud Save sebelum keluar.'
                        : 'Saves farm progress locally and to Cloud Save before returning.'}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={onExitGame}
                    className="px-4 py-2 rounded-xl bg-[#a63424] hover:bg-[#822518] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                    {lang === 'id' ? 'Keluar' : 'Exit Game'}
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Signed-In Account Management (Logout & Hardened Delete Account) */}
          {firebaseUserEmail && (onLogout || onDeleteAccount) && (
            <div className="pt-2 border-t border-[#d3bc92] space-y-2.5">
              <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-3.5 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-xs font-extrabold text-[#2b1a0e] flex items-center gap-1.5">
                      <UserCheck className="w-4 h-4 text-[#3a6b2c] shrink-0" />
                      <span>{t(lang, 'auth.signedInAccount')}</span>
                    </div>
                    <div className="text-[11px] font-bold text-[#6e4624] truncate">{firebaseUserEmail}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    {onLogout && (
                      <button
                        type="button"
                        disabled={accountBusy}
                        onClick={async () => {
                          setAccountBusy(true);
                          try {
                            await onLogout();
                            onClose();
                          } finally {
                            setAccountBusy(false);
                          }
                        }}
                        className="px-3 py-1.5 rounded-xl bg-[#4b2d16] hover:bg-[#361f0e] text-[#fef7e6] text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>{t(lang, 'auth.logout')}</span>
                      </button>
                    )}
                    {onDeleteAccount && (
                      <button
                        type="button"
                        disabled={accountBusy}
                        onClick={() => {
                          setDeleteOpen((v) => !v);
                          setDeleteEmailInput('');
                          setDeletePhraseInput('');
                          setDeleteError(null);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-[#991b1b] hover:bg-[#7f1d1d] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>{t(lang, 'auth.deleteAccount')}</span>
                      </button>
                    )}
                  </div>
                </div>

                {deleteOpen && onDeleteAccount && (
                  <div className="rounded-xl border-2 border-[#b91c1c] bg-[#fef2f2] p-3 space-y-2.5 text-[#7f1d1d]">
                    <div className="flex items-start gap-2">
                      <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-[#b91c1c]" />
                      <div className="space-y-0.5">
                        <div className="text-xs font-black">{t(lang, 'auth.deleteTitle')}</div>
                        <p className="text-[11px] font-semibold leading-snug">{t(lang, 'auth.deleteWarning')}</p>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[11px] font-extrabold">
                        {t(lang, 'auth.enterEmailLabel')} ({firebaseUserEmail})
                      </label>
                      <input
                        type="email"
                        value={deleteEmailInput}
                        onChange={(e) => setDeleteEmailInput(e.target.value)}
                        placeholder={firebaseUserEmail}
                        className="w-full rounded-lg border border-[#fca5a5] bg-white px-2.5 py-1.5 text-xs font-semibold text-[#1f2937]"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[11px] font-extrabold">{t(lang, 'auth.enterPhraseLabel')}</label>
                      <input
                        type="text"
                        value={deletePhraseInput}
                        onChange={(e) => setDeletePhraseInput(e.target.value)}
                        placeholder={t(lang, 'auth.confirmPhrase')}
                        className="w-full rounded-lg border border-[#fca5a5] bg-white px-2.5 py-1.5 text-xs font-semibold text-[#1f2937]"
                      />
                    </div>

                    {deleteError && (
                      <div className="text-[11px] font-bold text-[#991b1b] flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        <span>{deleteError}</span>
                      </div>
                    )}

                    <div className="flex items-center justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setDeleteOpen(false)}
                        className="px-3 py-1.5 rounded-lg bg-[#e5e7eb] hover:bg-[#d1d5db] text-[#374151] text-xs font-bold cursor-pointer"
                      >
                        {t(lang, 'auth.cancel')}
                      </button>
                      <button
                        type="button"
                        disabled={
                          accountBusy ||
                          deleteEmailInput.trim().toLowerCase() !== firebaseUserEmail.trim().toLowerCase() ||
                          deletePhraseInput.trim().toUpperCase() !== t(lang, 'auth.confirmPhrase').toUpperCase()
                        }
                        onClick={async () => {
                          setDeleteError(null);
                          setAccountBusy(true);
                          try {
                            await onDeleteAccount(deleteEmailInput.trim());
                            setDeleteOpen(false);
                            onClose();
                          } catch (err) {
                            setDeleteError(err instanceof Error ? err.message : 'Account deletion failed.');
                          } finally {
                            setAccountBusy(false);
                          }
                        }}
                        className="px-3 py-1.5 rounded-lg bg-[#b91c1c] hover:bg-[#991b1b] disabled:bg-[#fca5a5] text-white text-xs font-extrabold cursor-pointer disabled:cursor-not-allowed"
                      >
                        {accountBusy ? '...' : t(lang, 'auth.reauthButton')}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
      </div>
      {gamepadEditorOpen && (
        <MobileGamepadEditor
          language={lang}
          layout={settings.mobileGamepadLayout || mobileControlsConfig.defaultLayout || DEFAULT_MOBILE_GAMEPAD_LAYOUT}
          presets={settings.mobileGamepadPresets || []}
          boundsConfig={mobileControlsConfig}
          onSaveLayout={(nextLayout: CustomMobileGamepadLayout) => {
            onUpdateSettings({
              ...settings,
              mobileGamepadLayout: nextLayout,
            });
          }}
          onSavePresets={(nextPresets: MobileGamepadPreset[]) => {
            onUpdateSettings({
              ...settings,
              mobileGamepadPresets: nextPresets,
            });
          }}
          onClose={() => setGamepadEditorOpen(false)}
        />
      )}
    </DraggableWindow>
  );
};
