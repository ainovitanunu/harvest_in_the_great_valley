import React, { useEffect, useState } from 'react';
import { Clock, LogOut, ShieldAlert } from 'lucide-react';
import type { Language, PlayerBanRecord } from '../game/types';
import { localizeBanType } from '../game/localizationManager';

interface BanLockdownScreenProps {
  ban: PlayerBanRecord;
  language: Language;
  onSignOut: () => void;
}

function formatRemaining(ms: number, lang: Language): string {
  if (ms <= 0) return lang === 'id' ? 'Segera berakhir...' : 'Expiring soon...';
  const totalSec = Math.floor(ms / 1000);
  const days = Math.floor(totalSec / 86400);
  const hours = Math.floor((totalSec % 86400) / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  const parts: string[] = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0 || days > 0) parts.push(`${hours}h`);
  parts.push(`${String(mins).padStart(2, '0')}m`);
  parts.push(`${String(secs).padStart(2, '0')}s`);
  return parts.join(' ');
}

export const BanLockdownScreen: React.FC<BanLockdownScreenProps> = ({ ban, language, onSignOut }) => {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const isPermanent = ban.banType === 'permanent_ban' || ban.banType === 'account_lock' || !ban.expiresAt;
  const remainingMs = ban.expiresAt ? Math.max(0, ban.expiresAt - now) : 0;
  const isId = language === 'id';

  const durationLabel = isPermanent
    ? isId
      ? 'Permanen / Hingga Dibuka Developer'
      : 'Permanent / Until Unlocked by Developer'
    : ban.durationMinutes
      ? ban.durationMinutes >= 60
        ? `${Math.round(ban.durationMinutes / 60)} ${isId ? 'Jam' : 'Hours'}`
        : `${ban.durationMinutes} ${isId ? 'Menit' : 'Minutes'}`
      : ban.durationHours
        ? `${ban.durationHours} ${isId ? 'Jam' : 'Hours'}`
        : isId
          ? 'Sementara'
          : 'Temporary';

  const devNote = ban.devMessage || ban.developerMessage;
  const startedTimestamp = ban.issuedAt || ban.startedAt || Date.now();

  return (
    <div
      className="fixed inset-0 z-[200] flex items-center justify-center p-4 select-none"
      style={{
        background: 'radial-gradient(circle at top, rgba(127, 29, 29, 0.88), rgba(15, 23, 42, 0.98) 70%)',
      }}
    >
      <div
        className="w-full max-w-lg rounded-2xl border-2 p-6 shadow-2xl space-y-5"
        style={{
          backgroundColor: 'var(--hv-surface)',
          borderColor: '#dc2626',
          color: 'var(--hv-text)',
        }}
      >
        <div className="flex items-start gap-3">
          <div className="p-3 rounded-xl bg-rose-600/15 text-rose-600 shrink-0">
            <ShieldAlert className="w-8 h-8" />
          </div>
          <div>
            <div className="text-xs font-extrabold uppercase tracking-wider text-rose-600">
              {localizeBanType(language, ban.banType)}
            </div>
            <h1 className="text-xl font-extrabold mt-0.5">
              {isId ? 'Akses Akun Ditangguhkan' : 'Account Access Restricted'}
            </h1>
            <p className="text-xs opacity-75 mt-1">
              {isId
                ? 'Seluruh aktivitas bermain, pergerakan, interaksi, menu, dan chat dikunci hingga masa sanksi selesai.'
                : 'All gameplay, movement, interactions, menus, and chat are locked while this restriction is active.'}
            </p>
          </div>
        </div>

        <div
          className="rounded-xl p-4 space-y-3 border text-sm"
          style={{ backgroundColor: 'var(--hv-surface-2)', borderColor: 'var(--hv-border)' }}
        >
          <div>
            <div className="text-[11px] font-bold uppercase opacity-65">
              {isId ? 'Alasan Ban' : 'Reason'}
            </div>
            <div className="font-semibold mt-0.5">{ban.reason || '-'}</div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t" style={{ borderColor: 'var(--hv-border)' }}>
            <div>
              <div className="text-[11px] font-bold uppercase opacity-65">
                {isId ? 'Durasi' : 'Duration'}
              </div>
              <div className="font-semibold mt-0.5">{durationLabel}</div>
            </div>
            <div>
              <div className="text-[11px] font-bold uppercase opacity-65 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-rose-500" />
                {isId ? 'Sisa Waktu' : 'Remaining Time'}
              </div>
              <div className="font-extrabold text-rose-600 mt-0.5">
                {isPermanent
                  ? isId
                    ? 'Permanen'
                    : 'Permanent'
                  : formatRemaining(remainingMs, language)}
              </div>
            </div>
          </div>

          <div className="pt-2 border-t" style={{ borderColor: 'var(--hv-border)' }}>
            <div className="text-[11px] font-bold uppercase opacity-65">
              {isId ? 'Pesan Developer' : 'Developer Message'}
            </div>
            <p className="text-xs leading-relaxed mt-1 opacity-90">
              {devNote ||
                (isId
                  ? 'Jika Anda merasa ini adalah kesalahan, hubungi tim dukungan resmi dengan menyertakan ID akun Anda.'
                  : 'If you believe this was a mistake, please contact official support with your account ID.')}
            </p>
          </div>

          <div className="pt-2 border-t flex flex-wrap justify-between text-[11px] opacity-65" style={{ borderColor: 'var(--hv-border)' }}>
            <span>UID: {ban.uid}</span>
            <span>
              {isId ? 'Mulai:' : 'Started:'} {new Date(startedTimestamp).toLocaleString()}
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={onSignOut}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-bold text-sm bg-rose-600 hover:bg-rose-700 text-white transition-colors"
        >
          <LogOut className="w-4 h-4" />
          {isId ? 'Keluar ke Layar Login' : 'Return to Login Screen'}
        </button>
      </div>
    </div>
  );
};
