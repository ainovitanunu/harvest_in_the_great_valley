import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Check,
  Flag,
  Heart,
  Laptop,
  Lock,
  MessageSquare,
  Mic,
  MicOff,
  Phone,
  PhoneOff,
  RefreshCw,
  Send,
  ShieldBan,
  Smartphone,
  UserMinus,
  UserPlus,
  Users,
  Video,
  VideoOff,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { t } from '../game/i18n';
import type {
  ChatMessage,
  FriendRecord,
  FriendRequestRecord,
  Language,
  OnlinePlayerState,
  PlayerBanRecord,
} from '../game/types';
import type { CallStateSnapshot } from '../services/callManager';
import type { IncomingCallInvite } from '../services/multiplayerClient';
import { DraggableWindow } from './DraggableWindow';

export interface OnlineDirectoryEntry {
  uid: string;
  avatarName: string;
  farmName: string;
  zone: string;
  level: number;
}

interface ChatPanelProps {
  language?: Language;
  messages: ChatMessage[];
  currentUid: string;
  initialChannel?: ChatMessage['channel'];
  initialPrivateTarget?: { uid: string; name: string } | null;
  nearbyPlayers: OnlinePlayerState[];
  allOnlinePlayers?: OnlineDirectoryEntry[];
  friends?: FriendRecord[];
  incomingFriendRequests?: FriendRequestRecord[];
  outgoingFriendRequests?: FriendRequestRecord[];
  alreadyMarried: boolean;
  hasProposalItemId: string | null;
  canProposeMarriage?: boolean;
  marriageRequirementsLabel?: string;
  hasPhone: boolean;
  callState: CallStateSnapshot;
  incomingInvite: IncomingCallInvite | null;
  onStartVoiceCall: (targetUid?: string) => void;
  onStartVideoCall: (targetUid?: string) => void;
  onStartGroupCall: (mode: 'voice' | 'video', targetUids?: string[]) => void;
  onRequestMediaPermission?: () => Promise<void> | void;
  onSendFriendRequest?: (targetUid: string) => void;
  onRespondFriendRequest?: (fromUid: string, accept: boolean) => void;
  onRemoveFriend?: (friendUid: string) => void;
  onAcceptCallInvite: () => void;
  onDeclineCallInvite: () => void;
  onToggleMic: () => void;
  onToggleCam: () => void;
  onFlipCam: () => void;
  onLeaveCall: () => void;
  onProposePlayer: (targetUid: string, targetName: string, itemId: string) => void;
  onSend: (channel: ChatMessage['channel'], text: string, targetId?: string) => void;
  mutedPlayerIds: string[];
  activeBan?: PlayerBanRecord | null;
  onMute: (uid: string, shouldMute: boolean) => void;
  onBlock: (uid: string) => void;
  onReport: (msg: ChatMessage) => void;
  onClose: () => void;
}

type PanelTab = ChatMessage['channel'] | 'friends';

export const ChatPanel: React.FC<ChatPanelProps> = ({
  language = 'en',
  messages,
  currentUid,
  initialChannel = 'global',
  initialPrivateTarget = null,
  nearbyPlayers,
  allOnlinePlayers = [],
  friends = [],
  incomingFriendRequests = [],
  outgoingFriendRequests = [],
  alreadyMarried,
  hasProposalItemId,
  canProposeMarriage = false,
  marriageRequirementsLabel = 'Requires House Lv.3, Barn Lv.3, Coop Lv.3 & Unity Wedding Ring (Diamond)',
  hasPhone,
  callState,
  incomingInvite,
  onStartVoiceCall,
  onStartVideoCall,
  onStartGroupCall,
  onRequestMediaPermission,
  onSendFriendRequest,
  onRespondFriendRequest,
  onRemoveFriend,
  onAcceptCallInvite,
  onDeclineCallInvite,
  onToggleMic,
  onToggleCam,
  onFlipCam,
  onLeaveCall,
  onProposePlayer,
  activeBan = null,
  onSend,
  mutedPlayerIds,
  onMute,
  onBlock,
  onReport,
  onClose,
}) => {
  const [panelTab, setPanelTab] = useState<PanelTab>(initialChannel);
  const [text, setText] = useState('');
  const [targetId, setTargetId] = useState(initialPrivateTarget?.uid || '');
  const [selectedGroupFriendUids, setSelectedGroupFriendUids] = useState<string[]>([]);
  const [pendingRemoveFriend, setPendingRemoveFriend] = useState<FriendRecord | null>(null);
  const [requestingPerm, setRequestingPerm] = useState(false);

  useEffect(() => {
    setPanelTab(initialChannel);
  }, [initialChannel]);

  useEffect(() => {
    if (initialPrivateTarget?.uid) {
      setTargetId(initialPrivateTarget.uid);
    }
  }, [initialPrivateTarget]);

  const friendUidSet = new Set(friends.map((f) => f.uid));
  const outgoingUidSet = new Set(outgoingFriendRequests.map((r) => r.toUid));
  const onlineUidSet = new Set(allOnlinePlayers.map((p) => p.uid));

  // Private chat targets can be nearby players OR mutual friends (cross-zone!)
  const privateCandidates: Array<{ uid: string; avatarName: string; farmName: string; isFriend: boolean }> = [];
  const seenUids = new Set<string>();
  for (const f of friends) {
    if (f.uid !== currentUid && !seenUids.has(f.uid)) {
      seenUids.add(f.uid);
      privateCandidates.push({
        uid: f.uid,
        avatarName: f.avatarName,
        farmName: f.farmName || 'Great Valley Farm',
        isFriend: true,
      });
    }
  }
  for (const p of nearbyPlayers) {
    if (p.uid !== currentUid && !seenUids.has(p.uid)) {
      seenUids.add(p.uid);
      privateCandidates.push({
        uid: p.uid,
        avatarName: p.avatarName,
        farmName: p.farmName,
        isFriend: friendUidSet.has(p.uid),
      });
    }
  }

  const activePrivateCandidate =
    privateCandidates.find((p) => p.uid === targetId) || privateCandidates[0] || null;
  const activeNearbyTarget = nearbyPlayers.find((p) => p.uid === activePrivateCandidate?.uid) || null;
  const activeCallFriendTarget =
    (activePrivateCandidate && friendUidSet.has(activePrivateCandidate.uid) ? activePrivateCandidate : null) ||
    friends[0] ||
    null;

  const canSendPrivate = panelTab !== 'private' || Boolean(activePrivateCandidate);
  const canProposeActiveTarget =
    panelTab === 'private' &&
    Boolean(activeNearbyTarget) &&
    !alreadyMarried &&
    !activeNearbyTarget?.spousePlayerName;

  const mutedSet = new Set(mutedPlayerIds);
  const filtered =
    panelTab === 'friends'
      ? []
      : messages.filter(
          (m) => m.channel === panelTab && (m.senderId === currentUid || !mutedSet.has(m.senderId))
        );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (panelTab === 'friends' || !text.trim() || !canSendPrivate) return;
    onSend(panelTab, text.trim(), panelTab === 'private' ? activePrivateCandidate?.uid : undefined);
    setText('');
  };

  const toggleGroupFriend = (uid: string) => {
    setSelectedGroupFriendUids((prev) =>
      prev.includes(uid) ? prev.filter((id) => id !== uid) : [...prev, uid]
    );
  };

  const perm = callState.permissions;
  const showPermBanner =
    hasPhone &&
    Boolean(perm) &&
    (perm.needsPermissionPrompt || perm.mic === 'denied' || perm.cam === 'denied');

  return (
    <DraggableWindow
      windowId="chat"
      title={t(language, 'chat.title')}
      icon={<MessageSquare className="w-4 h-4 text-[#f5cc74]" />}
      widthClass="w-[min(94vw,490px)]"
      defaultOffset={{ x: -160, y: 40 }}
      headerAccent="walnut"
      zIndexClass="z-30"
      onClose={onClose}
    >
      <div className="flex flex-col text-[#2b1a0e]">
        {/* Channel & Friends Tabs */}
        <div className="px-3 pt-2.5 flex flex-wrap gap-1 border-b border-[#d3bc92] pb-2 bg-[#efe2c6]">
          {(
            [
              ['global', t(language, 'chat.global')],
              ['local', t(language, 'chat.local')],
              ['farm_visit', t(language, 'chat.farm')],
              ['event', t(language, 'chat.event')],
              ['private', t(language, 'chat.private')],
              [
                'friends',
                `${t(language, 'chat.friends')} (${friends.length}${
                  incomingFriendRequests.length > 0 ? ` +${incomingFriendRequests.length}` : ''
                })`,
              ],
            ] as const
          ).map(([ch, label]) => (
            <button
              key={ch}
              type="button"
              onClick={() => setPanelTab(ch)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer ${
                panelTab === ch
                  ? ch === 'friends'
                    ? 'bg-[#3a6b2c] border-[#1f4416] text-white'
                    : 'bg-[#f2cf7e] border-[#b8711e] text-[#3c2310]'
                  : 'bg-[#fffaf0] border-[#d3bc92] text-[#5c3c22]'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Valley Smartphone: Friends-Only Cross-Zone Voice Chat, Video Call & Group Call Panel */}
        <div className="px-3 py-2 bg-[#e8d9bc] border-b border-[#d3bc92] space-y-2">
          <div className="flex items-center justify-between text-[11px] font-extrabold text-[#4b2d16]">
            <span className="flex items-center gap-1.5">
              {callState.deviceType === 'mobile' ? (
                <Smartphone className="w-3.5 h-3.5 text-[#3a6b2c]" />
              ) : (
                <Laptop className="w-3.5 h-3.5 text-[#3a6b2c]" />
              )}
              <span>
                {callState.deviceType === 'mobile'
                  ? t(language, 'chat.deviceMobile')
                  : t(language, 'chat.deviceDesktop')}
              </span>
            </span>
            <span className="text-[10px] font-bold text-[#6e4624]">
              {hasPhone ? '📱 Smartphone Active' : '🔒 Smartphone Locked'}
            </span>
          </div>

          {/* Explicit Mic & Camera Permission Request Notification */}
          {showPermBanner && perm && (
            <div className="rounded-xl bg-[#fff7ed] border-2 border-[#f59e0b] px-2.5 py-2 text-[11px] text-[#78350f] flex flex-wrap items-center justify-between gap-2">
              <div className="min-w-0 flex-1 space-y-0.5">
                <div className="font-extrabold flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5 text-[#d97706] shrink-0" />
                  <span>{t(language, 'chat.permissionTitle')}</span>
                </div>
                <div className="text-[10px] font-semibold">
                  🎙️ Mic: <strong>{perm.hasMicHardware ? perm.mic : 'No hardware'}</strong> · 📹 Cam:{' '}
                  <strong>{perm.hasCamHardware ? perm.cam : 'No hardware'}</strong>
                </div>
              </div>
              {onRequestMediaPermission && (
                <button
                  type="button"
                  disabled={requestingPerm}
                  onClick={async () => {
                    setRequestingPerm(true);
                    try {
                      await onRequestMediaPermission();
                    } finally {
                      setRequestingPerm(false);
                    }
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-[#d97706] hover:bg-[#b45309] disabled:opacity-60 text-white text-[10px] font-extrabold cursor-pointer shrink-0"
                >
                  {requestingPerm ? '...' : t(language, 'chat.grantPermission')}
                </button>
              )}
            </div>
          )}

          {incomingInvite && !callState.inCall && (
            <div className="rounded-xl bg-[#244418] text-[#fef9ed] px-3 py-2 flex items-center justify-between gap-2 text-xs">
              <div className="min-w-0">
                <div className="font-extrabold truncate">
                  {incomingInvite.fromName}{' '}
                  {incomingInvite.mode === 'video' ? '📹 Video Call' : '📞 Voice Call'}
                  {incomingInvite.isGroup ? ' (Group)' : ''}
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  disabled={!hasPhone}
                  onClick={onAcceptCallInvite}
                  className="px-2.5 py-1 rounded-lg bg-[#529e3b] hover:bg-[#3f822b] disabled:opacity-50 text-white font-extrabold text-[11px] cursor-pointer"
                >
                  {language === 'id' ? 'Terima' : 'Join'}
                </button>
                <button
                  type="button"
                  onClick={onDeclineCallInvite}
                  className="px-2 py-1 rounded-lg bg-[#a63424] hover:bg-[#822518] text-white font-extrabold text-[11px] cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>
          )}

          {!hasPhone ? (
            <div className="rounded-xl bg-[#fffaf0] border border-[#d3bc92] px-2.5 py-2 text-[11px] font-bold text-[#6e4624] flex items-center gap-2">
              <Lock className="w-4 h-4 text-[#9e3b24] shrink-0" />
              <span>{t(language, 'chat.phoneLocked')}</span>
            </div>
          ) : callState.inCall ? (
            <div className="rounded-xl bg-gradient-to-r from-[#0f172a] via-[#1e293b] to-[#0f172a] border border-white/15 text-[#f8fafc] p-2.5 space-y-2 shadow-lg">
              <div className="flex items-center justify-between gap-2 text-[11px] font-bold">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>
                    {callState.mode === 'video' ? '📹' : '🎙️'}{' '}
                    {callState.isGroup ? t(language, 'chat.groupCall') : t(language, 'chat.videoCall')} ·{' '}
                    {callState.participants.length} {language === 'id' ? 'peserta' : 'in call'}
                  </span>
                </span>
                {callState.error ? (
                  <span className="text-[#fca5a5] truncate max-w-[180px]">{callState.error}</span>
                ) : (
                  <span className="px-1.5 py-0.5 rounded bg-white/10 text-[9px] font-mono text-sky-200">
                    {callState.mode === 'video' ? '240p · 30fps' : 'Voice HD'}
                  </span>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={onToggleMic}
                  className={`px-2.5 py-1.5 rounded-lg text-[11px] font-extrabold flex items-center gap-1 cursor-pointer transition-colors ${
                    callState.micOn ? 'bg-emerald-600 hover:bg-emerald-500 text-white' : 'bg-rose-700 hover:bg-rose-600 text-rose-100'
                  }`}
                >
                  {callState.micOn ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
                  {callState.micOn ? 'Mic' : 'Muted'}
                </button>
                <button
                  type="button"
                  onClick={onToggleCam}
                  className={`px-2.5 py-1.5 rounded-lg text-[11px] font-extrabold flex items-center gap-1 cursor-pointer transition-colors ${
                    callState.camOn ? 'bg-sky-600 hover:bg-sky-500 text-white' : 'bg-slate-700 hover:bg-slate-600 text-slate-200'
                  }`}
                >
                  {callState.camOn ? <Video className="w-3.5 h-3.5" /> : <VideoOff className="w-3.5 h-3.5" />}
                  {callState.camOn ? 'Cam' : 'Cam Off'}
                </button>
                {callState.camOn && (
                  <button
                    type="button"
                    onClick={onFlipCam}
                    className="px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-extrabold flex items-center gap-1 cursor-pointer transition-colors"
                    title={language === 'id' ? 'Putar Kamera Depan/Belakang' : 'Switch Front / Back Camera'}
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> {language === 'id' ? 'Putar' : 'Flip'}
                  </button>
                )}
                <button
                  type="button"
                  onClick={onLeaveCall}
                  className="ml-auto px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-extrabold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <PhoneOff className="w-3.5 h-3.5" /> {t(language, 'chat.endCall')}
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-1.5">
              <div className="text-[10px] font-bold text-[#5c3c22] flex items-center justify-between gap-2">
                <span>🔒 {t(language, 'chat.friendsOnlyCall')}</span>
                {activeCallFriendTarget && (
                  <span className="text-[#214417] truncate">→ {activeCallFriendTarget.avatarName}</span>
                )}
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  disabled={!activeCallFriendTarget}
                  onClick={() => activeCallFriendTarget && onStartVoiceCall(activeCallFriendTarget.uid)}
                  className="py-1.5 px-2 rounded-lg bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#cbbca3] disabled:text-[#5c4e3e] text-white text-[11px] font-extrabold flex items-center justify-center gap-1 cursor-pointer disabled:cursor-not-allowed"
                >
                  <Phone className="w-3.5 h-3.5" /> {t(language, 'chat.voiceCall')}
                </button>
                <button
                  type="button"
                  disabled={!activeCallFriendTarget}
                  onClick={() => activeCallFriendTarget && onStartVideoCall(activeCallFriendTarget.uid)}
                  className="py-1.5 px-2 rounded-lg bg-[#0284c7] hover:bg-[#0369a1] disabled:bg-[#cbbca3] disabled:text-[#5c4e3e] text-white text-[11px] font-extrabold flex items-center justify-center gap-1 cursor-pointer disabled:cursor-not-allowed"
                >
                  <Video className="w-3.5 h-3.5" /> {t(language, 'chat.videoCall')}
                </button>
                <button
                  type="button"
                  disabled={friends.length === 0}
                  onClick={() => {
                    const targets =
                      selectedGroupFriendUids.length > 0
                        ? selectedGroupFriendUids
                        : friends.map((f) => f.uid);
                    onStartGroupCall('video', targets);
                  }}
                  className="py-1.5 px-2 rounded-lg bg-[#784820] hover:bg-[#5c3616] disabled:bg-[#cbbca3] disabled:text-[#5c4e3e] text-white text-[11px] font-extrabold flex items-center justify-center gap-1 cursor-pointer disabled:cursor-not-allowed"
                >
                  <Users className="w-3.5 h-3.5" /> {t(language, 'chat.groupCall')}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* FRIENDS TAB (Friend List, Cross-Zone Calls, Group Call Selection & Requests) */}
        {panelTab === 'friends' ? (
          <div className="h-72 overflow-y-auto p-3 space-y-3 bg-[#f7eedc] text-xs">
            {/* Incoming Friend Requests */}
            {incomingFriendRequests.length > 0 && (
              <div className="space-y-1.5">
                <div className="text-[11px] font-black uppercase text-[#9e3b24]">
                  {language === 'id' ? 'Permintaan Pertemanan Masuk' : 'Incoming Friend Requests'} ({incomingFriendRequests.length})
                </div>
                {incomingFriendRequests.map((req) => (
                  <div
                    key={req.id}
                    className="rounded-xl border-2 border-[#d98a2b] bg-[#fffbeb] px-2.5 py-2 flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <div className="font-extrabold truncate">{req.fromName}</div>
                      <div className="text-[10px] text-[#6e4624] truncate">🤝 {language === 'id' ? 'Ingin berteman' : 'Wants to be friends'}</div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => onRespondFriendRequest?.(req.fromUid, true)}
                        className="px-2 py-1 rounded-lg bg-[#3a6b2c] hover:bg-[#2d5422] text-white font-extrabold flex items-center gap-1 cursor-pointer"
                      >
                        <Check className="w-3 h-3" /> {language === 'id' ? 'Terima' : 'Accept'}
                      </button>
                      <button
                        type="button"
                        onClick={() => onRespondFriendRequest?.(req.fromUid, false)}
                        className="p-1 rounded-lg bg-[#a63424] hover:bg-[#822518] text-white cursor-pointer"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Mutual Friend List (Supports Cross-Zone Private & Group Calls) */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black uppercase text-[#3a6b2c]">
                  {language === 'id' ? 'Daftar Teman' : 'My Friends'} ({friends.length})
                </span>
                {friends.length > 1 && hasPhone && !callState.inCall && (
                  <button
                    type="button"
                    onClick={() =>
                      onStartGroupCall(
                        'video',
                        selectedGroupFriendUids.length > 0 ? selectedGroupFriendUids : friends.map((f) => f.uid)
                      )
                    }
                    className="px-2 py-0.5 rounded-lg bg-[#784820] hover:bg-[#5c3616] text-white text-[10px] font-extrabold cursor-pointer"
                  >
                    📹 {language === 'id' ? 'Grup Call' : 'Group Call'} (
                    {selectedGroupFriendUids.length || friends.length})
                  </button>
                )}
              </div>

              {friends.length === 0 ? (
                <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-3 text-center text-[#6e4624]">
                  {language === 'id'
                    ? 'Belum ada teman. Tambahkan pemain online di bawah untuk membuka Voice/Video Call lintas zona!'
                    : 'No friends yet. Add an online farmer below to unlock cross-zone Voice, Video & Group Calls!'}
                </div>
              ) : (
                friends.map((friend) => {
                  const isOnlineNow = onlineUidSet.has(friend.uid);
                  const checked = selectedGroupFriendUids.includes(friend.uid);
                  return (
                    <div
                      key={friend.uid}
                      className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] px-2.5 py-2 flex items-center justify-between gap-2"
                    >
                      <label className="flex items-center gap-2 min-w-0 cursor-pointer flex-1">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => toggleGroupFriend(friend.uid)}
                          className="accent-[#3a6b2c]"
                        />
                        <div className="min-w-0">
                          <div className="font-extrabold truncate flex items-center gap-1.5">
                            <span
                              className={`w-2 h-2 rounded-full shrink-0 ${
                                isOnlineNow ? 'bg-[#22c55e]' : 'bg-[#a8a29e]'
                              }`}
                            />
                            <span className="truncate">{friend.avatarName}</span>
                          </div>
                          <div className="text-[10px] text-[#6e4624] truncate">🏡 {friend.farmName}</div>
                        </div>
                      </label>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          disabled={!hasPhone || callState.inCall}
                          onClick={() => onStartVoiceCall(friend.uid)}
                          title={t(language, 'chat.voiceCall')}
                          className="p-1.5 rounded-lg bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#cbbca3] text-white cursor-pointer disabled:cursor-not-allowed"
                        >
                          <Phone className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={!hasPhone || callState.inCall}
                          onClick={() => onStartVideoCall(friend.uid)}
                          title={t(language, 'chat.videoCall')}
                          className="p-1.5 rounded-lg bg-[#0284c7] hover:bg-[#0369a1] disabled:bg-[#cbbca3] text-white cursor-pointer disabled:cursor-not-allowed"
                        >
                          <Video className="w-3.5 h-3.5" />
                        </button>
                        {onRemoveFriend && (
                          <button
                            type="button"
                            onClick={() => setPendingRemoveFriend(friend)}
                            title={language === 'id' ? 'Hapus Teman' : 'Remove Friend'}
                            className="p-1.5 rounded-lg bg-[#efe2c6] hover:bg-[#fae1da] text-[#a63424] cursor-pointer"
                          >
                            <UserMinus className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
              {pendingRemoveFriend && onRemoveFriend && (
                <div className="mt-2 rounded-xl border-2 border-[#b91c1c] bg-[#fef2f2] p-3 text-[#7f1d1d] shadow-md space-y-2">
                  <div className="text-xs font-black flex items-center gap-1.5">
                    <UserMinus className="w-4 h-4 shrink-0" />
                    <span>{language === 'id' ? 'Konfirmasi Hapus Teman' : 'Confirm Remove Friend'}</span>
                  </div>
                  <p className="text-[11px] font-semibold leading-snug">
                    {language === 'id'
                      ? `Apakah Anda yakin ingin menghapus "${pendingRemoveFriend.avatarName}" dari daftar pertemanan?`
                      : `Are you sure you want to remove "${pendingRemoveFriend.avatarName}" from your friends list?`}
                  </p>
                  <div className="flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setPendingRemoveFriend(null)}
                      className="px-3 py-1 rounded-lg bg-white hover:bg-[#f3f4f6] border border-[#d1d5db] text-[#374151] text-[11px] font-extrabold cursor-pointer"
                    >
                      {language === 'id' ? 'Batal' : 'Cancel'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const targetUid = pendingRemoveFriend.uid;
                        setPendingRemoveFriend(null);
                        onRemoveFriend(targetUid);
                      }}
                      className="px-3 py-1 rounded-lg bg-[#dc2626] hover:bg-[#b91c1c] text-white text-[11px] font-extrabold cursor-pointer"
                    >
                      {language === 'id' ? 'Ya, Hapus Teman' : 'Yes, Remove'}
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Online Farmers Directory (Add Friend) */}
            <div className="space-y-1.5 pt-2 border-t border-[#d3bc92]">
              <div className="text-[11px] font-black uppercase text-[#5c3c22]">
                {language === 'id' ? 'Pemain Online (Tambah Teman)' : 'Online Farmers (Add Friend)'}
              </div>
              {allOnlinePlayers.filter((p) => p.uid !== currentUid && !friendUidSet.has(p.uid)).length === 0 ? (
                <div className="text-[11px] text-[#6e4624] italic">
                  {language === 'id'
                    ? 'Tidak ada pemain lain yang belum berteman saat ini.'
                    : 'No other non-friend farmers online right now.'}
                </div>
              ) : (
                allOnlinePlayers
                  .filter((p) => p.uid !== currentUid && !friendUidSet.has(p.uid))
                  .map((p) => {
                    const alreadySent = outgoingUidSet.has(p.uid);
                    return (
                      <div
                        key={p.uid}
                        className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] px-2.5 py-2 flex items-center justify-between gap-2"
                      >
                        <div className="min-w-0">
                          <div className="font-extrabold truncate">{p.avatarName}</div>
                          <div className="text-[10px] text-[#6e4624] truncate">
                            🏡 {p.farmName} · Lv.{p.level}
                          </div>
                        </div>
                        <button
                          type="button"
                          disabled={alreadySent}
                          onClick={() => onSendFriendRequest?.(p.uid)}
                          className="px-2.5 py-1 rounded-lg bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#cbbca3] text-white text-[11px] font-extrabold flex items-center gap-1 cursor-pointer disabled:cursor-default shrink-0"
                        >
                          <UserPlus className="w-3 h-3" />
                          {alreadySent
                            ? language === 'id'
                              ? 'Terkirim'
                              : 'Sent'
                            : language === 'id'
                              ? 'Tambah'
                              : 'Add'}
                        </button>
                      </div>
                    );
                  })
              )}
            </div>
          </div>
        ) : (
          <>
            {mutedPlayerIds.length > 0 && (
              <div className="px-3 py-2 bg-[#f4dfb8] border-b border-[#d3bc92] text-[11px] flex flex-wrap items-center gap-1.5">
                <span className="font-extrabold text-[#6e4624]">Muted:</span>
                {mutedPlayerIds.map((uid) => {
                  const player = nearbyPlayers.find((p) => p.uid === uid);
                  return (
                    <button
                      key={uid}
                      type="button"
                      onClick={() => onMute(uid, false)}
                      className="rounded-md border border-[#b8711e] bg-[#fffaf0] px-2 py-1 font-bold text-[#5c3c22] hover:bg-[#f2cf7e] cursor-pointer"
                    >
                      🔊 {player?.avatarName || uid.slice(0, 8)}
                    </button>
                  );
                })}
              </div>
            )}

            {/* Messages Feed */}
            <div className="h-48 overflow-y-auto p-3 space-y-2 text-xs bg-[#f7eedc]">
              {filtered.length === 0 && (
                <div className="text-center text-[#6e4624] py-8">
                  {language === 'id'
                    ? 'Belum ada pesan di kanal ini. Sapa tetangga atau pemain lain!'
                    : 'No messages in this channel yet. Say hello to neighbors or visiting farmers!'}
                </div>
              )}
              {filtered.map((m) => {
                const isMe = m.senderId === currentUid;
                return (
                  <div
                    key={m.id}
                    className={`rounded-xl p-2 ${
                      isMe ? 'bg-[#dcecd1] border border-[#96b884]' : 'bg-[#fffaf0] border border-[#d3bc92]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-extrabold text-[#3a6b2c]">
                        {m.channel === 'private' ? '🔒 ' : ''}
                        {m.senderName}
                      </span>
                      {!isMe && (
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => onMute(m.senderId, !mutedSet.has(m.senderId))}
                            className={`cursor-pointer ${mutedSet.has(m.senderId) ? 'text-[#b8711e]' : 'text-[#6e4624]'}`}
                          >
                            {mutedSet.has(m.senderId) ? (
                              <Volume2 className="w-3.5 h-3.5" />
                            ) : (
                              <VolumeX className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <button type="button" onClick={() => onBlock(m.senderId)} className="text-[#a63424] cursor-pointer">
                            <ShieldBan className="w-3.5 h-3.5" />
                          </button>
                          <button type="button" onClick={() => onReport(m)} className="text-[#b8711e] cursor-pointer">
                            <Flag className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                    <p className="mt-0.5 text-[#2b1a0e] break-words">{m.text}</p>
                  </div>
                );
              })}
            </div>

            {/* Input Form */}
            <form onSubmit={handleSubmit} className="p-2.5 bg-[#efe2c6] border-t border-[#d3bc92] space-y-1.5">
              {panelTab === 'private' &&
                (privateCandidates.length > 0 ? (
                  <div className="flex items-center gap-1.5">
                    <select
                      value={activePrivateCandidate?.uid || ''}
                      onChange={(e) => setTargetId(e.target.value)}
                      className="flex-1 rounded-lg border border-[#bfa070] bg-[#fffaf0] px-2.5 py-1.5 text-xs font-bold"
                    >
                      {privateCandidates.map((p) => (
                        <option key={p.uid} value={p.uid}>
                          {p.isFriend ? '⭐' : '🔒'} {p.avatarName} ({p.farmName})
                        </option>
                      ))}
                    </select>

                    {canProposeActiveTarget && activeNearbyTarget && (
                      <button
                        type="button"
                        disabled={!hasProposalItemId || !canProposeMarriage}
                        title={
                          hasProposalItemId && canProposeMarriage
                            ? 'Propose marriage!'
                            : marriageRequirementsLabel
                        }
                        onClick={() => {
                          if (hasProposalItemId && canProposeMarriage) {
                            onProposePlayer(activeNearbyTarget.uid, activeNearbyTarget.avatarName, hasProposalItemId);
                          }
                        }}
                        className="px-2.5 py-1.5 rounded-lg bg-[#9e3b24] hover:bg-[#7b2a17] disabled:bg-[#cbbca3] disabled:text-[#5c4e3e] text-white text-[11px] font-extrabold flex items-center gap-1 shrink-0 cursor-pointer"
                      >
                        <Heart className="w-3 h-3 fill-current" />
                        {hasProposalItemId && canProposeMarriage ? '💍 Propose' : '💍 Lv.3 + Ring'}
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="rounded-lg bg-[#fae1da] border border-[#d49689] px-2.5 py-1.5 text-[11px] font-bold text-[#751d11]">
                    {language === 'id'
                      ? 'Tambahkan teman di tab Teman atau dekati pemain lain (≤ 2.6m) untuk Chat Privat.'
                      : 'Add a friend in the Friends tab or stand near another player (≤ 2.6m) for Private Chat.'}
                  </div>
                ))}
              {activeBan?.active && activeBan.banType === 'chat_ban' ? (
                <div className="rounded-xl bg-[#fef2f2] border border-[#dc2626] p-2.5 text-[11px] text-[#991b1b] space-y-1">
                  <div className="font-black flex items-center gap-1.5">
                    <ShieldBan className="w-4 h-4 shrink-0" />
                    <span>{language === 'id' ? 'Akun Anda sedang terkena Chat Ban' : 'Your account is currently Chat Banned'}</span>
                  </div>
                  <div className="font-semibold">
                    {language === 'id' ? 'Alasan' : 'Reason'}: {activeBan.reason}
                  </div>
                  {activeBan.devMessage && (
                    <div className="text-[10px] opacity-90">
                      {language === 'id' ? 'Pesan Developer' : 'Developer Message'}: {activeBan.devMessage}
                    </div>
                  )}
                  {activeBan.expiresAt && (
                    <div className="text-[10px] font-bold">
                      {language === 'id' ? 'Berakhir pada' : 'Expires at'}: {new Date(activeBan.expiresAt).toLocaleString()}
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex gap-1.5">
                  <input
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    disabled={!canSendPrivate}
                    placeholder={canSendPrivate ? t(language, 'chat.placeholder') : '...'}
                    maxLength={200}
                    className="flex-1 rounded-xl border border-[#bfa070] bg-[#fffaf0] px-3 py-1.5 text-xs font-medium disabled:opacity-60"
                  />
                  <button
                    type="submit"
                    disabled={!canSendPrivate}
                    className="px-3 py-1.5 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#b8ab96] text-white flex items-center justify-center cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              )}
            </form>
          </>
        )}
      </div>
    </DraggableWindow>
  );
};
