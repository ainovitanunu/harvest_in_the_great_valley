import React, { useEffect, useRef, useState } from 'react';
import { GripHorizontal, X } from 'lucide-react';

interface DraggableWindowProps {
  windowId: string;
  title: React.ReactNode;
  icon?: React.ReactNode;
  widthClass?: string;
  defaultOffset?: { x: number; y: number };
  centerOnMount?: boolean;
  headerAccent?: 'walnut' | 'moss' | 'oak';
  zIndexClass?: string;
  onClose: () => void;
  children: React.ReactNode;
}

const STORAGE_PREFIX = 'hgv_win_pos_v1_';

function loadSavedPos(windowId: string): { x: number; y: number } | null {
  try {
    const raw = localStorage.getItem(`${STORAGE_PREFIX}${windowId}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { x?: unknown; y?: unknown };
    if (typeof parsed.x === 'number' && typeof parsed.y === 'number') {
      return { x: parsed.x, y: parsed.y };
    }
    return null;
  } catch {
    return null;
  }
}

function savePos(windowId: string, pos: { x: number; y: number }) {
  try {
    localStorage.setItem(`${STORAGE_PREFIX}${windowId}`, JSON.stringify(pos));
  } catch {
    // ignore storage quota errors
  }
}

export const DraggableWindow: React.FC<DraggableWindowProps> = ({
  windowId,
  title,
  icon,
  widthClass = 'w-[min(94vw,760px)]',
  defaultOffset = { x: 0, y: 0 },
  centerOnMount = false,
  headerAccent = 'walnut',
  zIndexClass = 'z-40',
  onClose,
  children,
}) => {
  const boxRef = useRef<HTMLDivElement | null>(null);
  const dragStateRef = useRef<{
    active: boolean;
    pointerId: number | null;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  }>({ active: false, pointerId: null, startX: 0, startY: 0, origX: 0, origY: 0 });

  const [pos, setPos] = useState<{ x: number; y: number }>(() => {
    if (!centerOnMount) {
      const saved = loadSavedPos(windowId);
      if (saved) return saved;
    }
    const initW = Math.min(window.innerWidth * 0.92, 620);
    const initH = Math.min(window.innerHeight * 0.72, 460);
    return {
      x: Math.max(12, Math.round((window.innerWidth - initW) / 2 + defaultOffset.x)),
      y: Math.max(12, Math.round((window.innerHeight - initH) / 2 + defaultOffset.y)),
    };
  });

  // Center accurately once mounted if centerOnMount=true, and clamp on resize
  useEffect(() => {
    const clampToViewport = (forceCenter = false) => {
      const el = boxRef.current;
      const w = el?.offsetWidth || 360;
      const h = el?.offsetHeight || 240;
      setPos((prev) => {
        const maxX = Math.max(8, window.innerWidth - Math.min(w, window.innerWidth - 16) - 8);
        const maxY = Math.max(8, window.innerHeight - Math.min(h, window.innerHeight - 16) - 8);
        if (forceCenter) {
          const cx = Math.max(8, Math.min(maxX, Math.round((window.innerWidth - w) / 2 + defaultOffset.x)));
          const cy = Math.max(8, Math.min(maxY, Math.round((window.innerHeight - h) / 2 + defaultOffset.y)));
          return { x: cx, y: cy };
        }
        const cx = Math.max(8, Math.min(prev.x, maxX));
        const cy = Math.max(8, Math.min(prev.y, maxY));
        if (cx === prev.x && cy === prev.y) return prev;
        if (!centerOnMount) savePos(windowId, { x: cx, y: cy });
        return { x: cx, y: cy };
      });
    };
    clampToViewport(centerOnMount);
    const onResize = () => clampToViewport(false);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [windowId, centerOnMount, defaultOffset.x, defaultOffset.y]);

  useEffect(() => {
    const onPointerMove = (e: PointerEvent) => {
      const ds = dragStateRef.current;
      if (!ds.active) return;
      if (ds.pointerId !== null && e.pointerId !== ds.pointerId) return;
      const el = boxRef.current;
      const w = el?.offsetWidth || 360;
      const h = el?.offsetHeight || 200;
      const maxX = Math.max(8, window.innerWidth - Math.min(w, window.innerWidth - 16) - 8);
      const maxY = Math.max(8, window.innerHeight - Math.min(h, window.innerHeight - 16) - 8);
      const nx = Math.max(8, Math.min(maxX, ds.origX + (e.clientX - ds.startX)));
      const ny = Math.max(8, Math.min(maxY, ds.origY + (e.clientY - ds.startY)));
      setPos({ x: nx, y: ny });
    };

    const onPointerUp = (e: PointerEvent) => {
      const ds = dragStateRef.current;
      if (!ds.active) return;
      if (ds.pointerId !== null && e.pointerId !== ds.pointerId) return;
      ds.active = false;
      ds.pointerId = null;
      setPos((latest) => {
        if (!centerOnMount) savePos(windowId, latest);
        return latest;
      });
    };

    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('pointercancel', onPointerUp);
    return () => {
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('pointercancel', onPointerUp);
    };
  }, [windowId, centerOnMount]);

  return (
    <div className={`fixed inset-0 ${zIndexClass} pointer-events-none`}>
      <div
        ref={boxRef}
        style={{ left: `${pos.x}px`, top: `${pos.y}px` }}
        className={`gv-window fixed pointer-events-auto ${widthClass} max-h-[86vh] flex flex-col overflow-hidden`}
      >
        {/* Theme-aware ornamental corner accents */}
        <span className="gv-corner-tl" aria-hidden="true" />
        <span className="gv-corner-tr" aria-hidden="true" />
        <span className="gv-corner-bl" aria-hidden="true" />
        <span className="gv-corner-br" aria-hidden="true" />

        <div
          data-accent={headerAccent}
          onPointerDown={(e) => {
            if ((e.target as HTMLElement).closest('button')) return;
            e.preventDefault();
            dragStateRef.current = {
              active: true,
              pointerId: e.pointerId,
              startX: e.clientX,
              startY: e.clientY,
              origX: pos.x,
              origY: pos.y,
            };
          }}
          className="gv-window-header px-4 py-2.5 flex items-center justify-between select-none touch-none cursor-grab active:cursor-grabbing shrink-0"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <GripHorizontal className="w-4 h-4 opacity-80 shrink-0" />
            {icon && <span className="shrink-0">{icon}</span>}
            <div className="font-extrabold text-sm sm:text-base tracking-tight truncate">{title}</div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-[#b33827] hover:bg-[#8f291b] border border-white/40 flex items-center justify-center cursor-pointer shrink-0 transition-colors"
            aria-label="Close Window"
          >
            <X className="w-4 h-4 text-white stroke-[2.8]" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
};
