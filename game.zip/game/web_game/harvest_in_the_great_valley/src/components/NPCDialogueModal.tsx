import React, { useEffect, useState } from 'react';
import { Gift, Heart, MessageCircle, Scissors, ScrollText, ShoppingBag, Sparkles } from 'lucide-react';
import { HAIR_COLORS_CATALOG, HAIR_STYLES_CATALOG } from '../game/data/hairstyles';
import { ITEMS } from '../game/data/itemsAndCrops';
import { NPC_MAP, getFriendshipTier, pickDynamicDialogue } from '../game/data/npcs';
import { QUESTS, getBarnCapacity, getCoopCapacity, getIncubatorCount } from '../game/data/worldConfig';
import { t } from '../game/i18n';
import { localizeNpcDialogue } from '../game/localizationManager';
import type {
  AnimalState,
  AvatarConfig,
  BranchingDialogueChoice,
  BranchingDialogueNode,
  FestivalDef,
  HairStyleId,
  InventorySlot,
  Language,
  MarketPriceEntry,
  NPCData,
  NPCRelationshipState,
  Season,
  Weather,
} from '../game/types';
import { DraggableWindow } from './DraggableWindow';

const HAIR_SALON_GOLD_COST = 350;

interface NPCDialogueModalProps {
  language?: Language;
  npc: NPCData;
  initialTab?: 'talk' | 'gift' | 'shop' | 'quest';
  nextGiftJoyAmount?: number;
  relationship: NPCRelationshipState;
  season: Season;
  weather?: Weather;
  day: number;
  hour: number;
  isRainy: boolean;
  isMarriedToPlayer: boolean;
  playerGold: number;
  playerDiamond: number;
  currentAvatar?: AvatarConfig;
  houseLevel: number;
  barnLevel: number;
  coopLevel: number;
  hasCheeseMaker?: boolean;
  hasPhone?: boolean;
  animals?: AnimalState[];
  defaultDogName?: string;
  defaultHorseName?: string;
  activeFestival?: FestivalDef | null;
  festivalAttendedToday?: boolean;
  inventory: InventorySlot[];
  completedQuestIds: string[];
  marketPrices?: Record<string, MarketPriceEntry>;
  branchingDialogues?: BranchingDialogueNode[];
  onDialogueChoiceEffect?: (npcId: string, choice: BranchingDialogueChoice) => void;
  onGiveGift: (npcId: string, itemId: string) => string;
  onBuyItem: (itemId: string) => void;
  onSellItem?: (slotIndex: number) => void;
  onApplyHaircut?: (hairStyle: HairStyleId, hairColor: string, goldCost: number) => void;
  onUpgradeTool: (slotIndex: number) => void;
  onUpgradeHouse: () => void;
  onUpgradeBarn: () => void;
  onUpgradeCoop: () => void;
  onBuyAnimal: (type: 'cow' | 'chicken' | 'sheep' | 'dog' | 'horse', customName: string) => void;
  onJoinFestival?: (festival: FestivalDef) => void;
  onCompleteQuest: (questId: string) => void;
  onPropose: (npcId: string) => void;
  onClose: () => void;
}

export const NPCDialogueModal: React.FC<NPCDialogueModalProps> = ({
  language = 'en',
  npc,
  initialTab = 'talk',
  nextGiftJoyAmount = 10,
  relationship,
  season,
  weather = 'Sunny',
  day,
  hour,
  isRainy,
  isMarriedToPlayer,
  playerGold,
  playerDiamond,
  currentAvatar,
  houseLevel,
  barnLevel,
  coopLevel,
  hasCheeseMaker = false,
  hasPhone = false,
  animals = [],
  defaultDogName = 'Biscuit',
  defaultHorseName = 'Maple',
  activeFestival = null,
  festivalAttendedToday = false,
  inventory,
  completedQuestIds,
  marketPrices,
  branchingDialogues = [],
  onDialogueChoiceEffect,
  onGiveGift,
  onBuyItem,
  onSellItem,
  onApplyHaircut,
  onUpgradeTool,
  onUpgradeHouse,
  onUpgradeBarn,
  onUpgradeCoop,
  onBuyAnimal,
  onJoinFestival,
  onCompleteQuest,
  onPropose,
  onClose,
}) => {
  const isShopMode = initialTab === 'shop';
  const [tab, setTab] = useState<'talk' | 'gift' | 'shop' | 'quest'>(initialTab);
  const [pendingAnimalType, setPendingAnimalType] = useState<'cow' | 'chicken' | 'sheep' | 'dog' | 'horse' | null>(null);
  const [animalNameInput, setAnimalNameInput] = useState('');
  const [salonGenderFilter, setSalonGenderFilter] = useState<'all' | 'male' | 'female'>('all');
  const [salonHairStyle, setSalonHairStyle] = useState<HairStyleId>(currentAvatar?.hairStyle || 'short');
  const [salonHairColor, setSalonHairColor] = useState<string>(currentAvatar?.hairColor || '#6b3e1b');

  const npcBranchNodes = branchingDialogues.filter((n) => n.npcId === npc.id || n.npcId === '*');
  const pickInitialBranchNode = (): BranchingDialogueNode | null => {
    if (npcBranchNodes.length === 0) return null;
    const matchByContext = npcBranchNodes.find(
      (n) =>
        (isRainy && n.trigger === 'rainy') ||
        (Boolean(activeFestival) && n.trigger === 'festival') ||
        (hour >= 5 && hour < 12 && n.trigger === 'morning') ||
        (hour >= 12 && hour < 17 && n.trigger === 'afternoon') ||
        (hour >= 17 && n.trigger === 'evening') ||
        n.trigger === 'greeting'
    );
    return matchByContext || npcBranchNodes[0] || null;
  };

  const [activeBranchNode, setActiveBranchNode] = useState<BranchingDialogueNode | null>(() => pickInitialBranchNode());
  const [choiceFeedback, setChoiceFeedback] = useState<string | null>(null);

  const getNodeLocalizedText = (node: BranchingDialogueNode): string | undefined => {
    const map = node.textByLang || node.text;
    return map?.[language] || map?.en || map?.id;
  };

  const buildLocalizedDefaultLine = (dayOffset = 0, hourOffset = 0) => {
    const englishFallback = pickDynamicDialogue(
      npc,
      relationship,
      season,
      day + dayOffset,
      (hour + hourOffset) % 24,
      isRainy,
      isMarriedToPlayer
    );
    return localizeNpcDialogue(language, {
      npcName: npc.name,
      profession: npc.profession,
      fallbackEnglish: englishFallback,
      season,
      hour: (hour + hourOffset) % 24,
      weather: isRainy ? 'Rainy' : weather,
      isBirthday: npc.birthday.season === season && npc.birthday.day === day,
      isMarried: isMarriedToPlayer,
      friendshipPoints: relationship.friendshipPoints,
    });
  };

  const [dialogueText, setDialogueText] = useState<string>(() => {
    const node = pickInitialBranchNode();
    if (node) {
      return getNodeLocalizedText(node) || buildLocalizedDefaultLine();
    }
    return buildLocalizedDefaultLine();
  });

  useEffect(() => {
    setTab(initialTab);
    setPendingAnimalType(null);
    setChoiceFeedback(null);
    if (currentAvatar) {
      setSalonHairStyle(currentAvatar.hairStyle);
      setSalonHairColor(currentAvatar.hairColor);
    }
    const node = pickInitialBranchNode();
    setActiveBranchNode(node);
    if (node) {
      setDialogueText(getNodeLocalizedText(node) || buildLocalizedDefaultLine());
    } else {
      setDialogueText(buildLocalizedDefaultLine());
    }
  }, [npc.id, initialTab, language]);

  const chickenCount = animals.filter((a) => a.type === 'chicken').length;
  const coopMax = getCoopCapacity(coopLevel);
  const barnAnimalCount = animals.filter((a) => a.type === 'cow' || a.type === 'sheep').length;
  const barnMax = getBarnCapacity(barnLevel);
  const dogCount = animals.filter((a) => a.type === 'dog').length;
  const horseCount = animals.filter((a) => a.type === 'horse').length;
  const isId = language === 'id';
  const isFestivalLiveNow =
    Boolean(activeFestival) &&
    hour >= (activeFestival?.startHour ?? 10) &&
    hour <= (activeFestival?.endHour ?? 18);

  const isBirthday = npc.birthday.season === season && npc.birthday.day === day;
  const tier = getFriendshipTier(relationship.friendshipPoints);
  const npcQuests = QUESTS.filter((q) => q.npcId === npc.id && !completedQuestIds.includes(q.id));
  const giftableSlots = inventory.filter((s) => ITEMS[s.itemId]?.isGiftable && !ITEMS[s.itemId]?.isProposalItem);
  const proposalSlot = inventory.find(
    (s) => s.itemId === 'item_golden_ring' && s.quantity > 0
  );
  const toolSlots = inventory
    .map((slot, idx) => ({ slot, idx }))
    .filter(({ slot }) => ITEMS[slot.itemId]?.category === 'Tools');

  const sellableSlots = inventory
    .map((slot, idx) => ({ slot, idx, def: ITEMS[slot.itemId] }))
    .filter(({ def }) => def && (marketPrices?.[def.id]?.sellPrice ?? def.sellPrice) > 0);

  const buildingsReady = houseLevel >= 3 && barnLevel >= 3 && coopLevel >= 3;
  const heartsMaxed = relationship.heartLevel >= 10;
  const canProposeNpc =
    npc.isMarriageCandidate &&
    !isMarriedToPlayer &&
    heartsMaxed &&
    buildingsReady &&
    Boolean(proposalSlot);

  const headerTitle = (
    <div className="flex flex-wrap items-center gap-2">
      <span>{npc.name}</span>
      <span className="text-[11px] px-2 py-0.5 rounded-lg bg-[#244418] text-[#e8f5d8] font-bold">
        {isShopMode ? `${isId ? 'Toko & Layanan' : 'Shop & Services'} · ${npc.profession}` : npc.profession}
      </span>
      {isBirthday && (
        <span className="text-[11px] px-2 py-0.5 rounded-lg bg-[#f2cf7e] text-[#3c2310] font-extrabold">
          🎂 {isId ? 'Ulang Tahun!' : 'Birthday!'}
        </span>
      )}
    </div>
  );

  return (
    <DraggableWindow
      windowId={isShopMode ? 'npc_shop' : 'npc_dialogue'}
      title={headerTitle}
      icon={
        <div
          className="w-7 h-7 rounded-lg border border-[#f5d8aa] flex items-center justify-center text-sm font-black text-white"
          style={{ backgroundColor: npc.appearance.outfitColor }}
        >
          {npc.name[0]}
        </div>
      }
      widthClass="w-[min(94vw,680px)]"
      headerAccent={isShopMode ? 'oak' : 'moss'}
      onClose={onClose}
    >
      <div className="p-4 space-y-3.5 text-[#2b1a0e]">
        {/* Relationship Bar (shown in E Social Mode) */}
        {!isShopMode && (
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-[#efe2c6] border border-[#d3bc92] px-3 py-2 text-xs">
            <span className="font-extrabold text-[#4b2d16]">
              FP: {relationship.friendshipPoints}/1000 ({tier})
            </span>
            {npc.isMarriageCandidate && (
              <span className="flex items-center gap-1 font-extrabold text-[#9e3b24]">
                <Heart className="w-3.5 h-3.5 fill-[#c8432b] text-[#c8432b]" />
                {isMarriedToPlayer
                  ? 'Married Partner'
                  : `Hearts ${relationship.heartLevel}/10 (${relationship.romanceStage})`}
              </span>
            )}
          </div>
        )}

        {/* Strict Separation: E = Social Tabs ONLY; F = Shop & Services ONLY */}
        {!isShopMode ? (
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => setTab('talk')}
              className={`px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border cursor-pointer ${
                tab === 'talk' ? 'bg-[#f2cf7e] border-[#b8711e] text-[#3c2310]' : 'bg-[#efe2c6] border-[#d3bc92] text-[#5c3c22]'
              }`}
            >
              <MessageCircle className="w-3.5 h-3.5" /> {isId ? 'Bicara' : 'Talk'}
            </button>
            <button
              type="button"
              onClick={() => setTab('gift')}
              className={`px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border cursor-pointer ${
                tab === 'gift' ? 'bg-[#f2cf7e] border-[#b8711e] text-[#3c2310]' : 'bg-[#efe2c6] border-[#d3bc92] text-[#5c3c22]'
              }`}
            >
              <Gift className="w-3.5 h-3.5" /> {isId ? 'Beri Hadiah' : 'Give Gift'}
            </button>
            {npcQuests.length > 0 && (
              <button
                type="button"
                onClick={() => setTab('quest')}
                className={`px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border cursor-pointer ${
                  tab === 'quest' ? 'bg-[#f2cf7e] border-[#b8711e] text-[#3c2310]' : 'bg-[#efe2c6] border-[#d3bc92] text-[#5c3c22]'
                }`}
              >
                <ScrollText className="w-3.5 h-3.5" /> {isId ? 'Misi' : 'Quests'} ({npcQuests.length})
              </button>
            )}
            {npc.isMarriageCandidate && !isMarriedToPlayer && relationship.heartLevel >= 8 && (
              <button
                type="button"
                disabled={!canProposeNpc}
                onClick={() => {
                  onPropose(npc.id);
                  setDialogueText(
                    isId
                      ? 'Ya!! Dengan sepenuh hati, aku mau menikah denganmu dan membangun hidup di Great Valley!'
                      : 'Yes!! With all my heart, I will marry you and share our life in Great Valley!'
                  );
                }}
                className="px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 bg-[#9e3b24] hover:bg-[#7b2a17] disabled:bg-[#cbbca3] disabled:text-[#5c4e3e] text-white border border-[#6d2211] cursor-pointer disabled:cursor-not-allowed"
              >
                <Sparkles className="w-3.5 h-3.5" /> {isId ? 'Lamar Menikah' : 'Propose Marriage'}
              </button>
            )}
          </div>
        ) : (
          <div className="flex items-center justify-between rounded-xl bg-[#efe2c6] border border-[#d3bc92] px-3 py-2 text-xs font-extrabold">
            <span className="flex items-center gap-1.5 text-[#4b2d16]">
              <ShoppingBag className="w-4 h-4 text-[#3a6b2c]" />{' '}
              {isId ? 'Toko & Layanan (Harga Pasar Langsung)' : 'Shop & Services (Live Supply & Demand)'}
            </span>
            <span className="tabular-nums">💰 {playerGold.toLocaleString()} G · 💎 {playerDiamond}</span>
          </div>
        )}

        {/* Marriage Prerequisite Reminder for candidates near max hearts */}
        {!isShopMode && npc.isMarriageCandidate && !isMarriedToPlayer && relationship.heartLevel >= 7 && (
          <div className="rounded-xl border border-[#d3bc92] bg-[#fae8c4]/70 px-3 py-2 text-[11px] font-bold text-[#4b2d16]">
            💍 Marriage Checklist:{' '}
            <span className={heartsMaxed ? 'text-[#214617]' : 'text-[#9e3b24]'}>
              {heartsMaxed ? '✓' : '✗'} 10/10 Hearts
            </span>{' '}
            ·{' '}
            <span className={houseLevel >= 3 ? 'text-[#214617]' : 'text-[#9e3b24]'}>
              {houseLevel >= 3 ? '✓' : '✗'} House Lv.{houseLevel}/3
            </span>{' '}
            ·{' '}
            <span className={barnLevel >= 3 ? 'text-[#214617]' : 'text-[#9e3b24]'}>
              {barnLevel >= 3 ? '✓' : '✗'} Barn Lv.{barnLevel}/3
            </span>{' '}
            ·{' '}
            <span className={coopLevel >= 3 ? 'text-[#214617]' : 'text-[#9e3b24]'}>
              {coopLevel >= 3 ? '✓' : '✗'} Coop Lv.{coopLevel}/3
            </span>{' '}
            ·{' '}
            <span className={proposalSlot ? 'text-[#214617]' : 'text-[#9e3b24]'}>
              {proposalSlot ? '✓' : '✗'}{' '}
              {language === 'id' ? 'Cincin Pernikahan (Diamond)' : 'Unity Wedding Ring (Diamond)'}
            </span>
          </div>
        )}

        {/* Tab Content */}
        {!isShopMode && tab === 'talk' && (
          <div className="space-y-3">
            {isFestivalLiveNow && activeFestival && (
              <div className="rounded-xl border-2 border-[#d97706] bg-[#fef3c7] p-3 flex flex-wrap items-center justify-between gap-2">
                <div className="text-xs text-[#451a03]">
                  <div className="font-black">🎪 {activeFestival.name}</div>
                  <div className="text-[11px] font-semibold text-[#78350f]">{activeFestival.description}</div>
                </div>
                {onJoinFestival && (
                  <button
                    type="button"
                    disabled={festivalAttendedToday}
                    onClick={() => {
                      onJoinFestival(activeFestival);
                      setDialogueText(
                        language === 'id'
                          ? `Selamat merayakan ${activeFestival.name}! Seluruh warga desa sangat senang berkumpul bersamamu di alun-alun!`
                          : `Happy ${activeFestival.name}! Every villager in town is thrilled to celebrate with you at the square!`
                      );
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-[#d97706] hover:bg-[#b45309] disabled:bg-[#96b884] text-white text-xs font-extrabold cursor-pointer disabled:cursor-default shrink-0"
                  >
                    {festivalAttendedToday
                      ? language === 'id'
                        ? '✅ Sudah Merayakan'
                        : '✅ Celebrated!'
                      : `🎉 ${t(language, 'festival.joinEvent')} (+${activeFestival.rewardGold} G)`}
                  </button>
                )}
              </div>
            )}

            <div className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-4 text-sm leading-relaxed font-medium shadow-inner">
              &ldquo;{dialogueText}&rdquo;
            </div>

            {choiceFeedback && (
              <div className="rounded-xl px-3 py-1.5 text-xs font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
                {choiceFeedback}
              </div>
            )}

            {/* Branching Dialogue Player Choices (Live from Dev Panel Dialog Editor) */}
            {activeBranchNode && activeBranchNode.choices.length > 0 && (
              <div className="space-y-1.5">
                {activeBranchNode.choices.map((ch) => {
                  const labelMap = ch.labelByLang || ch.label;
                  const label = labelMap?.[language] || labelMap?.en || labelMap?.id || '...';
                  return (
                    <button
                      key={ch.id}
                      type="button"
                      onClick={() => {
                        onDialogueChoiceEffect?.(npc.id, ch);
                        const effects: string[] = [];
                        if (ch.friendshipDelta) effects.push(`${ch.friendshipDelta > 0 ? '+' : ''}${ch.friendshipDelta} FP`);
                        if (ch.affectionDelta) effects.push(`${ch.affectionDelta > 0 ? '+' : ''}${ch.affectionDelta} ❤️`);
                        if (ch.rewardGold) effects.push(`+${ch.rewardGold} G`);
                        if (ch.questId) effects.push(`Quest: ${ch.questId}`);
                        if (effects.length > 0) setChoiceFeedback(effects.join(' · '));

                        const nextNode = ch.nextNodeId
                          ? branchingDialogues.find((n) => n.id === ch.nextNodeId) || null
                          : null;
                        setActiveBranchNode(nextNode);
                        if (nextNode) {
                          setDialogueText(getNodeLocalizedText(nextNode) || buildLocalizedDefaultLine());
                        } else if (ch.replyByLang?.[language] || ch.replyByLang?.en || ch.replyByLang?.id) {
                          setDialogueText(ch.replyByLang[language] || ch.replyByLang.en || ch.replyByLang.id || buildLocalizedDefaultLine(1, 2));
                        } else {
                          setDialogueText(buildLocalizedDefaultLine(1, 2));
                        }
                      }}
                      className="w-full text-left px-3.5 py-2 rounded-xl border border-[#b8711e] bg-[#fae8c4] hover:bg-[#f2cf7e] text-xs font-extrabold text-[#3c2310] transition cursor-pointer flex items-center justify-between gap-2"
                    >
                      <span>▸ {label}</span>
                      {(ch.friendshipDelta || ch.rewardGold) && (
                        <span className="text-[10px] opacity-75">
                          {ch.friendshipDelta ? `${ch.friendshipDelta > 0 ? '+' : ''}${ch.friendshipDelta} FP` : ''}{' '}
                          {ch.rewardGold ? `+${ch.rewardGold}G` : ''}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#5c3c22]">
              <div>
                <span className="font-bold">Social Circle: </span>
                {[...npc.familyIds, ...npc.socialPartnerIds]
                  .map((id) => NPC_MAP[id]?.name)
                  .filter(Boolean)
                  .join(', ') || 'Valley Villagers'}
              </div>
              <button
                type="button"
                onClick={() => {
                  setActiveBranchNode(null);
                  setDialogueText(buildLocalizedDefaultLine(Math.floor(Math.random() * 5), 3));
                }}
                className="px-3.5 py-1.5 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] text-white font-bold cursor-pointer"
              >
                {isId ? 'Ngobrol Lagi' : 'Chat More'}
              </button>
            </div>
          </div>
        )}

        {!isShopMode && tab === 'gift' && (
          <div className="space-y-3">
            <div className="text-xs font-bold text-[#5c3c22] space-y-1">
              <div>
                {language === 'id'
                  ? `Pilih barang dari tas untuk diberikan (Hadiah berikutnya menambah +${nextGiftJoyAmount.toFixed(2).replace(/\.00$/, '')} Kesenangan — berkurang 50% tiap kali hingga hari berganti):`
                  : `Choose an item to gift (Next gift adds +${nextGiftJoyAmount.toFixed(2).replace(/\.00$/, '')} Joy — decays 50% per repeat until tomorrow):`}
              </div>
              <div className="text-[11px] font-semibold text-[#784820] italic">
                {language === 'id'
                  ? '✨ Setiap warga punya barang favorit rahasia — temukan sendiri lewat hadiah untuk bonus kesenangan ekstra!'
                  : '✨ Every villager has secret favorite gifts — discover them by gifting to earn extra Friendship & Joy!'}
              </div>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-48 overflow-y-auto">
              {giftableSlots.map((slot) => {
                const def = ITEMS[slot.itemId];
                return (
                  <button
                    key={slot.itemId}
                    type="button"
                    onClick={() => {
                      const reaction = onGiveGift(npc.id, slot.itemId);
                      setDialogueText(reaction);
                      setTab('talk');
                    }}
                    className="rounded-xl border-2 border-[#d3bc92] bg-[#fffaf0] hover:border-[#3a6b2c] p-2 flex flex-col items-center gap-1 cursor-pointer"
                  >
                    <span className="text-2xl">{def.iconEmoji}</span>
                    <span className="text-[11px] font-bold truncate w-full text-center">{def.name}</span>
                    <span className="text-[10px] text-[#6e4624]">x{slot.quantity}</span>
                  </button>
                );
              })}
              {giftableSlots.length === 0 && (
                <p className="col-span-full text-xs text-[#6e4624]">
                  {language === 'id' ? 'Tidak ada barang hadiah di tas.' : 'No giftable items in your bag.'}
                </p>
              )}
            </div>
          </div>
        )}

        {isShopMode && (
          <div className="space-y-3 max-h-88 overflow-y-auto pr-1">
            {npc.shopInventoryIds?.map((itemId) => {
              const def = ITEMS[itemId];
              if (!def) return null;
              const isDiamondPriced = Boolean(def.diamondPrice && def.buyPrice === 0);
              const isOwnedPhone = itemId === 'item_valley_phone' && hasPhone;
              const mEntry = marketPrices?.[itemId];
              const liveBuyPrice = mEntry?.buyPrice ?? def.buyPrice;
              const liveDiamondPrice = mEntry?.diamondPrice ?? def.diamondPrice ?? 0;
              const trendIcon = mEntry?.trend === 'up' ? '📈' : mEntry?.trend === 'down' ? '📉' : '';
              const cannotAfford = isDiamondPriced
                ? playerDiamond < liveDiamondPrice
                : playerGold < liveBuyPrice;
              return (
                <div key={itemId} className="flex items-center justify-between gap-2 rounded-xl border border-[#d3bc92] bg-[#fffaf0] px-3 py-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="text-2xl shrink-0">{def.iconEmoji}</span>
                    <div className="min-w-0">
                      <div className="text-sm font-extrabold truncate">
                        {def.name} {trendIcon}
                      </div>
                      <div className="text-[11px] text-[#5c3c22]">{def.description}</div>
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={isOwnedPhone || cannotAfford}
                    onClick={() => onBuyItem(itemId)}
                    className={`px-3 py-1.5 rounded-xl disabled:bg-[#cbbca3] disabled:text-[#5c4e3e] text-white text-xs font-extrabold shrink-0 cursor-pointer disabled:cursor-not-allowed tabular-nums ${
                      isDiamondPriced ? 'bg-[#0284c7] hover:bg-[#0369a1]' : 'bg-[#3a6b2c] hover:bg-[#2d5422]'
                    }`}
                  >
                    {isOwnedPhone
                      ? isId
                        ? '✅ Dimiliki'
                        : '✅ Owned'
                      : isDiamondPriced
                        ? `${isId ? 'Beli' : 'Buy'} (💎 ${liveDiamondPrice})`
                        : `${isId ? 'Beli' : 'Buy'} (${liveBuyPrice.toLocaleString()} G)`}
                  </button>
                </div>
              );
            })}

            {npc.specialService === 'blacksmith' && (
              <div className="space-y-2 pt-2 border-t border-[#d3bc92]">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="text-xs font-extrabold uppercase text-[#5c3c22]">
                    ⚒️ {language === 'id' ? 'Upgrade Alat Pandai Besi (Maks Lv.5)' : 'Blacksmith Tool Upgrades (Max Lv.5)'}
                  </h4>
                  <span className="text-[10px] font-bold text-[#6e4624]">
                    {language === 'id' ? 'Lv.5 butuh Mythril Goa' : 'Lv.5 needs Cave Mythril'}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {toolSlots.map(({ slot, idx }) => {
                    const def = ITEMS[slot.itemId];
                    const lv = slot.toolLevel || 1;
                    const isMax = lv >= 5;
                    const costLabel =
                      lv === 1
                        ? '500 G + 2 Iron'
                        : lv === 2
                          ? '1,200 G + 2 Silver'
                          : lv === 3
                            ? '2,500 G + 2 Gold Ore'
                            : '5,000 G + 2 ✨ Mythril Starstone';
                    return (
                      <button
                        key={`${slot.itemId}_${idx}`}
                        type="button"
                        disabled={isMax}
                        onClick={() => onUpgradeTool(idx)}
                        className="px-3 py-2 rounded-xl bg-[#4b382a] hover:bg-[#36271d] disabled:bg-[#96b884] text-white text-xs font-bold flex flex-col gap-0.5 text-left cursor-pointer disabled:cursor-default"
                      >
                        <div className="flex items-center justify-between w-full">
                          <span>{def.iconEmoji} {def.name}</span>
                          <span className="font-black text-[#f5cc74]">
                            {isMax ? '✅ MAX Lv.5' : `Lv.${lv} → Lv.${lv + 1}`}
                          </span>
                        </div>
                        {!isMax && (
                          <span className="text-[10px] text-[#f7eedc]/85 font-semibold">
                            {costLabel}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {npc.specialService === 'carpenter' && (
              <div className="pt-2 border-t border-[#d3bc92] space-y-2">
                <h4 className="text-xs font-extrabold uppercase text-[#5c3c22]">
                  Homestead Carpentry Upgrades (Required Lv.3 for Marriage)
                </h4>
                <button
                  type="button"
                  disabled={houseLevel >= 3}
                  onClick={onUpgradeHouse}
                  className="w-full py-2.5 px-3 rounded-xl bg-[#b8711e] hover:bg-[#965a14] disabled:bg-[#96b884] text-white font-extrabold text-xs cursor-pointer disabled:cursor-default"
                >
                  {houseLevel >= 3
                    ? '✅ Farmhouse Max Level (Lv.3)'
                    : `🏡 Upgrade Farmhouse Lv.${houseLevel} → Lv.${houseLevel + 1} (${houseLevel * 1200} G + ${houseLevel * 10} Timber + ${houseLevel * 5} Stone)`}
                </button>
                <button
                  type="button"
                  disabled={barnLevel >= 3}
                  onClick={onUpgradeBarn}
                  className="w-full py-2.5 px-3 rounded-xl bg-[#784820] hover:bg-[#5c3616] disabled:bg-[#96b884] text-white font-extrabold text-xs cursor-pointer disabled:cursor-default"
                >
                  {barnLevel >= 3
                    ? '✅ Cow & Sheep Barn Max Lv.3 (20 Troughs · Cheese Maker Unlocked)'
                    : `🐄 Upgrade Barn Lv.${barnLevel} → Lv.${barnLevel + 1} (${getBarnCapacity(barnLevel)} → ${getBarnCapacity(barnLevel + 1)} Troughs · ${barnLevel * 1000} G + ${barnLevel * 8} Timber + ${barnLevel * 4} Stone)`}
                </button>
                <button
                  type="button"
                  disabled={coopLevel >= 3}
                  onClick={onUpgradeCoop}
                  className="w-full py-2.5 px-3 rounded-xl bg-[#8d5224] hover:bg-[#6e3e19] disabled:bg-[#96b884] text-white font-extrabold text-xs cursor-pointer disabled:cursor-default"
                >
                  {coopLevel >= 3
                    ? '✅ Chicken Coop Max Lv.3 (20 Troughs · 2 Egg Incubators)'
                    : `🐔 Upgrade Coop Lv.${coopLevel} → Lv.${coopLevel + 1} (${getCoopCapacity(coopLevel)} → ${getCoopCapacity(coopLevel + 1)} Troughs · ${getIncubatorCount(coopLevel + 1)} Incubator${getIncubatorCount(coopLevel + 1) > 1 ? 's' : ''} · ${coopLevel * 800} G + ${coopLevel * 6} Timber + ${coopLevel * 3} Stone)`}
                </button>
              </div>
            )}

            {npc.specialService === 'ranch' && (
              <div className="space-y-2.5 pt-2 border-t border-[#d3bc92]">
                <div className="text-[11px] font-bold text-[#3a6b2c] bg-[#e7f1df] border border-[#96b884] px-3 py-1.5 rounded-lg space-y-0.5">
                  <div>
                    🐔 {isId ? 'Kandang Ayam' : 'Coop'} Lv.{coopLevel}: <strong>{chickenCount}/{coopMax}</strong> · 🐄🐑 {isId ? 'Kandang Sapi & Domba' : 'Barn'} Lv.{barnLevel}: <strong>{barnAnimalCount}/{barnMax}</strong>
                  </div>
                  <div>
                    🐕 {isId ? 'Anjing (Maks 1)' : 'Dog (Max 1)'}: <strong>{dogCount}/1</strong> · 🐎 {isId ? 'Kuda (Maks 1)' : 'Horse (Max 1)'}: <strong>{horseCount}/1</strong>
                  </div>
                  <div className="text-[10px]">
                    {isId
                      ? 'Setiap hewan wajib diberi nama saat dibeli; ulang tahunnya otomatis tercatat di hari pembelian! Jangan lupa beri makan agar tidak sakit.'
                      : 'Name every animal on purchase; its birthday is recorded as today! Feed daily so animals stay healthy.'}
                  </div>
                </div>

                {/* Inline Mandatory Animal Naming Panel */}
                {pendingAnimalType && (
                  <form
                    className="rounded-xl border-2 border-[#b8711e] bg-[#fef3c7] p-3 space-y-2"
                    onSubmit={(e) => {
                      e.preventDefault();
                      const clean = animalNameInput.trim();
                      if (!clean) return;
                      onBuyAnimal(pendingAnimalType, clean);
                      setPendingAnimalType(null);
                      setAnimalNameInput('');
                    }}
                  >
                    <div className="text-xs font-extrabold text-[#451a03]">
                      {isId
                        ? `Beri nama untuk ${pendingAnimalType.toUpperCase()} barumu (Ultah: ${season} ${day}):`
                        : `Name your new ${pendingAnimalType.toUpperCase()} (Birthday: ${season} ${day}):`}
                    </div>
                    <div className="flex gap-2">
                      <input
                        required
                        autoFocus
                        maxLength={20}
                        value={animalNameInput}
                        onChange={(e) => setAnimalNameInput(e.target.value)}
                        placeholder={isId ? 'Masukkan nama hewan...' : 'Enter animal name...'}
                        className="flex-1 rounded-lg border border-[#b8711e] bg-white px-2.5 py-1.5 text-xs font-bold"
                      />
                      <button
                        type="submit"
                        className="px-3 py-1.5 rounded-lg bg-[#3a6b2c] hover:bg-[#2d5422] text-white text-xs font-extrabold cursor-pointer"
                      >
                        {isId ? 'Beli' : 'Confirm'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setPendingAnimalType(null)}
                        className="px-2.5 py-1.5 rounded-lg bg-[#e5d3b0] text-[#4b2d16] text-xs font-bold cursor-pointer"
                      >
                        ✕
                      </button>
                    </div>
                  </form>
                )}

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  <button
                    type="button"
                    disabled={chickenCount >= coopMax}
                    onClick={() => {
                      setPendingAnimalType('chicken');
                      setAnimalNameInput(`Cluckie ${chickenCount + 1}`);
                    }}
                    className="py-2 px-2 rounded-xl bg-[#d98a2b] hover:bg-[#b8711e] disabled:bg-[#cbbca3] text-white font-extrabold text-xs cursor-pointer disabled:cursor-not-allowed"
                  >
                    🐔 {isId ? 'Ayam' : 'Chicken'} (350 G)
                  </button>
                  <button
                    type="button"
                    disabled={barnAnimalCount >= barnMax}
                    onClick={() => {
                      setPendingAnimalType('sheep');
                      setAnimalNameInput(`Woolly ${barnAnimalCount + 1}`);
                    }}
                    className="py-2 px-2 rounded-xl bg-[#784820] hover:bg-[#5c3616] disabled:bg-[#cbbca3] text-white font-extrabold text-xs cursor-pointer disabled:cursor-not-allowed"
                  >
                    🐑 {isId ? 'Domba' : 'Sheep'} (700 G)
                  </button>
                  <button
                    type="button"
                    disabled={barnAnimalCount >= barnMax}
                    onClick={() => {
                      setPendingAnimalType('cow');
                      setAnimalNameInput(`Bessie ${barnAnimalCount + 1}`);
                    }}
                    className="py-2 px-2 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#cbbca3] text-white font-extrabold text-xs cursor-pointer disabled:cursor-not-allowed"
                  >
                    🐄 {isId ? 'Sapi' : 'Cow'} (1,000 G)
                  </button>
                  <button
                    type="button"
                    disabled={dogCount >= 1}
                    onClick={() => {
                      setPendingAnimalType('dog');
                      setAnimalNameInput(defaultDogName);
                    }}
                    className="py-2 px-2 rounded-xl bg-[#8d5224] hover:bg-[#6e3e19] disabled:bg-[#cbbca3] text-white font-extrabold text-xs cursor-pointer disabled:cursor-not-allowed"
                  >
                    {dogCount >= 1
                      ? isId
                        ? '🐕 Anjing (Maks 1/1)'
                        : '🐕 Dog (Max 1/1)'
                      : `🐕 ${isId ? 'Anjing' : 'Dog'} (800 G)`}
                  </button>
                  <button
                    type="button"
                    disabled={horseCount >= 1}
                    onClick={() => {
                      setPendingAnimalType('horse');
                      setAnimalNameInput(defaultHorseName);
                    }}
                    className="py-2 px-2 rounded-xl bg-[#4b2d16] hover:bg-[#321b0b] disabled:bg-[#cbbca3] text-white font-extrabold text-xs cursor-pointer disabled:cursor-not-allowed"
                  >
                    {horseCount >= 1
                      ? isId
                        ? '🐎 Kuda (Maks 1/1)'
                        : '🐎 Horse (Max 1/1)'
                      : `🐎 ${isId ? 'Kuda' : 'Horse'} (1,500 G)`}
                  </button>
                </div>

                {/* Artisan Cheese Maker Machine (Requires Cow & Sheep Barn Lv.3) */}
                <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] px-3 py-2 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-2xl">🧀</span>
                    <div className="min-w-0">
                      <div className="text-xs font-extrabold">
                        {ITEMS.item_cheese_maker?.name || 'Artisan Cheese Maker'}
                      </div>
                      <div className="text-[10px] text-[#5c3c22]">
                        {barnLevel < 3
                          ? language === 'id'
                            ? 'Butuh Kandang Sapi & Domba Lv.3 untuk membeli & menempatkan mesin ini.'
                            : 'Requires Cow & Sheep Barn Lv.3 to purchase and install.'
                          : language === 'id'
                            ? 'Olah Susu Segar menjadi Keju Artisan di dalam Kandang Sapi & Domba!'
                            : 'Turns Fresh Milk into Artisan Valley Cheese inside your Lv.3 Barn!'}
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={hasCheeseMaker || barnLevel < 3 || playerGold < (ITEMS.item_cheese_maker?.buyPrice ?? 4500)}
                    onClick={() => onBuyItem('item_cheese_maker')}
                    className="px-3 py-1.5 rounded-xl bg-[#d97706] hover:bg-[#b45309] disabled:bg-[#cbbca3] text-white text-xs font-extrabold shrink-0 cursor-pointer disabled:cursor-not-allowed"
                  >
                    {hasCheeseMaker
                      ? '✅ Installed'
                      : barnLevel < 3
                        ? 'Need Barn Lv.3'
                        : `Buy (${(ITEMS.item_cheese_maker?.buyPrice ?? 4500).toLocaleString()} G)`}
                  </button>
                </div>
              </div>
            )}

            {npc.specialService === 'salon' && onApplyHaircut && (
              <div className="space-y-3 pt-2 border-t border-[#d3bc92]">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h4 className="text-xs font-extrabold uppercase text-[#5c3c22] flex items-center gap-1.5">
                    <Scissors className="w-4 h-4 text-[#9e3b24]" />
                    {t(language, 'salon.title')} ({HAIR_SALON_GOLD_COST} G)
                  </h4>
                  <div className="flex gap-1">
                    {(
                      [
                        ['all', language === 'id' ? 'Semua' : 'All'],
                        ['male', language === 'id' ? 'Pria' : "Men's"],
                        ['female', language === 'id' ? 'Wanita' : "Women's"],
                      ] as const
                    ).map(([flt, label]) => (
                      <button
                        key={flt}
                        type="button"
                        onClick={() => setSalonGenderFilter(flt)}
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold border cursor-pointer ${
                          salonGenderFilter === flt
                            ? 'bg-[#3a6b2c] text-white border-[#214417]'
                            : 'bg-[#fffaf0] text-[#5c3c22] border-[#d3bc92]'
                        }`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] p-3 space-y-2.5">
                  <div>
                    <label className="block text-[11px] font-extrabold text-[#4b2d16] mb-1">
                      {t(language, 'create.hairstyle')} (
                      {
                        HAIR_STYLES_CATALOG.filter(
                          (h) => salonGenderFilter === 'all' || h.gender === salonGenderFilter || h.gender === 'unisex'
                        ).length
                      }
                      )
                    </label>
                    <select
                      value={salonHairStyle}
                      onChange={(e) => setSalonHairStyle(e.target.value as HairStyleId)}
                      className="w-full rounded-lg border border-[#bfa070] bg-white px-2.5 py-1.5 text-xs font-bold"
                    >
                      {HAIR_STYLES_CATALOG.filter(
                        (h) => salonGenderFilter === 'all' || h.gender === salonGenderFilter || h.gender === 'unisex'
                      ).map((h) => (
                        <option key={h.value} value={h.value}>
                          {language === 'id' ? h.id : h.en}
                        </option>
                      ))}
                    </select>
                    {(() => {
                      const chosen = HAIR_STYLES_CATALOG.find((h) => h.value === salonHairStyle);
                      return chosen ? (
                        <p className="text-[10px] text-[#6e4624] mt-1">
                          {language === 'id' ? chosen.descId : chosen.descEn}
                        </p>
                      ) : null;
                    })()}
                  </div>

                  <div>
                    <div className="flex items-center justify-between text-[11px] font-extrabold text-[#4b2d16] mb-1">
                      <span>{t(language, 'create.hairColor')}</span>
                      <span className="text-[#8a4d22]">
                        {(() => {
                          const cDef = HAIR_COLORS_CATALOG.find((c) => c.hex === salonHairColor);
                          return cDef ? (language === 'id' ? cDef.nameId : cDef.nameEn) : salonHairColor;
                        })()}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {HAIR_COLORS_CATALOG.map((c) => (
                        <button
                          key={c.hex}
                          type="button"
                          title={language === 'id' ? c.nameId : c.nameEn}
                          onClick={() => setSalonHairColor(c.hex)}
                          style={{ backgroundColor: c.hex }}
                          className={`w-6 h-6 rounded-full border-2 cursor-pointer ${
                            salonHairColor === c.hex
                              ? 'border-[#2b1a0e] scale-110 ring-2 ring-[#f5cc74]'
                              : 'border-white'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={playerGold < HAIR_SALON_GOLD_COST}
                    onClick={() => onApplyHaircut(salonHairStyle, salonHairColor, HAIR_SALON_GOLD_COST)}
                    className="w-full py-2 rounded-xl bg-[#9e3b24] hover:bg-[#7b2a17] disabled:bg-[#cbbca3] text-white text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer disabled:cursor-not-allowed"
                  >
                    <Scissors className="w-3.5 h-3.5" />
                    {language === 'id'
                      ? `Potong & Warnai Rambut (${HAIR_SALON_GOLD_COST} G)`
                      : `Cut & Color Hair (${HAIR_SALON_GOLD_COST} G)`}
                  </button>
                </div>
              </div>
            )}

            {/* Sell Crops, Materials & Spare Tools back to Shop at 50% Market Value */}
            {onSellItem && sellableSlots.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-[#d3bc92]">
                <h4 className="text-xs font-extrabold uppercase text-[#6e4624]">
                  Sell Crops, Materials &amp; Tools (50% Resell Price)
                </h4>
                <div className="grid sm:grid-cols-2 gap-1.5">
                  {sellableSlots.slice(0, 12).map(({ slot, idx, def }) => {
                    const liveSell = marketPrices?.[def.id]?.sellPrice ?? def.sellPrice;
                    return (
                      <button
                        key={`${slot.itemId}_sell_${idx}`}
                        type="button"
                        onClick={() => onSellItem(idx)}
                        className="flex items-center justify-between rounded-xl border border-[#d3bc92] bg-[#f9f3e4] hover:bg-[#fae8c4] px-2.5 py-1.5 text-xs font-bold cursor-pointer"
                      >
                        <span className="truncate flex items-center gap-1.5">
                          <span>{def.iconEmoji}</span>
                          <span className="truncate">{def.name}</span>
                          {slot.quantity > 1 && <span className="text-[#6e4624]">x{slot.quantity}</span>}
                        </span>
                        <span className="text-[#3a6b2c] font-black shrink-0 tabular-nums">
                          +{liveSell.toLocaleString()} G
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {!isShopMode && tab === 'quest' && (
          <div className="space-y-2.5">
            {npcQuests.map((q) => {
              const reqItem = q.requiredItemId ? ITEMS[q.requiredItemId] : null;
              const playerCount = q.requiredItemId
                ? inventory.find((s) => s.itemId === q.requiredItemId)?.quantity || 0
                : 0;
              const canComplete = !q.requiredItemId || playerCount >= (q.requiredQty || 1);

              return (
                <div key={q.id} className="rounded-2xl border-2 border-[#d3bc92] bg-[#fffaf0] p-3.5 space-y-2">
                  <div className="font-extrabold text-sm">{q.title}</div>
                  <p className="text-xs text-[#5c3c22]">{q.description}</p>
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <span className="text-xs font-bold text-[#3a6b2c]">
                      Reward: {q.rewardGold} G · +{q.rewardFriendship} FP
                    </span>
                    <button
                      type="button"
                      disabled={!canComplete}
                      onClick={() => {
                        onCompleteQuest(q.id);
                        setDialogueText('Wonderful! Thank you so much for your help!');
                        setTab('talk');
                      }}
                      className="px-3.5 py-1.5 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] disabled:bg-[#cbbca3] text-white text-xs font-extrabold cursor-pointer"
                    >
                      {reqItem ? `Deliver ${reqItem.name} (${playerCount}/${q.requiredQty || 1})` : 'Complete'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </DraggableWindow>
  );
};
