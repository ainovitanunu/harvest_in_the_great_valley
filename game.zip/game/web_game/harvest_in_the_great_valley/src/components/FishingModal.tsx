import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Fish, RotateCcw, Sparkles, Timer, Waves } from 'lucide-react';
import { t } from '../game/i18n';
import type { Language } from '../game/types';
import { DraggableWindow } from './DraggableWindow';

interface FishingModalProps {
  spotType?: 'river' | 'ocean';
  hasBait: boolean;
  language?: Language;
  onCatch: (fishId: string) => void;
  onClose: () => void;
}

type FishingPhase = 'waiting' | 'splash_miss' | 'reeling' | 'result';

interface CastRoll {
  luckPct: number; // 0..100
  waitSeconds: number; // 1..300 (1s to 5 minutes)
  requiredStrikes: number; // 1..3
}

function rollCastParameters(hasBait: boolean, isOcean: boolean): CastRoll {
  // Without bait: full 0-100% luck range (including realistic 0% slip-off chance!)
  // With bait: minimum 15% luck up to 100%
  const rawLuck = hasBait
    ? Math.min(100, Math.floor(Math.random() * 86) + 15)
    : Math.random() < 0.08
      ? 0
      : Math.floor(Math.random() * 101);

  // Realistic 1 second to 5 minutes (300s) bite wait distribution:
  // Weighted so quick bites feel natural while slow 1-5 min casts genuinely occur
  const bucket = Math.random();
  let waitSeconds: number;
  if (hasBait) {
    if (bucket < 0.65) waitSeconds = 1 + Math.floor(Math.random() * 12); // 1–12s
    else if (bucket < 0.90) waitSeconds = 13 + Math.floor(Math.random() * 48); // 13–60s
    else waitSeconds = 61 + Math.floor(Math.random() * 240); // 61–300s (up to 5m)
  } else {
    if (bucket < 0.45) waitSeconds = 1 + Math.floor(Math.random() * 18); // 1–18s
    else if (bucket < 0.80) waitSeconds = 19 + Math.floor(Math.random() * 72); // 19–90s
    else waitSeconds = 91 + Math.floor(Math.random() * 210); // 91–300s (up to 5m)
  }
  waitSeconds = Math.max(1, Math.min(300, waitSeconds));

  const requiredStrikes = rawLuck >= 80 ? (isOcean ? 3 : 2) : rawLuck >= 45 ? 2 : 1;
  return { luckPct: rawLuck, waitSeconds, requiredStrikes };
}

function formatClock(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const mm = Math.floor(s / 60);
  const ss = s % 60;
  return `${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}`;
}

function polarToCartesian(cx: number, cy: number, r: number, angleDeg: number) {
  const rad = ((angleDeg - 90) * Math.PI) / 180;
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

function describeArc(cx: number, cy: number, r: number, startAngle: number, endAngle: number): string {
  const start = polarToCartesian(cx, cy, r, endAngle);
  const end = polarToCartesian(cx, cy, r, startAngle);
  const largeArc = endAngle - startAngle <= 180 ? '0' : '1';
  return `M ${start.x.toFixed(2)} ${start.y.toFixed(2)} A ${r} ${r} 0 ${largeArc} 0 ${end.x.toFixed(2)} ${end.y.toFixed(2)}`;
}

function angularDistanceDeg(a: number, b: number): number {
  const diff = Math.abs((((a - b) % 360) + 540) % 360 - 180);
  return diff;
}

export const FishingModal: React.FC<FishingModalProps> = ({
  spotType = 'river',
  hasBait,
  language = 'en',
  onCatch,
  onClose,
}) => {
  const isOcean = spotType === 'ocean';
  const [cast, setCast] = useState<CastRoll>(() => rollCastParameters(hasBait, isOcean));
  const [phase, setPhase] = useState<FishingPhase>('waiting');
  const [elapsedSec, setElapsedSec] = useState(0);
  const [strikesDone, setStrikesDone] = useState(0);
  const [needleDeg, setNeedleDeg] = useState(0);
  const [targetCenterDeg, setTargetCenterDeg] = useState(() => 60 + Math.floor(Math.random() * 240));
  const [result, setResult] = useState<string | null>(null);
  const [caughtSuccess, setCaughtSuccess] = useState(false);

  const needleRef = useRef(0);
  const spinDirRef = useRef(1);
  const rafRef = useRef<number | null>(null);
  const lastTsRef = useRef(0);

  // Target arc half-width in degrees (wider with bait & higher luck, tighter for rare ocean bites)
  const targetHalfArc = Math.max(
    18,
    Math.min(44, (hasBait ? 36 : 28) + Math.round((cast.luckPct - 50) * 0.12) - (isOcean ? 4 : 0))
  );

  // Phase 1: Live realistic wait timer (1s – 5 minutes)
  useEffect(() => {
    if (phase !== 'waiting') return;
    const startedAt = Date.now();
    setElapsedSec(0);

    const interval = window.setInterval(() => {
      const secs = (Date.now() - startedAt) / 1000;
      setElapsedSec(secs);
      if (secs >= cast.waitSeconds) {
        window.clearInterval(interval);
        if (cast.luckPct <= 0) {
          // 0% Luck: fish splashes/bites and slips right off!
          setPhase('splash_miss');
        } else {
          needleRef.current = 0;
          spinDirRef.current = Math.random() < 0.5 ? 1 : -1;
          lastTsRef.current = performance.now();
          setNeedleDeg(0);
          setStrikesDone(0);
          setTargetCenterDeg(55 + Math.floor(Math.random() * 250));
          setPhase('reeling');
        }
      }
    }, 120);

    return () => window.clearInterval(interval);
  }, [phase, cast]);

  // Phase 1b: 0% Luck Splash Slip animation -> Result
  useEffect(() => {
    if (phase !== 'splash_miss') return;
    const timer = window.setTimeout(() => {
      setCaughtSuccess(false);
      setResult(
        language === 'id'
          ? '💦 Keberuntungan 0%! Ikan sempat menyambar kail tetapi langsung terlepas sebelum sempat ditarik.'
          : '💦 0% Cast Luck! A fish nibbled the hook and slipped right off before you could set the line.'
      );
      setPhase('result');
    }, 1450);
    return () => window.clearTimeout(timer);
  }, [phase, language]);

  // Phase 2: Rotating Compass/Tension Dial (60fps RAF)
  useEffect(() => {
    if (phase !== 'reeling') return;
    const baseDegPerSec = (isOcean ? 210 : 175) + strikesDone * 34;
    const step = (now: number) => {
      const dt = Math.min(0.05, (now - lastTsRef.current) / 1000);
      lastTsRef.current = now;
      const next = (((needleRef.current + spinDirRef.current * baseDegPerSec * dt) % 360) + 360) % 360;
      needleRef.current = next;
      setNeedleDeg(next);
      rafRef.current = requestAnimationFrame(step);
    };
    lastTsRef.current = performance.now();
    rafRef.current = requestAnimationFrame(step);
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    };
  }, [phase, isOcean, strikesDone]);

  const finishCatch = useCallback(
    (isBullseye: boolean) => {
      const luckFactor = cast.luckPct / 100;
      const cm = Math.round(24 + luckFactor * 42 + (isBullseye ? 16 : 0) + Math.random() * 14);
      if (isOcean) {
        const roll = Math.random() * 0.65 + luckFactor * 0.35;
        let fishId = 'fish_coral_snapper';
        let name = 'Coral Reef Snapper';
        if (isBullseye || roll > 0.78) {
          fishId = 'fish_midnight_squid';
          name = 'Midnight Luminous Squid';
        } else if (roll > 0.48) {
          fishId = 'fish_ocean_tuna';
          name = 'Bluefin Ocean Tuna';
        }
        setCaughtSuccess(true);
        setResult(
          language === 'id'
            ? `🐟 Mantap! Kamu menangkap ${name} (${cm} cm · Luck ${cast.luckPct}%)${isBullseye ? ' — Bullseye!' : ''}`
            : `🐟 Catch! You landed a ${name} (${cm} cm · ${cast.luckPct}% Luck)${isBullseye ? ' — Bullseye!' : ''}`
        );
        setPhase('result');
        onCatch(fishId);
      } else {
        const isRare = isBullseye || luckFactor > 0.72 || (hasBait && Math.random() < 0.35);
        const fishId = isRare ? 'fish_golden_koi' : 'fish_river_trout';
        const name = isRare ? 'Golden River Koi' : 'River Trout';
        setCaughtSuccess(true);
        setResult(
          language === 'id'
            ? `🐠 Luar biasa! Kamu mendapatkan ${name} (${cm} cm · Luck ${cast.luckPct}%)${isBullseye ? ' — Bullseye!' : ''}`
            : `🐠 Great catch! You landed a ${name} (${cm} cm · ${cast.luckPct}% Luck)${isBullseye ? ' — Bullseye!' : ''}`
        );
        setPhase('result');
        onCatch(fishId);
      }
    },
    [cast.luckPct, isOcean, hasBait, language, onCatch]
  );

  const handleStrike = useCallback(() => {
    if (phase !== 'reeling') return;
    const dist = angularDistanceDeg(needleRef.current, targetCenterDeg);
    if (dist <= targetHalfArc) {
      const isBullseye = dist <= 8;
      const nextStrikes = strikesDone + 1;
      if (nextStrikes >= cast.requiredStrikes) {
        finishCatch(isBullseye);
      } else {
        setStrikesDone(nextStrikes);
        spinDirRef.current = -spinDirRef.current;
        setTargetCenterDeg((prev) => (prev + 115 + Math.floor(Math.random() * 120)) % 360);
      }
    } else {
      setCaughtSuccess(false);
      setResult(
        language === 'id'
          ? '💦 Tarikan meleset! Ikan berhasil melepaskan diri dari kail.'
          : '💦 Missed the tension arc! The fish broke free from the line.'
      );
      setPhase('result');
    }
  }, [phase, targetCenterDeg, targetHalfArc, strikesDone, cast.requiredStrikes, finishCatch, language]);

  const handleCastAgain = useCallback(() => {
    setResult(null);
    setCaughtSuccess(false);
    setStrikesDone(0);
    setCast(rollCastParameters(hasBait, isOcean));
    setPhase('waiting');
  }, [hasBait, isOcean]);

  // Keyboard support: Space / F / Enter to strike or recast
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'KeyF' || e.code === 'Enter') {
        e.preventDefault();
        if (phase === 'reeling') handleStrike();
        else if (phase === 'result') handleCastAgain();
      } else if (e.code === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [phase, handleStrike, handleCastAgain, onClose]);

  const needleTip = polarToCartesian(100, 100, 74, needleDeg);
  const greenArcPath = describeArc(100, 100, 72, targetCenterDeg - targetHalfArc, targetCenterDeg + targetHalfArc);
  const goldArcPath = describeArc(100, 100, 72, targetCenterDeg - 7, targetCenterDeg + 7);

  return (
    <DraggableWindow
      windowId="fishing"
      centerOnMount
      title={isOcean ? t(language, 'fishing.oceanTitle') : t(language, 'fishing.riverTitle')}
      icon={<Fish className="w-5 h-5 text-[#f5cc74]" />}
      widthClass="w-[min(92vw,440px)]"
      headerAccent="oak"
      onClose={onClose}
    >
      <div className="p-5 space-y-4 text-center text-[#2b1a0e]">
        {/* Cast Status Strip: Luck % + Water Type */}
        <div className="rounded-xl border border-[#d3bc92] bg-[#fffaf0] px-3 py-2 flex items-center justify-between gap-2 text-[11px] font-bold">
          <span className="truncate">
            {isOcean
              ? language === 'id'
                ? '🌊 Laut Dalam'
                : '🌊 Ocean Pier'
              : language === 'id'
                ? '🏞️ Sungai Lembah'
                : '🏞️ Valley River'}
          </span>
          <span
            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg font-black tabular-nums ${
              cast.luckPct === 0
                ? 'bg-red-100 text-red-700 border border-red-300'
                : cast.luckPct >= 75
                  ? 'bg-amber-100 text-amber-800 border border-amber-300'
                  : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
            }`}
          >
            <Sparkles className="w-3 h-3" />
            {language === 'id' ? 'Keberuntungan' : 'Luck'}: {cast.luckPct}%
          </span>
        </div>

        {/* PHASE 1: WAITING FOR BITE (1s – 5m) */}
        {phase === 'waiting' && (
          <div className="py-4 space-y-3">
            <div className="w-16 h-16 mx-auto rounded-full bg-sky-100 border-2 border-sky-600 flex items-center justify-center text-sky-700 shadow-inner animate-pulse">
              <Waves className="w-8 h-8" />
            </div>
            <div className="text-sm font-extrabold">
              {t(language, 'fishing.waiting')}
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-[#efe2c6] border border-[#c59a45] text-xs font-black tabular-nums">
              <Timer className="w-3.5 h-3.5 text-[#784820]" />
              <span>{formatClock(elapsedSec)}</span>
              <span className="opacity-60 text-[10px]">
                ({language === 'id' ? '1 dtk – 5 mnt' : '1s – 5m'})
              </span>
            </div>
            <div className="text-[11px] opacity-80">
              {hasBait
                ? language === 'id'
                  ? '🪱 Umpan aktif — peluang ikan langka & gigitan lebih cepat!'
                  : '🪱 Bait active — higher minimum luck & faster bites!'
                : language === 'id'
                  ? 'Tunggu kail bergetar. Tanpa umpan, keberuntungan bisa 0%–100%.'
                  : 'Watch the float for a bite. Without bait, cast luck ranges 0%–100%.'}
            </div>
            <button
              type="button"
              onClick={handleCastAgain}
              className="px-4 py-1.5 rounded-xl bg-[#efe2c6] hover:bg-[#e5d3b0] border border-[#bfa070] text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              {language === 'id' ? 'Lempar Ulang Kail' : 'Recast Line'}
            </button>
          </div>
        )}

        {/* PHASE 1b: 0% LUCK SPLASH SLIP */}
        {phase === 'splash_miss' && (
          <div className="py-6 space-y-2.5">
            <div className="text-4xl animate-bounce">💦</div>
            <div className="text-sm font-black text-[#a63424]">
              {language === 'id'
                ? 'BYUR! Ikan menyambar tapi terlepas...'
                : 'SPLASH! A fish bit and slipped off...'}
            </div>
          </div>
        )}

        {/* PHASE 2: ROTATING DIAL MINI-GAME */}
        {phase === 'reeling' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-extrabold px-1">
              <span className="text-[#9e3b24]">🎣 {t(language, 'fishing.bite')}</span>
              <span className="px-2 py-0.5 rounded-lg bg-[#e2ecd8] text-[#23481a] border border-[#8db07b] tabular-nums">
                {language === 'id' ? 'Tarikan' : 'Strikes'}: {strikesDone}/{cast.requiredStrikes}
              </span>
            </div>

            {/* 360° Rotating Tension Dial */}
            <div className="flex justify-center">
              <svg viewBox="0 0 200 200" className="w-44 h-44 select-none drop-shadow">
                <circle cx="100" cy="100" r="82" fill="#f7eedc" stroke="#8a5a32" strokeWidth="6" />
                <circle cx="100" cy="100" r="72" fill="none" stroke="#dfd1b5" strokeWidth="14" />
                {/* Green Target Arc */}
                <path d={greenArcPath} fill="none" stroke="#3a8b34" strokeWidth="15" strokeLinecap="round" />
                {/* Golden Bullseye Arc */}
                <path d={goldArcPath} fill="none" stroke="#f5b82e" strokeWidth="15" strokeLinecap="round" />
                {/* Rotating Needle */}
                <line
                  x1="100"
                  y1="100"
                  x2={needleTip.x}
                  y2={needleTip.y}
                  stroke="#b91c1c"
                  strokeWidth="5"
                  strokeLinecap="round"
                />
                <circle cx="100" cy="100" r="10" fill="#4b2d16" stroke="#f5cc74" strokeWidth="3" />
              </svg>
            </div>

            <button
              type="button"
              onClick={handleStrike}
              className="w-full py-3 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] active:scale-[0.98] text-white font-extrabold text-base border-b-4 border-[#1f3b16] cursor-pointer transition"
            >
              🎣 {language === 'id' ? 'TARIK SEKARANG!' : 'STRIKE / REEL!'} [Space / F]
            </button>
          </div>
        )}

        {/* PHASE 3: RESULT */}
        {phase === 'result' && (
          <div className="space-y-3 py-2">
            <div className={`text-sm font-extrabold leading-relaxed ${caughtSuccess ? 'text-[#2e5e21]' : 'text-[#a63424]'}`}>
              {result}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleCastAgain}
                className="py-2.5 rounded-xl bg-[#3a6b2c] hover:bg-[#2d5422] text-white font-extrabold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" /> {t(language, 'fishing.castAgain')}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="py-2.5 rounded-xl bg-[#4b2d16] hover:bg-[#36200f] text-white font-extrabold text-xs cursor-pointer"
              >
                {t(language, 'common.close')}
              </button>
            </div>
          </div>
        )}
      </div>
    </DraggableWindow>
  );
};
