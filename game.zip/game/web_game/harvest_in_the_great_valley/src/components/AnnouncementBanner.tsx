import React, { useEffect, useState } from 'react';
import { AlertTriangle, Calendar, Clock, Megaphone, Sparkles, Tag, Wrench } from 'lucide-react';
import type { AnnouncementCategory, Language } from '../game/types';
import { localizeAnnouncementCategory } from '../game/localizationManager';
import { DraggableWindow } from './DraggableWindow';

interface AnnouncementBannerProps {
  title: string;
  message: string;
  category?: AnnouncementCategory;
  durationSec?: number;
  bannerKey?: string | number;
  language?: Language;
  onClose: () => void;
}

const CATEGORY_STYLE: Record<
  AnnouncementCategory,
  {
    accent: 'oak' | 'moss' | 'walnut';
    badgeBg: string;
    barClass: string;
    icon: React.ReactNode;
  }
> = {
  update: {
    accent: 'oak',
    badgeBg: '#2563eb',
    barClass: 'from-blue-500 via-sky-400 to-emerald-400',
    icon: <Sparkles className="w-5 h-5 text-sky-300" />,
  },
  maintenance: {
    accent: 'walnut',
    badgeBg: '#d97706',
    barClass: 'from-amber-500 via-orange-400 to-yellow-300',
    icon: <Wrench className="w-5 h-5 text-amber-300" />,
  },
  event: {
    accent: 'moss',
    badgeBg: '#16a34a',
    barClass: 'from-emerald-500 via-lime-400 to-amber-300',
    icon: <Calendar className="w-5 h-5 text-emerald-300" />,
  },
  emergency: {
    accent: 'walnut',
    badgeBg: '#dc2626',
    barClass: 'from-rose-600 via-red-500 to-amber-400',
    icon: <AlertTriangle className="w-5 h-5 text-rose-300" />,
  },
  promotion: {
    accent: 'oak',
    badgeBg: '#9333ea',
    barClass: 'from-purple-500 via-pink-400 to-amber-300',
    icon: <Tag className="w-5 h-5 text-pink-300" />,
  },
};

export const AnnouncementBanner: React.FC<AnnouncementBannerProps> = ({
  title,
  message,
  category = 'update',
  durationSec = 10,
  bannerKey,
  language = 'en',
  onClose,
}) => {
  const safeDuration = Math.max(3, Math.min(180, Math.round(durationSec)));
  const [remainingMs, setRemainingMs] = useState(safeDuration * 1000);

  useEffect(() => {
    setRemainingMs(safeDuration * 1000);
    const startedAt = Date.now();
    const timer = window.setInterval(() => {
      const elapsed = Date.now() - startedAt;
      const next = Math.max(0, safeDuration * 1000 - elapsed);
      setRemainingMs(next);
      if (next <= 0) {
        window.clearInterval(timer);
        onClose();
      }
    }, 100);

    return () => window.clearInterval(timer);
  }, [safeDuration, title, message, bannerKey, onClose]);

  const pct = Math.max(0, Math.min(100, (remainingMs / (safeDuration * 1000)) * 100));
  const secondsLeft = Math.ceil(remainingMs / 1000);
  const meta = CATEGORY_STYLE[category] || CATEGORY_STYLE.update;
  const catLabel = localizeAnnouncementCategory(language, category);

  return (
    <DraggableWindow
      windowId="announcement_banner"
      centerOnMount
      title={title || catLabel}
      icon={meta.icon || <Megaphone className="w-5 h-5 text-[#f5cc74]" />}
      widthClass="w-[min(92vw,500px)]"
      headerAccent={meta.accent}
      zIndexClass="z-[75]"
      onClose={onClose}
    >
      <div className="p-5 space-y-4">
        <div className="flex items-center justify-between gap-2">
          <span
            className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-extrabold text-white uppercase tracking-wide"
            style={{ backgroundColor: meta.badgeBg }}
          >
            {catLabel}
          </span>
          <span className="text-[11px] font-bold opacity-70">Global Broadcast</span>
        </div>

        <div
          className="gv-card rounded-2xl p-4 border shadow-inner"
          style={{
            borderColor: category === 'emergency' ? '#ef4444' : 'var(--hv-border)',
          }}
        >
          <p className="text-sm sm:text-[15px] leading-relaxed font-semibold whitespace-pre-line">
            {message}
          </p>
        </div>

        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-bold opacity-80">
            <span className="inline-flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-500" />
              {language === 'id'
                ? `Menutup otomatis dalam ${secondsLeft} dtk`
                : `Auto-closing in ${secondsLeft}s`}
            </span>
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-[11px] font-extrabold transition cursor-pointer"
            >
              {language === 'id' ? 'Tutup' : 'Dismiss'}
            </button>
          </div>
          <div className="h-2 rounded-full bg-black/20 overflow-hidden border border-black/15">
            <div
              className={`h-full transition-[width] duration-100 ease-linear bg-gradient-to-r ${meta.barClass}`}
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>
      </div>
    </DraggableWindow>
  );
};
