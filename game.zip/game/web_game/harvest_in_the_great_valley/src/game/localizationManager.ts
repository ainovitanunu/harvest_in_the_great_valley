import type { AnnouncementCategory, BanType, Language, Season, TimeOfDayPhase, Weather } from './types';
import { BILINGUAL_NPC_DIALOGUES } from './data/npcDialoguesLocalized';

export interface LanguageOption {
  code: Language;
  nativeName: string;
  englishName: string;
  flag: string;
  subtitle: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'id', nativeName: 'Bahasa Indonesia', englishName: 'Indonesian', flag: '🇮🇩', subtitle: 'Antarmuka & dialog lengkap Bahasa Indonesia' },
  { code: 'en', nativeName: 'English', englishName: 'English', flag: '🇺🇸', subtitle: 'Complete English UI & NPC dialogues' },
];

const LOCALE_STORAGE_KEY = 'hgv_global_language_v2';
const LOCALE_CHANNEL = 'hgv_global_locale_sync';

const runtimeLocalePacks: Record<string, Record<string, string>> = {};

export function registerLocalePack(langCode: string, dictionary: Record<string, string>) {
  runtimeLocalePacks[langCode] = {
    ...(runtimeLocalePacks[langCode] || {}),
    ...dictionary,
  };
}

export function getRuntimeLocaleValue(langCode: string, key: string): string | undefined {
  return runtimeLocalePacks[langCode]?.[key];
}

export function normalizeLanguage(raw: unknown): Language {
  return raw === 'en' ? 'en' : 'id';
}

export function localizeSeasonName(lang: Language, season: Season): string {
  const table: Record<Language, Record<Season, string>> = {
    en: { Spring: 'Spring', Summer: 'Summer', Autumn: 'Autumn', Winter: 'Winter' },
    id: { Spring: 'Musim Semi', Summer: 'Musim Panas', Autumn: 'Musim Gugur', Winter: 'Musim Dingin' },
  };
  return table[lang]?.[season] || season;
}

export function localizeWeatherName(lang: Language, weather: Weather): string {
  const table: Record<Language, Record<Weather, string>> = {
    en: {
      Sunny: 'Clear / Sunny',
      Cloudy: 'Cloudy',
      LightRain: 'Light Rain',
      HeavyRain: 'Heavy Rain',
      Rainy: 'Rainy',
      Stormy: 'Stormy',
      Foggy: 'Foggy',
      Snowy: 'Snowy',
    },
    id: {
      Sunny: 'Cerah',
      Cloudy: 'Berawan',
      LightRain: 'Hujan Ringan',
      HeavyRain: 'Hujan Deras',
      Rainy: 'Hujan',
      Stormy: 'Badai',
      Foggy: 'Kabut',
      Snowy: 'Salju',
    },
  };
  return table[lang]?.[weather] || weather;
}

export function getTimeOfDayPhase(hour: number): TimeOfDayPhase {
  const h = ((hour % 24) + 24) % 24;
  if (h >= 4 && h < 6) return 'dawn';
  if (h >= 6 && h < 11) return 'morning';
  if (h >= 11 && h < 15) return 'noon';
  if (h >= 15 && h < 17) return 'afternoon';
  if (h >= 17 && h < 19) return 'dusk';
  return 'night';
}

export function localizeTimePhase(lang: Language, phase: TimeOfDayPhase): string {
  const table: Record<Language, Record<TimeOfDayPhase, string>> = {
    en: { dawn: 'Dawn', morning: 'Morning', noon: 'Noon', afternoon: 'Afternoon', dusk: 'Dusk', night: 'Night' },
    id: { dawn: 'Subuh', morning: 'Pagi', noon: 'Siang', afternoon: 'Sore', dusk: 'Senja', night: 'Malam' },
  };
  return table[lang]?.[phase] || phase;
}

export function localizeAnnouncementCategory(lang: Language, category: AnnouncementCategory): string {
  const table: Record<Language, Record<AnnouncementCategory, string>> = {
    en: {
      update: 'Update Notice',
      maintenance: 'Maintenance Notice',
      event: 'Event Notice',
      emergency: 'Emergency Notice',
      promotion: 'Promotion Notice',
    },
    id: {
      update: 'Info Pembaruan',
      maintenance: 'Pemberitahuan Maintenance',
      event: 'Pengumuman Event',
      emergency: 'Peringatan Darurat',
      promotion: 'Promo Spesial',
    },
  };
  return table[lang]?.[category] || category;
}

export function localizeBanType(lang: Language, banType: BanType): string {
  const table: Record<Language, Record<BanType, string>> = {
    en: {
      chat_ban: 'Chat Ban',
      temporary_ban: 'Temporary Ban',
      permanent_ban: 'Permanent Ban',
      account_lock: 'Account Lock',
    },
    id: {
      chat_ban: 'Larangan Chat (Chat Ban)',
      temporary_ban: 'Ban Sementara',
      permanent_ban: 'Ban Permanen',
      account_lock: 'Akun Dikunci (Account Lock)',
    },
  };
  return table[lang]?.[banType] || banType;
}

export function localizeNpcDialogue(
  lang: Language,
  opts: {
    npcName: string;
    profession: string;
    fallbackEnglish: string;
    season: Season;
    hour: number;
    weather: Weather;
    isBirthday?: boolean;
    isMarried?: boolean;
    friendshipPoints?: number;
  }
): string {
  if (lang === 'en') return opts.fallbackEnglish;

  const phase = getTimeOfDayPhase(opts.hour);
  const isWet = opts.weather === 'Rainy' || opts.weather === 'LightRain' || opts.weather === 'HeavyRain' || opts.weather === 'Stormy';
  const isFoggy = opts.weather === 'Foggy';
  const isSnowy = opts.weather === 'Snowy';
  const seasonTxt = localizeSeasonName('id', opts.season);
  const fp = opts.friendshipPoints ?? 0;

  const pickId = (cat: string) => {
    const arr = BILINGUAL_NPC_DIALOGUES.id[cat];
    if (!arr || arr.length === 0) return null;
    return arr[Math.floor(Math.random() * arr.length)]
      .replace(/\{playerName\}/g, 'Sahabat')
      .replace(/\{npcName\}/g, opts.npcName)
      .replace(/\{farmName\}/g, 'kebunmu')
      .replace(/\{season\}/g, seasonTxt)
      .replace(/\{weather\}/g, localizeWeatherName('id', opts.weather));
  };
  if (opts.isBirthday) {
    return `Terima kasih sudah ingat hari ulang tahunku! Hari ini terasa sangat spesial di Great Valley.`;
  }
  if (opts.isMarried) {
    return pickId('relationship_romance') || `Selamat ${localizeTimePhase('id', phase).toLowerCase()}, sayang! Jangan lupa jaga staminamu ya.`;
  }
  if (opts.weather === 'Stormy') return pickId('weather_stormy') || `Badainya cukup kencang hari ini! Sebaiknya kita berteduh dulu.`;
  if (opts.weather === 'HeavyRain') return pickId('weather_heavy_rain') || pickId('weather_rainy') || `Hujan deras sekali hari ini!`;
  if (opts.weather === 'LightRain') return pickId('weather_light_rain') || pickId('weather_rainy') || `Gerimis lembut menyegarkan seluruh desa!`;
  if (isWet) return pickId('weather_rainy') || `Hujan di ${seasonTxt} ini bikin tanaman kebun tersiram alami!`;
  if (isFoggy) return pickId('weather_foggy') || `Kabut di lembah cukup tebal hari ini. Hati-hati melangkah ya.`;
  if (isSnowy) return pickId('weather_snowy') || `Salju turun lembut sekali! Cocok minum cokelat hangat.`;
  const candidates: string[] = [];
  const timeKey =
    phase === 'dawn' || phase === 'morning'
      ? 'time_morning'
      : phase === 'noon' || phase === 'afternoon'
        ? 'time_afternoon'
        : phase === 'dusk'
          ? 'time_evening'
          : 'time_night';
  const tl = pickId(timeKey);
  if (tl) candidates.push(tl);
  const sl = pickId(`season_${opts.season.toLowerCase()}`);
  if (sl) candidates.push(sl);
  const relKey = fp >= 600 ? 'relationship_close' : fp >= 200 ? 'relationship_friend' : 'relationship_stranger';
  const rl = pickId(relKey);
  if (rl) candidates.push(rl);
  const actKeys = ['activity_farming', 'activity_socializing', 'activity_walking', 'activity_eating'];
  const al = pickId(actKeys[Math.floor(Math.random() * actKeys.length)]);
  if (al) candidates.push(al);
  if (candidates.length > 0) {
    return candidates[Math.floor(Math.random() * candidates.length)];
  }
  return `Halo! Udara ${seasonTxt} di Great Valley terasa segar sekali ya.`;
}

export function localizeNpcGreetingBubble(lang: Language, hour: number, weather: Weather): string {
  const phase = getTimeOfDayPhase(hour);
  const isWet = weather === 'Rainy' || weather === 'LightRain' || weather === 'HeavyRain' || weather === 'Stormy';
  if (isWet) {
    return lang === 'id' ? 'Hati-hati hujan ya!' : 'Watch out for the rain!';
  }
  const greetMap: Record<Language, Record<'morning' | 'day' | 'night', string>> = {
    en: { morning: 'Good morning, neighbor!', day: 'Lovely day in the valley!', night: 'Good evening, friend!' },
    id: { morning: 'Selamat pagi, tetangga!', day: 'Halo! Semangat berkebun ya!', night: 'Selamat malam!' },
  };
  const bucket = phase === 'dawn' || phase === 'morning' ? 'morning' : phase === 'night' || phase === 'dusk' ? 'night' : 'day';
  return greetMap[lang][bucket];
}

type LocaleListener = (lang: Language) => void;

class GlobalLocalizationManager {
  private currentLang: Language = 'id';
  private listeners = new Set<LocaleListener>();
  private channel: BroadcastChannel | null = null;
  private initialized = false;

  public init() {
    if (this.initialized || typeof window === 'undefined') return;
    this.initialized = true;
    try {
      const saved = localStorage.getItem(LOCALE_STORAGE_KEY);
      if (saved === 'en' || saved === 'id') {
        this.currentLang = saved;
      } else if (saved) {
        this.currentLang = 'id';
        localStorage.setItem(LOCALE_STORAGE_KEY, 'id');
      }
    } catch {
      // ignore
    }
    if (typeof BroadcastChannel !== 'undefined') {
      try {
        this.channel = new BroadcastChannel(LOCALE_CHANNEL);
        this.channel.onmessage = (ev) => {
          const lang = ev.data?.lang;
          if (lang === 'en' || lang === 'id') {
            this.currentLang = lang;
            document.documentElement.lang = lang;
            this.listeners.forEach((fn) => fn(lang));
          }
        };
      } catch {
        this.channel = null;
      }
    }
    document.documentElement.lang = this.currentLang;
  }

  public getLanguage(): Language {
    this.init();
    return this.currentLang;
  }

  public setLanguage(lang: Language, broadcast = true) {
    this.init();
    const safeLang = normalizeLanguage(lang);
    this.currentLang = safeLang;
    try {
      localStorage.setItem(LOCALE_STORAGE_KEY, safeLang);
    } catch {
      // ignore
    }
    if (typeof document !== 'undefined') {
      document.documentElement.lang = safeLang;
    }
    this.listeners.forEach((fn) => fn(safeLang));
    if (broadcast && this.channel) {
      try {
        this.channel.postMessage({ lang: safeLang });
      } catch {
        // ignore
      }
    }
  }

  public subscribe(listener: LocaleListener): () => void {
    this.init();
    this.listeners.add(listener);
    listener(this.currentLang);
    return () => {
      this.listeners.delete(listener);
    };
  }
}

export const localizationManager = new GlobalLocalizationManager();
