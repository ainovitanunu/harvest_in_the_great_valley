import type { Language, Season, ThemeMode } from './types';

export type ResolvedThemeKey = 'light' | 'dark' | 'cozy' | 'seasonal';

export interface ThemeDescriptor {
  id: 'system' | 'cozy' | 'light' | 'dark' | 'seasonal';
  label: Record<Language, string>;
  description: Record<Language, string>;
  swatches: [string, string, string];
  fontBody: string;
  fontDisplay: string;
}

export const GLOBAL_THEMES: ThemeDescriptor[] = [
  {
    id: 'system',
    label: {
      en: 'Follow System (Auto)',
      id: 'Ikuti Sistem (Otomatis)',
    },
    description: {
      en: 'Matches your operating system Light or Dark appearance strictly across every screen.',
      id: 'Mengikuti tampilan Terang/Gelap sistem perangkat secara otomatis di seluruh UI game.',
    },
    swatches: ['#0f172a', '#ffffff', '#0284c7'],
    fontBody: "'Plus Jakarta Sans', system-ui, sans-serif",
    fontDisplay: "'Plus Jakarta Sans', system-ui, sans-serif",
  },
  {
    id: 'cozy',
    label: {
      en: 'Cozy Valley (Default)',
      id: 'Cozy Hangat (Bawaan)',
    },
    description: {
      en: 'Warm artisanal timber, cream parchment, and sunlit moss accents.',
      id: 'Nuansa kayu hangat, perkamen lembut, dan hijau lumut khas pedesaan.',
    },
    swatches: ['#4b2d16', '#f7eedc', '#3a6b2c'],
    fontBody: "'Plus Jakarta Sans', system-ui, sans-serif",
    fontDisplay: "'Fraunces', Georgia, serif",
  },
  {
    id: 'light',
    label: {
      en: 'Light Daylight',
      id: 'Terang (Light)',
    },
    description: {
      en: 'Crisp porcelain daylight surfaces with clean slate typography and sky accents.',
      id: 'Tampilan terang siang hari yang bersih, modern, dan kontras tinggi.',
    },
    swatches: ['#0f172a', '#ffffff', '#0284c7'],
    fontBody: "'Plus Jakarta Sans', system-ui, sans-serif",
    fontDisplay: "'Plus Jakarta Sans', system-ui, sans-serif",
  },
  {
    id: 'dark',
    label: {
      en: 'Dark Midnight',
      id: 'Gelap (Dark)',
    },
    description: {
      en: 'Low-glare twilight slate canvas with luminous indigo and emerald accents.',
      id: 'Mode malam gelap rendah silau yang nyaman di mata di seluruh layar.',
    },
    swatches: ['#0b1120', '#1e293b', '#6366f1'],
    fontBody: "'Plus Jakarta Sans', system-ui, sans-serif",
    fontDisplay: "'Fraunces', Georgia, serif",
  },
  {
    id: 'seasonal',
    label: {
      en: 'Seasonal Living Theme',
      id: 'Tema Musiman Dinamis',
    },
    description: {
      en: 'Adapts colors, backgrounds, and borders live to Spring, Summer, Autumn, or Winter.',
      id: 'Berubah otomatis mengikuti musim di dunia: Semi, Panas, Gugur, dan Dingin.',
    },
    swatches: ['#f472b6', '#f59e0b', '#38bdf8'],
    fontBody: "'Plus Jakarta Sans', system-ui, sans-serif",
    fontDisplay: "'Fraunces', Georgia, serif",
  },
];

const THEME_STORAGE_KEY = 'hgv_global_theme_v2';
const SEASON_STORAGE_KEY = 'hgv_global_season_v2';
const CHANNEL_NAME = 'hgv_global_theme_sync';

type ThemeListener = (state: { theme: ThemeMode; resolved: ResolvedThemeKey; season: Season }) => void;

class GlobalThemeManager {
  private currentTheme: ThemeMode = 'system';
  private currentSeason: Season = 'Spring';
  private listeners = new Set<ThemeListener>();
  private channel: BroadcastChannel | null = null;
  private initialized = false;

  public init() {
    if (this.initialized || typeof window === 'undefined') return;
    this.initialized = true;

    try {
      const savedTheme = localStorage.getItem(THEME_STORAGE_KEY) as ThemeMode | null;
      if (savedTheme && ['system', 'cozy', 'farmhouse', 'light', 'dark', 'seasonal'].includes(savedTheme)) {
        this.currentTheme = savedTheme === 'farmhouse' ? 'cozy' : savedTheme;
      }
      const savedSeason = localStorage.getItem(SEASON_STORAGE_KEY) as Season | null;
      if (savedSeason && ['Spring', 'Summer', 'Autumn', 'Winter'].includes(savedSeason)) {
        this.currentSeason = savedSeason;
      }
    } catch {
      // ignore storage errors
    }

    if (typeof BroadcastChannel !== 'undefined') {
      try {
        this.channel = new BroadcastChannel(CHANNEL_NAME);
        this.channel.onmessage = (ev) => {
          const data = ev.data as { theme?: ThemeMode; season?: Season } | null;
          if (!data) return;
          if (data.theme) this.currentTheme = data.theme === 'farmhouse' ? 'cozy' : data.theme;
          if (data.season) this.currentSeason = data.season;
          this.applyToDom();
          this.emit();
        };
      } catch {
        this.channel = null;
      }
    }

    const mq = window.matchMedia?.('(prefers-color-scheme: dark)');
    if (mq?.addEventListener) {
      mq.addEventListener('change', () => {
        if (this.currentTheme === 'system') {
          this.applyToDom();
          this.emit();
        }
      });
    }

    this.applyToDom();
  }

  public resolveTheme(mode: ThemeMode = this.currentTheme): ResolvedThemeKey {
    if (mode === 'farmhouse' || mode === 'cozy') return 'cozy';
    if (mode === 'light') return 'light';
    if (mode === 'dark') return 'dark';
    if (mode === 'seasonal') return 'seasonal';
    if (mode === 'system') {
      if (typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches) {
        return 'dark';
      }
      return 'light';
    }
    return 'cozy';
  }

  public getTheme(): ThemeMode {
    this.init();
    return this.currentTheme;
  }

  public getSeason(): Season {
    this.init();
    return this.currentSeason;
  }

  public setTheme(theme: ThemeMode, broadcast = true) {
    this.init();
    const normalized: ThemeMode = theme === 'farmhouse' ? 'cozy' : theme;
    this.currentTheme = normalized;
    try {
      localStorage.setItem(THEME_STORAGE_KEY, normalized);
    } catch {
      // ignore
    }
    this.applyToDom();
    this.emit();
    if (broadcast && this.channel) {
      try {
        this.channel.postMessage({ theme: normalized, season: this.currentSeason });
      } catch {
        // ignore
      }
    }
  }

  public setSeason(season: Season, broadcast = true) {
    this.init();
    if (this.currentSeason === season) return;
    this.currentSeason = season;
    try {
      localStorage.setItem(SEASON_STORAGE_KEY, season);
    } catch {
      // ignore
    }
    this.applyToDom();
    this.emit();
    if (broadcast && this.channel) {
      try {
        this.channel.postMessage({ theme: this.currentTheme, season });
      } catch {
        // ignore
      }
    }
  }

  public subscribe(listener: ThemeListener): () => void {
    this.init();
    this.listeners.add(listener);
    listener({
      theme: this.currentTheme,
      resolved: this.resolveTheme(this.currentTheme),
      season: this.currentSeason,
    });
    return () => {
      this.listeners.delete(listener);
    };
  }

  private applyToDom() {
    if (typeof document === 'undefined') return;
    const resolved = this.resolveTheme(this.currentTheme);
    const root = document.documentElement;
    root.setAttribute('data-theme', resolved);
    root.setAttribute('data-theme-mode', this.currentTheme);
    root.setAttribute('data-season', this.currentSeason.toLowerCase());
    if (resolved === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    root.style.colorScheme = resolved === 'dark' ? 'dark' : 'light';
  }

  private emit() {
    const payload = {
      theme: this.currentTheme,
      resolved: this.resolveTheme(this.currentTheme),
      season: this.currentSeason,
    };
    this.listeners.forEach((fn) => fn(payload));
  }
}

export const themeManager = new GlobalThemeManager();
