import type { DailyFunTracker } from './types';

/**
 * Progression & Anti-Spam Joy (Tingkat Kesenangan) System:
 * - Once-per-day activities (e.g., talking to a specific NPC, petting a specific animal)
 *   only grant Joy once per in-game day.
 * - Repeatable activities (e.g., giving gifts) decay by 50% on every repeat
 *   (10 -> 5 -> 2.5 -> 1.25 -> ...) until the in-game day changes.
 * - Farm Job completion grants proportional Joy (e.g. 20% done -> +20% Joy, 100% done -> +100% Joy).
 */

export function xpRequiredForLevel(level: number): number {
  const safeLv = Math.max(1, Math.floor(level));
  return Math.round(180 * Math.pow(safeLv, 1.55));
}

export function computeXpGain(baseXp: number, currentLevel: number): number {
  const safeLv = Math.max(1, Math.floor(currentLevel));
  const multiplier = 1 / (1 + (safeLv - 1) * 0.28);
  return Math.max(1, Math.round(baseXp * multiplier));
}

export function applyXpProgress(currentLevel: number, currentXp: number, baseGain: number): {
  level: number;
  xp: number;
  xpAdded: number;
  leveledUp: boolean;
} {
  let lv = Math.max(1, Math.floor(currentLevel));
  const xpAdded = computeXpGain(baseGain, lv);
  let xp = Math.max(0, currentXp) + xpAdded;
  let leveledUp = false;

  while (xp >= xpRequiredForLevel(lv) && lv < 999) {
    xp -= xpRequiredForLevel(lv);
    lv += 1;
    leveledUp = true;
  }

  return { level: lv, xp, xpAdded, leveledUp };
}

export function createEmptyDailyFunTracker(dayKey: string): DailyFunTracker {
  return {
    dayKey,
    onceKeys: [],
    diminishingCounts: {},
  };
}

export function computeFunGain(baseFun: number, currentFun: number): number {
  const clamped = Math.max(0, Math.min(100, currentFun));
  if (clamped >= 100 || baseFun <= 0) return 0;
  return Number(Math.min(100 - clamped, baseFun).toFixed(2));
}

export function applyFunProgress(currentFun: number, baseFun: number): {
  fun: number;
  funAdded: number;
} {
  const funAdded = computeFunGain(baseFun, currentFun);
  const nextFun = Math.min(100, Number((Math.max(0, currentFun) + funAdded).toFixed(2)));
  return { fun: nextFun, funAdded };
}

/**
 * Once-per-day Joy reward (talking to an NPC, petting/caring for an animal, etc.).
 * Returns 0 if already claimed today.
 */
export function applyOncePerDayFun(
  tracker: DailyFunTracker,
  activityKey: string,
  baseFun: number,
  currentFun: number
): {
  tracker: DailyFunTracker;
  fun: number;
  funAdded: number;
  alreadyClaimed: boolean;
} {
  if (tracker.onceKeys.includes(activityKey)) {
    return { tracker, fun: currentFun, funAdded: 0, alreadyClaimed: true };
  }
  const res = applyFunProgress(currentFun, baseFun);
  return {
    tracker: {
      ...tracker,
      onceKeys: [...tracker.onceKeys, activityKey],
    },
    fun: res.fun,
    funAdded: res.funAdded,
    alreadyClaimed: false,
  };
}

/**
 * 50% geometric diminishing returns per repeat until the in-game day changes.
 * Example (initialBase = 10):
 *  1st time -> 10
 *  2nd time -> 5
 *  3rd time -> 2.5
 *  4th time -> 1.25 ...
 */
export function applyDiminishingFun(
  tracker: DailyFunTracker,
  categoryKey: string,
  initialBaseFun: number,
  currentFun: number
): {
  tracker: DailyFunTracker;
  fun: number;
  funAdded: number;
  effectiveBase: number;
  repeatIndex: number;
} {
  const repeatIndex = tracker.diminishingCounts[categoryKey] || 0;
  const rawGain = initialBaseFun * Math.pow(0.5, repeatIndex);
  const effectiveBase = rawGain < 0.05 ? 0 : Number(rawGain.toFixed(2));
  const res = applyFunProgress(currentFun, effectiveBase);
  return {
    tracker: {
      ...tracker,
      diminishingCounts: {
        ...tracker.diminishingCounts,
        [categoryKey]: repeatIndex + 1,
      },
    },
    fun: res.fun,
    funAdded: res.funAdded,
    effectiveBase,
    repeatIndex,
  };
}

/**
 * Farm Job proportional Joy reward for both employer and worker:
 * 100% completion -> +100% Joy, 20% completion -> +20% Joy.
 */
export function applyProportionalJobFun(
  currentFun: number,
  completionRatio: number
): { fun: number; funAdded: number } {
  const pct = Math.max(0, Math.min(1, completionRatio)) * 100;
  return applyFunProgress(currentFun, Number(pct.toFixed(2)));
}
