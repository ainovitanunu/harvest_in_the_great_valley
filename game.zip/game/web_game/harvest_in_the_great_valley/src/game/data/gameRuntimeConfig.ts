import type {
  AnnouncementBannerConfig,
  CameraConfig,
  CaveMiningConfig,
  CustomMobileGamepadLayout,
  DevPortalBridgeConfig,
  FishingConfig,
  GlobalTreeEcosystemConfig,
  GuestSessionConfig,
  MarketEconomyConfig,
  EconomyTaxConfig,
  NameChangeEconomyConfig,
  MobileControlsConfig,
  MusicConfig,
  PaymentMethodConfig,
  PerformanceConfig,
  PublicGameEnvConfig,
  SalesStats,
  Season,
  SkyAtmosphereConfig,
  ThemeMode,
  VideoCallConfig,
  Weather,
  WeatherControlConfig,
  WorldTimeOverrideConfig,
} from '../types';

/**
 * Clean, self-contained game runtime configuration.
 * All toggles are pure TypeScript constants so the game operates with zero external dependencies.
 */

// Developer Debug Mode:
// true  = Unlimited Gold & Diamonds (for testing & debugging)
// false = Normal release economy (starter Gold = 500, starter Diamond = 0, normal currency deduction)
export const DEVELOPER_DEBUG_MODE = false;

export const NORMAL_STARTER_GOLD = 300;
export const NORMAL_STARTER_DIAMOND = 0;
export const DEBUG_UNLIMITED_CURRENCY = 999999999;

// Payment Gateway Toggles (independent ON/OFF switches)
export const PAYMENT_METHODS: PaymentMethodConfig = {
  googlePlayBilling: true,
  duitku: true,
};

// Default global UI theme ('system' | 'cozy' | 'light' | 'dark' | 'seasonal' | 'farmhouse')
export const DEFAULT_GLOBAL_THEME: ThemeMode = 'system';

// Global Forest Ecosystem Control (200-500 protected trees across Town Square, Woods, Cave, Coast)
// Asymmetric growth vs. Village Carpenter (Orin) harvesting produces natural population waves.
export const GLOBAL_TREE_ECOSYSTEM: GlobalTreeEcosystemConfig = {
  minTrees: 200,
  maxTrees: 500,
  growthIntervalSec: 18,
  growthBatchMin: 2,
  growthBatchMax: 9,
  carpenterCutIntervalSec: 22,
  carpenterCutBatchMin: 1,
  carpenterCutBatchMax: 8,
};

// Independent Dev Panel Route (Game runs 100% independently even if Dev Panel is removed)
export const DEV_PORTAL_BRIDGE: DevPortalBridgeConfig = {
  enabled: true,
  authorizedEmailHash: '',
  dashboardUrl: '/dev-panel',
};

export const PUBLIC_GAME_ENV_DEFAULTS: PublicGameEnvConfig = {
  GAME_VERSION: '2.0.0',
  GAME_MAINTENANCE_MODE: false,
  EXP_RATE_MULTIPLIER: 1.0,
  DROP_RATE_MULTIPLIER: 1.0,
  PLAYER_INITIAL_GOLD: 300,
  PLAYER_INITIAL_DIAMOND: 0,
  PLAYER_MAX_LEVEL: 100,
  CDN_URL: '',
};

export const SKY_ATMOSPHERE_CONFIG: SkyAtmosphereConfig = {
  cloudDensity: 0.65,
  cloudSpeed: 1.0,
  starTwinkleIntensity: 0.9,
  moonPhaseOverride: null,
};

// Ephemeral Guest Session Duration Control (Default: 60 minutes = 1 hour, configurable live in Developer Dashboard)
export const GUEST_SESSION_CONFIG: GuestSessionConfig = {
  durationMinutes: 60,
  warningBeforeMinutes: 5,
};

// Real-Time World Time & Weather Override (Controlled live from Developer Dashboard)
export const WORLD_TIME_OVERRIDE: WorldTimeOverrideConfig = {
  enabled: false,
  hour: 8,
  minute: 0,
  day: 1,
  season: 'Spring',
  year: 1,
  timePaused: false,
  timeScale: 1,
  weatherOverride: null,
};

// In-Game Announcement Banner (Script Toggle + Custom Message, displayed 10s in center, closable & draggable)
// enabled = true  -> Displays the center announcement banner when players enter the valley
// enabled = false -> Banner stays hidden
export const ANNOUNCEMENT_BANNER_CONFIG: AnnouncementBannerConfig = {
  enabled: true,
  title: 'Great Valley Update Notice',
  message: 'A new Harvest in the Great Valley update is coming soon! Save your farm progress safely.',
  durationSec: 10,
};

// Background Music Configuration (Harvest Moon: Back to Nature pastoral synth + optional custom uploaded tracks)
export const MUSIC_CONFIG: MusicConfig = {
  mode: 'procedural',
  preset: 'btn_pastoral',
  tempoScale: 1.0,
  customTracks: {},
};

// Secret Developer Fishing Parameters (Never shown to players; controlled here or via Developer Dashboard)
export const FISHING_CONFIG: FishingConfig = {
  luckMin: 0,
  luckMax: 100,
  waitMinSec: 1,
  waitMaxSec: 300,
  strikesRequired: 3,
  greenZoneWidthPct: 22,
};

// Multi-Level Cave Floor Mining & Rarity Scaling (+3% find & +3% rarity per floor; editable in Developer Dashboard)
// Example: Lv.1 = 5-30% drop & 5% rarity -> Lv.2 = 8-38% drop & 8% rarity -> Lv.3 = 11-46% drop & 11% rarity
export const CAVE_MINING_CONFIG: CaveMiningConfig = {
  baseDropMinPct: 5,
  baseDropMaxPct: 30,
  baseRarityPct: 5,
  levelDropStepPct: 3,
  levelRarityStepPct: 3,
  maxLevel: 20,
};

export function createEmptySalesStats(): SalesStats {
  return {
    marketGoldBySeason: {
      Spring: { qty: 0, revenue: 0 },
      Summer: { qty: 0, revenue: 0 },
      Autumn: { qty: 0, revenue: 0 },
      Winter: { qty: 0, revenue: 0 },
    },
    marketGoldTotalQty: 0,
    marketGoldTotalRevenue: 0,
    p2pDiamondBySeason: {
      Spring: { qty: 0, revenue: 0 },
      Summer: { qty: 0, revenue: 0 },
      Autumn: { qty: 0, revenue: 0 },
      Winter: { qty: 0, revenue: 0 },
    },
    p2pDiamondTotalQty: 0,
    p2pDiamondTotalRevenue: 0,
  };
}

// Weather Override & Custom Probability Control:
// overrideEnabled = false -> Natural seasonal weather (default)
// overrideEnabled = true  -> Weighted random roll using weights below (0..100 each)
export const WEATHER_CONTROL: WeatherControlConfig = {
  overrideEnabled: false,
  weights: {
    Sunny: 38,
    Cloudy: 20,
    LightRain: 14,
    HeavyRain: 8,
    Rainy: 8,
    Stormy: 4,
    Foggy: 5,
    Snowy: 3,
  },
};

// Video Call Encoding & Self-Preview Defaults (240p, 30fps, 130Kbps)
export const VIDEO_CALL_CONFIG: VideoCallConfig = {
  width: 320,
  height: 240,
  fps: 30,
  bitrateKbps: 130,
  showSelfPreviewByDefault: false,
};

// Camera Follow Distance & POV Mode Defaults ('lock' = natural horizon-aligned view behind character with orbit + auto-return)
export const CAMERA_CONFIG: CameraConfig = {
  defaultDistance: 7.4,
  minZoom: 4.5,
  maxZoom: 18,
  povMode: 'lock',
  fov: 46,
  defaultPitch: 0.24,
  mobileLockOrbitEnabled: true,
  mobileLockAutoReturnDelaySec: 2.5,
  mobileLockAutoReturnSpeed: 3.2,
};

export const DEFAULT_MOBILE_GAMEPAD_LAYOUT: CustomMobileGamepadLayout = {
  presetName: 'Default',
  elements: {
    analog: { xPct: 14, yPct: 78, sizePx: 124, opacity: 0.88 },
    jump: { xPct: 90, yPct: 82, sizePx: 64, opacity: 0.92 },
    action: { xPct: 81, yPct: 84, sizePx: 54, opacity: 0.9 },
    sprint: { xPct: 72, yPct: 85, sizePx: 50, opacity: 0.88 },
    interact: { xPct: 83, yPct: 68, sizePx: 50, opacity: 0.9 },
    tool: { xPct: 91, yPct: 68, sizePx: 50, opacity: 0.9 },
  },
};

// Mobile Virtual Analog Thumbstick & Action Buttons Layout (Ergonomic proportional bottom-left & bottom-right thumb zones)
export const MOBILE_CONTROLS_CONFIG: MobileControlsConfig = {
  joystickBottomPx: 56,
  joystickLeftPx: 58,
  joystickSizePx: 124,
  actionBottomPx: 56,
  actionRightPx: 58,
  buttonScale: 1.0,
  showTopRightSwitchOnly: true,
  minAnalogSizePx: 84,
  maxAnalogSizePx: 180,
  minButtonSizePx: 40,
  maxButtonSizePx: 88,
  defaultLayout: DEFAULT_MOBILE_GAMEPAD_LAYOUT,
};

// Global Supply & Demand market. Prices can fall below base prices when supply exceeds demand.
export const MARKET_ECONOMY_CONFIG: MarketEconomyConfig = {
  minMultiplier: 0.5,
  maxMultiplier: 2.6,
  goldDemandFactor: 1.0,
  diamondFloorMultiplier: 0.5,
};

// Progressive transaction tax: sample defaults are fully editable by the Owner/Developer Panel.
export const ECONOMY_TAX_CONFIG: EconomyTaxConfig = {
  enabled: true,
  goldTiers: [
    { minLevel: 1, taxPercent: 25 },
    { minLevel: 11, taxPercent: 20 },
    { minLevel: 21, taxPercent: 15 },
    { minLevel: 31, taxPercent: 10 },
    { minLevel: 41, taxPercent: 5 },
  ],
  diamondTiers: [
    { minLevel: 1, taxPercent: 25 },
    { minLevel: 11, taxPercent: 20 },
    { minLevel: 21, taxPercent: 15 },
    { minLevel: 31, taxPercent: 10 },
    { minLevel: 41, taxPercent: 5 },
  ],
};

// Display-name rename fee is market-sensitive but may never fall below 250 Diamonds.
export const NAME_CHANGE_ECONOMY_CONFIG: NameChangeEconomyConfig = {
  basePriceDiamond: 250,
  minimumPriceDiamond: 250,
};

// 3D Engine LOD, Occlusion Culling & 4GB RAM Low-Power Optimization Defaults
export const PERFORMANCE_CONFIG: PerformanceConfig = {
  enableLod: true,
  enableOcclusionCulling: true,
  lowPower4GbMode: true,
  maxDprLowPower: 1.25,
  maxAnisotropy: 4,
  lod0Distance: 22,
  lod1Distance: 48,
};

// Per-Item Diamond P2P Trade Eligibility Percentage (0..100)
// All tradeable items default to 5% (rare Diamond P2P market drop) and can be tuned per-item in Developer Dashboard.
export const ITEM_TRADE_RATES: Record<string, number> = {
  tool_hoe: 0,
  tool_watering_can: 0,
  tool_axe: 0,
  tool_hammer: 0,
  tool_sickle: 0,
  tool_fishing_rod: 0,
  tool_milk_pail: 0,
  tool_brush: 0,
  seed_turnip: 5,
  seed_potato: 5,
  seed_strawberry: 5,
  seed_corn: 5,
  seed_tomato: 5,
  seed_carrot: 5,
  seed_grape: 5,
  seed_tulip: 5,
  seed_sunflower: 5,
  seed_starfrost: 5,
  crop_turnip: 5,
  crop_potato: 5,
  crop_strawberry: 5,
  crop_corn: 5,
  crop_tomato: 5,
  crop_carrot: 5,
  crop_grape: 5,
  crop_tulip: 5,
  crop_sunflower: 5,
  crop_starfrost: 5,
  food_apple: 5,
  egg_fresh: 5,
  milk_fresh: 5,
  food_cheese: 5,
  wool_soft: 5,
  food_meat: 5,
  animal_feed: 5,
  fish_river_trout: 5,
  fish_golden_koi: 5,
  fish_ocean_tuna: 5,
  fish_coral_snapper: 5,
  fish_midnight_squid: 5,
  mat_wood: 5,
  mat_stone: 5,
  mat_copper: 5,
  mat_iron: 5,
  mat_silver: 5,
  mat_gold_ore: 5,
  mat_crystal: 5,
  mat_emerald: 5,
  mat_ancient_relic: 5,
  mat_mythril_star: 5,
  food_honey: 5,
  food_bread: 5,
  food_berry_cake: 5,
  item_herbal_tonic: 5,
  item_animal_medicine: 5,
  item_fish_bait: 5,
  item_fertilizer: 5,
  item_miracle_fertilizer: 5,
  item_royal_elixir: 5,
  item_golden_ring: 5,
  item_cheese_maker: 5,
  item_valley_phone: 5,
};

export function getItemTradeRate(itemId: string): number {
  const rate = ITEM_TRADE_RATES[itemId];
  if (typeof rate === 'number' && Number.isFinite(rate)) {
    return Math.max(0, Math.min(100, rate));
  }
  return 5;
}

export function rollItemDiamondTradeable(itemId: string): boolean {
  const rate = getItemTradeRate(itemId);
  if (rate <= 0) return false;
  if (rate >= 100) return true;
  return Math.random() * 100 < rate;
}

export function rollNextWeather(season: Season, weatherOverride?: WeatherControlConfig): Weather {
  const activeWeatherCtrl = weatherOverride || WEATHER_CONTROL;
  if (activeWeatherCtrl.overrideEnabled) {
    const entries: Array<[Weather, number]> = [
      ['Sunny', Math.max(0, Number(activeWeatherCtrl.weights.Sunny) || 0)],
      ['Cloudy', Math.max(0, Number(activeWeatherCtrl.weights.Cloudy) || 0)],
      ['LightRain', Math.max(0, Number(activeWeatherCtrl.weights.LightRain) || 0)],
      ['HeavyRain', Math.max(0, Number(activeWeatherCtrl.weights.HeavyRain) || 0)],
      ['Rainy', Math.max(0, Number(activeWeatherCtrl.weights.Rainy) || 0)],
      ['Stormy', Math.max(0, Number(activeWeatherCtrl.weights.Stormy) || 0)],
      ['Foggy', Math.max(0, Number(activeWeatherCtrl.weights.Foggy) || 0)],
      ['Snowy', Math.max(0, Number(activeWeatherCtrl.weights.Snowy) || 0)],
    ];
    const total = entries.reduce((sum, [, w]) => sum + w, 0);
    if (total > 0) {
      let roll = Math.random() * total;
      for (const [weather, weight] of entries) {
        roll -= weight;
        if (roll <= 0) return weather;
      }
      return entries[0][0];
    }
  }

  // Default realistic seasonal weather model (6+ atmospheric weather states)
  const r = Math.random();
  if (season === 'Winter') {
    if (r < 0.40) return 'Snowy';
    if (r < 0.62) return 'Cloudy';
    if (r < 0.76) return 'Foggy';
    if (r < 0.86) return 'Stormy';
    return 'Sunny';
  }
  if (season === 'Summer') {
    if (r < 0.50) return 'Sunny';
    if (r < 0.68) return 'Cloudy';
    if (r < 0.80) return 'LightRain';
    if (r < 0.90) return 'HeavyRain';
    return 'Stormy';
  }
  if (season === 'Autumn') {
    if (r < 0.34) return 'Sunny';
    if (r < 0.54) return 'Cloudy';
    if (r < 0.68) return 'Foggy';
    if (r < 0.82) return 'LightRain';
    if (r < 0.93) return 'HeavyRain';
    return 'Stormy';
  }
  // Spring
  if (r < 0.42) return 'Sunny';
  if (r < 0.62) return 'Cloudy';
  if (r < 0.78) return 'LightRain';
  if (r < 0.88) return 'Foggy';
  if (r < 0.95) return 'HeavyRain';
  return 'Stormy';
}
