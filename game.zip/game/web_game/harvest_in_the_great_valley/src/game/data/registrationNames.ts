import type { RegistrationNameConfig } from '../types';

/**
 * Editable name pool used when new players register / create their farmer
 * and when assigning default pet/NPC names. Editable directly in Developer Dashboard.
 */
// DEV_REG_NAMES_START
export const REGISTRATION_NAME_CONFIG: RegistrationNameConfig = {
  farmerNames: [
    'Arka',
    'Raka',
    'Sora',
    'Lina',
    'Nino',
    'Maya',
    'Bima',
    'Kira',
    'Hana',
    'Dika',
    'Elara',
    'Taro',
  ],
  farmNames: [
    'Great Valley Farm',
    'Sunrise Meadow Farm',
    'Greenleaf Homestead',
    'Golden Clover Ranch',
    'Whispering Brook Farm',
    'Harvest Breeze Estate',
  ],
  dogNames: [
    'Biscuit',
    'Bobi',
    'Kuro',
    'Milo',
    'Bruno',
    'Sunny',
    'Choco',
    'Rocky',
  ],
  horseNames: [
    'Maple',
    'Gale',
    'Comet',
    'Chestnut',
    'Zephyr',
    'Amber',
    'Storm',
    'Clover',
  ],
  npcRandomNames: [
    'Aldric',
    'Martha',
    'Elian',
    'Daren',
    'Theo',
    'Celia',
    'Felix',
    'Nadia',
    'Gideon',
    'Bruno',
    'Orin',
    'Rowan',
    'Rosa',
    'Mira',
    'Nyra',
    'Silas',
    'Tessa',
    'Kael',
    'Oliver',
    'Ethan',
    'Lily',
    'Mina',
    'Lukas',
    'Sera',
    'Pip',
  ],
};
// DEV_REG_NAMES_END

export function pickRandomFromPool(pool: string[], fallback: string): string {
  const valid = (pool || []).map((s) => s.trim()).filter(Boolean);
  if (valid.length === 0) return fallback;
  return valid[Math.floor(Math.random() * valid.length)];
}

export function generateStarterRegistrationNames(): {
  avatarName: string;
  farmName: string;
  dogName: string;
  horseName: string;
} {
  return {
    avatarName: pickRandomFromPool(REGISTRATION_NAME_CONFIG.farmerNames, 'Arka'),
    farmName: pickRandomFromPool(REGISTRATION_NAME_CONFIG.farmNames, 'Great Valley Farm'),
    dogName: pickRandomFromPool(REGISTRATION_NAME_CONFIG.dogNames, 'Biscuit'),
    horseName: pickRandomFromPool(REGISTRATION_NAME_CONFIG.horseNames, 'Maple'),
  };
}
