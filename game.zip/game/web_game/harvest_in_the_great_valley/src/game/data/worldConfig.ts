import {
  AchievementDef,
  BuildingFacing,
  CharacterAnimConfig,
  DailyMission,
  FestivalDef,
  QuestDef,
  Season,
  Weather,
  WorldZoneId,
} from '../types';

export const DEFAULT_WEATHER: Weather = 'Snowy';
export const STARTER_GOLD = 99999;
export const STARTER_DIAMOND = 99999;

export const CUSTOMIZATION_DIAMOND_COST = 10;

export function getCoopCapacity(level = 1): number {
  if (level >= 3) return 20;
  if (level === 2) return 10;
  return 5;
}

export function getBarnCapacity(level = 1): number {
  if (level >= 3) return 20;
  if (level === 2) return 10;
  return 5;
}

export function getIncubatorCount(coopLevel = 1): number {
  return coopLevel >= 3 ? 2 : 1;
}

export const CHARACTER_ANIM_CONFIG: CharacterAnimConfig = {
  playerWalkSpeed: 6.2,
  playerRunSpeed: 10.6,
  playerDefaultIdlePose: 'relaxed',
  npcIdleSpeed: 1.0,
  defaultPlayerPreset: {
    gender: 'male',
    skinColor: '#fcd5b5',
    eyeColor: '#292524',
    hairStyle: 'none',
    hairColor: '#6b3e1b',
    shirtStyle: 'none',
    outfitColor: '#3a6b2c',
    pantsStyle: 'none',
    pantsColor: '#1e3a8a',
    hatStyle: 'none',
    accessory: 'none',
  },
};

export interface TreeSpeciesDef {
  id: string;
  name: string;
  treeModel: 'oak' | 'pine' | 'birch';
  foliageHex: string;
  scaleMin: number;
  scaleMax: number;
}

export const TREE_SPECIES: TreeSpeciesDef[] = [
  { id: 'tree_oak', name: 'Valley Oak', treeModel: 'oak', foliageHex: '#4f9c3b', scaleMin: 0.88, scaleMax: 1.24 },
  { id: 'tree_emerald_pine', name: 'Emerald Pine', treeModel: 'pine', foliageHex: '#256037', scaleMin: 0.94, scaleMax: 1.34 },
  { id: 'tree_golden_birch', name: 'Golden Birch', treeModel: 'birch', foliageHex: '#7ac143', scaleMin: 0.85, scaleMax: 1.18 },
];

/**
 * Season & Time Acceleration Math:
 * - Spring = 31 days, Summer = 31 days, Autumn = 30 days, Winter = 28 days (Total = 120 in-game days / year)
 * - Average 30 in-game days complete in 14 real-world days (1,209,600 seconds)
 * - 1 in-game day = 14/30 real days = 0.466667 real days = 11 hours 12 minutes = 40,320 real seconds
 * - 1 in-game minute = 40,320 / 1,440 = 28 real seconds (28,000 ms)
 */
export const SEASON_DAYS: Record<Season, number> = {
  Spring: 31,
  Summer: 31,
  Autumn: 30,
  Winter: 28,
};
export const TOTAL_DAYS_PER_YEAR = 31 + 31 + 30 + 28; // 120 days
export const DAYS_PER_SEASON = 30; // Average/legacy fallback; prefer getDaysInSeason(season)
export const REAL_DAYS_PER_SEASON = 14;
export const REAL_SECONDS_PER_GAME_DAY = (REAL_DAYS_PER_SEASON * 86400) / DAYS_PER_SEASON; // 40,320s (11h 12m)
export const REAL_SECONDS_PER_GAME_MINUTE = REAL_SECONDS_PER_GAME_DAY / 1440; // 28 seconds
export const GAME_MINUTES_PER_DAY = 1440;
export const SEASONS_ORDER: Season[] = ['Spring', 'Summer', 'Autumn', 'Winter'];

export function getDaysInSeason(season: Season): number {
  return SEASON_DAYS[season] ?? 30;
}

export function dayOfYearToSeasonDay(dayIndex0To119: number): { season: Season; day: number } {
  let rem = ((Math.floor(dayIndex0To119) % TOTAL_DAYS_PER_YEAR) + TOTAL_DAYS_PER_YEAR) % TOTAL_DAYS_PER_YEAR;
  for (const s of SEASONS_ORDER) {
    const len = SEASON_DAYS[s];
    if (rem < len) {
      return { season: s, day: rem + 1 };
    }
    rem -= len;
  }
  return { season: 'Spring', day: 1 };
}

// Fixed valley epoch so server & clients share smooth deterministic real-to-game progression
export const VALLEY_EPOCH_MS = Date.UTC(2025, 0, 1, 0, 0, 0);

export function getSynchronizedWorldClock(dayOffset = 0, nowMs = Date.now()): {
  year: number;
  season: Season;
  day: number;
  hour: number;
  minute: number;
} {
  const elapsedGameMinutes = Math.floor((nowMs - VALLEY_EPOCH_MS) / (REAL_SECONDS_PER_GAME_MINUTE * 1000));
  const totalGameMinutes = 8 * 60 + elapsedGameMinutes + dayOffset * GAME_MINUTES_PER_DAY;
  const modDayMinutes = ((totalGameMinutes % GAME_MINUTES_PER_DAY) + GAME_MINUTES_PER_DAY) % GAME_MINUTES_PER_DAY;
  const hour = Math.floor(modDayMinutes / 60);
  const minute = modDayMinutes % 60;
  const totalDays = Math.max(0, Math.floor(totalGameMinutes / GAME_MINUTES_PER_DAY));
  const year = Math.floor(totalDays / TOTAL_DAYS_PER_YEAR) + 1;
  const dayInYear = totalDays % TOTAL_DAYS_PER_YEAR;
  const { season, day } = dayOfYearToSeasonDay(dayInYear);
  return { year, season, day, hour, minute };
}

// Expanded 16x14 plantation yard (224 plots) in Spacious Private Far-West Estate (x: -148..-118, z: -4..+22)
export const FARM_GRID_COLS = 16;
export const FARM_GRID_ROWS = 14;
export const FARM_ORIGIN_X = -148;
export const FARM_ORIGIN_Z = -4;
export const FARM_TILE_STEP = 2;

// Generous 16m spacing between Farmhouse, Barn, Coop, and Horse Stable so Lv.1 -> Lv.3 upgrades never crowd!
export const FARMHOUSE_OUTDOOR_SPAWN = { x: -112, z: -17.2 };
export const APPLE_TREE_POS = { x: -94, z: -22 };
export const HORSE_STABLE_POS = { x: -160, z: -21 };
export const DOGHOUSE_POS = { x: -101.8, z: -20.5 };
export const DOG_FOOD_BOWL_POS = { x: -101.8, z: -18.2 };
export const SHIPPING_BIN_POS = { x: -114.5, z: -8.6 };

export interface BuildingPortal {
  id: string;
  name: string;
  interiorZone: WorldZoneId;
  outdoorZone: WorldZoneId;
  doorX: number;
  doorZ: number;
  exitSpawnX: number;
  exitSpawnZ: number;
  facing: BuildingFacing;
  color: string;
  roofColor: string;
  width: number;
  depth: number;
  height: number;
  signEmoji: string;
}

export const BUILDING_PORTALS: BuildingPortal[] = [
  // === EXPANDED PRIVATE FARM ESTATE (Generous clearance between buildings for Lv.3 upgrades) ===
  {
    id: 'farmhouse',
    name: 'Your Farmhouse',
    interiorZone: 'int_farmhouse',
    outdoorZone: 'farm_home',
    doorX: -112,
    doorZ: -21,
    exitSpawnX: -112,
    exitSpawnZ: -17.2,
    facing: 'south',
    color: '#dfd3be',
    roofColor: '#9e3b24',
    width: 7.2,
    depth: 5.8,
    height: 3.9,
    signEmoji: '🏡',
  },
  {
    id: 'barn',
    name: 'Cow & Sheep Barn',
    interiorZone: 'int_barn',
    outdoorZone: 'farm_home',
    doorX: -128,
    doorZ: -21,
    exitSpawnX: -128,
    exitSpawnZ: -17.2,
    facing: 'south',
    color: '#b8422b',
    roofColor: '#5c1f14',
    width: 7.6,
    depth: 6.0,
    height: 4.1,
    signEmoji: '🐄',
  },
  {
    id: 'coop',
    name: 'Chicken Coop',
    interiorZone: 'int_coop',
    outdoorZone: 'farm_home',
    doorX: -144,
    doorZ: -21,
    exitSpawnX: -144,
    exitSpawnZ: -17.2,
    facing: 'south',
    color: '#d8b470',
    roofColor: '#7c3f1d',
    width: 6.0,
    depth: 5.0,
    height: 3.5,
    signEmoji: '🐔',
  },
  {
    id: 'stable',
    name: 'Horse Stable',
    interiorZone: 'int_stable',
    outdoorZone: 'farm_home',
    doorX: -160,
    doorZ: -21,
    exitSpawnX: -160,
    exitSpawnZ: -17.2,
    facing: 'south',
    color: '#9c6638',
    roofColor: '#4e2b14',
    width: 6.6,
    depth: 5.4,
    height: 3.7,
    signEmoji: '🐴',
  },

  // === GREAT VALLEY TOWN & TOWN SQUARE ===
  {
    id: 'ranch',
    name: 'Felix’s Valley Ranch',
    interiorZone: 'int_ranch',
    outdoorZone: 'village_square',
    doorX: -34,
    doorZ: -13,
    exitSpawnX: -34,
    exitSpawnZ: -10.0,
    facing: 'south',
    color: '#f4e6a7',
    roofColor: '#2a6434',
    width: 6.8,
    depth: 5.4,
    height: 3.8,
    signEmoji: '🐑',
  },
  {
    id: 'inn',
    name: 'Rosa’s Hearth Inn',
    interiorZone: 'int_inn',
    outdoorZone: 'village_square',
    doorX: -20,
    doorZ: 8,
    exitSpawnX: -17.0,
    exitSpawnZ: 8,
    facing: 'east',
    color: '#efe0b8',
    roofColor: '#8c4419',
    width: 7.0,
    depth: 5.4,
    height: 3.9,
    signEmoji: '🍲',
  },
  {
    id: 'manor',
    name: 'Aldric’s Town Hall',
    interiorZone: 'int_manor',
    outdoorZone: 'village_square',
    doorX: -8,
    doorZ: -24,
    exitSpawnX: -8,
    exitSpawnZ: -21.0,
    facing: 'south',
    color: '#f4efe6',
    roofColor: '#2d5a27',
    width: 7.8,
    depth: 6.0,
    height: 4.3,
    signEmoji: '🏛️',
  },
  {
    id: 'general_store',
    name: 'Theo’s General Store',
    interiorZone: 'int_general_store',
    outdoorZone: 'village_square',
    doorX: 14,
    doorZ: -24,
    exitSpawnX: 14,
    exitSpawnZ: -21.0,
    facing: 'south',
    color: '#f3dfb4',
    roofColor: '#3f7634',
    width: 6.6,
    depth: 5.4,
    height: 3.7,
    signEmoji: '🛒',
  },
  {
    id: 'bakery',
    name: 'Nadia’s Bakery & Kitchen',
    interiorZone: 'int_bakery',
    outdoorZone: 'village_square',
    doorX: 28,
    doorZ: -10,
    exitSpawnX: 25.0,
    exitSpawnZ: -10,
    facing: 'west',
    color: '#f5d2ac',
    roofColor: '#b45309',
    width: 6.0,
    depth: 5.0,
    height: 3.6,
    signEmoji: '🥐',
  },
  {
    id: 'flower_shop',
    name: 'Celia’s Flower Shop',
    interiorZone: 'int_flower_shop',
    outdoorZone: 'village_square',
    doorX: 28,
    doorZ: 10,
    exitSpawnX: 25.0,
    exitSpawnZ: 10,
    facing: 'west',
    color: '#f5cedb',
    roofColor: '#9d2b57',
    width: 5.8,
    depth: 5.0,
    height: 3.5,
    signEmoji: '🌷',
  },
  {
    id: 'library',
    name: 'Great Valley Library',
    interiorZone: 'int_library',
    outdoorZone: 'village_square',
    doorX: 14,
    doorZ: 24,
    exitSpawnX: 14,
    exitSpawnZ: 21.0,
    facing: 'north',
    color: '#e8e2d0',
    roofColor: '#4e3b2b',
    width: 6.8,
    depth: 5.4,
    height: 4.0,
    signEmoji: '📚',
  },
  {
    id: 'clinic',
    name: 'Dr. Gideon’s Clinic',
    interiorZone: 'int_clinic',
    outdoorZone: 'village_square',
    doorX: -6,
    doorZ: 24,
    exitSpawnX: -6,
    exitSpawnZ: 21.0,
    facing: 'north',
    color: '#f8faf8',
    roofColor: '#2f6b56',
    width: 6.2,
    depth: 5.2,
    height: 3.7,
    signEmoji: '🩺',
  },

  // === MOUNTAIN MINE BLACKSMITH & WHISPERING CAVE ===
  {
    id: 'blacksmith',
    name: 'Bruno’s Smithy',
    interiorZone: 'int_blacksmith',
    outdoorZone: 'mountain_mine',
    doorX: 6,
    doorZ: -40,
    exitSpawnX: 6,
    exitSpawnZ: -37.0,
    facing: 'south',
    color: '#cbd2d6',
    roofColor: '#3f4750',
    width: 6.6,
    depth: 5.2,
    height: 3.8,
    signEmoji: '⚒️',
  },
  {
    id: 'cave',
    name: 'Whispering Mountain Cave',
    interiorZone: 'int_cave',
    outdoorZone: 'mountain_mine',
    doorX: -48,
    doorZ: -62,
    exitSpawnX: -48,
    exitSpawnZ: -58.2,
    facing: 'south',
    color: '#475569',
    roofColor: '#1e293b',
    width: 6.0,
    depth: 4.2,
    height: 4.0,
    signEmoji: '🪨',
  },
];

export const ZONE_LABELS: Record<WorldZoneId, string> = {
  farm_home: 'Private Homestead (West)',
  village_square: 'Great Valley Town Square',
  forest: 'Whispering Woods',
  river_beach: 'Eastern River & Ocean Coast',
  mountain_mine: 'Northern Mountain & Mine',
  secret_grove: 'Ancient Secret Grove',
  int_farmhouse: 'Inside Farmhouse',
  int_barn: 'Cow & Sheep Barn',
  int_coop: 'Chicken Coop',
  int_stable: 'Horse Stable',
  int_general_store: 'Theo’s General Store',
  int_blacksmith: 'Bruno’s Smithy',
  int_flower_shop: 'Celia’s Flower Shop',
  int_ranch: 'Felix’s Valley Ranch',
  int_clinic: 'Dr. Gideon’s Clinic',
  int_inn: 'Rosa’s Hearth Inn',
  int_bakery: 'Nadia’s Bakery & Kitchen',
  int_library: 'Mira’s Library',
  int_manor: 'Aldric’s Town Hall',
  int_cave: 'Whispering Mountain Cave',
};

export const FESTIVALS: FestivalDef[] = [
  {
    id: 'fest_new_year',
    name: 'New Year Spring Feast',
    season: 'Spring',
    day: 1,
    startHour: 10,
    endHour: 18,
    activityLabel: 'Toast the New Year & Music Dance',
    rewardGold: 500,
    hostNpcId: 'aldric',
    locationZone: 'village_square',
    description: 'All villagers gather at Town Square to welcome the New Year with warm soup, music, and cheers!',
  },
  {
    id: 'fest_goddess',
    name: 'Spring Goddess Festival',
    season: 'Spring',
    day: 8,
    startHour: 10,
    endHour: 18,
    activityLabel: 'Flower Crown Dance',
    rewardGold: 600,
    hostNpcId: 'celia',
    locationZone: 'village_square',
    description: 'Inspired by Harvest Moon traditions — every villager gathers at Town Square for floral dances and blossoms!',
  },
  {
    id: 'fest_egg',
    name: 'Spring Egg & Horse Derby',
    season: 'Spring',
    day: 18,
    startHour: 10,
    endHour: 18,
    activityLabel: 'Town Square Egg Hunt & Cheer',
    rewardGold: 650,
    hostNpcId: 'felix',
    locationZone: 'village_square',
    description: 'Townsfolk and children gather in Town Square for colorful egg hunts and lively ranch cheers.',
  },
  {
    id: 'fest_cooking',
    name: 'Great Valley Cooking Festival',
    season: 'Spring',
    day: 22,
    startHour: 10,
    endHour: 18,
    activityLabel: 'Taste & Judge Gourmet Dishes',
    rewardGold: 750,
    hostNpcId: 'martha',
    locationZone: 'village_square',
    description: 'Martha & Nadia host a lively culinary showdown right in Town Square with all 25 villagers tasting!',
  },
  {
    id: 'fest_tomato',
    name: 'Summer Tomato Splash Festival',
    season: 'Summer',
    day: 12,
    startHour: 10,
    endHour: 18,
    activityLabel: 'Friendly Tomato Toss Contest',
    rewardGold: 700,
    hostNpcId: 'daren',
    locationZone: 'village_square',
    description: 'Classic Summer excitement! Everyone gathers at Town Square for a playful harvest tomato contest.',
  },
  {
    id: 'fest_fireworks',
    name: 'Midsummer Harvest Fair',
    season: 'Summer',
    day: 24,
    startHour: 10,
    endHour: 18,
    activityLabel: 'Showcase Crops & Lantern Toast',
    rewardGold: 800,
    hostNpcId: 'rowan',
    locationZone: 'village_square',
    description: 'Villagers pack Town Square with prize crops, grilled fish stalls, and Summer evening cheer.',
  },
  {
    id: 'fest_harvest_pot',
    name: 'Autumn Harvest Stew Festival',
    season: 'Autumn',
    day: 9,
    startHour: 10,
    endHour: 18,
    activityLabel: 'Contribute to the Giant Village Pot',
    rewardGold: 750,
    hostNpcId: 'martha',
    locationZone: 'village_square',
    description: 'Every villager brings an Autumn ingredient to Town Square for the giant communal harvest pot!',
  },
  {
    id: 'fest_animal',
    name: 'Valley Livestock & Sheep Festival',
    season: 'Autumn',
    day: 21,
    startHour: 10,
    endHour: 18,
    activityLabel: 'Livestock Parade & Ribbon Award',
    rewardGold: 850,
    hostNpcId: 'felix',
    locationZone: 'village_square',
    description: 'Celebrate healthy cows, woolly sheep, prize hens, dogs, and horses together in Town Square.',
  },
  {
    id: 'fest_snow',
    name: 'Winter Snow & Hot Cocoa Festival',
    season: 'Winter',
    day: 11,
    startHour: 10,
    endHour: 18,
    activityLabel: 'Snow Sculpture & Hearth Feast',
    rewardGold: 700,
    hostNpcId: 'aldric',
    locationZone: 'village_square',
    description: 'All villagers bundle up at Town Square for snow sculpting and steaming mugs of hot cocoa.',
  },
  {
    id: 'fest_star',
    name: 'Starry Night Lantern Festival',
    season: 'Winter',
    day: 24,
    startHour: 10,
    endHour: 18,
    activityLabel: 'Release Starlight Wish Lanterns',
    rewardGold: 1000,
    hostNpcId: 'nyra',
    locationZone: 'village_square',
    description: 'An unforgettable Winter gathering at Town Square under glowing star lanterns with every villager.',
  },
];

export const QUESTS: QuestDef[] = [
  {
    id: 'quest_aldric_welcome',
    npcId: 'aldric',
    title: 'Reviving the Valley Farm',
    description: 'Harvest and bring 3 Fresh Turnips to Mayor Aldric to mark your homestead’s rebirth.',
    requiredItemId: 'crop_turnip',
    requiredQty: 3,
    rewardGold: 450,
    rewardFriendship: 60,
  },
  {
    id: 'quest_daren_crops',
    npcId: 'daren',
    title: 'Veteran Farmer’s Secret',
    description: 'Deliver 2 Golden Potatoes to Daren to unlock advanced soil & fertilizer insight.',
    requiredItemId: 'crop_potato',
    requiredQty: 2,
    rewardGold: 550,
    rewardFriendship: 60,
    unlocksFeature: 'advanced_farming',
  },
  {
    id: 'quest_elian_relic',
    npcId: 'elian',
    title: 'Mystery of the Ancient Valley',
    description: 'Find 1 Ancient Valley Relic inside Whispering Mountain Cave and hand it to Elian to unlock the Secret Grove!',
    requiredItemId: 'mat_ancient_relic',
    requiredQty: 1,
    rewardGold: 900,
    rewardFriendship: 80,
    unlocksFeature: 'secret_grove',
  },
  {
    id: 'quest_orin_forest',
    npcId: 'orin',
    title: 'Keeper of Whispering Woods',
    description: 'Chop 5 Hardwood Timber and help Orin maintain the forest trails.',
    requiredItemId: 'mat_wood',
    requiredQty: 5,
    rewardGold: 420,
    rewardFriendship: 70,
  },
  {
    id: 'quest_nyra_magic',
    npcId: 'nyra',
    title: 'Nyra’s Luminous Crystal',
    description: 'Gift 1 Blue Crystal to Nyra to unlock enchanted Starfrost Seeds.',
    requiredItemId: 'mat_crystal',
    requiredQty: 1,
    rewardGold: 850,
    rewardFriendship: 80,
    unlocksFeature: 'magic_seeds',
  },
  {
    id: 'quest_rowan_fish',
    npcId: 'rowan',
    title: 'Legend of the Golden Koi',
    description: 'Catch 1 Rare Golden Koi from the river and show it to Rowan.',
    requiredItemId: 'fish_golden_koi',
    requiredQty: 1,
    rewardGold: 950,
    rewardFriendship: 85,
    unlocksFeature: 'rare_rod',
  },
];

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: 'ach_first_harvest', title: 'First Harvest', description: 'Harvest your very first crop in Great Valley.', rewardGold: 250, icon: '🌾' },
  { id: 'ach_green_thumb', title: 'Green Thumb', description: 'Harvest a total of 15 crops.', rewardGold: 600, icon: '🌱' },
  { id: 'ach_friend_village', title: 'Friendly Neighbor', description: 'Reach Friend tier (250+ FP) with 3 villagers.', rewardGold: 500, icon: '💛' },
  { id: 'ach_master_angler', title: 'Valley Angler', description: 'Catch 5 fish from the river or ocean.', rewardGold: 450, icon: '🎣' },
  { id: 'ach_wealthy_farmer', title: 'Valley Merchant', description: 'Earn 3,000 Gold in total revenue.', rewardGold: 800, icon: '💰' },
  { id: 'ach_secret_finder', title: 'Ancient Explorer', description: 'Unlock the Ancient Secret Grove with Elian.', rewardGold: 1000, icon: '✨' },
  { id: 'ach_true_love', title: 'Eternal Bond', description: 'Marry a villager or partner in Great Valley.', rewardGold: 1500, icon: '💍' },
];

export const DAILY_MISSION_TEMPLATES: Omit<DailyMission, 'progress' | 'claimed'>[] = [
  { id: 'dm_plant', title: 'Plant Seeds', description: 'Plant 5 seeds on your farm today.', type: 'plant', target: 5, rewardGold: 200 },
  { id: 'dm_water', title: 'Water Crops', description: 'Water 8 farm plots today.', type: 'water', target: 8, rewardGold: 160 },
  { id: 'dm_harvest', title: 'Fresh Harvest', description: 'Harvest 4 ripe crops.', type: 'harvest', target: 4, rewardGold: 240 },
  { id: 'dm_talk', title: 'Greet Villagers', description: 'Talk with 3 different NPCs.', type: 'talk_npc', target: 3, rewardGold: 160 },
  { id: 'dm_animal', title: 'Care for Animals', description: 'Feed 2 livestock or pets.', type: 'feed_animal', target: 2, rewardGold: 180 },
  { id: 'dm_fish', title: 'Relaxing Fishing', description: 'Catch 2 fish at the river or ocean.', type: 'catch_fish', target: 2, rewardGold: 220 },
  { id: 'dm_gather', title: 'Gather Materials', description: 'Gather 3 timber, stone, or ore.', type: 'gather', target: 3, rewardGold: 180 },
];

export const DIAMOND_PACKAGES = [
  { id: 'pkg_pouch', name: 'Valley Diamond Pouch', diamonds: 25, priceLabel: '$0.99' },
  { id: 'pkg_chest', name: 'Farmer Crystal Chest', diamonds: 80, priceLabel: '$2.99' },
  { id: 'pkg_royal', name: 'Great Valley Crown', diamonds: 200, priceLabel: '$6.99' },
];
