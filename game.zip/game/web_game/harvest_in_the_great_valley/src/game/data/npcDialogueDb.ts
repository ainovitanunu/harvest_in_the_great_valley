import {
  Language,
  NPCData,
  NPCRelationshipState,
  NpcDialogueDatabase,
  NpcEmotion,
  NpcProfessionRole,
  Season,
  Weather,
} from '../types';
import { BILINGUAL_NPC_DIALOGUES, pickLocalizedNpcCategoryLine } from './npcDialoguesLocalized';

/**
 * Editable & Extensible Living Village NPC Dialogue Database.
 * Supports template variables: {playerName}, {npcName}, {partnerName}, {season}, {weather}, {giftName}, {farmName}.
 * Developers can edit existing categories or add brand-new dialogue categories directly from the Developer Dashboard.
 */
// DEV_DIALOGUE_DB_START
export const NPC_DIALOGUE_DATABASE: NpcDialogueDatabase = {
  version: 1,
  updatedAt: '2026-11-23T00:00:00.000Z',
  categories: {
    time_morning: {
      id: 'time_morning',
      label: 'Morning Greeting',
      description: 'Spoken between 06:00 and 11:59',
      lines: [
        'Good morning, {playerName}! The valley dew makes everything sparkle today.',
        'Rise and shine, {playerName}! Early birds always get the best harvest.',
        'Fresh {season} morning air always wakes me right up. How is {farmName} doing?',
        'Morning, {playerName}! Ready to make today a productive one?',
      ],
    },
    time_afternoon: {
      id: 'time_afternoon',
      label: 'Afternoon Greeting',
      description: 'Spoken between 12:00 and 16:59',
      lines: [
        'Good afternoon, {playerName}! Remember to take a breather under the shade.',
        'The village is buzzing with energy this afternoon, {playerName}!',
        'Have you stopped by the town square yet, {playerName}? Everyone is out and about.',
        'Midday already! Time flies when you love living in the Great Valley.',
      ],
    },
    time_evening: {
      id: 'time_evening',
      label: 'Evening Greeting',
      description: 'Spoken between 17:00 and 20:59',
      lines: [
        'What a golden sunset, {playerName}. You worked hard at {farmName} today!',
        'Good evening, {playerName}! The smell of fresh dinner is drifting across town.',
        'Winding down after a long {season} day feels so peaceful.',
        'Evening, {playerName}! Make sure you get some rest before tomorrow.',
      ],
    },
    time_night: {
      id: 'time_night',
      label: 'Night Greeting',
      description: 'Spoken after 21:00',
      lines: [
        'Still awake this late, {playerName}? The stars above the valley are crystal clear.',
        'Better head home soon, {playerName} — a good farmer needs sleep!',
        'The night breeze is cool and quiet. I am heading back to rest myself.',
      ],
    },
    weather_rainy: {
      id: 'weather_rainy',
      label: 'Rainy Weather',
      description: 'Reacting to rain',
      lines: [
        'Listen to that rain, {playerName}! At least your crops at {farmName} get watered for free.',
        'I am taking shelter until the rain eases up. Stay dry out there!',
        'Rainy days make the valley smell like fresh pine and wet earth.',
      ],
    },
    weather_stormy: {
      id: 'weather_stormy',
      label: 'Stormy Weather',
      description: 'Reacting to heavy storm',
      lines: [
        'Whoa, that wind is wild! Stay indoors if you can, {playerName}!',
        'I hurried under cover as soon as the thunder rolled in. Check on your animals!',
        'What a fierce storm! Hope the fences at {farmName} hold strong.',
      ],
    },
    weather_sunny_hot: {
      id: 'weather_sunny_hot',
      label: 'Warm Sunny Day',
      description: 'Reacting to bright sunshine or summer heat',
      lines: [
        'Such bright sunshine today! Perfect weather to watch the crops thrive.',
        'Phew, the sun is strong today, {playerName}! Do not forget to rest in the shade.',
        'Blue skies over the Great Valley always lift my spirits!',
      ],
    },
    weather_snowy: {
      id: 'weather_snowy',
      label: 'Snowy Weather',
      description: 'Reacting to winter snow',
      lines: [
        'Brrr! Snowflakes are blanketing the roofs — looks like a storybook, {playerName}.',
        'Keep warm today! A hot cup of tea by the hearth sounds wonderful.',
        'Careful on the snowy paths, {playerName}!',
      ],
    },
    festival_day: {
      id: 'festival_day',
      label: 'Festival Celebration',
      description: 'Spoken during village festivals',
      lines: [
        'Happy Festival Day, {playerName}! The whole valley came together for this!',
        'I have been looking forward to today all {season}! Let us celebrate!',
        'Look at all the smiling faces in the square — festivals make Great Valley magical.',
      ],
    },
    profession_miner: {
      id: 'profession_miner',
      label: 'Profession: Miner',
      description: 'Autonomous mine workers (Kael, Bruno)',
      lines: [
        'Just struck a glittering vein in the mountain cave! My arms are feeling it.',
        'Hauling fresh copper and iron ore back for the forge — heavy work, good payoff!',
        'The deeper cave shafts hold rare gems, {playerName}. Bring a sturdy hammer!',
        'Time to rest my shoulders before the next ore run.',
      ],
    },
    profession_lumberjack: {
      id: 'profession_lumberjack',
      label: 'Profession: Lumberjack',
      description: 'Autonomous forest lumberjacks (Oliver, Daren)',
      lines: [
        'Timber! I only chop mature trees and leave the saplings room to grow.',
        'Carrying freshly cut logs back to the workshop keeps me strong!',
        'The forest air smells like fresh cedar after a good morning of chopping.',
        'I noticed some cleared clearings earlier, so I moved deeper into the woods.',
      ],
    },
    profession_shopkeeper: {
      id: 'profession_shopkeeper',
      label: 'Profession: Shopkeeper',
      description: 'Town shopkeepers welcoming & tidying shelves',
      lines: [
        'Welcome in, {playerName}! Fresh stock is lined up and ready for you.',
        'Just tidying the shelves and counting inventory — press F anytime if you want to browse!',
        'Business has been lively today! Tell me if you need seeds, tools, or supplies.',
        'I keep the counter spotless for my favorite neighbor from {farmName}.',
      ],
    },
    profession_angler: {
      id: 'profession_angler',
      label: 'Profession: Angler',
      description: 'Autonomous river & beach fishers (Rowan, Ethan)',
      lines: [
        'Shhh... I just felt a nibble on the line! Patience is the secret to big fish.',
        'I rotate between the river dock and ocean pier whenever the school moves.',
        'Nothing beats the sound of water lapping the pier while waiting for a bite!',
        'Caught a beauty earlier — heading to the market soon to see what it fetches.',
      ],
    },
    emotion_happy: {
      id: 'emotion_happy',
      label: 'Emotion: Happy',
      description: 'Cheerful mood dialogue',
      lines: [
        'Seeing you always brightens my whole day, {playerName}!',
        'Everything feels right in the world today — I could hum a tune all afternoon!',
        'Life in the Great Valley is genuinely wonderful, isn\'t it?',
      ],
    },
    emotion_tired: {
      id: 'emotion_tired',
      label: 'Emotion: Tired',
      description: 'Fatigued after hard work or late hours',
      lines: [
        '*Yawn*... My feet are aching after all that work today, {playerName}.',
        'I really need a quick sit on a square bench and a tall glass of water.',
        'Working hard feels rewarding, though my eyelids are getting heavy.',
      ],
    },
    emotion_sad: {
      id: 'emotion_sad',
      label: 'Emotion: Sad',
      description: 'Melancholy or gloomy weather mood',
      lines: [
        'Sigh... some days feel a little heavier than others, {playerName}.',
        'Thanks for stopping to talk to me — it honestly helps lift the gloom.',
        'I hope tomorrow brings clearer skies and brighter news.',
      ],
    },
    emotion_angry: {
      id: 'emotion_angry',
      label: 'Emotion: Frustrated / Grumpy',
      description: 'Annoyed by rough weather, stubborn ore, or long shift',
      lines: [
        'Hmph! Nothing went smoothly this hour — even my tools are acting stubborn!',
        'Sorry if I sound gruff, {playerName}. I just need a minute to cool off.',
        'Ugh, this weather ruined my plans for the whole afternoon!',
      ],
    },
    emotion_nervous: {
      id: 'emotion_nervous',
      label: 'Emotion: Nervous',
      description: 'Shy or uneasy during storms or romance moments',
      lines: [
        'Oh! {playerName}, you startled me a bit — I was lost in thought!',
        'Is that thunder getting closer? I always get jittery during valley storms...',
        'H-hey, {playerName}... I was actually hoping I might run into you today.',
      ],
    },
    emotion_excited: {
      id: 'emotion_excited',
      label: 'Emotion: Excited',
      description: 'Enthusiastic about festivals, harvests, or good news',
      lines: [
        'Oh! {playerName}! I have so much energy today I can barely stand still!',
        'Wait until you see how lively the valley is right now — this is awesome!',
        'Best {season} we have had in years! Let us make it unforgettable!',
      ],
    },
    relationship_stranger: {
      id: 'relationship_stranger',
      label: 'Relationship: Stranger / Newcomer',
      description: 'Low friendship (Hearts 0-1)',
      lines: [
        'You are {playerName} from {farmName}, right? Welcome to the Great Valley!',
        'Nice to meet you, {playerName}. Stop by and chat whenever you have time.',
      ],
    },
    relationship_friend: {
      id: 'relationship_friend',
      label: 'Relationship: Friend',
      description: 'Friendly bond (Hearts 2-5)',
      lines: [
        'Hey there, my friend {playerName}! Always great catching up with you.',
        'You have really brought {farmName} back to life — the whole town talks about it!',
      ],
    },
    relationship_close: {
      id: 'relationship_close',
      label: 'Relationship: Close / Best Friend',
      description: 'High bond (Hearts 6-10)',
      lines: [
        '{playerName}, you are one of the people I trust most in the entire valley.',
        'Whenever you walk by, I feel like home is right here. Thank you for being such a dear friend!',
      ],
    },
    relationship_romance: {
      id: 'relationship_romance',
      label: 'Relationship: Romantic / Partner',
      description: 'Partner or Spouse dialogue',
      lines: [
        'My heart still skips a beat when you walk over, {playerName}.',
        'Every season with you at {farmName} feels like a dream come true, {playerName}.',
      ],
    },
    memory_gift: {
      id: 'memory_gift',
      label: 'Memory: Recent Gift',
      description: 'References a remembered gift from the player',
      lines: [
        'I still smile thinking about that {giftName} you gave me, {playerName}!',
        'Thank you again for the {giftName}, {playerName} — you really know what I love.',
      ],
    },
    memory_quest: {
      id: 'memory_quest',
      label: 'Memory: Helped with Quest',
      description: 'Remembers the player completing favors/quests',
      lines: [
        'I have not forgotten how you helped me out earlier, {playerName}. You are a lifesaver!',
        'Thanks to your help with my request, everything has been running smoothly!',
      ],
    },
    memory_farm: {
      id: 'memory_farm',
      label: 'Memory: Farm Reputation',
      description: 'Reacts to player harvest & farming milestones',
      lines: [
        'Word around town is {farmName} has been producing incredible harvests lately!',
        'Everyone at the market raves about the produce coming from {farmName}, {playerName}!',
      ],
    },
    npc_to_npc_greet: {
      id: 'npc_to_npc_greet',
      label: 'NPC-to-NPC Conversation Starters',
      description: 'Overhead lines spoken when two NPCs meet',
      lines: [
        'Hey {partnerName}! How is your day treating you?',
        'Good seeing you out here, {partnerName}!',
        '{partnerName}! Have you tried the fresh bread from the bakery today?',
        'Nice weather for a stroll, huh {partnerName}?',
        'Working hard as always, {partnerName}!',
      ],
    },
    npc_to_npc_reply: {
      id: 'npc_to_npc_reply',
      label: 'NPC-to-NPC Replies',
      description: 'Overhead replies during NPC-to-NPC chats',
      lines: [
        'Doing great, {partnerName}! The valley feels so lively today.',
        'Keeping busy, {partnerName}! Let us catch up at the square later.',
        'Haha, you know me — always something to tidy or harvest!',
        'Couldn\'t be better! Hope your afternoon goes smoothly too!',
      ],
    },
    ambient_thought: {
      id: 'ambient_thought',
      label: 'Ambient Overhead Thoughts',
      description: 'Short thought bubbles NPCs show while going about their day',
      lines: [
        'Hmm, what should I cook for dinner tonight?',
        'What a peaceful breeze across the valley...',
        'I should visit the general store before sunset.',
        'Hope the harvest festival is extra lively this season!',
        'Maybe I will sit by the square fountain for a bit.',
        'Those birds are singing such a sweet melody today.',
      ],
    },
    shop_welcome: {
      id: 'shop_welcome',
      label: 'Shopkeeper Proximity Welcome',
      description: 'Spoken overhead when player approaches an open shop',
      lines: [
        'Welcome, {playerName}! Browse anytime with F!',
        'Come on in, {playerName}! Best goods in Great Valley!',
        'Good to see you, {playerName}! Fresh supplies just arrived!',
      ],
    },
    shop_tidy: {
      id: 'shop_tidy',
      label: 'Shopkeeper Tidying Thoughts',
      description: 'Spoken while shopkeeper organizes shelves during quiet hours',
      lines: [
        'Dusting the counter and lining up the jars...',
        'Let me check today\'s stock ledger.',
        'Everything neat and tidy for the next customer!',
      ],
    },
  },
};
// DEV_DIALOGUE_DB_END

let runtimeDialogueDb: NpcDialogueDatabase = NPC_DIALOGUE_DATABASE;

export function getNpcDialogueDatabase(): NpcDialogueDatabase {
  return runtimeDialogueDb;
}

export function setNpcDialogueDatabase(next: NpcDialogueDatabase): void {
  if (next && next.categories && typeof next.categories === 'object') {
    runtimeDialogueDb = next;
  }
}

export function getNpcProfessionRole(npcId: string): NpcProfessionRole {
  if (npcId === 'kael') return 'miner';
  if (npcId === 'oliver' || npcId === 'daren') return 'lumberjack';
  if (npcId === 'rowan' || npcId === 'ethan') return 'angler';
  if (
    npcId === 'theo' ||
    npcId === 'celia' ||
    npcId === 'felix' ||
    npcId === 'nadia' ||
    npcId === 'rosa' ||
    npcId === 'bruno' ||
    npcId === 'gideon' ||
    npcId === 'mira'
  ) {
    return 'shopkeeper';
  }
  return 'villager';
}

export function formatDialogueTemplate(
  template: string,
  vars: {
    playerName?: string;
    npcName?: string;
    partnerName?: string;
    season?: string;
    weather?: string;
    giftName?: string;
    farmName?: string;
  }
): string {
  return template
    .replace(/\{playerName\}/g, vars.playerName || 'Farmer')
    .replace(/\{npcName\}/g, vars.npcName || 'Villager')
    .replace(/\{partnerName\}/g, vars.partnerName || 'friend')
    .replace(/\{season\}/g, vars.season || 'Spring')
    .replace(/\{weather\}/g, vars.weather || 'Sunny')
    .replace(/\{giftName\}/g, vars.giftName || 'thoughtful gift')
    .replace(/\{farmName\}/g, vars.farmName || 'your farm');
}

function pickFromCategory(categoryId: string, lang: Language = 'en', seedOffset = 0): string | null {
  if (lang === 'id') {
    const idLine = pickLocalizedNpcCategoryLine('id', categoryId, null);
    if (idLine) return idLine;
  }
  const cat = runtimeDialogueDb.categories[categoryId];
  const extraLines = lang === 'en' ? BILINGUAL_NPC_DIALOGUES.en[categoryId] : undefined;
  const combined = [...(cat?.lines || []), ...(extraLines || [])];
  if (combined.length === 0) return null;
  const idx = Math.abs(Math.floor(Math.random() * combined.length) + seedOffset) % combined.length;
  return combined[idx] || combined[0];
}

export interface ContextualDialogueInput {
  npc: NPCData;
  relationship?: NPCRelationshipState;
  playerName: string;
  farmName: string;
  season: Season;
  weather: Weather;
  hour: number;
  isFestivalToday: boolean;
  emotion: NpcEmotion;
  cropsHarvestedTotal: number;
  lastGiftName?: string;
  language?: Language;
  activity?: 'farming' | 'eating' | 'socializing' | 'walking' | 'sleeping' | 'shopping' | 'work';
}

export function pickContextualNpcLine(input: ContextualDialogueInput): string {
  const {
    npc,
    relationship,
    playerName,
    farmName,
    season,
    weather,
    hour,
    isFestivalToday,
    emotion,
    cropsHarvestedTotal,
    lastGiftName,
    language = 'en',
    activity,
  } = input;

  const role = getNpcProfessionRole(npc.id);
  const pool: string[] = [];

  // 1. Personal NPC character lines (English) or localized seasonal/activity opener (Indonesian)
  if (language === 'en') {
    if (hour < 12 && npc.dialogues.greetingMorning.length > 0) {
      pool.push(npc.dialogues.greetingMorning[Math.floor(Math.random() * npc.dialogues.greetingMorning.length)]);
    } else if (hour < 17 && npc.dialogues.greetingAfternoon.length > 0) {
      pool.push(npc.dialogues.greetingAfternoon[Math.floor(Math.random() * npc.dialogues.greetingAfternoon.length)]);
    } else if (npc.dialogues.greetingEvening.length > 0) {
      pool.push(npc.dialogues.greetingEvening[Math.floor(Math.random() * npc.dialogues.greetingEvening.length)]);
    }
  } else {
    const seasonKey = `season_${season.toLowerCase()}`;
    const sLine = pickFromCategory(seasonKey, language);
    if (sLine) pool.push(sLine);
  }

  // 2. Festival & Weather priority lines
  if (isFestivalToday) {
    const festLine = pickFromCategory('festival_day', language);
    if (festLine) pool.push(festLine, festLine);
  }
  if (weather === 'Stormy') {
    const l = pickFromCategory('weather_stormy', language);
    if (l) pool.push(l, l);
  } else if (weather === 'HeavyRain') {
    const l = pickFromCategory('weather_heavy_rain', language) || pickFromCategory('weather_rainy', language);
    if (l) pool.push(l, l);
  } else if (weather === 'LightRain') {
    const l = pickFromCategory('weather_light_rain', language) || pickFromCategory('weather_rainy', language);
    if (l) pool.push(l);
  } else if (weather === 'Rainy') {
    const l = pickFromCategory('weather_rainy', language);
    if (l) pool.push(l);
  } else if (weather === 'Foggy') {
    const l = pickFromCategory('weather_foggy', language);
    if (l) pool.push(l);
  } else if (weather === 'Snowy') {
    const l = pickFromCategory('weather_snowy', language);
    if (l) pool.push(l);
  } else if (weather === 'Sunny' && season === 'Summer' && hour >= 11 && hour <= 15) {
    const l = pickFromCategory('weather_sunny_hot', language);
    if (l) pool.push(l);
  }

  // 3. Time-of-day category
  const timeCat =
    hour < 12 ? 'time_morning' : hour < 17 ? 'time_afternoon' : hour < 21 ? 'time_evening' : 'time_night';
  const timeLine = pickFromCategory(timeCat, language);
  if (timeLine) pool.push(timeLine);

  // 4. Activity & Profession-specific lines
  if (activity && activity !== 'work') {
    const actLine = pickFromCategory(`activity_${activity}`, language);
    if (actLine) pool.push(actLine, actLine);
  }
  if (role !== 'villager') {
    const profLine = pickFromCategory(`profession_${role}`, language);
    if (profLine) pool.push(profLine);
  }

  // 5. Emotion-driven line
  if (emotion !== 'neutral') {
    const emoLine = pickFromCategory(`emotion_${emotion}`, language);
    if (emoLine) pool.push(emoLine, emoLine);
  }

  // 6. Relationship & Memory lines
  const hearts = relationship?.heartLevel ?? 0;
  if (relationship?.romanceStage === 'Married' || relationship?.romanceStage === 'Partner') {
    const l = pickFromCategory('relationship_romance', language);
    if (l) pool.push(l, l);
  } else if (hearts >= 6) {
    const l = pickFromCategory('relationship_close', language);
    if (l) pool.push(l);
  } else if (hearts >= 2) {
    const l = pickFromCategory('relationship_friend', language);
    if (l) pool.push(l);
  } else {
    const l = pickFromCategory('relationship_stranger', language);
    if (l) pool.push(l);
  }

  if (lastGiftName || (relationship?.memory.favoriteGiftsRemembered.length ?? 0) > 0) {
    const l = pickFromCategory('memory_gift', language);
    if (l) pool.push(l);
  }
  if ((relationship?.memory.completedQuests.length ?? 0) > 0) {
    const l = pickFromCategory('memory_quest', language);
    if (l) pool.push(l);
  }
  if (cropsHarvestedTotal >= 8) {
    const l = pickFromCategory('memory_farm', language);
    if (l) pool.push(l);
  }

  // 7. Include any custom developer-added dialogue categories!
  const builtInPrefix = /^(time_|weather_|festival_|profession_|activity_|season_|emotion_|relationship_|memory_|npc_to_npc_|ambient_|shop_)/;
  for (const catId of Object.keys(runtimeDialogueDb.categories)) {
    if (!builtInPrefix.test(catId)) {
      const customLine = pickFromCategory(catId, language);
      if (customLine) pool.push(customLine);
    }
  }

  const seasonLabel =
    language === 'id'
      ? season === 'Spring'
        ? 'Musim Semi'
        : season === 'Summer'
          ? 'Musim Panas'
          : season === 'Autumn'
            ? 'Musim Gugur'
            : 'Musim Dingin'
      : season;

  const chosen =
    pool[Math.floor(Math.random() * pool.length)] ||
    (language === 'id' ? `Halo, ${playerName}! Senang bertemu di Great Valley.` : `Hello, ${playerName}!`);
  return formatDialogueTemplate(chosen, {
    playerName,
    npcName: npc.name,
    season: seasonLabel,
    weather,
    farmName,
    giftName: lastGiftName || relationship?.memory.favoriteGiftsRemembered[0] || (language === 'id' ? 'hadiah spesial' : 'gift'),
  });
}

export function pickNpcAmbientLine(
  categoryId: string,
  vars: { playerName?: string; npcName?: string; partnerName?: string; season?: string; weather?: string; farmName?: string },
  language: Language = 'en'
): string {
  const raw =
    pickFromCategory(categoryId, language) ||
    pickFromCategory('ambient_thought', language) ||
    (language === 'id' ? 'Hari yang begitu damai di Great Valley...' : 'What a lovely day in the valley...');
  return formatDialogueTemplate(raw, vars);
}
