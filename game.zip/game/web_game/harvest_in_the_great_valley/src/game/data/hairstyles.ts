import type { HairStyleId } from '../types';

export interface HairStyleDef {
  value: HairStyleId;
  gender: 'male' | 'female' | 'unisex';
  en: string;
  id: string;
  descEn: string;
  descId: string;
}

export interface HairColorDef {
  hex: string;
  nameEn: string;
  nameId: string;
  tag?: 'male' | 'female' | 'unisex';
}

export const HAIR_STYLES_CATALOG: HairStyleDef[] = [
  // Bare
  { value: 'none', gender: 'unisex', en: 'Bald / None', id: 'Botak / Polos', descEn: 'Clean bare head.', descId: 'Polos tanpa rambut.' },

  // === 18 MEN'S HAIRSTYLES ===
  { value: 'soft_mullet', gender: 'male', en: 'Soft Mullet / Modern Mullet', id: 'Soft Mullet / Modern Mullet', descEn: 'Shorter front & sides with soft tapered length at the back.', descId: 'Potongan modern lebih pendek di depan & samping, panjang lembut di belakang.' },
  { value: 'textured_crop', gender: 'male', en: 'Textured Crop / Messy Fringe', id: 'Textured Crop / Messy Fringe', descEn: 'Short cropped silhouette with natural messy forward texture.', descId: 'Gaya pendek bertekstur acak alami di bagian depan.' },
  { value: 'low_taper_fade', gender: 'male', en: 'Low Taper Fade', id: 'Low Taper Fade', descEn: 'Clean low gradient fade around ears & neckline, neat natural top.', descId: 'Gradasi tipis di sekitar telinga & leher, rapi dan alami.' },
  { value: 'bro_flow', gender: 'male', en: 'Bro Flow / Mid-Length Flow', id: 'Bro Flow / Mid-Length Flow', descEn: 'Effortless medium-length hair swept smoothly backwards.', descId: 'Rambut panjang sedang disisir alami ke belakang.' },
  { value: 'modern_pompadour', gender: 'male', en: 'Modern Pompadour', id: 'Modern Pompadour', descEn: 'Voluminous sculpted front swept up with neat tailored sides.', descId: 'Volume tinggi elegan di depan dengan sisi rapi.' },
  { value: 'buzz_cut', gender: 'male', en: 'Buzz Cut', id: 'Buzz Cut', descEn: 'Ultra-short uniform masculine cut, clean and practical.', descId: 'Potongan sangat pendek merata, simpel dan maskulin.' },
  { value: 'curly_undercut', gender: 'male', en: 'Curly Undercut', id: 'Curly Undercut', descEn: 'Natural bouncy curls on top contrasted by closely shaved sides.', descId: 'Rambut keriting bervolume di atas dengan sisi dicukur tipis.' },
  { value: 'mid_fade_slick_back', gender: 'male', en: 'Mid Fade Slick Back', id: 'Mid Fade Slick Back', descEn: 'Sharp mid-level fade paired with sleek combed-back crown.', descId: 'Sisi gradasi tengah dengan bagian atas disisir licin ke belakang.' },
  { value: 'burst_fade', gender: 'male', en: 'Burst Fade / Modern Burst', id: 'Burst Fade / Modern Burst', descEn: 'Semi-circular fade curving around the ear into a bold back ridge.', descId: 'Gradasi melingkar di sekitar telinga dengan volume belakang tegas.' },
  { value: 'french_crop_fade', gender: 'male', en: 'French Crop Fade', id: 'French Crop Fade', descEn: 'Crisp straight blunt fringe across forehead with high skin fade.', descId: 'Poni depan lurus rata pendek dipadukan sisi fade rapi.' },
  { value: 'messy_quiff', gender: 'male', en: 'Messy Quiff', id: 'Messy Quiff', descEn: 'Lifted textured front quiff with relaxed windswept volume.', descId: 'Jambul depan terangkat bertekstur santai dan stylish.' },
  { value: 'curtain_hair', gender: 'male', en: 'Curtain Hair / Middle Part', id: 'Curtain Hair / Belah Tengah', descEn: '90s-inspired center-parted bangs framing both sides of the face.', descId: 'Belah tengah klasik jatuh membingkai kedua sisi wajah.' },
  { value: 'wolf_cut', gender: 'male', en: 'Wolf Cut', id: 'Wolf Cut', descEn: 'Shaggy rock-inspired crown volume tapering into feathery ends.', descId: 'Layer shaggy bervolume di puncak kepala dengan ujung bertrap.' },
  { value: 'ivy_league', gender: 'male', en: 'Ivy League', id: 'Ivy League', descEn: 'Refined preppy short cut with slightly longer side-swept front.', descId: 'Potongan klasik rapi dengan bagian depan sedikit panjang disisir samping.' },
  { value: 'crew_cut_textured', gender: 'male', en: 'Crew Cut Textured', id: 'Crew Cut Textured', descEn: 'Classic military-inspired short top styled with choppy texture.', descId: 'Potongan pendek tegap dengan tekstur modern di bagian atas.' },
  { value: 'side_part_clean', gender: 'male', en: 'Side Part Clean', id: 'Side Part Clean', descEn: 'Crisp gentleman side-part with polished contours.', descId: 'Belah samping bersih dan profesional.' },
  { value: 'natural_afro', gender: 'male', en: 'Natural Afro', id: 'Natural Afro', descEn: 'Full rounded natural coiled volume celebrating rich texture.', descId: 'Volume keriting penuh membulat alami dan ikonik.' },
  { value: 'k_inspired', gender: 'male', en: 'K-Inspired Comma / Two-Block', id: 'K-Inspired Haircut', descEn: 'Soft Korean-style layered two-block with gentle comma bangs.', descId: 'Gaya Korea two-block lembut dengan poni koma modern.' },

  // === 17 WOMEN'S HAIRSTYLES ===
  { value: 'ultra_short_bob', gender: 'female', en: 'Ultra-Short Bob / Cheekbone Bob', id: 'Ultra-Short Bob / Cheekbone Bob', descEn: 'Chic ultra-short bob grazing the cheekbones for sharp modern elegance.', descId: 'Bob sangat pendek setinggi tulang pipi yang modern dan chic.' },
  { value: 'structured_bob', gender: 'female', en: 'Structured Bob / Jawline Bob', id: 'Structured Bob / Jawline Bob', descEn: 'Precision jaw-length bob with crisp geometric polish.', descId: 'Bob berstruktur rapi tepat di garis rahang.' },
  { value: 'french_bob', gender: 'female', en: 'French Bob', id: 'French Bob', descEn: 'Parisian chin-skimming bob paired with breezy wispy bangs.', descId: 'Bob pendek ala Paris dengan poni ringan menawan.' },
  { value: 'bixie', gender: 'female', en: 'Bixie (Bob + Pixie)', id: 'Bixie (Bob + Pixie)', descEn: 'Playful hybrid combining pixie lightness with bob softness.', descId: 'Perpaduan manis antara potongan pixie pendek dan kelembutan bob.' },
  { value: 'baby_bob', gender: 'female', en: 'Baby Bob', id: 'Baby Bob', descEn: 'Cute airy short bob with softly tucked ends.', descId: 'Bob mungil ringan dengan ujung melengkung manis.' },
  { value: 'floating_bob', gender: 'female', en: 'Floating Bob', id: 'Floating Bob', descEn: 'Weightless layered bob with subtle lift and bounce.', descId: 'Bob berlayer ringan yang tampak melayang alami.' },
  { value: 'butterfly_cut', gender: 'female', en: 'Butterfly Cut / Layered Long Hair', id: 'Butterfly Cut / Layered Long', descEn: 'Feathery short crown layers flowing into cascading long waves.', descId: 'Rambut panjang berlayer bak sayap kupu-kupu penuh dimensi.' },
  { value: 'birkin_layers', gender: 'female', en: 'Birkin Layers', id: 'Birkin Layers', descEn: 'Effortless bohemian long layers with signature wispy brow bangs.', descId: 'Layer panjang santai dengan poni tipis ala ikon klasik.' },
  { value: 'face_framing_layers', gender: 'female', en: 'Face-Framing Layers', id: 'Face-Framing Layers', descEn: 'Soft graduated front strands sculpting cheekbones and jawline.', descId: 'Layer bertingkat lembut membingkai kontur wajah.' },
  { value: 'rebel_layers', gender: 'female', en: 'Rebel Layers', id: 'Rebel Layers', descEn: 'Edgy razor-textured shag layers full of rock-chic movement.', descId: 'Layer acak berani dengan tekstur edgy dan dinamis.' },
  { value: 'supermodel_blowout', gender: 'female', en: '90s Supermodel Blowout', id: 'Supermodel Blowout 90-an', descEn: 'Glamorous voluminous salon blowout with bouncy curled ends.', descId: 'Blowout bervolume glamor ala supermodel 90-an.' },
  { value: 'sculptural_updo', gender: 'female', en: 'Sculptural Updo', id: 'Sculptural Updo', descEn: 'Artistic high twisted bun updo with sleek regal silhouette.', descId: 'Sanggul atas artistik berstruktur elegan dan anggun.' },
  { value: 'side_part_woman', gender: 'female', en: 'Side Part Glamour', id: 'Side Part (Belah Samping)', descEn: 'Deep glossy side part sweeping gracefully over one shoulder.', descId: 'Belah samping dalam jatuh anggun melewati bahu.' },
  { value: 'butterfly_fringe', gender: 'female', en: 'Butterfly Fringe / Wispy Curtain Bangs', id: 'Butterfly Fringe / Poni Tipis', descEn: 'Long flowing hair with airy parted curtain fringe.', descId: 'Rambut panjang dengan poni tirai tipis berayun lembut.' },
  { value: 'poni_tebal', gender: 'female', en: 'Thick Full Bangs (Poni Tebal)', id: 'Poni Tebal Penuh', descEn: 'Bold straight full bangs paired with smooth sleek length.', descId: 'Poni penuh tebal dan rata dipadukan rambut panjang halus.' },
  { value: 'wet_look_90s', gender: 'female', en: '90s Wet Look Waves', id: 'Wet Look Waves 90-an', descEn: 'Sleek high-shine swept waves straight off the 90s runway.', descId: 'Gelombang rambut berkilau rapi bergaya 90-an.' },
  { value: 'emo_fringe', gender: 'female', en: 'Emo / Side-Swept Fringe', id: 'Emo Fringe / Poni Menyamping', descEn: 'Dramatic long side-swept fringe with tapered choppy ends.', descId: 'Poni panjang menyamping dramatis dengan ujung runcing.' },

  // Classic Farm Styles
  { value: 'short', gender: 'unisex', en: 'Classic Short', id: 'Pendek Klasik', descEn: 'Simple everyday farm cut.', descId: 'Potongan pendek sederhana sehari-hari.' },
  { value: 'ponytail', gender: 'unisex', en: 'High Ponytail', id: 'Kuncir Kuda', descEn: 'Tied back high for breezy farm work.', descId: 'Dikuncir ke belakang agar praktis bekerja di kebun.' },
  { value: 'spiky', gender: 'male', en: 'Spiky', id: 'Runcing (Spiky)', descEn: 'Energetic upturned spikes.', descId: 'Rambut runcing penuh energi.' },
  { value: 'bob', gender: 'female', en: 'Classic Bob', id: 'Bob Klasik', descEn: 'Timeless neat bob cut.', descId: 'Potongan bob klasik yang selalu rapi.' },
  { value: 'long', gender: 'female', en: 'Long Straight', id: 'Panjang Lurus', descEn: 'Flowing straight hair past the shoulders.', descId: 'Rambut panjang lurus melebihi bahu.' },
  { value: 'buns', gender: 'female', en: 'Twin Buns', id: 'Sanggul Kembar', descEn: 'Playful twin buns on each side.', descId: 'Dua sanggul manis di kiri dan kanan.' },
  { value: 'curly', gender: 'unisex', en: 'Soft Curly', id: 'Keriting Lembut', descEn: 'Lively curls full of charm.', descId: 'Rambut keriting lembut dan ceria.' },
  { value: 'braids', gender: 'female', en: 'Twin Braids', id: 'Kepang Dua', descEn: 'Country-style twin braided pigtails.', descId: 'Kepang dua khas gadis pedesaan.' },
  { value: 'mohawk', gender: 'male', en: 'Mohawk', id: 'Mohawk', descEn: 'Bold central ridge crest.', descId: 'Jambul tengah yang tegas dan unik.' },
  { value: 'undercut', gender: 'male', en: 'Classic Undercut', id: 'Undercut Klasik', descEn: 'Short sides with swept top.', descId: 'Sisi tipis dengan bagian atas rapi.' },
  { value: 'wavy', gender: 'female', en: 'Wavy Long', id: 'Bergelombang Panjang', descEn: 'Soft natural waves flowing down the back.', descId: 'Rambut panjang bergelombang lembut.' },
  { value: 'afro', gender: 'unisex', en: 'Classic Afro', id: 'Afro Klasik', descEn: 'Full bouncy afro silhouette.', descId: 'Siluet afro klasik bervolume.' },
];

export const HAIR_COLORS_CATALOG: HairColorDef[] = [
  // Requested Trend Hair Colors (Men's + Women's)
  { hex: '#9c4a2b', nameEn: 'Cowboy Copper', nameId: 'Cowboy Copper (Tembaga Hangat)', tag: 'unisex' },
  { hex: '#b8976c', nameEn: 'Bronde', nameId: 'Bronde (Cokelat Pirang)', tag: 'female' },
  { hex: '#5a3420', nameEn: 'Warm Brunette (Candlelit)', nameId: 'Warm Brunette / Candlelit Brunette', tag: 'female' },
  { hex: '#b84a24', nameEn: 'Spiced Copper', nameId: 'Spiced Copper (Tembaga Rempah)', tag: 'female' },
  { hex: '#e6e4ee', nameEn: 'Ethereal Platinum Blonde', nameId: 'Ethereal Platinum Blonde', tag: 'female' },
  { hex: '#8c6239', nameEn: 'Golden Brunette Balayage', nameId: 'Golden Brunette Balayage', tag: 'female' },
  // Classic Palette
  { hex: '#1c1917', nameEn: 'Jet Black', nameId: 'Hitam Pekat', tag: 'unisex' },
  { hex: '#451a03', nameEn: 'Dark Espresso', nameId: 'Cokelat Espresso', tag: 'unisex' },
  { hex: '#6b3e1b', nameEn: 'Chestnut Brown', nameId: 'Cokelat Kastanye', tag: 'unisex' },
  { hex: '#d97706', nameEn: 'Honey Amber', nameId: 'Kuning Madu', tag: 'unisex' },
  { hex: '#eab308', nameEn: 'Sunlit Blonde', nameId: 'Pirang Cerah', tag: 'unisex' },
  { hex: '#b91c1c', nameEn: 'Crimson Auburn', nameId: 'Merah Marun', tag: 'unisex' },
  { hex: '#db2777', nameEn: 'Sakura Rose', nameId: 'Merah Muda Sakura', tag: 'female' },
  { hex: '#4f46e5', nameEn: 'Indigo Twilight', nameId: 'Biru Indigo', tag: 'unisex' },
  { hex: '#cbd5e1', nameEn: 'Silver Frost', nameId: 'Perak Salju', tag: 'unisex' },
];

export const ALL_VALID_HAIRSTYLE_IDS: HairStyleId[] = HAIR_STYLES_CATALOG.map((h) => h.value);
