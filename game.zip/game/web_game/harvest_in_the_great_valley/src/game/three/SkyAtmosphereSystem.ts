import * as THREE from 'three';
import type { Season, SkyAtmosphereConfig, TimeOfDayPhase, Weather } from '../types';
import { getTimeOfDayPhase } from '../localizationManager';

export interface SkyLightingOutput {
  phase: TimeOfDayPhase;
  skyTopColor: THREE.Color;
  skyHorizonColor: THREE.Color;
  fogColor: THREE.Color;
  fogNear: number;
  fogFar: number;
  sunIntensity: number;
  sunColor: THREE.Color;
  hemiIntensity: number;
  hemiSkyColor: THREE.Color;
  hemiGroundColor: THREE.Color;
  ambientIntensity: number;
  ambientColor: THREE.Color;
  sunPosition: THREE.Vector3;
  isNight: boolean;
}

interface CloudCluster {
  group: THREE.Group;
  speed: number;
  baseX: number;
  baseY: number;
  baseZ: number;
  baseScale: number;
  seed: number;
  layerIndex: number;
}

const SKY_PALETTES: Record<
  TimeOfDayPhase,
  {
    top: string;
    horizon: string;
    sun: string;
    hemiSky: string;
    hemiGround: string;
    ambient: string;
    sunInt: number;
    hemiInt: number;
    ambInt: number;
  }
> = {
  dawn: {
    top: '#2e3c6e',
    horizon: '#f9a88c',
    sun: '#ffb98a',
    hemiSky: '#fbcfe8',
    hemiGround: '#5c5346',
    ambient: '#f4c7ab',
    sunInt: 0.72,
    hemiInt: 0.56,
    ambInt: 0.34,
  },
  morning: {
    top: '#4f9be8',
    horizon: '#d8f1ff',
    sun: '#fff4d6',
    hemiSky: '#bae6fd',
    hemiGround: '#7a8a5e',
    ambient: '#fff7e6',
    sunInt: 1.24,
    hemiInt: 0.78,
    ambInt: 0.4,
  },
  noon: {
    top: '#2b7de0',
    horizon: '#b8e3ff',
    sun: '#ffffff',
    hemiSky: '#e0f2fe',
    hemiGround: '#7c8f58',
    ambient: '#ffffff',
    sunInt: 1.42,
    hemiInt: 0.84,
    ambInt: 0.44,
  },
  afternoon: {
    top: '#4d8ad6',
    horizon: '#fce0b6',
    sun: '#ffe3b3',
    hemiSky: '#fde68a',
    hemiGround: '#786e4d',
    ambient: '#fff1d6',
    sunInt: 1.22,
    hemiInt: 0.74,
    ambInt: 0.4,
  },
  dusk: {
    top: '#2b2d5c',
    horizon: '#ee7b54',
    sun: '#ff8a5b',
    hemiSky: '#fda4af',
    hemiGround: '#4a3d3b',
    ambient: '#e2a38b',
    sunInt: 0.62,
    hemiInt: 0.48,
    ambInt: 0.3,
  },
  night: {
    top: '#090f24',
    horizon: '#1a2748',
    sun: '#93c5fd',
    hemiSky: '#3b4e7a',
    hemiGround: '#1a2234',
    ambient: '#526799',
    sunInt: 0.34,
    hemiInt: 0.36,
    ambInt: 0.28,
  },
};

const PHASE_ANCHOR_HOURS: Array<{ hour: number; phase: TimeOfDayPhase }> = [
  { hour: 0, phase: 'night' },
  { hour: 4.5, phase: 'night' },
  { hour: 5.5, phase: 'dawn' },
  { hour: 7.5, phase: 'morning' },
  { hour: 12.0, phase: 'noon' },
  { hour: 15.5, phase: 'afternoon' },
  { hour: 18.2, phase: 'dusk' },
  { hour: 20.0, phase: 'night' },
  { hour: 24.0, phase: 'night' },
];

export class SkyAtmosphereSystem {
  public readonly root = new THREE.Group();

  private skyDomeMesh: THREE.Mesh;
  private skyUniforms: {
    uTopColor: { value: THREE.Color };
    uHorizonColor: { value: THREE.Color };
    uBottomColor: { value: THREE.Color };
  };

  private sunGroup = new THREE.Group();
  private sunDisc: THREE.Mesh;
  private sunHalo: THREE.Mesh;

  private moonGroup = new THREE.Group();
  private moonMesh: THREE.Mesh;
  private moonHalo: THREE.Mesh;
  private moonCanvas: HTMLCanvasElement;
  private moonTexture: THREE.CanvasTexture;
  private lastMoonPhaseBucket = -1;

  private starField: THREE.Points;
  private starMat: THREE.PointsMaterial;
  private starBaseColors: Float32Array;
  private starSeeds: Float32Array;
  private starCount = 420;

  private cloudsGroup = new THREE.Group();
  private clouds: CloudCluster[] = [];
  private cloudMat: THREE.MeshStandardMaterial;

  private config: SkyAtmosphereConfig = {
    cloudDensity: 0.55,
    cloudSpeed: 1.0,
    starTwinkleIntensity: 0.85,
    moonPhaseOverride: null,
  };

  // Reusable colors to avoid per-frame allocations
  private readonly tmpTop = new THREE.Color();
  private readonly tmpHorizon = new THREE.Color();
  private readonly tmpFog = new THREE.Color();
  private readonly tmpSun = new THREE.Color();
  private readonly tmpHemiSky = new THREE.Color();
  private readonly tmpHemiGround = new THREE.Color();
  private readonly tmpAmb = new THREE.Color();
  private readonly tmpNext = new THREE.Color();
  private readonly tmpStormTint = new THREE.Color('#273449');
  private readonly tmpRainTint = new THREE.Color('#4b6078');
  private readonly tmpFogTint = new THREE.Color('#cbd5e1');
  private readonly tmpSnowTint = new THREE.Color('#dce8f5');
  private readonly tmpCloudTint = new THREE.Color('#ffffff');

  constructor() {
    this.root.name = 'SkyAtmosphereSystem';

    // 1. Procedural Sky Gradient Dome
    this.skyUniforms = {
      uTopColor: { value: new THREE.Color('#4f9be8') },
      uHorizonColor: { value: new THREE.Color('#d8f1ff') },
      uBottomColor: { value: new THREE.Color('#9ec5d8') },
    };

    const skyGeo = new THREE.SphereGeometry(260, 28, 18);
    const skyMat = new THREE.ShaderMaterial({
      uniforms: this.skyUniforms,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      vertexShader: `
        varying vec3 vWorldDir;
        void main() {
          vec4 worldPosition = modelMatrix * vec4(position, 1.0);
          vWorldDir = normalize(position);
          gl_Position = projectionMatrix * viewMatrix * worldPosition;
        }
      `,
      fragmentShader: `
        uniform vec3 uTopColor;
        uniform vec3 uHorizonColor;
        uniform vec3 uBottomColor;
        varying vec3 vWorldDir;
        void main() {
          float h = clamp(vWorldDir.y, -1.0, 1.0);
          vec3 col;
          if (h >= 0.0) {
            float t = pow(h, 0.58);
            col = mix(uHorizonColor, uTopColor, t);
          } else {
            float t = clamp(-h * 3.0, 0.0, 1.0);
            col = mix(uHorizonColor, uBottomColor, t);
          }
          gl_FragColor = vec4(col, 1.0);
        }
      `,
    });
    this.skyDomeMesh = new THREE.Mesh(skyGeo, skyMat);
    this.skyDomeMesh.renderOrder = -20;
    this.root.add(this.skyDomeMesh);

    // 2. Twinkling Starfield
    const starPositions = new Float32Array(this.starCount * 3);
    const starColors = new Float32Array(this.starCount * 3);
    this.starBaseColors = new Float32Array(this.starCount * 3);
    this.starSeeds = new Float32Array(this.starCount);

    for (let i = 0; i < this.starCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(0.14 + Math.random() * 0.86); // Upper hemisphere above horizon
      const r = 215 + Math.random() * 18;
      starPositions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      starPositions[i * 3 + 1] = r * Math.cos(phi);
      starPositions[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);

      // Subtle warm/cool star tints
      const tint = Math.random();
      const cr = tint < 0.25 ? 1.0 : tint < 0.7 ? 0.92 : 0.78;
      const cg = tint < 0.25 ? 0.92 : tint < 0.7 ? 0.95 : 0.88;
      const cb = tint < 0.25 ? 0.75 : 1.0;

      this.starBaseColors[i * 3] = cr;
      this.starBaseColors[i * 3 + 1] = cg;
      this.starBaseColors[i * 3 + 2] = cb;
      starColors[i * 3] = cr;
      starColors[i * 3 + 1] = cg;
      starColors[i * 3 + 2] = cb;

      this.starSeeds[i] = Math.random() * Math.PI * 2;
    }

    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    starGeo.setAttribute('color', new THREE.BufferAttribute(starColors, 3));
    this.starMat = new THREE.PointsMaterial({
      size: 2.3,
      sizeAttenuation: true,
      vertexColors: true,
      transparent: true,
      opacity: 0,
      depthWrite: false,
      fog: false,
    });
    this.starField = new THREE.Points(starGeo, this.starMat);
    this.starField.renderOrder = -15;
    this.root.add(this.starField);

    // 3. Sun Disc + Soft Halo
    const sunGeo = new THREE.SphereGeometry(7.2, 16, 12);
    const sunMat = new THREE.MeshBasicMaterial({ color: '#fff7d1', fog: false });
    this.sunDisc = new THREE.Mesh(sunGeo, sunMat);
    const haloGeo = new THREE.SphereGeometry(12.2, 16, 12);
    const haloMat = new THREE.MeshBasicMaterial({
      color: '#fde68a',
      transparent: true,
      opacity: 0.24,
      depthWrite: false,
      fog: false,
    });
    this.sunHalo = new THREE.Mesh(haloGeo, haloMat);
    this.sunGroup.add(this.sunDisc, this.sunHalo);
    this.root.add(this.sunGroup);

    // 4. Dynamic Moon with Lunar Phase Canvas Texture
    this.moonCanvas = document.createElement('canvas');
    this.moonCanvas.width = 128;
    this.moonCanvas.height = 128;
    this.moonTexture = new THREE.CanvasTexture(this.moonCanvas);
    this.moonTexture.colorSpace = THREE.SRGBColorSpace;
    this.redrawMoonTexture(0.5);

    const moonPlaneMat = new THREE.MeshBasicMaterial({
      map: this.moonTexture,
      transparent: true,
      depthWrite: false,
      fog: false,
      side: THREE.DoubleSide,
    });
    this.moonMesh = new THREE.Mesh(new THREE.PlaneGeometry(15.5, 15.5), moonPlaneMat);
    const moonHaloMat = new THREE.MeshBasicMaterial({
      color: '#cbd5e1',
      transparent: true,
      opacity: 0.14,
      depthWrite: false,
      fog: false,
    });
    this.moonHalo = new THREE.Mesh(new THREE.SphereGeometry(10.2, 14, 10), moonHaloMat);
    this.moonGroup.add(this.moonHalo, this.moonMesh);
    this.root.add(this.moonGroup);

    // 5. Drifting 3D Fluffy Cloud Clusters
    this.cloudMat = new THREE.MeshStandardMaterial({
      color: '#ffffff',
      roughness: 0.96,
      metalness: 0.0,
      transparent: true,
      opacity: 0.88,
      depthWrite: false,
      fog: false,
    });
    this.buildClouds();
    this.root.add(this.cloudsGroup);
  }

  private buildClouds() {
    const puffGeo = new THREE.IcosahedronGeometry(1, 1);
    const totalClouds = 28;
    for (let i = 0; i < totalClouds; i++) {
      const group = new THREE.Group();
      const puffCount = 4 + (i % 4);
      for (let p = 0; p < puffCount; p++) {
        const puff = new THREE.Mesh(puffGeo, this.cloudMat);
        const angle = (p / puffCount) * Math.PI * 2;
        const spreadX = (p - (puffCount - 1) / 2) * 2.15 + Math.cos(angle) * 0.6;
        const spreadY = Math.sin(p * 1.4) * 0.55 + (p === 1 || p === 2 ? 0.6 : 0);
        const spreadZ = Math.sin(angle) * 1.1;
        const radius = 1.6 + (p === 1 || p === 2 ? 0.9 : 0.35);
        puff.position.set(spreadX, spreadY, spreadZ);
        puff.scale.set(radius * 1.25, radius * 0.72, radius * 0.95);
        group.add(puff);
      }
      const baseX = -155 + Math.random() * 310;
      const baseY = 38 + (i % 5) * 4.8 + Math.random() * 6;
      const baseZ = -145 + Math.random() * 290;
      const baseScale = 1.15 + Math.random() * 1.35;
      group.position.set(baseX, baseY, baseZ);
      group.scale.setScalar(baseScale);
      this.cloudsGroup.add(group);
      this.clouds.push({
        group,
        speed: 1.4 + Math.random() * 2.2,
        baseX,
        baseY,
        baseZ,
        baseScale,
        seed: Math.random() * Math.PI * 2,
        layerIndex: i,
      });
    }
  }

  private redrawMoonTexture(phase01: number) {
    // phase01: 0 = New Moon, 0.25 = First Quarter, 0.5 = Full Moon, 0.75 = Last Quarter
    const bucket = Math.round(((phase01 % 1) + 1) % 1 * 24);
    if (bucket === this.lastMoonPhaseBucket) return;
    this.lastMoonPhaseBucket = bucket;

    const ctx = this.moonCanvas.getContext('2d');
    if (!ctx) return;
    const w = this.moonCanvas.width;
    const h = this.moonCanvas.height;
    const cx = w / 2;
    const cy = h / 2;
    const r = 50;

    ctx.clearRect(0, 0, w, h);

    // Subtle dark lunar disk base
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.clip();

    ctx.fillStyle = 'rgba(20, 30, 56, 0.52)';
    ctx.fillRect(0, 0, w, h);

    // Draw illuminated portion based on lunar phase
    const p = ((phase01 % 1) + 1) % 1;
    const illumGrad = ctx.createRadialGradient(cx - 10, cy - 10, 6, cx, cy, r);
    illumGrad.addColorStop(0, '#fffbeb');
    illumGrad.addColorStop(0.75, '#f1f5f9');
    illumGrad.addColorStop(1, '#cbd5e1');

    ctx.fillStyle = illumGrad;
    ctx.beginPath();
    if (p < 0.5) {
      // Waxing: right half illuminated, inner terminator ellipse shifts from +r to -r
      const k = Math.cos(p * Math.PI * 2); // +1 at new, 0 at first quarter, -1 at full
      ctx.arc(cx, cy, r, -Math.PI / 2, Math.PI / 2, false);
      ctx.ellipse(cx, cy, Math.abs(k) * r, r, 0, Math.PI / 2, -Math.PI / 2, k > 0);
    } else {
      // Waning: left half illuminated
      const k = Math.cos((p - 0.5) * Math.PI * 2); // +1 at full, 0 at last quarter, -1 at new
      ctx.arc(cx, cy, r, Math.PI / 2, -Math.PI / 2, false);
      ctx.ellipse(cx, cy, Math.abs(k) * r, r, 0, -Math.PI / 2, Math.PI / 2, k < 0);
    }
    ctx.closePath();
    ctx.fill();

    // Subtle lunar craters
    ctx.fillStyle = 'rgba(100, 116, 139, 0.18)';
    [
      [cx - 16, cy - 12, 10],
      [cx + 14, cy + 8, 12],
      [cx - 6, cy + 20, 7],
      [cx + 18, cy - 16, 6],
      [cx - 22, cy + 8, 5],
    ].forEach(([x, y, rad]) => {
      ctx.beginPath();
      ctx.arc(x, y, rad, 0, Math.PI * 2);
      ctx.fill();
    });

    ctx.restore();
    this.moonTexture.needsUpdate = true;
  }

  public setConfig(partial?: Partial<SkyAtmosphereConfig> | null) {
    if (!partial) return;
    this.config = {
      cloudDensity: typeof partial.cloudDensity === 'number' ? THREE.MathUtils.clamp(partial.cloudDensity, 0, 1) : this.config.cloudDensity,
      cloudSpeed: typeof partial.cloudSpeed === 'number' ? THREE.MathUtils.clamp(partial.cloudSpeed, 0.2, 3) : this.config.cloudSpeed,
      starTwinkleIntensity:
        typeof partial.starTwinkleIntensity === 'number'
          ? THREE.MathUtils.clamp(partial.starTwinkleIntensity, 0, 1)
          : this.config.starTwinkleIntensity,
      moonPhaseOverride:
        partial.moonPhaseOverride === null || typeof partial.moonPhaseOverride === 'number'
          ? partial.moonPhaseOverride
          : this.config.moonPhaseOverride,
    };
  }

  public update(params: {
    hourFloat: number;
    day: number;
    season: Season;
    weather: Weather;
    isIndoor: boolean;
    elapsedSec: number;
    dt: number;
    anchorPos: THREE.Vector3;
    camera: THREE.Camera;
  }): SkyLightingOutput {
    const { hourFloat, day, season, weather, isIndoor, elapsedSec, dt, anchorPos, camera } = params;
    const h = ((hourFloat % 24) + 24) % 24;
    const phase = getTimeOfDayPhase(h);

    this.root.visible = !isIndoor;
    // Keep sky dome centered on camera/player so horizon never clips
    this.root.position.set(anchorPos.x, 0, anchorPos.z);

    // Smoothly interpolate between phase anchor palettes
    let prevAnchor = PHASE_ANCHOR_HOURS[0];
    let nextAnchor = PHASE_ANCHOR_HOURS[PHASE_ANCHOR_HOURS.length - 1];
    for (let i = 0; i < PHASE_ANCHOR_HOURS.length - 1; i++) {
      if (h >= PHASE_ANCHOR_HOURS[i].hour && h <= PHASE_ANCHOR_HOURS[i + 1].hour) {
        prevAnchor = PHASE_ANCHOR_HOURS[i];
        nextAnchor = PHASE_ANCHOR_HOURS[i + 1];
        break;
      }
    }
    const span = Math.max(0.01, nextAnchor.hour - prevAnchor.hour);
    const alpha = THREE.MathUtils.smoothstep((h - prevAnchor.hour) / span, 0, 1);
    const pA = SKY_PALETTES[prevAnchor.phase];
    const pB = SKY_PALETTES[nextAnchor.phase];

    this.tmpTop.set(pA.top).lerp(this.tmpNext.set(pB.top), alpha);
    this.tmpHorizon.set(pA.horizon).lerp(this.tmpNext.set(pB.horizon), alpha);
    this.tmpSun.set(pA.sun).lerp(this.tmpNext.set(pB.sun), alpha);
    this.tmpHemiSky.set(pA.hemiSky).lerp(this.tmpNext.set(pB.hemiSky), alpha);
    this.tmpHemiGround.set(pA.hemiGround).lerp(this.tmpNext.set(pB.hemiGround), alpha);
    this.tmpAmb.set(pA.ambient).lerp(this.tmpNext.set(pB.ambient), alpha);

    let sunInt = THREE.MathUtils.lerp(pA.sunInt, pB.sunInt, alpha);
    let hemiInt = THREE.MathUtils.lerp(pA.hemiInt, pB.hemiInt, alpha);
    let ambInt = THREE.MathUtils.lerp(pA.ambInt, pB.ambInt, alpha);

    // Seasonal subtle warmth/coolness tint
    if (season === 'Autumn') {
      this.tmpHorizon.lerp(this.tmpNext.set('#f5c99b'), 0.14);
    } else if (season === 'Winter') {
      this.tmpHorizon.lerp(this.tmpNext.set('#dce9f5'), 0.18);
    }

    // Weather atmosphere modifiers
    let fogNear = 42;
    let fogFar = 148;
    let cloudDensityBoost = 0;
    let cloudSpeedBoost = 1.0;
    let cloudDarkness = 0.0;
    let starWeatherVis = 1.0;

    if (weather === 'Cloudy') {
      this.tmpTop.lerp(this.tmpRainTint, 0.32);
      this.tmpHorizon.lerp(this.tmpFogTint, 0.35);
      sunInt *= 0.78;
      hemiInt *= 0.9;
      fogNear = 36;
      fogFar = 128;
      cloudDensityBoost = 0.28;
      cloudDarkness = 0.15;
      starWeatherVis = 0.38;
    } else if (weather === 'LightRain') {
      this.tmpTop.lerp(this.tmpRainTint, 0.5);
      this.tmpHorizon.lerp(this.tmpRainTint, 0.42);
      sunInt *= 0.62;
      hemiInt *= 0.82;
      fogNear = 28;
      fogFar = 104;
      cloudDensityBoost = 0.38;
      cloudSpeedBoost = 1.35;
      cloudDarkness = 0.34;
      starWeatherVis = 0.15;
    } else if (weather === 'Rainy' || weather === 'HeavyRain') {
      this.tmpTop.lerp(this.tmpRainTint, 0.66);
      this.tmpHorizon.lerp(this.tmpStormTint, 0.45);
      sunInt *= weather === 'HeavyRain' ? 0.45 : 0.54;
      hemiInt *= 0.72;
      fogNear = weather === 'HeavyRain' ? 20 : 25;
      fogFar = weather === 'HeavyRain' ? 82 : 95;
      cloudDensityBoost = 0.48;
      cloudSpeedBoost = weather === 'HeavyRain' ? 1.8 : 1.5;
      cloudDarkness = weather === 'HeavyRain' ? 0.5 : 0.42;
      starWeatherVis = 0.05;
    } else if (weather === 'Stormy') {
      this.tmpTop.lerp(this.tmpStormTint, 0.8);
      this.tmpHorizon.lerp(this.tmpStormTint, 0.68);
      sunInt *= 0.34;
      hemiInt *= 0.62;
      fogNear = 16;
      fogFar = 72;
      cloudDensityBoost = 0.55;
      cloudSpeedBoost = 2.4;
      cloudDarkness = 0.62;
      starWeatherVis = 0.0;
    } else if (weather === 'Foggy') {
      this.tmpTop.lerp(this.tmpFogTint, 0.52);
      this.tmpHorizon.lerp(this.tmpFogTint, 0.74);
      sunInt *= 0.66;
      hemiInt *= 0.88;
      fogNear = 11;
      fogFar = 54;
      cloudDensityBoost = 0.35;
      cloudSpeedBoost = 0.65;
      cloudDarkness = 0.12;
      starWeatherVis = 0.12;
    } else if (weather === 'Snowy') {
      this.tmpTop.lerp(this.tmpSnowTint, 0.45);
      this.tmpHorizon.lerp(this.tmpSnowTint, 0.55);
      sunInt *= 0.74;
      hemiInt *= 0.92;
      fogNear = 24;
      fogFar = 92;
      cloudDensityBoost = 0.36;
      cloudSpeedBoost = 1.1;
      cloudDarkness = 0.1;
      starWeatherVis = 0.22;
    }

    // Update sky shader uniforms
    this.skyUniforms.uTopColor.value.copy(this.tmpTop);
    this.skyUniforms.uHorizonColor.value.copy(this.tmpHorizon);
    this.skyUniforms.uBottomColor.value.copy(this.tmpHorizon).multiplyScalar(0.76);

    // Sun & Moon orbital positions
    const dayAngle = ((h - 6) / 24) * Math.PI * 2; // 0 at 06:00, PI/2 at 12:00, PI at 18:00
    const sunOrbitR = 175;
    const sunX = Math.cos(dayAngle) * sunOrbitR;
    const sunY = Math.sin(dayAngle) * sunOrbitR;
    const sunZ = -62;

    this.sunGroup.position.set(sunX, sunY, sunZ);
    this.sunGroup.visible = sunY > -14 && weather !== 'Stormy' && weather !== 'HeavyRain';
    (this.sunDisc.material as THREE.MeshBasicMaterial).color.copy(this.tmpSun);
    (this.sunHalo.material as THREE.MeshBasicMaterial).color.copy(this.tmpHorizon);

    // Moon orbits opposite the sun with slight seasonal inclination
    const moonAngle = dayAngle + Math.PI;
    const moonX = Math.cos(moonAngle) * sunOrbitR;
    const moonY = Math.sin(moonAngle) * sunOrbitR;
    const moonZ = 48;
    this.moonGroup.position.set(moonX, moonY, moonZ);
    this.moonGroup.visible = moonY > -12 && weather !== 'Stormy';
    this.moonMesh.lookAt(camera.position);

    const autoLunarPhase = ((day - 1) % 30) / 30;
    const activeMoonPhase =
      this.config.moonPhaseOverride !== null ? this.config.moonPhaseOverride : autoLunarPhase;
    this.redrawMoonTexture(activeMoonPhase);

    // Night factor for twinkling stars (visible from 18:30 to 05:45)
    let nightFactor = 0;
    if (h >= 19.5 || h <= 4.75) {
      nightFactor = 1;
    } else if (h > 17.75 && h < 19.5) {
      nightFactor = (h - 17.75) / 1.75;
    } else if (h > 4.75 && h < 6.25) {
      nightFactor = 1 - (h - 4.75) / 1.5;
    }
    const starOpacity = nightFactor * starWeatherVis;
    this.starMat.opacity = starOpacity;
    this.starField.visible = starOpacity > 0.02;
    if (this.starField.visible) {
      this.starField.rotation.y = elapsedSec * 0.0025;
      const colorAttr = this.starField.geometry.getAttribute('color') as THREE.BufferAttribute;
      const twinkleAmp = 0.25 + this.config.starTwinkleIntensity * 0.55;
      for (let i = 0; i < this.starCount; i++) {
        const wave = 0.5 + 0.5 * Math.sin(elapsedSec * (1.8 + (i % 7) * 0.45) + this.starSeeds[i]);
        const brightness = 1 - twinkleAmp + wave * twinkleAmp;
        colorAttr.setXYZ(
          i,
          this.starBaseColors[i * 3] * brightness,
          this.starBaseColors[i * 3 + 1] * brightness,
          this.starBaseColors[i * 3 + 2] * brightness
        );
      }
      colorAttr.needsUpdate = true;
    }

    // Moving clouds with dynamic density & time-of-day tint
    const effectiveDensity = THREE.MathUtils.clamp(this.config.cloudDensity + cloudDensityBoost, 0.08, 1.0);
    const activeCloudCount = Math.max(2, Math.round(effectiveDensity * this.clouds.length));
    const speedMul = this.config.cloudSpeed * cloudSpeedBoost;

    // Cloud color follows sky horizon (warm gold at dawn/dusk, cool slate at night, dark grey in storm)
    this.tmpCloudTint.set('#ffffff').lerp(this.tmpHorizon, 0.32);
    if (nightFactor > 0.3) {
      this.tmpCloudTint.lerp(this.tmpNext.set('#334155'), nightFactor * 0.72);
    }
    if (cloudDarkness > 0) {
      this.tmpCloudTint.lerp(this.tmpStormTint, cloudDarkness);
    }
    this.cloudMat.color.copy(this.tmpCloudTint);
    this.cloudMat.opacity = THREE.MathUtils.clamp(0.62 + effectiveDensity * 0.34, 0.45, 0.95);

    for (let i = 0; i < this.clouds.length; i++) {
      const c = this.clouds[i];
      const show = i < activeCloudCount;
      c.group.visible = show;
      if (!show) continue;
      c.baseX += c.speed * speedMul * dt;
      if (c.baseX > 160) c.baseX = -160;
      c.group.position.set(
        c.baseX,
        c.baseY + Math.sin(elapsedSec * 0.25 + c.seed) * 0.85,
        c.baseZ
      );
      const scaleFactor = c.baseScale * (0.82 + effectiveDensity * 0.45);
      c.group.scale.setScalar(scaleFactor);
    }

    // Compute directional light vector (follows Sun by day, Moon by night)
    const isNight = nightFactor > 0.6;
    const lightPos = new THREE.Vector3(
      isNight ? moonX * 0.28 : sunX * 0.28,
      Math.max(18, isNight ? moonY * 0.35 : sunY * 0.35),
      isNight ? moonZ * 0.32 : 24
    );

    this.tmpFog.copy(this.tmpHorizon);

    return {
      phase,
      skyTopColor: this.tmpTop,
      skyHorizonColor: this.tmpHorizon,
      fogColor: this.tmpFog,
      fogNear,
      fogFar,
      sunIntensity: sunInt,
      sunColor: this.tmpSun,
      hemiIntensity: hemiInt,
      hemiSkyColor: this.tmpHemiSky,
      hemiGroundColor: this.tmpHemiGround,
      ambientIntensity: ambInt,
      ambientColor: this.tmpAmb,
      sunPosition: lightPos,
      isNight,
    };
  }
}
