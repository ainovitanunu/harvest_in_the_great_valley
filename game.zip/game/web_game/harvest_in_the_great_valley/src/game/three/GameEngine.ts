import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { soundEngine } from '../audio/SoundEngine';
import { CAMERA_CONFIG, PERFORMANCE_CONFIG } from '../data/gameRuntimeConfig';
import { CROPS, DEFAULT_KEYBINDINGS } from '../data/itemsAndCrops';
import { NPCS, getNpcRoutineSlot } from '../data/npcs';
import { getNpcProfessionRole, pickNpcAmbientLine } from '../data/npcDialogueDb';
import {
  APPLE_TREE_POS,
  BUILDING_PORTALS,
  CHARACTER_ANIM_CONFIG,
  DOGHOUSE_POS,
  DOG_FOOD_BOWL_POS,
  FARM_GRID_COLS,
  FARM_GRID_ROWS,
  FARM_ORIGIN_X,
  FARM_ORIGIN_Z,
  FARM_TILE_STEP,
  FARMHOUSE_OUTDOOR_SPAWN,
  FESTIVALS,
  HORSE_STABLE_POS,
} from '../data/worldConfig';
import type {
  AnimalState,
  AvatarConfig,
  CameraConfig,
  CameraPovMode,
  EggIncubatorSlot,
  FarmPlotState,
  GraphicsSettings,
  KeyBindings,
  Language,
  NpcEmotion,
  NpcIdlePose,
  NpcProfessionRole,
  NPCRoutineSlot,
  OnlinePlayerState,
  PerformanceConfig,
  Season,
  SkyAtmosphereConfig,
  ToolKind,
  Weather,
  WorldTreeRecord,
  WorldZoneId,
} from '../types';
import { localizeNpcGreetingBubble } from '../localizationManager';
import { SkyAtmosphereSystem } from './SkyAtmosphereSystem';
import {
  LivingAnimalActor,
  createLivingAnimalRig,
  getAnimalRadius,
  updateLivingAnimals,
} from './AnimalSystem';
import {
  ChibiRig,
  LocomotionInput,
  animateChibiRig,
  computeFishingRodTipLocal,
  createCanvasTexture,
  createChibiCharacter,
  createCropMesh,
  createFarmObstacleMesh,
  createHeldItemMesh,
  createToolMesh,
  updateTreeLodDistances,
} from './AssetFactory';
import { glbAssets } from './GLBAssetManager';
import {
  InteractiveWorldNode,
  OutdoorWorldRefs,
  TOWN_SQUARE_BENCHES,
  WorldColliders,
  applySeasonToWorld,
  buildInteriorScene,
  buildOutdoorWorld,
  createCaveDescentHoleMesh,
  rebuildFarmTrees,
  setAppleTreeVisuals,
  syncGlobalTrees,
} from './WorldBuilder';

const _camTarget = new THREE.Vector3();
const _camPos = new THREE.Vector3();
const _projVec = new THREE.Vector3();
const _frustum = new THREE.Frustum();
const _projScreenMat = new THREE.Matrix4();
const _raycaster = new THREE.Raycaster();
const _pointerNdc = new THREE.Vector2();

export interface FloatingTag {
  id: string;
  label: string;
  sublabel?: string;
  x: number;
  y: number;
  kind: 'npc' | 'player' | 'animal';
}

export interface NearbyPrompt {
  social?: {
    kind: 'npc' | 'remote_player' | 'signboard';
    id: string;
    label: string;
    player?: OnlinePlayerState;
    signTitle?: string;
    signText?: string;
  };
  execute?: {
    kind: 'npc_shop' | 'plot' | 'animal' | 'world' | 'chop_tree' | 'cave_dig' | 'cast_water';
    id: string;
    label: string;
    worldKind?: InteractiveWorldNode['kind'];
    targetZone?: WorldZoneId;
    portalId?: string;
    spotType?: 'river' | 'ocean';
    treeScope?: 'global' | 'farm';
    treeLevel?: 1 | 2 | 3 | 4;
    isStump?: boolean;
  };
}

export interface PlayerHeadAnchor {
  uid: string;
  avatarName: string;
  x: number;
  y: number;
  visible: boolean;
  isLocal?: boolean;
}

export interface EngineCallbacks {
  onMoveSync: (
    x: number,
    y: number,
    z: number,
    yaw: number,
    animState: 'idle' | 'walk' | 'run' | 'work' | 'jump' | 'swim'
  ) => void;
  onPromptChange: (prompt: NearbyPrompt | null) => void;
  onInteractWorld: (node: InteractiveWorldNode) => void;
  onChopTree?: (treeId: string, scope: 'global' | 'farm', treeLevel?: 1 | 2 | 3 | 4, isStump?: boolean) => void;
  onDigCaveTile?: (gx: number, gz: number) => void;
  onCastFishingWater?: (spotType: 'river' | 'ocean') => void;
  onFishingSpacePress?: () => void;
  onFishingCancel?: () => void;
  onPlayerJump?: () => void;
  onReadSignboard?: (signId: string, title: string, text: string) => void;
  onInteractNpc: (npcId: string, mode: 'talk' | 'shop') => void;
  onPrivateChatPlayer: (player: OnlinePlayerState) => void;
  onInteractPlot: (gx: number, gz: number) => void;
  onInteractAnimal: (animalId: string) => void;
  onZoneAutoDetect: (zone: WorldZoneId) => void;
  onTagsUpdate: (tags: FloatingTag[]) => void;
  onHeadAnchorsUpdate?: (anchors: PlayerHeadAnchor[]) => void;
  onToggleInventory?: () => void;
  onToggleChat?: () => void;
  onToggleMenu?: () => void;
  onToggleSettings?: () => void;
  onTriggerToolSlot?: (slotNum: number) => void;
  onGamepadChange?: (connected: boolean, name?: string) => void;
  onAssetsReady?: () => void;
  onNpcAmbientBubble?: (
    npcId: string,
    npcName: string,
    text: string,
    emotion: NpcEmotion,
    isThought: boolean
  ) => void;
  onAnimalAmbientBubble?: (
    animalId: string,
    animalName: string,
    text: string,
    isThought: boolean
  ) => void;
}

interface DustParticle {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
}

interface VfxParticle {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  gravity: number;
  rotSpeed: number;
  life: number;
  maxLife: number;
}

interface HitShakeEntry {
  obj: THREE.Object3D;
  baseRotX: number;
  baseRotZ: number;
  dirX: number;
  dirZ: number;
  timer: number;
  duration: number;
  amp: number;
}

interface FallingTreeAnim {
  treeId: string;
  mesh: THREE.Object3D;
  stumpMesh?: THREE.Object3D;
  fallAxisX: number;
  fallAxisZ: number;
  angle: number;
  angVel: number;
  baseRotY: number;
  x: number;
  z: number;
}

export class GameEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean;
  private isLowPowerDevice: boolean;
  private clock = new THREE.Clock();
  private frameId = 0;
  private disposed = false;
  private assetsReady = false;
  private mobileSprintActive = false;
  private lastOcclusionPassAt = 0;
  private cameraConfig: CameraConfig = { ...CAMERA_CONFIG };
  private performanceConfig: PerformanceConfig = { ...PERFORMANCE_CONFIG };

  private outdoorRefs: OutdoorWorldRefs | null = null;
  private interiorGroup: THREE.Group | null = null;
  private interiorInteractives: InteractiveWorldNode[] = [];
  private interiorColliders: WorldColliders = { boxes: [], circles: [] };
  private interiorRoomBounds = { halfW: 6, halfD: 5 };
  private coopLevel = 1;
  private barnLevel = 1;
  private hasCheeseMaker = false;
  private coopIncubators: EggIncubatorSlot[] = [];

  private farmPlotsGroup = new THREE.Group();
  private plotMeshes = new Map<string, THREE.Group>();
  private soilUntilledMat!: THREE.MeshStandardMaterial;
  private soilTilledMat!: THREE.MeshStandardMaterial;
  private soilWateredMat!: THREE.MeshStandardMaterial;
  private soilSlabGeo = new THREE.BoxGeometry(FARM_TILE_STEP + 0.04, 0.04, FARM_TILE_STEP + 0.04);
  private farmObstacleColliders: Array<{ x: number; z: number; radius: number; jumpable?: boolean; topY?: number }> = [];
  private activeHeldItemId: string | null = null;
  private caveDugTiles = new Set<string>();
  private caveDugGroup = new THREE.Group();
  private rtgiTargetColor = new THREE.Color('#d8e6c5');

  private animalsGroup = new THREE.Group();
  private animalActors = new Map<string, LivingAnimalActor>();
  private animalFootprints: Array<{ mesh: THREE.Mesh; life: number }> = [];
  private cachedAnimals: AnimalState[] = [];
  private barnLocked = true;
  private coopLocked = true;
  private stableLocked = true;
  private pendingApplesReady = 0;
  private pendingHasBees = false;
  private activeFarmOwnerKey = 'default_valley_farm';
  private pendingGlobalTrees: WorldTreeRecord[] | null = null;
  private pendingFarmTrees?: WorldTreeRecord[];
  private localUid = 'local';
  private localAvatarName = 'Farmer';
  private language: Language = 'en';
  private weatherFxEnabled = true;
  private lastAnchorEmitAt = 0;

  // Visual Smoothness & Seamless Transition Targets (Lighting, Sky, Fog, Weather, Camera)
  private targetSkyColor = new THREE.Color('#8fd3f4');
  private targetSunColor = new THREE.Color('#fff3d1');
  private targetSunIntensity = 1.28;
  private targetHemiIntensity = 0.64;
  private targetFogDensity = 0.0052;
  private targetWindowEmissive = 0.18;
  private targetWeatherOpacity = 0.0;
  private currentWeatherOpacity = 0.0;
  private smoothCamTarget = new THREE.Vector3(FARMHOUSE_OUTDOOR_SPAWN.x, 1.2, FARMHOUSE_OUTDOOR_SPAWN.z);
  private smoothCamYaw = Math.PI;
  private smoothCamPitch = CAMERA_CONFIG.defaultPitch;

  private playerRig: ChibiRig | null = null;
  private pendingAvatarConfig: AvatarConfig;
  private pendingToolKind: ToolKind | undefined;
  private pendingPlots: Record<string, FarmPlotState> | null = null;

  private playerPos = new THREE.Vector3(FARMHOUSE_OUTDOOR_SPAWN.x, 0, FARMHOUSE_OUTDOOR_SPAWN.z);
  private playerYaw = Math.PI;
  private playerVelX = 0;
  private playerVelZ = 0;
  private playerTurnRate = 0;
  private playerGaitPhase = 0;
  private playerLandSquash = 0;
  private wasAirborne = false;
  private jumpVelY = 0;
  private jumpBufferTimer = 0;
  private coyoteTimer = 0;
  private hasUsedGroundJump = false;
  private airJumpsRemaining = 1;
  private jumpKeyHeld = false;
  private doubleJumpAnimTimer = 0;
  private cornerCutLiftY = 0;
  private dashTimer = 0;
  private dashCooldown = 0;
  private dashVector = new THREE.Vector2();
  private dashSpeed = 15;
  private playerAnim: 'idle' | 'walk' | 'run' | 'work' | 'jump' | 'swim' | 'sleep' = 'idle';
  private playerSleeping = false;
  private playerSpeakingUntil = 0;
  private playerBreathCooldown = 0;
  private workTimer = 0;
  private workDuration = 0.42;
  private workStyle: NonNullable<LocomotionInput['workStyle']> = 'chop';

  // In-World 3D Fishing Rig (line + floating bobber + ripple ring + Space jump lock)
  private fishingState: 'idle' | 'casting' | 'waiting' | 'bite' | 'reeling' = 'idle';
  private fishingGroup: THREE.Group | null = null;
  private fishingBobber: THREE.Mesh | null = null;
  private fishingRipple: THREE.Mesh | null = null;
  private fishingLine: THREE.Line | null = null;
  private fishingBobberPos = new THREE.Vector3();

  // Impact VFX, Hit Shake, Physics Tree Felling & Off-Camera Unobserved Respawn Queue
  private vfxParticles: VfxParticle[] = [];
  private hitShakes: HitShakeEntry[] = [];
  private fallingTrees: FallingTreeAnim[] = [];
  private impactCamShake = 0;
  private deferredRespawns: Array<{ obj: THREE.Object3D; x: number; z: number }> = [];
  private prevPlotObstacles = new Map<string, string | undefined>();
  private caveFloorLevel = 1;

  // Perfected World-Space Third-Person Orbit / Lock Camera (Zero Feedback Spin)
  private camYaw = Math.PI;
  private camPitch = CAMERA_CONFIG.defaultPitch;
  private lockCamManualOrbitActive = false;
  private lockCamLastDragAt = 0;
  private camZoomDist = CAMERA_CONFIG.defaultDistance;
  private smoothCamDist = CAMERA_CONFIG.defaultDistance;
  private isDraggingCam = false;
  private cameraPointerId: number | null = null;
  private dragLastX = 0;
  private dragLastY = 0;
  private pointerDownX = 0;
  private pointerDownY = 0;

  // Sprint dust particle pool, Winter cold-breath vapor pool & footstep cadence
  private dustPool: DustParticle[] = [];
  private breathPool: DustParticle[] = [];
  private dustSpawnAccum = 0;
  private footstepAccum = 0;

  // Custom keybindings & gamepad state
  private keyBindings: KeyBindings = { ...DEFAULT_KEYBINDINGS };
  private gamepadConnected = false;
  private prevGamepadButtons: boolean[] = [];

  // Account creation realtime 3D preview mode
  public isTitleMode = true;
  public isCreationPreview = false;
  private creationPreviewYaw = 0.25;

  private npcRigs = new Map<
    string,
    {
      npcId: string;
      npcName: string;
      role: NpcProfessionRole;
      rig: ChibiRig;
      pos: THREE.Vector3;
      homeTargetPos: THREE.Vector3;
      targetPos: THREE.Vector3;
      yaw: number;
      zone: WorldZoneId;
      activity: string;
      idlePose: NpcIdlePose;
      activePose: NpcIdlePose;
      wanderTimer: number;
      emotion: NpcEmotion;
      energy: number;
      aiPhase:
        | 'commute'
        | 'work'
        | 'carry'
        | 'rest'
        | 'shelter'
        | 'shop_serve'
        | 'shop_tidy'
        | 'fish'
        | 'socialize'
        | 'ambient'
        | 'sleep';
      phaseTimer: number;
      vfxTimer: number;
      bubbleCooldown: number;
      greetCooldown: number;
      heldItemId: string | null;
      chatPartnerId: string | null;
      chatTimer: number;
      isTalking: boolean;
      spotIndex: number;
      benchIndex: number | null;
      stuckTimer: number;
      lastCheckX: number;
      lastCheckZ: number;
      fishCycleTimer: number;
    }
  >();
  private remoteRigs = new Map<
    string,
    { rig: ChibiRig; player: OnlinePlayerState; pos: THREE.Vector3; targetPos: THREE.Vector3; yaw: number; fadeIn?: number }
  >();

  private sunLight: THREE.DirectionalLight;
  private rimLight: THREE.DirectionalLight;
  private giBounceLight: THREE.DirectionalLight;
  private rtgiProbeLight: THREE.PointLight;
  private hemiLight: THREE.HemisphereLight;
  private envMapTexture: THREE.Texture | null = null;
  private composer: EffectComposer | null = null;
  private bloomPass: UnrealBloomPass | null = null;
  private graphicsProfile: Required<GraphicsSettings> = {
    quality: 'high',
    shadows: true,
    weatherParticles: true,
    renderScale: 1,
    realTimeLighting: true,
    dynamicShadows: true,
    globalIllumination: true,
    realTimeGI: true,
    rayTracing: false,
    pathTracing: false,
  };
  private weatherPoints: THREE.Points;
  private weatherPositions: Float32Array;
  private skySystem: SkyAtmosphereSystem;
  private tileHighlight: THREE.Mesh;

  private keys = new Set<string>();
  public touchMove = { x: 0, y: 0 };
  public currentZone: WorldZoneId = 'farm_home';
  public currentSeason: Season = 'Spring';
  public currentWeather: Weather = 'Sunny';
  public currentHour = 8;
  public currentDay = 1;
  public spouseId: string | null = null;
  public secretUnlocked = false;
  private lastZoneDetected: WorldZoneId = 'farm_home';
  private movementLocked = false;
  private landingRecoveryTimer = 0;
  private playerIdleTimer = 0;
  private playerIdleVariant: NpcIdlePose = 'relaxed';
  private npcScheduleOverrides: Record<string, NPCRoutineSlot[]> = {};
  private lastSoundSourcePos: THREE.Vector3 | null = null;
  private lastSoundSourceUntil = 0;

  private lastMoveSyncAt = 0;
  private lastPromptKey = '';
  private lastTagEmitAt = 0;
  private callbacks: EngineCallbacks;

  constructor(container: HTMLElement, initialAvatar: AvatarConfig, callbacks: EngineCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.pendingAvatarConfig = initialAvatar;

    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();
    const devMem = (navigator as Navigator & { deviceMemory?: number }).deviceMemory;
    const cpuCores = navigator.hardwareConcurrency || 4;
    this.isLowPowerDevice =
      this.isSoftwareGl ||
      (typeof devMem === 'number' && devMem <= 4) ||
      cpuCores <= 4 ||
      /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent || '');

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl && !this.isLowPowerDevice,
      powerPreference: this.isLowPowerDevice ? 'low-power' : 'high-performance',
      preserveDrawingBuffer: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.06;
    const initialDprCap = this.isSoftwareGl ? 1 : this.isLowPowerDevice ? 1.2 : 1.75;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, initialDprCap));
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = this.isLowPowerDevice ? THREE.PCFShadowMap : THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#93d5f7');
    this.scene.fog = new THREE.FogExp2('#93d5f7', 0.0062);

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.envMapTexture = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environment = this.envMapTexture;
    pmrem.dispose();

    const aspect = (container.clientWidth || window.innerWidth) / (container.clientHeight || window.innerHeight);
    const farClip = this.isLowPowerDevice ? 185 : 260;
    this.camera = new THREE.PerspectiveCamera(this.cameraConfig.fov, aspect, 0.1, farClip);
    this.camera.position.set(this.playerPos.x, 5.2, this.playerPos.z + this.cameraConfig.defaultDistance);

    this.hemiLight = new THREE.HemisphereLight('#bae6fd', '#6b4c35', 0.85);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight('#fff3d1', 1.65);
    this.sunLight.position.set(28, 42, 24);
    this.sunLight.castShadow = !this.isSoftwareGl;
    const initShadowRes = this.isLowPowerDevice ? 512 : 1024;
    this.sunLight.shadow.mapSize.set(initShadowRes, initShadowRes);
    const d = 52;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.normalBias = 0.02;
    this.sunLight.shadow.radius = 2.5;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    // Real-Time Rim Light (silhouette highlight opposite key sun)
    this.rimLight = new THREE.DirectionalLight('#dbeafe', 0.42);
    this.rimLight.position.set(-22, 18, -26);
    this.scene.add(this.rimLight);

    // Global Illumination (GI) Warm Indirect Ground Bounce Fill Light
    this.giBounceLight = new THREE.DirectionalLight('#fde68a', 0.36);
    this.giBounceLight.position.set(-14, -12, 16);
    this.scene.add(this.giBounceLight);

    // Real-Time Global Illumination (RTGI) Live Local Bounce Probe around player
    this.rtgiProbeLight = new THREE.PointLight('#bef264', 0.55, 18, 1.5);
    this.rtgiProbeLight.position.set(this.playerPos.x, 2.2, this.playerPos.z);
    this.scene.add(this.rtgiProbeLight);

    // Hardware-GPU Cinematic Post-Processing Pipeline (Ray Tracing / Path Tracing Bloom & ACES Output)
    if (!this.isSoftwareGl) {
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      this.composer = new EffectComposer(this.renderer);
      this.composer.addPass(new RenderPass(this.scene, this.camera));
      this.bloomPass = new UnrealBloomPass(new THREE.Vector2(w, h), 0.24, 0.55, 0.86);
      this.bloomPass.enabled = false;
      this.composer.addPass(this.bloomPass);
      this.composer.addPass(new OutputPass());
    }

    this.scene.add(this.farmPlotsGroup);
    this.scene.add(this.animalsGroup);

    // Dynamic 6-Phase Sky Dome, Drifting Clouds, Twinkling Stars & Dynamic Moon
    this.skySystem = new SkyAtmosphereSystem();
    this.scene.add(this.skySystem.root);

    // Target Tile Highlight Ring
    const ringGeo = new THREE.RingGeometry(0.7, 0.86, 16);
    ringGeo.rotateX(-Math.PI / 2);
    this.tileHighlight = new THREE.Mesh(
      ringGeo,
      new THREE.MeshBasicMaterial({ color: '#facc15', transparent: true, opacity: 0.78, side: THREE.DoubleSide })
    );
    this.tileHighlight.position.y = 0.05;
    this.tileHighlight.visible = false;
    this.scene.add(this.tileHighlight);

    // Sprint Dust Particle Pool
    const dustGeo = new THREE.SphereGeometry(0.16, 6, 6);
    for (let i = 0; i < 28; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: '#ede4d3', transparent: true, opacity: 0 });
      const mesh = new THREE.Mesh(dustGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.dustPool.push({ mesh, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 0.4 });
    }

    // Winter Cold-Weather Mouth Breath Steam Pool (zero per-frame allocations)
    const breathGeo = new THREE.SphereGeometry(0.085, 7, 7);
    for (let i = 0; i < 26; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: '#f0f9ff',
        transparent: true,
        opacity: 0,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(breathGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.breathPool.push({ mesh, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 0.95 });
    }

    // Weather Particle Pool
    const pCount = 260;
    this.weatherPositions = new Float32Array(pCount * 3);
    for (let i = 0; i < pCount; i++) {
      this.weatherPositions[i * 3] = (Math.random() - 0.5) * 60;
      this.weatherPositions[i * 3 + 1] = Math.random() * 18;
      this.weatherPositions[i * 3 + 2] = (Math.random() - 0.5) * 60;
    }
    const pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute('position', new THREE.BufferAttribute(this.weatherPositions, 3));
    const pMat = new THREE.PointsMaterial({ color: '#bae6fd', size: 0.22, transparent: true, opacity: 0.75 });
    this.weatherPoints = new THREE.Points(pGeo, pMat);
    this.weatherPoints.visible = false;
    this.scene.add(this.weatherPoints);

    this.initSharedSoilMaterials();
    this.bindEvents();
    void this.bootGLBAssets();
    this.tick();
  }

  private initSharedSoilMaterials() {
    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();
    const untilledTex = createCanvasTexture(
      (ctx, w, h) => {
        ctx.fillStyle = '#e5f2d9';
        ctx.fillRect(0, 0, w, h);
        for (let i = 0; i < 700; i++) {
          ctx.fillStyle = i % 2 === 0 ? 'rgba(42,95,28,0.16)' : 'rgba(255,255,255,0.14)';
          ctx.fillRect(Math.random() * w, Math.random() * h, 2, 5);
        }
      },
      128,
      2,
      maxAniso
    );
    const furrowTex = createCanvasTexture(
      (ctx, w, h) => {
        ctx.fillStyle = '#d4b48c';
        ctx.fillRect(0, 0, w, h);
        // Sculpted parallel plowed garden ridges
        for (let y = 0; y < h; y += 22) {
          ctx.fillStyle = 'rgba(72,42,18,0.34)';
          ctx.fillRect(0, y, w, 6);
          ctx.fillStyle = 'rgba(255,236,204,0.2)';
          ctx.fillRect(0, y + 7, w, 5);
        }
        for (let i = 0; i < 650; i++) {
          ctx.fillStyle = i % 2 === 0 ? 'rgba(55,30,12,0.18)' : 'rgba(220,185,140,0.15)';
          ctx.fillRect(Math.random() * w, Math.random() * h, 3, 2);
        }
      },
      128,
      2,
      maxAniso
    );
    const furrowBump = createCanvasTexture(
      (ctx, w, h) => {
        ctx.fillStyle = '#909090';
        ctx.fillRect(0, 0, w, h);
        for (let y = 0; y < h; y += 22) {
          ctx.fillStyle = '#383838';
          ctx.fillRect(0, y, w, 6);
          ctx.fillStyle = '#d4d4d4';
          ctx.fillRect(0, y + 7, w, 7);
        }
      },
      128,
      2,
      maxAniso,
      true
    );
    this.soilUntilledMat = new THREE.MeshStandardMaterial({ color: '#65ad3e', map: untilledTex, roughness: 0.94 });
    this.soilTilledMat = new THREE.MeshStandardMaterial({
      color: '#9e6734',
      map: furrowTex,
      bumpMap: furrowBump,
      bumpScale: 0.08,
      roughness: 0.94,
    });
    this.soilWateredMat = new THREE.MeshStandardMaterial({
      color: '#4e2f1a',
      map: furrowTex,
      bumpMap: furrowBump,
      bumpScale: 0.07,
      roughness: 0.62,
      metalness: 0.05,
    });
  }

  private async bootGLBAssets() {
    await glbAssets.preloadAll();
    if (this.disposed) return;

    const maxAniso = Math.min(
      this.renderer.capabilities.getMaxAnisotropy(),
      this.performanceConfig.lowPower4GbMode && this.isLowPowerDevice ? 2 : this.performanceConfig.maxAnisotropy
    );
    this.outdoorRefs = buildOutdoorWorld(maxAniso, this.secretUnlocked);
    if (this.pendingGlobalTrees && this.pendingGlobalTrees.length > 0) {
      syncGlobalTrees(this.outdoorRefs, this.pendingGlobalTrees, this.currentSeason);
    }
    rebuildFarmTrees(this.outdoorRefs, this.activeFarmOwnerKey, this.currentSeason, this.pendingFarmTrees);
    applySeasonToWorld(this.outdoorRefs, this.currentSeason);
    setAppleTreeVisuals(this.outdoorRefs, this.pendingApplesReady, this.pendingHasBees);
    this.applyPerformanceToOutdoorWorld();
    this.scene.add(this.outdoorRefs.group);

    this.playerRig = createChibiCharacter({ avatarConfig: this.pendingAvatarConfig, scale: 1.0 });
    this.playerRig.root.position.copy(this.playerPos);
    this.playerRig.root.rotation.y = this.playerYaw;
    if (this.pendingToolKind) {
      this.playerRig.toolMount.add(createToolMesh(this.pendingToolKind));
    }
    this.scene.add(this.playerRig.root);

    // Load all 25 NPCs using chibi_male.glb / chibi_female.glb with varied outfits & idle poses
    for (const npc of NPCS) {
      const rig = createChibiCharacter({
        avatarConfig: {
          gender: npc.gender,
          hairStyle: npc.appearance.hairStyle,
          hairColor: npc.appearance.hairColor,
          shirtStyle: npc.appearance.shirtStyle ?? 'overalls',
          pantsStyle: npc.appearance.pantsStyle ?? 'trousers',
          outfitColor: npc.appearance.outfitColor,
          pantsColor: npc.appearance.pantsColor ?? '#1e3a8a',
          hatStyle: npc.appearance.hatStyle,
          accessory: npc.appearance.accessory,
        },
        skinColor: npc.appearance.skinColor,
        scale: npc.appearance.scale,
      });
      const slot = getNpcRoutineSlot(npc, this.currentHour, this.currentWeather === 'Rainy', false);
      const pos = new THREE.Vector3(slot.x, 0, slot.z);
      rig.root.position.copy(pos);
      rig.root.visible = !slot.zone.startsWith('int_');
      this.scene.add(rig.root);
      this.npcRigs.set(npc.id, {
        npcId: npc.id,
        npcName: npc.name,
        role: getNpcProfessionRole(npc.id),
        rig,
        pos,
        homeTargetPos: pos.clone(),
        targetPos: pos.clone(),
        yaw: 0,
        zone: slot.zone,
        activity: slot.activity,
        idlePose: npc.appearance.idlePose ?? 'relaxed',
        activePose: npc.appearance.idlePose ?? 'relaxed',
        wanderTimer: 2 + Math.random() * 5,
        emotion: 'neutral',
        energy: 85 + Math.random() * 15,
        aiPhase: 'ambient',
        phaseTimer: 3 + Math.random() * 5,
        vfxTimer: 0,
        bubbleCooldown: 8 + Math.random() * 18,
        greetCooldown: 0,
        heldItemId: null,
        chatPartnerId: null,
        chatTimer: 0,
        isTalking: false,
        spotIndex: Math.floor(Math.random() * 4),
        benchIndex: null,
        stuckTimer: 0,
        lastCheckX: pos.x,
        lastCheckZ: pos.z,
        fishCycleTimer: Math.random() * 8,
      });
    }

    this.assetsReady = true;
    if (this.pendingPlots) {
      this.syncFarmPlots(this.pendingPlots);
    }
    if (this.cachedAnimals.length > 0) {
      this.syncAnimals(this.cachedAnimals, this.barnLocked, this.coopLocked);
    }
    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }
    this.callbacks.onAssetsReady?.();
  }

  public setKeyBindings(kb: KeyBindings) {
    this.keyBindings = { ...kb };
  }

  public setMobileSprint(active: boolean) {
    this.mobileSprintActive = active;
  }

  public setPovMode(mode: CameraPovMode) {
    this.cameraConfig.povMode = mode;
    if (mode === 'lock') {
      this.camZoomDist = this.cameraConfig.defaultDistance;
      this.camPitch = this.cameraConfig.defaultPitch;
      this.camYaw = this.playerYaw;
      this.smoothCamYaw = this.playerYaw;
      this.lockCamManualOrbitActive = false;
      this.lockCamLastDragAt = 0;
    }
  }

  public setCameraConfig(cfg: Partial<CameraConfig>) {
    this.cameraConfig = {
      povMode: cfg.povMode === 'free' ? 'free' : cfg.povMode === 'lock' ? 'lock' : this.cameraConfig.povMode,
      defaultDistance: Math.max(4.5, Math.min(18, Number(cfg.defaultDistance ?? this.cameraConfig.defaultDistance))),
      minZoom: Math.max(3.5, Math.min(10, Number(cfg.minZoom ?? this.cameraConfig.minZoom))),
      maxZoom: Math.max(8, Math.min(28, Number(cfg.maxZoom ?? this.cameraConfig.maxZoom))),
      fov: Math.max(32, Math.min(68, Number(cfg.fov ?? this.cameraConfig.fov))),
      defaultPitch: Math.max(0.12, Math.min(1.05, Number(cfg.defaultPitch ?? this.cameraConfig.defaultPitch))),
      mobileLockOrbitEnabled:
        typeof cfg.mobileLockOrbitEnabled === 'boolean'
          ? cfg.mobileLockOrbitEnabled
          : this.cameraConfig.mobileLockOrbitEnabled ?? true,
      mobileLockAutoReturnDelaySec: Math.max(
        0.5,
        Math.min(15, Number(cfg.mobileLockAutoReturnDelaySec ?? this.cameraConfig.mobileLockAutoReturnDelaySec ?? 2.5))
      ),
      mobileLockAutoReturnSpeed: Math.max(
        0.5,
        Math.min(10, Number(cfg.mobileLockAutoReturnSpeed ?? this.cameraConfig.mobileLockAutoReturnSpeed ?? 3.2))
      ),
    };
    this.camera.fov = this.cameraConfig.fov;
    this.camera.updateProjectionMatrix();
    if (this.cameraConfig.povMode === 'lock') {
      this.camZoomDist = this.cameraConfig.defaultDistance;
      this.camPitch = THREE.MathUtils.clamp(
        this.cameraConfig.defaultPitch,
        0.14,
        1.05
      );
    } else {
      this.camZoomDist = THREE.MathUtils.clamp(
        this.camZoomDist,
        this.cameraConfig.minZoom,
        this.cameraConfig.maxZoom
      );
    }
  }

  public setPerformanceConfig(cfg: Partial<PerformanceConfig>) {
    this.performanceConfig = {
      enableLod: typeof cfg.enableLod === 'boolean' ? cfg.enableLod : this.performanceConfig.enableLod,
      lod0Distance: Math.max(8, Math.min(45, Number(cfg.lod0Distance ?? this.performanceConfig.lod0Distance))),
      lod1Distance: Math.max(16, Math.min(90, Number(cfg.lod1Distance ?? this.performanceConfig.lod1Distance))),
      enableOcclusionCulling:
        typeof cfg.enableOcclusionCulling === 'boolean'
          ? cfg.enableOcclusionCulling
          : this.performanceConfig.enableOcclusionCulling,
      lowPower4GbMode:
        typeof cfg.lowPower4GbMode === 'boolean' ? cfg.lowPower4GbMode : this.performanceConfig.lowPower4GbMode,
      maxDprLowPower: Math.max(0.75, Math.min(2.0, Number(cfg.maxDprLowPower ?? this.performanceConfig.maxDprLowPower))),
      maxAnisotropy: Math.max(1, Math.min(8, Number(cfg.maxAnisotropy ?? this.performanceConfig.maxAnisotropy))),
    };
    this.applyPerformanceToOutdoorWorld();
    this.applyGraphicsSettings(this.graphicsProfile);
  }

  private applyPerformanceToOutdoorWorld() {
    if (!this.outdoorRefs) return;
    const lowPowerActive = this.performanceConfig.lowPower4GbMode && this.isLowPowerDevice;
    const ratio = lowPowerActive ? 0.52 : this.performanceConfig.lowPower4GbMode ? 0.78 : 1.0;
    this.outdoorRefs.grassInstanced.count = Math.max(120, Math.round(this.outdoorRefs.maxGrassCount * ratio));
    updateTreeLodDistances(
      this.outdoorRefs.group,
      this.performanceConfig.enableLod,
      this.performanceConfig.lod0Distance,
      this.performanceConfig.lod1Distance
    );
    if (!this.performanceConfig.enableOcclusionCulling) {
      for (const t of this.outdoorRefs.occlusionTargets) {
        t.obj.visible = t.shouldBeVisible ? t.shouldBeVisible() : true;
      }
    }
    const maxRenderDistance = lowPowerActive ? 84 : this.performanceConfig.lowPower4GbMode ? 115 : 165;
    this.camera.far = Math.max(120, Math.min(260, maxRenderDistance + 75));
    this.camera.updateProjectionMatrix();
    const weatherCount = lowPowerActive ? 120 : 260;
    this.weatherPoints.geometry.setDrawRange(0, weatherCount);
  }

  public setLocalIdentity(uid: string, avatarName: string) {
    this.localUid = uid;
    this.localAvatarName = avatarName;
  }

  public setActiveHeldItem(itemId: string | null) {
    this.activeHeldItemId = itemId;
    if (!this.playerRig) return;
    this.playerRig.toolMount.clear();
    if (itemId) {
      const heldMesh = createHeldItemMesh(itemId);
      if (heldMesh) {
        this.playerRig.toolMount.add(heldMesh);
      }
    }
  }

  public markCaveTileDug(gx: number, gz: number) {
    if (this.currentZone !== 'int_cave' || !this.interiorGroup) return;
    const key = `${gx}_${gz}`;
    if (this.caveDugTiles.has(key)) return;
    this.caveDugTiles.add(key);
    const patch = new THREE.Mesh(
      new THREE.BoxGeometry(1.48, 0.024, 1.48),
      new THREE.MeshStandardMaterial({ color: '#2e241d', roughness: 0.96, metalness: 0.02 })
    );
    patch.position.set(gx * 1.6, 0.015, gz * 1.6);
    patch.receiveShadow = true;
    this.caveDugGroup.add(patch);
    this.spawnImpactVfx('dirt', gx * 1.6, 0.15, gz * 1.6, 10);
  }

  public revealCaveDescentHole(gx: number, gz: number) {
    if (this.currentZone !== 'int_cave' || !this.interiorGroup) return;
    const wx = gx * 1.6;
    const wz = gz * 1.6;
    // Remove any existing hole interactive before adding new one
    this.interiorInteractives = this.interiorInteractives.filter((n) => n.kind !== 'cave_ladder_down');
    const holeMesh = createCaveDescentHoleMesh();
    holeMesh.name = 'CaveDescentHole';
    holeMesh.position.set(wx, 0, wz);
    this.caveDugGroup.add(holeMesh);
    this.interiorInteractives.push({
      id: `cave_ladder_lv_${this.caveFloorLevel + 1}`,
      kind: 'cave_ladder_down',
      label: `Descend Ladder to Cave Lv.${this.caveFloorLevel + 1} [F]`,
      x: wx,
      z: wz,
      radius: 1.95,
      mesh: holeMesh,
    });
    this.spawnImpactVfx('sparkle', wx, 0.45, wz, 14);
  }

  public resetCaveFloorForLevel(level: number) {
    this.caveFloorLevel = Math.max(1, level);
    if (this.currentZone !== 'int_cave' || !this.interiorGroup) return;
    this.caveDugTiles.clear();
    while (this.caveDugGroup.children.length > 0) {
      this.caveDugGroup.remove(this.caveDugGroup.children[0]);
    }
    this.interiorInteractives = this.interiorInteractives.filter((n) => n.kind !== 'cave_ladder_down');
    this.playerPos.set(0, 0, Math.max(1.5, this.interiorRoomBounds.halfD - 1.8));
    this.playerYaw = Math.PI;
    if (this.playerRig) {
      this.playerRig.root.position.copy(this.playerPos);
      this.playerRig.root.rotation.y = this.playerYaw;
    }
    this.spawnImpactVfx('dirt', this.playerPos.x, 0.35, this.playerPos.z, 12);
  }

  /**
   * Controls the live 3D in-world fishing rod cast, floating bobber, ripple ring & Space jump lock.
   */
  public setFishingVisualState(state: 'idle' | 'casting' | 'waiting' | 'bite' | 'reeling', _spotType?: 'river' | 'ocean') {
    this.fishingState = state;
    if (state === 'idle') {
      if (this.fishingGroup) this.fishingGroup.visible = false;
      return;
    }
    if (!this.fishingGroup) {
      const g = new THREE.Group();
      const bobber = new THREE.Mesh(
        new THREE.SphereGeometry(0.11, 10, 8),
        new THREE.MeshStandardMaterial({ color: '#ef4444', roughness: 0.45, metalness: 0.05 })
      );
      const bobberCap = new THREE.Mesh(
        new THREE.SphereGeometry(0.112, 10, 6, 0, Math.PI * 2, Math.PI * 0.52, Math.PI * 0.48),
        new THREE.MeshStandardMaterial({ color: '#e2e8f0', roughness: 0.55, metalness: 0.05 })
      );
      bobber.add(bobberCap);

      const ripple = new THREE.Mesh(
        new THREE.RingGeometry(0.16, 0.24, 20),
        new THREE.MeshBasicMaterial({ color: '#e0f2fe', transparent: true, opacity: 0.65, side: THREE.DoubleSide })
      );
      ripple.rotation.x = -Math.PI / 2;

      // 12-vertex smooth catenary fishing line from exact RodTip -> Bobber
      const linePts: THREE.Vector3[] = [];
      for (let i = 0; i < 12; i++) linePts.push(new THREE.Vector3());
      const lineGeo = new THREE.BufferGeometry().setFromPoints(linePts);
      const lineMat = new THREE.LineBasicMaterial({ color: '#f8fafc', transparent: true, opacity: 0.85 });
      const line = new THREE.Line(lineGeo, lineMat);
      line.frustumCulled = false;

      g.add(bobber, ripple, line);
      this.scene.add(g);
      this.fishingGroup = g;
      this.fishingBobber = bobber;
      this.fishingRipple = ripple;
      this.fishingLine = line;
    }

    if (state === 'casting') {
      const castDist = 2.65;
      this.fishingBobberPos.set(
        this.playerPos.x + Math.sin(this.playerYaw) * castDist,
        0.08,
        this.playerPos.z + Math.cos(this.playerYaw) * castDist
      );
      this.playWorkAnimation('fish_cast', 0.48);
      this.spawnImpactVfx('water', this.fishingBobberPos.x, 0.14, this.fishingBobberPos.z, 10);
    } else if (state === 'bite' || state === 'reeling') {
      this.spawnImpactVfx('water', this.fishingBobberPos.x, 0.18, this.fishingBobberPos.z, 14);
    }
    this.fishingGroup.visible = true;
  }

  public isFishingActive(): boolean {
    return this.fishingState !== 'idle';
  }

  public spawnImpactVfx(
    kind: 'wood' | 'leaf' | 'stone' | 'dirt' | 'water' | 'sparkle',
    x: number,
    y: number,
    z: number,
    count = 9
  ) {
    const palette: Record<typeof kind, number[]> = {
      wood: [0x925529, 0xc99c62, 0x6b3d1c],
      leaf: [0x22c55e, 0x4ade80, 0x16a34a],
      stone: [0x94a3b8, 0x64748b, 0xcbd5e1],
      dirt: [0x78492a, 0x5c371e, 0x9c673e],
      water: [0x7dd3fc, 0x38bdf8, 0xe0f2fe],
      sparkle: [0xfacc15, 0xfef08a, 0x38bdf8],
    };
    const colors = palette[kind];
    for (let i = 0; i < count; i++) {
      const col = colors[i % colors.length];
      const geo =
        kind === 'leaf'
          ? new THREE.BoxGeometry(0.11, 0.025, 0.07)
          : kind === 'water' || kind === 'sparkle'
            ? new THREE.SphereGeometry(0.055, 6, 5)
            : new THREE.BoxGeometry(0.08, 0.08, 0.08);
      const mat = new THREE.MeshStandardMaterial({
        color: col,
        roughness: kind === 'sparkle' ? 0.25 : 0.85,
        metalness: kind === 'sparkle' ? 0.4 : 0.02,
        emissive: kind === 'sparkle' ? new THREE.Color(col) : new THREE.Color(0x000000),
        emissiveIntensity: kind === 'sparkle' ? 0.7 : 0,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x + (Math.random() - 0.5) * 0.35, y + Math.random() * 0.25, z + (Math.random() - 0.5) * 0.35);
      this.scene.add(mesh);
      const angle = Math.random() * Math.PI * 2;
      const spd = kind === 'leaf' ? 0.7 + Math.random() * 0.9 : 1.2 + Math.random() * 1.9;
      this.vfxParticles.push({
        mesh,
        vx: Math.cos(angle) * spd,
        vy: (kind === 'leaf' ? 1.5 : 2.4) + Math.random() * 1.8,
        vz: Math.sin(angle) * spd,
        gravity: kind === 'leaf' ? 3.2 : 10.5,
        rotSpeed: (Math.random() - 0.5) * 9,
        life: kind === 'leaf' ? 0.95 : 0.55 + Math.random() * 0.2,
        maxLife: kind === 'leaf' ? 0.95 : 0.75,
      });
    }
    if (kind === 'wood' || kind === 'stone') {
      this.impactCamShake = Math.max(this.impactCamShake, 0.12);
    }
  }

  public triggerTreeHitReaction(treeId: string) {
    const t = this.outdoorRefs?.farmTrees.find((n) => n.id === treeId);
    if (!t) return;
    const targetObj = t.isStump ? t.stumpMesh : t.mesh;
    if (!targetObj) return;
    const dx = t.x - this.playerPos.x;
    const dz = t.z - this.playerPos.z;
    const len = Math.max(0.01, Math.hypot(dx, dz));
    this.hitShakes.push({
      obj: targetObj,
      baseRotX: 0,
      baseRotZ: 0,
      dirX: dx / len,
      dirZ: dz / len,
      timer: 0,
      duration: 0.32,
      amp: t.isStump ? 0.1 : 0.14,
    });
    this.spawnImpactVfx('wood', t.x, 0.7, t.z, 9);
    if (!t.isStump) {
      this.spawnImpactVfx('leaf', t.x, 2.4, t.z, 8);
    }
  }

  public triggerPlotHitReaction(gx: number, gz: number, vfxKind: 'wood' | 'stone' | 'dirt' | 'water' | 'leaf' = 'dirt') {
    const worldX = FARM_ORIGIN_X + gx * FARM_TILE_STEP;
    const worldZ = FARM_ORIGIN_Z + gz * FARM_TILE_STEP;
    const tileGroup = this.plotMeshes.get(`${gx}_${gz}`);
    if (tileGroup && tileGroup.children.length > 1) {
      const obsObj = tileGroup.children[1];
      this.hitShakes.push({
        obj: obsObj,
        baseRotX: 0,
        baseRotZ: 0,
        dirX: Math.sin(this.playerYaw),
        dirZ: Math.cos(this.playerYaw),
        timer: 0,
        duration: 0.28,
        amp: 0.12,
      });
    }
    this.spawnImpactVfx(vfxKind, worldX, 0.35, worldZ, 9);
  }

  /**
   * Physics-based tree felling: topples upper tree trunk & canopy under angular gravity
   * away from the player's axe swing, emits leaf/wood VFX, and leaves behind a SOLID 3D tree stump!
   */
  public markTreeFelledToStump(treeId: string) {
    const t = this.outdoorRefs?.farmTrees.find((n) => n.id === treeId);
    if (!t || t.scope !== 'farm') return;
    t.isStump = true;
    t.chopped = false;
    t.radius = 0.52 * (t.scale ?? 1);
    if (t.stumpMesh) t.stumpMesh.visible = true;
    if (t.mesh && t.mesh.visible) {
      const dx = t.x - this.playerPos.x;
      const dz = t.z - this.playerPos.z;
      const len = Math.max(0.01, Math.hypot(dx, dz));
      this.fallingTrees.push({
        treeId: t.id,
        mesh: t.mesh,
        stumpMesh: t.stumpMesh,
        fallAxisX: dz / len,
        fallAxisZ: -dx / len,
        angle: 0,
        angVel: 0.45,
        baseRotY: t.mesh.rotation.y,
        x: t.x,
        z: t.z,
      });
    }
    this.spawnImpactVfx('wood', t.x, 0.85, t.z, 14);
    this.spawnImpactVfx('leaf', t.x, 2.5, t.z, 14);
  }

  private isPointInCameraFrustum(x: number, z: number): boolean {
    if (this.currentZone.startsWith('int_')) return false;
    this.camera.updateMatrixWorld();
    _projScreenMat.multiplyMatrices(this.camera.projectionMatrix, this.camera.matrixWorldInverse);
    _frustum.setFromProjectionMatrix(_projScreenMat);
    _projVec.set(x, 1.0, z);
    return _frustum.containsPoint(_projVec);
  }

  /**
   * Computes real physical walking surface height (Y) for elevated outdoor structures
   * (West Brook Bridge, River Dock, Ocean Pier) AND jumpable/standable 3D props
   * (Town Square Park Benches, Festival Stage, Shop Crates, Ore Cart, Forest Logs, Tree Stumps, Fences).
   */
  private getGroundSurfaceY(x: number, z: number, currentY = this.playerPos.y): number {
    if (this.currentZone.startsWith('int_')) return 0;

    let surfaceY = 0;

    // 1) West Brook Wooden Bridge (x: -69.75 .. -58.25, z: -2.35 .. +2.35, deck top y = 0.23)
    if (z >= -2.35 && z <= 2.35 && x >= -69.85 && x <= -58.15) {
      if (x < -68.8) {
        const t = THREE.MathUtils.clamp((x - -69.85) / 1.05, 0, 1);
        surfaceY = Math.max(surfaceY, t * 0.23);
      } else if (x > -59.2) {
        const t = THREE.MathUtils.clamp((-58.15 - x) / 1.05, 0, 1);
        surfaceY = Math.max(surfaceY, t * 0.23);
      } else {
        surfaceY = Math.max(surfaceY, 0.23);
      }
    }

    // 2) Freshwater River Fishing Dock (x: 38.35 .. 44.5, z: 14.2 .. 17.8, deck top y = 0.285)
    if (z >= 14.2 && z <= 17.8 && x >= 38.35 && x <= 44.6) {
      if (x < 39.4) {
        const t = THREE.MathUtils.clamp((x - 38.35) / 1.05, 0, 1);
        surfaceY = Math.max(surfaceY, t * 0.285);
      } else {
        surfaceY = Math.max(surfaceY, 0.285);
      }
    }

    // 3) Eastern Ocean Pier (x: 45.8 .. 56.3, z: -9.8 .. -6.2, deck top y = 0.285)
    if (z >= -9.8 && z <= -6.2 && x >= 45.8 && x <= 56.3) {
      if (x < 46.9) {
        const t = THREE.MathUtils.clamp((x - 45.8) / 1.1, 0, 1);
        surfaceY = Math.max(surfaceY, t * 0.285);
      } else {
        surfaceY = Math.max(surfaceY, 0.285);
      }
    }

    // 4) Standable/Jumpable Small 3D Props (Park Benches, Stage, Crates, Ore Cart, Planters, Shipping Bin, Fences)
    if (this.outdoorRefs) {
      const footPad = 0.16;
      for (const box of this.outdoorRefs.colliders.boxes) {
        if (!box.jumpable || typeof box.topY !== 'number') continue;
        if (
          x >= box.minX - footPad &&
          x <= box.maxX + footPad &&
          z >= box.minZ - footPad &&
          z <= box.maxZ + footPad &&
          currentY >= box.topY - 0.34
        ) {
          surfaceY = Math.max(surfaceY, box.topY);
        }
      }

      // Standable circular props (Forest Logs)
      for (const c of this.outdoorRefs.colliders.circles) {
        if (!c.jumpable || typeof c.topY !== 'number') continue;
        const r = c.radius + 0.14;
        const dx = x - c.x;
        const dz = z - c.z;
        if (dx * dx + dz * dz <= r * r && currentY >= c.topY - 0.34) {
          surfaceY = Math.max(surfaceY, c.topY);
        }
      }

      // Standable Outdoor Tree Stumps
      for (const tree of this.outdoorRefs.choppableTrees) {
        if (tree.chopped || !tree.isStump || typeof tree.topY !== 'number') continue;
        const r = tree.radius + 0.14;
        const dx = x - tree.x;
        const dz = z - tree.z;
        if (dx * dx + dz * dz <= r * r && currentY >= tree.topY - 0.34) {
          surfaceY = Math.max(surfaceY, tree.topY);
        }
      }

      // Standable Farm Plot Stumps / Rocks / Roots
      for (const obs of this.farmObstacleColliders) {
        if (!obs.jumpable || typeof obs.topY !== 'number') continue;
        const r = obs.radius + 0.14;
        const dx = x - obs.x;
        const dz = z - obs.z;
        if (dx * dx + dz * dz <= r * r && currentY >= obs.topY - 0.34) {
          surfaceY = Math.max(surfaceY, obs.topY);
        }
      }
    }

    return surfaceY;
  }

  public getNpcEmotion(npcId: string): NpcEmotion {
    return this.npcRigs.get(npcId)?.emotion ?? 'neutral';
  }

  /**
   * Checks if there is fishable water approximately 1 tile (1.5m–2.2m) directly ahead of the player.
   */
  private detectWaterAheadAtOneTile(): 'river' | 'ocean' | null {
    if (this.currentZone.startsWith('int_')) return null;
    for (const dist of [1.55, 2.05]) {
      const tx = this.playerPos.x + Math.sin(this.playerYaw) * dist;
      const tz = this.playerPos.z + Math.cos(this.playerYaw) * dist;
      // West Brook (x: -67.4 .. -60.6, outside bridge deck width)
      if (tx >= -67.4 && tx <= -60.6 && Math.abs(tz) >= 2.2) {
        return 'river';
      }
      // River Cove (x: 39.5 .. 48.2, z: 10.0 .. 36.0)
      if (tx >= 39.5 && tx <= 48.2 && tz >= 10.0 && tz <= 36.0) {
        return 'river';
      }
      // Eastern Ocean (x >= 47.4, or looking off the side/end of Ocean Pier)
      if (tx >= 47.4) {
        const onPierInterior = tx >= 46.8 && tx <= 55.9 && tz >= -9.55 && tz <= -6.45;
        if (!onPierInterior) return 'ocean';
      }
    }
    return null;
  }

  public applyGraphicsSettings(g: GraphicsSettings) {
    const dynamicShadows = g.dynamicShadows ?? g.shadows;
    const realTimeLighting = g.realTimeLighting ?? g.quality !== 'low';
    const globalIllumination = g.globalIllumination ?? g.quality !== 'low';
    const realTimeGI = g.realTimeGI ?? (g.quality === 'high' || g.quality === 'ultra');
    const rayTracing = Boolean(g.rayTracing);
    const pathTracing = Boolean(g.pathTracing);

    this.graphicsProfile = {
      quality: g.quality,
      shadows: dynamicShadows,
      weatherParticles: g.weatherParticles,
      renderScale: g.renderScale,
      realTimeLighting,
      dynamicShadows,
      globalIllumination,
      realTimeGI,
      rayTracing,
      pathTracing,
    };

    this.weatherFxEnabled = g.weatherParticles;
    const allowShadows = !this.isSoftwareGl && dynamicShadows && g.quality !== 'low';
    this.renderer.shadowMap.enabled = allowShadows;
    this.sunLight.castShadow = allowShadows;

    const lowPowerCap = this.performanceConfig.lowPower4GbMode && this.isLowPowerDevice;
    const shadowRes = lowPowerCap
      ? 512
      : pathTracing || rayTracing || g.quality === 'ultra'
        ? 2048
        : g.quality === 'high'
          ? 1024
          : 512;
    if (this.sunLight.shadow.mapSize.x !== shadowRes) {
      this.sunLight.shadow.mapSize.set(shadowRes, shadowRes);
      if (this.sunLight.shadow.map) {
        this.sunLight.shadow.map.dispose();
        this.sunLight.shadow.map = null;
      }
    }
    this.sunLight.shadow.radius = pathTracing ? 4.8 : rayTracing ? 3.4 : 2.2;

    // Global Illumination (IBL + subtle indirect ground bounce fill) & Real-Time Lighting rim
    // Physically energy-conserving intensities (prevents overexposure, blown-out highlights & energy gain!)
    this.scene.environment = globalIllumination || rayTracing || pathTracing ? this.envMapTexture : null;
    this.rimLight.visible = realTimeLighting || rayTracing || pathTracing;
    this.rimLight.intensity = pathTracing ? 0.16 : rayTracing ? 0.14 : 0.12;
    this.giBounceLight.visible = globalIllumination || realTimeGI || pathTracing;
    this.giBounceLight.intensity = pathTracing ? 0.12 : realTimeGI ? 0.1 : globalIllumination ? 0.08 : 0;
    this.rtgiProbeLight.visible = realTimeGI || pathTracing;
    if (!this.rtgiProbeLight.visible) {
      this.rtgiProbeLight.intensity = 0;
    }

    // Calibrated ACES Filmic exposure: keeps white house walls & beach sand crisp with rich shading (zero whiteout!)
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = pathTracing ? 0.85 : rayTracing ? 0.88 : realTimeLighting ? 0.92 : 0.94;

    // Physically balanced roughness-weighted reflection intensity (energy conservation: matte surfaces never blow out!)
    const envBoost = pathTracing ? 0.48 : rayTracing ? 0.42 : globalIllumination ? 0.3 : 0.18;
    if (this.outdoorRefs) {
      const waterMats = [this.outdoorRefs.waterMesh.material, this.outdoorRefs.brookMesh.material];
      for (const m of waterMats) {
        if (m instanceof THREE.MeshStandardMaterial) {
          m.roughness = rayTracing || pathTracing ? 0.18 : 0.26;
          m.metalness = rayTracing || pathTracing ? 0.32 : 0.16;
          m.envMapIntensity = Math.min(0.65, envBoost * (rayTracing || pathTracing ? 1.15 : 0.85));
          m.needsUpdate = true;
        }
      }
    }
    this.scene.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mat = (obj as THREE.Mesh).material;
        if (
          mat instanceof THREE.MeshStandardMaterial &&
          mat !== this.soilUntilledMat &&
          mat !== this.soilTilledMat &&
          mat !== this.soilWateredMat
        ) {
          const isMatte = mat.roughness >= 0.72 && mat.metalness < 0.15;
          if (isMatte) {
            // Strictly cap IBL reflection on matte stucco walls, beach sand, terrain, and wood to prevent specular blowout & hotspot artifacts
            mat.envMapIntensity = Math.min(0.11, envBoost * 0.22);
          } else {
            mat.envMapIntensity = Math.min(0.55, envBoost * (1 - mat.roughness * 0.55));
          }
        }
      }
    });

    // Strict HDR-only cinematic bloom (threshold = 1.65 prevents sunlit white stucco & sand from blooming!)
    if (this.bloomPass) {
      const enablePost = !this.isSoftwareGl && !lowPowerCap && (rayTracing || pathTracing);
      this.bloomPass.enabled = enablePost;
      this.bloomPass.strength = pathTracing ? 0.08 : 0.05;
      this.bloomPass.radius = 0.28;
      this.bloomPass.threshold = 1.65;
    }

    const dprLimit = lowPowerCap
      ? 1.15
      : this.performanceConfig.lowPower4GbMode
        ? 1.45
        : g.quality === 'ultra' || g.quality === 'high'
          ? 2
          : 1.5;
    const baseDpr = this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, dprLimit);
    const scale = Math.max(0.55, Math.min(1.0, g.renderScale));
    this.renderer.setPixelRatio(Math.max(0.6, baseDpr * scale));
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h);
    if (this.composer) {
      this.composer.setSize(w, h);
    }
    if (!g.weatherParticles) {
      this.weatherPoints.visible = false;
    }
  }

  public regenerateFarmTrees(farmOwnerKey: string, savedFarmTrees?: WorldTreeRecord[]) {
    this.activeFarmOwnerKey = farmOwnerKey || 'default_valley_farm';
    this.pendingFarmTrees = savedFarmTrees;
    if (this.outdoorRefs) {
      rebuildFarmTrees(this.outdoorRefs, this.activeFarmOwnerKey, this.currentSeason, savedFarmTrees);
      updateTreeLodDistances(
        this.outdoorRefs.farmTreesGroup,
        this.performanceConfig.enableLod,
        this.performanceConfig.lod0Distance,
        this.performanceConfig.lod1Distance
      );
    }
  }

  public setGlobalTrees(records: WorldTreeRecord[]) {
    this.pendingGlobalTrees = records;
    if (this.outdoorRefs) {
      syncGlobalTrees(this.outdoorRefs, records, this.currentSeason);
    }
  }

  public setMovementLocked(locked: boolean) {
    this.movementLocked = locked;
    if (locked) {
      this.keys.clear();
      this.touchMove.x = 0;
      this.touchMove.y = 0;
      this.playerVelX = 0;
      this.playerVelZ = 0;
      this.dashTimer = 0;
    }
  }

  public setSkyAtmosphereConfig(cfg?: Partial<SkyAtmosphereConfig> | null) {
    this.skySystem.setConfig(cfg);
  }

  public setNpcScheduleOverrides(overrides?: Record<string, NPCRoutineSlot[]> | null) {
    this.npcScheduleOverrides = overrides ? { ...overrides } : {};
    this.setWorldCondition(
      this.currentSeason,
      this.currentWeather,
      this.currentHour,
      this.currentDay,
      this.spouseId,
      this.secretUnlocked
    );
  }

  public notifyWorldSound(x: number, z: number, durationSec = 4.5) {
    if (!this.lastSoundSourcePos) this.lastSoundSourcePos = new THREE.Vector3();
    this.lastSoundSourcePos.set(x, 0, z);
    this.lastSoundSourceUntil = this.clock.elapsedTime + durationSec;
  }

  public setPlayerSleeping(sleeping: boolean) {
    this.playerSleeping = sleeping;
    if (sleeping) {
      this.playerVelX = 0;
      this.playerVelZ = 0;
      this.jumpVelY = 0;
      this.playerAnim = 'sleep';
    }
  }

  public triggerPlayerSpeechBreath(durationSec = 2.4) {
    this.playerSpeakingUntil = Math.max(this.playerSpeakingUntil, this.clock.elapsedTime + durationSec);
    if ((this.currentSeason === 'Winter' || this.currentWeather === 'Snowy') && !this.currentZone.startsWith('int_')) {
      this.emitWinterBreathSteam(this.playerPos.x, this.playerPos.y, this.playerPos.z, this.playerYaw, 2);
    }
  }

  public triggerNpcSpeechBreath(npcId: string) {
    if (this.currentSeason !== 'Winter' && this.currentWeather !== 'Snowy') return;
    if (this.currentZone.startsWith('int_')) return;
    const entry = this.npcRigs.get(npcId);
    if (!entry || !entry.rig.root.visible) return;
    this.emitWinterBreathSteam(entry.pos.x, entry.pos.y, entry.pos.z, entry.yaw, 2);
  }

  public emitWinterBreathSteam(worldX: number, worldY: number, worldZ: number, yaw: number, count = 2) {
    if (this.currentSeason !== 'Winter' && this.currentWeather !== 'Snowy') return;
    if (this.currentZone.startsWith('int_')) return;
    const fx = Math.sin(yaw);
    const fz = Math.cos(yaw);
    let spawned = 0;
    for (const slot of this.breathPool) {
      if (slot.life > 0) continue;
      slot.maxLife = 0.85 + Math.random() * 0.35;
      slot.life = slot.maxLife;
      const spreadX = (Math.random() - 0.5) * 0.07;
      const spreadZ = (Math.random() - 0.5) * 0.07;
      slot.mesh.position.set(worldX + fx * 0.25 + spreadX, worldY + 1.24 + (Math.random() - 0.5) * 0.04, worldZ + fz * 0.25 + spreadZ);
      slot.mesh.scale.setScalar(0.45);
      slot.mesh.visible = true;
      slot.vx = fx * (0.36 + Math.random() * 0.16) + (Math.random() - 0.5) * 0.12;
      slot.vy = 0.26 + Math.random() * 0.14;
      slot.vz = fz * (0.36 + Math.random() * 0.16) + (Math.random() - 0.5) * 0.12;
      spawned += 1;
      if (spawned >= count) break;
    }
  }

  public triggerJump() {
    if (this.isTitleMode || !this.assetsReady || this.movementLocked || this.playerSleeping) return;
    // CRITICAL: Pressing Space while fishing NEVER makes the character jump!
    if (this.fishingState !== 'idle') {
      this.callbacks.onFishingSpacePress?.();
      return;
    }
    this.jumpKeyHeld = true;
    this.jumpBufferTimer = 0.13;
    this.performBufferedJump();
  }

  public releaseJump() {
    this.jumpKeyHeld = false;
    // Short Hop: releasing Jump early while ascending trims upward velocity cleanly for variable jump height
    if (this.jumpVelY > 2.35) {
      this.jumpVelY *= 0.52;
    }
  }

  private performBufferedJump() {
    if (this.fishingState !== 'idle' || this.movementLocked || this.playerSleeping) {
      this.jumpBufferTimer = 0;
      return;
    }
    if (this.jumpBufferTimer <= 0) return;

    // 1) Primary / Anti-Exploit Coyote Jump:
    // Strictly requires !hasUsedGroundJump so walking off a ledge grants coyote grace once and can NEVER be exploited.
    if (!this.hasUsedGroundJump && this.coyoteTimer > 0) {
      this.jumpVelY = 6.55;
      this.hasUsedGroundJump = true;
      this.coyoteTimer = 0;
      this.jumpBufferTimer = 0;
      this.notifyWorldSound(this.playerPos.x, this.playerPos.z, 2.5);
      soundEngine.playJump();
      this.callbacks.onPlayerJump?.();
      return;
    }

    // 2) Realistic Double Jump (strictly 1 mid-air boost per ground contact, cannot stack with coyote for a triple jump)
    if (this.airJumpsRemaining > 0 && (this.wasAirborne || this.hasUsedGroundJump)) {
      this.jumpVelY = 5.65;
      this.hasUsedGroundJump = true;
      this.airJumpsRemaining = 0;
      this.coyoteTimer = 0;
      this.jumpBufferTimer = 0;
      this.doubleJumpAnimTimer = 0.28;
      // Subtle mid-air puff under boots for tactile double-jump feedback
      for (let i = 0; i < 3; i++) {
        this.spawnDustPuff(this.playerPos.y + 0.08);
      }
      this.notifyWorldSound(this.playerPos.x, this.playerPos.z, 2.0);
      soundEngine.playJump();
      this.callbacks.onPlayerJump?.();
    }
  }

  public triggerDash() {
    if (this.isTitleMode || !this.assetsReady || this.movementLocked || this.playerSleeping || this.dashCooldown > 0 || this.fishingState !== 'idle') return;
    const ix = this.touchMove.x;
    const iz = this.touchMove.y;
    const fx = Math.sin(this.playerYaw);
    const fz = Math.cos(this.playerYaw);
    const length = Math.hypot(ix, iz);
    if (length > 0.15) {
      const forwardX = Math.sin(this.smoothCamYaw), forwardZ = Math.cos(this.smoothCamYaw);
      const rightX = -Math.cos(this.smoothCamYaw), rightZ = Math.sin(this.smoothCamYaw);
      this.dashVector.set(forwardX * -iz + rightX * ix, forwardZ * -iz + rightZ * ix).normalize();
    } else this.dashVector.set(fx, fz);
    this.dashTimer = 0.18;
    this.dashCooldown = 0.85;
  }

  public markTreeChopped(treeId: string, chopped = true) {
    const t = this.outdoorRefs?.farmTrees.find((n) => n.id === treeId);
    if (t && t.scope === 'farm') {
      t.chopped = chopped;
      t.isStump = false;
      if (chopped) {
        if (t.mesh) t.mesh.visible = false;
        if (t.stumpMesh) t.stumpMesh.visible = false;
        this.spawnImpactVfx('wood', t.x, 0.5, t.z, 12);
      } else {
        // Off-camera unobserved respawn: only pop into view when player is NOT looking at this spot!
        if (t.mesh) {
          t.mesh.rotation.x = 0;
          t.mesh.rotation.z = 0;
          if (this.isPointInCameraFrustum(t.x, t.z)) {
            t.mesh.visible = false;
            this.deferredRespawns.push({ obj: t.mesh, x: t.x, z: t.z });
          } else {
            t.mesh.visible = true;
          }
        }
        if (t.stumpMesh) t.stumpMesh.visible = false;
      }
    }
  }

  public regrowOutdoorTrees() {
    this.outdoorRefs?.farmTrees.forEach((t) => {
      if (t.scope === 'farm') {
        const wasGone = t.chopped || t.isStump;
        t.chopped = false;
        t.isStump = false;
        if (t.stumpMesh) t.stumpMesh.visible = false;
        if (t.mesh) {
          t.mesh.rotation.x = 0;
          t.mesh.rotation.z = 0;
          if (wasGone && this.isPointInCameraFrustum(t.x, t.z)) {
            t.mesh.visible = false;
            this.deferredRespawns.push({ obj: t.mesh, x: t.x, z: t.z });
          } else {
            t.mesh.visible = true;
          }
        }
      }
    });
  }

  public syncAppleTree(applesReady: number, hasBees: boolean) {
    this.pendingApplesReady = applesReady;
    this.pendingHasBees = hasBees;
    if (this.outdoorRefs) {
      setAppleTreeVisuals(this.outdoorRefs, applesReady, hasBees);
    }
  }

  private spawnDustPuff(yOverride?: number) {
    const slot = this.dustPool.find((d) => d.life <= 0);
    if (!slot) return;
    slot.life = slot.maxLife;
    const backX = this.playerPos.x - Math.sin(this.playerYaw) * 0.35 + (Math.random() - 0.5) * 0.25;
    const backZ = this.playerPos.z - Math.cos(this.playerYaw) * 0.35 + (Math.random() - 0.5) * 0.25;
    slot.mesh.position.set(backX, yOverride ?? 0.14, backZ);
    slot.mesh.scale.setScalar(0.8);
    slot.mesh.visible = true;
    slot.vx = -Math.sin(this.playerYaw) * 0.6 + (Math.random() - 0.5) * 0.4;
    slot.vy = 0.65 + Math.random() * 0.35;
    slot.vz = -Math.cos(this.playerYaw) * 0.6 + (Math.random() - 0.5) * 0.4;
  }

  private onKeyDown = (e: KeyboardEvent) => {
    const tag = (document.activeElement?.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
    const wasHeld = this.keys.has(e.code);
    this.keys.add(e.code);
    if (this.isTitleMode) return;

    if (e.code === this.keyBindings.jump) {
      e.preventDefault();
      if (!wasHeld) this.triggerJump();
    } else if (e.code === this.keyBindings.dash) {
      e.preventDefault();
      this.triggerDash();
    } else if (e.code === this.keyBindings.social) {
      e.preventDefault();
      this.triggerContextualAction('social');
    } else if (e.code === this.keyBindings.execute) {
      e.preventDefault();
      this.triggerContextualAction('execute');
    } else if (e.code === this.keyBindings.inventory) {
      e.preventDefault();
      this.callbacks.onToggleInventory?.();
    } else if (e.code === this.keyBindings.chat) {
      e.preventDefault();
      this.callbacks.onToggleChat?.();
    } else if (this.keyBindings.openMenu && e.code === this.keyBindings.openMenu) {
      e.preventDefault();
      this.callbacks.onToggleMenu?.();
    } else if (this.keyBindings.openSettings && e.code === this.keyBindings.openSettings) {
      e.preventDefault();
      this.callbacks.onToggleSettings?.();
    } else if (e.code === this.keyBindings.toolSlot1) {
      e.preventDefault();
      this.callbacks.onTriggerToolSlot?.(1);
    } else if (e.code === this.keyBindings.toolSlot2) {
      e.preventDefault();
      this.callbacks.onTriggerToolSlot?.(2);
    } else if (e.code === this.keyBindings.toolSlot3) {
      e.preventDefault();
      this.callbacks.onTriggerToolSlot?.(3);
    } else if (e.code === this.keyBindings.toolSlot4) {
      e.preventDefault();
      this.callbacks.onTriggerToolSlot?.(4);
    } else if (e.code === this.keyBindings.toolSlot5) {
      e.preventDefault();
      this.callbacks.onTriggerToolSlot?.(5);
    } else if (e.code === this.keyBindings.toolSlot6) {
      e.preventDefault();
      this.callbacks.onTriggerToolSlot?.(6);
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
    if (e.code === this.keyBindings.jump) {
      this.releaseJump();
    }
  };

  private onBlur = () => {
    this.keys.clear();
    this.jumpKeyHeld = false;
    this.touchMove.x = 0;
    this.touchMove.y = 0;
    this.isDraggingCam = false;
    this.cameraPointerId = null;
  };

  private onResize = () => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    if (this.composer) {
      this.composer.setSize(w, h);
    }
  };

  private onPointerDown = (e: PointerEvent) => {
    // One pointer owns camera orbit; other fingers can operate movement/actions.
    if (this.cameraPointerId !== null) return;
    this.cameraPointerId = e.pointerId;
    this.isDraggingCam = true;
    this.dragLastX = e.clientX;
    this.dragLastY = e.clientY;
    this.pointerDownX = e.clientX;
    this.pointerDownY = e.clientY;
    try { (e.currentTarget as HTMLCanvasElement).setPointerCapture(e.pointerId); } catch { /* fallback */ }
  };

  private onPointerMove = (e: PointerEvent) => {
    if (!this.isDraggingCam || e.pointerId !== this.cameraPointerId) return;
    const dx = e.clientX - this.dragLastX;
    const dy = e.clientY - this.dragLastY;
    this.dragLastX = e.clientX;
    this.dragLastY = e.clientY;

    if (this.isTitleMode && this.isCreationPreview) {
      this.creationPreviewYaw += dx * 0.012;
      return;
    }
    if (!this.isTitleMode && this.cameraConfig.povMode === 'free') {
      const yawScale = e.pointerType === 'touch' ? 0.0088 : 0.0064;
      const pitchScale = e.pointerType === 'touch' ? 0.006 : 0.0046;
      this.camYaw -= dx * yawScale;
      this.camPitch = THREE.MathUtils.clamp(this.camPitch + dy * pitchScale, 0.14, 1.08);
    } else if (!this.isTitleMode && this.cameraConfig.povMode === 'lock') {
      // Direct world-space orbit in Lock POV (identical smooth feel to desktop Free POV, zero spin feedback loop),
      // then smoothly eases back behind the character after mobileLockAutoReturnDelaySec when idle.
      if (this.cameraConfig.mobileLockOrbitEnabled !== false) {
        const yawScale = e.pointerType === 'touch' ? 0.0088 : 0.0064;
        const pitchScale = e.pointerType === 'touch' ? 0.006 : 0.0046;
        this.camYaw -= dx * yawScale;
        this.camPitch = THREE.MathUtils.clamp(this.camPitch + dy * pitchScale, 0.14, 1.05);
        this.lockCamManualOrbitActive = true;
        this.lockCamLastDragAt = performance.now();
      }
    }
  };

  private onPointerUp = (e: PointerEvent) => {
    if (e.pointerId !== this.cameraPointerId) return;
    const clickDist = Math.hypot(e.clientX - this.pointerDownX, e.clientY - this.pointerDownY);
    this.isDraggingCam = false;
    this.cameraPointerId = null;
    if (!this.isTitleMode && this.cameraConfig.povMode === 'lock' && clickDist >= 6) {
      this.lockCamLastDragAt = performance.now();
    }

    // Clickable 3D Signboards in front of NPC houses/shops -> open overhead Speech Bubble!
    if (!this.isTitleMode && !this.currentZone.startsWith('int_') && clickDist < 7 && this.outdoorRefs?.signboards.length) {
      const rect = this.renderer.domElement.getBoundingClientRect();
      _pointerNdc.x = ((e.clientX - rect.left) / Math.max(1, rect.width)) * 2 - 1;
      _pointerNdc.y = -((e.clientY - rect.top) / Math.max(1, rect.height)) * 2 + 1;
      _raycaster.setFromCamera(_pointerNdc, this.camera);
      const targets = this.outdoorRefs.signboards.map((s) => s.mesh);
      const hits = _raycaster.intersectObjects(targets, true);
      if (hits.length > 0) {
        const hitData = hits[0].object.userData as { signboardId?: string; signTitle?: string; signText?: string };
        if (hitData?.signboardId && hitData.signText) {
          soundEngine.playTalkBlip();
          this.callbacks.onReadSignboard?.(hitData.signboardId, hitData.signTitle || 'Papan Informasi', hitData.signText);
        }
      }
    }
  };

  private onWheel = (e: WheelEvent) => {
    if (this.isTitleMode || this.cameraConfig.povMode === 'lock') return;
    this.camZoomDist = THREE.MathUtils.clamp(
      this.camZoomDist + e.deltaY * 0.01,
      this.cameraConfig.minZoom,
      this.cameraConfig.maxZoom
    );
  };

  private bindEvents() {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
    window.addEventListener('resize', this.onResize);
    const dom = this.renderer.domElement;
    dom.style.touchAction = 'none';
    dom.style.userSelect = 'none';
    dom.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
    dom.addEventListener('wheel', this.onWheel, { passive: true });
  }

  public setCreationPreviewMode(enabled: boolean) {
    this.isCreationPreview = enabled;
    if (enabled && this.playerRig) {
      this.playerRig.root.position.set(FARMHOUSE_OUTDOOR_SPAWN.x, 0, FARMHOUSE_OUTDOOR_SPAWN.z);
      this.playerRig.root.rotation.y = 0.25;
      this.creationPreviewYaw = 0.25;
    }
  }

  public updateAvatar(avatar: AvatarConfig, equippedTool?: ToolKind) {
    this.pendingAvatarConfig = avatar;
    this.pendingToolKind = equippedTool;
    if (!this.assetsReady) return;

    const oldPos = this.playerRig ? this.playerRig.root.position.clone() : this.playerPos.clone();
    const oldYaw = this.playerRig ? this.playerRig.root.rotation.y : this.playerYaw;
    if (this.playerRig) {
      this.scene.remove(this.playerRig.root);
    }
    this.playerRig = createChibiCharacter({ avatarConfig: avatar, scale: 1.0 });
    this.playerRig.root.position.copy(oldPos);
    this.playerRig.root.rotation.y = oldYaw;
    if (this.activeHeldItemId) {
      const heldMesh = createHeldItemMesh(this.activeHeldItemId);
      if (heldMesh) this.playerRig.toolMount.add(heldMesh);
    } else if (equippedTool) {
      this.playerRig.toolMount.add(createToolMesh(equippedTool));
    }
    this.scene.add(this.playerRig.root);
  }

  public setEquippedTool(toolKind?: ToolKind) {
    this.pendingToolKind = toolKind;
    if (!this.playerRig) return;
    this.playerRig.toolMount.clear();
    if (toolKind) {
      this.playerRig.toolMount.add(createToolMesh(toolKind));
    } else if (this.activeHeldItemId) {
      const heldMesh = createHeldItemMesh(this.activeHeldItemId);
      if (heldMesh) this.playerRig.toolMount.add(heldMesh);
    }
  }

  public playWorkAnimation(style?: LocomotionInput['workStyle'], duration = 0.42) {
    const inferred: NonNullable<LocomotionInput['workStyle']> =
      style ||
      (this.activeHeldItemId === 'tool_watering_can'
        ? 'water'
        : this.activeHeldItemId === 'tool_hoe'
          ? 'dig'
          : this.activeHeldItemId === 'tool_sickle'
            ? 'sickle'
            : this.activeHeldItemId === 'tool_hammer'
              ? 'hammer'
              : this.activeHeldItemId === 'tool_fishing_rod'
                ? 'fish_cast'
                : 'chop');
    this.workStyle = inferred;
    this.workDuration = duration;
    this.workTimer = duration;
    this.playerAnim = 'work';
  }

  public syncFarmPlots(plots: Record<string, FarmPlotState>) {
    this.pendingPlots = plots;
    if (!this.assetsReady) return;

    const nextObstacleColliders: Array<{ x: number; z: number; radius: number; jumpable?: boolean; topY?: number }> = [];

    for (let gx = 0; gx < FARM_GRID_COLS; gx++) {
      for (let gz = 0; gz < FARM_GRID_ROWS; gz++) {
        const id = `${gx}_${gz}`;
        const state = plots[id];
        const worldX = FARM_ORIGIN_X + gx * FARM_TILE_STEP;
        const worldZ = FARM_ORIGIN_Z + gz * FARM_TILE_STEP;

        let tileGroup = this.plotMeshes.get(id);
        if (!tileGroup) {
          tileGroup = new THREE.Group();
          const soilMesh = new THREE.Mesh(this.soilSlabGeo, this.soilTilledMat);
          soilMesh.name = 'SoilMesh';
          soilMesh.position.y = 0.018;
          soilMesh.receiveShadow = true;
          soilMesh.visible = false;
          tileGroup.add(soilMesh);
          tileGroup.position.set(worldX, 0, worldZ);
          tileGroup.userData = { gx, gz };
          this.farmPlotsGroup.add(tileGroup);
          this.plotMeshes.set(id, tileGroup);
        }

        while (tileGroup.children.length > 1) {
          tileGroup.remove(tileGroup.children[1]);
        }

        // Seamless flat real-world plowed field: full-cell flush soil beds merge cleanly with zero grass gaps!
        const soilMesh = (tileGroup.getObjectByName('SoilMesh') || tileGroup.children[0]) as THREE.Mesh;
        if (!state || !state.tilled) {
          soilMesh.visible = false;
        } else {
          soilMesh.visible = true;
          soilMesh.material = state.watered ? this.soilWateredMat : this.soilTilledMat;
          soilMesh.rotation.y = 0;
        }

        const prevObs = this.prevPlotObstacles.get(id);
        this.prevPlotObstacles.set(id, state?.obstacle ?? undefined);

        if (state?.obstacle) {
          const obsMesh = createFarmObstacleMesh(state.obstacle);
          obsMesh.rotation.y = ((gx * 17 + gz * 31) % 12) * 0.5;
          // Off-camera unobserved respawn: freshly respawned weeds/rocks/trees wait until camera looks away!
          const isNewRespawn = !prevObs && state.obstacle !== 'stump' && this.prevPlotObstacles.size > 16;
          if (isNewRespawn && this.isPointInCameraFrustum(worldX, worldZ)) {
            obsMesh.visible = false;
            this.deferredRespawns.push({ obj: obsMesh, x: worldX, z: worldZ });
          }
          tileGroup.add(obsMesh);
          if (
            state.obstacle === 'stump' ||
            state.obstacle === 'sapling' ||
            state.obstacle === 'root' ||
            state.obstacle === 'tree' ||
            state.obstacle === 'large_tree' ||
            state.obstacle === 'rock' ||
            state.obstacle === 'large_rock'
          ) {
            const isStumpOrLow =
              state.obstacle === 'stump' ||
              state.obstacle === 'root' ||
              state.obstacle === 'rock' ||
              state.obstacle === 'large_rock';
            nextObstacleColliders.push({
              x: worldX,
              z: worldZ,
              radius:
                state.obstacle === 'large_tree' || state.obstacle === 'large_rock'
                  ? 0.68
                  : state.obstacle === 'tree' || state.obstacle === 'stump'
                    ? 0.54
                    : state.obstacle === 'sapling' || state.obstacle === 'root'
                      ? 0.44
                      : 0.5,
              jumpable: isStumpOrLow,
              topY:
                state.obstacle === 'large_rock'
                  ? 0.68
                  : state.obstacle === 'stump' || state.obstacle === 'rock'
                    ? 0.46
                    : state.obstacle === 'root'
                      ? 0.38
                      : undefined,
            });
          }
        } else if (state?.cropId) {
          const cropDef = CROPS[state.cropId];
          let stage: 0 | 1 | 2 | 3 = 0;
          if (state.readyToHarvest) stage = 3;
          else if (cropDef && state.growthDays >= Math.ceil(cropDef.daysToGrow * 0.66)) stage = 2;
          else if (state.growthDays >= 1) stage = 1;
          const cropMesh = createCropMesh(state.cropId, stage);
          cropMesh.position.y = 0.04;
          tileGroup.add(cropMesh);
        }
      }
    }

    this.farmObstacleColliders = nextObstacleColliders;
    this.farmPlotsGroup.visible = !this.currentZone.startsWith('int_');
  }

  public setLanguage(lang: Language) {
    this.language = lang;
    this.lastPromptKey = '';
  }

  public triggerAnimalInteractionFx(animalId: string) {
    const actor = this.animalActors.get(animalId);
    if (!actor) return;
    actor.interactBoostTimer = 6.5;
    actor.happiness = Math.min(100, actor.happiness + 18);
    actor.emotion = 'happy';
    this.spawnImpactVfx('sparkle', actor.pos.x, actor.pos.y + 0.95, actor.pos.z, 8);
  }

  private spawnAnimalFootprint(x: number, z: number, yaw: number, size: number, isSnow: boolean) {
    if (this.animalFootprints.length >= 42) {
      const oldest = this.animalFootprints.shift();
      if (oldest) {
        this.scene.remove(oldest.mesh);
        oldest.mesh.geometry.dispose();
        (oldest.mesh.material as THREE.Material).dispose();
      }
    }
    const mat = new THREE.MeshBasicMaterial({
      color: isSnow ? '#94a3b8' : '#5b3f24',
      transparent: true,
      opacity: 0.32,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -2,
      polygonOffsetUnits: -2,
    });
    const mesh = new THREE.Mesh(new THREE.CircleGeometry(Math.max(0.08, size), 7), mat);
    mesh.rotation.x = -Math.PI / 2;
    mesh.rotation.z = yaw;
    mesh.position.set(x, 0.026, z);
    this.scene.add(mesh);
    this.animalFootprints.push({ mesh, life: 9.0 });
  }

  public syncAnimals(
    animals: AnimalState[],
    barnLocked = this.barnLocked,
    coopLocked = this.coopLocked,
    stableLocked = this.stableLocked
  ) {
    this.cachedAnimals = animals;
    this.barnLocked = barnLocked;
    this.coopLocked = coopLocked;
    this.stableLocked = stableLocked;
    if (!this.assetsReady) return;

    const validIds = new Set(animals.map((a) => a.id));
    for (const [id, actor] of this.animalActors.entries()) {
      if (!validIds.has(id)) {
        this.animalsGroup.remove(actor.rig.root);
        this.animalActors.delete(id);
      }
    }

    const inBarn = this.currentZone === 'int_barn';
    const inCoop = this.currentZone === 'int_coop';
    const inStable = this.currentZone === 'int_stable';
    const inOutdoor = !this.currentZone.startsWith('int_');
    const isDayPleasant =
      this.currentHour >= 6 &&
      this.currentHour < 19 &&
      this.currentWeather !== 'Rainy' &&
      this.currentWeather !== 'Stormy';

    animals.forEach((a, idx) => {
      let actor = this.animalActors.get(a.id);
      const isBarnType = a.type === 'cow' || a.type === 'sheep';
      const isCoopType = a.type === 'chicken';
      const isDog = a.type === 'dog';
      const isHorse = a.type === 'horse';

      const livestockOutdoorNow =
        inOutdoor &&
        isDayPleasant &&
        !a.isSick &&
        ((isBarnType && !this.barnLocked) || (isCoopType && !this.coopLocked));

      const showHere =
        (inBarn && isBarnType) ||
        (inCoop && isCoopType) ||
        (inStable && isHorse) ||
        (inOutdoor && (isDog || isHorse || livestockOutdoorNow));

      let homeX = a.x;
      let homeZ = a.z;
      if (inBarn) {
        homeX = -4.2 + (idx % 4) * 2.6;
        homeZ = -1.6 + Math.floor(idx / 4) * 2.0;
      } else if (inCoop) {
        homeX = -3.0 + (idx % 3) * 2.8;
        homeZ = -1.2 + Math.floor(idx / 3) * 1.9;
      } else if (inStable) {
        homeX = idx % 2 === 0 ? -2.6 : 2.6;
        homeZ = -1.0 + Math.floor(idx / 2) * 1.9;
      } else if (inOutdoor && isDog) {
        homeX = DOG_FOOD_BOWL_POS.x + 0.5;
        homeZ = DOG_FOOD_BOWL_POS.z + 1.0;
      } else if (inOutdoor && isHorse) {
        homeX = HORSE_STABLE_POS.x + 1.2;
        homeZ = HORSE_STABLE_POS.z + 5.2;
      } else if (inOutdoor && isCoopType) {
        homeX = -144 + ((idx % 4) - 1.5) * 2.1;
        homeZ = -12.5 + Math.floor(idx / 4) * 2.0;
      } else if (inOutdoor && isBarnType) {
        homeX = -128 + ((idx % 4) - 1.5) * 2.8;
        homeZ = -12.2 + Math.floor(idx / 4) * 2.4;
      }

      if (!actor) {
        const rig = createLivingAnimalRig(a.type, a.id, a.breedVariant, a.sizeScale);
        rig.root.position.set(homeX, 0, homeZ);
        rig.root.visible = showHere;
        this.animalsGroup.add(rig.root);
        actor = {
          id: a.id,
          state: a,
          rig,
          pos: new THREE.Vector3(homeX, 0, homeZ),
          targetPos: new THREE.Vector3(homeX, 0, homeZ),
          homeX,
          homeZ,
          yaw: Math.random() * Math.PI * 2,
          targetYaw: 0,
          speed: 0,
          gaitPhase: idx * 1.7,
          phaseOffset: idx * 1.37,
          behavior: 'idle',
          behaviorTimer: 0.6 + (idx % 4) * 0.5,
          emotion: a.isSick ? 'sick' : a.emotion || 'relaxed',
          hunger: a.hunger ?? (a.fedToday ? 95 : 65),
          thirst: 75 + (idx % 3) * 8,
          energy: a.energy ?? 85,
          happiness: a.happiness ?? Math.round((a.affection / 255) * 100),
          health: a.health ?? (a.isSick ? 35 : 100),
          blinkTimer: 1.5 + Math.random() * 3.0,
          blinkAmount: 0,
          earAlertTimer: 0,
          emoteCooldown: 6 + idx * 3,
          interactBoostTimer: 0,
          stuckTimer: 0,
          socialPartnerId: null,
          footprintAccum: 0,
          blendWalk: 0,
          blendRun: 0,
          blendSit: 0,
          blendLie: 0,
          blendSleep: 0,
          blendGraze: 0,
          blendTailWag: 0.3,
          blendHeadPitch: 0,
          blendHeadYaw: 0,
        };
        this.animalActors.set(a.id, actor);
      } else {
        actor.state = a;
        actor.homeX = homeX;
        actor.homeZ = homeZ;
        const wasVisible = actor.rig.root.visible;
        actor.rig.root.visible = showHere;
        if (showHere && (!wasVisible || Math.hypot(actor.pos.x - homeX, actor.pos.z - homeZ) > 22)) {
          actor.pos.set(homeX, 0, homeZ);
          actor.targetPos.set(homeX, 0, homeZ);
          actor.rig.root.position.set(homeX, 0, homeZ);
        }
      }
    });

    this.animalsGroup.visible = inBarn || inCoop || inStable || inOutdoor;
  }

  public setWorldCondition(
    season: Season,
    weather: Weather,
    hour: number,
    day: number,
    spouseId: string | null,
    secretUnlocked: boolean
  ) {
    if (this.currentSeason !== season && this.outdoorRefs) {
      applySeasonToWorld(this.outdoorRefs, season);
    }
    const prevHour = this.currentHour;
    const prevWeather = this.currentWeather;
    this.currentSeason = season;
    this.currentWeather = weather;
    this.currentHour = hour;
    this.currentDay = day;
    this.spouseId = spouseId;
    this.secretUnlocked = secretUnlocked;

    const isNight = hour >= 19 || hour < 6;
    const isDawn = hour >= 5 && hour < 7;
    const isEvening = hour >= 17 && hour < 19;
    const isWet =
      weather === 'LightRain' || weather === 'Rainy' || weather === 'HeavyRain' || weather === 'Stormy';

    // Smooth, balanced sky & lighting targets (augmented every frame by SkyAtmosphereSystem!)
    const skyHex =
      this.currentZone === 'int_cave'
        ? '#111827'
        : weather === 'Stormy'
          ? '#2c3a4f'
          : weather === 'HeavyRain'
            ? '#475569'
            : weather === 'Rainy' || weather === 'LightRain'
              ? '#64748b'
              : weather === 'Foggy'
                ? '#cbd5e1'
                : weather === 'Cloudy'
                  ? isNight
                    ? '#1e293b'
                    : '#9aa8b8'
                  : season === 'Winter' && isNight
                    ? '#1e293b'
                    : isNight
                      ? '#151c3b'
                      : isEvening
                        ? '#d98a5b'
                        : isDawn
                          ? '#d9a79c'
                          : season === 'Winter'
                            ? '#bcc7d6'
                            : '#8dc4e4';

    this.targetSkyColor.set(skyHex);

    const rtActive = this.graphicsProfile.rayTracing || this.graphicsProfile.pathTracing;
    const sunScale = rtActive ? 0.78 : 0.88;
    const hemiScale = rtActive ? 0.76 : 0.84;

    this.targetSunIntensity =
      (this.currentZone === 'int_cave'
        ? 0.34
        : isNight
          ? 0.36
          : weather === 'Stormy'
            ? 0.42
            : weather === 'HeavyRain'
              ? 0.56
              : weather === 'Rainy' || weather === 'LightRain'
                ? 0.74
                : weather === 'Foggy'
                  ? 0.78
                  : weather === 'Cloudy'
                    ? 0.96
                    : isDawn || isEvening
                      ? 1.05
                      : 1.32) * sunScale;

    this.targetSunColor.set(
      isNight
        ? '#93c5fd'
        : weather === 'Stormy' || weather === 'HeavyRain'
          ? '#cbd5e1'
          : isEvening
            ? '#f5b87d'
            : isDawn
              ? '#f7d5b5'
              : '#f9edd0'
    );

    this.targetHemiIntensity =
      (this.currentZone === 'int_cave' ? 0.32 : isNight ? 0.4 : weather === 'Stormy' ? 0.52 : 0.7) * hemiScale;

    this.targetFogDensity =
      this.currentZone === 'int_cave'
        ? 0.018
        : this.currentZone.startsWith('int_')
          ? 0.0025
          : weather === 'Foggy'
            ? 0.0165
            : weather === 'Stormy'
              ? 0.0108
              : weather === 'HeavyRain'
                ? 0.0092
                : weather === 'Rainy' || weather === 'LightRain'
                  ? 0.0072
                  : weather === 'Snowy'
                    ? 0.0068
                    : weather === 'Cloudy'
                      ? 0.0056
                      : 0.0042;

    this.targetWindowEmissive = isNight || isEvening || isWet ? 0.95 : 0.16;

    // Gradual weather particle opacity transition across all 6+ weather states
    const pMat = this.weatherPoints.material as THREE.PointsMaterial;
    pMat.transparent = true;
    const showParticles =
      this.weatherFxEnabled &&
      !this.currentZone.startsWith('int_') &&
      (weather === 'Stormy' ||
        weather === 'HeavyRain' ||
        weather === 'Rainy' ||
        weather === 'LightRain' ||
        weather === 'Snowy' ||
        season === 'Winter' ||
        (weather === 'Sunny' && season === 'Spring'));

    if (showParticles) {
      this.weatherPoints.visible = true;
      if (weather === 'Stormy') {
        pMat.color.set('#d8e2ec');
        pMat.size = 0.22;
        this.targetWeatherOpacity = 0.74;
      } else if (weather === 'HeavyRain') {
        pMat.color.set('#bae6fd');
        pMat.size = 0.2;
        this.targetWeatherOpacity = 0.68;
      } else if (weather === 'Rainy') {
        pMat.color.set('#bae6fd');
        pMat.size = 0.17;
        this.targetWeatherOpacity = 0.56;
      } else if (weather === 'LightRain') {
        pMat.color.set('#e0f2fe');
        pMat.size = 0.13;
        this.targetWeatherOpacity = 0.36;
      } else if (weather === 'Snowy' || season === 'Winter') {
        pMat.color.set('#f1f5f9');
        pMat.size = 0.22;
        this.targetWeatherOpacity = 0.62;
      } else {
        pMat.color.set('#f5c6dc');
        pMat.size = 0.15;
        this.targetWeatherOpacity = 0.42;
      }
    } else {
      this.targetWeatherOpacity = 0;
    }

    if (prevHour !== hour || prevWeather !== weather) {
      this.syncAnimals(this.cachedAnimals);
    }

    const fest = FESTIVALS.find((f) => f.season === season && f.day === day);
    if (this.outdoorRefs) {
      this.outdoorRefs.festivalDecorGroup.visible = Boolean(fest);
    }
    for (const npc of NPCS) {
      const overrideSlots = this.npcScheduleOverrides[npc.id];
      const overrideMatch =
        Array.isArray(overrideSlots) && overrideSlots.length > 0
          ? overrideSlots.find((s) =>
              s.startHour <= s.endHour
                ? hour >= s.startHour && hour < s.endHour
                : hour >= s.startHour || hour < s.endHour
            ) || overrideSlots[0]
          : null;
      const slot =
        overrideMatch || getNpcRoutineSlot(npc, hour, isWet, Boolean(fest), fest?.locationZone, spouseId);
      const entry = this.npcRigs.get(npc.id);
      if (entry) {
        const zoneChanged = entry.zone !== slot.zone;
        entry.zone = slot.zone;
        entry.homeTargetPos.set(slot.x, 0, slot.z);
        if (zoneChanged || slot.activity === 'work' || slot.activity === 'sleep' || slot.activity === 'festival') {
          entry.targetPos.set(slot.x, 0, slot.z);
        }
        entry.activity = slot.activity;
      }
    }
    this.refreshVisibilityForZone();
  }

  public setFarmBuildingState(
    coopLevel: number,
    barnLevel: number,
    hasCheeseMaker: boolean,
    coopIncubators: EggIncubatorSlot[]
  ) {
    const changed =
      this.coopLevel !== coopLevel ||
      this.barnLevel !== barnLevel ||
      this.hasCheeseMaker !== hasCheeseMaker ||
      JSON.stringify(this.coopIncubators) !== JSON.stringify(coopIncubators);

    this.coopLevel = coopLevel;
    this.barnLevel = barnLevel;
    this.hasCheeseMaker = hasCheeseMaker;
    this.coopIncubators = coopIncubators.map((s) => ({ ...s }));

    if (changed && (this.currentZone === 'int_coop' || this.currentZone === 'int_barn')) {
      this.rebuildActiveInterior();
    }
  }

  private rebuildActiveInterior() {
    if (!this.currentZone.startsWith('int_')) return;
    if (this.interiorGroup) {
      this.scene.remove(this.interiorGroup);
    }
    const built = buildInteriorScene(this.currentZone, this.renderer.capabilities.getMaxAnisotropy(), {
      coopLevel: this.coopLevel,
      barnLevel: this.barnLevel,
      hasCheeseMaker: this.hasCheeseMaker,
      coopIncubators: this.coopIncubators,
    });
    this.interiorGroup = built.group;
    this.interiorInteractives = built.interactives;
    this.interiorColliders = built.colliders;
    this.interiorRoomBounds = { halfW: built.roomHalfW, halfD: built.roomHalfD };
    this.scene.add(this.interiorGroup);
    this.playerPos.x = THREE.MathUtils.clamp(this.playerPos.x, -(built.roomHalfW - 0.8), built.roomHalfW - 0.8);
    this.playerPos.z = THREE.MathUtils.clamp(this.playerPos.z, -(built.roomHalfD - 0.8), built.roomHalfD - 0.8);
    this.syncAnimals(this.cachedAnimals, this.barnLocked, this.coopLocked, this.stableLocked);
  }

  public applyServerNpcSync(states: Array<{ id: string; zone: WorldZoneId; x: number; z: number; activity: string }>) {
    for (const st of states) {
      const entry = this.npcRigs.get(st.id);
      if (entry && this.spouseId !== st.id) {
        entry.zone = st.zone;
        entry.targetPos.set(st.x, 0, st.z);
        entry.activity = st.activity;
      }
    }
    this.refreshVisibilityForZone();
  }

  public enterZone(zone: WorldZoneId, spawnX?: number, spawnZ?: number) {
    const prevZone = this.currentZone;
    this.currentZone = zone;
    this.jumpVelY = 0;

    if (this.interiorGroup) {
      this.scene.remove(this.interiorGroup);
      this.interiorGroup = null;
      this.interiorInteractives = [];
      this.interiorColliders = { boxes: [], circles: [] };
    }

    if (zone.startsWith('int_')) {
      if (this.outdoorRefs) this.outdoorRefs.group.visible = false;
      this.farmPlotsGroup.visible = false;
      this.weatherPoints.visible = false;
      const built = buildInteriorScene(zone, this.renderer.capabilities.getMaxAnisotropy(), {
        coopLevel: this.coopLevel,
        barnLevel: this.barnLevel,
        hasCheeseMaker: this.hasCheeseMaker,
        coopIncubators: this.coopIncubators,
      });
      this.interiorGroup = built.group;
      this.interiorInteractives = built.interactives;
      this.interiorColliders = built.colliders;
      this.interiorRoomBounds = { halfW: built.roomHalfW, halfD: built.roomHalfD };
      if (zone === 'int_cave') {
        this.caveDugTiles.clear();
        while (this.caveDugGroup.children.length > 0) {
          this.caveDugGroup.remove(this.caveDugGroup.children[0]);
        }
        this.interiorGroup.add(this.caveDugGroup);
      }
      this.scene.add(this.interiorGroup);
      this.playerPos.set(spawnX ?? 0, 0, spawnZ ?? Math.max(1.5, built.roomHalfD - 1.6));
      this.playerYaw = Math.PI;
      this.camYaw = Math.PI;
      this.smoothCamDist = Math.min(this.camZoomDist, Math.min(built.roomHalfD * 1.15, 7.6));
    } else {
      if (this.outdoorRefs) this.outdoorRefs.group.visible = true;
      this.farmPlotsGroup.visible = true;
      if (spawnX !== undefined && spawnZ !== undefined) {
        this.playerPos.set(spawnX, 0, spawnZ);
      } else if (prevZone.startsWith('int_')) {
        const portal = BUILDING_PORTALS.find((p) => p.interiorZone === prevZone);
        if (portal) {
          this.playerPos.set(portal.exitSpawnX, 0, portal.exitSpawnZ);
          // Position character outward from building door; in Lock POV stay behind character facing direction
          if (portal.facing === 'south') {
            this.playerYaw = 0;
            this.camYaw = this.cameraConfig.povMode === 'lock' ? this.playerYaw : Math.PI;
          } else if (portal.facing === 'north') {
            this.playerYaw = Math.PI;
            this.camYaw = this.cameraConfig.povMode === 'lock' ? this.playerYaw : 0;
          } else if (portal.facing === 'east') {
            this.playerYaw = Math.PI / 2;
            this.camYaw = this.cameraConfig.povMode === 'lock' ? this.playerYaw : -Math.PI / 2;
          } else {
            this.playerYaw = -Math.PI / 2;
            this.camYaw = this.cameraConfig.povMode === 'lock' ? this.playerYaw : Math.PI / 2;
          }
          this.camPitch = Math.max(0.46, Math.min(0.62, this.camPitch));
          this.smoothCamDist = this.camZoomDist;
        }
      }
      this.lastZoneDetected = zone;
    }

    if (this.playerRig) {
      this.playerRig.root.position.copy(this.playerPos);
      this.playerRig.root.rotation.y = this.playerYaw;
    }

    // Snap camera immediately to the new unobstructed vantage point so it never sweeps through walls on door exit
    const snapDist = zone.startsWith('int_')
      ? Math.min(this.camZoomDist, Math.min(this.interiorRoomBounds.halfD * 1.15, 7.6))
      : this.camZoomDist;
    const snapHoriz = Math.cos(this.camPitch) * snapDist;
    const snapVert = Math.sin(this.camPitch) * snapDist + 1.4;
    let snapX = this.playerPos.x - Math.sin(this.camYaw) * snapHoriz;
    let snapZ = this.playerPos.z - Math.cos(this.camYaw) * snapHoriz;
    if (zone.startsWith('int_')) {
      snapX = THREE.MathUtils.clamp(snapX, -(this.interiorRoomBounds.halfW - 0.65), this.interiorRoomBounds.halfW - 0.65);
      snapZ = THREE.MathUtils.clamp(snapZ, -(this.interiorRoomBounds.halfD - 0.65), this.interiorRoomBounds.halfD - 0.65);
    }
    this.camera.position.set(snapX, Math.max(2.2, snapVert), snapZ);
    this.camera.lookAt(this.playerPos.x, 1.15, this.playerPos.z);

    this.setWorldCondition(this.currentSeason, this.currentWeather, this.currentHour, this.currentDay, this.spouseId, this.secretUnlocked);
    this.syncAnimals(this.cachedAnimals, this.barnLocked, this.coopLocked, this.stableLocked);
    this.refreshVisibilityForZone();
  }

  private refreshVisibilityForZone() {
    const inInterior = this.currentZone.startsWith('int_');
    for (const entry of this.npcRigs.values()) {
      if (inInterior) {
        entry.rig.root.visible = entry.zone === this.currentZone;
      } else {
        entry.rig.root.visible = !entry.zone.startsWith('int_');
      }
    }
  }

  public syncRemotePlayers(peers: OnlinePlayerState[]) {
    const activeIds = new Set(peers.map((p) => p.clientId));
    for (const [cid, entry] of this.remoteRigs.entries()) {
      if (!activeIds.has(cid)) {
        this.scene.remove(entry.rig.root);
        this.remoteRigs.delete(cid);
      }
    }
    for (const p of peers) {
      this.addOrUpdateRemotePlayer(p);
    }
  }

  public addOrUpdateRemotePlayer(p: OnlinePlayerState) {
    if (!this.assetsReady) return;
    let entry = this.remoteRigs.get(p.clientId);
    if (!entry) {
      const rig = createChibiCharacter({ avatarConfig: p.avatarConfig, scale: 1.0 });
      const pos = new THREE.Vector3(p.x, p.y, p.z);
      rig.root.position.copy(pos);
      this.scene.add(rig.root);
      rig.root.scale.setScalar(0.82);
      entry = { rig, player: p, pos, targetPos: pos.clone(), yaw: p.yaw, fadeIn: 0 };
      this.remoteRigs.set(p.clientId, entry);
    } else {
      entry.player = p;
      entry.targetPos.set(p.x, p.y, p.z);
      entry.yaw = p.yaw;
    }
  }

  public moveRemotePlayer(
    clientId: string,
    x: number,
    y: number,
    z: number,
    yaw: number,
    animState: OnlinePlayerState['animState']
  ) {
    const entry = this.remoteRigs.get(clientId);
    if (!entry) return;
    entry.targetPos.set(x, y, z);
    entry.yaw = yaw;
    entry.player.animState = animState;
  }

  public removeRemotePlayer(clientId: string) {
    const entry = this.remoteRigs.get(clientId);
    if (!entry) return;
    this.scene.remove(entry.rig.root);
    this.remoteRigs.delete(clientId);
  }

  private resolveCollisions(x: number, z: number, playerY = this.playerPos.y): { x: number; z: number } {
    const playerRadius = 0.44;
    let rx = x;
    let rz = z;

    if (this.currentZone.startsWith('int_')) {
      const limX = Math.max(2.5, this.interiorRoomBounds.halfW - 0.72);
      const limZ = Math.max(2.5, this.interiorRoomBounds.halfD - 0.72);
      rx = THREE.MathUtils.clamp(rx, -limX, limX);
      rz = THREE.MathUtils.clamp(rz, -limZ, limZ);
    } else {
      // River Dock (z: 14.2..17.8, x <= 44.8) & Ocean Pier (z: -9.8..-6.2, x <= 56.2) vs Sandy Shoreline (x <= 47.4)
      const onOceanPier = rz >= -9.8 && rz <= -6.2;
      const onRiverDock = rz >= 14.2 && rz <= 17.8;
      const maxEastX = onOceanPier ? 56.2 : onRiverDock ? 44.8 : 47.4;
      rx = THREE.MathUtils.clamp(rx, -185, maxEastX);
      rz = THREE.MathUtils.clamp(rz, -69, 60);
    }

    const activeColliders = this.currentZone.startsWith('int_')
      ? this.interiorColliders
      : this.outdoorRefs?.colliders;

    // 3-pass slide + depenetration stuck-prevention solver with step-height tolerance
    for (let pass = 0; pass < 3; pass++) {
      if (activeColliders) {
        const outdoor = !this.currentZone.startsWith('int_');
        for (const box of activeColliders.boxes) {
          // Strict 3D solid collision on ground; jumpable small props (benches, crates, stage, fences) are clearable & standable once jumped onto!
          const clearanceY = typeof box.topY === 'number' ? box.topY - 0.24 : (box.stepHeight ?? 0.42);
          if (outdoor && box.jumpable === true && playerY >= clearanceY) continue;
          const cx = THREE.MathUtils.clamp(rx, box.minX, box.maxX);
          const cz = THREE.MathUtils.clamp(rz, box.minZ, box.maxZ);
          const dx = rx - cx;
          const dz = rz - cz;
          const distSq = dx * dx + dz * dz;
          if (distSq < playerRadius * playerRadius) {
            // Corner Cutting: if jumping and barely clipping the top rim of a jumpable ledge, smoothly step up onto it!
            if (
              outdoor &&
              box.jumpable === true &&
              typeof box.topY === 'number' &&
              playerY >= box.topY - 0.36 &&
              playerY < box.topY &&
              this.jumpVelY >= -3.2
            ) {
              this.cornerCutLiftY = Math.max(this.cornerCutLiftY, box.topY + 0.02);
              continue;
            }
            if (distSq > 1e-6) {
              const dist = Math.sqrt(distSq);
              const push = playerRadius - dist;
              rx += (dx / dist) * push;
              rz += (dz / dist) * push;
            } else {
              const dLeft = Math.abs(rx - box.minX);
              const dRight = Math.abs(box.maxX - rx);
              const dTop = Math.abs(rz - box.minZ);
              const dBot = Math.abs(box.maxZ - rz);
              const m = Math.min(dLeft, dRight, dTop, dBot);
              if (m === dLeft) rx = box.minX - playerRadius;
              else if (m === dRight) rx = box.maxX + playerRadius;
              else if (m === dTop) rz = box.minZ - playerRadius;
              else rz = box.maxZ + playerRadius;
            }
          }
        }

        for (const c of activeColliders.circles) {
          // Solid on ground; jumpable logs/low rocks can be climbed when player jumps above their top edge
          if (outdoor && c.jumpable === true && typeof c.topY === 'number' && playerY >= c.topY - 0.24) continue;
          const dx = rx - c.x;
          const dz = rz - c.z;
          const minDist = c.radius + playerRadius;
          const distSq = dx * dx + dz * dz;
          if (distSq < minDist * minDist && distSq > 1e-6) {
            const dist = Math.sqrt(distSq);
            const push = minDist - dist;
            rx += (dx / dist) * push;
            rz += (dz / dist) * push;
          }
        }
      }

      // All Outdoor 3D Trees & Stumps (both User Farm Trees and Protected Global Trees) are strictly solid on ground!
      // Stumps can be jumped onto (topY = 0.46) while remaining completely impassable on the ground.
      if (!this.currentZone.startsWith('int_') && this.outdoorRefs) {
        for (const tree of this.outdoorRefs.choppableTrees) {
          if (tree.chopped) continue;
          if (tree.isStump && typeof tree.topY === 'number' && playerY >= tree.topY - 0.24) continue;
          const dx = rx - tree.x;
          const dz = rz - tree.z;
          const minDist = tree.radius + playerRadius;
          const distSq = dx * dx + dz * dz;
          if (distSq < minDist * minDist && distSq > 1e-6) {
            const dist = Math.sqrt(distSq);
            const push = minDist - dist;
            rx += (dx / dist) * push;
            rz += (dz / dist) * push;
          }
        }

        // Farm plot obstacles (trees, saplings, stumps, roots, boulders) are strictly solid on ground; stumps/rocks jumpable!
        for (const obs of this.farmObstacleColliders) {
          if (obs.jumpable && typeof obs.topY === 'number' && playerY >= obs.topY - 0.24) continue;
          const dx = rx - obs.x;
          const dz = rz - obs.z;
          const minDist = obs.radius + playerRadius;
          const distSq = dx * dx + dz * dz;
          if (distSq < minDist * minDist && distSq > 1e-6) {
            const dist = Math.sqrt(distSq);
            const push = minDist - dist;
            rx += (dx / dist) * push;
            rz += (dz / dist) * push;
          }
        }
      }

      // Collide softly against visible NPCs
      for (const npc of this.npcRigs.values()) {
        if (!npc.rig.root.visible) continue;
        const dx = rx - npc.pos.x;
        const dz = rz - npc.pos.z;
        const minDist = 0.85;
        const d2 = dx * dx + dz * dz;
        if (d2 < minDist * minDist && d2 > 1e-6) {
          const dist = Math.sqrt(d2);
          const push = minDist - dist;
          rx += (dx / dist) * push;
          rz += (dz / dist) * push;
        }
      }

      // Collide softly against visible Animals (matching species traversal radius)
      if (this.animalsGroup.visible) {
        for (const actor of this.animalActors.values()) {
          if (!actor.rig.root.visible) continue;
          const dx = rx - actor.pos.x;
          const dz = rz - actor.pos.z;
          const minDist = getAnimalRadius(actor.state.type) + playerRadius * 0.85;
          const d2 = dx * dx + dz * dz;
          if (d2 < minDist * minDist && d2 > 1e-6) {
            const dist = Math.sqrt(d2);
            const push = minDist - dist;
            rx += (dx / dist) * push;
            rz += (dz / dist) * push;
          }
        }
      }

      // Collide softly against Remote Players
      for (const peer of this.remoteRigs.values()) {
        const dx = rx - peer.pos.x;
        const dz = rz - peer.pos.z;
        const minDist = 0.85;
        const d2 = dx * dx + dz * dz;
        if (d2 < minDist * minDist && d2 > 1e-6) {
          const dist = Math.sqrt(d2);
          const push = minDist - dist;
          rx += (dx / dist) * push;
          rz += (dz / dist) * push;
        }
      }
    }

    return { x: rx, z: rz };
  }

  private localizeWorldPromptLabel(raw: string): string {
    const clean = raw.replace(/\s*\[[EF]\]$/i, '');
    if (this.language !== 'id') return clean;
    const map: Record<string, string> = {
      'Shipping Bin — Sell Harvest': 'Kotak Kirim — Jual Panen',
      'Dog Food Bowl — Feed Dog': 'Mangkuk Anjing — Beri Makan',
      'Water Well — Refill Watering Can': 'Sumur Air — Isi Penyiram',
      'Bed — Sleep & Save Until Morning': 'Kasur — Tidur & Simpan Sampai Pagi',
      'Journal Desk — Save Progress': 'Meja Jurnal — Simpan Progres',
      'Kitchen Counter — Cook Meal': 'Meja Dapur — Masak Makanan',
      'Wardrobe — Change Outfit': 'Lemari — Ganti Kostum',
      'Farm Notice Board': 'Papan Pengumuman Peternakan',
      'Barn Feed Trough — Fill Hay': 'Palung Jerami — Isi Pakan Ternak',
      'Coop Feed Trough — Fill Feed': 'Palung Ayam — Isi Pakan Ayam',
      'Egg Incubator — Hatch Chick': 'Inkubator Telur — Tetaskan Anak Ayam',
      'Stable Hay Trough — Feed Horse': 'Palung Kuda — Beri Jerami Kuda',
      'Mine Ore Vein (Hammer)': 'Tambang Bijih (Palu)',
      'Exit Outside': 'Keluar ke Luar Ruangan',
      'Enter Farm House': 'Masuk Rumah Peternakan',
      'Enter Barn': 'Masuk Kandang Sapi & Domba',
      'Enter Chicken Coop': 'Masuk Kandang Ayam',
      'Enter Horse Stable': 'Masuk Kandang Kuda',
      'Enter Whispering Mountain Cave': 'Masuk Goa Gunung Berbisik',
      'Enter General Store': 'Masuk Toko Umum',
      'Enter Blacksmith': 'Masuk Pandai Besi',
      'Enter Ranch Shop': 'Masuk Peternakan Felix',
      'Enter Valley Clinic': 'Masuk Klinik Lembah',
      'Enter Town Inn & Tavern': 'Masuk Penginapan & Kedai',
      'Enter Carpenter Workshop': 'Masuk Bengkel Tukang Kayu',
      'Enter Church': 'Masuk Gereja Lembah',
      'Enter Town Hall': 'Masuk Balai Kota',
      'River Fishing Dock': 'Dermaga Mancing Sungai',
      'Ocean Pier Fishing': 'Dermaga Mancing Pantai',
      'Harvest Wild Forage': 'Ambil Hasil Hutan',
    };
    if (map[clean]) return map[clean];
    if (clean.startsWith('Enter ')) return `Masuk ${clean.slice(6)}`;
    if (clean.startsWith('Exit ')) return `Keluar ${clean.slice(5)}`;
    if (clean.startsWith('Mine ')) return `Tambang ${clean.slice(5)}`;
    if (clean.startsWith('Fish ')) return `Mancing ${clean.slice(5)}`;
    return clean;
  }

  public getNearestPrompt(): NearbyPrompt | null {
    const prompt: NearbyPrompt = {};
    const isId = this.language === 'id';

    // 1. Social Key (E): Nearby Remote Player (Private Chat + Marriage) OR NPC (Talk/Gift/Quest)
    let bestPeerDist = 2.6;
    let bestPeer: OnlinePlayerState | null = null;
    for (const entry of this.remoteRigs.values()) {
      const dist = Math.hypot(entry.pos.x - this.playerPos.x, entry.pos.z - this.playerPos.z);
      if (dist <= bestPeerDist) {
        bestPeerDist = dist;
        bestPeer = entry.player;
      }
    }

    let bestNpcDist = 2.3;
    let bestNpcId: string | null = null;
    for (const [npcId, entry] of this.npcRigs.entries()) {
      if (!entry.rig.root.visible) continue;
      const dist = Math.hypot(entry.pos.x - this.playerPos.x, entry.pos.z - this.playerPos.z);
      if (dist <= bestNpcDist) {
        bestNpcDist = dist;
        bestNpcId = npcId;
      }
    }

    if (bestPeer && (!bestNpcId || bestPeerDist <= bestNpcDist)) {
      prompt.social = {
        kind: 'remote_player',
        id: bestPeer.uid,
        label: isId
          ? `Chat Pribadi / Lamar: ${bestPeer.avatarName}`
          : `Private Chat / Propose: ${bestPeer.avatarName}`,
        player: bestPeer,
      };
    } else if (bestNpcId) {
      const npc = NPCS.find((n) => n.id === bestNpcId);
      prompt.social = {
        kind: 'npc',
        id: bestNpcId,
        label: isId ? `Bicara dengan ${npc?.name || bestNpcId}` : `Talk to ${npc?.name || bestNpcId}`,
      };
    } else if (!this.currentZone.startsWith('int_') && this.outdoorRefs) {
      for (const sb of this.outdoorRefs.signboards) {
        const dist = Math.hypot(sb.x - this.playerPos.x, sb.z - this.playerPos.z);
        if (dist <= 2.45) {
          prompt.social = {
            kind: 'signboard',
            id: sb.id,
            label: isId ? `Baca Papan: ${sb.title}` : `Read Sign: ${sb.title}`,
            signTitle: sb.title,
            signText: sb.text,
          };
          break;
        }
      }
    }

    // 2. Execute Key (F): NPC Shop/Service, World Interactives, Animals, Farm Plot, or Wild Trees
    if (bestNpcId) {
      const npc = NPCS.find((n) => n.id === bestNpcId);
      if (npc?.shopInventoryIds?.length || npc?.specialService) {
        prompt.execute = {
          kind: 'npc_shop',
          id: bestNpcId,
          label: isId ? `Belanja / Layanan: ${npc.name}` : `Shop / Service: ${npc.name}`,
        };
      }
    }

    if (!prompt.execute) {
      const list = this.currentZone.startsWith('int_')
        ? this.interiorInteractives
        : this.outdoorRefs?.interactives || [];
      for (const node of list) {
        if (node.kind === 'signboard') continue;
        const dist = Math.hypot(node.x - this.playerPos.x, node.z - this.playerPos.z);
        if (dist <= node.radius) {
          prompt.execute = {
            kind: 'world',
            id: node.id,
            label: this.localizeWorldPromptLabel(node.label),
            worldKind: node.kind,
            targetZone: node.targetZone,
            portalId: node.portalId,
            spotType: node.spotType,
          };
          break;
        }
      }
    }

    if (!prompt.execute && this.animalsGroup.visible) {
      let bestAnimalDist = 2.25;
      let bestAnimal: { id: string; state: AnimalState } | null = null;
      for (const [animalId, entry] of this.animalActors.entries()) {
        if (!entry.rig.root.visible) continue;
        const dist = Math.hypot(entry.pos.x - this.playerPos.x, entry.pos.z - this.playerPos.z);
        if (dist <= bestAnimalDist) {
          bestAnimalDist = dist;
          bestAnimal = { id: animalId, state: entry.state };
        }
      }
      if (bestAnimal) {
        const sickTag = bestAnimal.state.isSick ? (isId ? ' (SAKIT! Beri Obat)' : ' (SICK! Give Medicine)') : '';
        prompt.execute = {
          kind: 'animal',
          id: bestAnimal.id,
          label: isId
            ? `Rawat / Beri Makan ${bestAnimal.state.name}${sickTag}`
            : `Care / Feed ${bestAnimal.state.name}${sickTag}`,
        };
      }
    }

    if (!prompt.execute && this.currentZone === 'farm_home') {
      const targetX = this.playerPos.x + Math.sin(this.playerYaw) * 0.95;
      const targetZ = this.playerPos.z + Math.cos(this.playerYaw) * 0.95;
      const gx = Math.round((targetX - FARM_ORIGIN_X) / FARM_TILE_STEP);
      const gz = Math.round((targetZ - FARM_ORIGIN_Z) / FARM_TILE_STEP);
      if (gx >= 0 && gx < FARM_GRID_COLS && gz >= 0 && gz < FARM_GRID_ROWS) {
        const tileCenterX = FARM_ORIGIN_X + gx * FARM_TILE_STEP;
        const tileCenterZ = FARM_ORIGIN_Z + gz * FARM_TILE_STEP;
        if (Math.hypot(tileCenterX - this.playerPos.x, tileCenterZ - this.playerPos.z) <= 1.65) {
          prompt.execute = {
            kind: 'plot',
            id: `${gx}_${gz}`,
            label: isId ? `Petak Kebun (${gx + 1}, ${gz + 1})` : `Farm Tile (${gx + 1}, ${gz + 1})`,
          };
        }
      }
    }

    if (!prompt.execute && !this.currentZone.startsWith('int_') && this.outdoorRefs) {
      let bestTreeDist = 2.05;
      let bestTree: { id: string; scope: 'global' | 'farm'; level: 1 | 2 | 3 | 4; isStump: boolean } | null = null;
      for (const tree of this.outdoorRefs.choppableTrees) {
        if (tree.chopped) continue;
        const dist = Math.hypot(tree.x - this.playerPos.x, tree.z - this.playerPos.z);
        if (dist <= bestTreeDist) {
          bestTreeDist = dist;
          bestTree = { id: tree.id, scope: tree.scope, level: tree.level ?? 3, isStump: Boolean(tree.isStump) };
        }
      }
      if (bestTree) {
        prompt.execute = {
          kind: 'chop_tree',
          id: bestTree.id,
          treeScope: bestTree.scope,
          treeLevel: bestTree.level,
          isStump: bestTree.isStump,
          label:
            bestTree.scope === 'global'
              ? isId
                ? 'Pohon Lembah Dilindungi (Khusus Orin)'
                : 'Protected Valley Tree (Carpenter Orin Only)'
              : bestTree.isStump
                ? isId
                  ? 'Tebang Tunggul Pohon (Kapak)'
                  : 'Chop Tree Stump (Axe)'
                : isId
                  ? `Tebang Pohon Kebun Lv.${bestTree.level} (Kapak${bestTree.level >= 4 ? ' Lv.2+' : ''})`
                  : `Chop Farm Tree Lv.${bestTree.level} (Axe${bestTree.level >= 4 ? ' Lv.2+' : ''})`,
        };
      }
    }

    if (!prompt.execute && this.activeHeldItemId === 'tool_fishing_rod' && !this.currentZone.startsWith('int_')) {
      const waterSpot = this.detectWaterAheadAtOneTile();
      if (waterSpot) {
        prompt.execute = {
          kind: 'cast_water',
          id: `water_${waterSpot}`,
          spotType: waterSpot,
          label: isId
            ? waterSpot === 'ocean'
              ? 'Lempar Pancing — Laut'
              : 'Lempar Pancing — Sungai'
            : waterSpot === 'ocean'
              ? 'Cast Fishing Rod — Ocean'
              : 'Cast Fishing Rod — River',
        };
      }
    }

    if (!prompt.execute && this.currentZone === 'int_cave') {
      const digX = this.playerPos.x + Math.sin(this.playerYaw) * 1.05;
      const digZ = this.playerPos.z + Math.cos(this.playerYaw) * 1.05;
      if (
        Math.abs(digX) <= this.interiorRoomBounds.halfW - 1.1 &&
        digZ >= -(this.interiorRoomBounds.halfD - 1.1) &&
        digZ <= this.interiorRoomBounds.halfD - 2.2
      ) {
        const gx = Math.round(digX / 1.6);
        const gz = Math.round(digZ / 1.6);
        prompt.execute = {
          kind: 'cave_dig',
          id: `${gx}_${gz}`,
          label: isId
            ? this.activeHeldItemId === 'tool_hoe'
              ? 'Gali Kerikil Goa (Cangkul)'
              : 'Gunakan Cangkul untuk Gali Kerikil Goa'
            : this.activeHeldItemId === 'tool_hoe'
              ? 'Dig Cave Gravel (Hoe)'
              : 'Equip Hoe to Dig Cave Gravel',
        };
      }
    }

    if (!prompt.social && !prompt.execute) return null;
    return prompt;
  }

  public triggerContextualAction(mode: 'social' | 'execute') {
    const prompt = this.getNearestPrompt();
    if (!prompt) return;

    if (mode === 'social') {
      if (prompt.social?.kind === 'remote_player' && prompt.social.player) {
        soundEngine.playTalkBlip();
        this.callbacks.onPrivateChatPlayer(prompt.social.player);
        return;
      }
      if (prompt.social?.kind === 'npc') {
        soundEngine.playTalkBlip();
        this.callbacks.onInteractNpc(prompt.social.id, 'talk');
        return;
      }
      if (prompt.social?.kind === 'signboard' && prompt.social.signText) {
        soundEngine.playTalkBlip();
        this.callbacks.onReadSignboard?.(
          prompt.social.id,
          prompt.social.signTitle || 'Papan Informasi',
          prompt.social.signText
        );
        return;
      }
      return;
    }

    const ex = prompt.execute;
    if (!ex) return;

    if (ex.kind === 'npc_shop') {
      soundEngine.playUiClick();
      this.callbacks.onInteractNpc(ex.id, 'shop');
    } else if (ex.kind === 'plot') {
      const [gx, gz] = ex.id.split('_').map(Number);
      this.callbacks.onInteractPlot(gx, gz);
    } else if (ex.kind === 'animal') {
      this.callbacks.onInteractAnimal(ex.id);
    } else if (ex.kind === 'chop_tree') {
      this.callbacks.onChopTree?.(ex.id, ex.treeScope ?? 'farm', ex.treeLevel ?? 3, ex.isStump);
    } else if (ex.kind === 'cast_water') {
      this.callbacks.onCastFishingWater?.(ex.spotType ?? 'river');
    } else if (ex.kind === 'cave_dig') {
      const [gx, gz] = ex.id.split('_').map(Number);
      this.callbacks.onDigCaveTile?.(gx, gz);
    } else if (ex.kind === 'world') {
      const list = this.currentZone.startsWith('int_')
        ? this.interiorInteractives
        : this.outdoorRefs?.interactives || [];
      const node = list.find((n) => n.id === ex.id);
      if (node) this.callbacks.onInteractWorld(node);
    }
  }

  public captureScreenshotDataUrl(): string {
    this.renderer.render(this.scene, this.camera);
    return this.renderer.domElement.toDataURL('image/png');
  }

  private pollGamepad(): { ix: number; iz: number; sprint: boolean } {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    const gp = pads?.[0] || null;
    const isNowConnected = Boolean(gp);
    if (isNowConnected !== this.gamepadConnected) {
      this.gamepadConnected = isNowConnected;
      this.callbacks.onGamepadChange?.(isNowConnected, gp?.id);
    }
    if (!gp) return { ix: 0, iz: 0, sprint: false };

    const deadzone = 0.2;
    const ax0 = Math.abs(gp.axes[0] || 0) > deadzone ? gp.axes[0] : 0;
    const ax1 = Math.abs(gp.axes[1] || 0) > deadzone ? gp.axes[1] : 0;
    const rx = Math.abs(gp.axes[2] || 0) > deadzone ? gp.axes[2] : 0;
    const ry = Math.abs(gp.axes[3] || 0) > deadzone ? gp.axes[3] : 0;

    if (!this.isTitleMode && (rx !== 0 || ry !== 0)) {
      this.camYaw -= rx * 0.042;
      this.camPitch = THREE.MathUtils.clamp(this.camPitch + ry * 0.03, 0.25, 1.05);
    }

    const pressed = gp.buttons.map((b) => b.pressed);
    const justPressed = (idx: number) => pressed[idx] && !this.prevGamepadButtons[idx];
    if (!this.isTitleMode) {
      if (justPressed(0)) this.triggerJump(); // A / Cross -> Jump
      if (justPressed(2)) this.triggerContextualAction('execute'); // X / Square -> Action (F)
      if (justPressed(3)) this.triggerContextualAction('social'); // Y / Triangle -> Talk (E)
      if (justPressed(1)) this.callbacks.onToggleInventory?.(); // B / Circle -> Bag
    }
    this.prevGamepadButtons = pressed;

    return {
      ix: ax0,
      iz: ax1,
      sprint: Boolean(pressed[4] || pressed[5]),
    };
  }

  private tick = () => {
    if (this.disposed) return;
    const rawDt = this.clock.getDelta();
    const dt = Math.min(rawDt, 0.05);
    const elapsed = this.clock.elapsedTime;

    if (this.outdoorRefs) {
      this.outdoorRefs.grassUniformTime.value = elapsed;
      this.outdoorRefs.waterMesh.position.y = 0.04 + Math.sin(elapsed * 2) * 0.014;
      this.outdoorRefs.brookMesh.position.y = 0.04 + Math.sin(elapsed * 2 + 1) * 0.012;
      this.outdoorRefs.waterTex.offset.y = (elapsed * 0.05) % 1;

      if (this.outdoorRefs.beePoints.visible) {
        const attr = this.outdoorRefs.beePoints.geometry.attributes.position as THREE.BufferAttribute;
        const arr = attr.array as Float32Array;
        const count = arr.length / 3;
        for (let i = 0; i < count; i++) {
          const a = elapsed * (1.8 + (i % 3) * 0.4) + i * 0.9;
          arr[i * 3] = APPLE_TREE_POS.x + 1.15 + Math.cos(a) * (0.55 + (i % 3) * 0.18);
          arr[i * 3 + 1] = 1.9 + Math.sin(elapsed * 3.5 + i) * 0.28;
          arr[i * 3 + 2] = APPLE_TREE_POS.z + 0.8 + Math.sin(a) * (0.55 + (i % 3) * 0.18);
        }
        attr.needsUpdate = true;
      }
    }

    if (this.weatherPoints.visible) {
      const isStorm = this.currentWeather === 'Stormy';
      const isHeavyRain = this.currentWeather === 'HeavyRain';
      const isRain = this.currentWeather === 'Rainy';
      const isLightRain = this.currentWeather === 'LightRain';
      const speedY = isStorm ? 25 : isHeavyRain ? 21 : isRain ? 16 : isLightRain ? 11.5 : 2.5;
      const driftX = isStorm ? -6.0 : isHeavyRain ? -2.2 : isRain || isLightRain ? -0.6 : Math.sin(elapsed) * 0.6;
      const arr = this.weatherPositions;
      for (let i = 0; i < arr.length; i += 3) {
        arr[i] += driftX * dt;
        arr[i + 1] -= speedY * dt;
        if (arr[i + 1] < 0) {
          arr[i] = this.playerPos.x + (Math.random() - 0.5) * 44;
          arr[i + 1] = 15 + Math.random() * 4;
          arr[i + 2] = this.playerPos.z + (Math.random() - 0.5) * 44;
        }
      }
      this.weatherPoints.geometry.attributes.position.needsUpdate = true;
      // Subtle lightning flash during Stormy weather outdoors
      if (isStorm && !this.currentZone.startsWith('int_')) {
        const flashPulse = Math.sin(elapsed * 1.9) * Math.sin(elapsed * 7.3) * Math.sin(elapsed * 13.1);
        this.sunLight.intensity = flashPulse > 0.94 ? 2.4 : this.targetSunIntensity;
      }
    }

    // Update Dynamic Sky Dome, Drifting 3D Clouds, Twinkling Stars & Moon Phases
    const skyOut = this.skySystem.update({
      hourFloat: this.currentHour,
      day: this.currentDay,
      season: this.currentSeason,
      weather: this.currentWeather,
      isIndoor: this.currentZone.startsWith('int_'),
      elapsedSec: elapsed,
      dt,
      anchorPos: this.isTitleMode ? this.camera.position : this.playerPos,
      camera: this.camera,
    });
    if (!this.currentZone.startsWith('int_')) {
      this.targetSkyColor.copy(skyOut.fogColor);
      this.targetSunColor.copy(skyOut.sunColor);
    }

    // Update 3D Sprint Dust Particles
    for (const p of this.dustPool) {
      if (p.life <= 0) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.mesh.visible = false;
      } else {
        p.mesh.position.x += p.vx * dt;
        p.mesh.position.y += p.vy * dt;
        p.mesh.position.z += p.vz * dt;
        const ratio = p.life / p.maxLife;
        p.mesh.scale.setScalar(0.5 + (1 - ratio) * 1.1);
        (p.mesh.material as THREE.MeshBasicMaterial).opacity = ratio * 0.65;
      }
    }

    // Update 3D Winter Mouth Breath Steam Puffs (subtle translucent mist rising & dissipating)
    for (const b of this.breathPool) {
      if (b.life <= 0) continue;
      b.life -= dt;
      if (b.life <= 0) {
        b.mesh.visible = false;
      } else {
        b.mesh.position.x += b.vx * dt;
        b.mesh.position.y += b.vy * dt;
        b.mesh.position.z += b.vz * dt;
        b.vx *= Math.exp(-1.8 * dt);
        b.vz *= Math.exp(-1.8 * dt);
        const progress = 1 - b.life / b.maxLife;
        b.mesh.scale.setScalar(0.45 + progress * 1.55);
        const alpha = progress < 0.2 ? (progress / 0.2) * 0.42 : (1 - progress) * 0.42;
        (b.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, alpha);
      }
    }

    const gpState = this.pollGamepad();

    if (this.isTitleMode) {
      if (this.isCreationPreview && this.playerRig) {
        const px = this.playerRig.root.position.x;
        const pz = this.playerRig.root.position.z;
        this.playerRig.root.rotation.y = this.creationPreviewYaw;
        animateChibiRig(this.playerRig, 'idle', elapsed, dt);

        _camPos.set(px + 0.55, 1.45, pz + 3.1);
        this.camera.position.lerp(_camPos, 1 - Math.exp(-6 * dt));
        _camTarget.set(px + 0.72, 1.0, pz);
        this.camera.lookAt(_camTarget);
      } else {
        const angle = elapsed * 0.1;
        _camPos.set(4 + Math.cos(angle) * 30, 17, Math.sin(angle) * 28);
        this.camera.position.lerp(_camPos, 1 - Math.exp(-3 * dt));
        this.camera.lookAt(4, 1.5, 0);
      }
    } else if (this.assetsReady && this.playerRig) {
      // Combine Keyboard (Custom KeyBindings + Arrow keys) + Touch Joystick + Gamepad Analog
      let ix = this.movementLocked ? 0 : this.touchMove.x + gpState.ix;
      let iz = this.movementLocked ? 0 : this.touchMove.y + gpState.iz;
      if (!this.movementLocked) {
        if (this.keys.has(this.keyBindings.forward) || this.keys.has('ArrowUp')) iz -= 1;
        if (this.keys.has(this.keyBindings.backward) || this.keys.has('ArrowDown')) iz += 1;
        if (this.keys.has(this.keyBindings.left) || this.keys.has('ArrowLeft')) ix -= 1;
        if (this.keys.has(this.keyBindings.right) || this.keys.has('ArrowRight')) ix += 1;
      }

      // Natural human platforming: Momentum Control, Short Hop, Anti-Exploit Coyote Time, Corner Cutting & Realistic Double Jump
      this.jumpBufferTimer = Math.max(0, this.jumpBufferTimer - dt);
      this.dashCooldown = Math.max(0, this.dashCooldown - dt);
      this.dashTimer = Math.max(0, this.dashTimer - dt);
      this.landingRecoveryTimer = Math.max(0, this.landingRecoveryTimer - dt);
      this.doubleJumpAnimTimer = Math.max(0, this.doubleJumpAnimTimer - dt);
      this.playerLandSquash = THREE.MathUtils.damp(this.playerLandSquash, 0, 8.5, dt);

      const groundY = this.getGroundSurfaceY(this.playerPos.x, this.playerPos.z, this.playerPos.y);
      const groundedBeforeStep = this.playerPos.y <= groundY + 0.035 && this.jumpVelY <= 0;
      if (groundedBeforeStep) {
        this.playerPos.y = groundY;
        this.coyoteTimer = 0.11;
        this.hasUsedGroundJump = false;
        this.airJumpsRemaining = 1;
      } else {
        // Anti-exploit: coyote timer ONLY ticks when player walked off a ledge without jumping
        this.coyoteTimer = this.hasUsedGroundJump ? 0 : Math.max(0, this.coyoteTimer - dt);
      }
      this.performBufferedJump();

      if (this.playerPos.y > groundY || this.jumpVelY > 0) {
        // Short Hop + crisp asymmetric gravity (lighter apex feel while holding Jump, weighty landing descent)
        const gravity = this.jumpVelY >= 0 ? (this.jumpKeyHeld ? 23.5 : 31.0) : 29.8;
        this.jumpVelY -= gravity * dt;
        this.playerPos.y += this.jumpVelY * dt;
        const landingSurfaceY = this.getGroundSurfaceY(this.playerPos.x, this.playerPos.z, this.playerPos.y);
        if (this.playerPos.y <= landingSurfaceY && this.jumpVelY <= 0) {
          this.playerPos.y = landingSurfaceY;
          this.jumpVelY = 0;
          this.coyoteTimer = 0.11;
          this.hasUsedGroundJump = false;
          this.airJumpsRemaining = 1;
          if (this.wasAirborne) {
            this.playerLandSquash = 1.0;
            this.landingRecoveryTimer = 0.12;
            soundEngine.playFootstep(false);
          }
        }
      }

      const isSwimming = false;
      const isAirborne = this.playerPos.y > groundY + 0.05;
      this.wasAirborne = isAirborne;

      // Natural Human Locomotion: Smooth Acceleration, Deceleration, Air Momentum Control & Stable Camera-Relative Steering
      const controlsDisabled = this.movementLocked || this.playerSleeping;
      const isSprint =
        !controlsDisabled &&
        (this.mobileSprintActive ||
          this.keys.has(this.keyBindings.sprint) ||
          (this.keyBindings.sprint === 'ShiftLeft' && this.keys.has('ShiftRight')) ||
          (this.keyBindings.sprint === 'ShiftRight' && this.keys.has('ShiftLeft')) ||
          gpState.sprint);

      let targetVelX = 0;
      let targetVelZ = 0;
      const rawMoveInput = !controlsDisabled && (Math.abs(ix) > 0.02 || Math.abs(iz) > 0.02);
      if (this.fishingState === 'waiting' && rawMoveInput) {
        this.callbacks.onFishingCancel?.();
      }
      const hasMoveInput = !controlsDisabled && this.fishingState === 'idle' && this.workTimer <= 0 && rawMoveInput;
      const currentSpeed = Math.hypot(this.playerVelX, this.playerVelZ);
      const speedNorm = THREE.MathUtils.clamp(currentSpeed / Math.max(1, CHARACTER_ANIM_CONFIG.playerRunSpeed), 0, 1);

      if (hasMoveInput) {
        const len = Math.max(1, Math.hypot(ix, iz));
        const nx = ix / len;
        const nz = iz / len;

        // Always project steering cleanly from smoothCamYaw (rendered screen view) so movement matches camera 100%
        const moveBasisYaw = this.smoothCamYaw;
        const forwardX = Math.sin(moveBasisYaw);
        const forwardZ = Math.cos(moveBasisYaw);
        const rightX = -Math.cos(moveBasisYaw);
        const rightZ = Math.sin(moveBasisYaw);

        const wx = forwardX * -nz + rightX * nx;
        const wz = forwardZ * -nz + rightZ * nx;

        const landingSlowdown = this.landingRecoveryTimer > 0 ? 0.78 : 1.0;
        const groundSpeed =
          (isSwimming
            ? 2.8
            : isSprint
              ? CHARACTER_ANIM_CONFIG.playerRunSpeed
              : CHARACTER_ANIM_CONFIG.playerWalkSpeed) * landingSlowdown;

        // Momentum Control: preserve sprint launch momentum smoothly in mid-air while allowing controlled steering
        const maxAirJumpSpeed = Math.max(currentSpeed * 0.98, Math.min(CHARACTER_ANIM_CONFIG.playerRunSpeed * 0.88, 6.2));
        const moveSpeed = isAirborne ? Math.min(groundSpeed, maxAirJumpSpeed) : groundSpeed;

        targetVelX = wx * moveSpeed;
        targetVelZ = wz * moveSpeed;

        // Smooth speed-adaptive character rotation (never whips or fights camera yaw)
        const targetYaw = Math.atan2(wx, wz);
        let diff = targetYaw - this.playerYaw;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        const turnDamp = isAirborne ? 5.2 : THREE.MathUtils.lerp(11.5, 7.6, speedNorm);
        const prevYaw = this.playerYaw;
        this.playerYaw += diff * (1 - Math.exp(-turnDamp * dt));
        this.playerTurnRate = THREE.MathUtils.damp(this.playerTurnRate, (this.playerYaw - prevYaw) / Math.max(0.008, dt), 9, dt);
      } else {
        this.playerTurnRate = THREE.MathUtils.damp(this.playerTurnRate, 0, 10, dt);
      }

      // Momentum Control: responsive ground accel/decel + natural mid-air inertia (no abrupt mid-air freeze)
      const accelDamp = isAirborne
        ? hasMoveInput
          ? 3.1
          : 0.95
        : hasMoveInput
          ? isSprint
            ? 5.6
            : 6.8
          : 8.6;
      this.playerVelX = THREE.MathUtils.damp(this.playerVelX, targetVelX, accelDamp, dt);
      this.playerVelZ = THREE.MathUtils.damp(this.playerVelZ, targetVelZ, accelDamp, dt);
      if (!isAirborne && !hasMoveInput && Math.hypot(this.playerVelX, this.playerVelZ) < 0.08) {
        this.playerVelX = 0;
        this.playerVelZ = 0;
      }

      if (isAirborne) {
        const airSpeed = Math.hypot(this.playerVelX, this.playerVelZ);
        const maxAirCap = Math.min(CHARACTER_ANIM_CONFIG.playerRunSpeed * 0.92, 6.6);
        if (airSpeed > maxAirCap) {
          const factor = maxAirCap / airSpeed;
          this.playerVelX *= factor;
          this.playerVelZ *= factor;
        }
      }

      const dashX = this.dashTimer > 0 ? this.dashVector.x * this.dashSpeed : 0;
      const dashZ = this.dashTimer > 0 ? this.dashVector.y * this.dashSpeed : 0;
      const prevX = this.playerPos.x;
      const prevZ = this.playerPos.z;
      this.cornerCutLiftY = 0;
      const resolved = this.resolveCollisions(
        this.playerPos.x + (this.playerVelX + dashX) * dt,
        this.playerPos.z + (this.playerVelZ + dashZ) * dt,
        this.playerPos.y
      );
      this.playerPos.x = resolved.x;
      this.playerPos.z = resolved.z;
      if (this.cornerCutLiftY > this.playerPos.y) {
        this.playerPos.y = THREE.MathUtils.lerp(this.playerPos.y, this.cornerCutLiftY, Math.min(1, dt * 18));
        if (this.jumpVelY < 0.6) this.jumpVelY = 0.6;
      }

      // Root Motion: compute actual horizontal displacement to drive footstep & stride phase with zero skating
      const actualStepDist = Math.hypot(this.playerPos.x - prevX, this.playerPos.z - prevZ);
      const actualHorizSpeed = actualStepDist / Math.max(0.004, dt);
      if (!isAirborne && actualStepDist > 0.0008) {
        this.playerGaitPhase += actualStepDist * 2.55;
      }

      // Winter cold-breath vapor while player is speaking/chatting outdoors
      if (this.playerSpeakingUntil > elapsed && (this.currentSeason === 'Winter' || this.currentWeather === 'Snowy')) {
        this.playerBreathCooldown -= dt;
        if (this.playerBreathCooldown <= 0) {
          this.playerBreathCooldown = 0.48;
          this.emitWinterBreathSteam(this.playerPos.x, this.playerPos.y, this.playerPos.z, this.playerYaw, 2);
        }
      }

      let activeWorkStyle = this.workStyle;
      let workProgress = 1 - Math.max(0, this.workTimer) / Math.max(0.01, this.workDuration);
      if (this.playerSleeping) {
        this.playerAnim = 'sleep';
        this.playerIdleTimer = 0;
      } else if (this.workTimer > 0) {
        this.workTimer -= dt;
        this.playerAnim = 'work';
        this.playerIdleTimer = 0;
      } else if (this.fishingState !== 'idle') {
        this.playerAnim = 'work';
        this.playerIdleTimer = 0;
        activeWorkStyle =
          this.fishingState === 'bite' || this.fishingState === 'reeling'
            ? 'fish_reel'
            : this.fishingState === 'casting'
              ? 'fish_cast'
              : 'fish_wait';
        workProgress = (elapsed * 2) % 1;
      } else if (isSwimming) {
        this.playerAnim = 'swim';
        this.playerIdleTimer = 0;
      } else if (isAirborne) {
        this.playerAnim = 'jump';
        this.playerIdleTimer = 0;
      } else if (actualHorizSpeed > 0.28) {
        this.playerIdleTimer = 0;
        this.playerIdleVariant = CHARACTER_ANIM_CONFIG.playerDefaultIdlePose;
        const runningNow = actualHorizSpeed > CHARACTER_ANIM_CONFIG.playerWalkSpeed * 1.15 || this.dashTimer > 0;
        this.playerAnim = runningNow ? 'run' : 'walk';

        // Footstep cadence synced directly with Root Motion displacement
        this.footstepAccum += actualStepDist;
        const stepStrideMeters = runningNow ? 2.15 : 1.75;
        if (this.footstepAccum >= stepStrideMeters) {
          this.footstepAccum = 0;
          soundEngine.playFootstep(runningNow);
        }
        if (runningNow && !this.currentZone.startsWith('int_')) {
          this.dustSpawnAccum += dt;
          if (this.dustSpawnAccum >= 0.075) {
            this.dustSpawnAccum = 0;
            this.spawnDustPuff();
          }
        }
      } else {
        this.playerAnim = 'idle';
        this.footstepAccum = 1.0;
        // Organic idle pose cycling so character never looks like a stiff statue
        this.playerIdleTimer += dt;
        if (this.playerIdleTimer > 8.5) {
          this.playerIdleTimer = 0;
          const variants: NpcIdlePose[] = ['relaxed', 'look_around', 'stretch', 'relaxed', 'ponder', 'whistle'];
          this.playerIdleVariant = variants[Math.floor(Math.random() * variants.length)];
        }
      }

      const postMoveGroundY = this.getGroundSurfaceY(this.playerPos.x, this.playerPos.z, this.playerPos.y);
      if (!isAirborne) {
        if (this.playerPos.y <= postMoveGroundY + 0.14) {
          this.playerPos.y = postMoveGroundY;
        }
      } else if (this.playerPos.y < postMoveGroundY) {
        this.playerPos.y = postMoveGroundY;
        this.jumpVelY = 0;
      }

      const playerLoco: LocomotionInput = {
        horizontalSpeed: actualHorizSpeed,
        maxSpeed: CHARACTER_ANIM_CONFIG.playerRunSpeed,
        verticalVel: this.jumpVelY,
        groundHeight: Math.max(0, this.playerPos.y - postMoveGroundY),
        gaitPhase: this.playerGaitPhase,
        turnRate: this.playerTurnRate,
        landSquash: this.playerLandSquash,
        dashWeight: this.dashTimer > 0 ? Math.min(1, this.dashTimer / 0.18) : 0,
        handIkReach: this.workTimer > 0 ? 0.25 : 0,
        workStyle: activeWorkStyle,
        workProgress,
        weather: this.currentWeather,
        hour: this.currentHour,
      };

      this.playerRig.root.position.copy(this.playerPos);
      this.playerRig.root.rotation.y = this.playerYaw;
      animateChibiRig(
        this.playerRig,
        this.playerAnim,
        elapsed,
        dt,
        this.playerIdleVariant,
        CHARACTER_ANIM_CONFIG.npcIdleSpeed,
        playerLoco
      );

      // Update live 3D Fishing Bobber, Ripples & Smooth 12-Segment Catenary Line from EXACT Calibrated RodTip -> Bobber
      if (this.fishingGroup && this.fishingGroup.visible && this.fishingBobber && this.fishingRipple && this.fishingLine) {
        // Recompute live bone/tool world matrices AFTER animateChibiRig so RodTip never lags by 1 frame!
        this.playerRig.root.updateMatrixWorld(true);

        const isFighting = this.fishingState === 'bite' || this.fishingState === 'reeling';
        const bobY = isFighting
          ? 0.02 + Math.sin(elapsed * 26) * 0.13
          : 0.08 + Math.sin(elapsed * 3.4) * 0.025;
        const jitterX = isFighting ? Math.sin(elapsed * 21) * 0.14 : 0;
        const jitterZ = isFighting ? Math.cos(elapsed * 19) * 0.14 : 0;
        this.fishingBobber.position.set(this.fishingBobberPos.x + jitterX, bobY, this.fishingBobberPos.z + jitterZ);
        const rippleScale = isFighting ? 1.1 + ((elapsed * 4.5) % 1.4) : 0.75 + ((elapsed * 1.1) % 0.9);
        this.fishingRipple.position.set(this.fishingBobber.position.x, 0.06, this.fishingBobber.position.z);
        this.fishingRipple.scale.setScalar(rippleScale);
        (this.fishingRipple.material as THREE.MeshBasicMaterial).opacity = Math.max(0.08, 0.75 - rippleScale * 0.3);

        const tipObj = this.playerRig.toolMount.getObjectByName('RodTip') || this.playerRig.toolMount;
        if (tipObj && tipObj.name === 'RodTip' && !tipObj.userData.calibrated && tipObj.parent) {
          const calibrated = computeFishingRodTipLocal(tipObj.parent);
          if (calibrated) {
            tipObj.position.copy(calibrated);
            tipObj.userData.calibrated = true;
            this.playerRig.root.updateMatrixWorld(true);
          }
        }
        tipObj.getWorldPosition(_projVec);

        const startX = _projVec.x;
        const startY = _projVec.y;
        const startZ = _projVec.z;
        const endX = this.fishingBobber.position.x;
        const endY = this.fishingBobber.position.y + 0.09;
        const endZ = this.fishingBobber.position.z;

        const posAttr = this.fishingLine.geometry.attributes.position as THREE.BufferAttribute;
        const segCount = posAttr.count;
        const sagAmp = isFighting ? 0.035 : this.fishingState === 'casting' ? 0.14 : 0.24;
        const swayAmp = isFighting ? 0.03 : 0.015;
        for (let i = 0; i < segCount; i++) {
          const t = i / Math.max(1, segCount - 1);
          const lx = THREE.MathUtils.lerp(startX, endX, t);
          const lz = THREE.MathUtils.lerp(startZ, endZ, t);
          const sag = 4 * t * (1 - t) * sagAmp;
          const vib = Math.sin(elapsed * (isFighting ? 36 : 3.5) + t * Math.PI * 3) * swayAmp * (4 * t * (1 - t));
          const ly = Math.max(0.05, THREE.MathUtils.lerp(startY, endY, t) - sag);
          posAttr.setXYZ(i, lx + vib, ly, lz + vib * 0.6);
        }
        posAttr.needsUpdate = true;
      }

      // Update Impact VFX Particles (woodchips, leaves, stone shards, dirt, water droplets, sparkles)
      for (let i = this.vfxParticles.length - 1; i >= 0; i--) {
        const vp = this.vfxParticles[i];
        vp.life -= dt;
        if (vp.life <= 0) {
          this.scene.remove(vp.mesh);
          vp.mesh.geometry.dispose();
          (vp.mesh.material as THREE.Material).dispose();
          this.vfxParticles.splice(i, 1);
        } else {
          vp.vy -= vp.gravity * dt;
          vp.mesh.position.x += vp.vx * dt;
          vp.mesh.position.y = Math.max(0.02, vp.mesh.position.y + vp.vy * dt);
          vp.mesh.position.z += vp.vz * dt;
          vp.mesh.rotation.x += vp.rotSpeed * dt;
          vp.mesh.rotation.y += vp.rotSpeed * 0.7 * dt;
          const sc = Math.max(0.05, vp.life / vp.maxLife);
          vp.mesh.scale.setScalar(sc);
        }
      }

      // Update Hit Reaction Shakes (recoil wobble on chopped trees/stumps/rocks)
      for (let i = this.hitShakes.length - 1; i >= 0; i--) {
        const hs = this.hitShakes[i];
        hs.timer += dt;
        if (hs.timer >= hs.duration) {
          hs.obj.rotation.x = hs.baseRotX;
          hs.obj.rotation.z = hs.baseRotZ;
          this.hitShakes.splice(i, 1);
        } else {
          const p = hs.timer / hs.duration;
          const wave = Math.sin(p * Math.PI * 4) * (1 - p) * hs.amp;
          hs.obj.rotation.x = hs.baseRotX + hs.dirZ * wave;
          hs.obj.rotation.z = hs.baseRotZ - hs.dirX * wave;
        }
      }

      // Update Physics-Based Falling Trees (gravity angular acceleration -> ground thud -> leaves solid stump!)
      for (let i = this.fallingTrees.length - 1; i >= 0; i--) {
        const ft = this.fallingTrees[i];
        ft.angVel += 4.8 * dt;
        ft.angle += ft.angVel * dt;
        ft.mesh.rotation.x = ft.fallAxisX * ft.angle;
        ft.mesh.rotation.z = ft.fallAxisZ * ft.angle;
        if (ft.angle >= Math.PI * 0.47) {
          ft.mesh.visible = false;
          ft.mesh.rotation.x = 0;
          ft.mesh.rotation.z = 0;
          this.spawnImpactVfx('dirt', ft.x + ft.fallAxisZ * 2.2, 0.25, ft.z - ft.fallAxisX * 2.2, 12);
          this.spawnImpactVfx('leaf', ft.x + ft.fallAxisZ * 2.4, 0.65, ft.z - ft.fallAxisX * 2.4, 14);
          this.impactCamShake = Math.max(this.impactCamShake, 0.2);
          this.fallingTrees.splice(i, 1);
        }
      }

      // Secondary Environmental Foliage Wind Sway on standing farm trees
      if (this.outdoorRefs && !this.currentZone.startsWith('int_')) {
        for (let i = 0; i < this.outdoorRefs.farmTrees.length; i++) {
          const ft = this.outdoorRefs.farmTrees[i];
          if (!ft.mesh || !ft.mesh.visible || ft.isStump || ft.chopped) continue;
          if (this.fallingTrees.some((f) => f.treeId === ft.id)) continue;
          if (this.hitShakes.some((h) => h.obj === ft.mesh)) continue;
          ft.mesh.rotation.z = Math.sin(elapsed * 1.45 + ft.x * 0.25 + ft.z * 0.17) * 0.016;
        }
      }

      // Off-Camera / Unobserved Respawn Check (item 17): reveal deferred respawns ONLY once player looks away!
      if (this.deferredRespawns.length > 0) {
        for (let i = this.deferredRespawns.length - 1; i >= 0; i--) {
          const item = this.deferredRespawns[i];
          if (!this.isPointInCameraFrustum(item.x, item.z)) {
            item.obj.visible = true;
            this.deferredRespawns.splice(i, 1);
          }
        }
      }

      // Update Tile Highlight on Farm Yard OR Flat Diggable Cave Floor
      if (this.currentZone === 'farm_home') {
        const targetX = this.playerPos.x + Math.sin(this.playerYaw) * 0.95;
        const targetZ = this.playerPos.z + Math.cos(this.playerYaw) * 0.95;
        const gx = Math.round((targetX - FARM_ORIGIN_X) / FARM_TILE_STEP);
        const gz = Math.round((targetZ - FARM_ORIGIN_Z) / FARM_TILE_STEP);
        if (gx >= 0 && gx < FARM_GRID_COLS && gz >= 0 && gz < FARM_GRID_ROWS) {
          const cx = FARM_ORIGIN_X + gx * FARM_TILE_STEP;
          const cz = FARM_ORIGIN_Z + gz * FARM_TILE_STEP;
          if (Math.hypot(cx - this.playerPos.x, cz - this.playerPos.z) <= 1.65) {
            this.tileHighlight.visible = true;
            this.tileHighlight.position.set(cx, 0.05, cz);
          } else {
            this.tileHighlight.visible = false;
          }
        } else {
          this.tileHighlight.visible = false;
        }
      } else if (this.currentZone === 'int_cave' && this.activeHeldItemId === 'tool_hoe') {
        const digX = this.playerPos.x + Math.sin(this.playerYaw) * 1.05;
        const digZ = this.playerPos.z + Math.cos(this.playerYaw) * 1.05;
        if (
          Math.abs(digX) <= this.interiorRoomBounds.halfW - 1.1 &&
          digZ >= -(this.interiorRoomBounds.halfD - 1.1) &&
          digZ <= this.interiorRoomBounds.halfD - 2.2
        ) {
          const gx = Math.round(digX / 1.6);
          const gz = Math.round(digZ / 1.6);
          this.tileHighlight.visible = true;
          this.tileHighlight.position.set(gx * 1.6, 0.04, gz * 1.6);
        } else {
          this.tileHighlight.visible = false;
        }
      } else {
        this.tileHighlight.visible = false;
      }

      // Detect outdoor sub-zone changes
      if (!this.currentZone.startsWith('int_')) {
        let detected: WorldZoneId = 'village_square';
        if (this.playerPos.x <= -64) detected = 'farm_home';
        else if (this.playerPos.x < -12 && this.playerPos.z >= 36) detected = 'secret_grove';
        else if (this.playerPos.z >= 27) detected = 'forest';
        else if (this.playerPos.z <= -27) detected = 'mountain_mine';
        else if (this.playerPos.x >= 34) detected = 'river_beach';
        if (detected !== this.lastZoneDetected) {
          this.lastZoneDetected = detected;
          this.currentZone = detected;
          this.callbacks.onZoneAutoDetect(detected);
        }
      }

      // Texel-snapped Real-Time Lighting Solar Arc + Dynamic Shadows Frustum (eliminates shadow edge shimmer!)
      const snapX = Math.round(this.playerPos.x);
      const snapZ = Math.round(this.playerPos.z);
      if (this.graphicsProfile.realTimeLighting) {
        const dayArc = THREE.MathUtils.clamp((this.currentHour - 6) / 13, 0, 1) * Math.PI;
        const sunOffsetX = Math.cos(dayArc) * 34;
        const sunHeight = Math.max(14, Math.sin(dayArc) * 44);
        this.sunLight.position.set(snapX + sunOffsetX, sunHeight, snapZ + 20);
        this.rimLight.position.set(snapX - sunOffsetX * 0.7, 16, snapZ - 22);
      } else {
        this.sunLight.position.set(snapX + 24, 38, snapZ + 20);
      }
      this.sunLight.target.position.set(snapX, 0, snapZ);

      // Flicker-Free Smooth Real-Time Global Illumination (RTGI) Probe (lerped color & position, never fights hemiLight)
      if (this.graphicsProfile.realTimeGI || this.graphicsProfile.pathTracing) {
        const rtgiDamp = 1 - Math.exp(-3.5 * dt);
        this.rtgiProbeLight.position.x = THREE.MathUtils.lerp(this.rtgiProbeLight.position.x, this.playerPos.x, rtgiDamp);
        this.rtgiProbeLight.position.y = THREE.MathUtils.lerp(this.rtgiProbeLight.position.y, this.playerPos.y + 2.4, rtgiDamp);
        this.rtgiProbeLight.position.z = THREE.MathUtils.lerp(this.rtgiProbeLight.position.z, this.playerPos.z, rtgiDamp);
        const zoneBounceHex =
          this.currentZone === 'int_cave'
            ? '#7dd3fc'
            : this.currentZone.startsWith('int_')
              ? '#f5d08a'
              : this.currentSeason === 'Winter'
                ? '#cbd5e1'
                : this.currentZone === 'river_beach'
                  ? '#f3e1a4'
                  : this.currentZone === 'village_square'
                    ? '#e7d5bc'
                    : '#b7d48c';
        this.rtgiTargetColor.set(zoneBounceHex);
        this.rtgiProbeLight.color.lerp(this.rtgiTargetColor, rtgiDamp);
        const targetIntensity = this.graphicsProfile.pathTracing ? 0.2 : 0.14;
        this.rtgiProbeLight.intensity = THREE.MathUtils.lerp(this.rtgiProbeLight.intensity, targetIntensity, rtgiDamp);
      }

      // Visual Smoothness & Seamless Transition System:
      // Gently interpolate sky, fog, sun, hemi, window emissive, and weather opacity every frame (zero popping/flicker!)
      const envDamp = 1 - Math.exp(-2.2 * dt);
      if (this.scene.background instanceof THREE.Color) {
        this.scene.background.lerp(this.targetSkyColor, envDamp);
      } else {
        this.scene.background = this.targetSkyColor.clone();
      }
      const fogExp = this.scene.fog as THREE.FogExp2 | null;
      if (fogExp) {
        fogExp.color.lerp(this.targetSkyColor, envDamp);
        fogExp.density = THREE.MathUtils.damp(fogExp.density, this.targetFogDensity, 2.2, dt);
      }
      this.sunLight.color.lerp(this.targetSunColor, envDamp);
      this.sunLight.intensity = THREE.MathUtils.damp(this.sunLight.intensity, this.targetSunIntensity, 2.2, dt);
      this.hemiLight.intensity = THREE.MathUtils.damp(this.hemiLight.intensity, this.targetHemiIntensity, 2.2, dt);
      this.outdoorRefs?.windowMats.forEach((m) => {
        m.emissiveIntensity = THREE.MathUtils.damp(m.emissiveIntensity, this.targetWindowEmissive, 2.4, dt);
      });
      const wpMat = this.weatherPoints.material as THREE.PointsMaterial;
      this.currentWeatherOpacity = THREE.MathUtils.damp(this.currentWeatherOpacity, this.targetWeatherOpacity, 1.8, dt);
      wpMat.opacity = this.currentWeatherOpacity;
      if (this.currentWeatherOpacity < 0.015 && this.targetWeatherOpacity === 0) {
        this.weatherPoints.visible = false;
      }

      // Perfected Anti-Occlusion Third-Person Camera (Zero Spin Feedback Loop!)
      if (this.cameraConfig.povMode === 'lock') {
        this.camZoomDist = this.cameraConfig.defaultDistance;
        const returnDelayMs = Math.max(500, (this.cameraConfig.mobileLockAutoReturnDelaySec ?? 2.5) * 1000);
        const returnSpeed = Math.max(0.6, this.cameraConfig.mobileLockAutoReturnSpeed ?? 3.2);
        const idleSinceDragMs = this.lockCamLastDragAt > 0 ? performance.now() - this.lockCamLastDragAt : Infinity;

        if (!this.isDraggingCam) {
          if (this.lockCamManualOrbitActive) {
            // After a manual drag (mobile or desktop), hold the user's chosen angle cleanly for returnDelayMs,
            // then gently ease back behind the character facing forward.
            if (idleSinceDragMs >= returnDelayMs) {
              let diffToBack = this.playerYaw - this.camYaw;
              while (diffToBack > Math.PI) diffToBack -= Math.PI * 2;
              while (diffToBack < -Math.PI) diffToBack += Math.PI * 2;
              this.camYaw += diffToBack * (1 - Math.exp(-returnSpeed * dt));
              this.camPitch = THREE.MathUtils.damp(this.camPitch, this.cameraConfig.defaultPitch, returnSpeed, dt);
              if (Math.abs(diffToBack) < 0.02 && Math.abs(this.camPitch - this.cameraConfig.defaultPitch) < 0.015) {
                this.lockCamManualOrbitActive = false;
              }
            }
          } else {
            // Normal Lock POV travel: camera stays rock-steady and ONLY softly arcs behind diagonal/forward steering,
            // never spinning wildly on strafe or reversing when walking backward!
            this.camPitch = THREE.MathUtils.damp(this.camPitch, this.cameraConfig.defaultPitch, 4.0, dt);
            const movingForward = hasMoveInput && iz < -0.15;
            const steeringSideways = Math.abs(ix) > 0.12;
            if (movingForward && steeringSideways) {
              let yawDiff = this.playerYaw - this.camYaw;
              while (yawDiff > Math.PI) yawDiff -= Math.PI * 2;
              while (yawDiff < -Math.PI) yawDiff += Math.PI * 2;
              const gentleFollow = Math.min(1.65, returnSpeed * 0.48);
              this.camYaw += yawDiff * (1 - Math.exp(-gentleFollow * dt));
            }
          }
        }
      }

      // Frame slightly higher & forward along camera view so the horizon stays open & natural (never overly downward)
      const isLockMode = this.cameraConfig.povMode === 'lock';
      const lookAheadDist = isLockMode ? 0.85 : 0.25;
      const targetLookX = this.playerPos.x + Math.sin(this.smoothCamYaw) * lookAheadDist;
      const targetLookY = this.playerPos.y * 0.65 + (isLockMode ? 1.55 : 1.32);
      const targetLookZ = this.playerPos.z + Math.cos(this.smoothCamYaw) * lookAheadDist;

      this.smoothCamTarget.x = THREE.MathUtils.damp(this.smoothCamTarget.x, targetLookX, 11, dt);
      this.smoothCamTarget.y = THREE.MathUtils.damp(this.smoothCamTarget.y, targetLookY, 11, dt);
      this.smoothCamTarget.z = THREE.MathUtils.damp(this.smoothCamTarget.z, targetLookZ, 11, dt);
      _camTarget.copy(this.smoothCamTarget);

      // Shortest-angle damping prevents 360-degree spin artifacts when crossing +/- PI
      let smoothYawDelta = this.camYaw - this.smoothCamYaw;
      while (smoothYawDelta > Math.PI) smoothYawDelta -= Math.PI * 2;
      while (smoothYawDelta < -Math.PI) smoothYawDelta += Math.PI * 2;
      const yawSmoothSpeed = this.isDraggingCam ? 22 : isLockMode ? 11 : 15;
      this.smoothCamYaw += smoothYawDelta * (1 - Math.exp(-yawSmoothSpeed * dt));
      this.smoothCamPitch = THREE.MathUtils.damp(this.smoothCamPitch, this.camPitch, this.isDraggingCam ? 20 : 11, dt);

      const inInterior = this.currentZone.startsWith('int_');
      const desiredDist = inInterior
        ? Math.min(this.camZoomDist, Math.min(this.interiorRoomBounds.halfD * 1.18, 8.2))
        : this.camZoomDist;
      const dirX = -Math.sin(this.smoothCamYaw) * Math.cos(this.smoothCamPitch);
      const dirY = Math.sin(this.smoothCamPitch);
      const dirZ = -Math.cos(this.smoothCamYaw) * Math.cos(this.smoothCamPitch);

      let safeDist = desiredDist;

      if (inInterior) {
        const pad = 0.65;
        const maxX = Math.max(1.5, this.interiorRoomBounds.halfW - pad);
        const maxZ = Math.max(1.5, this.interiorRoomBounds.halfD - pad);
        if (Math.abs(dirX) > 1e-4) {
          const boundX = dirX > 0 ? maxX : -maxX;
          const tX = (boundX - _camTarget.x) / dirX;
          if (tX > 0.5 && tX < safeDist) safeDist = tX;
        }
        if (Math.abs(dirZ) > 1e-4) {
          const boundZ = dirZ > 0 ? maxZ : -maxZ;
          const tZ = (boundZ - _camTarget.z) / dirZ;
          if (tZ > 0.5 && tZ < safeDist) safeDist = tZ;
        }
        if (dirY > 1e-4) {
          const tY = (4.1 - _camTarget.y) / dirY;
          if (tY > 0.5 && tY < safeDist) safeDist = tY;
        }
        safeDist = Math.max(3.4, safeDist);
      } else if (this.outdoorRefs) {
        for (const box of this.outdoorRefs.cameraOccluders) {
          let tMin = 0;
          let tMax = safeDist;
          const checkAxis = (orig: number, dir: number, bMin: number, bMax: number): boolean => {
            if (Math.abs(dir) < 1e-6) return orig >= bMin && orig <= bMax;
            let t1 = (bMin - orig) / dir;
            let t2 = (bMax - orig) / dir;
            if (t1 > t2) {
              const tmp = t1;
              t1 = t2;
              t2 = tmp;
            }
            tMin = Math.max(tMin, t1);
            tMax = Math.min(tMax, t2);
            return tMin <= tMax;
          };
          if (
            checkAxis(_camTarget.x, dirX, box.minX, box.maxX) &&
            checkAxis(_camTarget.y, dirY, 0, box.maxY) &&
            checkAxis(_camTarget.z, dirZ, box.minZ, box.maxZ)
          ) {
            if (tMin > 0.25 && tMin < safeDist) {
              safeDist = Math.max(3.1, tMin - 0.55);
            }
          }
        }
      }

      const camDampSpeed = safeDist < this.smoothCamDist ? 14 : 5.0;
      this.smoothCamDist = THREE.MathUtils.damp(this.smoothCamDist, safeDist, camDampSpeed, dt);

      _camPos.set(
        _camTarget.x + dirX * this.smoothCamDist,
        Math.max(1.55, _camTarget.y + dirY * this.smoothCamDist),
        _camTarget.z + dirZ * this.smoothCamDist
      );
      // Gentle, comfortable impact recoil (capped so camera never shakes harshly)
      let shakeX = 0;
      let shakeY = 0;
      if (this.impactCamShake > 0) {
        this.impactCamShake = Math.max(0, this.impactCamShake - dt * 1.8);
        const softAmp = Math.min(0.055, this.impactCamShake * 0.14);
        shakeX = Math.sin(elapsed * 42) * softAmp;
        shakeY = Math.cos(elapsed * 36) * softAmp * 0.8;
      }
      this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, _camPos.x, 12, dt) + shakeX;
      this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, _camPos.y, 12, dt) + shakeY;
      this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, _camPos.z, 12, dt);
      this.camera.lookAt(_camTarget);

      // Runtime Three.js Occlusion & Frustum Culling Pass (throttled ~65ms, zero-allocation)
      const occNowMs = performance.now();
      if (
        !inInterior &&
        this.outdoorRefs &&
        this.performanceConfig.enableOcclusionCulling &&
        occNowMs - this.lastOcclusionPassAt > 65
      ) {
        this.lastOcclusionPassAt = occNowMs;
        this.runOutdoorOcclusionPass();
      }

      // Throttled multiplayer move emit
      const nowMs = performance.now();
      if (nowMs - this.lastMoveSyncAt > 85) {
        this.lastMoveSyncAt = nowMs;
        this.callbacks.onMoveSync(
          Number(this.playerPos.x.toFixed(2)),
          Number(this.playerPos.y.toFixed(2)),
          Number(this.playerPos.z.toFixed(2)),
          Number(this.playerYaw.toFixed(2)),
          this.playerAnim === 'sleep' ? 'idle' : this.playerAnim
        );
      }

      // Contextual Prompt Check
      const prompt = this.getNearestPrompt();
      const pKey = prompt
        ? `${prompt.social?.kind || ''}:${prompt.social?.id || ''}|${prompt.execute?.kind || ''}:${prompt.execute?.id || ''}`
        : '';
      if (pKey !== this.lastPromptKey) {
        this.lastPromptKey = pKey;
        this.callbacks.onPromptChange(prompt);
      }

      // Proximity-Only Floating Nameplate Projection (<= 3.6m only!)
      if (nowMs - this.lastTagEmitAt > 60) {
        this.lastTagEmitAt = nowMs;
        const w = this.container.clientWidth || window.innerWidth;
        const h = this.container.clientHeight || window.innerHeight;
        const tags: FloatingTag[] = [];

        for (const [npcId, entry] of this.npcRigs.entries()) {
          if (!entry.rig.root.visible) continue;
          const dist = Math.hypot(entry.pos.x - this.playerPos.x, entry.pos.z - this.playerPos.z);
          if (dist > 3.6) continue;
          _projVec.set(entry.pos.x, entry.pos.y + 2.05, entry.pos.z).project(this.camera);
          if (_projVec.z < 1) {
            const npc = NPCS.find((n) => n.id === npcId);
            tags.push({
              id: `npc_${npcId}`,
              label: npc?.name || npcId,
              sublabel: npc?.profession,
              x: ((_projVec.x + 1) / 2) * w,
              y: ((-_projVec.y + 1) / 2) * h,
              kind: 'npc',
            });
          }
        }

        for (const [cid, entry] of this.remoteRigs.entries()) {
          const dist = Math.hypot(entry.pos.x - this.playerPos.x, entry.pos.z - this.playerPos.z);
          if (dist > 3.6) continue;
          _projVec.set(entry.pos.x, entry.pos.y + 2.1, entry.pos.z).project(this.camera);
          if (_projVec.z < 1) {
            tags.push({
              id: `plr_${cid}`,
              label: entry.player.avatarName,
              sublabel: entry.player.farmName,
              x: ((_projVec.x + 1) / 2) * w,
              y: ((-_projVec.y + 1) / 2) * h,
              kind: 'player',
            });
          }
        }
        this.callbacks.onTagsUpdate(tags);
      }

      // Smooth 3D Head Anchors for Floating Chat Bubbles & Live Video Call Bubbles (local + all remote players)
      if (this.callbacks.onHeadAnchorsUpdate && nowMs - this.lastAnchorEmitAt > 33) {
        this.lastAnchorEmitAt = nowMs;
        const w = this.container.clientWidth || window.innerWidth;
        const h = this.container.clientHeight || window.innerHeight;
        const anchors: PlayerHeadAnchor[] = [];

        _projVec.set(this.playerPos.x, this.playerPos.y + 2.25, this.playerPos.z).project(this.camera);
        anchors.push({
          uid: this.localUid,
          avatarName: this.localAvatarName,
          x: ((_projVec.x + 1) / 2) * w,
          y: ((-_projVec.y + 1) / 2) * h,
          visible: _projVec.z < 1 && _projVec.z > -1,
          isLocal: true,
        });

        for (const entry of this.remoteRigs.values()) {
          _projVec.set(entry.pos.x, entry.pos.y + 2.25, entry.pos.z).project(this.camera);
          const visible = _projVec.z < 1 && _projVec.z > -1 && Math.abs(_projVec.x) <= 1.2 && Math.abs(_projVec.y) <= 1.2;
          anchors.push({
            uid: entry.player.uid,
            avatarName: entry.player.avatarName,
            x: ((_projVec.x + 1) / 2) * w,
            y: ((-_projVec.y + 1) / 2) * h,
            visible,
            isLocal: false,
          });
        }

        // Project visible NPC head anchors ('npc:<id>') for overhead NPC Speech Bubbles & Talk/Give Popover!
        for (const [npcId, entry] of this.npcRigs.entries()) {
          if (!entry.rig.root.visible) continue;
          const dist = Math.hypot(entry.pos.x - this.playerPos.x, entry.pos.z - this.playerPos.z);
          if (dist > 18) continue;
          _projVec.set(entry.pos.x, entry.pos.y + 2.25, entry.pos.z).project(this.camera);
          const visible = _projVec.z < 1 && _projVec.z > -1 && Math.abs(_projVec.x) <= 1.25 && Math.abs(_projVec.y) <= 1.25;
          const npc = NPCS.find((n) => n.id === npcId);
          anchors.push({
            uid: `npc:${npcId}`,
            avatarName: npc?.name || npcId,
            x: ((_projVec.x + 1) / 2) * w,
            y: ((-_projVec.y + 1) / 2) * h,
            visible,
            isLocal: false,
          });
        }

        // Project nearby outdoor Signboard anchors ('sign_<portalId>') for overhead Signboard Speech Bubbles!
        if (!this.currentZone.startsWith('int_') && this.outdoorRefs) {
          for (const sb of this.outdoorRefs.signboards) {
            const dist = Math.hypot(sb.x - this.playerPos.x, sb.z - this.playerPos.z);
            if (dist > 22) continue;
            _projVec.set(sb.x, sb.y, sb.z).project(this.camera);
            const visible = _projVec.z < 1 && _projVec.z > -1 && Math.abs(_projVec.x) <= 1.25 && Math.abs(_projVec.y) <= 1.25;
            anchors.push({
              uid: sb.id,
              avatarName: sb.title,
              x: ((_projVec.x + 1) / 2) * w,
              y: ((-_projVec.y + 1) / 2) * h,
              visible,
              isLocal: false,
            });
          }
        }

        // Project visible Animal head anchors ('animal:<id>') for overhead Animal Speech & Emote Bubbles!
        if (this.animalsGroup.visible) {
          for (const actor of this.animalActors.values()) {
            if (!actor.rig.root.visible) continue;
            const dist = Math.hypot(actor.pos.x - this.playerPos.x, actor.pos.z - this.playerPos.z);
            if (dist > 18) continue;
            const headH = actor.state.type === 'horse' ? 2.1 : actor.state.type === 'cow' ? 1.65 : actor.state.type === 'chicken' ? 0.95 : 1.3;
            _projVec.set(actor.pos.x, actor.pos.y + headH, actor.pos.z).project(this.camera);
            const visible = _projVec.z < 1 && _projVec.z > -1 && Math.abs(_projVec.x) <= 1.25 && Math.abs(_projVec.y) <= 1.25;
            anchors.push({
              uid: `animal:${actor.id}`,
              avatarName: actor.state.name,
              x: ((_projVec.x + 1) / 2) * w,
              y: ((-_projVec.y + 1) / 2) * h,
              visible,
              isLocal: false,
            });
          }
        }

        this.callbacks.onHeadAnchorsUpdate(anchors);
      }
    }

    // =========================================================================
    // LIVING, INTELLIGENT VILLAGE NPC AI SYSTEM
    // - 4 Autonomous Professions: Miner, Lumberjack, Shopkeeper, Angler
    // - Weather & Schedule Reactions, Energy/Fatigue, Emotions & 3D Facial Expressions
    // - NPC-to-NPC Conversations, Bench Sitting, Ambient Thoughts, Head Tracking & Eye Contact
    // - Obstacle-Avoiding Navigation & Bridge Traversal
    // =========================================================================
    const randomIdlePool: NpcIdlePose[] = [
      'relaxed',
      'wave',
      'stretch',
      'ponder',
      'chat',
      'cheerful',
      'thoughtful',
      'yawn',
      'look_around',
      'whistle',
    ];
    const isRainOrStorm =
      this.currentWeather === 'LightRain' ||
      this.currentWeather === 'Rainy' ||
      this.currentWeather === 'HeavyRain' ||
      this.currentWeather === 'Stormy';
    const isFestivalNow = FESTIVALS.some((f) => f.season === this.currentSeason && f.day === this.currentDay);
    const inOutdoor = !this.currentZone.startsWith('int_');

    const anglerSpots: ReadonlyArray<{ id: string; x: number; z: number; faceYaw: number }> = [
      { id: 'fish_river_dock', x: 43.0, z: 16.0, faceYaw: Math.PI / 2 },
      { id: 'fish_ocean_pier', x: 54.0, z: -8.0, faceYaw: Math.PI / 2 },
      { id: 'fish_river_bank', x: 41.2, z: 21.5, faceYaw: Math.PI / 2 },
      { id: 'fish_south_shore', x: 45.2, z: -13.2, faceYaw: Math.PI / 2 },
    ];
    // Live validated Mine Rock objects from WorldBuilder (including far-corner Cave mountain ore veins!)
    const liveMineRocks = (this.outdoorRefs?.interactives || [])
      .filter((n) => n.kind === 'mine_rock')
      .map((n) => ({ id: n.id, x: n.x, z: n.z, standX: n.x, standZ: n.z + 1.45 }));
    const mineNodes =
      liveMineRocks.length > 0
        ? liveMineRocks
        : [
            { id: 'mine_fallback_0', x: 12, z: -36, standX: 12, standZ: -34.5 },
            { id: 'mine_fallback_1', x: 17, z: -33, standX: 17, standZ: -31.5 },
          ];
    const claimedTargets = new Set<string>();

    const equipNpcItem = (
      entry: { rig: ChibiRig; heldItemId: string | null },
      itemId: string | null
    ) => {
      if (entry.heldItemId === itemId) return;
      entry.heldItemId = itemId;
      entry.rig.toolMount.clear();
      if (itemId) {
        const mesh = createHeldItemMesh(itemId);
        if (mesh) entry.rig.toolMount.add(mesh);
      }
    };

    const visibleNpcList = Array.from(this.npcRigs.values()).filter((e) => e.rig.root.visible);

    const resolveNpcStep = (
      nx: number,
      nz: number,
      isInt: boolean,
      selfNpcId: string
    ): { x: number; z: number; blocked: boolean } => {
      let rx = nx;
      let rz = nz;
      let blocked = false;
      if (isInt) {
        rx = THREE.MathUtils.clamp(rx, -4.4, 4.4);
        rz = THREE.MathUtils.clamp(rz, -3.6, 3.4);
        for (const box of this.interiorColliders.boxes) {
          const cx = THREE.MathUtils.clamp(rx, box.minX, box.maxX);
          const cz = THREE.MathUtils.clamp(rz, box.minZ, box.maxZ);
          const dx = rx - cx;
          const dz = rz - cz;
          const d2 = dx * dx + dz * dz;
          if (d2 < 0.18) {
            blocked = true;
            if (d2 > 1e-5) {
              const d = Math.sqrt(d2);
              rx += (dx / d) * (0.42 - d);
              rz += (dz / d) * (0.42 - d);
            }
          }
        }
        return { x: rx, z: rz, blocked };
      }
      const r = 0.44;
      const coll = this.outdoorRefs?.colliders;
      if (coll) {
        for (const box of coll.boxes) {
          const cx = THREE.MathUtils.clamp(rx, box.minX, box.maxX);
          const cz = THREE.MathUtils.clamp(rz, box.minZ, box.maxZ);
          const dx = rx - cx;
          const dz = rz - cz;
          const d2 = dx * dx + dz * dz;
          if (d2 < r * r) {
            blocked = true;
            if (d2 > 1e-5) {
              const d = Math.sqrt(d2);
              rx += (dx / d) * (r - d);
              rz += (dz / d) * (r - d);
            } else {
              rx += 0.35;
            }
          }
        }
        for (const c of coll.circles) {
          const dx = rx - c.x;
          const dz = rz - c.z;
          const minD = c.radius + r;
          const d2 = dx * dx + dz * dz;
          if (d2 < minD * minD && d2 > 1e-5) {
            blocked = true;
            const d = Math.sqrt(d2);
            rx += (dx / d) * (minD - d);
            rz += (dz / d) * (minD - d);
          }
        }
      }
      if (this.outdoorRefs) {
        for (const t of this.outdoorRefs.choppableTrees) {
          if (t.chopped) continue;
          const dx = rx - t.x;
          const dz = rz - t.z;
          const minD = t.radius + r;
          const d2 = dx * dx + dz * dz;
          if (d2 < minD * minD && d2 > 1e-5) {
            blocked = true;
            const d = Math.sqrt(d2);
            rx += (dx / d) * (minD - d);
            rz += (dz / d) * (minD - d);
          }
        }
      }
      // Avoid clipping into Player, Animals, and other NPCs
      const pDx = rx - this.playerPos.x;
      const pDz = rz - this.playerPos.z;
      const pD2 = pDx * pDx + pDz * pDz;
      if (pD2 < 0.72 * 0.72 && pD2 > 1e-5) {
        blocked = true;
        const d = Math.sqrt(pD2);
        rx += (pDx / d) * (0.72 - d);
        rz += (pDz / d) * (0.72 - d);
      }
      for (const other of visibleNpcList) {
        if (other.npcId === selfNpcId || other.zone.startsWith('int_')) continue;
        const oDx = rx - other.pos.x;
        const oDz = rz - other.pos.z;
        const oD2 = oDx * oDx + oDz * oDz;
        if (oD2 < 0.78 * 0.78 && oD2 > 1e-5) {
          const d = Math.sqrt(oD2);
          rx += (oDx / d) * (0.78 - d);
          rz += (oDz / d) * (0.78 - d);
        }
      }
      if (this.animalsGroup.visible) {
        for (const actor of this.animalActors.values()) {
          if (!actor.rig.root.visible) continue;
          const aDx = rx - actor.pos.x;
          const aDz = rz - actor.pos.z;
          const minD = getAnimalRadius(actor.state.type) + r;
          const aD2 = aDx * aDx + aDz * aDz;
          if (aD2 < minD * minD && aD2 > 1e-5) {
            blocked = true;
            const d = Math.sqrt(aD2);
            rx += (aDx / d) * (minD - d);
            rz += (aDz / d) * (minD - d);
          }
        }
      }
      const onOceanPier = rz >= -9.5 && rz <= -6.5;
      const onRiverDock = rz >= 14.5 && rz <= 17.5;
      const maxX = onOceanPier ? 55.2 : onRiverDock ? 43.8 : 46.2;
      rx = THREE.MathUtils.clamp(rx, -56, maxX);
      rz = THREE.MathUtils.clamp(rz, -64, 52);
      return { x: rx, z: rz, blocked };
    };

    for (const entry of visibleNpcList) {
      const isInt = entry.zone.startsWith('int_');
      entry.phaseTimer -= dt;
      entry.bubbleCooldown -= dt;
      entry.greetCooldown = Math.max(0, entry.greetCooldown - dt);
      entry.vfxTimer = Math.max(0, entry.vfxTimer - dt);

      // Update dynamic NPC emotion based on weather, time, festival, energy, and socialization
      if (isFestivalNow && !isInt) {
        entry.emotion = 'excited';
      } else if (this.currentWeather === 'Stormy') {
        entry.emotion = 'nervous';
      } else if (this.currentHour >= 21 || entry.energy < 28) {
        entry.emotion = 'tired';
      } else if (entry.chatPartnerId) {
        entry.emotion = 'happy';
      } else if (this.currentWeather === 'Rainy' && entry.aiPhase === 'shelter') {
        entry.emotion = 'sad';
      } else if (this.currentWeather === 'Sunny' && this.currentHour >= 7 && this.currentHour <= 16) {
        entry.emotion = entry.role === 'shopkeeper' ? 'happy' : 'neutral';
      } else {
        entry.emotion = 'neutral';
      }

      const distToPlayer = Math.hypot(this.playerPos.x - entry.pos.x, this.playerPos.z - entry.pos.z);

      // 1) Active NPC-to-NPC conversation override
      if (entry.chatPartnerId) {
        const partner = this.npcRigs.get(entry.chatPartnerId);
        entry.chatTimer -= dt;
        if (!partner || !partner.rig.root.visible || entry.chatTimer <= 0) {
          entry.chatPartnerId = null;
          entry.isTalking = false;
        } else {
          entry.targetPos.copy(entry.pos);
          entry.yaw = Math.atan2(partner.pos.x - entry.pos.x, partner.pos.z - entry.pos.z);
          entry.activePose = 'chat';
          entry.isTalking = true;
          equipNpcItem(entry, null);
        }
      }

      // Friendly pass-by player greeting in player's active language!
      if (
        !this.isTitleMode &&
        distToPlayer < 4.5 &&
        entry.greetCooldown <= 0 &&
        entry.activity !== 'sleep' &&
        !entry.chatPartnerId
      ) {
        entry.greetCooldown = 28 + Math.random() * 18;
        entry.activePose = 'wave';
        this.callbacks.onNpcAmbientBubble?.(
          entry.npcId,
          entry.npcName,
          localizeNpcGreetingBubble(
            this.language,
            this.currentHour,
            this.currentWeather
          ),
          isFestivalNow ? 'excited' : 'happy',
          false
        );
      }

      let anim: 'idle' | 'walk' | 'work' | 'festival' | 'sleep' =
        entry.activity === 'sleep' ? 'sleep' : 'idle';
      let npcWorkStyle: LocomotionInput['workStyle'] = 'chop';
      let npcWorkProg = (elapsed * 1.65) % 1;
      let moveSpeed = isRainOrStorm && !isInt ? 2.65 : 1.95;

      // 2) Autonomous Profession State Machines (outdoor daytime when not in festival or chat)
      if (!entry.chatPartnerId && !isInt && inOutdoor && !isFestivalNow && entry.activity !== 'sleep') {
        if (entry.role === 'miner') {
          // MINER AI: Wake -> Mine Ore (hammer) -> Carry Ore to Blacksmith Forge -> Rest -> Shelter in Storm/Rain
          if (isRainOrStorm) {
            entry.aiPhase = 'shelter';
            entry.targetPos.set(5.5, 0, -33.5);
            equipNpcItem(entry, null);
            entry.activePose = 'ponder';
          } else if (this.currentHour >= 12 && this.currentHour < 14) {
            entry.aiPhase = 'rest';
            entry.targetPos.set(4.0, 0, -28.0);
            equipNpcItem(entry, null);
            entry.activePose = 'yawn';
            entry.energy = Math.min(100, entry.energy + dt * 6);
          } else if (this.currentHour >= 6 && this.currentHour < 19) {
            if (entry.aiPhase !== 'work' && entry.aiPhase !== 'carry') {
              entry.aiPhase = 'work';
              entry.phaseTimer = 11 + Math.random() * 6;
              entry.spotIndex = (entry.spotIndex + 1) % mineNodes.length;
            }
            if (entry.aiPhase === 'work') {
              // Activity Validation & Precise Object Detection: pick unclaimed valid mine_rock & face rock directly!
              let spot = mineNodes[entry.spotIndex % mineNodes.length];
              if (claimedTargets.has(spot.id) && mineNodes.length > 1) {
                const altIdx = mineNodes.findIndex((m) => !claimedTargets.has(m.id));
                if (altIdx >= 0) {
                  entry.spotIndex = altIdx;
                  spot = mineNodes[altIdx];
                }
              }
              claimedTargets.add(spot.id);
              entry.targetPos.set(spot.standX, 0, spot.standZ);
              const d = Math.hypot(spot.standX - entry.pos.x, spot.standZ - entry.pos.z);
              if (d < 1.15) {
                // Face exact ore rock before starting mining animation!
                entry.yaw = Math.atan2(spot.x - entry.pos.x, spot.z - entry.pos.z);
                equipNpcItem(entry, 'tool_hammer');
                anim = 'work';
                npcWorkStyle = 'hammer';
                entry.energy = Math.max(15, entry.energy - dt * 1.4);
                if (entry.vfxTimer <= 0 && distToPlayer < 26) {
                  this.spawnImpactVfx('stone', spot.x, 0.55, spot.z, 5);
                  entry.vfxTimer = 0.85;
                }
                if (entry.phaseTimer <= 0) {
                  entry.aiPhase = 'carry';
                  entry.phaseTimer = 14;
                }
              } else {
                equipNpcItem(entry, 'tool_hammer');
              }
            } else if (entry.aiPhase === 'carry') {
              // Carry mined ore to Blacksmith forge storage
              const forgeX = 6.2;
              const forgeZ = -32.8;
              entry.targetPos.set(forgeX, 0, forgeZ);
              equipNpcItem(entry, 'copper_ore');
              npcWorkStyle = 'carry';
              moveSpeed = 1.45;
              const d = Math.hypot(forgeX - entry.pos.x, forgeZ - entry.pos.z);
              if (d < 1.3 || entry.phaseTimer <= 0) {
                if (entry.bubbleCooldown <= 0 && distToPlayer < 16) {
                  this.callbacks.onNpcAmbientBubble?.(
                    entry.npcId,
                    entry.npcName,
                    pickNpcAmbientLine('profession_miner', { playerName: this.localAvatarName, npcName: entry.npcName }),
                    'happy',
                    false
                  );
                  entry.bubbleCooldown = 26 + Math.random() * 14;
                }
                entry.aiPhase = 'work';
                entry.spotIndex = (entry.spotIndex + 1) % mineNodes.length;
                entry.phaseTimer = 12 + Math.random() * 6;
              }
            }
          } else {
            entry.aiPhase = 'rest';
            entry.targetPos.copy(entry.homeTargetPos);
            equipNpcItem(entry, null);
          }
        } else if (entry.role === 'lumberjack') {
          // LUMBERJACK AI: Strictly detect live standing non-stump forest tree -> walk to exact interaction point -> face tree -> chop!
          if (isRainOrStorm) {
            entry.aiPhase = 'shelter';
            entry.targetPos.set(-18, 0, 22);
            equipNpcItem(entry, null);
            entry.activePose = 'stretch';
          } else if (this.currentHour >= 13 && this.currentHour < 15) {
            entry.aiPhase = 'rest';
            entry.targetPos.set(-8, 0, 20);
            equipNpcItem(entry, null);
            entry.activePose = 'yawn';
            entry.energy = Math.min(100, entry.energy + dt * 6);
          } else if (this.currentHour >= 6 && this.currentHour < 18) {
            const forestTrees = (this.outdoorRefs?.globalTrees || []).filter(
              (t) => !t.chopped && !t.isStump && t.zone === 'forest' && t.z >= 27 && t.z <= 47 && t.x >= -28 && t.x <= 20
            );
            if (entry.aiPhase !== 'work' && entry.aiPhase !== 'carry') {
              entry.aiPhase = 'work';
              entry.phaseTimer = 11 + Math.random() * 6;
              if (forestTrees.length > 0) {
                entry.spotIndex = (entry.spotIndex + 1 + Math.floor(Math.random() * 3)) % forestTrees.length;
              }
            }
            if (entry.aiPhase === 'work') {
              if (forestTrees.length === 0) {
                // Smart failure handling: no valid standing tree -> switch to rest/patrol
                entry.aiPhase = 'ambient';
                entry.phaseTimer = 4;
                equipNpcItem(entry, null);
              } else {
                let targetTree = forestTrees[entry.spotIndex % forestTrees.length];
                if (claimedTargets.has(targetTree.id) && forestTrees.length > 1) {
                  const freeIdx = forestTrees.findIndex((t) => !claimedTargets.has(t.id));
                  if (freeIdx >= 0) {
                    entry.spotIndex = freeIdx;
                    targetTree = forestTrees[freeIdx];
                  }
                }
                claimedTargets.add(targetTree.id);
                const standDist = targetTree.radius + 0.92;
                const standX = targetTree.x - standDist * 0.72;
                const standZ = targetTree.z - standDist * 0.68;
                entry.targetPos.set(standX, 0, standZ);
                const d = Math.hypot(standX - entry.pos.x, standZ - entry.pos.z);
                equipNpcItem(entry, 'tool_axe');
                if (d < 1.15) {
                  // Face exact tree trunk before chopping!
                  entry.yaw = Math.atan2(targetTree.x - entry.pos.x, targetTree.z - entry.pos.z);
                  anim = 'work';
                  npcWorkStyle = 'chop';
                  entry.energy = Math.max(15, entry.energy - dt * 1.4);
                  if (entry.vfxTimer <= 0 && distToPlayer < 26) {
                    this.spawnImpactVfx('wood', targetTree.x, 0.9, targetTree.z, 5);
                    entry.vfxTimer = 0.8;
                  }
                  if (entry.phaseTimer <= 0) {
                    entry.aiPhase = 'carry';
                    entry.phaseTimer = 15;
                  }
                }
              }
            } else if (entry.aiPhase === 'carry') {
              // Carry harvested wood back toward village carpenter depot
              const depotX = -16;
              const depotZ = 18;
              entry.targetPos.set(depotX, 0, depotZ);
              equipNpcItem(entry, 'wood');
              npcWorkStyle = 'carry';
              moveSpeed = 1.45;
              const d = Math.hypot(depotX - entry.pos.x, depotZ - entry.pos.z);
              if (d < 1.5 || entry.phaseTimer <= 0) {
                if (entry.bubbleCooldown <= 0 && distToPlayer < 16) {
                  this.callbacks.onNpcAmbientBubble?.(
                    entry.npcId,
                    entry.npcName,
                    pickNpcAmbientLine('profession_lumberjack', { playerName: this.localAvatarName, npcName: entry.npcName }),
                    'happy',
                    false
                  );
                  entry.bubbleCooldown = 28 + Math.random() * 14;
                }
                entry.aiPhase = 'ambient';
                entry.phaseTimer = 4;
              }
            }
          } else {
            entry.aiPhase = 'rest';
            entry.targetPos.copy(entry.homeTargetPos);
            equipNpcItem(entry, null);
          }
        } else if (entry.role === 'angler') {
          // ANGLER AI: Rotate River Dock / Riverbank / Ocean Pier fishing spots -> Cast/Wait/Reel -> Visit Market
          if (isRainOrStorm && this.currentWeather === 'Stormy') {
            entry.aiPhase = 'shelter';
            entry.targetPos.set(16, 0, 2);
            equipNpcItem(entry, null);
          } else if (this.currentHour >= 6 && this.currentHour < 20) {
            if (entry.aiPhase !== 'fish' && entry.aiPhase !== 'carry') {
              entry.aiPhase = 'fish';
              entry.spotIndex = (entry.spotIndex + 1) % anglerSpots.length;
              entry.phaseTimer = 18 + Math.random() * 10;
            }
            if (entry.aiPhase === 'fish') {
              const spot = anglerSpots[entry.spotIndex % anglerSpots.length];
              entry.targetPos.set(spot.x, 0, spot.z);
              equipNpcItem(entry, 'tool_fishing_rod');
              const d = Math.hypot(spot.x - entry.pos.x, spot.z - entry.pos.z);
              if (d < 1.2) {
                entry.yaw = spot.faceYaw;
                entry.fishCycleTimer = (entry.fishCycleTimer + dt) % 10;
                anim = 'work';
                if (entry.fishCycleTimer < 1.1) {
                  npcWorkStyle = 'fish_cast';
                  npcWorkProg = entry.fishCycleTimer / 1.1;
                } else if (entry.fishCycleTimer < 7.6) {
                  npcWorkStyle = 'fish_wait';
                } else {
                  npcWorkStyle = 'fish_reel';
                  if (entry.vfxTimer <= 0 && distToPlayer < 26) {
                    this.spawnImpactVfx('water', spot.x + 2.2, 0.12, spot.z, 6);
                    entry.vfxTimer = 0.7;
                  }
                }
                if (entry.phaseTimer <= 0) {
                  entry.aiPhase = 'carry';
                  entry.phaseTimer = 16;
                }
              }
            } else if (entry.aiPhase === 'carry') {
              // Bring freshly caught fish to Town Square Market
              entry.targetPos.set(10, 0, 4);
              equipNpcItem(entry, 'river_trout');
              const d = Math.hypot(10 - entry.pos.x, 4 - entry.pos.z);
              if (d < 1.6 || entry.phaseTimer <= 0) {
                if (entry.bubbleCooldown <= 0 && distToPlayer < 16) {
                  this.callbacks.onNpcAmbientBubble?.(
                    entry.npcId,
                    entry.npcName,
                    pickNpcAmbientLine('profession_angler', { playerName: this.localAvatarName, npcName: entry.npcName }),
                    'excited',
                    false
                  );
                  entry.bubbleCooldown = 28 + Math.random() * 12;
                }
                entry.aiPhase = 'fish';
                entry.spotIndex = (entry.spotIndex + 1 + Math.floor(Math.random() * 2)) % anglerSpots.length;
                entry.phaseTimer = 18 + Math.random() * 10;
              }
            }
          } else {
            entry.aiPhase = 'rest';
            entry.targetPos.copy(entry.homeTargetPos);
            equipNpcItem(entry, null);
          }
        } else if (entry.role === 'shopkeeper') {
          // SHOPKEEPER AI: Open shop on schedule -> Welcome approaching player -> Tidy shelves when quiet
          equipNpcItem(entry, null);
          if (this.currentHour >= 8 && this.currentHour < 20) {
            entry.targetPos.copy(entry.homeTargetPos);
            const dHome = Math.hypot(entry.homeTargetPos.x - entry.pos.x, entry.homeTargetPos.z - entry.pos.z);
            if (dHome < 1.4) {
              if (distToPlayer < 5.2) {
                entry.aiPhase = 'shop_serve';
                entry.activePose = 'wave';
                entry.emotion = 'happy';
                entry.yaw = Math.atan2(this.playerPos.x - entry.pos.x, this.playerPos.z - entry.pos.z);
                if (entry.greetCooldown <= 0) {
                  this.callbacks.onNpcAmbientBubble?.(
                    entry.npcId,
                    entry.npcName,
                    pickNpcAmbientLine('shop_welcome', {
                      playerName: this.localAvatarName,
                      npcName: entry.npcName,
                    }),
                    'happy',
                    false
                  );
                  entry.greetCooldown = 36;
                }
              } else {
                entry.aiPhase = 'shop_tidy';
                anim = 'work';
                npcWorkStyle = 'tidy';
                if (entry.bubbleCooldown <= 0 && distToPlayer < 14) {
                  this.callbacks.onNpcAmbientBubble?.(
                    entry.npcId,
                    entry.npcName,
                    pickNpcAmbientLine('shop_tidy', { npcName: entry.npcName }),
                    'neutral',
                    true
                  );
                  entry.bubbleCooldown = 34 + Math.random() * 18;
                }
              }
            }
          } else {
            entry.aiPhase = 'rest';
            entry.targetPos.copy(entry.homeTargetPos);
            entry.activePose = 'yawn';
          }
        }
      }

      // 3) Standard Villager & Interior Ambient Roaming + Bench Sitting + NPC-to-NPC Chat
      const handledByProfession =
        !isInt &&
        inOutdoor &&
        !isFestivalNow &&
        entry.activity !== 'sleep' &&
        entry.role !== 'villager' &&
        !entry.chatPartnerId;

      if (!handledByProfession && !entry.chatPartnerId) {
        equipNpcItem(entry, null);
        const canRoam = entry.activity !== 'work' && entry.activity !== 'sleep' && entry.activity !== 'festival';
        if (canRoam) {
          entry.wanderTimer -= dt;
          if (entry.wanderTimer <= 0) {
            entry.benchIndex = null;
            const roll = Math.random();
            if (!isInt && roll < 0.22 && Math.hypot(entry.pos.x - 4, entry.pos.z) < 22) {
              // Sit on an unoccupied Town Square Park Bench!
              const usedBenches = new Set(visibleNpcList.map((n) => n.benchIndex).filter((b) => b !== null));
              const freeIdx = TOWN_SQUARE_BENCHES.findIndex((_, idx) => !usedBenches.has(idx));
              if (freeIdx >= 0) {
                const bench = TOWN_SQUARE_BENCHES[freeIdx];
                entry.benchIndex = freeIdx;
                entry.targetPos.set(bench.x, 0, bench.z);
                entry.activePose = 'sit';
                entry.wanderTimer = 11 + Math.random() * 8;
              } else {
                entry.wanderTimer = 3.5;
              }
            } else if (roll < 0.7) {
              const radius = isInt ? 2.1 : 6.2;
              const angle = Math.random() * Math.PI * 2;
              const distR = (0.35 + Math.random() * 0.65) * radius;
              let nx = entry.homeTargetPos.x + Math.cos(angle) * distR;
              let nz = entry.homeTargetPos.z + Math.sin(angle) * distR;
              if (isInt) {
                nx = THREE.MathUtils.clamp(nx, -4.1, 4.1);
                nz = THREE.MathUtils.clamp(nz, -3.4, 3.1);
              }
              entry.targetPos.set(nx, 0, nz);
              entry.activePose = entry.idlePose;
              entry.wanderTimer = 4.5 + Math.random() * 5.2;
            } else {
              entry.targetPos.copy(entry.pos);
              entry.activePose = randomIdlePool[Math.floor(Math.random() * randomIdlePool.length)];
              entry.yaw += (Math.random() - 0.5) * 1.4;
              entry.wanderTimer = 3.6 + Math.random() * 4.4;
              // Occasional ambient thought bubble when near player
              if (entry.bubbleCooldown <= 0 && distToPlayer < 13) {
                this.callbacks.onNpcAmbientBubble?.(
                  entry.npcId,
                  entry.npcName,
                  pickNpcAmbientLine('ambient_thought', {
                    playerName: this.localAvatarName,
                    npcName: entry.npcName,
                    season: this.currentSeason,
                    weather: this.currentWeather,
                  }),
                  entry.emotion,
                  true
                );
                entry.bubbleCooldown = 32 + Math.random() * 24;
              }
            }
          }

          // Check for organic NPC-to-NPC conversation when two roaming villagers pass nearby!
          if (!isInt && entry.benchIndex === null && entry.bubbleCooldown <= 0) {
            for (const other of visibleNpcList) {
              if (
                other.npcId === entry.npcId ||
                other.chatPartnerId ||
                other.benchIndex !== null ||
                other.zone.startsWith('int_') ||
                other.activity === 'sleep'
              ) {
                continue;
              }
              const pairDist = Math.hypot(other.pos.x - entry.pos.x, other.pos.z - entry.pos.z);
              if (pairDist > 1.1 && pairDist < 3.1) {
                entry.chatPartnerId = other.npcId;
                other.chatPartnerId = entry.npcId;
                entry.chatTimer = 6.5;
                other.chatTimer = 6.5;
                entry.bubbleCooldown = 35 + Math.random() * 20;
                other.bubbleCooldown = 35 + Math.random() * 20;
                if (distToPlayer < 17) {
                  this.callbacks.onNpcAmbientBubble?.(
                    entry.npcId,
                    entry.npcName,
                    pickNpcAmbientLine('npc_to_npc_greet', { partnerName: other.npcName }),
                    'happy',
                    false
                  );
                  this.callbacks.onNpcAmbientBubble?.(
                    other.npcId,
                    other.npcName,
                    pickNpcAmbientLine('npc_to_npc_reply', { partnerName: entry.npcName }),
                    'happy',
                    false
                  );
                }
                break;
              }
            }
          }
        } else {
          entry.activePose = entry.idlePose;
        }
      }

      // 4) Obstacle-Avoiding Movement, Stuck Recovery & Ground/Bridge Traversal
      const dx = entry.targetPos.x - entry.pos.x;
      const dz = entry.targetPos.z - entry.pos.z;
      const dist = Math.hypot(dx, dz);
      let horizSpeed = 0;

      if (dist > 0.3) {
        const step = Math.min(dist, moveSpeed * dt);
        const baseAngle = Math.atan2(dx, dz);
        const steerAngles = [0, 0.58, -0.58, 1.22, -1.22];
        let movedNpc = false;
        let finalAngle = baseAngle;
        for (const offset of steerAngles) {
          const testAng = baseAngle + offset;
          const res = resolveNpcStep(
            entry.pos.x + Math.sin(testAng) * step,
            entry.pos.z + Math.cos(testAng) * step,
            isInt,
            entry.npcId
          );
          if (!res.blocked) {
            entry.pos.x = res.x;
            entry.pos.z = res.z;
            finalAngle = testAng;
            movedNpc = true;
            break;
          }
        }
        if (movedNpc) {
          entry.stuckTimer = Math.max(0, entry.stuckTimer - dt);
          let yDiff = finalAngle - entry.yaw;
          while (yDiff > Math.PI) yDiff -= Math.PI * 2;
          while (yDiff < -Math.PI) yDiff += Math.PI * 2;
          entry.yaw += yDiff * (1 - Math.exp(-8.5 * dt));
        } else {
          entry.stuckTimer += dt;
          if (entry.stuckTimer > 1.8) {
            entry.targetPos.copy(entry.pos);
            entry.stuckTimer = 0;
            entry.wanderTimer = 1.0;
          }
        }
        horizSpeed = movedNpc ? moveSpeed : 0;
        if (entry.aiPhase === 'carry') {
          anim = 'work';
          npcWorkStyle = 'carry';
        } else if (movedNpc) {
          anim = 'walk';
        }
      } else {
        if (entry.benchIndex !== null && TOWN_SQUARE_BENCHES[entry.benchIndex]) {
          entry.yaw = TOWN_SQUARE_BENCHES[entry.benchIndex].rotY;
          entry.activePose = 'sit';
          anim = 'idle';
        } else if (entry.activity === 'festival' || (isFestivalNow && !isInt && Math.hypot(entry.pos.x - 4, entry.pos.z) < 18)) {
          anim = 'festival';
        } else if (anim === 'idle' && entry.activity === 'work' && entry.role === 'villager') {
          anim = 'work';
        }
      }

      // Bridge / Deck / Bench surface Y grounding for NPCs
      const npcBaseY = isInt ? 0 : this.getGroundSurfaceY(entry.pos.x, entry.pos.z, entry.pos.y);
      entry.pos.y = entry.activePose === 'sit' && entry.benchIndex !== null ? 0.34 : npcBaseY;

      // 5) Head Tracking & Eye Contact toward nearby Player, Chat Partner, or World Sound/Activity Source!
      let headTargetYaw: number | undefined;
      let headTargetPitch: number | undefined;
      if (distToPlayer < 6.0 && !entry.chatPartnerId && entry.activity !== 'sleep') {
        const toPlayerYaw = Math.atan2(this.playerPos.x - entry.pos.x, this.playerPos.z - entry.pos.z);
        let relYaw = toPlayerYaw - entry.yaw;
        while (relYaw > Math.PI) relYaw -= Math.PI * 2;
        while (relYaw < -Math.PI) relYaw += Math.PI * 2;
        if (Math.abs(relYaw) < 1.35) {
          headTargetYaw = THREE.MathUtils.clamp(relYaw, -0.72, 0.72);
          headTargetPitch = THREE.MathUtils.clamp((entry.pos.y - this.playerPos.y) * 0.15, -0.22, 0.22);
        }
      } else if (
        this.lastSoundSourcePos &&
        elapsed < this.lastSoundSourceUntil &&
        !entry.chatPartnerId &&
        entry.activity !== 'sleep'
      ) {
        const sd = Math.hypot(this.lastSoundSourcePos.x - entry.pos.x, this.lastSoundSourcePos.z - entry.pos.z);
        if (sd > 0.6 && sd < 14) {
          const toSoundYaw = Math.atan2(this.lastSoundSourcePos.x - entry.pos.x, this.lastSoundSourcePos.z - entry.pos.z);
          let relYaw = toSoundYaw - entry.yaw;
          while (relYaw > Math.PI) relYaw -= Math.PI * 2;
          while (relYaw < -Math.PI) relYaw += Math.PI * 2;
          headTargetYaw = THREE.MathUtils.clamp(relYaw, -0.75, 0.75);
        }
      }

      // Emit subtle cold-weather mouth breath steam when NPCs speak outdoors during Winter / Snowy weather
      if (
        !isInt &&
        (this.currentSeason === 'Winter' || this.currentWeather === 'Snowy') &&
        (entry.isTalking || entry.activePose === 'chat') &&
        distToPlayer < 24 &&
        entry.vfxTimer <= 0
      ) {
        this.emitWinterBreathSteam(entry.pos.x, entry.pos.y, entry.pos.z, entry.yaw, 2);
        entry.vfxTimer = 0.65 + Math.random() * 0.35;
      }

      entry.rig.root.position.copy(entry.pos);
      entry.rig.root.rotation.y = entry.yaw;
      animateChibiRig(entry.rig, anim, elapsed, dt, entry.activePose, CHARACTER_ANIM_CONFIG.npcIdleSpeed, {
        horizontalSpeed: horizSpeed,
        maxSpeed: 4.5,
        verticalVel: 0,
        groundHeight: 0,
        gaitPhase: elapsed * 7.8 + entry.spotIndex,
        turnRate: 0,
        landSquash: 0,
        dashWeight: 0,
        workStyle: npcWorkStyle,
        workProgress: npcWorkProg,
        headTargetYaw,
        headTargetPitch,
        emotion: entry.emotion,
        isTalking: entry.isTalking,
        weather: this.currentWeather,
        hour: this.currentHour,
      });
    }

    // Animate Remote Players
    for (const entry of this.remoteRigs.values()) {
      entry.fadeIn = Math.min(1, (entry.fadeIn ?? 1) + dt * 2.8);
      const appearScale = 0.82 + 0.18 * (entry.fadeIn ?? 1);
      entry.rig.root.scale.setScalar(appearScale);
      entry.pos.x = THREE.MathUtils.damp(entry.pos.x, entry.targetPos.x, 10, dt);
      entry.pos.y = THREE.MathUtils.damp(entry.pos.y, entry.targetPos.y, 12, dt);
      entry.pos.z = THREE.MathUtils.damp(entry.pos.z, entry.targetPos.z, 10, dt);
      entry.rig.root.position.copy(entry.pos);
      entry.rig.root.rotation.y = entry.yaw;
      animateChibiRig(entry.rig, entry.player.animState || 'idle', elapsed, dt);
    }

    // === LIVING ANIMAL AI, COLLISION, NAVIGATION, EMOTION & VISUAL ANIMATION ENGINE ===
    if (this.animalsGroup.visible && this.animalActors.size > 0) {
      const inInteriorAnimal =
        this.currentZone === 'int_barn' || this.currentZone === 'int_coop' || this.currentZone === 'int_stable';
      const activeAnimalColliders = inInteriorAnimal
        ? this.interiorColliders
        : this.outdoorRefs?.colliders || { boxes: [], circles: [] };
      const activeTreeCircles =
        !inInteriorAnimal && this.outdoorRefs
          ? this.outdoorRefs.choppableTrees.filter((t) => !t.chopped)
          : [];
      const npcPosList = visibleNpcList.map((n) => ({ x: n.pos.x, z: n.pos.z }));

      updateLivingAnimals(this.animalActors, {
        dt,
        elapsed,
        zone: this.currentZone,
        season: this.currentSeason,
        weather: this.currentWeather,
        hour: this.currentHour,
        language: this.language,
        playerPos: this.playerPos,
        playerSpeed: Math.hypot(this.playerVelX, this.playerVelZ),
        npcPositions: npcPosList,
        colliders: activeAnimalColliders,
        treeCircles: activeTreeCircles,
        farmObstacleCircles: this.farmObstacleColliders,
        barnLocked: this.barnLocked,
        coopLocked: this.coopLocked,
        stableLocked: this.stableLocked,
        getGroundY: (x, z) => (inInteriorAnimal ? 0 : this.getGroundSurfaceY(x, z, 0)),
        onAnimalBubble: (animalId, animalName, text, isThought) => {
          this.callbacks.onAnimalAmbientBubble?.(animalId, animalName, text, Boolean(isThought));
        },
        onFootprint: (x, z, yaw, size, isSnow) => {
          this.spawnAnimalFootprint(x, z, yaw, size, isSnow);
        },
      });
    }

    // Fade out Mud/Snow Animal Footprints smoothly
    for (let i = this.animalFootprints.length - 1; i >= 0; i--) {
      const fp = this.animalFootprints[i];
      fp.life -= dt;
      if (fp.life <= 0) {
        this.scene.remove(fp.mesh);
        fp.mesh.geometry.dispose();
        (fp.mesh.material as THREE.Material).dispose();
        this.animalFootprints.splice(i, 1);
      } else {
        (fp.mesh.material as THREE.MeshBasicMaterial).opacity = Math.min(0.32, fp.life * 0.06);
      }
    }

    if (this.composer && this.bloomPass?.enabled && !this.isSoftwareGl) {
      this.composer.render();
    } else {
      this.renderer.render(this.scene, this.camera);
    }

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private runOutdoorOcclusionPass() {
    if (!this.outdoorRefs) return;
    this.camera.updateMatrixWorld();
    _projScreenMat.multiplyMatrices(this.camera.projectionMatrix, this.camera.matrixWorldInverse);
    _frustum.setFromProjectionMatrix(_projScreenMat);

    const cx = this.camera.position.x;
    const cy = this.camera.position.y;
    const cz = this.camera.position.z;
    const lowPowerCap = this.performanceConfig.lowPower4GbMode && this.isLowPowerDevice;
    const maxDist = lowPowerCap ? 78 : this.performanceConfig.lowPower4GbMode ? 115 : 150;
    const maxDistSq = maxDist * maxDist;
    const occluders = this.outdoorRefs.cameraOccluders;
    const targets = this.outdoorRefs.occlusionTargets;

    for (let i = 0; i < targets.length; i++) {
      const t = targets[i];
      if (t.shouldBeVisible && !t.shouldBeVisible()) {
        t.obj.visible = false;
        continue;
      }
      const dx = t.x - cx;
      const dy = t.y - cy;
      const dz = t.z - cz;
      const distSq = dx * dx + dy * dy + dz * dz;
      const hillDistBoost = t.category === 'hill' ? 2.1 : 1.0;
      if (distSq > maxDistSq * hillDistBoost * hillDistBoost) {
        t.obj.visible = false;
        continue;
      }
      // Frustum check with conservative margin so shadows & canopies near frustum border don't pop
      _projVec.set(t.x, t.y, t.z);
      if (distSq > 225 && !_frustum.containsPoint(_projVec)) {
        // Check quick angle approximation with target radius before hiding
        const invDist = 1 / Math.sqrt(distSq);
        const fx = -Math.sin(this.smoothCamYaw) * Math.cos(this.smoothCamPitch);
        const fz = -Math.cos(this.smoothCamYaw) * Math.cos(this.smoothCamPitch);
        // Camera forward is -dir
        const dot = (dx * -fx + dz * -fz) * invDist;
        if (dot < 0.25 && t.radius < 4.5) {
          t.obj.visible = false;
          continue;
        }
      }

      // Ray-AABB Occlusion test against baked opaque building & cliff occluders
      let occluded = false;
      if (distSq > 100 && t.category !== 'hill') {
        for (let b = 0; b < occluders.length; b++) {
          const box = occluders[b];
          // Quick distance skip if target is closer than box center
          const boxCx = (box.minX + box.maxX) * 0.5;
          const boxCz = (box.minZ + box.maxZ) * 0.5;
          const boxDistSq = (boxCx - cx) * (boxCx - cx) + (boxCz - cz) * (boxCz - cz);
          if (boxDistSq >= distSq) continue;

          let tMin = 0;
          let tMax = 1;
          const hitAxis = (orig: number, delta: number, bMin: number, bMax: number): boolean => {
            if (Math.abs(delta) < 1e-6) return orig >= bMin && orig <= bMax;
            let t1 = (bMin - orig) / delta;
            let t2 = (bMax - orig) / delta;
            if (t1 > t2) {
              const tmp = t1;
              t1 = t2;
              t2 = tmp;
            }
            if (t1 > tMin) tMin = t1;
            if (t2 < tMax) tMax = t2;
            return tMin <= tMax;
          };

          if (
            hitAxis(cx, dx, box.minX + 0.35, box.maxX - 0.35) &&
            hitAxis(cy, dy, 0, box.maxY - 0.35) &&
            hitAxis(cz, dz, box.minZ + 0.35, box.maxZ - 0.35)
          ) {
            if (tMin > 0.04 && tMin < 0.9) {
              occluded = true;
              break;
            }
          }
        }
      }
      t.obj.visible = !occluded;
    }
  }

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    window.removeEventListener('resize', this.onResize);
    const dom = this.renderer.domElement;
    dom.removeEventListener('pointerdown', this.onPointerDown);
    window.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerup', this.onPointerUp);
    dom.removeEventListener('wheel', this.onWheel);
    this.composer?.dispose();
    this.envMapTexture?.dispose();
    this.renderer.dispose();
    if (dom.parentNode === this.container) {
      this.container.removeChild(dom);
    }
  }
}
