import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import {
  APPLE_TREE_POS,
  BUILDING_PORTALS,
  BuildingPortal,
  DOGHOUSE_POS,
  DOG_FOOD_BOWL_POS,
  FARM_GRID_COLS,
  FARM_GRID_ROWS,
  FARM_ORIGIN_X,
  FARM_ORIGIN_Z,
  FARM_TILE_STEP,
  SHIPPING_BIN_POS,
  TREE_SPECIES,
  getBarnCapacity,
  getCoopCapacity,
  getIncubatorCount,
} from '../data/worldConfig';
import { EggIncubatorSlot, Season, WorldTreeRecord, WorldZoneId } from '../types';
import {
  createCanvasTexture,
  createDistinctTreeLodMesh,
  createDistinctTreeMesh,
  createTreeStumpMesh,
  getStdMat,
} from './AssetFactory';
import { glbAssets } from './GLBAssetManager';

export interface AABBCollider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  /** True for 3D fences, park benches, crates, and low props that players can jump onto/over */
  jumpable?: boolean;
  /** Optional low step-over height tolerance (m) for smooth traversal */
  stepHeight?: number;
  /** Standable top surface height (m) when player jumps onto the prop */
  topY?: number;
}

export interface CameraOccluderBox extends AABBCollider {
  maxY: number;
}

export interface OcclusionTarget {
  id: string;
  obj: THREE.Object3D;
  x: number;
  y: number;
  z: number;
  radius: number;
  category: 'tree' | 'prop' | 'hill';
  shouldBeVisible?: () => boolean;
}

export interface InteriorBuildOptions {
  coopLevel?: number;
  barnLevel?: number;
  hasCheeseMaker?: boolean;
  coopIncubators?: EggIncubatorSlot[];
}

export interface CircleCollider {
  x: number;
  z: number;
  radius: number;
  /** True when player can jump onto and stand atop this cylindrical prop (log, rock, stump) */
  jumpable?: boolean;
  /** Standable top surface height (m) */
  topY?: number;
}

export interface WorldColliders {
  boxes: AABBCollider[];
  circles: CircleCollider[];
}

export interface ChoppableTreeNode {
  id: string;
  x: number;
  z: number;
  radius: number;
  scope: 'global' | 'farm';
  zone: WorldTreeRecord['zone'];
  model: 'oak' | 'pine' | 'birch';
  level: 1 | 2 | 3 | 4;
  mesh?: THREE.Group;
  stumpMesh?: THREE.Group;
  crownMats: THREE.MeshStandardMaterial[];
  chopped: boolean;
  isStump?: boolean;
  scale?: number;
  /** Standable top Y when tree has been chopped down into a stump */
  topY?: number;
}

export const TOWN_SQUARE_BENCHES: ReadonlyArray<{ x: number; z: number; rotY: number }> = [
  { x: -2.5, z: 0, rotY: Math.PI / 2 },
  { x: 10.5, z: 0, rotY: -Math.PI / 2 },
  { x: 4, z: -6.2, rotY: 0 },
  { x: 4, z: 6.2, rotY: Math.PI },
];

export interface GlbTreeInstancePool {
  trunk: THREE.InstancedMesh;
  crown: THREE.InstancedMesh;
  crownMat: THREE.MeshStandardMaterial;
  capacity: number;
}

export interface InteractiveWorldNode {
  id: string;
  kind:
    | 'door'
    | 'shipping_bin'
    | 'harvest_apple_honey'
    | 'sleep_bed'
    | 'use_tv'
    | 'use_fridge'
    | 'use_toolbox'
    | 'use_wardrobe'
    | 'exit_door'
    | 'mine_rock'
    | 'cave_ore'
    | 'cave_ladder_down'
    | 'forest_log'
    | 'chop_tree'
    | 'fishing_spot'
    | 'secret_gate'
    | 'dog_bowl'
    | 'egg_incubator'
    | 'cheese_maker'
    | 'signboard';
  label: string;
  x: number;
  z: number;
  radius: number;
  targetZone?: WorldZoneId;
  portalId?: string;
  spotType?: 'river' | 'ocean';
  slotIndex?: number;
  signTitle?: string;
  signText?: string;
  mesh?: THREE.Object3D;
}

export interface WorldSignboardRef {
  id: string;
  portalId: string;
  title: string;
  text: string;
  x: number;
  y: number;
  z: number;
  mesh: THREE.Group;
}

export interface OutdoorWorldRefs {
  group: THREE.Group;
  groundMat: THREE.MeshStandardMaterial;
  choppableTrees: ChoppableTreeNode[];
  globalTrees: ChoppableTreeNode[];
  farmTrees: ChoppableTreeNode[];
  globalTreePools: Record<'oak' | 'pine' | 'birch', GlbTreeInstancePool>;
  farmTreesGroup: THREE.Group;
  valleyTreeCount: number;
  farmTreeOwnerKey: string;
  grassInstanced: THREE.InstancedMesh;
  grassUniformTime: { value: number };
  waterMesh: THREE.Mesh;
  brookMesh: THREE.Mesh;
  waterTex: THREE.CanvasTexture;
  windowMats: THREE.MeshStandardMaterial[];
  interactives: InteractiveWorldNode[];
  signboards: WorldSignboardRef[];
  colliders: WorldColliders;
  cameraOccluders: CameraOccluderBox[];
  occlusionTargets: OcclusionTarget[];
  maxGrassCount: number;
  festivalDecorGroup: THREE.Group;
  secretBarrier: THREE.Group;
  appleTreeGroup: THREE.Group;
  beehiveGroup: THREE.Group;
  beePoints: THREE.Points;
}

function buildGlbInstancedTreePool(
  modelType: 'oak' | 'pine' | 'birch',
  capacity: number,
  maxAnisotropy: number
): GlbTreeInstancePool {
  const { mesh: sample } = createDistinctTreeMesh(modelType, '#4f9c3b', maxAnisotropy);
  sample.updateMatrixWorld(true);
  const trunkGeos: THREE.BufferGeometry[] = [];
  const crownGeos: THREE.BufferGeometry[] = [];
  let trunkMat: THREE.MeshStandardMaterial = getStdMat('#6b4423', 0.92, 0.02);
  let crownMat: THREE.MeshStandardMaterial = getStdMat('#ffffff', 0.86, 0.01);

  sample.traverse((child) => {
    if (!(child as THREE.Mesh).isMesh) return;
    const m = child as THREE.Mesh;
    const clonedGeo = m.geometry.clone();
    clonedGeo.applyMatrix4(m.matrixWorld);
    const nonIdx = clonedGeo.index ? clonedGeo.toNonIndexed() : clonedGeo;
    if (nonIdx !== clonedGeo) clonedGeo.dispose();
    // Strip extra attributes so mergeGeometries succeeds cleanly across meshes
    for (const attr of Object.keys(nonIdx.attributes)) {
      if (attr !== 'position' && attr !== 'normal' && attr !== 'uv') {
        nonIdx.deleteAttribute(attr);
      }
    }
    if (!nonIdx.getAttribute('normal')) nonIdx.computeVertexNormals();
    const lowerName = (m.name || '').toLowerCase();
    const matObj = Array.isArray(m.material) ? m.material[0] : m.material;
    const matName = (matObj?.name || '').toLowerCase();
    const isTrunk =
      lowerName.includes('trunk') ||
      lowerName.includes('bark') ||
      matName.includes('trunk') ||
      matName.includes('bark');
    if (isTrunk) {
      trunkGeos.push(nonIdx);
      if (matObj instanceof THREE.MeshStandardMaterial) trunkMat = matObj.clone();
    } else {
      crownGeos.push(nonIdx);
      if (matObj instanceof THREE.MeshStandardMaterial) {
        crownMat = matObj.clone();
        crownMat.color.setHex(0xffffff);
      }
    }
  });

  const mergedTrunk =
    trunkGeos.length > 0
      ? mergeGeometries(trunkGeos, false) || new THREE.CylinderGeometry(0.22, 0.35, 2.2, 8)
      : new THREE.CylinderGeometry(0.22, 0.35, 2.2, 8);
  const mergedCrown =
    crownGeos.length > 0
      ? mergeGeometries(crownGeos, false) || new THREE.DodecahedronGeometry(1.4, 1)
      : new THREE.DodecahedronGeometry(1.4, 1);

  trunkGeos.forEach((g) => g.dispose());
  crownGeos.forEach((g) => g.dispose());

  const trunk = new THREE.InstancedMesh(mergedTrunk, trunkMat, capacity);
  trunk.castShadow = true;
  trunk.receiveShadow = true;
  trunk.count = 0;
  trunk.frustumCulled = false;

  const crown = new THREE.InstancedMesh(mergedCrown, crownMat, capacity);
  crown.castShadow = true;
  crown.receiveShadow = true;
  crown.count = 0;
  crown.frustumCulled = false;

  return { trunk, crown, crownMat, capacity };
}

const SEASON_GROUND: Record<Season, string> = {
  Spring: '#6fba45',
  Summer: '#52a33a',
  Autumn: '#b88c3c',
  Winter: '#dbe6f0',
};

const SEASON_FOLIAGE: Record<Season, number[]> = {
  Spring: [0x4ade80, 0xf9a8d4, 0x86efac, 0x22c55e],
  Summer: [0x16a34a, 0x22c55e, 0x15803d, 0x4ade80],
  Autumn: [0xf59e0b, 0xea580c, 0xdc2626, 0xca8a04],
  Winter: [0xe2e8f0, 0xcbd5e1, 0x94a3b8, 0x64748b],
};

const SEASON_GRASS_TINT: Record<Season, number[]> = {
  Spring: [0x58b847, 0x6cd056, 0x45a336, 0x7ddc67],
  Summer: [0x3d9936, 0x4db042, 0x2f822b, 0x5ec24e],
  Autumn: [0x9f7e2f, 0xb58932, 0x8c6825, 0xc99c3b],
  Winter: [0xcfdbe6, 0xdbe6f0, 0xb6c5d4, 0xe5eef6],
};

const SHOP_SIGN_LABELS: Record<string, { top: string; sub: string; desc: string; accent: string }> = {
  general_store: { top: 'GENERAL STORE', sub: 'TOKO UMUM · THEO', desc: 'Benih musiman, pakan ternak, dan kebutuhan kebun harian. Buka 08:00–18:00.', accent: '#1d4ed8' },
  blacksmith: { top: 'BLACKSMITH', sub: 'PANDAI BESI · FORGE', desc: 'Upgrade Kapak, Cangkul, Palu, dan alat tambang. Jual beli bijih logam!', accent: '#b91c1c' },
  flower_shop: { top: 'FLOWER SHOP', sub: 'TOKO BUNGA · CLARA', desc: 'Bunga segar musiman, buket romantis & hadiah indah untuk warga desa.', accent: '#be185d' },
  ranch: { top: 'VALLEY RANCH', sub: 'PETERNAKAN · TERNAK', desc: 'Beli sapi, domba, ayam, keju maker & perlengkapan ternak terbaik.', accent: '#b45309' },
  clinic: { top: 'VALLEY CLINIC', sub: 'KLINIK · GIDEON', desc: 'Ramuan pemulih stamina, tonik herbal & layanan kesehatan desa.', accent: '#0f766e' },
  inn: { top: 'ROSA’S INN', sub: 'PENGINAPAN & MAKAN', desc: 'Hidangan hangat, sup lezat & minuman spesial buatan Rosa setiap hari.', accent: '#9a3412' },
  bakery: { top: 'SUNRISE BAKERY', sub: 'TOKO ROTI · NADIA', desc: 'Roti panggang segar, kue manis & camilan penambah energi.', accent: '#c2410c' },
  library: { top: 'VALLEY LIBRARY', sub: 'PERPUSTAKAAN · ELIAN', desc: 'Arsip sejarah Great Valley, rahasia kebun & misi kuno.', accent: '#4338ca' },
  manor: { top: 'MAYOR MANOR', sub: 'BALAI DESA · ALDER', desc: 'Balai pertemuan desa, jadwal festival & papan informasi warga.', accent: '#6d28d9' },
  cave: { top: 'MINING CAVE', sub: 'GOA TAMBANG · GALI', desc: 'Gali lantai goa dengan Cangkul untuk menemukan bijih langka & tangga lantai lebih dalam!', accent: '#334155' },
};

function createShopSignboardMesh(topText: string, subText: string, accentHex: string): THREE.Group {
  const g = new THREE.Group();
  const postMat = getStdMat('#5c3417', 0.88, 0.03);
  const frameMat = getStdMat('#7c4a26', 0.82, 0.04);

  const postL = new THREE.Mesh(new THREE.BoxGeometry(0.14, 2.35, 0.14), postMat);
  postL.position.set(-1.1, 1.175, 0);
  postL.castShadow = true;
  const postR = postL.clone();
  postR.position.x = 1.1;

  const boardBack = new THREE.Mesh(new THREE.BoxGeometry(2.45, 0.92, 0.12), frameMat);
  boardBack.position.set(0, 1.98, 0);
  boardBack.castShadow = true;

  const roofTrim = new THREE.Mesh(new THREE.BoxGeometry(2.65, 0.12, 0.24), getStdMat(accentHex, 0.72, 0.05));
  roofTrim.position.set(0, 2.48, 0);
  roofTrim.castShadow = true;

  const signTex = createCanvasTexture(
    (ctx, w, h) => {
      ctx.fillStyle = '#fef6e4';
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = accentHex;
      ctx.lineWidth = 10;
      ctx.strokeRect(8, 8, w - 16, h - 16);
      ctx.fillStyle = accentHex;
      ctx.fillRect(14, 14, w - 28, 72);
      ctx.fillStyle = '#ffffff';
      ctx.font = '900 34px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(topText, w / 2, 52);
      ctx.fillStyle = '#3b2412';
      ctx.font = '700 22px system-ui, sans-serif';
      ctx.fillText(subText, w / 2, 118);
    },
    512,
    1,
    4
  );
  signTex.repeat.set(1, 1);

  const faceMat = new THREE.MeshStandardMaterial({ map: signTex, roughness: 0.65, metalness: 0.02 });
  const frontFace = new THREE.Mesh(new THREE.PlaneGeometry(2.26, 0.78), faceMat);
  frontFace.position.set(0, 1.98, 0.068);
  const backFace = new THREE.Mesh(new THREE.PlaneGeometry(2.26, 0.78), faceMat);
  backFace.position.set(0, 1.98, -0.068);
  backFace.rotation.y = Math.PI;

  g.add(postL, postR, boardBack, roofTrim, frontFace, backFace);
  return g;
}

function createBuildingFromGLB(
  portal: BuildingPortal,
  windowMats: THREE.MeshStandardMaterial[],
  wallTex: THREE.CanvasTexture,
  wallBump: THREE.CanvasTexture,
  roofTex: THREE.CanvasTexture,
  roofBump: THREE.CanvasTexture
): {
  group: THREE.Group;
  box: AABBCollider;
  occluder: CameraOccluderBox;
  signboard?: WorldSignboardRef;
  extraColliders?: AABBCollider[];
} {
  if (portal.id === 'cave') {
    const wrapper = new THREE.Group();
    const cave = glbAssets.clone('/assets/glb/environment/cave_entrance.glb');
    cave.position.set(portal.doorX, 0, portal.doorZ - 1.5);
    wrapper.add(cave);
    const signInfo = SHOP_SIGN_LABELS.cave;
    const sign = createShopSignboardMesh(signInfo.top, signInfo.sub, signInfo.accent);
    const sx = portal.doorX + 3.4;
    const sz = portal.doorZ + 0.6;
    sign.position.set(sx, 0, sz);
    sign.userData = { signboardId: `sign_${portal.id}`, signTitle: signInfo.top, signText: `${signInfo.sub} — ${signInfo.desc}` };
    sign.traverse((c) => {
      c.userData = { ...c.userData, signboardId: `sign_${portal.id}`, signTitle: signInfo.top, signText: `${signInfo.sub} — ${signInfo.desc}` };
    });
    wrapper.add(sign);
    const box: AABBCollider = {
      minX: portal.doorX - 3.2,
      maxX: portal.doorX + 3.2,
      minZ: portal.doorZ - 3.4,
      maxZ: portal.doorZ - 0.6,
    };
    return {
      group: wrapper,
      box,
      occluder: { ...box, maxY: 4.8 },
      signboard: {
        id: `sign_${portal.id}`,
        portalId: portal.id,
        title: signInfo.top,
        text: `${signInfo.sub} — ${signInfo.desc}`,
        x: sx,
        y: 2.75,
        z: sz,
        mesh: sign,
      },
    };
  }

  const g = glbAssets.clone('/assets/glb/environment/building_cottage.glb');

  // Building base in .glb has normalized 1x1 footprint, local door at +0.51 Z
  g.scale.set(portal.width, portal.height, portal.depth);

  // Energy-conserving matte stucco wall material (prevents RT/PT overexposure & specular blowout)
  const wallColor = new THREE.Color(portal.color);
  const hsl = { h: 0, s: 0, l: 0 };
  wallColor.getHSL(hsl);
  if (hsl.l > 0.78) {
    wallColor.setHSL(hsl.h, hsl.s, 0.76);
  }
  const wallMat = new THREE.MeshStandardMaterial({
    color: wallColor,
    map: wallTex,
    bumpMap: wallBump,
    bumpScale: 0.06,
    roughness: 0.9,
    metalness: 0.0,
  });
  const roofMat = new THREE.MeshStandardMaterial({
    color: portal.roofColor,
    map: roofTex,
    bumpMap: roofBump,
    bumpScale: 0.09,
    roughness: 0.7,
    metalness: 0.06,
  });
  const winMat = new THREE.MeshStandardMaterial({
    color: '#fef08a',
    emissive: '#f59e0b',
    emissiveIntensity: 0.25,
    roughness: 0.2,
  });
  windowMats.push(winMat);

  g.traverse((obj) => {
    if (!(obj as THREE.Mesh).isMesh) return;
    const m = obj as THREE.Mesh;
    m.castShadow = true;
    m.receiveShadow = true;
    if (m.name === 'WallPart') {
      m.material = wallMat;
    } else if (m.name === 'RoofPart') {
      m.material = roofMat;
    } else if (m.name === 'WindowPart') {
      m.material = winMat;
    }
  });

  // Rotate & align front doorstep cleanly to (portal.doorX, portal.doorZ)
  let rotY = 0;
  let centerX = portal.doorX;
  let centerZ = portal.doorZ - (portal.depth * 0.5 + 0.65);

  if (portal.facing === 'north') {
    rotY = Math.PI;
    centerX = portal.doorX;
    centerZ = portal.doorZ + (portal.depth * 0.5 + 0.65);
  } else if (portal.facing === 'east') {
    rotY = Math.PI / 2;
    centerX = portal.doorX - (portal.depth * 0.5 + 0.65);
    centerZ = portal.doorZ;
  } else if (portal.facing === 'west') {
    rotY = -Math.PI / 2;
    centerX = portal.doorX + (portal.depth * 0.5 + 0.65);
    centerZ = portal.doorZ;
  }

  g.rotation.y = rotY;
  g.position.set(centerX, 0, centerZ);

  const swapped = portal.facing === 'east' || portal.facing === 'west';
  const halfW = swapped ? portal.depth * 0.5 : portal.width * 0.5;
  const halfD = swapped ? portal.width * 0.5 : portal.depth * 0.5;

  const box: AABBCollider = {
    minX: centerX - halfW - 0.18,
    maxX: centerX + halfW + 0.18,
    minZ: centerZ - halfD - 0.18,
    maxZ: centerZ + halfD + 0.18,
  };

  // Unique yard accent props per building so every house feels alive & distinct (with solid & jumpable colliders!)
  const wrapper = new THREE.Group();
  wrapper.add(g);
  const extraColliders: AABBCollider[] = [];

  if (portal.id === 'ranch') {
    const post = glbAssets.clone('/assets/glb/environment/fence_post.glb');
    post.position.set(centerX - 4.2, 0, portal.doorZ + 0.5);
    wrapper.add(post);
  } else if (portal.id === 'flower_shop') {
    const planterMat = getStdMat('#ec4899', 0.65, 0.05);
    [-1.4, 1.4].forEach((offZ) => {
      const px = portal.doorX - 0.5;
      const pz = portal.doorZ + offZ;
      const boxMesh = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.45, 0.9), getStdMat('#7c4a2d', 0.85, 0.02));
      boxMesh.position.set(px, 0.225, pz);
      const bloom = new THREE.Mesh(new THREE.DodecahedronGeometry(0.32, 0), planterMat);
      bloom.position.set(px, 0.55, pz);
      wrapper.add(boxMesh, bloom);
      extraColliders.push({
        minX: px - 0.34,
        maxX: px + 0.34,
        minZ: pz - 0.48,
        maxZ: pz + 0.48,
        jumpable: true,
        stepHeight: 0.32,
        topY: 0.46,
      });
    });
  } else if (portal.id === 'general_store') {
    const cx = portal.doorX + 2.5;
    const cz = portal.doorZ - 0.5;
    const crate = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.9, 0.95), getStdMat('#b45309', 0.85, 0.02));
    crate.position.set(cx, 0.45, cz);
    wrapper.add(crate);
    extraColliders.push({
      minX: cx - 0.5,
      maxX: cx + 0.5,
      minZ: cz - 0.5,
      maxZ: cz + 0.5,
      jumpable: true,
      stepHeight: 0.45,
      topY: 0.9,
    });
  } else if (portal.id === 'blacksmith') {
    const ox = portal.doorX - 2.6;
    const oz = portal.doorZ - 0.4;
    const oreCart = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.65, 0.8), getStdMat('#475569', 0.55, 0.5));
    oreCart.position.set(ox, 0.325, oz);
    wrapper.add(oreCart);
    extraColliders.push({
      minX: ox - 0.58,
      maxX: ox + 0.58,
      minZ: oz - 0.42,
      maxZ: oz + 0.42,
      jumpable: true,
      stepHeight: 0.38,
      topY: 0.65,
    });
  }

  // Outdoor 3D Wooden Signboard in front of NPC Shops & Village Buildings (clickable + [E] interactable!)
  let signboard: WorldSignboardRef | undefined;
  const signMeta = SHOP_SIGN_LABELS[portal.id];
  if (signMeta) {
    const sign = createShopSignboardMesh(signMeta.top, signMeta.sub, signMeta.accent);
    const sideOffset = portal.width * 0.36 + 1.15;
    let sx = portal.doorX + sideOffset;
    let sz = portal.doorZ + 0.55;
    if (portal.facing === 'south') {
      sx = portal.doorX + sideOffset;
      sz = portal.doorZ + 0.55;
      sign.rotation.y = 0;
    } else if (portal.facing === 'north') {
      sx = portal.doorX - sideOffset;
      sz = portal.doorZ - 0.55;
      sign.rotation.y = Math.PI;
    } else if (portal.facing === 'east') {
      sx = portal.doorX + 0.55;
      sz = portal.doorZ + sideOffset;
      sign.rotation.y = Math.PI / 2;
    } else {
      sx = portal.doorX - 0.55;
      sz = portal.doorZ - sideOffset;
      sign.rotation.y = -Math.PI / 2;
    }
    sign.position.set(sx, 0, sz);
    const signText = `${signMeta.sub} — ${signMeta.desc}`;
    sign.userData = { signboardId: `sign_${portal.id}`, signTitle: signMeta.top, signText };
    sign.traverse((c) => {
      c.userData = { ...c.userData, signboardId: `sign_${portal.id}`, signTitle: signMeta.top, signText };
    });
    wrapper.add(sign);
    signboard = {
      id: `sign_${portal.id}`,
      portalId: portal.id,
      title: signMeta.top,
      text: signText,
      x: sx,
      y: 2.75,
      z: sz,
      mesh: sign,
    };
  }

  return {
    group: wrapper,
    box,
    extraColliders,
    occluder: {
      minX: box.minX - 0.2,
      maxX: box.maxX + 0.2,
      minZ: box.minZ - 0.2,
      maxZ: box.maxZ + 0.2,
      maxY: portal.height + 2.4,
    },
    signboard,
  };
}

export function setAppleTreeVisuals(refs: OutdoorWorldRefs, applesReady: number, hasBees: boolean) {
  refs.appleTreeGroup.traverse((obj) => {
    if (obj.name.startsWith('AppleFruit_')) {
      const idx = Number(obj.name.split('_')[1] || 0);
      obj.visible = idx < applesReady * 2;
    }
  });
  refs.beehiveGroup.visible = hasBees;
  refs.beePoints.visible = hasBees;
}

export function buildOutdoorWorld(maxAnisotropy: number, secretUnlocked: boolean): OutdoorWorldRefs {
  const group = new THREE.Group();
  const interactives: InteractiveWorldNode[] = [];
  const signboards: WorldSignboardRef[] = [];
  const colliders: WorldColliders = { boxes: [], circles: [] };
  const cameraOccluders: CameraOccluderBox[] = [];
  const occlusionTargets: OcclusionTarget[] = [];
  const windowMats: THREE.MeshStandardMaterial[] = [];

  // === 1. DETAILED PROCEDURAL PBR TEXTURES ===
  const grassAlbedo = createCanvasTexture(
    (ctx, w, h) => {
      ctx.fillStyle = '#e7f5df';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 2400; i++) {
        const x = Math.random() * w;
        const y = Math.random() * h;
        const shade = Math.random();
        ctx.fillStyle =
          shade > 0.65
            ? 'rgba(255,255,255,0.16)'
            : shade > 0.3
              ? 'rgba(30,90,25,0.11)'
              : 'rgba(130,190,70,0.14)';
        ctx.fillRect(x, y, 2 + (i % 3), 5 + (i % 6));
      }
      for (let i = 0; i < 160; i++) {
        ctx.fillStyle = 'rgba(255,255,255,0.12)';
        ctx.beginPath();
        ctx.arc(Math.random() * w, Math.random() * h, 1.8, 0, Math.PI * 2);
        ctx.fill();
      }
    },
    256,
    48,
    maxAnisotropy
  );

  const grassBump = createCanvasTexture(
    (ctx, w, h) => {
      ctx.fillStyle = '#808080';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 1800; i++) {
        const v = 95 + Math.floor(Math.random() * 80);
        ctx.fillStyle = `rgb(${v},${v},${v})`;
        ctx.fillRect(Math.random() * w, Math.random() * h, 2, 6);
      }
    },
    256,
    48,
    maxAnisotropy,
    true
  );

  const groundMat = new THREE.MeshStandardMaterial({
    color: SEASON_GROUND.Spring,
    map: grassAlbedo,
    bumpMap: grassBump,
    bumpScale: 0.08,
    roughness: 0.92,
    metalness: 0.0,
  });

  // Vast expanded valley terrain spanning Spacious Far-West Homestead (-198..-64) -> Town/Forest/Mine/Beach (-64..+56)
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(290, 230), groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.position.set(-72, 0, 0);
  ground.receiveShadow = true;
  group.add(ground);

  const wallTex = createCanvasTexture(
    (ctx, w, h) => {
      ctx.fillStyle = '#ddd4c2';
      ctx.fillRect(0, 0, w, h);
      // Warm horizontal timber-plank & plaster grain (calibrated diffuse albedo to prevent RT/PT whiteout)
      for (let y = 0; y < h; y += 20) {
        ctx.fillStyle = y % 40 === 0 ? 'rgba(122,84,48,0.13)' : 'rgba(240,234,220,0.08)';
        ctx.fillRect(0, y, w, 18);
        ctx.strokeStyle = 'rgba(92,58,30,0.22)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
      // Subtle plaster speckle & vertical beams
      ctx.fillStyle = 'rgba(85,54,28,0.18)';
      ctx.fillRect(0, 0, 8, h);
      ctx.fillRect(w - 8, 0, 8, h);
      for (let i = 0; i < 420; i++) {
        ctx.fillStyle = i % 2 === 0 ? 'rgba(90,65,40,0.09)' : 'rgba(255,252,240,0.12)';
        ctx.fillRect(Math.random() * w, Math.random() * h, 3, 2);
      }
    },
    256,
    3,
    maxAnisotropy
  );

  const wallBump = createCanvasTexture(
    (ctx, w, h) => {
      ctx.fillStyle = '#888888';
      ctx.fillRect(0, 0, w, h);
      for (let y = 0; y < h; y += 20) {
        ctx.fillStyle = '#404040';
        ctx.fillRect(0, y, w, 2);
        ctx.fillStyle = '#a4a4a4';
        ctx.fillRect(0, y + 3, w, 3);
      }
    },
    256,
    3,
    maxAnisotropy,
    true
  );

  const roofTex = createCanvasTexture(
    (ctx, w, h) => {
      ctx.fillStyle = '#f8f2ea';
      ctx.fillRect(0, 0, w, h);
      for (let y = 0; y < h; y += 20) {
        const stagger = (y / 20) % 2 === 0 ? 0 : 16;
        for (let x = -16; x < w + 16; x += 32) {
          const shade = 225 + ((x * 3 + y * 5) % 24);
          ctx.fillStyle = `rgb(${shade},${shade - 6},${shade - 10})`;
          ctx.fillRect(x + stagger + 1, y + 1, 30, 17);
          ctx.fillStyle = 'rgba(0,0,0,0.22)';
          ctx.fillRect(x + stagger, y + 17, 32, 3);
          ctx.fillRect(x + stagger, y, 2, 20);
        }
      }
    },
    256,
    4,
    maxAnisotropy
  );

  const roofBump = createCanvasTexture(
    (ctx, w, h) => {
      ctx.fillStyle = '#909090';
      ctx.fillRect(0, 0, w, h);
      for (let y = 0; y < h; y += 20) {
        ctx.fillStyle = '#303030';
        ctx.fillRect(0, y + 17, w, 3);
      }
    },
    256,
    4,
    maxAnisotropy,
    true
  );

  // === 2. TOWN SQUARE PLAZA & DIRT PATHWAYS ===
  const stoneTex = createCanvasTexture(
    (ctx, w, h) => {
      ctx.fillStyle = '#c9bfae';
      ctx.fillRect(0, 0, w, h);
      for (let y = 0; y < h; y += 32) {
        for (let x = 0; x < w; x += 44) {
          const off = (y / 32) % 2 === 0 ? 0 : 22;
          const tint = 185 + ((x * 7 + y * 13) % 30);
          ctx.fillStyle = `rgb(${tint}, ${tint - 8}, ${tint - 20})`;
          ctx.fillRect(x + off + 2, y + 2, 40, 28);
          ctx.strokeStyle = '#928878';
          ctx.lineWidth = 3;
          ctx.strokeRect(x + off + 1, y + 1, 42, 30);
        }
      }
    },
    256,
    14,
    maxAnisotropy
  );

  const dirtTex = createCanvasTexture(
    (ctx, w, h) => {
      ctx.fillStyle = '#c7a473';
      ctx.fillRect(0, 0, w, h);
      // Warm country path grain + tiny pebbles + wheel ruts
      ctx.fillStyle = 'rgba(148,105,58,0.16)';
      ctx.fillRect(w * 0.22, 0, w * 0.14, h);
      ctx.fillRect(w * 0.64, 0, w * 0.14, h);
      for (let i = 0; i < 1400; i++) {
        const px = Math.random() * w;
        const py = Math.random() * h;
        ctx.fillStyle =
          i % 4 === 0
            ? 'rgba(110,72,34,0.22)'
            : i % 4 === 1
              ? 'rgba(248,228,188,0.2)'
              : 'rgba(166,125,78,0.18)';
        ctx.fillRect(px, py, 2 + (i % 4), 2 + (i % 3));
      }
      // Small rounded path pebbles
      for (let i = 0; i < 85; i++) {
        ctx.fillStyle = i % 2 === 0 ? 'rgba(130,115,96,0.38)' : 'rgba(225,210,185,0.34)';
        ctx.beginPath();
        ctx.ellipse(Math.random() * w, Math.random() * h, 3 + (i % 3), 2, Math.random() * Math.PI, 0, Math.PI * 2);
        ctx.fill();
      }
    },
    256,
    6,
    maxAnisotropy
  );

  const plazaMat = new THREE.MeshStandardMaterial({
    map: stoneTex,
    bumpMap: stoneTex,
    bumpScale: 0.05,
    roughness: 0.86,
    metalness: 0.02,
  });
  const plaza = new THREE.Mesh(new THREE.CircleGeometry(22, 40), plazaMat);
  plaza.rotation.x = -Math.PI / 2;
  plaza.position.set(4, 0.025, 0);
  plaza.receiveShadow = true;
  group.add(plaza);

  const pathMat = new THREE.MeshStandardMaterial({
    map: dirtTex,
    bumpMap: dirtTex,
    bumpScale: 0.04,
    roughness: 0.94,
    metalness: 0,
  });

  const addPath = (x: number, z: number, w: number, d: number) => {
    const p = new THREE.Mesh(new THREE.PlaneGeometry(w, d), pathMat);
    p.rotation.x = -Math.PI / 2;
    p.position.set(x, 0.022, z);
    p.receiveShadow = true;
    group.add(p);
  };
  // Private farm estate paths (expanded spacious layout connecting Stable/Coop/Barn/Farmhouse, Shipping Bin & Bridge)
  addPath(-136, -17.8, 62, 3.6); // Main homestead promenade along Stable (-160) -> Coop (-144) -> Barn (-128) -> Farmhouse (-112)
  addPath(-106, -9.0, 3.6, 18.5); // Farmhouse yard south toward Shipping Bin & bridge road
  addPath(-86, 0, 42, 3.6); // Farm eastbound lane to West Brook bridge
  // Town & Valley connecting roads
  addPath(-38, 0, 44, 3.6); // Bridge East through Town into Town Square
  addPath(4, -30, 3.6, 22); // Town Square North to Mountain Mine & Smithy
  addPath(4, -46, 3.6, 14); // North trail beyond Smithy to Mountain Ridge
  addPath(-22, -52, 54, 3.4); // Remote Mountain Ridge West trail leading toward Far-Corner Cave
  addPath(-48, -56, 3.6, 11); // Final ascent to Whispering Mountain Cave mouth (-48, -62)
  addPath(4, 30, 3.6, 22); // Town Square South to Whispering Woods
  addPath(34, 0, 24, 3.4); // Town Square East to River Cove & Ocean Beach

  // === 3. FLOWING WATER, WEST BROOK + BRIDGE, RIVER COVE & VAST EASTERN OCEAN ===
  const waterTex = createCanvasTexture(
    (ctx, w, h) => {
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, '#38bdf8');
      grad.addColorStop(0.5, '#0ea5e9');
      grad.addColorStop(1, '#38bdf8');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
      // Soft caustic patches
      for (let i = 0; i < 65; i++) {
        ctx.fillStyle = i % 2 === 0 ? 'rgba(224,242,254,0.22)' : 'rgba(3,105,161,0.18)';
        ctx.beginPath();
        ctx.ellipse(Math.random() * w, Math.random() * h, 14 + Math.random() * 18, 6 + Math.random() * 8, Math.random() * Math.PI, 0, Math.PI * 2);
        ctx.fill();
      }
      // Layered wave highlights
      ctx.strokeStyle = 'rgba(255,255,255,0.34)';
      ctx.lineWidth = 3;
      for (let y = 8; y < h; y += 22) {
        ctx.beginPath();
        for (let x = 0; x <= w; x += 12) {
          ctx.lineTo(x, y + Math.sin((x / w) * Math.PI * 4 + y * 0.1) * 4.5);
        }
        ctx.stroke();
      }
    },
    256,
    7,
    maxAnisotropy
  );

  const waterMat = new THREE.MeshStandardMaterial({
    color: '#5cc8f8',
    map: waterTex,
    bumpMap: waterTex,
    bumpScale: 0.04,
    roughness: 0.14,
    metalness: 0.18,
    transparent: true,
    opacity: 0.9,
  });

  const oceanMat = new THREE.MeshStandardMaterial({
    color: '#0e85c7',
    map: waterTex,
    bumpMap: waterTex,
    bumpScale: 0.05,
    roughness: 0.12,
    metalness: 0.24,
    transparent: true,
    opacity: 0.92,
  });

  // West Brook separating Private Farm Estate (x < -67) from Town (x > -61)
  const brookMesh = new THREE.Mesh(new THREE.PlaneGeometry(6.5, 180, 4, 20), waterMat);
  brookMesh.rotation.x = -Math.PI / 2;
  brookMesh.position.set(-64, 0.04, 0);
  group.add(brookMesh);
  colliders.boxes.push({ minX: -67.3, maxX: -60.7, minZ: -90, maxZ: -2.4 });
  colliders.boxes.push({ minX: -67.3, maxX: -60.7, minZ: 2.4, maxZ: 90 });

  // Wooden Bridge over West Brook at (-64, 0) with Sloped End Ramps & Guardrails
  const bridgeMat = getStdMat('#92400e', 0.82, 0.04);
  const bridgePostMat = getStdMat('#6b3610', 0.86, 0.04);
  const bridgeDeck = new THREE.Mesh(new THREE.BoxGeometry(9.6, 0.22, 4.6), bridgeMat);
  bridgeDeck.position.set(-64, 0.12, 0);
  bridgeDeck.receiveShadow = true;
  bridgeDeck.castShadow = true;
  // Smooth west & east approach ramps so feet step cleanly onto deck height (y=0.23)
  const rampW = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.16, 4.5), bridgeMat);
  rampW.position.set(-69.25, 0.075, 0);
  rampW.rotation.z = 0.19;
  rampW.receiveShadow = true;
  const rampE = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.16, 4.5), bridgeMat);
  rampE.position.set(-58.75, 0.075, 0);
  rampE.rotation.z = -0.19;
  rampE.receiveShadow = true;
  const railN = new THREE.Mesh(new THREE.BoxGeometry(9.8, 0.14, 0.2), bridgeMat);
  railN.position.set(-64, 0.92, -2.22);
  const railNMid = new THREE.Mesh(new THREE.BoxGeometry(9.8, 0.1, 0.14), bridgeMat);
  railNMid.position.set(-64, 0.58, -2.22);
  const railS = railN.clone();
  railS.position.z = 2.22;
  const railSMid = railNMid.clone();
  railSMid.position.z = 2.22;
  group.add(bridgeDeck, rampW, rampE, railN, railNMid, railS, railSMid);
  [-68.6, -66.3, -64.0, -61.7, -59.4].forEach((px) => {
    [-2.22, 2.22].forEach((pz) => {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.96, 0.22), bridgePostMat);
      post.position.set(px, 0.56, pz);
      post.castShadow = true;
      group.add(post);
    });
  });
  colliders.boxes.push({ minX: -69.2, maxX: -58.8, minZ: -2.48, maxZ: -2.08 });
  colliders.boxes.push({ minX: -69.2, maxX: -58.8, minZ: 2.08, maxZ: 2.48 });

  // Wide Sandy Beach Strip along Eastern Coast (x: 34..50) — physically grounded warm sand albedo (no RT/PT white blowout!)
  const sandTex = createCanvasTexture(
    (ctx, w, h) => {
      ctx.fillStyle = '#d4ba7e';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 1100; i++) {
        ctx.fillStyle = i % 2 === 0 ? 'rgba(164,132,74,0.22)' : 'rgba(232,212,162,0.18)';
        ctx.fillRect(Math.random() * w, Math.random() * h, 2, 2);
      }
    },
    256,
    8,
    maxAnisotropy
  );

  const sandMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(18, 200),
    new THREE.MeshStandardMaterial({ map: sandTex, roughness: 0.95, metalness: 0 })
  );
  sandMesh.rotation.x = -Math.PI / 2;
  sandMesh.position.set(42.5, 0.018, 0);
  sandMesh.receiveShadow = true;
  group.add(sandMesh);

  // Crystal River Cove Channel (inland cove z: +10..+36, x: 40..50)
  const riverCoveMesh = new THREE.Mesh(new THREE.PlaneGeometry(10, 28, 6, 12), waterMat);
  riverCoveMesh.rotation.x = -Math.PI / 2;
  riverCoveMesh.position.set(44.5, 0.042, 23);
  group.add(riverCoveMesh);
  colliders.boxes.push({ minX: 39.8, maxX: 49.0, minZ: 10.0, maxZ: 14.0 });
  colliders.boxes.push({ minX: 39.8, maxX: 49.0, minZ: 18.0, maxZ: 36.0 });

  // Vast Deep Blue Eastern Ocean (x: +48 .. +260, z: -140 .. +140)
  const waterMesh = new THREE.Mesh(new THREE.PlaneGeometry(212, 280, 24, 32), oceanMat);
  waterMesh.rotation.x = -Math.PI / 2;
  waterMesh.position.set(154, 0.04, 0);
  group.add(waterMesh);

  // Solid Eastern Shoreline Water Barrier (split around Ocean Pier at z = -9.9..-6.1)
  colliders.boxes.push({ minX: 47.4, maxX: 50.2, minZ: -60, maxZ: -9.85 });
  colliders.boxes.push({ minX: 47.4, maxX: 50.2, minZ: -6.15, maxZ: 60 });

  // Coastal Shoreline Boulders for visual detail
  [
    [45.5, -24],
    [46.2, -16],
    [45.8, 3],
    [44.5, -34],
  ].forEach(([rx, rz]) => {
    const cr = glbAssets.clone('/assets/glb/environment/mine_rock.glb');
    cr.position.set(rx, 0, rz);
    cr.scale.setScalar(0.85);
    group.add(cr);
    colliders.circles.push({ x: rx, z: rz, radius: 0.78 });
  });

  // Helper: 3D Wooden Safety Guardrails + Solid Perimeter Colliders around Docks/Piers (prevents stepping into water!)
  const addPierGuardrails = (minX: number, maxX: number, minZ: number, maxZ: number) => {
    const lenX = maxX - minX;
    const lenZ = maxZ - minZ;
    const midX = (minX + maxX) * 0.5;
    const midZ = (minZ + maxZ) * 0.5;
    const deckTop = 0.285;
    const railMat = getStdMat('#7c4a26', 0.85, 0.04);
    const postMat = getStdMat('#5b3216', 0.88, 0.04);

    // North & South side rails
    [minZ, maxZ].forEach((rz) => {
      const topBar = new THREE.Mesh(new THREE.BoxGeometry(lenX + 0.14, 0.11, 0.13), railMat);
      topBar.position.set(midX, deckTop + 0.86, rz);
      topBar.castShadow = true;
      const midBar = new THREE.Mesh(new THREE.BoxGeometry(lenX + 0.14, 0.08, 0.1), railMat);
      midBar.position.set(midX, deckTop + 0.48, rz);
      group.add(topBar, midBar);

      const postCount = Math.max(3, Math.round(lenX / 2.0) + 1);
      for (let i = 0; i < postCount; i++) {
        const px = minX + (lenX * i) / (postCount - 1);
        const post = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.96, 0.18), postMat);
        post.position.set(px, deckTop + 0.48, rz);
        post.castShadow = true;
        group.add(post);
      }
    });

    // East end rail facing deep water
    const endTop = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.11, lenZ + 0.14), railMat);
    endTop.position.set(maxX, deckTop + 0.86, midZ);
    endTop.castShadow = true;
    const endMid = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.08, lenZ + 0.14), railMat);
    endMid.position.set(maxX, deckTop + 0.48, midZ);
    const endMidPost = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.96, 0.18), postMat);
    endMidPost.position.set(maxX, deckTop + 0.48, midZ);
    group.add(endTop, endMid, endMidPost);

    // Solid non-jumpable perimeter AABB colliders so players CANNOT walk off pier into water!
    colliders.boxes.push({ minX: minX - 0.15, maxX: maxX + 0.25, minZ: minZ - 0.22, maxZ: minZ + 0.14 });
    colliders.boxes.push({ minX: minX - 0.15, maxX: maxX + 0.25, minZ: maxZ - 0.14, maxZ: maxZ + 0.22 });
    colliders.boxes.push({ minX: maxX - 0.14, maxX: maxX + 0.35, minZ: minZ - 0.2, maxZ: maxZ + 0.2 });
  };

  // 1) Freshwater River Fishing Dock (x: 39.2..44.3, z: 14.35..17.65)
  const riverDock = glbAssets.clone('/assets/glb/environment/wooden_dock.glb');
  riverDock.position.set(41.5, 0, 16.0);
  const riverRamp = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.16, 3.3), bridgeMat);
  riverRamp.position.set(38.9, 0.11, 16.0);
  riverRamp.rotation.z = 0.22;
  group.add(riverDock, riverRamp);
  addPierGuardrails(39.3, 44.3, 14.35, 17.65);
  interactives.push({
    id: 'fishing_river',
    kind: 'fishing_spot',
    spotType: 'river',
    label: 'Cast Fishing Rod — River Dock [F]',
    x: 43.2,
    z: 16.0,
    radius: 3.0,
  });

  // 2) Long Ocean Pier stretching east over Deep Blue Ocean (x: 46.8..56.1, z: -9.65..-6.35)
  const oceanDock1 = glbAssets.clone('/assets/glb/environment/wooden_dock.glb');
  oceanDock1.position.set(49.0, 0, -8.0);
  const oceanDock2 = glbAssets.clone('/assets/glb/environment/wooden_dock.glb');
  oceanDock2.position.set(53.2, 0, -8.0);
  const oceanRamp = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.16, 3.3), bridgeMat);
  oceanRamp.position.set(46.35, 0.11, -8.0);
  oceanRamp.rotation.z = 0.22;
  group.add(oceanDock1, oceanDock2, oceanRamp);
  addPierGuardrails(46.8, 56.05, -9.65, -6.35);
  interactives.push({
    id: 'fishing_ocean',
    kind: 'fishing_spot',
    spotType: 'ocean',
    label: 'Cast Fishing Rod — Ocean Pier [F]',
    x: 54.4,
    z: -8.0,
    radius: 3.2,
  });

  // === 4. CENTRAL TOWN SQUARE LANDMARKS (.glb) ===
  const fountain = glbAssets.clone('/assets/glb/environment/fountain.glb');
  fountain.position.set(4, 0, 0);
  group.add(fountain);
  colliders.circles.push({ x: 4, z: 0, radius: 2.65 });

  // Festival Stage at North side of Plaza (solid on ground, jumpable & standable on stage platform!)
  const stage = glbAssets.clone('/assets/glb/environment/festival_stage.glb');
  stage.position.set(4, 0, -12.5);
  group.add(stage);
  colliders.boxes.push({
    minX: -0.6,
    maxX: 8.6,
    minZ: -15.3,
    maxZ: -9.7,
    jumpable: true,
    stepHeight: 0.42,
    topY: 0.72,
  });

  // 4 Plaza Market Stalls
  const stallCoords: Array<[number, number, number]> = [
    [-10, -8, Math.PI * 0.25],
    [18, -8, -Math.PI * 0.25],
    [-10, 8, Math.PI * 0.75],
    [18, 8, -Math.PI * 0.75],
  ];
  stallCoords.forEach(([sx, sz, srot], idx) => {
    const stall = glbAssets.clone('/assets/glb/environment/market_stall.glb');
    stall.position.set(sx, 0, sz);
    stall.rotation.y = srot;
    group.add(stall);
    colliders.boxes.push({ minX: sx - 1.55, maxX: sx + 1.55, minZ: sz - 0.9, maxZ: sz + 0.9 });
    occlusionTargets.push({ id: `stall_${idx}`, obj: stall, x: sx, y: 1.5, z: sz, radius: 1.8, category: 'prop' });
  });

  // 4 Park Benches around Fountain (solid on ground + jumpable & standable top seat surface!)
  TOWN_SQUARE_BENCHES.forEach(({ x: bx, z: bz, rotY: brot }, idx) => {
    const bench = glbAssets.clone('/assets/glb/environment/park_bench.glb');
    bench.position.set(bx, 0, bz);
    bench.rotation.y = brot;
    group.add(bench);
    const rotSwap = Math.abs(Math.sin(brot)) > 0.5;
    colliders.boxes.push({
      minX: bx - (rotSwap ? 0.42 : 0.88),
      maxX: bx + (rotSwap ? 0.42 : 0.88),
      minZ: bz - (rotSwap ? 0.88 : 0.42),
      maxZ: bz + (rotSwap ? 0.88 : 0.42),
      jumpable: true,
      stepHeight: 0.34,
      topY: 0.5,
    });
    occlusionTargets.push({ id: `bench_${idx}`, obj: bench, x: bx, y: 0.6, z: bz, radius: 1.2, category: 'prop' });
  });

  // === 4B. HARVEST MOON FESTIVAL SQUARE DECORATIONS (visible on Festival Days!) ===
  const festivalDecorGroup = new THREE.Group();
  festivalDecorGroup.visible = false;
  const festPoleMat = getStdMat('#7c4a26', 0.85, 0.04);
  const festBannerPalette = ['#ef4444', '#f59e0b', '#22c55e', '#3b82f6', '#ec4899', '#facc15'];
  const poleRingCount = 10;
  const poleCoords: Array<[number, number]> = [];
  for (let i = 0; i < poleRingCount; i++) {
    const a = (i / poleRingCount) * Math.PI * 2;
    const px = 4 + Math.cos(a) * 14.5;
    const pz = Math.sin(a) * 14.5;
    poleCoords.push([px, pz]);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.11, 4.4, 8), festPoleMat);
    pole.position.set(px, 2.2, pz);
    pole.castShadow = true;
    const lantern = new THREE.Mesh(
      new THREE.SphereGeometry(0.28, 10, 8),
      getStdMat('#fef08a', 0.25, 0.05, '#f59e0b', 1.1)
    );
    lantern.position.set(px, 4.35, pz);
    festivalDecorGroup.add(pole, lantern);
  }
  // Colorful triangular bunting strings between adjacent festival poles
  for (let i = 0; i < poleRingCount; i++) {
    const [x1, z1] = poleCoords[i];
    const [x2, z2] = poleCoords[(i + 1) % poleRingCount];
    const flags = 6;
    for (let f = 1; f <= flags; f++) {
      const tFrac = f / (flags + 1);
      const fx = x1 + (x2 - x1) * tFrac;
      const fz = z1 + (z2 - z1) * tFrac;
      const sag = Math.sin(tFrac * Math.PI) * 0.55;
      const flag = new THREE.Mesh(
        new THREE.ConeGeometry(0.24, 0.44, 3),
        getStdMat(festBannerPalette[(i + f) % festBannerPalette.length], 0.65, 0.02)
      );
      flag.rotation.x = Math.PI;
      flag.position.set(fx, 4.05 - sag, fz);
      festivalDecorGroup.add(flag);
    }
  }
  // Festive Garland Feast Tables on East & West flanks of Town Square
  [
    [-7.5, -2.5],
    [15.5, -2.5],
  ].forEach(([tx, tz]) => {
    const tableTop = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.14, 1.15), getStdMat('#fef3c7', 0.78, 0.02));
    tableTop.position.set(tx, 0.85, tz);
    tableTop.castShadow = true;
    const cloth = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.45, 1.2), getStdMat('#dc2626', 0.85, 0.02));
    cloth.position.set(tx, 0.58, tz);
    const cake = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.34, 0.26, 12), getStdMat('#fde68a', 0.6, 0.05));
    cake.position.set(tx, 1.05, tz);
    festivalDecorGroup.add(tableTop, cloth, cake);
  });
  group.add(festivalDecorGroup);

  // === 5. PRIVATE FARM ESTATE PROPS: SHIPPING BIN (well-spaced away from Doghouse!), APPLE TREE + BEEHIVE, FENCES ===
  const binGroup = glbAssets.clone('/assets/glb/environment/shipping_bin.glb');
  binGroup.position.set(SHIPPING_BIN_POS.x, 0, SHIPPING_BIN_POS.z);
  group.add(binGroup);
  occlusionTargets.push({ id: 'shipping_bin', obj: binGroup, x: SHIPPING_BIN_POS.x, y: 0.6, z: SHIPPING_BIN_POS.z, radius: 1.3, category: 'prop' });
  colliders.boxes.push({
    minX: SHIPPING_BIN_POS.x - 1.0,
    maxX: SHIPPING_BIN_POS.x + 1.0,
    minZ: SHIPPING_BIN_POS.z - 0.7,
    maxZ: SHIPPING_BIN_POS.z + 0.7,
    jumpable: true,
    stepHeight: 0.44,
    topY: 0.84,
  });
  interactives.push({
    id: 'shipping_bin',
    kind: 'shipping_bin',
    label: 'Sell Crops & Goods (Shipping Bin) [F]',
    x: SHIPPING_BIN_POS.x,
    z: SHIPPING_BIN_POS.z,
    radius: 2.35,
  });

  // Farmhouse Apple Tree (.glb) — Protected event tree (cannot be chopped!)
  const appleTreeGroup = glbAssets.clone('/assets/glb/environment/apple_tree.glb');
  appleTreeGroup.position.set(APPLE_TREE_POS.x, 0, APPLE_TREE_POS.z);
  group.add(appleTreeGroup);
  colliders.circles.push({ x: APPLE_TREE_POS.x, z: APPLE_TREE_POS.z, radius: 0.72 });

  const beehiveGroup = glbAssets.clone('/assets/glb/environment/beehive.glb');
  beehiveGroup.position.set(APPLE_TREE_POS.x + 1.15, 1.9, APPLE_TREE_POS.z + 0.8);
  beehiveGroup.visible = false;
  group.add(beehiveGroup);

  const beeCount = 16;
  const beePosArr = new Float32Array(beeCount * 3);
  for (let i = 0; i < beeCount; i++) {
    const a = (i / beeCount) * Math.PI * 2;
    beePosArr[i * 3] = APPLE_TREE_POS.x + 1.15 + Math.cos(a) * 0.7;
    beePosArr[i * 3 + 1] = 1.9 + (i % 3) * 0.25;
    beePosArr[i * 3 + 2] = APPLE_TREE_POS.z + 0.8 + Math.sin(a) * 0.7;
  }
  const beeGeo = new THREE.BufferGeometry();
  beeGeo.setAttribute('position', new THREE.BufferAttribute(beePosArr, 3));
  const beePoints = new THREE.Points(
    beeGeo,
    new THREE.PointsMaterial({ color: '#facc15', size: 0.16, transparent: true, opacity: 0.95 })
  );
  beePoints.visible = false;
  group.add(beePoints);

  interactives.push({
    id: 'farm_apple_tree',
    kind: 'harvest_apple_honey',
    label: 'Check / Harvest Apples & Honey [F]',
    x: APPLE_TREE_POS.x,
    z: APPLE_TREE_POS.z + 1.6,
    radius: 2.35,
  });

  // 3D Wooden Fence Perimeter (.glb, Jumpable by Player!) around Expanded Plantation Yard (-148..-118, z: -4..+22)
  // South farm fence (x: -152..-114, z: 25.0)
  for (let fx = -152; fx <= -115; fx += 3) {
    const fence = glbAssets.clone('/assets/glb/environment/fence_post.glb');
    fence.position.set(fx, 0, 25.0);
    group.add(fence);
    occlusionTargets.push({ id: `fence_s_${fx}`, obj: fence, x: fx, y: 0.5, z: 25.0, radius: 1.8, category: 'prop' });
  }
  colliders.boxes.push({
    minX: -152.2,
    maxX: -113.8,
    minZ: 24.7,
    maxZ: 25.3,
    jumpable: true,
    stepHeight: 0.42,
    topY: 0.84,
  });

  // West farm fence (x: -153.2, z: -6..+24)
  for (let fz = -6; fz <= 22; fz += 3) {
    const fence = glbAssets.clone('/assets/glb/environment/fence_post.glb');
    fence.position.set(-153.2, 0, fz);
    fence.rotation.y = -Math.PI / 2;
    group.add(fence);
    occlusionTargets.push({ id: `fence_w_${fz}`, obj: fence, x: -153.2, y: 0.5, z: fz, radius: 1.8, category: 'prop' });
  }
  colliders.boxes.push({
    minX: -153.5,
    maxX: -152.9,
    minZ: -6.4,
    maxZ: 25.0,
    jumpable: true,
    stepHeight: 0.42,
    topY: 0.84,
  });

  // East farm garden fence (with wide road opening around z = -6..+4)
  for (let fz = 5; fz <= 22; fz += 3) {
    const fence = glbAssets.clone('/assets/glb/environment/fence_post.glb');
    fence.position.set(-113.5, 0, fz);
    fence.rotation.y = -Math.PI / 2;
    group.add(fence);
    occlusionTargets.push({ id: `fence_e_${fz}`, obj: fence, x: -113.5, y: 0.5, z: fz, radius: 1.8, category: 'prop' });
  }
  colliders.boxes.push({
    minX: -113.8,
    maxX: -113.2,
    minZ: 4.6,
    maxZ: 25.0,
    jumpable: true,
    stepHeight: 0.42,
    topY: 0.84,
  });

  // Cozy Wooden Doghouse (.glb — solid non-pass-through collider!)
  const doghouseGroup = glbAssets.clone('/assets/glb/environment/doghouse.glb');
  doghouseGroup.position.set(DOGHOUSE_POS.x, 0, DOGHOUSE_POS.z);
  group.add(doghouseGroup);
  occlusionTargets.push({ id: 'doghouse', obj: doghouseGroup, x: DOGHOUSE_POS.x, y: 0.7, z: DOGHOUSE_POS.z, radius: 1.1, category: 'prop' });
  colliders.boxes.push({
    minX: DOGHOUSE_POS.x - 0.72,
    maxX: DOGHOUSE_POS.x + 0.72,
    minZ: DOGHOUSE_POS.z - 0.76,
    maxZ: DOGHOUSE_POS.z + 0.76,
  });

  // Outdoor Dog Food Bowl (.glb — solid collider!)
  const dogBowlGroup = glbAssets.clone('/assets/glb/environment/dog_bowl.glb');
  dogBowlGroup.position.set(DOG_FOOD_BOWL_POS.x, 0, DOG_FOOD_BOWL_POS.z);
  group.add(dogBowlGroup);
  colliders.circles.push({ x: DOG_FOOD_BOWL_POS.x, z: DOG_FOOD_BOWL_POS.z, radius: 0.38 });
  interactives.push({
    id: 'dog_food_bowl',
    kind: 'dog_bowl',
    label: 'Feed Dog (Outdoor Bowl) [F]',
    x: DOG_FOOD_BOWL_POS.x,
    z: DOG_FOOD_BOWL_POS.z,
    radius: 2.0,
    mesh: dogBowlGroup,
  });

  // === 6. ALL ENTERABLE BUILDINGS & WHISPERING CAVE PORTAL (.glb) ===
  for (const portal of BUILDING_PORTALS) {
    const { group: bMesh, box, extraColliders, occluder, signboard } = createBuildingFromGLB(
      portal,
      windowMats,
      wallTex,
      wallBump,
      roofTex,
      roofBump
    );
    group.add(bMesh);
    colliders.boxes.push(box);
    if (extraColliders && extraColliders.length > 0) {
      colliders.boxes.push(...extraColliders);
    }
    cameraOccluders.push(occluder);
    if (signboard) {
      signboards.push(signboard);
      interactives.push({
        id: signboard.id,
        kind: 'signboard',
        label: `Read Sign: ${signboard.title} [E]`,
        x: signboard.x,
        z: signboard.z,
        radius: 2.35,
        portalId: portal.id,
        signTitle: signboard.title,
        signText: signboard.text,
        mesh: signboard.mesh,
      });
    }
    const isPrivate =
      portal.id === 'farmhouse' || portal.id === 'barn' || portal.id === 'coop' || portal.id === 'stable';
    interactives.push({
      id: `door_${portal.id}`,
      kind: 'door',
      label: isPrivate
        ? `Access / Lock ${portal.name} [F]`
        : portal.id === 'cave'
          ? `Enter ${portal.name} [F]`
          : `Enter ${portal.name} [F]`,
      x: portal.doorX,
      z: portal.doorZ,
      radius: portal.id === 'cave' ? 2.6 : 2.2,
      targetZone: portal.interiorZone,
      portalId: portal.id,
    });
  }

  // === 7. NATURAL PERIMETER HILLS & MOUNTAIN PEAKS (.glb) ===
  for (let i = 0; i < 40; i++) {
    const angle = (i / 40) * Math.PI * 2;
    const distX = 148 + (i % 3) * 10;
    const distZ = 84 + (i % 3) * 8;
    const hx = -72 + Math.cos(angle) * distX;
    const hz = Math.sin(angle) * distZ;
    // Leave east coast ocean side open so the sea horizon looks clear!
    if (hx > 36 && Math.abs(hz) < 58) continue;
    const isNorth = hz < -48;
    const prop = glbAssets.clone(
      isNorth ? '/assets/glb/environment/mountain_peak.glb' : '/assets/glb/environment/hill_mound.glb'
    );
    const scale = 0.95 + (i % 3) * 0.25;
    prop.position.set(hx, isNorth ? 0 : -1.5, hz);
    prop.scale.setScalar(scale);
    prop.rotation.y = angle;
    group.add(prop);
    occlusionTargets.push({ id: `hill_${i}`, obj: prop, x: hx, y: 2.5, z: hz, radius: 7.5, category: 'hill' });
  }

  // Baked opaque cliff occluder behind Whispering Cave mountain ridge
  cameraOccluders.push({ minX: -54, maxX: -42, minZ: -67, maxZ: -61, maxY: 6.5 });

  // === 7B. DENSE NATURAL PERIMETER FOREST & BUSHES AT WORLD BOUNDARIES ===
  // Closes off all inaccessible edges (West x < -186, North z < -62, South z > 62) naturally while keeping East Ocean open!
  const perimeterModels: Array<'oak' | 'pine' | 'birch'> = ['pine', 'oak', 'birch'];
  const perimeterPlacements: Array<[number, number, number]> = [];
  // West edge: x = -188 .. -200, z = -64 .. +64
  for (let z = -64; z <= 64; z += 5.4) {
    perimeterPlacements.push([-188.5 - ((Math.abs(Math.round(z)) % 3) * 1.4), z, 1.18]);
    perimeterPlacements.push([-195.5 - ((Math.abs(Math.round(z)) % 2) * 2.2), z + 2.4, 1.38]);
  }
  // North edge: z = -62 .. -72, x = -188 .. +36
  for (let x = -186; x <= 36; x += 5.6) {
    if (x >= -67 && x <= -61) continue; // West Brook channel
    perimeterPlacements.push([x, -62.2 - ((Math.abs(Math.round(x)) % 3) * 1.4), 1.18]);
    perimeterPlacements.push([x + 2.5, -69.0 - ((Math.abs(Math.round(x)) % 2) * 2.0), 1.36]);
  }
  // South edge: z = +62 .. +72, x = -188 .. +36
  for (let x = -186; x <= 36; x += 5.6) {
    if (x >= -67 && x <= -61) continue; // West Brook channel
    perimeterPlacements.push([x, 62.2 + ((Math.abs(Math.round(x)) % 3) * 1.4), 1.18]);
    perimeterPlacements.push([x + 2.5, 69.0 + ((Math.abs(Math.round(x)) % 2) * 2.0), 1.36]);
  }

  perimeterPlacements.forEach(([px, pz, sc], idx) => {
    const modelType = perimeterModels[idx % perimeterModels.length];
    const shade = idx % 3 === 0 ? 0x1e6b32 : idx % 3 === 1 ? 0x2d853d : 0x3f9646;
    const { mesh } = createDistinctTreeLodMesh(modelType, shade, maxAnisotropy, 18, 40);
    mesh.position.set(px, 0, pz);
    mesh.scale.setScalar(sc + (idx % 3) * 0.1);
    mesh.rotation.y = idx * 1.37;
    group.add(mesh);
    occlusionTargets.push({ id: `perim_tree_${idx}`, obj: mesh, x: px, y: 2.2, z: pz, radius: 2.0, category: 'tree' });

    // Dense 3D .glb undergrowth hedge/bush bridging trunk gaps along the boundary
    const bush = glbAssets.clone('/assets/glb/environment/bush_hedge.glb');
    const bScale = 1.25 + (idx % 2) * 0.25;
    bush.scale.set(bScale, bScale * 0.85, bScale);
    bush.position.set(px + (idx % 2 === 0 ? 1.8 : -1.8), 0, pz + 0.6);
    bush.rotation.y = idx * 0.9;
    group.add(bush);
    occlusionTargets.push({ id: `perim_bush_${idx}`, obj: bush, x: bush.position.x, y: 0.7, z: bush.position.z, radius: 1.5, category: 'prop' });
  });

  // === 8. GLOBAL PROTECTED FOREST (.glb InstancedMesh: 200-500 Trees across Town Square, Woods, Cave, Coast) ===
  const globalTreePools: Record<'oak' | 'pine' | 'birch', GlbTreeInstancePool> = {
    oak: buildGlbInstancedTreePool('oak', 300, maxAnisotropy),
    pine: buildGlbInstancedTreePool('pine', 300, maxAnisotropy),
    birch: buildGlbInstancedTreePool('birch', 300, maxAnisotropy),
  };
  (['oak', 'pine', 'birch'] as const).forEach((sp) => {
    group.add(globalTreePools[sp].trunk, globalTreePools[sp].crown);
  });

  const choppableTrees: ChoppableTreeNode[] = [];
  const globalTrees: ChoppableTreeNode[] = [];
  const farmTrees: ChoppableTreeNode[] = [];
  const valleyTreeCount = 0;

  // 8B. Per-farm randomized tree container (stored per-user in player save data!)
  const farmTreesGroup = new THREE.Group();
  group.add(farmTreesGroup);

  // === 9. REALISTIC SWAYING 3D GRASS TUFTS ===
  const { geometry: grassGeo } = glbAssets.getFirstMeshGeometryAndMaterial('/assets/glb/environment/grass_tuft.glb');
  const grassUniformTime = { value: 0 };
  const grassMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.88,
    metalness: 0.0,
    side: THREE.DoubleSide,
  });
  grassMat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = grassUniformTime;
    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
         uniform float uTime;`
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
         float swayAmt = clamp(position.y * 2.5, 0.0, 1.0);
         #ifdef USE_INSTANCING
           vec4 wPos = instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
           float wave = sin(uTime * 2.2 + wPos.x * 0.35 + wPos.z * 0.25) * 0.11;
         #else
           float wave = sin(uTime * 2.2) * 0.11;
         #endif
         transformed.x += wave * swayAmt;
         transformed.z += wave * 0.5 * swayAmt;`
      );
  };

  const maxGrass = 3400;
  const grassPositions: Array<{ x: number; z: number; s: number; rot: number }> = [];
  const fieldMinX = FARM_ORIGIN_X - 1.5;
  const fieldMaxX = FARM_ORIGIN_X + (FARM_GRID_COLS - 1) * FARM_TILE_STEP + 1.5;
  const fieldMinZ = FARM_ORIGIN_Z - 1.5;
  const fieldMaxZ = FARM_ORIGIN_Z + (FARM_GRID_ROWS - 1) * FARM_TILE_STEP + 1.5;

  let seed = 1337;
  const nextRand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  // === 9.5. OUTDOOR MINABLE ROCKS (.glb) + COLLIDERS (Validated before grass so grass never clips rocks!) ===
  const candidateRockCoords: [number, number][] = [
    [12, -36],
    [17, -33],
    [21, -29],
    [-41, -59],
    [-54, -58],
    [-43, -53],
    [-34, -55],
  ];
  const placedRockCoords: [number, number][] = [];
  candidateRockCoords.forEach(([rx, rz], idx) => {
    const blockedByBox = colliders.boxes.some(
      (b) => rx >= b.minX - 1.3 && rx <= b.maxX + 1.3 && rz >= b.minZ - 1.3 && rz <= b.maxZ + 1.3
    );
    const blockedByCircle = colliders.circles.some((c) => Math.hypot(rx - c.x, rz - c.z) < c.radius + 1.6);
    if (blockedByBox || blockedByCircle) return;
    placedRockCoords.push([rx, rz]);
    const rock = glbAssets.clone('/assets/glb/environment/mine_rock.glb');
    rock.position.set(rx, 0, rz);
    group.add(rock);
    colliders.circles.push({ x: rx, z: rz, radius: 0.95 });
    interactives.push({
      id: `mine_rock_${idx}`,
      kind: 'mine_rock',
      label: 'Mine Rock & Ore (Hammer) [F]',
      x: rx,
      z: rz,
      radius: 2.0,
      mesh: rock,
    });
  });

  // Extra dense tall wild grass border along West, North, and South edges (strictly avoiding water, cave & trails)
  for (let i = 0; i < 650; i++) {
    const edge = i % 3;
    let gx = 0;
    let gz = 0;
    if (edge === 0) {
      gx = -185.5 - nextRand() * 11;
      gz = (nextRand() - 0.5) * 126;
    } else if (edge === 1) {
      gx = -186 + nextRand() * 222;
      gz = -68.5 - nextRand() * 9;
    } else {
      gx = -186 + nextRand() * 222;
      gz = 60.5 + nextRand() * 10;
    }
    if (gx >= -68 && gx <= -60) continue; // West Brook
    if (Math.hypot(gx + 48, gz + 62) < 9.0) continue; // Relocated Far-Corner Cave mouth
    grassPositions.push({
      x: gx,
      z: gz,
      s: 1.35 + nextRand() * 0.9,
      rot: nextRand() * Math.PI * 2,
    });
  }

  for (let attempt = 0; attempt < 9500 && grassPositions.length < maxGrass; attempt++) {
    const gx = -184 + nextRand() * 218; // -184 .. +34
    const gz = -66 + nextRand() * 124; // -66 .. +58
    if (gx > 33) continue; // Keep sandy east beach & water clean
    if (gx >= -69 && gx <= -59) continue; // West Brook
    if (gx >= fieldMinX && gx <= fieldMaxX && gz >= fieldMinZ && gz <= fieldMaxZ) continue; // Farm plots
    if (Math.hypot(gx - 4, gz) < 22.8) continue; // Town Square Plaza
    // Keep all dirt roads, homestead promenade & far-corner cave mountain trail clear
    if (Math.abs(gz + 17.8) < 2.8 && gx >= -168 && gx <= -98) continue;
    if (Math.abs(gx + 106) < 2.6 && gz >= -20 && gz <= 2) continue;
    if (Math.abs(gz) < 2.6 && gx >= -108 && gx <= 40) continue;
    if (Math.abs(gx - 4) < 2.6 && gz >= -54 && gz <= 46) continue;
    if (Math.abs(gz + 52) < 2.6 && gx >= -51 && gx <= 6) continue;
    if (Math.abs(gx + 48) < 2.8 && gz >= -64 && gz <= -50) continue;
    if (Math.hypot(gx + 48, gz + 60) < 6.8) continue; // Cave doorway & apron
    // Strict Collision Check: never spawn grass inside buildings, fences, props, benches, rocks, or logs
    if (
      colliders.boxes.some(
        (b) => gx >= b.minX - 0.95 && gx <= b.maxX + 0.95 && gz >= b.minZ - 0.95 && gz <= b.maxZ + 1.5
      )
    ) {
      continue;
    }
    if (colliders.circles.some((c) => Math.hypot(gx - c.x, gz - c.z) < c.radius + 0.85)) {
      continue;
    }
    grassPositions.push({
      x: gx,
      z: gz,
      s: 0.75 + nextRand() * 0.75,
      rot: nextRand() * Math.PI * 2,
    });
  }

  const dummy = new THREE.Object3D();
  const tempColor = new THREE.Color();
  const grassInstanced = new THREE.InstancedMesh(grassGeo, grassMat, grassPositions.length);
  grassPositions.forEach((gp, idx) => {
    dummy.position.set(gp.x, 0, gp.z);
    dummy.scale.set(gp.s, gp.s * (0.85 + (idx % 3) * 0.15), gp.s);
    dummy.rotation.set(0, gp.rot, 0);
    dummy.updateMatrix();
    grassInstanced.setMatrixAt(idx, dummy.matrix);
    tempColor.setHex(SEASON_GRASS_TINT.Spring[idx % 4]);
    grassInstanced.setColorAt(idx, tempColor);
  });
  grassInstanced.instanceMatrix.needsUpdate = true;
  if (grassInstanced.instanceColor) grassInstanced.instanceColor.needsUpdate = true;
  grassInstanced.computeBoundingSphere();
  group.add(grassInstanced);

  // === 11. CHOPPABLE FOREST LOGS (.glb) + COLLIDERS ===
  const logCoords: [number, number][] = [
    [-16, 33],
    [-7, 36],
    [-18, 38],
    [9, 34],
  ];
  logCoords.forEach(([lx, lz], idx) => {
    const log = glbAssets.clone('/assets/glb/environment/forest_log.glb');
    log.position.set(lx, 0, lz);
    group.add(log);
    colliders.circles.push({ x: lx, z: lz, radius: 0.85, jumpable: true, topY: 0.46 });
    interactives.push({
      id: `forest_log_${idx}`,
      kind: 'forest_log',
      label: 'Chop Forest Log (Axe) [F]',
      x: lx,
      z: lz,
      radius: 2.0,
      mesh: log,
    });
  });

  // === 12. SECRET GROVE ANCIENT SHRINE (.glb) — Protected event monument ===
  const secretBarrier = glbAssets.clone('/assets/glb/environment/secret_shrine.glb');
  secretBarrier.position.set(-22, 0, 42);
  secretBarrier.traverse((obj) => {
    if (obj.name === 'RunePart' && (obj as THREE.Mesh).isMesh) {
      const mat = (obj as THREE.Mesh).material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = secretUnlocked ? 0.9 : 0.2;
    }
  });
  group.add(secretBarrier);
  colliders.circles.push({ x: -23.8, z: 42, radius: 0.65 });
  colliders.circles.push({ x: -20.2, z: 42, radius: 0.65 });
  interactives.push({
    id: 'secret_gate',
    kind: 'secret_gate',
    label: secretUnlocked ? 'Ancient Secret Grove Shrine [F]' : 'Locked Ancient Gate (Elian Quest) [F]',
    x: -22,
    z: 42,
    radius: 2.4,
  });

  const refs: OutdoorWorldRefs = {
    group,
    groundMat,
    choppableTrees,
    globalTrees,
    farmTrees,
    globalTreePools,
    farmTreesGroup,
    valleyTreeCount,
    farmTreeOwnerKey: '',
    grassInstanced,
    maxGrassCount: grassPositions.length,
    grassUniformTime,
    waterMesh,
    brookMesh,
    waterTex,
    windowMats,
    interactives,
    signboards,
    colliders,
    cameraOccluders,
    occlusionTargets,
    festivalDecorGroup,
    secretBarrier,
    appleTreeGroup,
    beehiveGroup,
    beePoints,
  };

  syncGlobalTrees(refs, generateFallbackGlobalTrees(320), 'Spring');
  rebuildFarmTrees(refs, 'default_valley_farm', 'Spring');
  return refs;
}

export function hashStringToSeed(str: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) || 1337;
}

// Strict 7-check resource spawn validation (Collision, Distance, Surface, Height, Water, Buildings, Navigation)
export function isBlockedGlobalTreeSpot(tx: number, tz: number): boolean {
  // 1. Water & Surface bounds check (keep West Brook, Farm Estate, Eastern Beach/Ocean & map edges clear)
  if (tx < -58.5) return true;
  if (tx > 34.5) return true;
  if (tz < -66.0 || tz > 52.5) return true;
  // 2. Town Square plaza, fountain & NPC bench sitting area clear
  if (Math.hypot(tx - 4, tz) < 20.0) return true;
  // 3. Navigation corridors: all main roads, bridge lane & far-corner mountain cave trail
  if (Math.abs(tz) < 4.2 && tx >= -62 && tx <= 42) return true;
  if (Math.abs(tx - 4) < 4.2 && tz >= -55 && tz <= 48) return true;
  if (Math.abs(tz + 52) < 4.0 && tx >= -52 && tx <= 8) return true;
  if (Math.abs(tx + 48) < 4.4 && tz >= -66 && tz <= -48) return true;
  // 4. Festival stage, Secret Shrine, Smithy, Relocated Far-Corner Cave & Mine Rock zones clear
  if (tx >= -3.5 && tx <= 11.5 && tz >= -18.5 && tz <= -7.5) return true;
  if (Math.hypot(tx + 22, tz - 42) < 5.2) return true;
  if (Math.hypot(tx + 48, tz + 60) < 8.5) return true; // Relocated Far-Corner Cave doorway & apron
  if (Math.hypot(tx - 6, tz + 37) < 5.8) return true;  // Smithy doorway
  // 5. Outdoor minable rocks & choppable forest logs clearance
  const reservedResourceSpots: Array<[number, number, number]> = [
    [12, -36, 3.0],
    [17, -33, 3.0],
    [21, -29, 3.0],
    [-41, -59, 3.2],
    [-54, -58, 3.2],
    [-43, -53, 3.2],
    [-34, -55, 3.2],
    [-16, 33, 3.0],
    [-7, 36, 3.0],
    [-18, 38, 3.0],
    [9, 34, 3.0],
  ];
  for (const [rx, rz, rr] of reservedResourceSpots) {
    if (Math.hypot(tx - rx, tz - rz) < rr) return true;
  }
  // 6. All village & mountain building footprints (actual center + doorways + NPC approach space)
  for (const p of BUILDING_PORTALS) {
    if (p.outdoorZone === 'farm_home') continue;
    const swapped = p.facing === 'east' || p.facing === 'west';
    const halfW = (swapped ? p.depth : p.width) * 0.5 + 3.2;
    const halfD = (swapped ? p.width : p.depth) * 0.5 + 3.2;
    let cx = p.doorX;
    let cz = p.doorZ - (p.depth * 0.5 + 0.65);
    if (p.facing === 'north') cz = p.doorZ + (p.depth * 0.5 + 0.65);
    else if (p.facing === 'east') { cx = p.doorX - (p.depth * 0.5 + 0.65); cz = p.doorZ; }
    else if (p.facing === 'west') { cx = p.doorX + (p.depth * 0.5 + 0.65); cz = p.doorZ; }
    if (Math.abs(tx - cx) < halfW && Math.abs(tz - cz) < halfD) return true;
    if (Math.hypot(tx - p.doorX, tz - p.doorZ) < 4.5) return true;
    if (Math.hypot(tx - p.exitSpawnX, tz - p.exitSpawnZ) < 4.5) return true;
  }
  return false;
}

export function generateFallbackGlobalTrees(targetCount = 320, seedKey = 'great_valley_global_v1'): WorldTreeRecord[] {
  let s = hashStringToSeed(seedKey);
  const rand = () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
  const models: Array<'oak' | 'pine' | 'birch'> = ['oak', 'pine', 'birch'];
  const result: WorldTreeRecord[] = [];
  const zones: Array<{ zone: WorldTreeRecord['zone']; minX: number; maxX: number; minZ: number; maxZ: number; weight: number }> = [
    { zone: 'forest', minX: -56, maxX: 33, minZ: 27, maxZ: 51, weight: 0.36 },
    { zone: 'mountain_mine', minX: -56, maxX: 33, minZ: -64, maxZ: -27, weight: 0.30 },
    { zone: 'village_square', minX: -56, maxX: 32, minZ: -26, maxZ: 26, weight: 0.24 },
    { zone: 'river_beach', minX: 22, maxX: 34, minZ: -44, maxZ: 44, weight: 0.1 },
  ];

  let attempts = 0;
  while (result.length < targetCount && attempts < targetCount * 28) {
    attempts++;
    let roll = rand();
    let picked = zones[0];
    for (const z of zones) {
      roll -= z.weight;
      if (roll <= 0) {
        picked = z;
        break;
      }
    }
    const tx = Number((picked.minX + rand() * (picked.maxX - picked.minX)).toFixed(2));
    const tz = Number((picked.minZ + rand() * (picked.maxZ - picked.minZ)).toFixed(2));
    if (isBlockedGlobalTreeSpot(tx, tz)) continue;
    const minSpace = picked.zone === 'village_square' ? 3.5 : 2.85;
    if (result.some((t) => Math.hypot(t.x - tx, t.z - tz) < minSpace)) continue;
    const model = models[Math.floor(rand() * models.length)];
    result.push({
      id: `gtree_${result.length}_${Math.floor(rand() * 9999)}`,
      zone: picked.zone,
      scope: 'global',
      model,
      x: tx,
      z: tz,
      scale: Number((0.78 + rand() * 0.48).toFixed(2)),
      rotation: Number((rand() * Math.PI * 2).toFixed(2)),
      chopped: false,
      plantedAt: Date.now(),
    });
  }
  return result;
}

export function generateUserFarmTrees(ownerKey: string, targetCount = 34): WorldTreeRecord[] {
  const normalizedKey = ownerKey || 'default_valley_farm';
  let state = hashStringToSeed(`${normalizedKey}_yard_trees_v2`);
  const rand = () => {
    state = (state * 1664525 + 1013904223) >>> 0;
    return state / 4294967296;
  };
  const fieldMinX = FARM_ORIGIN_X - 3.2;
  const fieldMaxX = FARM_ORIGIN_X + (FARM_GRID_COLS - 1) * FARM_TILE_STEP + 3.2;
  const fieldMinZ = FARM_ORIGIN_Z - 3.2;
  const fieldMaxZ = FARM_ORIGIN_Z + (FARM_GRID_ROWS - 1) * FARM_TILE_STEP + 3.2;
  const models: Array<'oak' | 'pine' | 'birch'> = ['oak', 'pine', 'birch'];
  const out: WorldTreeRecord[] = [];

  for (let attempt = 0; attempt < 900 && out.length < targetCount; attempt++) {
    const tx = Number((-180 + rand() * 108).toFixed(2)); // -180 .. -72 (safely west of West Brook)
    const tz = Number((-54 + rand() * 106).toFixed(2));  // -54 .. +52
    // Keep crop field + fences + margins completely clear
    if (tx >= fieldMinX - 1.5 && tx <= fieldMaxX + 1.5 && tz >= fieldMinZ - 1.5 && tz <= fieldMaxZ + 1.5) continue;
    // Keep animal outdoor grazing corridor & homestead promenade clear
    if (Math.abs(tz + 17.8) < 5.2 && tx >= -174 && tx <= -96) continue;
    if (Math.abs(tx + 106) < 4.8 && tz >= -22 && tz <= 4) continue;
    if (Math.abs(tz) < 4.5 && tx >= -112 && tx <= -66) continue;
    if (tx >= -166 && tx <= -100 && tz >= -25 && tz <= -8) continue; // Animal barn/coop/stable/doghouse yard
    if (Math.hypot(tx - APPLE_TREE_POS.x, tz - APPLE_TREE_POS.z) < 5.0) continue;
    if (Math.hypot(tx - DOGHOUSE_POS.x, tz - DOGHOUSE_POS.z) < 4.8) continue;
    if (Math.hypot(tx - SHIPPING_BIN_POS.x, tz - SHIPPING_BIN_POS.z) < 4.8) continue;
    let hitsBuilding = false;
    for (const p of BUILDING_PORTALS) {
      if (p.outdoorZone !== 'farm_home') continue;
      if (Math.abs(tx - p.doorX) < p.width / 2 + 4.8 && Math.abs(tz - (p.doorZ - p.depth * 0.5)) < p.depth / 2 + 5.0) {
        hitsBuilding = true;
        break;
      }
      if (Math.hypot(tx - p.exitSpawnX, tz - p.exitSpawnZ) < 4.8) {
        hitsBuilding = true;
        break;
      }
    }
    if (hitsBuilding) continue;
    if (out.some((p) => Math.hypot(p.x - tx, p.z - tz) < 4.5)) continue;
    const model = models[Math.floor(rand() * models.length)];
    // Assign 4-tier tree levels on Farm Estate: Lv.2 (small), Lv.3 (medium), Lv.4 (large ancient tree)
    const lvRoll = rand();
    const level: 2 | 3 | 4 = lvRoll < 0.34 ? 2 : lvRoll < 0.72 ? 3 : 4;
    const scale =
      level === 2
        ? Number((0.72 + rand() * 0.12).toFixed(2))
        : level === 3
          ? Number((0.96 + rand() * 0.12).toFixed(2))
          : Number((1.22 + rand() * 0.18).toFixed(2));
    out.push({
      id: `farm_tree_${out.length}`,
      zone: 'farm_home',
      scope: 'farm',
      model,
      level,
      x: tx,
      z: tz,
      scale,
      rotation: Number((rand() * Math.PI * 2).toFixed(2)),
      chopped: false,
      plantedAt: Date.now(),
    });
  }
  return out;
}

function rebuildCombinedChoppableList(refs: OutdoorWorldRefs) {
  refs.choppableTrees.length = 0;
  refs.choppableTrees.push(...refs.globalTrees, ...refs.farmTrees);
  refs.valleyTreeCount = refs.globalTrees.length;
}

const _treeDummy = new THREE.Object3D();
const _treeColor = new THREE.Color();

export function syncGlobalTrees(refs: OutdoorWorldRefs, records: WorldTreeRecord[], season: Season) {
  const palette = SEASON_FOLIAGE[season];
  const counts: Record<'oak' | 'pine' | 'birch', number> = { oak: 0, pine: 0, birch: 0 };
  refs.globalTrees.length = 0;

  for (let i = 0; i < records.length; i++) {
    const rec = records[i];
    if (rec.chopped) continue;
    const sp: 'oak' | 'pine' | 'birch' =
      rec.model === 'pine' || rec.model === 'birch' ? rec.model : 'oak';
    const pool = refs.globalTreePools[sp];
    const idx = counts[sp];
    if (idx >= pool.capacity) continue;

    _treeDummy.position.set(rec.x, 0, rec.z);
    _treeDummy.rotation.set(0, rec.rotation, 0);
    _treeDummy.scale.setScalar(rec.scale);
    _treeDummy.updateMatrix();

    pool.trunk.setMatrixAt(idx, _treeDummy.matrix);
    pool.crown.setMatrixAt(idx, _treeDummy.matrix);
    _treeColor.setHex(palette[i % palette.length]);
    pool.crown.setColorAt(idx, _treeColor);
    counts[sp] = idx + 1;

    const treeLevel: 1 | 2 | 3 | 4 = rec.level ?? (rec.scale < 0.9 ? 2 : rec.scale < 1.12 ? 3 : 4);
    refs.globalTrees.push({
      id: rec.id,
      x: rec.x,
      z: rec.z,
      radius: Math.max(0.52, 0.58 * rec.scale),
      scope: 'global',
      zone: rec.zone,
      model: sp,
      level: treeLevel,
      crownMats: [pool.crownMat],
      chopped: false,
    });
  }

  (['oak', 'pine', 'birch'] as const).forEach((sp) => {
    const pool = refs.globalTreePools[sp];
    pool.trunk.count = counts[sp];
    pool.crown.count = counts[sp];
    pool.trunk.instanceMatrix.needsUpdate = true;
    pool.crown.instanceMatrix.needsUpdate = true;
    if (pool.crown.instanceColor) pool.crown.instanceColor.needsUpdate = true;
  });

  rebuildCombinedChoppableList(refs);
}

export function rebuildFarmTrees(
  refs: OutdoorWorldRefs,
  ownerKey: string,
  season: Season,
  savedFarmTrees?: WorldTreeRecord[]
) {
  const normalizedKey = ownerKey || 'default_valley_farm';
  const records =
    savedFarmTrees && savedFarmTrees.length > 0 ? savedFarmTrees : generateUserFarmTrees(normalizedKey);
  const signature = `${normalizedKey}:${records.map((r) => `${r.id}${r.chopped ? 'x' : r.isStump ? 's' : ''}`).join(',')}`;
  if (refs.farmTreeOwnerKey === signature && refs.farmTrees.length > 0) {
    return;
  }
  refs.farmTreeOwnerKey = signature;

  // Clear previous farm-estate trees and unregister stale farm tree occlusion targets
  for (let i = refs.occlusionTargets.length - 1; i >= 0; i--) {
    if (refs.occlusionTargets[i].id.startsWith('farm_tree_occ_')) {
      refs.occlusionTargets.splice(i, 1);
    }
  }
  while (refs.farmTreesGroup.children.length > 0) {
    refs.farmTreesGroup.remove(refs.farmTreesGroup.children[0]);
  }
  refs.farmTrees.length = 0;

  const seasonPalette = SEASON_FOLIAGE[season];
  const speciesList = TREE_SPECIES.length > 0 ? TREE_SPECIES : [];

  records.forEach((rec, idx) => {
    const sp = speciesList.find((x) => x.treeModel === rec.model);
    const baseHex =
      season === 'Spring' || season === 'Summer'
        ? sp
          ? new THREE.Color(sp.foliageHex).getHex()
          : seasonPalette[idx % seasonPalette.length]
        : seasonPalette[idx % seasonPalette.length];

    const treeLevel: 1 | 2 | 3 | 4 = rec.level ?? (rec.scale < 0.9 ? 2 : rec.scale < 1.12 ? 3 : 4);
    const { mesh: treeMesh, crownMats } = createDistinctTreeLodMesh(rec.model, baseHex, 4, 16, 36);
    treeMesh.position.set(rec.x, 0, rec.z);
    treeMesh.scale.setScalar(rec.scale);
    treeMesh.rotation.y = rec.rotation;
    treeMesh.visible = !rec.chopped && !rec.isStump;

    const stumpMesh = createTreeStumpMesh(Math.max(0.85, rec.scale * 0.92));
    stumpMesh.position.set(rec.x, 0, rec.z);
    stumpMesh.rotation.y = rec.rotation;
    stumpMesh.visible = !rec.chopped && Boolean(rec.isStump);

    refs.farmTreesGroup.add(treeMesh, stumpMesh);
    const treeNode: ChoppableTreeNode = {
      id: rec.id,
      x: rec.x,
      z: rec.z,
      radius: rec.isStump ? Math.max(0.54, 0.58 * rec.scale) : Math.max(0.52, 0.6 * rec.scale),
      scope: 'farm',
      zone: 'farm_home',
      model: rec.model,
      level: treeLevel,
      mesh: treeMesh,
      stumpMesh,
      crownMats,
      chopped: Boolean(rec.chopped),
      isStump: Boolean(rec.isStump),
      scale: rec.scale,
      topY: rec.isStump ? 0.46 : undefined,
    };
    refs.farmTrees.push(treeNode);
    refs.occlusionTargets.push({
      id: `farm_tree_occ_${rec.id}`,
      obj: treeMesh,
      x: rec.x,
      y: 2.2,
      z: rec.z,
      radius: 2.0 * rec.scale,
      category: 'tree',
      shouldBeVisible: () => !treeNode.chopped && !treeNode.isStump,
    });
  });

  rebuildCombinedChoppableList(refs);
}

/**
 * 3D Recessed Descent Pit + Wooden Ladder revealed in Whispering Cave when player discovers the floor exit hole.
 */
export function createCaveDescentHoleMesh(): THREE.Group {
  const g = new THREE.Group();
  const pitMat = new THREE.MeshStandardMaterial({ color: '#09090b', roughness: 0.98, metalness: 0.0 });
  const rimMat = getStdMat('#57534e', 0.94, 0.04);
  const woodMat = getStdMat('#92400e', 0.85, 0.03);

  const pit = new THREE.Mesh(new THREE.CircleGeometry(0.68, 16), pitMat);
  pit.rotation.x = -Math.PI / 2;
  pit.position.y = 0.025;
  g.add(pit);

  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.7, 0.09, 8, 18), rimMat);
  rim.rotation.x = Math.PI / 2;
  rim.position.y = 0.04;
  g.add(rim);

  // Wooden ladder rails sticking slightly out of the hole
  const railL = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.95, 0.07), woodMat);
  railL.position.set(-0.22, 0.22, -0.25);
  railL.rotation.x = 0.25;
  const railR = railL.clone();
  railR.position.x = 0.22;
  g.add(railL, railR);

  for (let i = 0; i < 4; i++) {
    const rung = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.05, 0.05), woodMat);
    rung.position.set(0, 0.06 + i * 0.2, -0.21 - i * 0.05);
    g.add(rung);
  }

  // Subtle emerald-amber marker glow so player spots the discovered ladder immediately
  const glow = new THREE.PointLight('#fbbf24', 1.1, 4.5);
  glow.position.set(0, 0.7, 0);
  g.add(glow);

  return g;
}

export function applySeasonToWorld(refs: OutdoorWorldRefs, season: Season) {
  refs.groundMat.color.set(SEASON_GROUND[season]);
  const palette = SEASON_FOLIAGE[season];
  const grassPalette = SEASON_GRASS_TINT[season];
  const color = new THREE.Color();

  refs.farmTrees.forEach((tree, i) => {
    tree.crownMats.forEach((mat) => mat.color.setHex(palette[i % palette.length]));
  });
  (['oak', 'pine', 'birch'] as const).forEach((sp, sIdx) => {
    const pool = refs.globalTreePools[sp];
    for (let i = 0; i < pool.crown.count; i++) {
      color.setHex(palette[(i + sIdx) % palette.length]);
      pool.crown.setColorAt(i, color);
    }
    if (pool.crown.instanceColor) pool.crown.instanceColor.needsUpdate = true;
  });

  for (let i = 0; i < refs.grassInstanced.count; i++) {
    color.setHex(grassPalette[i % grassPalette.length]);
    refs.grassInstanced.setColorAt(i, color);
  }
  if (refs.grassInstanced.instanceColor) {
    refs.grassInstanced.instanceColor.needsUpdate = true;
  }

  refs.appleTreeGroup.traverse((obj) => {
    if (obj.name === 'AppleFoliage' && (obj as THREE.Mesh).isMesh) {
      const m = obj as THREE.Mesh;
      (m.material as THREE.MeshStandardMaterial).color.setHex(palette[0]);
    }
  });
}

function createInteriorExitDoorMesh(isCave: boolean): THREE.Group {
  const g = new THREE.Group();
  const frameMat = getStdMat(isCave ? '#5c3b1e' : '#4a2912', 0.85, 0.04);
  const doorMat = getStdMat('#8a5228', 0.78, 0.05);
  const panelMat = getStdMat('#6c3e1b', 0.82, 0.04);
  const brassMat = getStdMat('#facc15', 0.25, 0.85);

  // Heavy Timber Frame
  const leftJamb = new THREE.Mesh(new THREE.BoxGeometry(0.24, 2.7, 0.28), frameMat);
  leftJamb.position.set(-1.12, 1.35, 0);
  const rightJamb = leftJamb.clone();
  rightJamb.position.x = 1.12;
  const headerBeam = new THREE.Mesh(new THREE.BoxGeometry(2.58, 0.28, 0.34), frameMat);
  headerBeam.position.set(0, 2.72, 0);
  g.add(leftJamb, rightJamb, headerBeam);

  if (isCave) {
    // Daylight cave exit opening seen from inside
    const daylightPortal = new THREE.Mesh(
      new THREE.PlaneGeometry(2.0, 2.55),
      getStdMat('#bae6fd', 0.2, 0, '#7dd3fc', 0.65)
    );
    daylightPortal.position.set(0, 1.28, -0.02);
    daylightPortal.rotation.y = Math.PI;
    g.add(daylightPortal);
  } else {
    // Detailed Interior Wooden Door Leaf with recessed panels, warm light gap & brass doorknob
    const doorLeaf = new THREE.Mesh(new THREE.BoxGeometry(2.0, 2.55, 0.12), doorMat);
    doorLeaf.position.set(0, 1.28, 0.02);
    const panelTop = new THREE.Mesh(new THREE.BoxGeometry(1.48, 0.92, 0.06), panelMat);
    panelTop.position.set(0, 1.82, -0.05);
    const panelBot = new THREE.Mesh(new THREE.BoxGeometry(1.48, 0.92, 0.06), panelMat);
    panelBot.position.set(0, 0.72, -0.05);
    const handle = new THREE.Mesh(new THREE.SphereGeometry(0.085, 10, 10), brassMat);
    handle.position.set(0.72, 1.18, -0.1);
    const lightStrip = new THREE.Mesh(
      new THREE.PlaneGeometry(1.96, 0.14),
      getStdMat('#fef08a', 0.2, 0, '#fde047', 0.85)
    );
    lightStrip.position.set(0, 0.07, -0.07);
    lightStrip.rotation.y = Math.PI;
    g.add(doorLeaf, panelTop, panelBot, handle, lightStrip);
  }

  // Overhead Illuminated EXIT / KELUAR Plaque facing inward (-Z)
  const exitSignTex = createCanvasTexture(
    (ctx, w, h) => {
      ctx.fillStyle = '#14532d';
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = '#86efac';
      ctx.lineWidth = 8;
      ctx.strokeRect(6, 6, w - 12, h - 12);
      ctx.fillStyle = '#ffffff';
      ctx.font = '900 44px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('EXIT · KELUAR', w / 2, h / 2);
    },
    256,
    1,
    4
  );
  exitSignTex.repeat.set(1, 1);
  const plaque = new THREE.Mesh(
    new THREE.PlaneGeometry(1.55, 0.42),
    new THREE.MeshStandardMaterial({
      map: exitSignTex,
      emissive: '#166534',
      emissiveIntensity: 0.45,
      roughness: 0.4,
    })
  );
  plaque.position.set(0, 3.06, -0.14);
  plaque.rotation.y = Math.PI;
  g.add(plaque);

  return g;
}

export function buildInteriorScene(
  zone: WorldZoneId,
  maxAnisotropy: number,
  opts: InteriorBuildOptions = {}
): {
  group: THREE.Group;
  interactives: InteractiveWorldNode[];
  colliders: WorldColliders;
  roomHalfW: number;
  roomHalfD: number;
} {
  const group = new THREE.Group();
  const interactives: InteractiveWorldNode[] = [];
  const colliders: WorldColliders = { boxes: [], circles: [] };
  const coopLevel = Math.max(1, Math.min(3, opts.coopLevel ?? 1));
  const barnLevel = Math.max(1, Math.min(3, opts.barnLevel ?? 1));
  const hasCheeseMaker = Boolean(opts.hasCheeseMaker);
  const coopIncubators = opts.coopIncubators || [];

  // === WHISPERING MOUNTAIN CAVE INTERIOR (Flat Diggable Gravel & Earth Floor, ZERO Protruding Boulders!) ===
  if (zone === 'int_cave') {
    const caveFloorTex = createCanvasTexture(
      (ctx, w, h) => {
        ctx.fillStyle = '#47423d';
        ctx.fillRect(0, 0, w, h);
        // Natural layered cavern dirt, gravel & fine pebbles
        for (let i = 0; i < 2200; i++) {
          const x = Math.random() * w;
          const y = Math.random() * h;
          const r = 1 + Math.random() * 3.2;
          const shade = Math.random();
          ctx.fillStyle =
            shade < 0.35
              ? 'rgba(30,27,24,0.34)'
              : shade < 0.7
                ? 'rgba(120,113,108,0.28)'
                : 'rgba(168,162,158,0.24)';
          ctx.beginPath();
          ctx.arc(x, y, r, 0, Math.PI * 2);
          ctx.fill();
        }
      },
      256,
      6,
      maxAnisotropy
    );

    const caveWallTex = createCanvasTexture(
      (ctx, w, h) => {
        ctx.fillStyle = '#292524';
        ctx.fillRect(0, 0, w, h);
        for (let y = 0; y < h; y += 26) {
          ctx.fillStyle = y % 52 === 0 ? 'rgba(68,64,60,0.38)' : 'rgba(15,23,42,0.3)';
          ctx.fillRect(0, y, w, 18);
        }
        for (let i = 0; i < 650; i++) {
          ctx.fillStyle = i % 2 === 0 ? 'rgba(148,163,184,0.12)' : 'rgba(12,10,9,0.28)';
          ctx.fillRect(Math.random() * w, Math.random() * h, 7, 4);
        }
      },
      256,
      4,
      maxAnisotropy
    );

    const floorW = 19;
    const floorD = 17;
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(floorW, floorD),
      new THREE.MeshStandardMaterial({
        map: caveFloorTex,
        bumpMap: caveFloorTex,
        bumpScale: 0.04,
        roughness: 0.94,
        metalness: 0.05,
      })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    group.add(floor);

    // Subtle flat gravel/pebble soil patches (100% walkable, zero protruding rocks!)
    const gravelPatchMat = getStdMat('#57534e', 0.96, 0.04);
    for (let i = 0; i < 24; i++) {
      const px = -7.4 + ((i * 5.7) % 14.8);
      const pz = -6.6 + ((i * 3.9) % 11.4);
      const patch = new THREE.Mesh(new THREE.CircleGeometry(0.55 + (i % 3) * 0.22, 10), gravelPatchMat);
      patch.rotation.x = -Math.PI / 2;
      patch.position.set(px, 0.008, pz);
      patch.receiveShadow = true;
      group.add(patch);
    }

    const rockWallMat = new THREE.MeshStandardMaterial({
      map: caveWallTex,
      bumpMap: caveWallTex,
      bumpScale: 0.06,
      roughness: 0.94,
      metalness: 0.06,
    });
    const backWall = new THREE.Mesh(new THREE.BoxGeometry(floorW, 5.2, 0.8), rockWallMat);
    backWall.position.set(0, 2.6, -floorD / 2);
    const leftWall = new THREE.Mesh(new THREE.BoxGeometry(0.8, 5.2, floorD), rockWallMat);
    leftWall.position.set(-floorW / 2, 2.6, 0);
    const rightWall = new THREE.Mesh(new THREE.BoxGeometry(0.8, 5.2, floorD), rockWallMat);
    rightWall.position.set(floorW / 2, 2.6, 0);
    group.add(backWall, leftWall, rightWall);

    // Glowing cavern wall crystal lanterns mounted high on cave walls (never blocking walking space)
    const lanternColors = ['#38bdf8', '#fbbf24', '#a855f7', '#10b981'];
    [
      [-8.7, -6.2],
      [8.7, -6.2],
      [-8.7, 3.6],
      [8.7, 3.6],
    ].forEach(([lx, lz], idx) => {
      const crystal = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.38, 0),
        getStdMat(lanternColors[idx], 0.2, 0.3, lanternColors[idx], 1.1)
      );
      crystal.position.set(lx, 2.35, lz);
      group.add(crystal);
      const pl = new THREE.PointLight(lanternColors[idx], 1.5, 13);
      pl.position.set(lx * 0.85, 2.5, lz);
      group.add(pl);
    });

    // Clear 3D Cave Exit Archway + Welcome Mat back to Mountain Mine Ridge
    const exitZ = floorD / 2 - 1.0;
    const exitDoor = createInteriorExitDoorMesh(true);
    exitDoor.position.set(0, 0, floorD / 2 - 0.14);
    group.add(exitDoor);
    const exitMat = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 1.3), getStdMat('#94a3b8', 0.9, 0));
    exitMat.rotation.x = -Math.PI / 2;
    exitMat.position.set(0, 0.02, exitZ);
    group.add(exitMat);
    interactives.push({
      id: 'exit_interior',
      kind: 'exit_door',
      label: 'Exit Cave to Mountain Ridge [F]',
      x: 0,
      z: exitZ,
      radius: 2.0,
    });

    return { group, interactives, colliders, roomHalfW: floorW / 2, roomHalfD: floorD / 2 };
  }

  const isBarnOrCoop = zone === 'int_barn' || zone === 'int_coop' || zone === 'int_stable';
  const floorTex = createCanvasTexture(
    (ctx, w, h) => {
      if (zone === 'int_blacksmith') {
        ctx.fillStyle = '#475569';
        ctx.fillRect(0, 0, w, h);
        for (let y = 0; y < h; y += 32) {
          for (let x = 0; x < w; x += 32) {
            ctx.fillStyle = (x + y) % 64 === 0 ? '#526074' : '#3e4c5e';
            ctx.fillRect(x + 2, y + 2, 28, 28);
          }
        }
      } else if (zone === 'int_clinic' || zone === 'int_bakery') {
        ctx.fillStyle = zone === 'int_clinic' ? '#e2e8f0' : '#fef3c7';
        ctx.fillRect(0, 0, w, h);
        for (let y = 0; y < h; y += 32) {
          for (let x = 0; x < w; x += 32) {
            if (((x / 32 + y / 32) | 0) % 2 === 0) {
              ctx.fillStyle = zone === 'int_clinic' ? '#cbd5e1' : '#fde68a';
              ctx.fillRect(x, y, 32, 32);
            }
          }
        }
      } else {
        ctx.fillStyle =
          zone === 'int_barn'
            ? '#a67b4d'
            : zone === 'int_stable'
              ? '#9a6b3e'
              : zone === 'int_coop'
                ? '#b88b52'
                : zone === 'int_library'
                  ? '#8c5a32'
                  : '#c08552';
        ctx.fillRect(0, 0, w, h);
        // Realistic plank grain & subtle straw flecks inside barns/coops
        for (let y = 0; y < h; y += 28) {
          ctx.fillStyle = y % 56 === 0 ? 'rgba(255,236,205,0.1)' : 'rgba(60,32,12,0.08)';
          ctx.fillRect(0, y, w, 26);
          ctx.strokeStyle = 'rgba(70,38,15,0.34)';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(w, y);
          ctx.stroke();
        }
        if (isBarnOrCoop) {
          for (let i = 0; i < 240; i++) {
            ctx.fillStyle = i % 2 === 0 ? 'rgba(234,179,8,0.28)' : 'rgba(202,138,4,0.22)';
            ctx.fillRect(Math.random() * w, Math.random() * h, 10, 2);
          }
        }
      }
    },
    256,
    5,
    maxAnisotropy
  );

  const interiorWallTex = createCanvasTexture(
    (ctx, w, h) => {
      const upperColor =
        zone === 'int_blacksmith'
          ? '#64748b'
          : zone === 'int_clinic'
            ? '#f0fdfa'
            : zone === 'int_flower_shop'
              ? '#fdf2f8'
              : zone === 'int_library'
                ? '#f3e8d2'
                : isBarnOrCoop
                  ? '#e2caa3'
                  : '#f7eedc';
      ctx.fillStyle = upperColor;
      ctx.fillRect(0, 0, w, h);
      // Subtle plaster/wallpaper texture stripes on upper wall
      ctx.fillStyle = 'rgba(0,0,0,0.035)';
      for (let x = 0; x < w; x += 24) {
        ctx.fillRect(x, 0, 6, h * 0.68);
      }
      // Lower wooden wainscoting + trim molding
      ctx.fillStyle = zone === 'int_blacksmith' ? '#334155' : isBarnOrCoop ? '#9a6a3d' : '#b78350';
      ctx.fillRect(0, h * 0.68, w, h * 0.32);
      ctx.strokeStyle = 'rgba(55,32,12,0.3)';
      ctx.lineWidth = 3;
      for (let x = 0; x < w; x += 32) {
        ctx.beginPath();
        ctx.moveTo(x, h * 0.68);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      ctx.fillStyle = 'rgba(72,42,18,0.42)';
      ctx.fillRect(0, h * 0.66, w, 7);
    },
    256,
    4,
    maxAnisotropy
  );

  // Livestock Buildings scale cleanly across Lv.1 (5 troughs) -> Lv.2 (10 troughs) -> Lv.3 (20 troughs)
  const floorW =
    zone === 'int_barn'
      ? barnLevel === 1
        ? 11
        : barnLevel === 2
          ? 15
          : 19
      : zone === 'int_coop'
        ? coopLevel === 1
          ? 10
          : coopLevel === 2
            ? 13
            : 17
        : zone === 'int_farmhouse' || zone === 'int_stable'
          ? 13
          : 12;
  const floorD =
    zone === 'int_barn'
      ? barnLevel === 1
        ? 9
        : barnLevel === 2
          ? 11
          : 13
      : zone === 'int_coop'
        ? coopLevel === 1
          ? 8
          : coopLevel === 2
            ? 10
            : 12
        : zone === 'int_farmhouse' || zone === 'int_stable'
          ? 11
          : 10;

  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(floorW, floorD),
    new THREE.MeshStandardMaterial({ map: floorTex, bumpMap: floorTex, bumpScale: 0.03, roughness: 0.84, metalness: 0.03 })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  group.add(floor);

  const wallMat = new THREE.MeshStandardMaterial({
    map: interiorWallTex,
    bumpMap: interiorWallTex,
    bumpScale: 0.025,
    roughness: 0.86,
    metalness: 0.02,
  });
  const backWall = new THREE.Mesh(new THREE.BoxGeometry(floorW, 4.4, 0.3), wallMat);
  backWall.position.set(0, 2.2, -floorD / 2);
  const leftWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, 4.4, floorD), wallMat);
  leftWall.position.set(-floorW / 2, 2.2, 0);
  const rightWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, 4.4, floorD), wallMat);
  rightWall.position.set(floorW / 2, 2.2, 0);
  // Low front-south doorframe wall flanking the interior Exit Door so players always clearly recognize the exit!
  const southWallHalfW = Math.max(1.2, floorW / 2 - 1.35);
  const southWallL = new THREE.Mesh(new THREE.BoxGeometry(southWallHalfW, 1.35, 0.22), wallMat);
  southWallL.position.set(-(1.35 + southWallHalfW / 2), 0.675, floorD / 2);
  const southWallR = new THREE.Mesh(new THREE.BoxGeometry(southWallHalfW, 1.35, 0.22), wallMat);
  southWallR.position.set(1.35 + southWallHalfW / 2, 0.675, floorD / 2);
  group.add(backWall, leftWall, rightWall, southWallL, southWallR);

  // Cozy Center Rug (non-barn/coop/stable)
  if (!isBarnOrCoop) {
    const rugColor =
      zone === 'int_flower_shop'
        ? '#be4b78'
        : zone === 'int_library'
          ? '#3b5284'
          : zone === 'int_blacksmith'
            ? '#475569'
            : '#9e3b24';
    const rug = new THREE.Mesh(new THREE.PlaneGeometry(5.5, 4.0), getStdMat(rugColor, 0.92, 0));
    rug.rotation.x = -Math.PI / 2;
    rug.position.set(0, 0.015, 0);
    rug.receiveShadow = true;
    group.add(rug);
  }

  // Distinct 3D Interior Exit Door + Welcome Mat back to Valley
  const exitZ = floorD / 2 - 0.9;
  const interiorExitDoor = createInteriorExitDoorMesh(false);
  interiorExitDoor.position.set(0, 0, floorD / 2 - 0.14);
  group.add(interiorExitDoor);
  const exitMat = new THREE.Mesh(new THREE.PlaneGeometry(2.3, 1.25), getStdMat('#c8922d', 0.85, 0));
  exitMat.rotation.x = -Math.PI / 2;
  exitMat.position.set(0, 0.02, exitZ);
  group.add(exitMat);
  interactives.push({
    id: 'exit_interior',
    kind: 'exit_door',
    label:
      zone === 'int_farmhouse' || zone === 'int_barn' || zone === 'int_coop' || zone === 'int_stable'
        ? 'Exit / Lock Door [F]'
        : 'Exit Building [F]',
    x: 0,
    z: exitZ,
    radius: 1.9,
  });

  // Interior-specific .glb Furniture & Solid Colliders
  if (zone === 'int_farmhouse') {
    const bed = glbAssets.clone('/assets/glb/environment/interior_bed.glb');
    bed.position.set(-4.2, 0, -3.2);
    group.add(bed);
    colliders.boxes.push({ minX: -5.3, maxX: -3.1, minZ: -4.7, maxZ: -1.7 });
    interactives.push({
      id: 'sleep_bed',
      kind: 'sleep_bed',
      label: 'Sleep & Advance to Next Day [F]',
      x: -3.6,
      z: -1.3,
      radius: 2.0,
    });

    const table = glbAssets.clone('/assets/glb/environment/interior_table.glb');
    table.position.set(0, 0, -2.6);
    const chairL = glbAssets.clone('/assets/glb/environment/interior_chair.glb');
    chairL.position.set(-1.55, 0, -2.6);
    chairL.rotation.y = Math.PI / 2;
    const chairR = glbAssets.clone('/assets/glb/environment/interior_chair.glb');
    chairR.position.set(1.55, 0, -2.6);
    chairR.rotation.y = -Math.PI / 2;
    group.add(table, chairL, chairR);
    colliders.boxes.push({ minX: -1.9, maxX: 1.9, minZ: -3.4, maxZ: -1.8 });

    // Functional Farmhouse Wardrobe (Switch stored Diamond Outfits)
    const wardrobe = glbAssets.clone('/assets/glb/environment/interior_wardrobe.glb');
    wardrobe.position.set(2.4, 0, -4.6);
    group.add(wardrobe);
    colliders.boxes.push({ minX: 1.45, maxX: 3.35, minZ: -5.2, maxZ: -4.05 });
    interactives.push({
      id: 'farmhouse_wardrobe',
      kind: 'use_wardrobe',
      label: 'Open Wardrobe (Change Outfits) [F]',
      x: 2.4,
      z: -3.4,
      radius: 1.9,
    });

    // Functional Farmhouse TV (Weather, Tips, Market Broadcast)
    const tv = glbAssets.clone('/assets/glb/environment/interior_tv.glb');
    tv.position.set(-4.9, 0, 0.5);
    tv.rotation.y = Math.PI / 2;
    group.add(tv);
    colliders.boxes.push({ minX: -5.5, maxX: -4.3, minZ: -0.3, maxZ: 1.3 });
    interactives.push({
      id: 'farmhouse_tv',
      kind: 'use_tv',
      label: 'Watch TV (Weather & Market Report) [F]',
      x: -3.8,
      z: 0.5,
      radius: 1.9,
    });

    // Functional Farmhouse Fridge
    const fridge = glbAssets.clone('/assets/glb/environment/interior_fridge.glb');
    fridge.position.set(4.8, 0, -3.6);
    group.add(fridge);
    colliders.boxes.push({ minX: 4.1, maxX: 5.5, minZ: -4.2, maxZ: -3.0 });
    interactives.push({
      id: 'farmhouse_fridge',
      kind: 'use_fridge',
      label: 'Open Fridge (Store Food & Harvests) [F]',
      x: 4.6,
      z: -2.4,
      radius: 1.9,
    });

    // Functional Farmhouse Toolbox Chest
    const toolbox = glbAssets.clone('/assets/glb/environment/interior_toolbox.glb');
    toolbox.position.set(4.9, 0, 0.5);
    toolbox.rotation.y = -Math.PI / 2;
    group.add(toolbox);
    colliders.boxes.push({ minX: 4.3, maxX: 5.5, minZ: -0.3, maxZ: 1.3 });
    interactives.push({
      id: 'farmhouse_toolbox',
      kind: 'use_toolbox',
      label: 'Open Toolbox (Store Tools) [F]',
      x: 3.8,
      z: 0.5,
      radius: 1.9,
    });
  } else if (zone === 'int_barn') {
    // Shared Cow & Sheep Barn: Lv.1 = 5 feeding troughs, Lv.2 = 10 troughs, Lv.3 = 20 troughs + Cheese Maker!
    const troughCount = getBarnCapacity(barnLevel);
    const woodMat = getStdMat('#7c4a26', 0.86, 0.04);
    const hayMat = getStdMat('#eab308', 0.94, 0.01);
    const rows = troughCount <= 5 ? 1 : 2;
    const perRow = Math.ceil(troughCount / rows);
    const rowWidth = floorW - 3.0;
    const stepX = perRow > 1 ? rowWidth / (perRow - 1) : 0;

    for (let r = 0; r < rows; r++) {
      const tz = r === 0 ? -floorD / 2 + 1.35 : -floorD / 2 + 4.2;
      for (let i = 0; i < perRow; i++) {
        const idx = r * perRow + i;
        if (idx >= troughCount) break;
        const tx = -rowWidth / 2 + i * stepX;
        const troughBox = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.5, 0.65), woodMat);
        troughBox.position.set(tx, 0.25, tz);
        troughBox.castShadow = true;
        troughBox.receiveShadow = true;
        const hayFill = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.22, 0.5), hayMat);
        hayFill.position.set(tx, 0.48, tz);
        group.add(troughBox, hayFill);
      }
      colliders.boxes.push({
        minX: -rowWidth / 2 - 0.6,
        maxX: rowWidth / 2 + 0.6,
        minZ: tz - 0.4,
        maxZ: tz + 0.4,
      });
    }

    // Artisan Cheese Maker (.glb — unlocked & placed inside Barn Lv.3 once purchased!)
    if (barnLevel >= 3 && hasCheeseMaker) {
      const cmX = floorW / 2 - 1.9;
      const cmZ = floorD / 2 - 2.6;
      const cmGroup = glbAssets.clone('/assets/glb/environment/cheese_maker.glb');
      cmGroup.position.set(cmX, 0, cmZ);
      group.add(cmGroup);
      colliders.circles.push({ x: cmX, z: cmZ, radius: 0.92 });
      interactives.push({
        id: 'barn_cheese_maker',
        kind: 'cheese_maker',
        label: 'Cheese Maker (Milk → Artisan Cheese) [F]',
        x: cmX,
        z: cmZ,
        radius: 2.2,
        mesh: cmGroup,
      });
    }
  } else if (zone === 'int_stable') {
    [-3.4, 3.4].forEach((sx) => {
      const stall = glbAssets.clone('/assets/glb/environment/interior_barn_stall.glb');
      stall.position.set(sx, 0, -3.9);
      group.add(stall);
      colliders.boxes.push({ minX: sx - 1.45, maxX: sx + 1.45, minZ: -4.6, maxZ: -3.05 });
    });
    const hayMat = getStdMat('#eab308', 0.95, 0.01);
    const hayL = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.85, 0.95), hayMat);
    hayL.position.set(-5.0, 0.425, 1.2);
    hayL.castShadow = true;
    const hayR = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.85, 0.95), hayMat);
    hayR.position.set(5.0, 0.425, 1.2);
    hayR.castShadow = true;
    const trough = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.55, 0.75), getStdMat('#78350f', 0.85, 0.05));
    trough.position.set(0, 0.275, -4.2);
    const waterTop = new THREE.Mesh(new THREE.PlaneGeometry(1.95, 0.55), getStdMat('#38bdf8', 0.15, 0.2));
    waterTop.rotation.x = -Math.PI / 2;
    waterTop.position.set(0, 0.56, -4.2);
    group.add(hayL, hayR, trough, waterTop);
    colliders.boxes.push({ minX: -5.7, maxX: -4.3, minZ: 0.7, maxZ: 1.7 });
    colliders.boxes.push({ minX: 4.3, maxX: 5.7, minZ: 0.7, maxZ: 1.7 });
    colliders.boxes.push({ minX: -1.15, maxX: 1.15, minZ: -4.6, maxZ: -3.8 });
  } else if (zone === 'int_coop') {
    // Chicken Coop: Lv.1 = 5 feeding troughs + 1 incubator, Lv.2 = 10 troughs + 1 incubator, Lv.3 = 20 troughs + 2 incubators!
    const troughCount = getCoopCapacity(coopLevel);
    const woodMat = getStdMat('#92592c', 0.85, 0.04);
    const grainMat = getStdMat('#f59e0b', 0.9, 0.02);
    const rows = troughCount <= 5 ? 1 : 2;
    const perRow = Math.ceil(troughCount / rows);
    const rowWidth = floorW - 2.6;
    const stepX = perRow > 1 ? rowWidth / (perRow - 1) : 0;

    for (let r = 0; r < rows; r++) {
      const tz = r === 0 ? -floorD / 2 + 1.25 : -floorD / 2 + 3.45;
      for (let i = 0; i < perRow; i++) {
        const idx = r * perRow + i;
        if (idx >= troughCount) break;
        const tx = -rowWidth / 2 + i * stepX;
        const feederBox = new THREE.Mesh(new THREE.BoxGeometry(0.88, 0.34, 0.5), woodMat);
        feederBox.position.set(tx, 0.17, tz);
        feederBox.castShadow = true;
        const seedFill = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.12, 0.36), grainMat);
        seedFill.position.set(tx, 0.34, tz);
        group.add(feederBox, seedFill);
      }
      colliders.boxes.push({
        minX: -rowWidth / 2 - 0.5,
        maxX: rowWidth / 2 + 0.5,
        minZ: tz - 0.32,
        maxZ: tz + 0.32,
      });
    }

    // Egg Incubator(s): 1 slot for Coop Lv.1 & Lv.2, 2 slots for Coop Lv.3!
    const incCount = getIncubatorCount(coopLevel);
    const incPositions: Array<[number, number]> =
      incCount === 1
        ? [[floorW / 2 - 1.5, floorD / 2 - 2.2]]
        : [
            [-floorW / 2 + 1.6, floorD / 2 - 2.2],
            [floorW / 2 - 1.6, floorD / 2 - 2.2],
          ];

    incPositions.forEach(([ix, iz], slotIdx) => {
      const slot = coopIncubators[slotIdx];
      const incGroup = glbAssets.clone('/assets/glb/environment/egg_incubator.glb');
      incGroup.position.set(ix, 0, iz);
      const hasEgg = Boolean(slot && slot.eggPlacedDay !== null);

      if (hasEgg && slot) {
        const ready = slot.readyToHatch || (slot.daysRemaining ?? 0) <= 0;
        const egg = new THREE.Mesh(
          new THREE.SphereGeometry(0.22, 12, 10),
          getStdMat(ready ? '#fef08a' : '#fffbeb', 0.4, 0.05, ready ? '#facc15' : '#000000', ready ? 0.5 : 0)
        );
        egg.scale.set(0.85, 1.15, 0.85);
        egg.position.set(0, 0.92, 0);
        incGroup.add(egg);
      }

      group.add(incGroup);
      colliders.boxes.push({ minX: ix - 0.68, maxX: ix + 0.68, minZ: iz - 0.62, maxZ: iz + 0.62 });

      const statusText = hasEgg && slot
        ? slot.readyToHatch || slot.daysRemaining <= 0
          ? `Hatch Baby Chick! (Incubator #${slotIdx + 1}) [F]`
          : `Incubator #${slotIdx + 1} (${slot.daysRemaining}d left) [F]`
        : `Egg Incubator #${slotIdx + 1} (Place Egg) [F]`;

      interactives.push({
        id: `egg_incubator_${slotIdx}`,
        kind: 'egg_incubator',
        slotIndex: slotIdx,
        label: statusText,
        x: ix,
        z: iz,
        radius: 2.0,
        mesh: incGroup,
      });
    });
  } else if (zone === 'int_blacksmith') {
    const anvil = glbAssets.clone('/assets/glb/environment/interior_anvil.glb');
    anvil.position.set(-2.5, 0, -2.2);
    colliders.boxes.push({ minX: -3.2, maxX: -1.8, minZ: -2.65, maxZ: -1.75 });

    const forge = glbAssets.clone('/assets/glb/environment/interior_forge.glb');
    forge.position.set(2.5, 0, -3.5);
    colliders.boxes.push({ minX: 1.35, maxX: 3.65, minZ: -4.25, maxZ: -2.6 });

    group.add(anvil, forge);
  } else {
    const counter = glbAssets.clone('/assets/glb/environment/interior_counter.glb');
    counter.position.set(0, 0, -2.5);
    colliders.boxes.push({ minX: -2.25, maxX: 2.25, minZ: -3.1, maxZ: -1.9 });

    const shelfL = glbAssets.clone('/assets/glb/environment/interior_shelf.glb');
    shelfL.position.set(-4.6, 0, -1.5);
    colliders.boxes.push({ minX: -5.25, maxX: -3.95, minZ: -3.15, maxZ: 0.15 });

    const shelfR = glbAssets.clone('/assets/glb/environment/interior_shelf.glb');
    shelfR.position.set(4.6, 0, -1.5);
    colliders.boxes.push({ minX: 3.95, maxX: 5.25, minZ: -3.15, maxZ: 0.15 });

    group.add(counter, shelfL, shelfR);
  }

  return { group, interactives, colliders, roomHalfW: floorW / 2, roomHalfD: floorD / 2 };
}
