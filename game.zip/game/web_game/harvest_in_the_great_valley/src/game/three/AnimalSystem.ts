import * as THREE from 'three';
import type { AnimalEmotion, AnimalState, Language, Season, Weather, WorldZoneId } from '../types';
import {
  APPLE_TREE_POS,
  BUILDING_PORTALS,
  DOG_FOOD_BOWL_POS,
  DOGHOUSE_POS,
  HORSE_STABLE_POS,
} from '../data/worldConfig';
import type { AABBCollider, CircleCollider } from './WorldBuilder';

export type AnimalBehaviorState =
  | 'idle'
  | 'walk'
  | 'run'
  | 'graze'
  | 'eat'
  | 'drink'
  | 'sleep'
  | 'rest_lie'
  | 'sit'
  | 'sniff'
  | 'bark'
  | 'play'
  | 'peck'
  | 'chase_bug'
  | 'roost'
  | 'shelter'
  | 'scratch'
  | 'stretch'
  | 'yawn'
  | 'look_around'
  | 'follow_player'
  | 'herd_follow'
  | 'shade_rest'
  | 'socialize';

export interface AnimalVisualRig {
  root: THREE.Group;
  bodyPivot: THREE.Group;
  chestMesh: THREE.Mesh;
  neckPivot: THREE.Group;
  headPivot: THREE.Group;
  leftEar: THREE.Group;
  rightEar: THREE.Group;
  leftEye: THREE.Mesh;
  rightEye: THREE.Mesh;
  leftEyelid: THREE.Mesh;
  rightEyelid: THREE.Mesh;
  muzzlePivot: THREE.Group;
  jawMesh: THREE.Mesh;
  noseMesh: THREE.Mesh;
  tailPivot: THREE.Group;
  tailTip?: THREE.Group;
  manePivot?: THREE.Group;
  leftWing?: THREE.Group;
  rightWing?: THREE.Group;
  legs: THREE.Group[]; // [FL, FR, BL, BR] or [L, R] for chicken
  coatMaterials: THREE.MeshStandardMaterial[];
  baseCoatColors: THREE.Color[];
  baseBodyY: number;
  baseScale: number;
}

export interface LivingAnimalActor {
  id: string;
  state: AnimalState;
  rig: AnimalVisualRig;
  pos: THREE.Vector3;
  targetPos: THREE.Vector3;
  homeX: number;
  homeZ: number;
  yaw: number;
  targetYaw: number;
  speed: number;
  gaitPhase: number;
  phaseOffset: number;
  behavior: AnimalBehaviorState;
  behaviorTimer: number;
  emotion: AnimalEmotion;
  hunger: number; // 0..100 (100 full)
  thirst: number; // 0..100 (100 hydrated)
  energy: number; // 0..100
  happiness: number; // 0..100
  health: number; // 0..100
  blinkTimer: number;
  blinkAmount: number;
  earAlertTimer: number;
  emoteCooldown: number;
  interactBoostTimer: number;
  stuckTimer: number;
  socialPartnerId: string | null;
  footprintAccum: number;
  // Smoothed animation blend weights
  blendWalk: number;
  blendRun: number;
  blendSit: number;
  blendLie: number;
  blendSleep: number;
  blendGraze: number;
  blendTailWag: number;
  blendHeadPitch: number;
  blendHeadYaw: number;
}

export interface AnimalWorldContext {
  dt: number;
  elapsed: number;
  zone: WorldZoneId;
  season: Season;
  weather: Weather;
  hour: number;
  language: Language;
  playerPos: THREE.Vector3;
  playerSpeed: number;
  npcPositions: Array<{ x: number; z: number }>;
  colliders: {
    boxes: AABBCollider[];
    circles: CircleCollider[];
  };
  treeCircles: Array<{ x: number; z: number; radius: number }>;
  farmObstacleCircles: Array<{ x: number; z: number; radius: number }>;
  barnLocked: boolean;
  coopLocked: boolean;
  stableLocked: boolean;
  getGroundY: (x: number, z: number) => number;
  onAnimalBubble?: (animalId: string, animalName: string, text: string, isThought?: boolean) => void;
  onFootprint?: (x: number, z: number, yaw: number, size: number, isSnow: boolean) => void;
}

// === ANIMAL VARIETY PALETTES (4 distinct breeds/coats per species) ===
interface CoatPalette {
  primary: string;
  secondary: string;
  accent: string;
  muzzle: string;
  hoofOrBeak: string;
  pattern: 'solid' | 'spotted' | 'patched' | 'dappled' | 'speckled';
}

const SPECIES_PALETTES: Record<AnimalState['type'], CoatPalette[]> = {
  dog: [
    { primary: '#d49a57', secondary: '#f3d9b1', accent: '#b87635', muzzle: '#f7e5c8', hoofOrBeak: '#2c1e16', pattern: 'patched' }, // Golden Retriever
    { primary: '#c86f33', secondary: '#f7ead6', accent: '#99481a', muzzle: '#fbf2e3', hoofOrBeak: '#261a14', pattern: 'patched' }, // Shiba Inu
    { primary: '#2d3138', secondary: '#f2f1ed', accent: '#4a505c', muzzle: '#f2f1ed', hoofOrBeak: '#1b1d22', pattern: 'spotted' }, // Border Collie
    { primary: '#7a6250', secondary: '#e9dcc9', accent: '#4d3a2c', muzzle: '#efe4d4', hoofOrBeak: '#241b16', pattern: 'patched' }, // Farm Shepherd
  ],
  horse: [
    { primary: '#8c4b27', secondary: '#3a1f12', accent: '#f0e6d8', muzzle: '#5e321a', hoofOrBeak: '#261d19', pattern: 'solid' }, // Chestnut Bay
    { primary: '#c4c7cc', secondary: '#6c727c', accent: '#e5e7eb', muzzle: '#9aa0a8', hoofOrBeak: '#35383d', pattern: 'dappled' }, // Dapple Grey
    { primary: '#d2a256', secondary: '#f5ebd1', accent: '#e7c682', muzzle: '#b38340', hoofOrBeak: '#382a1e', pattern: 'solid' }, // Palomino Gold
    { primary: '#342c28', secondary: '#1c1816', accent: '#f1ece4', muzzle: '#2a2320', hoofOrBeak: '#171412', pattern: 'patched' }, // Midnight Stallion
  ],
  chicken: [
    { primary: '#f2eee6', secondary: '#e3d9c6', accent: '#d93829', muzzle: '#e59f24', hoofOrBeak: '#e59f24', pattern: 'solid' }, // White Leghorn
    { primary: '#a84724', secondary: '#d67e40', accent: '#c92a2a', muzzle: '#eab308', hoofOrBeak: '#d97706', pattern: 'speckled' }, // Rhode Island Red
    { primary: '#52565e', secondary: '#e4e6eb', accent: '#d93829', muzzle: '#e59f24', hoofOrBeak: '#ca8a04', pattern: 'speckled' }, // Plymouth Speckled
    { primary: '#d99b43', secondary: '#f5d999', accent: '#dc2626', muzzle: '#f59e0b', hoofOrBeak: '#d97706', pattern: 'patched' }, // Golden Buff
  ],
  cow: [
    { primary: '#edeae2', secondary: '#262930', accent: '#f1b9bc', muzzle: '#efc2c4', hoofOrBeak: '#2b2522', pattern: 'spotted' }, // Holstein Dairy
    { primary: '#b57b48', secondary: '#e9d3b8', accent: '#ebb7b5', muzzle: '#ddb4a2', hoofOrBeak: '#36271d', pattern: 'patched' }, // Jersey Caramel
    { primary: '#704428', secondary: '#b8855c', accent: '#dba9a5', muzzle: '#9d7258', hoofOrBeak: '#2b1e16', pattern: 'solid' }, // Highland Brown
    { primary: '#dfd3be', secondary: '#8c6244', accent: '#ebbcc0', muzzle: '#e6c0be', hoofOrBeak: '#342923', pattern: 'spotted' }, // Guernsey Cream
  ],
  sheep: [
    { primary: '#f0ece1', secondary: '#dcd4c4', accent: '#4a403a', muzzle: '#4a403a', hoofOrBeak: '#2e2724', pattern: 'solid' }, // Snowy Merino
    { primary: '#e6dcc8', secondary: '#cdbda4', accent: '#332d2b', muzzle: '#332d2b', hoofOrBeak: '#221e1c', pattern: 'solid' }, // Warm Suffolk
    { primary: '#d4d6dc', secondary: '#aeb3be', accent: '#3c3e45', muzzle: '#4b4e57', hoofOrBeak: '#27292e', pattern: 'dappled' }, // Silver Fleece
    { primary: '#cbb59c', secondary: '#9a7d60', accent: '#523b2c', muzzle: '#523b2c', hoofOrBeak: '#2c1f17', pattern: 'patched' }, // Cocoa Highland
  ],
};

const coatTextureCache = new Map<string, THREE.CanvasTexture>();

function getProceduralCoatTexture(species: AnimalState['type'], variant: number): THREE.CanvasTexture {
  const key = `${species}_${variant}`;
  const cached = coatTextureCache.get(key);
  if (cached) return cached;

  const palette = SPECIES_PALETTES[species][variant % SPECIES_PALETTES[species].length];
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = palette.primary;
  ctx.fillRect(0, 0, 256, 256);

  // Deterministic pseudo-random seeded by species + variant
  let seed = (species.charCodeAt(0) * 131 + variant * 977 + 42) >>> 0;
  const rand = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };

  // Soft natural fur / feather / wool directional strokes
  if (species === 'sheep') {
    for (let i = 0; i < 420; i++) {
      const cx = rand() * 256;
      const cy = rand() * 256;
      const r = 6 + rand() * 12;
      ctx.fillStyle = i % 3 === 0 ? palette.secondary : palette.primary;
      ctx.globalAlpha = 0.42;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  } else if (species === 'chicken') {
    for (let i = 0; i < 480; i++) {
      const x = rand() * 256;
      const y = rand() * 256;
      ctx.fillStyle = i % 3 === 0 ? palette.secondary : palette.primary;
      ctx.globalAlpha = 0.45;
      ctx.beginPath();
      ctx.ellipse(x, y, 7 + rand() * 6, 3 + rand() * 2.5, 0.25, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  } else {
    // Fur / Hide fine strand grain
    for (let i = 0; i < 1200; i++) {
      const x = rand() * 256;
      const y = rand() * 256;
      ctx.strokeStyle = i % 2 === 0 ? 'rgba(255,255,255,0.09)' : 'rgba(20,12,6,0.09)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + (rand() - 0.5) * 4, y + 6 + rand() * 8);
      ctx.stroke();
    }
  }

  // Breed markings (spots, dapples, patches, speckles)
  if (palette.pattern === 'spotted') {
    ctx.fillStyle = palette.secondary;
    for (let i = 0; i < 14; i++) {
      ctx.beginPath();
      ctx.ellipse(rand() * 256, rand() * 256, 16 + rand() * 26, 12 + rand() * 22, rand() * Math.PI, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (palette.pattern === 'dappled') {
    ctx.fillStyle = palette.secondary;
    ctx.globalAlpha = 0.35;
    for (let i = 0; i < 42; i++) {
      ctx.beginPath();
      ctx.arc(rand() * 256, rand() * 256, 5 + rand() * 11, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  } else if (palette.pattern === 'patched') {
    ctx.fillStyle = palette.secondary;
    ctx.globalAlpha = 0.55;
    ctx.beginPath();
    ctx.ellipse(128, 188, 92, 54, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  } else if (palette.pattern === 'speckled') {
    ctx.fillStyle = palette.secondary;
    for (let i = 0; i < 65; i++) {
      ctx.beginPath();
      ctx.arc(rand() * 256, rand() * 256, 2 + rand() * 4.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  coatTextureCache.set(key, tex);
  return tex;
}

function createRadialShadow(radius: number): THREE.Mesh {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(32, 32, 4, 32, 32, 30);
  grad.addColorStop(0, 'rgba(18, 12, 8, 0.42)');
  grad.addColorStop(0.65, 'rgba(18, 12, 8, 0.16)');
  grad.addColorStop(1, 'rgba(18, 12, 8, 0.0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 64);
  const tex = new THREE.CanvasTexture(canvas);
  const mat = new THREE.MeshBasicMaterial({
    map: tex,
    transparent: true,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(radius * 2.2, radius * 2.2), mat);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = 0.018;
  return mesh;
}

export function hashAnimalSeed(id: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/**
 * Builds a realistic, multi-part articulated 3D Animal Rig with breed variety,
 * procedural fur/wool/feather PBR textures, facial blink/ear/mouth rig,
 * breathing chest, dynamic tail/mane, and grounded contact shadow.
 */
export function createLivingAnimalRig(
  type: AnimalState['type'],
  animalId: string,
  breedVariantInput?: number,
  sizeScaleInput?: number
): AnimalVisualRig {
  const seed = hashAnimalSeed(animalId);
  const variant = typeof breedVariantInput === 'number' ? Math.abs(breedVariantInput) % 4 : seed % 4;
  const sizeScale =
    typeof sizeScaleInput === 'number'
      ? THREE.MathUtils.clamp(sizeScaleInput, 0.88, 1.14)
      : 0.94 + ((seed % 17) / 16) * 0.14;

  const palette = SPECIES_PALETTES[type][variant];
  const coatTex = getProceduralCoatTexture(type, variant);

  const coatMat = new THREE.MeshStandardMaterial({
    color: '#ffffff',
    map: coatTex,
    roughness: type === 'sheep' ? 0.96 : type === 'chicken' ? 0.84 : 0.88,
    metalness: 0.0,
  });
  const secondaryMat = new THREE.MeshStandardMaterial({
    color: palette.secondary,
    roughness: 0.9,
    metalness: 0.0,
  });
  const muzzleMat = new THREE.MeshStandardMaterial({
    color: palette.muzzle,
    roughness: 0.78,
    metalness: 0.02,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: palette.accent,
    roughness: 0.65,
    metalness: 0.04,
  });
  const hoofMat = new THREE.MeshStandardMaterial({
    color: palette.hoofOrBeak,
    roughness: 0.42,
    metalness: 0.08,
  });
  const eyeWhiteMat = new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.16, metalness: 0.05 });
  const pupilMat = new THREE.MeshStandardMaterial({ color: '#181412', roughness: 0.1, metalness: 0.12 });
  const eyelidMat = new THREE.MeshStandardMaterial({ color: palette.primary, roughness: 0.85, metalness: 0.0 });

  const coatMaterials = [coatMat, secondaryMat, eyelidMat];
  const baseCoatColors = coatMaterials.map((m) => m.color.clone());

  const root = new THREE.Group();
  root.scale.setScalar(sizeScale);

  const bodyPivot = new THREE.Group();
  root.add(bodyPivot);

  const neckPivot = new THREE.Group();
  const headPivot = new THREE.Group();
  const leftEar = new THREE.Group();
  const rightEar = new THREE.Group();
  const muzzlePivot = new THREE.Group();
  const tailPivot = new THREE.Group();
  let tailTip: THREE.Group | undefined;
  let manePivot: THREE.Group | undefined;
  let leftWing: THREE.Group | undefined;
  let rightWing: THREE.Group | undefined;
  const legs: THREE.Group[] = [];

  const enableShadows = (obj: THREE.Object3D) => {
    obj.traverse((c) => {
      if ((c as THREE.Mesh).isMesh) {
        c.castShadow = true;
        c.receiveShadow = true;
      }
    });
  };

  let chestMesh: THREE.Mesh;
  let leftEye: THREE.Mesh;
  let rightEye: THREE.Mesh;
  let leftEyelid: THREE.Mesh;
  let rightEyelid: THREE.Mesh;
  let jawMesh: THREE.Mesh;
  let noseMesh: THREE.Mesh;
  let baseBodyY = 0.65;

  const makeEye = (side: -1 | 1, xOff: number, yOff: number, zOff: number, radius: number) => {
    const eyeGroup = new THREE.Group();
    eyeGroup.position.set(side * xOff, yOff, zOff);
    const sclera = new THREE.Mesh(new THREE.SphereGeometry(radius, 10, 8), eyeWhiteMat);
    const pupil = new THREE.Mesh(new THREE.SphereGeometry(radius * 0.66, 10, 8), pupilMat);
    pupil.position.set(side * radius * 0.12, 0, radius * 0.45);
    sclera.add(pupil);
    const lid = new THREE.Mesh(
      new THREE.SphereGeometry(radius * 1.12, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.55),
      eyelidMat
    );
    lid.rotation.x = -0.85; // open by default
    eyeGroup.add(sclera, lid);
    headPivot.add(eyeGroup);
    return { eye: sclera, lid };
  };

  if (type === 'dog') {
    baseBodyY = 0.44;
    bodyPivot.position.y = baseBodyY;

    // Slender athletic torso + breathing chest
    chestMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.18, 0.36, 8, 12), coatMat);
    chestMesh.rotation.x = Math.PI / 2;
    bodyPivot.add(chestMesh);

    const belly = new THREE.Mesh(new THREE.SphereGeometry(0.155, 10, 8), secondaryMat);
    belly.scale.set(0.92, 0.85, 1.35);
    belly.position.set(0, -0.05, 0.04);
    bodyPivot.add(belly);

    // Warm leather collar + brass bell tag
    const collarMat = new THREE.MeshStandardMaterial({ color: '#c2410c', roughness: 0.55, metalness: 0.05 });
    const brassMat = new THREE.MeshStandardMaterial({ color: '#f59e0b', roughness: 0.28, metalness: 0.78 });
    const collar = new THREE.Mesh(new THREE.TorusGeometry(0.145, 0.025, 8, 16), collarMat);
    collar.position.set(0, 0.07, 0.24);
    collar.rotation.x = 0.55;
    const bell = new THREE.Mesh(new THREE.SphereGeometry(0.032, 8, 8), brassMat);
    bell.position.set(0, -0.04, 0.33);
    bodyPivot.add(collar, bell);

    // Neck & expressive head
    neckPivot.position.set(0, 0.1, 0.24);
    bodyPivot.add(neckPivot);
    headPivot.position.set(0, 0.13, 0.12);
    neckPivot.add(headPivot);

    const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.165, 12, 10), coatMat);
    cranium.scale.set(0.95, 0.92, 1.05);
    headPivot.add(cranium);

    muzzlePivot.position.set(0, -0.03, 0.15);
    headPivot.add(muzzlePivot);
    const snout = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.085, 0.16), muzzleMat);
    snout.position.set(0, 0.01, 0.04);
    muzzlePivot.add(snout);
    jawMesh = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.04, 0.13), muzzleMat);
    jawMesh.position.set(0, -0.045, 0.03);
    muzzlePivot.add(jawMesh);
    noseMesh = new THREE.Mesh(new THREE.SphereGeometry(0.032, 8, 8), hoofMat);
    noseMesh.position.set(0, 0.035, 0.125);
    muzzlePivot.add(noseMesh);

    const lE = makeEye(-1, 0.075, 0.04, 0.13, 0.03);
    const rE = makeEye(1, 0.075, 0.04, 0.13, 0.03);
    leftEye = lE.eye;
    rightEye = rE.eye;
    leftEyelid = lE.lid;
    rightEyelid = rE.lid;

    // Articulated expressive ears
    leftEar.position.set(-0.115, 0.12, 0.01);
    rightEar.position.set(0.115, 0.12, 0.01);
    const earGeo = new THREE.ConeGeometry(0.055, 0.16, 6);
    const lEarM = new THREE.Mesh(earGeo, accentMat);
    lEarM.position.set(-0.01, 0.06, 0);
    lEarM.rotation.z = variant === 0 ? 2.55 : 0.25; // floppy for Golden, perky for Shiba/Collie
    const rEarM = new THREE.Mesh(earGeo, accentMat);
    rEarM.position.set(0.01, 0.06, 0);
    rEarM.rotation.z = variant === 0 ? -2.55 : -0.25;
    leftEar.add(lEarM);
    rightEar.add(rEarM);
    headPivot.add(leftEar, rightEar);

    // Dynamic fluffy tail
    tailPivot.position.set(0, 0.09, -0.27);
    bodyPivot.add(tailPivot);
    const tailBase = new THREE.Mesh(new THREE.CapsuleGeometry(0.038, 0.22, 6, 8), coatMat);
    tailBase.position.set(0, 0.1, -0.08);
    tailBase.rotation.x = -0.65;
    tailPivot.add(tailBase);
    tailTip = new THREE.Group();
    tailTip.position.set(0, 0.19, -0.15);
    const tipMesh = new THREE.Mesh(new THREE.SphereGeometry(0.048, 8, 8), secondaryMat);
    tailTip.add(tipMesh);
    tailPivot.add(tailTip);

    // 4 articulated legs with paws
    const legCoords: Array<[number, number]> = [
      [-0.11, 0.19],
      [0.11, 0.19],
      [-0.11, -0.19],
      [0.11, -0.19],
    ];
    for (const [lx, lz] of legCoords) {
      const leg = new THREE.Group();
      leg.position.set(lx, -0.06, lz);
      const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.044, 0.24, 6, 8), coatMat);
      upper.position.y = -0.17;
      const paw = new THREE.Mesh(new THREE.SphereGeometry(0.052, 8, 6), secondaryMat);
      paw.scale.set(1.0, 0.65, 1.3);
      paw.position.set(0, -0.35, 0.02);
      leg.add(upper, paw);
      bodyPivot.add(leg);
      legs.push(leg);
    }
    root.add(createRadialShadow(0.42));
  } else if (type === 'horse') {
    baseBodyY = 1.12;
    bodyPivot.position.y = baseBodyY;

    // Muscular equine barrel + chest
    chestMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.35, 0.86, 10, 14), coatMat);
    chestMesh.rotation.x = Math.PI / 2;
    bodyPivot.add(chestMesh);

    const rump = new THREE.Mesh(new THREE.SphereGeometry(0.36, 12, 10), coatMat);
    rump.position.set(0, 0.02, -0.42);
    bodyPivot.add(rump);

    // Graceful arched neck + flowing dynamic mane
    neckPivot.position.set(0, 0.18, 0.48);
    bodyPivot.add(neckPivot);
    const neckMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.17, 0.56, 8, 12), coatMat);
    neckMesh.position.set(0, 0.28, 0.15);
    neckMesh.rotation.x = 0.46;
    neckPivot.add(neckMesh);

    manePivot = new THREE.Group();
    manePivot.position.set(0, 0.34, 0.01);
    neckPivot.add(manePivot);
    for (let i = 0; i < 6; i++) {
      const tuft = new THREE.Mesh(new THREE.ConeGeometry(0.065, 0.24, 6), secondaryMat);
      tuft.position.set(0, 0.24 - i * 0.095, 0.11 - i * 0.045);
      tuft.rotation.x = -0.85;
      manePivot.add(tuft);
    }

    // Refined equine head + white forehead blaze + expressive muzzle
    headPivot.position.set(0, 0.58, 0.33);
    neckPivot.add(headPivot);
    const skull = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.25, 0.32), coatMat);
    headPivot.add(skull);
    const blaze = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.18, 0.02), accentMat);
    blaze.position.set(0, 0.01, 0.165);
    headPivot.add(blaze);

    muzzlePivot.position.set(0, -0.05, 0.18);
    headPivot.add(muzzlePivot);
    const snout = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.17, 0.26), muzzleMat);
    snout.position.set(0, -0.02, 0.1);
    muzzlePivot.add(snout);
    jawMesh = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.065, 0.22), muzzleMat);
    jawMesh.position.set(0, -0.11, 0.08);
    muzzlePivot.add(jawMesh);
    noseMesh = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 8), hoofMat);
    noseMesh.position.set(0, 0.0, 0.225);
    muzzlePivot.add(noseMesh);

    const lE = makeEye(-1, 0.125, 0.04, 0.09, 0.036);
    const rE = makeEye(1, 0.125, 0.04, 0.09, 0.036);
    leftEye = lE.eye;
    rightEye = rE.eye;
    leftEyelid = lE.lid;
    rightEyelid = rE.lid;

    leftEar.position.set(-0.09, 0.14, -0.04);
    rightEar.position.set(0.09, 0.14, -0.04);
    const hEarGeo = new THREE.ConeGeometry(0.042, 0.18, 6);
    const lEarM = new THREE.Mesh(hEarGeo, coatMat);
    lEarM.position.y = 0.08;
    const rEarM = new THREE.Mesh(hEarGeo, coatMat);
    rEarM.position.y = 0.08;
    leftEar.add(lEarM);
    rightEar.add(rEarM);
    headPivot.add(leftEar, rightEar);

    // Flowing multi-segment horse tail
    tailPivot.position.set(0, 0.12, -0.74);
    bodyPivot.add(tailPivot);
    const tailUpper = new THREE.Mesh(new THREE.CapsuleGeometry(0.065, 0.36, 6, 8), secondaryMat);
    tailUpper.position.set(0, -0.18, -0.09);
    tailUpper.rotation.x = 0.32;
    tailPivot.add(tailUpper);
    tailTip = new THREE.Group();
    tailTip.position.set(0, -0.38, -0.15);
    const tailLower = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.42, 8), secondaryMat);
    tailLower.position.y = -0.16;
    tailLower.rotation.x = Math.PI;
    tailTip.add(tailLower);
    tailPivot.add(tailTip);

    // 4 tall athletic legs + dark hooves
    const legCoords: Array<[number, number]> = [
      [-0.21, 0.42],
      [0.21, 0.42],
      [-0.22, -0.45],
      [0.22, -0.45],
    ];
    for (const [lx, lz] of legCoords) {
      const leg = new THREE.Group();
      leg.position.set(lx, -0.16, lz);
      const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.072, 0.44, 6, 8), coatMat);
      upper.position.y = -0.25;
      const lower = new THREE.Mesh(new THREE.CylinderGeometry(0.052, 0.046, 0.4, 8), coatMat);
      lower.position.y = -0.66;
      const hoof = new THREE.Mesh(new THREE.CylinderGeometry(0.056, 0.068, 0.12, 8), hoofMat);
      hoof.position.y = -0.9;
      leg.add(upper, lower, hoof);
      bodyPivot.add(leg);
      legs.push(leg);
    }
    root.add(createRadialShadow(0.78));
  } else if (type === 'chicken') {
    baseBodyY = 0.30;
    bodyPivot.position.y = baseBodyY;

    // Plump feathered hen body
    chestMesh = new THREE.Mesh(new THREE.SphereGeometry(0.21, 12, 10), coatMat);
    chestMesh.scale.set(0.92, 0.88, 1.24);
    bodyPivot.add(chestMesh);

    // Layered feathered wings
    leftWing = new THREE.Group();
    leftWing.position.set(-0.18, 0.02, 0.0);
    const lWingMesh = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 8), secondaryMat);
    lWingMesh.scale.set(0.36, 0.78, 1.35);
    leftWing.add(lWingMesh);
    rightWing = new THREE.Group();
    rightWing.position.set(0.18, 0.02, 0.0);
    const rWingMesh = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 8), secondaryMat);
    rWingMesh.scale.set(0.36, 0.78, 1.35);
    rightWing.add(rWingMesh);
    bodyPivot.add(leftWing, rightWing);

    // Neck + head + crimson comb + wattle + beak
    neckPivot.position.set(0, 0.11, 0.18);
    bodyPivot.add(neckPivot);
    headPivot.position.set(0, 0.14, 0.05);
    neckPivot.add(headPivot);

    const headMesh = new THREE.Mesh(new THREE.SphereGeometry(0.115, 10, 10), coatMat);
    headPivot.add(headMesh);

    // Layered comb
    for (let i = 0; i < 3; i++) {
      const lobe = new THREE.Mesh(new THREE.SphereGeometry(0.034 - i * 0.004, 8, 8), accentMat);
      lobe.position.set(0, 0.115 - i * 0.006, 0.04 - i * 0.045);
      headPivot.add(lobe);
    }

    muzzlePivot.position.set(0, -0.01, 0.11);
    headPivot.add(muzzlePivot);
    noseMesh = new THREE.Mesh(new THREE.ConeGeometry(0.036, 0.095, 6), hoofMat);
    noseMesh.rotation.x = Math.PI / 2;
    noseMesh.position.set(0, 0.01, 0.03);
    muzzlePivot.add(noseMesh);
    jawMesh = new THREE.Mesh(new THREE.ConeGeometry(0.025, 0.075, 6), hoofMat);
    jawMesh.rotation.x = Math.PI / 2 + 0.18;
    jawMesh.position.set(0, -0.025, 0.02);
    muzzlePivot.add(jawMesh);
    const wattle = new THREE.Mesh(new THREE.SphereGeometry(0.028, 8, 8), accentMat);
    wattle.position.set(0, -0.065, 0.02);
    muzzlePivot.add(wattle);

    const lE = makeEye(-1, 0.088, 0.025, 0.055, 0.024);
    const rE = makeEye(1, 0.088, 0.025, 0.055, 0.024);
    leftEye = lE.eye;
    rightEye = rE.eye;
    leftEyelid = lE.lid;
    rightEyelid = rE.lid;

    // Subtle ear tufts (for consistent rig interface)
    leftEar.position.set(-0.09, 0.0, 0);
    rightEar.position.set(0.09, 0.0, 0);
    headPivot.add(leftEar, rightEar);

    // Fanned tail feathers
    tailPivot.position.set(0, 0.09, -0.22);
    bodyPivot.add(tailPivot);
    for (let i = -1; i <= 1; i++) {
      const feather = new THREE.Mesh(new THREE.ConeGeometry(0.042, 0.22, 6), secondaryMat);
      feather.position.set(i * 0.042, 0.08, -0.06);
      feather.rotation.set(-0.7, 0, -i * 0.25);
      tailPivot.add(feather);
    }

    // 2 agile chicken legs + toes
    for (const lx of [-0.075, 0.075]) {
      const leg = new THREE.Group();
      leg.position.set(lx, -0.14, 0.01);
      const shin = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.015, 0.16, 6), hoofMat);
      shin.position.y = -0.07;
      const foot = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.018, 0.095), hoofMat);
      foot.position.set(0, -0.15, 0.025);
      leg.add(shin, foot);
      bodyPivot.add(leg);
      legs.push(leg);
    }
    root.add(createRadialShadow(0.32));
  } else if (type === 'cow') {
    baseBodyY = 0.84;
    bodyPivot.position.y = baseBodyY;

    // Broad dairy cow torso + udder
    chestMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.38, 0.78, 10, 14), coatMat);
    chestMesh.rotation.x = Math.PI / 2;
    bodyPivot.add(chestMesh);

    const udder = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 8), accentMat);
    udder.scale.set(1.05, 0.72, 1.15);
    udder.position.set(0, -0.32, -0.22);
    bodyPivot.add(udder);

    // Cowbell around neck
    const bellMat = new THREE.MeshStandardMaterial({ color: '#eab308', roughness: 0.3, metalness: 0.8 });
    const strap = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.028, 8, 16), hoofMat);
    strap.position.set(0, 0.06, 0.44);
    strap.rotation.x = 0.45;
    const cowbell = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.065, 0.1, 8), bellMat);
    cowbell.position.set(0, -0.16, 0.54);
    bodyPivot.add(strap, cowbell);

    // Neck + gentle wide head + curved horns
    neckPivot.position.set(0, 0.14, 0.46);
    bodyPivot.add(neckPivot);
    headPivot.position.set(0, 0.14, 0.24);
    neckPivot.add(headPivot);

    const skull = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.32, 0.36), coatMat);
    headPivot.add(skull);

    const hornMat = new THREE.MeshStandardMaterial({ color: '#e6d8bd', roughness: 0.45, metalness: 0.05 });
    for (const side of [-1, 1]) {
      const horn = new THREE.Mesh(new THREE.ConeGeometry(0.042, 0.2, 8), hornMat);
      horn.position.set(side * 0.16, 0.19, -0.02);
      horn.rotation.z = -side * 0.65;
      headPivot.add(horn);
    }

    muzzlePivot.position.set(0, -0.08, 0.2);
    headPivot.add(muzzlePivot);
    const snout = new THREE.Mesh(new THREE.BoxGeometry(0.29, 0.18, 0.2), muzzleMat);
    snout.position.set(0, 0.0, 0.05);
    muzzlePivot.add(snout);
    jawMesh = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.065, 0.17), muzzleMat);
    jawMesh.position.set(0, -0.1, 0.04);
    muzzlePivot.add(jawMesh);
    noseMesh = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.045, 0.04), accentMat);
    noseMesh.position.set(0, 0.02, 0.155);
    muzzlePivot.add(noseMesh);

    const lE = makeEye(-1, 0.15, 0.055, 0.12, 0.036);
    const rE = makeEye(1, 0.15, 0.055, 0.12, 0.036);
    leftEye = lE.eye;
    rightEye = rE.eye;
    leftEyelid = lE.lid;
    rightEyelid = rE.lid;

    leftEar.position.set(-0.18, 0.09, -0.02);
    rightEar.position.set(0.18, 0.09, -0.02);
    const cEarGeo = new THREE.BoxGeometry(0.18, 0.075, 0.09);
    const lEarM = new THREE.Mesh(cEarGeo, coatMat);
    lEarM.position.x = -0.08;
    lEarM.rotation.z = 0.2;
    const rEarM = new THREE.Mesh(cEarGeo, coatMat);
    rEarM.position.x = 0.08;
    rEarM.rotation.z = -0.2;
    leftEar.add(lEarM);
    rightEar.add(rEarM);
    headPivot.add(leftEar, rightEar);

    // Long swishing cow tail with tuft
    tailPivot.position.set(0, 0.12, -0.66);
    bodyPivot.add(tailPivot);
    const tailRope = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.02, 0.46, 6), coatMat);
    tailRope.position.set(0, -0.22, -0.04);
    tailPivot.add(tailRope);
    tailTip = new THREE.Group();
    tailTip.position.set(0, -0.45, -0.05);
    const tuft = new THREE.Mesh(new THREE.SphereGeometry(0.065, 8, 8), secondaryMat);
    tuft.scale.set(0.85, 1.45, 0.85);
    tailTip.add(tuft);
    tailPivot.add(tailTip);

    // 4 sturdy legs + cloven hooves
    const legCoords: Array<[number, number]> = [
      [-0.22, 0.36],
      [0.22, 0.36],
      [-0.22, -0.38],
      [0.22, -0.38],
    ];
    for (const [lx, lz] of legCoords) {
      const leg = new THREE.Group();
      leg.position.set(lx, -0.22, lz);
      const limb = new THREE.Mesh(new THREE.CapsuleGeometry(0.078, 0.44, 6, 8), coatMat);
      limb.position.y = -0.26;
      const hoof = new THREE.Mesh(new THREE.CylinderGeometry(0.072, 0.082, 0.12, 8), hoofMat);
      hoof.position.y = -0.56;
      leg.add(limb, hoof);
      bodyPivot.add(leg);
      legs.push(leg);
    }
    root.add(createRadialShadow(0.72));
  } else {
    // === SHEEP (Fluffy multi-puff layered wool!) ===
    baseBodyY = 0.58;
    bodyPivot.position.y = baseBodyY;

    chestMesh = new THREE.Mesh(new THREE.SphereGeometry(0.32, 12, 10), coatMat);
    chestMesh.scale.set(1.05, 0.94, 1.38);
    bodyPivot.add(chestMesh);

    // Fluffy cloud-like wool puffs around body for thick wool silhouette
    const woolOffsets: Array<[number, number, number, number]> = [
      [-0.2, 0.12, 0.18, 0.18],
      [0.2, 0.12, 0.18, 0.18],
      [-0.22, 0.08, -0.18, 0.19],
      [0.22, 0.08, -0.18, 0.19],
      [0, 0.22, 0.0, 0.21],
      [0, 0.16, 0.28, 0.17],
      [0, 0.14, -0.31, 0.18],
      [-0.18, -0.05, 0.02, 0.17],
      [0.18, -0.05, 0.02, 0.17],
    ];
    for (const [wx, wy, wz, wr] of woolOffsets) {
      const puff = new THREE.Mesh(new THREE.SphereGeometry(wr, 9, 8), coatMat);
      puff.position.set(wx, wy, wz);
      chestMesh.add(puff);
    }

    neckPivot.position.set(0, 0.12, 0.36);
    bodyPivot.add(neckPivot);
    headPivot.position.set(0, 0.06, 0.16);
    neckPivot.add(headPivot);

    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.165, 10, 10), muzzleMat);
    skull.scale.set(0.88, 0.92, 1.18);
    headPivot.add(skull);
    // Fluffy wool crown cap on top of sheep head
    const woolCap = new THREE.Mesh(new THREE.SphereGeometry(0.145, 9, 8), coatMat);
    woolCap.scale.set(1.05, 0.72, 1.0);
    woolCap.position.set(0, 0.11, -0.02);
    headPivot.add(woolCap);

    muzzlePivot.position.set(0, -0.04, 0.15);
    headPivot.add(muzzlePivot);
    const snout = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), muzzleMat);
    snout.scale.set(0.9, 0.8, 1.15);
    muzzlePivot.add(snout);
    jawMesh = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.045, 0.1), muzzleMat);
    jawMesh.position.set(0, -0.06, 0.01);
    muzzlePivot.add(jawMesh);
    noseMesh = new THREE.Mesh(new THREE.SphereGeometry(0.028, 8, 8), hoofMat);
    noseMesh.position.set(0, 0.01, 0.095);
    muzzlePivot.add(noseMesh);

    const lE = makeEye(-1, 0.095, 0.035, 0.095, 0.028);
    const rE = makeEye(1, 0.095, 0.035, 0.095, 0.028);
    leftEye = lE.eye;
    rightEye = rE.eye;
    leftEyelid = lE.lid;
    rightEyelid = rE.lid;

    leftEar.position.set(-0.135, 0.04, -0.02);
    rightEar.position.set(0.135, 0.04, -0.02);
    const sEarGeo = new THREE.BoxGeometry(0.14, 0.055, 0.07);
    const lEarM = new THREE.Mesh(sEarGeo, muzzleMat);
    lEarM.position.x = -0.055;
    lEarM.rotation.z = 0.35;
    const rEarM = new THREE.Mesh(sEarGeo, muzzleMat);
    rEarM.position.x = 0.055;
    rEarM.rotation.z = -0.35;
    leftEar.add(lEarM);
    rightEar.add(rEarM);
    headPivot.add(leftEar, rightEar);

    // Cute fluffy sheep tail
    tailPivot.position.set(0, 0.03, -0.45);
    bodyPivot.add(tailPivot);
    const woolTail = new THREE.Mesh(new THREE.SphereGeometry(0.088, 8, 8), coatMat);
    woolTail.scale.set(0.9, 1.15, 1.25);
    woolTail.position.set(0, -0.04, -0.04);
    tailPivot.add(woolTail);

    const legCoords: Array<[number, number]> = [
      [-0.17, 0.22],
      [0.17, 0.22],
      [-0.17, -0.22],
      [0.17, -0.22],
    ];
    for (const [lx, lz] of legCoords) {
      const leg = new THREE.Group();
      leg.position.set(lx, -0.18, lz);
      const limb = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.04, 0.34, 8), muzzleMat);
      limb.position.y = -0.18;
      const hoof = new THREE.Mesh(new THREE.CylinderGeometry(0.046, 0.054, 0.08, 8), hoofMat);
      hoof.position.y = -0.36;
      leg.add(limb, hoof);
      bodyPivot.add(leg);
      legs.push(leg);
    }
    root.add(createRadialShadow(0.56));
  }

  enableShadows(bodyPivot);

  return {
    root,
    bodyPivot,
    chestMesh,
    neckPivot,
    headPivot,
    leftEar,
    rightEar,
    leftEye,
    rightEye,
    leftEyelid,
    rightEyelid,
    muzzlePivot,
    jawMesh,
    noseMesh,
    tailPivot,
    tailTip,
    manePivot,
    leftWing,
    rightWing,
    legs,
    coatMaterials,
    baseCoatColors,
    baseBodyY,
    baseScale: sizeScale,
  };
}

// === TRAVERSAL RULES PER SPECIES ===
export function getAnimalRadius(type: AnimalState['type']): number {
  switch (type) {
    case 'chicken':
      return 0.3;
    case 'dog':
      return 0.4;
    case 'sheep':
      return 0.48;
    case 'cow':
      return 0.62;
    case 'horse':
      return 0.72;
  }
}

function getAnimalTurnSpeed(type: AnimalState['type']): number {
  switch (type) {
    case 'chicken':
      return 9.5;
    case 'dog':
      return 8.5;
    case 'sheep':
      return 5.4;
    case 'cow':
      return 3.8;
    case 'horse':
      return 3.2; // Horses need wider turning space
  }
}

function getAnimalMoveSpeed(type: AnimalState['type'], behavior: AnimalBehaviorState): number {
  const isRun = behavior === 'run' || behavior === 'chase_bug' || behavior === 'follow_player';
  const isSlow = behavior === 'graze' || behavior === 'sniff' || behavior === 'peck';
  switch (type) {
    case 'horse':
      return isRun ? 4.8 : isSlow ? 0.95 : 2.1;
    case 'dog':
      return isRun ? 4.4 : isSlow ? 1.15 : 2.4;
    case 'chicken':
      return isRun ? 2.4 : isSlow ? 0.75 : 1.35;
    case 'sheep':
      return isRun ? 2.7 : isSlow ? 0.72 : 1.45;
    case 'cow':
      return isRun ? 2.5 : isSlow ? 0.62 : 1.25;
  }
}

function getShelterPortalDoor(type: AnimalState['type']): { x: number; z: number } {
  if (type === 'dog') return { x: DOGHOUSE_POS.x, z: DOGHOUSE_POS.z + 0.6 };
  if (type === 'horse') return { x: HORSE_STABLE_POS.x, z: HORSE_STABLE_POS.z + 3.2 };
  const pid = type === 'chicken' ? 'coop' : 'barn';
  const portal = BUILDING_PORTALS.find((p) => p.id === pid);
  return portal ? { x: portal.exitSpawnX, z: portal.exitSpawnZ + 0.8 } : { x: -128, z: -16 };
}

function getWaterSpot(inInterior: boolean, zone: WorldZoneId): { x: number; z: number } {
  if (inInterior) {
    if (zone === 'int_coop') return { x: 3.2, z: -1.8 };
    if (zone === 'int_stable') return { x: 3.4, z: -2.0 };
    return { x: 4.0, z: -2.0 };
  }
  // Farm watering trough / west brook edge (safely west of water collider at x=-67.3)
  return { x: -72.5, z: -11.5 };
}

function getFeedSpot(type: AnimalState['type'], inInterior: boolean, homeX: number, homeZ: number): { x: number; z: number } {
  if (inInterior) {
    return { x: homeX, z: Math.max(-2.6, homeZ - 1.1) };
  }
  if (type === 'dog') return { x: DOG_FOOD_BOWL_POS.x, z: DOG_FOOD_BOWL_POS.z + 0.45 };
  if (type === 'horse') return { x: HORSE_STABLE_POS.x + 1.4, z: HORSE_STABLE_POS.z + 3.6 };
  return { x: homeX, z: homeZ };
}

function isPointBlockedForAnimal(
  x: number,
  z: number,
  radius: number,
  actorId: string,
  allActors: Iterable<LivingAnimalActor>,
  ctx: AnimalWorldContext,
  inInterior: boolean,
  isDogEnteringHouse: boolean
): boolean {
  if (inInterior) {
    const limX = ctx.zone === 'int_barn' ? 5.6 : 4.4;
    const limZ = ctx.zone === 'int_barn' ? 4.2 : 3.4;
    if (x < -limX || x > limX || z < -limZ || z > limZ) return true;
  } else {
    // Animal Boundary System: stay strictly within private farm homestead & respect brook/fences!
    if (x < -176 || x > -69.5 || z < -36 || z > 32) return true;
  }

  for (const box of ctx.colliders.boxes) {
    // Allow dog to step into its own doghouse box when resting/sleeping
    if (
      isDogEnteringHouse &&
      Math.abs((box.minX + box.maxX) * 0.5 - DOGHOUSE_POS.x) < 1.5 &&
      Math.abs((box.minZ + box.maxZ) * 0.5 - DOGHOUSE_POS.z) < 1.5
    ) {
      continue;
    }
    const cx = THREE.MathUtils.clamp(x, box.minX, box.maxX);
    const cz = THREE.MathUtils.clamp(z, box.minZ, box.maxZ);
    const dx = x - cx;
    const dz = z - cz;
    if (dx * dx + dz * dz < radius * radius) return true;
  }

  for (const c of ctx.colliders.circles) {
    const minD = c.radius + radius;
    const dx = x - c.x;
    const dz = z - c.z;
    if (dx * dx + dz * dz < minD * minD) return true;
  }

  if (!inInterior) {
    for (const tc of ctx.treeCircles) {
      const minD = tc.radius + radius;
      const dx = x - tc.x;
      const dz = z - tc.z;
      if (dx * dx + dz * dz < minD * minD) return true;
    }
    for (const oc of ctx.farmObstacleCircles) {
      const minD = oc.radius + radius;
      const dx = x - oc.x;
      const dz = z - oc.z;
      if (dx * dx + dz * dz < minD * minD) return true;
    }
  }

  // Avoid player & NPCs
  const pDist = Math.hypot(x - ctx.playerPos.x, z - ctx.playerPos.z);
  if (pDist < radius + 0.55) return true;
  for (const np of ctx.npcPositions) {
    if (Math.hypot(x - np.x, z - np.z) < radius + 0.5) return true;
  }

  // Avoid clipping through other animals
  for (const other of allActors) {
    if (other.id === actorId || !other.rig.root.visible) continue;
    const minD = radius + getAnimalRadius(other.state.type) * 0.85;
    if (Math.hypot(x - other.pos.x, z - other.pos.z) < minD) return true;
  }

  return false;
}

function getAnimalBubbleLine(
  type: AnimalState['type'],
  kind: 'happy' | 'hungry' | 'sick' | 'bark' | 'play' | 'sleep' | 'rain' | 'social',
  lang: Language
): string {
  const id = lang === 'id';
  if (kind === 'sick') {
    return id ? '🤒 Lemas... butuh Obat Hewan!' : '🤒 Feeling sick... needs Animal Medicine!';
  }
  if (kind === 'hungry') {
    return id ? '🍽️ Lapar... mencari pakan' : '🍽️ Hungry... looking for food';
  }
  if (kind === 'rain') {
    return id ? '🌧️ Berteduh dari hujan' : '🌧️ Seeking shelter from rain';
  }
  if (kind === 'sleep') {
    return '💤 Zzz...';
  }
  if (type === 'dog') {
    if (kind === 'bark') return id ? '🐕 Guk! Guk! Mengawasi peternakan!' : '🐕 Woof! Guarding the farm!';
    if (kind === 'play') return id ? '🐾 Asyik bermain!' : '🐾 Playful wag!';
    if (kind === 'social') return id ? '🐕 Mengajak teman bermain!' : '🐕 Playing with farm friends!';
    return id ? '💛 Guk! Senang melihatmu!' : '💛 Woof! Happy to see you!';
  }
  if (type === 'horse') {
    if (kind === 'play') return id ? '🐎 Hiii-ha! Berlari bebas!' : '🐎 Neigh! Galloping freely!';
    if (kind === 'social') return id ? '🐎 Saling menyapa kawanan' : '🐎 Greeting the herd';
    return id ? '🐎 Hiii~ Merasa nyaman!' : '🐎 Neigh~ Feeling great!';
  }
  if (type === 'chicken') {
    if (kind === 'play') return id ? '🐔 Kokok! Mengejar serangga!' : '🐔 Cluck! Chasing bugs!';
    if (kind === 'social') return id ? '🐔 Berkumpul bersama ayam lain' : '🐔 Clucking with the flock';
    return id ? '🐔 Petok-petok~ Senang!' : '🐔 Cluck-cluck~ Happy!';
  }
  if (type === 'cow') {
    if (kind === 'social') return id ? '🐄 Mooo~ Dekat kawanan' : '🐄 Mooo~ Grazing with the herd';
    return id ? '🐄 Mooo~ Rumputnya segar!' : '🐄 Mooo~ Fresh pasture!';
  }
  // sheep
  if (kind === 'social') return id ? '🐑 Mbek~ Mengikuti kawanan' : '🐑 Baa~ Following the flock';
  return id ? '🐑 Mbek~ Nyaman dan hangat!' : '🐑 Baa~ Cozy and relaxed!';
}

function shortestAngleDiff(from: number, to: number): number {
  let diff = to - from;
  while (diff > Math.PI) diff -= Math.PI * 2;
  while (diff < -Math.PI) diff += Math.PI * 2;
  return diff;
}

const _tmpColor = new THREE.Color();
const _sickTint = new THREE.Color('#c8d4be');
const _rainTint = new THREE.Color('#d2dae2');
const _warmTint = new THREE.Color('#fff5e6');

export function updateLivingAnimals(
  actors: Map<string, LivingAnimalActor>,
  ctx: AnimalWorldContext
): void {
  const { dt, elapsed, zone, weather, hour, season, playerPos, language } = ctx;
  const inInterior = zone === 'int_barn' || zone === 'int_coop' || zone === 'int_stable';
  const isNight = hour >= 19 || hour < 6;
  const isDusk = hour >= 18 && hour < 19;
  const isWet = weather === 'Rainy' || weather === 'Stormy';
  const isHotMidday = (season === 'Summer' || weather === 'Sunny') && hour >= 11 && hour <= 15;
  const isSnowOrMud = weather === 'Snowy' || season === 'Winter' || isWet;

  // Identify herd leaders for Sheep & Cow (first visible animal of each species)
  let sheepLeader: LivingAnimalActor | null = null;
  let cowLeader: LivingAnimalActor | null = null;
  for (const a of actors.values()) {
    if (!a.rig.root.visible) continue;
    if (a.state.type === 'sheep' && !sheepLeader) sheepLeader = a;
    if (a.state.type === 'cow' && !cowLeader) cowLeader = a;
  }

  for (const actor of actors.values()) {
    if (!actor.rig.root.visible) continue;
    const type = actor.state.type;
    const radius = getAnimalRadius(type);

    // Sync baseline needs from authoritative state + subtle continuous runtime simulation
    const isSick = Boolean(actor.state.isSick);
    actor.health = isSick ? Math.min(actor.health, actor.state.health ?? 35) : (actor.state.health ?? 100);
    actor.happiness = actor.state.happiness ?? Math.round((actor.state.affection / 255) * 100);
    if (actor.state.fedToday) {
      actor.hunger = Math.min(100, Math.max(actor.hunger, 85));
    } else {
      actor.hunger = Math.max(12, actor.hunger - dt * 0.25);
    }
    actor.thirst = Math.max(15, actor.thirst - dt * 0.32);
    if (actor.behavior === 'sleep' || actor.behavior === 'rest_lie' || actor.behavior === 'roost' || actor.behavior === 'shade_rest') {
      actor.energy = Math.min(100, actor.energy + dt * 3.5);
    } else if (actor.behavior === 'run' || actor.behavior === 'play' || actor.behavior === 'chase_bug') {
      actor.energy = Math.max(15, actor.energy - dt * 1.4);
    } else {
      actor.energy = Math.max(20, actor.energy - dt * 0.15);
    }

    actor.behaviorTimer -= dt;
    actor.emoteCooldown = Math.max(0, actor.emoteCooldown - dt);
    actor.interactBoostTimer = Math.max(0, actor.interactBoostTimer - dt);
    actor.earAlertTimer = Math.max(0, actor.earAlertTimer - dt);

    const distToPlayer = Math.hypot(playerPos.x - actor.pos.x, playerPos.z - actor.pos.z);
    if (distToPlayer < 4.5 && ctx.playerSpeed > 5.0) {
      actor.earAlertTimer = 2.0; // Ears react to running footsteps / nearby sounds!
    }

    // Determine dynamic Animal Emotion
    if (isSick) {
      actor.emotion = 'sick';
    } else if (weather === 'Stormy' && !inInterior) {
      actor.emotion = 'scared';
    } else if (actor.hunger < 38 && !actor.state.fedToday) {
      actor.emotion = 'hungry';
    } else if (isNight || actor.energy < 28) {
      actor.emotion = 'sleepy';
    } else if (isWet && !inInterior && type !== 'dog') {
      actor.emotion = 'stressed';
    } else if (actor.interactBoostTimer > 0 || actor.happiness >= 65 || actor.state.fedToday) {
      actor.emotion = 'happy';
    } else {
      actor.emotion = 'relaxed';
    }

    // === DECISION STATE MACHINE ===
    if (actor.behaviorTimer <= 0) {
      actor.socialPartnerId = null;

      if (isSick) {
        // Sick animals rest lethargically & emit occasional help bubble
        actor.behavior = 'rest_lie';
        actor.targetPos.copy(actor.pos);
        actor.behaviorTimer = 5 + Math.random() * 4;
        if (actor.emoteCooldown <= 0 && distToPlayer < 13) {
          ctx.onAnimalBubble?.(actor.id, actor.state.name, getAnimalBubbleLine(type, 'sick', language), false);
          actor.emoteCooldown = 16;
        }
      } else if (isNight) {
        // Sleep System: all animals rest/sleep at night (indoor or shelter)
        const shelter = inInterior ? { x: actor.homeX, z: actor.homeZ } : getShelterPortalDoor(type);
        const dShelter = Math.hypot(shelter.x - actor.pos.x, shelter.z - actor.pos.z);
        if (!inInterior && dShelter > 2.2) {
          actor.behavior = 'shelter';
          actor.targetPos.set(shelter.x, 0, shelter.z);
          actor.behaviorTimer = 6;
        } else {
          actor.behavior = type === 'chicken' ? 'roost' : 'sleep';
          actor.targetPos.copy(actor.pos);
          actor.behaviorTimer = 7 + Math.random() * 5;
          if (actor.emoteCooldown <= 0 && distToPlayer < 9) {
            ctx.onAnimalBubble?.(actor.id, actor.state.name, getAnimalBubbleLine(type, 'sleep', language), true);
            actor.emoteCooldown = 26;
          }
        }
      } else if (isWet && !inInterior) {
        // Weather Reaction System: seek shelter in rain/storm
        const shelter = getShelterPortalDoor(type);
        const dShelter = Math.hypot(shelter.x - actor.pos.x, shelter.z - actor.pos.z);
        if (dShelter > 2.1) {
          actor.behavior = weather === 'Stormy' ? 'run' : 'shelter';
          actor.targetPos.set(shelter.x, 0, shelter.z);
          actor.behaviorTimer = 5;
        } else {
          actor.behavior = 'rest_lie';
          actor.targetPos.copy(actor.pos);
          actor.behaviorTimer = 6;
        }
        if (actor.emoteCooldown <= 0 && distToPlayer < 12) {
          ctx.onAnimalBubble?.(actor.id, actor.state.name, getAnimalBubbleLine(type, 'rain', language), true);
          actor.emoteCooldown = 22;
        }
      } else if (actor.hunger < 45 && !actor.state.fedToday) {
        // Dynamic Feeding System: head to food trough/bowl
        const feedSpot = getFeedSpot(type, inInterior, actor.homeX, actor.homeZ);
        actor.behavior = 'eat';
        actor.targetPos.set(feedSpot.x, 0, feedSpot.z);
        actor.behaviorTimer = 6 + Math.random() * 3;
        if (actor.emoteCooldown <= 0 && distToPlayer < 11) {
          ctx.onAnimalBubble?.(actor.id, actor.state.name, getAnimalBubbleLine(type, 'hungry', language), true);
          actor.emoteCooldown = 24;
        }
      } else if (actor.thirst < 40) {
        // Dynamic Drinking System: head to water trough / brook edge
        const wSpot = getWaterSpot(inInterior, zone);
        actor.behavior = 'drink';
        actor.targetPos.set(wSpot.x + (Math.random() - 0.5) * 1.4, 0, wSpot.z + (Math.random() - 0.5) * 1.4);
        actor.behaviorTimer = 6 + Math.random() * 3;
      } else {
        // Species-specific rich daily & natural behaviors
        const roll = Math.random();
        if (type === 'dog') {
          if (!inInterior && distToPlayer < 12 && distToPlayer > 2.4 && roll < 0.42) {
            // Follow player warmly!
            actor.behavior = 'follow_player';
            actor.behaviorTimer = 4.5 + Math.random() * 3;
          } else if (!inInterior && roll < 0.58) {
            // Pack Behavior: patrol farm perimeter & guard!
            actor.behavior = 'walk';
            const patrolPts: Array<[number, number]> = [
              [-106, -15],
              [-120, -14],
              [-134, -14],
              [-100, -10],
              [-96, -19],
              [DOGHOUSE_POS.x + 1.2, DOGHOUSE_POS.z + 2.5],
            ];
            const pt = patrolPts[Math.floor(Math.random() * patrolPts.length)];
            actor.targetPos.set(pt[0] + (Math.random() - 0.5) * 2.5, 0, pt[1] + (Math.random() - 0.5) * 2.5);
            actor.behaviorTimer = 5 + Math.random() * 4;
          } else if (!inInterior && roll < 0.7) {
            actor.behavior = 'sniff';
            actor.targetPos.set(actor.pos.x + (Math.random() - 0.5) * 3.5, 0, actor.pos.z + (Math.random() - 0.5) * 3.5);
            actor.behaviorTimer = 4.5;
          } else if (!inInterior && roll < 0.78) {
            actor.behavior = 'bark';
            actor.targetPos.copy(actor.pos);
            actor.behaviorTimer = 2.6;
            if (actor.emoteCooldown <= 0 && distToPlayer < 15) {
              ctx.onAnimalBubble?.(actor.id, actor.state.name, getAnimalBubbleLine('dog', 'bark', language), false);
              actor.emoteCooldown = 20;
            }
          } else if (roll < 0.86) {
            actor.behavior = 'sit';
            actor.targetPos.copy(actor.pos);
            actor.behaviorTimer = 5 + Math.random() * 4;
          } else if (roll < 0.93) {
            actor.behavior = 'play';
            actor.targetPos.set(DOG_FOOD_BOWL_POS.x + (Math.random() - 0.5) * 4, 0, DOG_FOOD_BOWL_POS.z + 1.5 + (Math.random() - 0.5) * 3);
            actor.behaviorTimer = 4;
          } else {
            const nat: AnimalBehaviorState[] = ['scratch', 'stretch', 'yawn', 'look_around'];
            actor.behavior = nat[Math.floor(Math.random() * nat.length)];
            actor.targetPos.copy(actor.pos);
            actor.behaviorTimer = 3.2;
          }
        } else if (type === 'horse') {
          if (inInterior) {
            actor.behavior = roll < 0.35 ? 'eat' : roll < 0.65 ? 'idle' : roll < 0.85 ? 'rest_lie' : 'stretch';
            actor.targetPos.set(actor.homeX + (Math.random() - 0.5) * 1.4, 0, actor.homeZ + (Math.random() - 0.5) * 1.2);
            actor.behaviorTimer = 5 + Math.random() * 4;
          } else if (roll < 0.24) {
            // Gallop freely across pasture!
            actor.behavior = 'run';
            actor.targetPos.set(HORSE_STABLE_POS.x + (Math.random() - 0.5) * 18, 0, HORSE_STABLE_POS.z + 7 + (Math.random() - 0.5) * 10);
            actor.behaviorTimer = 5.5;
            if (actor.emoteCooldown <= 0 && distToPlayer < 16) {
              ctx.onAnimalBubble?.(actor.id, actor.state.name, getAnimalBubbleLine('horse', 'play', language), true);
              actor.emoteCooldown = 28;
            }
          } else if (roll < 0.62) {
            // Grazing System: slow pasture graze
            actor.behavior = 'graze';
            actor.targetPos.set(actor.pos.x + (Math.random() - 0.5) * 6, 0, actor.pos.z + (Math.random() - 0.5) * 5);
            actor.behaviorTimer = 6 + Math.random() * 4;
          } else if (roll < 0.84) {
            actor.behavior = 'walk';
            actor.targetPos.set(HORSE_STABLE_POS.x + (Math.random() - 0.5) * 12, 0, HORSE_STABLE_POS.z + 6 + (Math.random() - 0.5) * 8);
            actor.behaviorTimer = 5 + Math.random() * 3;
          } else {
            const nat: AnimalBehaviorState[] = ['look_around', 'stretch', 'yawn', 'scratch'];
            actor.behavior = nat[Math.floor(Math.random() * nat.length)];
            actor.targetPos.copy(actor.pos);
            actor.behaviorTimer = 3.5;
          }
        } else if (type === 'chicken') {
          if (!inInterior && isDusk) {
            // Return to coop at dusk!
            const coopDoor = getShelterPortalDoor('chicken');
            actor.behavior = 'shelter';
            actor.targetPos.set(coopDoor.x, 0, coopDoor.z);
            actor.behaviorTimer = 6;
          } else if (inInterior) {
            actor.behavior = roll < 0.45 ? 'peck' : roll < 0.72 ? 'walk' : roll < 0.88 ? 'roost' : 'look_around';
            actor.targetPos.set(actor.homeX + (Math.random() - 0.5) * 2.4, 0, actor.homeZ + (Math.random() - 0.5) * 1.8);
            actor.behaviorTimer = 3.5 + Math.random() * 3.5;
          } else if (roll < 0.42) {
            actor.behavior = 'peck';
            actor.targetPos.set(actor.pos.x + (Math.random() - 0.5) * 3.2, 0, actor.pos.z + (Math.random() - 0.5) * 3.2);
            actor.behaviorTimer = 4 + Math.random() * 3;
          } else if (roll < 0.62) {
            actor.behavior = 'chase_bug';
            actor.targetPos.set(actor.pos.x + (Math.random() - 0.5) * 5.2, 0, actor.pos.z + (Math.random() - 0.5) * 4.6);
            actor.behaviorTimer = 3.0;
          } else if (roll < 0.84) {
            actor.behavior = 'walk';
            actor.targetPos.set(actor.homeX + (Math.random() - 0.5) * 7.5, 0, actor.homeZ + (Math.random() - 0.5) * 6.0);
            actor.behaviorTimer = 4.5;
          } else {
            const nat: AnimalBehaviorState[] = ['scratch', 'look_around', 'stretch'];
            actor.behavior = nat[Math.floor(Math.random() * nat.length)];
            actor.targetPos.copy(actor.pos);
            actor.behaviorTimer = 2.8;
          }
        } else if (type === 'cow') {
          if (inInterior) {
            actor.behavior = roll < 0.45 ? 'eat' : roll < 0.75 ? 'rest_lie' : roll < 0.9 ? 'walk' : 'yawn';
            actor.targetPos.set(actor.homeX + (Math.random() - 0.5) * 2.2, 0, actor.homeZ + (Math.random() - 0.5) * 1.5);
            actor.behaviorTimer = 5.5 + Math.random() * 4;
          } else if (cowLeader && cowLeader.id !== actor.id && Math.hypot(cowLeader.pos.x - actor.pos.x, cowLeader.pos.z - actor.pos.z) > 5.5) {
            // Herd Behavior System: move together with cow herd
            actor.behavior = 'herd_follow';
            actor.targetPos.set(cowLeader.pos.x + (Math.random() - 0.5) * 3.2, 0, cowLeader.pos.z + (Math.random() - 0.5) * 3.2);
            actor.behaviorTimer = 5;
          } else if (roll < 0.55) {
            actor.behavior = 'graze';
            actor.targetPos.set(actor.pos.x + (Math.random() - 0.5) * 4.5, 0, actor.pos.z + (Math.random() - 0.5) * 4.5);
            actor.behaviorTimer = 6 + Math.random() * 4;
          } else if (roll < 0.8) {
            actor.behavior = 'walk';
            actor.targetPos.set(actor.homeX + (Math.random() - 0.5) * 9, 0, actor.homeZ + (Math.random() - 0.5) * 7);
            actor.behaviorTimer = 5.5;
          } else {
            const nat: AnimalBehaviorState[] = ['rest_lie', 'look_around', 'stretch', 'yawn'];
            actor.behavior = nat[Math.floor(Math.random() * nat.length)];
            actor.targetPos.copy(actor.pos);
            actor.behaviorTimer = 4.5;
          }
        } else {
          // SHEEP
          if (inInterior) {
            actor.behavior = roll < 0.42 ? 'eat' : roll < 0.72 ? 'rest_lie' : roll < 0.9 ? 'walk' : 'scratch';
            actor.targetPos.set(actor.homeX + (Math.random() - 0.5) * 2.2, 0, actor.homeZ + (Math.random() - 0.5) * 1.6);
            actor.behaviorTimer = 5 + Math.random() * 4;
          } else if (isHotMidday && roll < 0.42) {
            // Rest under tree shade when midday is hot!
            actor.behavior = 'shade_rest';
            actor.targetPos.set(APPLE_TREE_POS.x + (Math.random() - 0.5) * 3.5, 0, APPLE_TREE_POS.z + 2.2 + (Math.random() - 0.5) * 2.0);
            actor.behaviorTimer = 7 + Math.random() * 4;
          } else if (sheepLeader && sheepLeader.id !== actor.id && Math.hypot(sheepLeader.pos.x - actor.pos.x, sheepLeader.pos.z - actor.pos.z) > 4.2) {
            // Flock Leader Following (Herd Behavior System)
            actor.behavior = 'herd_follow';
            actor.targetPos.set(sheepLeader.pos.x + (Math.random() - 0.5) * 2.8, 0, sheepLeader.pos.z + (Math.random() - 0.5) * 2.8);
            actor.behaviorTimer = 4.8;
          } else if (roll < 0.58) {
            actor.behavior = 'graze';
            actor.targetPos.set(actor.pos.x + (Math.random() - 0.5) * 5.0, 0, actor.pos.z + (Math.random() - 0.5) * 4.5);
            actor.behaviorTimer = 5.5 + Math.random() * 3.5;
          } else if (roll < 0.84) {
            actor.behavior = 'walk';
            actor.targetPos.set(actor.homeX + (Math.random() - 0.5) * 9, 0, actor.homeZ + (Math.random() - 0.5) * 7.5);
            actor.behaviorTimer = 5;
          } else {
            const nat: AnimalBehaviorState[] = ['rest_lie', 'scratch', 'look_around', 'stretch'];
            actor.behavior = nat[Math.floor(Math.random() * nat.length)];
            actor.targetPos.copy(actor.pos);
            actor.behaviorTimer = 3.8;
          }
        }

        // Animal-to-Animal Interaction check (friendly approach & communication)
        if (actor.behavior === 'walk' && actor.emoteCooldown <= 0 && Math.random() < 0.25) {
          for (const other of actors.values()) {
            if (other.id === actor.id || !other.rig.root.visible) continue;
            const compatible = other.state.type === type || type === 'dog';
            const dOther = Math.hypot(other.pos.x - actor.pos.x, other.pos.z - actor.pos.z);
            if (compatible && dOther > 1.5 && dOther < 6.0) {
              actor.behavior = 'socialize';
              actor.socialPartnerId = other.id;
              actor.targetPos.set(
                other.pos.x + ((actor.pos.x - other.pos.x) / dOther) * (radius + getAnimalRadius(other.state.type) + 0.5),
                0,
                other.pos.z + ((actor.pos.z - other.pos.z) / dOther) * (radius + getAnimalRadius(other.state.type) + 0.5)
              );
              actor.behaviorTimer = 4.2;
              if (distToPlayer < 13) {
                ctx.onAnimalBubble?.(actor.id, actor.state.name, getAnimalBubbleLine(type, 'social', language), true);
                actor.emoteCooldown = 24;
              }
              break;
            }
          }
        }
      }
    }

    // Live target update when Dog is following player
    if (actor.behavior === 'follow_player') {
      if (distToPlayer > 14 || inInterior) {
        actor.behavior = 'idle';
        actor.behaviorTimer = 1;
      } else if (distToPlayer > 2.2) {
        const ang = Math.atan2(actor.pos.x - playerPos.x, actor.pos.z - playerPos.z);
        actor.targetPos.set(playerPos.x + Math.sin(ang) * 1.9, 0, playerPos.z + Math.cos(ang) * 1.9);
      } else {
        actor.targetPos.copy(actor.pos);
      }
    }

    // === SMART MULTI-RAY PATHFINDING, OBSTACLE AVOIDANCE & COLLISION ===
    const dx = actor.targetPos.x - actor.pos.x;
    const dz = actor.targetPos.z - actor.pos.z;
    const distToTarget = Math.hypot(dx, dz);
    const wantsMove =
      distToTarget > 0.32 &&
      actor.behavior !== 'sleep' &&
      actor.behavior !== 'rest_lie' &&
      actor.behavior !== 'sit' &&
      actor.behavior !== 'roost' &&
      actor.behavior !== 'bark' &&
      actor.behavior !== 'scratch' &&
      actor.behavior !== 'stretch' &&
      actor.behavior !== 'yawn';

    const desiredSpeed = wantsMove ? getAnimalMoveSpeed(type, actor.behavior) : 0;
    let movedThisFrame = false;

    if (wantsMove) {
      const baseAngle = Math.atan2(dx, dz);
      const isDogHouseGoal = type === 'dog' && Math.hypot(actor.targetPos.x - DOGHOUSE_POS.x, actor.targetPos.z - DOGHOUSE_POS.z) < 2.2;
      const steerOffsets = [0, 0.48, -0.48, 0.98, -0.98, 1.55, -1.55];
      let chosenAngle: number | null = null;
      const probeStep = Math.max(0.45, Math.min(distToTarget, desiredSpeed * dt * 2.5));

      for (const offset of steerOffsets) {
        const testAngle = baseAngle + offset;
        const tx = actor.pos.x + Math.sin(testAngle) * probeStep;
        const tz = actor.pos.z + Math.cos(testAngle) * probeStep;
        if (!isPointBlockedForAnimal(tx, tz, radius, actor.id, actors.values(), ctx, inInterior, isDogHouseGoal)) {
          chosenAngle = testAngle;
          break;
        }
      }

      if (chosenAngle !== null) {
        actor.targetYaw = chosenAngle;
        const yawDiff = shortestAngleDiff(actor.yaw, actor.targetYaw);
        actor.yaw += yawDiff * (1 - Math.exp(-getAnimalTurnSpeed(type) * dt));
        // Natural curved speed attenuation when turning sharply
        const turnFactor = Math.max(0.32, Math.cos(Math.min(Math.PI * 0.5, Math.abs(yawDiff))));
        actor.speed = THREE.MathUtils.damp(actor.speed, desiredSpeed * turnFactor, 7.5, dt);

        const nx = actor.pos.x + Math.sin(actor.yaw) * actor.speed * dt;
        const nz = actor.pos.z + Math.cos(actor.yaw) * actor.speed * dt;
        if (!isPointBlockedForAnimal(nx, nz, radius, actor.id, actors.values(), ctx, inInterior, isDogHouseGoal)) {
          actor.pos.x = nx;
          actor.pos.z = nz;
          movedThisFrame = true;
          actor.stuckTimer = Math.max(0, actor.stuckTimer - dt);
        } else {
          actor.speed = THREE.MathUtils.damp(actor.speed, 0, 14, dt);
          actor.stuckTimer += dt;
        }
      } else {
        actor.speed = THREE.MathUtils.damp(actor.speed, 0, 12, dt);
        actor.stuckTimer += dt;
      }

      if (actor.stuckTimer > 1.8) {
        // Reroute cleanly instead of getting stuck against a fence or rock
        actor.targetPos.copy(actor.pos);
        actor.behaviorTimer = 0.25;
        actor.stuckTimer = 0;
      }
    } else {
      actor.speed = THREE.MathUtils.damp(actor.speed, 0, 8.5, dt);
      if (actor.behavior === 'drink' && distToTarget <= 0.6) {
        actor.thirst = Math.min(100, actor.thirst + dt * 22);
      } else if (actor.behavior === 'eat' && distToTarget <= 0.6) {
        actor.hunger = Math.min(100, actor.hunger + dt * 14);
      } else if (actor.behavior === 'shade_rest' && distToTarget <= 0.8) {
        actor.behavior = 'rest_lie';
      }
      // Face player gently when standing near them
      if (distToPlayer < 4.2 && actor.behavior !== 'sleep' && actor.behavior !== 'rest_lie') {
        const toPlayerYaw = Math.atan2(playerPos.x - actor.pos.x, playerPos.z - actor.pos.z);
        actor.yaw += shortestAngleDiff(actor.yaw, toPlayerYaw) * (1 - Math.exp(-3.5 * dt));
      }
    }

    // Ground contour interaction (feet always touch ground — zero floating, zero sinking!)
    const groundY = inInterior ? 0 : ctx.getGroundY(actor.pos.x, actor.pos.z);
    actor.pos.y = THREE.MathUtils.damp(actor.pos.y, groundY, 16, dt);

    // Mud / Snow Footprints while walking outdoors
    if (movedThisFrame && !inInterior && isSnowOrMud && ctx.onFootprint) {
      actor.footprintAccum += actor.speed * dt;
      if (actor.footprintAccum > (type === 'chicken' ? 0.65 : 1.15)) {
        actor.footprintAccum = 0;
        ctx.onFootprint(actor.pos.x, actor.pos.z, actor.yaw, radius * 0.45, weather === 'Snowy' || season === 'Winter');
      }
    }

    // === ADVANCED ANIMATION BLENDING, BREATHING, FACIAL, EAR, TAIL & WEATHER VISUALS ===
    const rig = actor.rig;
    const normSpeed = THREE.MathUtils.clamp(actor.speed / (type === 'horse' ? 4.4 : 3.2), 0, 1);
    const isRunning = normSpeed > 0.58;
    const isSitting = actor.behavior === 'sit';
    const isLying = actor.behavior === 'rest_lie' || actor.behavior === 'roost' || actor.behavior === 'shade_rest';
    const isSleeping = actor.behavior === 'sleep';
    const isGrazing =
      (actor.behavior === 'graze' || actor.behavior === 'eat' || actor.behavior === 'drink' || actor.behavior === 'peck' || actor.behavior === 'sniff') &&
      actor.speed < 0.7;

    actor.blendWalk = THREE.MathUtils.damp(actor.blendWalk, movedThisFrame ? Math.min(1, normSpeed * 1.8) : 0, 8, dt);
    actor.blendRun = THREE.MathUtils.damp(actor.blendRun, isRunning ? 1 : 0, 7, dt);
    actor.blendSit = THREE.MathUtils.damp(actor.blendSit, isSitting ? 1 : 0, 6, dt);
    actor.blendLie = THREE.MathUtils.damp(actor.blendLie, isLying || isSleeping ? 1 : 0, 5, dt);
    actor.blendSleep = THREE.MathUtils.damp(actor.blendSleep, isSleeping ? 1 : 0, 5, dt);
    actor.blendGraze = THREE.MathUtils.damp(actor.blendGraze, isGrazing ? 1 : 0, 6.5, dt);

    const gaitFreq = type === 'chicken' ? 11.5 : type === 'dog' ? 9.5 : type === 'horse' ? 7.8 : 6.4;
    actor.gaitPhase += dt * (1.2 + normSpeed * gaitFreq);

    // 1. Natural Breathing Animation (chest rises & falls continuously)
    const breathRate = isSleeping ? 1.3 : isRunning ? 5.2 : isSick ? 3.8 : 2.1;
    const breathAmp = isSleeping ? 0.036 : isRunning ? 0.042 : 0.025;
    const breath = Math.sin(elapsed * breathRate + actor.phaseOffset) * breathAmp;
    rig.chestMesh.scale.y = (type === 'chicken' ? 0.88 : type === 'sheep' ? 0.94 : 1.0) * (1 + breath);
    rig.chestMesh.scale.x = (type === 'chicken' ? 0.92 : type === 'sheep' ? 1.05 : 1.0) * (1 + breath * 0.7);

    // 2. Body Posture (walk bob, gallop bounce, sit/lie/sleep drop, stretch, shiver when scared/sick)
    const walkBob = Math.abs(Math.sin(actor.gaitPhase)) * (0.045 + actor.blendRun * 0.055) * actor.blendWalk;
    const lieDrop = rig.baseBodyY * (type === 'chicken' ? 0.36 : 0.48) * actor.blendLie;
    const sitDrop = rig.baseBodyY * 0.22 * actor.blendSit;
    const stretchLift = actor.behavior === 'stretch' ? Math.sin(elapsed * 2.5) * 0.04 : 0;
    const shiver = actor.emotion === 'scared' || actor.emotion === 'sick' ? Math.sin(elapsed * 28 + actor.phaseOffset) * 0.012 : 0;
    rig.bodyPivot.position.y = Math.max(0.14, rig.baseBodyY + walkBob - lieDrop - sitDrop + stretchLift);
    rig.bodyPivot.position.x = shiver;
    rig.bodyPivot.rotation.x =
      actor.blendSit * -0.34 +
      (actor.behavior === 'stretch' ? 0.28 : 0) +
      actor.blendRun * Math.sin(actor.gaitPhase) * 0.09;
    rig.bodyPivot.rotation.z =
      Math.sin(actor.gaitPhase) * 0.04 * actor.blendWalk +
      (actor.behavior === 'scratch' ? Math.sin(elapsed * 14) * 0.09 : 0);

    // 3. Articulated Legs & Chicken Wings
    const stride = (0.42 + actor.blendRun * 0.38) * actor.blendWalk;
    if (rig.legs.length === 4) {
      const p = actor.gaitPhase;
      // Diagonal trot vs gallop phase
      const fl = Math.sin(p) * stride;
      const fr = Math.sin(p + (isRunning ? 0.45 : Math.PI)) * stride;
      const bl = Math.sin(p + (isRunning ? Math.PI : Math.PI)) * stride;
      const br = Math.sin(p + (isRunning ? Math.PI + 0.45 : 0)) * stride;
      const fold = actor.blendLie * 1.15;
      rig.legs[0].rotation.x = fl - fold;
      rig.legs[1].rotation.x = fr - fold;
      rig.legs[2].rotation.x = bl + fold + actor.blendSit * 0.95 + (actor.behavior === 'scratch' ? Math.sin(elapsed * 18) * 0.55 : 0);
      rig.legs[3].rotation.x = br + fold + actor.blendSit * 0.95;
    } else if (rig.legs.length === 2) {
      rig.legs[0].rotation.x = Math.sin(actor.gaitPhase) * stride * 1.2 - actor.blendLie * 0.85;
      rig.legs[1].rotation.x = -Math.sin(actor.gaitPhase) * stride * 1.2 - actor.blendLie * 0.85;
      if (rig.leftWing && rig.rightWing) {
        const flap =
          actor.behavior === 'chase_bug' || actor.behavior === 'play' || actor.emotion === 'scared'
            ? Math.abs(Math.sin(elapsed * 18)) * 0.65
            : Math.sin(elapsed * 2.4 + actor.phaseOffset) * 0.05;
        rig.leftWing.rotation.z = flap;
        rig.rightWing.rotation.z = -flap;
      }
    }

    // 4. Neck & Head Animation (Grazing/Pecking/Sniffing, Looking Around, Sleep Droop, Emotion)
    let targetHeadPitch = 0;
    let targetHeadYaw = 0;
    if (actor.blendGraze > 0.1) {
      const peckBob = type === 'chicken' ? Math.abs(Math.sin(elapsed * 7.5)) * 0.45 : Math.sin(elapsed * 3.2) * 0.12;
      targetHeadPitch = (0.72 + peckBob) * actor.blendGraze;
    } else if (isSleeping) {
      targetHeadPitch = 0.46;
      targetHeadYaw = 0.28;
    } else if (actor.emotion === 'sick' || actor.emotion === 'stressed') {
      targetHeadPitch = 0.34;
    } else if (actor.behavior === 'look_around') {
      targetHeadYaw = Math.sin(elapsed * 1.6 + actor.phaseOffset) * 0.65;
      targetHeadPitch = -0.08;
    } else if (actor.behavior === 'bark') {
      targetHeadPitch = -0.25 - Math.abs(Math.sin(elapsed * 10)) * 0.18;
    } else if (distToPlayer < 5.0) {
      // Curious gaze toward player!
      const relYaw = shortestAngleDiff(actor.yaw, Math.atan2(playerPos.x - actor.pos.x, playerPos.z - actor.pos.z));
      targetHeadYaw = THREE.MathUtils.clamp(relYaw, -0.6, 0.6);
      targetHeadPitch = -0.1;
    }

    actor.blendHeadPitch = THREE.MathUtils.damp(actor.blendHeadPitch, targetHeadPitch, 6.5, dt);
    actor.blendHeadYaw = THREE.MathUtils.damp(actor.blendHeadYaw, targetHeadYaw, 6.5, dt);
    rig.neckPivot.rotation.x = actor.blendHeadPitch * 0.65;
    rig.headPivot.rotation.x = actor.blendHeadPitch * 0.45;
    rig.headPivot.rotation.y = actor.blendHeadYaw;

    // 5. Facial Animation System (Eye Blinking, Nose Twitch, Mouth/Jaw Chew/Bark/Yawn)
    actor.blinkTimer -= dt;
    if (actor.blinkTimer <= 0) {
      actor.blinkTimer = 2.6 + Math.random() * 3.8;
    }
    const isBlinking = actor.blinkTimer < 0.14;
    const targetLidClose = isSleeping
      ? 1.0
      : isBlinking
        ? 1.0
        : actor.emotion === 'sleepy' || actor.emotion === 'sick'
          ? 0.58
          : 0.0;
    actor.blinkAmount = THREE.MathUtils.damp(actor.blinkAmount, targetLidClose, 22, dt);
    const lidRotX = THREE.MathUtils.lerp(-0.85, 0.18, actor.blinkAmount);
    rig.leftEyelid.rotation.x = lidRotX;
    rig.rightEyelid.rotation.x = lidRotX;

    // Mouth / Jaw movement when eating, grazing, barking, yawning
    const jawOpen =
      actor.behavior === 'yawn'
        ? 0.35 + Math.sin(elapsed * 2.8) * 0.18
        : actor.behavior === 'bark'
          ? Math.abs(Math.sin(elapsed * 11)) * 0.34
          : isGrazing || actor.behavior === 'eat' || actor.behavior === 'drink'
            ? Math.abs(Math.sin(elapsed * 6.5)) * 0.16
            : 0;
    rig.jawMesh.rotation.x = jawOpen;
    rig.noseMesh.scale.setScalar(1 + (actor.behavior === 'sniff' ? Math.sin(elapsed * 14) * 0.14 : 0));

    // 6. Ear Movement System (responds to sound, emotion & attention)
    const earDroop =
      actor.emotion === 'sick' || actor.emotion === 'scared' || actor.emotion === 'stressed'
        ? 0.48
        : actor.emotion === 'sleepy'
          ? 0.28
          : actor.emotion === 'happy'
            ? -0.14
            : 0;
    const earAlert = actor.earAlertTimer > 0 ? Math.sin(elapsed * 9) * 0.22 : Math.sin(elapsed * 1.4 + actor.phaseOffset) * 0.07;
    rig.leftEar.rotation.z = earDroop + earAlert;
    rig.rightEar.rotation.z = -earDroop - earAlert;
    rig.leftEar.rotation.y = actor.blendHeadYaw * 0.35;
    rig.rightEar.rotation.y = actor.blendHeadYaw * 0.35;

    // 7. Dynamic Tail & Wind-Responsive Mane System
    const windFlutter = Math.sin(elapsed * 2.8 + actor.pos.x * 0.35) * (weather === 'Stormy' ? 0.22 : 0.07);
    const wagTarget =
      actor.emotion === 'happy' || actor.behavior === 'play' || actor.behavior === 'follow_player'
        ? 1.0
        : actor.emotion === 'relaxed'
          ? 0.32
          : 0.05;
    actor.blendTailWag = THREE.MathUtils.damp(actor.blendTailWag, wagTarget, 6, dt);
    const wagFreq = type === 'dog' ? 11.5 : 4.5;
    const tailTuck = actor.emotion === 'scared' || actor.emotion === 'sick' ? 0.55 : 0;
    rig.tailPivot.rotation.y = Math.sin(elapsed * wagFreq + actor.phaseOffset) * (0.48 * actor.blendTailWag) + windFlutter;
    rig.tailPivot.rotation.x = tailTuck - actor.blendTailWag * 0.22 + actor.blendRun * 0.25;
    if (rig.tailTip) {
      rig.tailTip.rotation.y = Math.sin(elapsed * wagFreq - 0.7 + actor.phaseOffset) * (0.35 * actor.blendTailWag) + windFlutter;
    }
    if (rig.manePivot) {
      rig.manePivot.rotation.z = windFlutter * 1.15 + Math.sin(actor.gaitPhase) * 0.12 * actor.blendRun;
    }

    // 8. Lighting & Weather Color Response (soft natural tint for sick / rainy / sunny warmth)
    const tint = isSick ? _sickTint : isWet && !inInterior ? _rainTint : _warmTint;
    const tintStrength = isSick ? 0.35 : isWet && !inInterior ? 0.14 : 0.06;
    for (let i = 0; i < rig.coatMaterials.length; i++) {
      _tmpColor.copy(rig.baseCoatColors[i]).lerp(tint, tintStrength);
      rig.coatMaterials[i].color.lerp(_tmpColor, 1 - Math.exp(-3.0 * dt));
    }

    rig.root.position.copy(actor.pos);
    rig.root.rotation.y = actor.yaw;
  }
}
