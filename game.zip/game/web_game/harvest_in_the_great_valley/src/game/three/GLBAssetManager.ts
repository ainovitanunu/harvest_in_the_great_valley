import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { ASSET_MANIFEST } from '../assets/AssetRegistry';

class GLBAssetManager {
  private loader = new GLTFLoader();
  private cache = new Map<string, THREE.Group>();
  private preloadPromise: Promise<void> | null = null;

  public preloadAll(): Promise<void> {
    if (this.preloadPromise) return this.preloadPromise;

    const allPaths: string[] = [
      ...ASSET_MANIFEST.characters,
      ...ASSET_MANIFEST.tools,
      ...ASSET_MANIFEST.animals,
      ...ASSET_MANIFEST.crops,
      ...ASSET_MANIFEST.environment,
    ];

    this.preloadPromise = Promise.all(
      allPaths.map(
        (url) =>
          new Promise<void>((resolve, reject) => {
            this.loader.load(
              url,
              (gltf) => {
                gltf.scene.traverse((child) => {
                  if ((child as THREE.Mesh).isMesh) {
                    const m = child as THREE.Mesh;
                    m.castShadow = true;
                    m.receiveShadow = true;
                    const mats = Array.isArray(m.material) ? m.material : [m.material];
                    for (const mat of mats) {
                      const std = mat as THREE.MeshStandardMaterial;
                      const textures = [std?.map, std?.normalMap, std?.roughnessMap, std?.emissiveMap, std?.aoMap, std?.bumpMap];
                      for (const t of textures) {
                        if (t) {
                          t.generateMipmaps = true;
                          t.minFilter = THREE.LinearMipmapLinearFilter;
                          t.magFilter = THREE.LinearFilter;
                          t.needsUpdate = true;
                        }
                      }
                    }
                  }
                });
                this.cache.set(url, gltf.scene);
                resolve();
              },
              undefined,
              (err) => {
                console.error(`Failed loading GLB asset ${url}:`, err);
                reject(err);
              }
            );
          })
      )
    ).then(() => undefined);

    return this.preloadPromise;
  }

  public isLoaded(): boolean {
    return this.cache.size > 0;
  }

  public clone(url: string): THREE.Group {
    const template = this.cache.get(url);
    if (!template) {
      throw new Error(`GLB asset not yet loaded: ${url}`);
    }
    const cloned = template.clone(true);
    cloned.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mesh = child as THREE.Mesh;
        if (Array.isArray(mesh.material)) {
          mesh.material = mesh.material.map((m) => m.clone());
        } else if (mesh.material) {
          mesh.material = mesh.material.clone();
        }
      }
    });
    return cloned;
  }

  public getFirstMeshGeometryAndMaterial(url: string): {
    geometry: THREE.BufferGeometry;
    material: THREE.Material;
  } {
    const template = this.cache.get(url);
    if (!template) {
      throw new Error(`GLB asset not yet loaded: ${url}`);
    }
    let foundMesh: THREE.Mesh | null = null;
    template.traverse((child) => {
      if (!foundMesh && (child as THREE.Mesh).isMesh) {
        foundMesh = child as THREE.Mesh;
      }
    });
    if (!foundMesh) {
      throw new Error(`GLB asset has no mesh: ${url}`);
    }
    const mesh = foundMesh as THREE.Mesh;
    const mat = Array.isArray(mesh.material) ? mesh.material[0].clone() : mesh.material.clone();
    return { geometry: mesh.geometry, material: mat };
  }
}

export const glbAssets = new GLBAssetManager();
