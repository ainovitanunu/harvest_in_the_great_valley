import * as THREE from 'three';
import { CROPS } from '../data/itemsAndCrops';
import type { AvatarConfig, FarmObstacleType, NpcEmotion, NpcIdlePose, ToolKind } from '../types';
import { glbAssets } from './GLBAssetManager';

export interface ChibiFaceRig {
  leftBrow: THREE.Mesh;
  rightBrow: THREE.Mesh;
  mouth: THREE.Mesh;
  blushLeft: THREE.Mesh;
  blushRight: THREE.Mesh;
  leftEyelid: THREE.Mesh;
  rightEyelid: THREE.Mesh;
  leftPupil?: THREE.Mesh;
  rightPupil?: THREE.Mesh;
  blinkSeed: number;
}

export interface ChibiRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  headGroup: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  baseLeftLegY: number;
  baseRightLegY: number;
  toolMount: THREE.Group;
  contactShadow?: THREE.Mesh;
  faceRig?: ChibiFaceRig;
}

export interface LocomotionInput {
  /** World-space horizontal speed (m/s) for Motion Matching pose blending */
  horizontalSpeed: number;
  /** Maximum sprint speed for speed normalization (0..1) */
  maxSpeed: number;
  /** Vertical velocity (m/s) for Jump Ascend / Apex / Fall matching */
  verticalVel: number;
  /** Height above ground (m) for foot IK & contact shadow grounding */
  groundHeight: number;
  /** Root Motion stride phase accumulated from real world displacement */
  gaitPhase: number;
  /** Signed turning angular velocity (rad/s) for procedural corner banking & head look-ahead */
  turnRate: number;
  /** Landing impact squash intensity (0..1) */
  landSquash: number;
  /** Active dash burst (0..1) */
  dashWeight: number;
  /** Optional work/interaction target elevation offset for Hand IK (-0.4..0.6) */
  handIkReach?: number;
  /** Distinct activity animation mode when state === 'work' */
  workStyle?:
    | 'chop'
    | 'dig'
    | 'water'
    | 'sickle'
    | 'hammer'
    | 'fish_cast'
    | 'fish_wait'
    | 'fish_reel'
    | 'gift'
    | 'carry'
    | 'tidy';
  /** Normalized 0..1 progress through a single work swing for crisp wind-up -> impact -> follow-through */
  workProgress?: number;
  /** Optional Head Tracking & Eye Contact target yaw in local head space (-0.75..0.75 rad) */
  headTargetYaw?: number;
  /** Optional Head Tracking & Eye Contact target pitch in local head space (-0.35..0.35 rad) */
  headTargetPitch?: number;
  /** Current NPC/character facial emotion */
  emotion?: NpcEmotion;
  /** Whether character is currently speaking (drives subtle mouth talking motion) */
  isTalking?: boolean;
  /** Active world weather for subtle character physical reactions (shiver/rain-huddle/etc.) */
  weather?: string;
  /** Active time-of-day hour (0..23) for subtle sleepy/morning reactions */
  hour?: number;
}

const matCache = new Map<string, THREE.MeshStandardMaterial>();
export function getStdMat(
  color: string | number,
  roughness = 0.75,
  metalness = 0.04,
  emissive?: string | number,
  emissiveIntensity = 0
): THREE.MeshStandardMaterial {
  const key = `${color}_${roughness}_${metalness}_${emissive || ''}_${emissiveIntensity}`;
  const found = matCache.get(key);
  if (found) return found;
  const mat = new THREE.MeshStandardMaterial({
    color,
    roughness,
    metalness,
    emissive: emissive !== undefined ? new THREE.Color(emissive) : new THREE.Color(0x000000),
    emissiveIntensity,
  });
  matCache.set(key, mat);
  return mat;
}

let cachedContactTex: THREE.CanvasTexture | null = null;
export function getContactShadowTexture(): THREE.CanvasTexture {
  if (cachedContactTex) return cachedContactTex;
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(64, 64, 6, 64, 64, 60);
  grad.addColorStop(0, 'rgba(15, 23, 42, 0.42)');
  grad.addColorStop(0.6, 'rgba(15, 23, 42, 0.16)');
  grad.addColorStop(1, 'rgba(15, 23, 42, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  cachedContactTex = tex;
  return tex;
}

export function createContactShadow(radius = 0.7): THREE.Mesh {
  const geo = new THREE.PlaneGeometry(radius * 2, radius * 2);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshBasicMaterial({
    map: getContactShadowTexture(),
    transparent: true,
    depthWrite: false,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 0.025;
  return mesh;
}

export function createCanvasTexture(
  drawFn: (ctx: CanvasRenderingContext2D, w: number, h: number) => void,
  size = 256,
  repeat = 1,
  maxAnisotropy = 4,
  isData = false
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  drawFn(ctx, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  if (!isData) {
    tex.colorSpace = THREE.SRGBColorSpace;
  }
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  tex.generateMipmaps = true;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.anisotropy = Math.max(1, maxAnisotropy);
  return tex;
}

// === CACHED PROCEDURAL ENVIRONMENT TEXTURES ===
const treeTexCache: {
  oakBark?: THREE.CanvasTexture;
  pineBark?: THREE.CanvasTexture;
  birchBark?: THREE.CanvasTexture;
  leafTex?: THREE.CanvasTexture;
  leafBump?: THREE.CanvasTexture;
} = {};

function getTreeTextures(maxAnisotropy = 4) {
  if (!treeTexCache.oakBark) {
    treeTexCache.oakBark = createCanvasTexture(
      (ctx, w, h) => {
        ctx.fillStyle = '#6c4728';
        ctx.fillRect(0, 0, w, h);
        for (let x = 0; x < w; x += 6) {
          ctx.fillStyle = x % 12 === 0 ? 'rgba(42,24,10,0.45)' : 'rgba(140,96,58,0.28)';
          ctx.fillRect(x, 0, 3, h);
        }
        for (let i = 0; i < 420; i++) {
          ctx.fillStyle = i % 2 === 0 ? 'rgba(30,15,5,0.3)' : 'rgba(165,120,76,0.18)';
          ctx.fillRect(Math.random() * w, Math.random() * h, 3, 14 + Math.random() * 18);
        }
      },
      128,
      2,
      maxAnisotropy
    );
  }
  if (!treeTexCache.pineBark) {
    treeTexCache.pineBark = createCanvasTexture(
      (ctx, w, h) => {
        ctx.fillStyle = '#5c3322';
        ctx.fillRect(0, 0, w, h);
        for (let i = 0; i < 360; i++) {
          ctx.fillStyle = i % 2 === 0 ? 'rgba(35,14,8,0.42)' : 'rgba(130,74,48,0.28)';
          ctx.fillRect(Math.random() * w, Math.random() * h, 5, 10 + Math.random() * 12);
        }
      },
      128,
      2,
      maxAnisotropy
    );
  }
  if (!treeTexCache.birchBark) {
    treeTexCache.birchBark = createCanvasTexture(
      (ctx, w, h) => {
        ctx.fillStyle = '#ece6d8';
        ctx.fillRect(0, 0, w, h);
        for (let i = 0; i < 95; i++) {
          ctx.fillStyle = i % 3 === 0 ? '#473e36' : 'rgba(100,90,78,0.55)';
          const bw = 12 + Math.random() * 30;
          const bh = 2 + Math.random() * 4;
          ctx.fillRect(Math.random() * w, Math.random() * h, bw, bh);
        }
      },
      128,
      2,
      maxAnisotropy
    );
  }
  if (!treeTexCache.leafTex) {
    treeTexCache.leafTex = createCanvasTexture(
      (ctx, w, h) => {
        ctx.fillStyle = '#e8f5e0';
        ctx.fillRect(0, 0, w, h);
        for (let i = 0; i < 650; i++) {
          const r = 3 + Math.random() * 6;
          ctx.fillStyle =
            i % 3 === 0
              ? 'rgba(255,255,255,0.26)'
              : i % 3 === 1
                ? 'rgba(22,72,28,0.22)'
                : 'rgba(120,175,75,0.2)';
          ctx.beginPath();
          ctx.ellipse(Math.random() * w, Math.random() * h, r, r * 0.65, Math.random() * Math.PI, 0, Math.PI * 2);
          ctx.fill();
        }
      },
      128,
      2,
      maxAnisotropy
    );
  }
  if (!treeTexCache.leafBump) {
    treeTexCache.leafBump = createCanvasTexture(
      (ctx, w, h) => {
        ctx.fillStyle = '#808080';
        ctx.fillRect(0, 0, w, h);
        for (let i = 0; i < 500; i++) {
          const v = 70 + Math.floor(Math.random() * 115);
          ctx.fillStyle = `rgb(${v},${v},${v})`;
          ctx.beginPath();
          ctx.arc(Math.random() * w, Math.random() * h, 3 + Math.random() * 4, 0, Math.PI * 2);
          ctx.fill();
        }
      },
      128,
      2,
      maxAnisotropy,
      true
    );
  }
  return treeTexCache;
}

/**
 * Creates one of 3 visually distinct textured 3D tree silhouettes:
 * - 'oak': Broad multi-lobed countryside oak with sturdy brown bark
 * - 'pine': Tall alpine conifer with 4 stacked evergreen tiers
 * - 'birch': Slender white-barked birch with airy high canopy clusters
 */
export function createDistinctTreeMesh(
  modelType: 'oak' | 'pine' | 'birch',
  foliageHex: string | number,
  maxAnisotropy = 4
): { mesh: THREE.Group; crownMats: THREE.MeshStandardMaterial[] } {
  const tex = getTreeTextures(maxAnisotropy);
  const url =
    modelType === 'pine'
      ? '/assets/glb/environment/tree_pine.glb'
      : modelType === 'birch'
        ? '/assets/glb/environment/tree_birch.glb'
        : '/assets/glb/environment/tree_oak.glb';

  const group = glbAssets.clone(url);
  const crownMats: THREE.MeshStandardMaterial[] = [];

  const leafMat = new THREE.MeshStandardMaterial({
    color: foliageHex,
    map: tex.leafTex,
    bumpMap: tex.leafBump,
    bumpScale: 0.08,
    roughness: 0.86,
    metalness: 0.01,
  });
  crownMats.push(leafMat);

  const trunkMat = new THREE.MeshStandardMaterial({
    map: modelType === 'pine' ? tex.pineBark : modelType === 'birch' ? tex.birchBark : tex.oakBark,
    roughness: modelType === 'birch' ? 0.84 : 0.92,
    metalness: 0.02,
  });

  group.traverse((child) => {
    if (!(child as THREE.Mesh).isMesh) return;
    const mesh = child as THREE.Mesh;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    const lowerName = (mesh.name || '').toLowerCase();
    const matName = !Array.isArray(mesh.material) ? (mesh.material?.name || '').toLowerCase() : '';
    const isTrunk =
      lowerName.includes('trunk') ||
      lowerName.includes('bark') ||
      matName.includes('trunk') ||
      matName.includes('bark');
    if (isTrunk) {
      mesh.material = trunkMat;
    } else {
      mesh.material = leafMat;
    }
  });

  return { mesh: group, crownMats };
}

// Shared pooled low-poly geometries for Three.js THREE.LOD tiers (reduces RAM & draw buffer allocations on 4GB devices)
const treeLodGeoPool: {
  trunkMed?: THREE.CylinderGeometry;
  trunkLow?: THREE.CylinderGeometry;
  oakCrownMed?: THREE.IcosahedronGeometry;
  pineCrownMed1?: THREE.ConeGeometry;
  pineCrownMed2?: THREE.ConeGeometry;
  birchCrownMed?: THREE.IcosahedronGeometry;
  crownLowCone?: THREE.ConeGeometry;
  crownLowOct?: THREE.OctahedronGeometry;
} = {};

function getTreeLodGeos() {
  if (!treeLodGeoPool.trunkMed) {
    treeLodGeoPool.trunkMed = new THREE.CylinderGeometry(0.18, 0.3, 2.2, 6);
    treeLodGeoPool.trunkMed.translate(0, 1.1, 0);
  }
  if (!treeLodGeoPool.trunkLow) {
    treeLodGeoPool.trunkLow = new THREE.CylinderGeometry(0.18, 0.28, 2.1, 4);
    treeLodGeoPool.trunkLow.translate(0, 1.05, 0);
  }
  if (!treeLodGeoPool.oakCrownMed) {
    treeLodGeoPool.oakCrownMed = new THREE.IcosahedronGeometry(1.42, 1);
  }
  if (!treeLodGeoPool.pineCrownMed1) {
    treeLodGeoPool.pineCrownMed1 = new THREE.ConeGeometry(1.38, 2.35, 6);
  }
  if (!treeLodGeoPool.pineCrownMed2) {
    treeLodGeoPool.pineCrownMed2 = new THREE.ConeGeometry(1.02, 1.9, 6);
  }
  if (!treeLodGeoPool.birchCrownMed) {
    treeLodGeoPool.birchCrownMed = new THREE.IcosahedronGeometry(1.08, 1);
  }
  if (!treeLodGeoPool.crownLowCone) {
    treeLodGeoPool.crownLowCone = new THREE.ConeGeometry(1.35, 3.1, 5);
  }
  if (!treeLodGeoPool.crownLowOct) {
    treeLodGeoPool.crownLowOct = new THREE.OctahedronGeometry(1.35, 0);
  }
  return treeLodGeoPool;
}

/**
 * Multi-level Three.js LOD Tree Builder:
 * - LOD0 (0..lod0Dist m): Full detailed GLB mesh (100% triangles)
 * - LOD1 (lod0Dist..lod1Dist m): Simplified 6-seg trunk + low-poly crown (~50% triangle reduction)
 * - LOD2 (lod1Dist+ m): Ultra-light 4-seg silhouette proxy without bump map or shadow casting (~85% triangle reduction)
 */
export function createDistinctTreeLodMesh(
  modelType: 'oak' | 'pine' | 'birch',
  foliageHex: string | number,
  maxAnisotropy = 4,
  lod0Dist = 16,
  lod1Dist = 36
): { mesh: THREE.Group; lod: THREE.LOD; crownMats: THREE.MeshStandardMaterial[] } {
  const { mesh: lod0Group, crownMats } = createDistinctTreeMesh(modelType, foliageHex, maxAnisotropy);
  const geos = getTreeLodGeos();
  const tex = getTreeTextures(maxAnisotropy);
  const baseLeafMat = crownMats[0];
  const trunkMat = getStdMat(modelType === 'birch' ? '#e5dfd2' : modelType === 'pine' ? '#5c3322' : '#6c4728', 0.9, 0.01);
  const lod2LeafMat = new THREE.MeshStandardMaterial({
    color: foliageHex,
    map: tex.leafTex,
    roughness: 0.9,
    metalness: 0.0,
  });
  crownMats.push(lod2LeafMat);

  // LOD1 (~50% fewer triangles)
  const lod1Group = new THREE.Group();
  const trunk1 = new THREE.Mesh(geos.trunkMed!, trunkMat);
  trunk1.castShadow = true;
  lod1Group.add(trunk1);
  if (modelType === 'pine') {
    const c1 = new THREE.Mesh(geos.pineCrownMed1!, baseLeafMat);
    c1.position.y = 2.6;
    c1.castShadow = true;
    const c2 = new THREE.Mesh(geos.pineCrownMed2!, baseLeafMat);
    c2.position.y = 3.8;
    lod1Group.add(c1, c2);
  } else if (modelType === 'birch') {
    const c1 = new THREE.Mesh(geos.birchCrownMed!, baseLeafMat);
    c1.position.y = 3.15;
    c1.scale.set(0.95, 1.25, 0.95);
    c1.castShadow = true;
    lod1Group.add(c1);
  } else {
    const c1 = new THREE.Mesh(geos.oakCrownMed!, baseLeafMat);
    c1.position.y = 2.95;
    c1.scale.set(1.08, 0.92, 1.08);
    c1.castShadow = true;
    lod1Group.add(c1);
  }

  // LOD2 (~85% fewer triangles, zero shadow casting)
  const lod2Group = new THREE.Group();
  const trunk2 = new THREE.Mesh(geos.trunkLow!, trunkMat);
  const crown2 = new THREE.Mesh(
    modelType === 'pine' ? geos.crownLowCone! : geos.crownLowOct!,
    lod2LeafMat
  );
  crown2.position.y = modelType === 'pine' ? 3.05 : 2.95;
  lod2Group.add(trunk2, crown2);

  const lod = new THREE.LOD();
  lod.userData.isTreeLod = true;
  lod.addLevel(lod0Group, 0);
  lod.addLevel(lod1Group, Math.max(8, lod0Dist));
  lod.addLevel(lod2Group, Math.max(18, lod1Dist));

  const wrapper = new THREE.Group();
  wrapper.add(lod);
  return { mesh: wrapper, lod, crownMats };
}

export function updateTreeLodDistances(root: THREE.Object3D, enableLod: boolean, lod0Dist: number, lod1Dist: number) {
  root.traverse((obj) => {
    if (obj instanceof THREE.LOD && obj.userData.isTreeLod) {
      if (obj.levels.length >= 3) {
        obj.levels[0].distance = 0;
        obj.levels[1].distance = enableLod ? Math.max(8, lod0Dist) : 9999;
        obj.levels[2].distance = enableLod ? Math.max(18, lod1Dist) : 9999;
      }
    }
  });
}

// === PROCEDURAL EXTRA HAIR, HAT, SHIRT, PANTS & ACCESSORY ATTACHMENTS ===
const BUILTIN_HAIR = new Set(['spiky', 'ponytail', 'bob', 'long', 'buns', 'short']);
const BUILTIN_HAT = new Set(['farmer_cap', 'straw_hat', 'flower_clip', 'wizard_hat']);
const BUILTIN_ACC = new Set(['bandana', 'glasses', 'scarf']);

function attachExtraHair(headGroup: THREE.Group, style: AvatarConfig['hairStyle'], hairHex: string) {
  if (style === 'none' || BUILTIN_HAIR.has(style)) return;
  const hairMat = getStdMat(hairHex, style === 'wet_look_90s' ? 0.22 : 0.72, style === 'wet_look_90s' ? 0.18 : 0.04);
  const g = new THREE.Group();
  g.name = `CustomHair_${style}`;

  const addCap = (radius = 0.365, phiLen = Math.PI * 0.58, y = 0.08) => {
    const cap = new THREE.Mesh(new THREE.SphereGeometry(radius, 12, 10, 0, Math.PI * 2, 0, phiLen), hairMat);
    cap.position.y = y;
    cap.castShadow = true;
    g.add(cap);
    return cap;
  };

  if (style === 'curly' || style === 'curly_undercut') {
    const isUndercut = style === 'curly_undercut';
    const offsets: Array<[number, number, number, number]> = isUndercut
      ? [
          [0, 0.38, 0.02, 0.25],
          [-0.16, 0.34, 0.14, 0.16],
          [0.16, 0.34, 0.14, 0.16],
          [-0.15, 0.34, -0.12, 0.16],
          [0.15, 0.34, -0.12, 0.16],
          [0, 0.36, 0.2, 0.14],
        ]
      : [
          [0, 0.36, 0, 0.28],
          [-0.24, 0.28, 0.08, 0.18],
          [0.24, 0.28, 0.08, 0.18],
          [-0.22, 0.24, -0.16, 0.19],
          [0.22, 0.24, -0.16, 0.19],
          [0, 0.28, -0.24, 0.22],
          [-0.14, 0.36, 0.2, 0.15],
          [0.14, 0.36, 0.2, 0.15],
        ];
    offsets.forEach(([x, y, z, r]) => {
      const puff = new THREE.Mesh(new THREE.SphereGeometry(r, 10, 8), hairMat);
      puff.position.set(x, y, z);
      puff.castShadow = true;
      g.add(puff);
    });
  } else if (style === 'braids') {
    addCap(0.36, Math.PI * 0.62, 0.08);
    [-0.27, 0.27].forEach((side) => {
      for (let i = 0; i < 4; i++) {
        const bead = new THREE.Mesh(new THREE.SphereGeometry(0.085 - i * 0.008, 8, 8), hairMat);
        bead.position.set(side, 0.02 - i * 0.11, -0.08);
        bead.castShadow = true;
        g.add(bead);
      }
      const tie = new THREE.Mesh(new THREE.TorusGeometry(0.055, 0.018, 6, 10), getStdMat('#f59e0b', 0.4, 0.2));
      tie.position.set(side, -0.32, -0.08);
      tie.rotation.x = Math.PI / 2;
      g.add(tie);
    });
  } else if (style === 'mohawk' || style === 'burst_fade') {
    if (style === 'burst_fade') addCap(0.34, Math.PI * 0.48, 0.12);
    for (let i = 0; i < 5; i++) {
      const spike = new THREE.Mesh(new THREE.ConeGeometry(style === 'burst_fade' ? 0.11 : 0.09, style === 'burst_fade' ? 0.19 : 0.24, 6), hairMat);
      spike.position.set(0, 0.38 - Math.abs(i - 2) * 0.022, 0.2 - i * 0.11);
      spike.rotation.x = -0.2 + i * 0.14;
      spike.castShadow = true;
      g.add(spike);
    }
    if (style === 'burst_fade') {
      const nape = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.24, 0.16), hairMat);
      nape.position.set(0, 0.06, -0.3);
      g.add(nape);
    }
  } else if (style === 'undercut' || style === 'mid_fade_slick_back' || style === 'ivy_league' || style === 'side_part_clean') {
    const top = new THREE.Mesh(new THREE.BoxGeometry(0.46, style === 'ivy_league' ? 0.14 : 0.18, 0.56), hairMat);
    top.position.set(0, 0.31, style === 'mid_fade_slick_back' ? -0.02 : 0.02);
    top.castShadow = true;
    const sweep = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.1, 0.24), hairMat);
    sweep.position.set(style === 'side_part_clean' ? 0.07 : 0.03, 0.27, style === 'mid_fade_slick_back' ? -0.18 : 0.21);
    sweep.rotation.z = style === 'side_part_clean' ? -0.24 : -0.14;
    if (style === 'mid_fade_slick_back') {
      sweep.rotation.x = -0.22;
    }
    g.add(top, sweep);
  } else if (style === 'modern_pompadour' || style === 'messy_quiff') {
    addCap(0.35, Math.PI * 0.48, 0.11);
    const crest = new THREE.Mesh(
      new THREE.SphereGeometry(style === 'modern_pompadour' ? 0.24 : 0.21, 12, 10),
      hairMat
    );
    crest.scale.set(1.05, 0.72, 1.38);
    crest.position.set(0, 0.39, 0.13);
    crest.rotation.x = -0.22;
    crest.castShadow = true;
    g.add(crest);
    if (style === 'messy_quiff') {
      for (let i = -1; i <= 1; i++) {
        const tuft = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.16, 6), hairMat);
        tuft.position.set(i * 0.12, 0.42, 0.24);
        tuft.rotation.x = 0.45;
        tuft.rotation.z = -i * 0.25;
        g.add(tuft);
      }
    }
  } else if (style === 'buzz_cut' || style === 'low_taper_fade' || style === 'crew_cut_textured') {
    addCap(style === 'buzz_cut' ? 0.355 : 0.365, style === 'buzz_cut' ? Math.PI * 0.52 : Math.PI * 0.56, 0.09);
    if (style === 'crew_cut_textured' || style === 'low_taper_fade') {
      const topPad = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.31, 0.11, 12), hairMat);
      topPad.position.set(0, 0.34, 0.02);
      g.add(topPad);
    }
  } else if (style === 'textured_crop' || style === 'french_crop_fade') {
    addCap(0.36, Math.PI * 0.52, 0.1);
    const fringe = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.12, 0.18), hairMat);
    fringe.position.set(0, 0.24, 0.29);
    fringe.castShadow = true;
    g.add(fringe);
    if (style === 'textured_crop') {
      for (let i = -2; i <= 2; i++) {
        const lock = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.13, 5), hairMat);
        lock.position.set(i * 0.1, 0.17, 0.34);
        lock.rotation.x = Math.PI + 0.15;
        g.add(lock);
      }
    }
  } else if (style === 'soft_mullet' || style === 'wolf_cut' || style === 'bro_flow') {
    addCap(0.37, Math.PI * 0.62, 0.09);
    const backFlow = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24, style === 'wolf_cut' ? 0.36 : 0.31, style === 'bro_flow' ? 0.36 : 0.44, 10),
      hairMat
    );
    backFlow.position.set(0, -0.08, -0.2);
    backFlow.rotation.x = 0.16;
    backFlow.castShadow = true;
    g.add(backFlow);
    if (style === 'wolf_cut' || style === 'soft_mullet') {
      [-0.25, 0.25].forEach((side) => {
        const sideLayer = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.28, 6), hairMat);
        sideLayer.position.set(side, 0.02, 0.02);
        sideLayer.rotation.x = Math.PI;
        g.add(sideLayer);
      });
    }
  } else if (style === 'curtain_hair' || style === 'k_inspired') {
    addCap(0.37, Math.PI * 0.6, 0.09);
    [-1, 1].forEach((dir) => {
      const curtain = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.24, 0.14), hairMat);
      curtain.position.set(dir * 0.17, 0.18, 0.27);
      curtain.rotation.z = dir * (style === 'k_inspired' ? 0.34 : 0.22);
      curtain.rotation.y = -dir * 0.22;
      curtain.castShadow = true;
      g.add(curtain);
    });
  } else if (style === 'afro' || style === 'natural_afro') {
    const dome = new THREE.Mesh(new THREE.IcosahedronGeometry(style === 'natural_afro' ? 0.48 : 0.45, 1), hairMat);
    dome.position.set(0, 0.26, -0.04);
    dome.castShadow = true;
    g.add(dome);
  } else if (
    style === 'ultra_short_bob' ||
    style === 'structured_bob' ||
    style === 'french_bob' ||
    style === 'bixie' ||
    style === 'baby_bob' ||
    style === 'floating_bob'
  ) {
    addCap(0.375, Math.PI * 0.64, 0.09);
    const len = style === 'ultra_short_bob' || style === 'bixie' ? 0.24 : style === 'baby_bob' ? 0.28 : 0.34;
    const flare = style === 'floating_bob' ? 0.36 : style === 'structured_bob' ? 0.31 : 0.33;
    const bobShell = new THREE.Mesh(new THREE.CylinderGeometry(0.33, flare, len, 14, 1, false, Math.PI * 0.18, Math.PI * 1.64), hairMat);
    bobShell.position.set(0, 0.07 - len * 0.35, -0.03);
    bobShell.rotation.y = Math.PI;
    bobShell.castShadow = true;
    g.add(bobShell);
    if (style === 'french_bob' || style === 'bixie') {
      const wispy = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.1, 0.14), hairMat);
      wispy.position.set(0, 0.24, 0.29);
      g.add(wispy);
    }
  } else if (style === 'sculptural_updo') {
    addCap(0.37, Math.PI * 0.62, 0.08);
    const bun = new THREE.Mesh(new THREE.TorusKnotGeometry(0.14, 0.055, 28, 8, 2, 3), hairMat);
    bun.position.set(0, 0.5, -0.06);
    bun.castShadow = true;
    const pin = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.42, 6), getStdMat('#fbbf24', 0.3, 0.7));
    pin.position.set(0, 0.5, -0.06);
    pin.rotation.z = 1.25;
    g.add(bun, pin);
  } else if (
    style === 'wavy' ||
    style === 'butterfly_cut' ||
    style === 'birkin_layers' ||
    style === 'face_framing_layers' ||
    style === 'rebel_layers' ||
    style === 'supermodel_blowout' ||
    style === 'side_part_woman' ||
    style === 'butterfly_fringe' ||
    style === 'poni_tebal' ||
    style === 'wet_look_90s' ||
    style === 'emo_fringe'
  ) {
    addCap(0.38, Math.PI * 0.65, 0.09);
    const bottomRad = style === 'supermodel_blowout' || style === 'butterfly_cut' ? 0.41 : 0.34;
    const height = style === 'rebel_layers' ? 0.4 : 0.52;
    const backWave = new THREE.Mesh(new THREE.CylinderGeometry(0.29, bottomRad, height, 12), hairMat);
    backWave.position.set(0, -0.14, -0.15);
    backWave.castShadow = true;
    g.add(backWave);

    if (style === 'butterfly_cut' || style === 'face_framing_layers' || style === 'supermodel_blowout' || style === 'rebel_layers') {
      [-0.29, 0.29].forEach((side) => {
        const wing = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.36, 8), hairMat);
        wing.position.set(side, -0.04, 0.08);
        wing.rotation.x = Math.PI;
        wing.rotation.z = side > 0 ? 0.2 : -0.2;
        g.add(wing);
      });
    }
    if (style === 'poni_tebal' || style === 'birkin_layers') {
      const bangs = new THREE.Mesh(new THREE.BoxGeometry(0.52, style === 'poni_tebal' ? 0.16 : 0.11, 0.15), hairMat);
      bangs.position.set(0, 0.22, 0.3);
      g.add(bangs);
    }
    if (style === 'butterfly_fringe') {
      [-1, 1].forEach((dir) => {
        const f = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.16, 0.14), hairMat);
        f.position.set(dir * 0.17, 0.22, 0.28);
        f.rotation.z = dir * 0.32;
        g.add(f);
      });
    }
    if (style === 'emo_fringe' || style === 'side_part_woman') {
      const sideSweep = new THREE.Mesh(new THREE.BoxGeometry(0.36, style === 'emo_fringe' ? 0.28 : 0.18, 0.16), hairMat);
      sideSweep.position.set(0.11, 0.17, 0.29);
      sideSweep.rotation.z = -0.34;
      g.add(sideSweep);
    }
  }

  headGroup.add(g);
}

function attachExtraHat(headGroup: THREE.Group, hatStyle: AvatarConfig['hatStyle'], outfitHex: string) {
  if (hatStyle === 'none' || BUILTIN_HAT.has(hatStyle)) return;
  const g = new THREE.Group();
  g.name = `CustomHat_${hatStyle}`;

  if (hatStyle === 'cowboy_hat') {
    const mat = getStdMat('#7c4a26', 0.85, 0.05);
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.56, 0.58, 0.05, 16), mat);
    brim.position.y = 0.33;
    const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.32, 0.26, 12), mat);
    crown.position.y = 0.46;
    const band = new THREE.Mesh(new THREE.CylinderGeometry(0.325, 0.325, 0.06, 12), getStdMat('#d97706', 0.45, 0.2));
    band.position.y = 0.38;
    g.add(brim, crown, band);
  } else if (hatStyle === 'beanie') {
    const mat = getStdMat(outfitHex, 0.92, 0.01);
    const dome = new THREE.Mesh(new THREE.SphereGeometry(0.36, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.56), mat);
    dome.position.y = 0.16;
    const cuff = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.06, 8, 16), mat);
    cuff.rotation.x = Math.PI / 2;
    cuff.position.y = 0.22;
    const pom = new THREE.Mesh(new THREE.SphereGeometry(0.085, 8, 8), getStdMat('#fef3c7', 0.9, 0));
    pom.position.y = 0.54;
    g.add(dome, cuff, pom);
  } else if (hatStyle === 'beret') {
    const mat = getStdMat(outfitHex, 0.88, 0.02);
    const disc = new THREE.Mesh(new THREE.SphereGeometry(0.37, 14, 10), mat);
    disc.scale.set(1.12, 0.38, 1.12);
    disc.position.set(0.06, 0.38, -0.02);
    disc.rotation.z = -0.22;
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.09, 6), mat);
    stem.position.set(0.08, 0.52, -0.02);
    g.add(disc, stem);
  } else if (hatStyle === 'crown') {
    const goldMat = getStdMat('#facc15', 0.26, 0.78, '#eab308', 0.15);
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.26, 0.13, 12), goldMat);
    base.position.y = 0.4;
    g.add(base);
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const tip = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.14, 5), goldMat);
      tip.position.set(Math.cos(a) * 0.24, 0.51, Math.sin(a) * 0.24);
      g.add(tip);
    }
    const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.05, 0), getStdMat('#ef4444', 0.2, 0.3));
    gem.position.set(0, 0.42, 0.28);
    g.add(gem);
  } else if (hatStyle === 'chef_hat') {
    const whiteMat = getStdMat('#ffffff', 0.8, 0.02);
    const band = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.18, 12), whiteMat);
    band.position.y = 0.38;
    const puff = new THREE.Mesh(new THREE.SphereGeometry(0.32, 12, 10), whiteMat);
    puff.scale.set(1.1, 0.85, 1.1);
    puff.position.y = 0.58;
    g.add(band, puff);
  } else if (hatStyle === 'sun_visor') {
    const mat = getStdMat(outfitHex, 0.65, 0.08);
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.33, 0.04, 8, 16), mat);
    band.rotation.x = Math.PI / 2;
    band.position.y = 0.24;
    const bill = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.035, 0.32), mat);
    bill.position.set(0, 0.22, 0.34);
    bill.rotation.x = 0.14;
    g.add(band, bill);
  }

  headGroup.add(g);
}

function attachExtraClothingAndAcc(
  rig: { bodyGroup: THREE.Group; headGroup: THREE.Group; leftLeg: THREE.Group; rightLeg: THREE.Group },
  avatarConfig: AvatarConfig,
  outfitHex: string,
  pantsHex: string
) {
  const shirtStyle = avatarConfig.shirtStyle ?? 'overalls';
  const pantsStyle = avatarConfig.pantsStyle ?? 'trousers';
  const acc = avatarConfig.accessory ?? 'none';

  // Shirt extras
  if (shirtStyle === 'hoodie') {
    const hood = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.08, 8, 14), getStdMat(outfitHex, 0.9, 0.02));
    hood.rotation.x = Math.PI / 2;
    hood.position.set(0, 0.98, -0.05);
    const pocket = new THREE.Mesh(
      new THREE.BoxGeometry(0.32, 0.14, 0.06),
      getStdMat(new THREE.Color(outfitHex).multiplyScalar(0.85).getStyle(), 0.9, 0.02)
    );
    pocket.position.set(0, 0.66, 0.2);
    rig.bodyGroup.add(hood, pocket);
  } else if (shirtStyle === 'jacket') {
    const trim = getStdMat('#1e293b', 0.55, 0.15);
    const lapelL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.36, 0.06), trim);
    lapelL.position.set(-0.1, 0.78, 0.2);
    const lapelR = lapelL.clone();
    lapelR.position.x = 0.1;
    rig.bodyGroup.add(lapelL, lapelR);
  } else if (shirtStyle === 'apron') {
    const apron = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.42, 0.05), getStdMat('#fef3c7', 0.86, 0.02));
    apron.position.set(0, 0.68, 0.21);
    rig.bodyGroup.add(apron);
  } else if (shirtStyle === 'kimono') {
    const obi = new THREE.Mesh(new THREE.CylinderGeometry(0.245, 0.25, 0.14, 14), getStdMat('#dc2626', 0.65, 0.08));
    obi.position.set(0, 0.64, 0);
    rig.bodyGroup.add(obi);
  } else if (shirtStyle === 'polo' || shirtStyle === 'flannel') {
    const collar = new THREE.Mesh(
      new THREE.TorusGeometry(0.18, 0.045, 6, 12),
      getStdMat(shirtStyle === 'polo' ? '#ffffff' : '#3b2416', 0.8, 0.02)
    );
    collar.rotation.x = Math.PI / 2;
    collar.position.set(0, 0.95, 0.02);
    rig.bodyGroup.add(collar);
  }

  // Pants extras
  if (pantsStyle === 'pleated_skirt') {
    const skirt = new THREE.Mesh(new THREE.ConeGeometry(0.36, 0.34, 14), getStdMat(pantsHex, 0.82, 0.02));
    skirt.position.set(0, 0.46, 0);
    skirt.castShadow = true;
    rig.bodyGroup.add(skirt);
  } else if (pantsStyle === 'boots_pants') {
    const bootMat = getStdMat('#3f2310', 0.55, 0.15);
    [rig.leftLeg, rig.rightLeg].forEach((leg) => {
      const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.115, 0.16, 10), bootMat);
      cuff.position.set(0, -0.22, 0);
      leg.add(cuff);
    });
  } else if (pantsStyle === 'cargos') {
    const pocketMat = getStdMat(new THREE.Color(pantsHex).multiplyScalar(0.82).getStyle(), 0.9, 0.02);
    [rig.leftLeg, rig.rightLeg].forEach((leg, idx) => {
      const p = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.11, 0.11), pocketMat);
      p.position.set(idx === 0 ? -0.095 : 0.095, -0.1, 0);
      leg.add(p);
    });
  }

  // Extra Accessories
  if (acc !== 'none' && !BUILTIN_ACC.has(acc)) {
    if (acc === 'bowtie') {
      const bowMat = getStdMat('#dc2626', 0.5, 0.12);
      const wingL = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.11, 4), bowMat);
      wingL.rotation.z = -Math.PI / 2;
      wingL.position.set(-0.055, 0.93, 0.21);
      const wingR = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.11, 4), bowMat);
      wingR.rotation.z = Math.PI / 2;
      wingR.position.set(0.055, 0.93, 0.21);
      const knot = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 8), bowMat);
      knot.position.set(0, 0.93, 0.22);
      rig.bodyGroup.add(wingL, wingR, knot);
    } else if (acc === 'sunglasses') {
      const frameMat = getStdMat('#0f172a', 0.22, 0.55);
      const lensL = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.09, 0.03), frameMat);
      lensL.position.set(-0.1, 0.08, 0.34);
      const lensR = lensL.clone();
      lensR.position.x = 0.1;
      const bridge = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.025, 0.03), frameMat);
      bridge.position.set(0, 0.1, 0.34);
      rig.headGroup.add(lensL, lensR, bridge);
    }
  }
}

export function createChibiCharacter(opts: {
  avatarConfig: AvatarConfig;
  skinColor?: string;
  scale?: number;
}): ChibiRig {
  const { avatarConfig, skinColor, scale = 1.0 } = opts;
  const modelUrl =
    avatarConfig.gender === 'female'
      ? '/assets/glb/characters/chibi_female.glb'
      : '/assets/glb/characters/chibi_male.glb';
  const root = glbAssets.clone(modelUrl);
  root.scale.setScalar(scale);

  const contactShadow = createContactShadow(0.62);
  root.add(contactShadow);

  const bodyGroup = (root.getObjectByName('BodyGroup') as THREE.Group) || root;
  const headGroup = (root.getObjectByName('HeadGroup') as THREE.Group) || root;
  const leftArm = (root.getObjectByName('LeftArm') as THREE.Group) || new THREE.Group();
  const rightArm = (root.getObjectByName('RightArm') as THREE.Group) || new THREE.Group();
  const leftLeg = (root.getObjectByName('LeftLeg') as THREE.Group) || new THREE.Group();
  const rightLeg = (root.getObjectByName('RightLeg') as THREE.Group) || new THREE.Group();
  const toolMount = (root.getObjectByName('ToolMount') as THREE.Group) || new THREE.Group();

  const resolvedSkin = avatarConfig.skinColor || skinColor || '#fcd5b5';
  const hairHex = avatarConfig.hairColor || '#6b3e1b';
  const outfitHex = avatarConfig.outfitColor || '#2563eb';
  const pantsHex = avatarConfig.pantsColor || '#1e3a8a';
  const eyeHex = avatarConfig.eyeColor || '#1e1b4b';
  const shirtStyle = avatarConfig.shirtStyle ?? 'overalls';
  const pantsStyle = avatarConfig.pantsStyle ?? 'trousers';

  const isInsideHat = (node: THREE.Object3D): boolean => {
    let cur: THREE.Object3D | null = node.parent;
    while (cur) {
      if (cur.name.startsWith('Hat_')) return true;
      cur = cur.parent;
    }
    return false;
  };

  root.traverse((obj) => {
    if (obj.name.startsWith('Hair_')) {
      obj.visible = avatarConfig.hairStyle !== 'none' && obj.name === `Hair_${avatarConfig.hairStyle}`;
    } else if (obj.name.startsWith('Hat_')) {
      obj.visible = avatarConfig.hatStyle !== 'none' && obj.name === `Hat_${avatarConfig.hatStyle}`;
    } else if (obj.name.startsWith('Acc_')) {
      obj.visible = avatarConfig.accessory !== 'none' && obj.name === `Acc_${avatarConfig.accessory}`;
    }

    if ((obj as THREE.Mesh).isMesh) {
      const mesh = obj as THREE.Mesh;
      const mat = mesh.material as THREE.MeshStandardMaterial;
      if (!mat) return;
      const inHat = isInsideHat(mesh);

      if (mesh.name.includes('SkinPart') || mat.name === 'SkinMat') {
        mat.color.set(resolvedSkin);
      } else if (mesh.name.includes('HairPart') || mat.name === 'HairMat') {
        mat.color.set(hairHex);
      } else if (mesh.name.includes('EyeIrisPart') || mat.name === 'EyeIrisMat') {
        mat.color.set(eyeHex);
      } else if (mesh.name.includes('PantsPart') || mat.name === 'PantsMat') {
        if (pantsStyle === 'none') {
          mat.color.set(resolvedSkin);
          mat.roughness = 0.72;
        } else {
          mat.color.set(pantsHex);
          mat.roughness = pantsStyle === 'denim' || pantsStyle === 'cargos' ? 0.9 : 0.78;
        }
      } else if (inHat) {
        if (mesh.name.includes('OutfitPart') || mat.name === 'CapMat' || mat.name === 'OutfitMat') {
          mat.color.set(outfitHex);
        }
      } else if (mesh.name.includes('OutfitPart') || mat.name === 'OutfitMat') {
        const lower = mesh.name.toLowerCase();
        const isSkirtLike = lower.includes('skirt') || (avatarConfig.gender === 'female' && mesh.position.y < 0.75);
        if (isSkirtLike) {
          mesh.visible = pantsStyle === 'skirt';
          mat.color.set(pantsHex);
        } else {
          mesh.visible = shirtStyle === 'overalls' || shirtStyle === 'vest';
          if (shirtStyle === 'vest') {
            const c = new THREE.Color(outfitHex).multiplyScalar(0.75);
            mat.color.copy(c);
          } else {
            mat.color.set(outfitHex);
          }
        }
      } else if (mesh.name.includes('ShirtPart') || mat.name === 'ShirtMat') {
        if (shirtStyle === 'none') {
          mat.color.set(resolvedSkin);
          mat.roughness = 0.72;
        } else if (shirtStyle === 'overalls') {
          mat.color.set('#f8fafc');
          mat.roughness = 0.8;
        } else if (shirtStyle === 'sweater' || shirtStyle === 'hoodie') {
          mat.color.set(outfitHex);
          mat.roughness = 0.95;
        } else {
          mat.color.set(outfitHex);
          mat.roughness = 0.78;
        }
      }
    }
  });

  // Attach procedural meshes for all expanded hairstyles, hats, shirts, pants & accessories
  attachExtraHair(headGroup, avatarConfig.hairStyle, hairHex);
  attachExtraHat(headGroup, avatarConfig.hatStyle, outfitHex);
  attachExtraClothingAndAcc({ bodyGroup, headGroup, leftLeg, rightLeg }, avatarConfig, outfitHex, pantsHex);

  // === ANATOMICAL RIGGING FIX: Gender-Fitted Pelvis/Hip Bridge, Tucked Shoulder Sockets & Hip Balls ===
  // Guarantees zero visual gap between torso, shoulders, arms, belt, pelvis, and thighs across all animations.
  const isFemale = avatarConfig.gender === 'female';
  const targetArmX = isFemale ? 0.205 : 0.285;
  const targetLegX = isFemale ? 0.105 : 0.135;
  leftArm.position.set(-targetArmX, 0.84, 0);
  rightArm.position.set(targetArmX, 0.84, 0);
  leftArm.rotation.z = isFemale ? -0.075 : -0.055;
  rightArm.rotation.z = isFemale ? 0.075 : 0.055;
  leftLeg.position.x = -targetLegX;
  rightLeg.position.x = targetLegX;

  const hipColor = pantsStyle === 'none' ? resolvedSkin : pantsHex;
  const hipMat = getStdMat(hipColor, pantsStyle === 'denim' || pantsStyle === 'cargos' ? 0.88 : 0.78, 0.03);
  const pelvisTopR = isFemale ? 0.176 : 0.226;
  const pelvisBotR = isFemale ? 0.2 : 0.238;
  const pelvisBridge = new THREE.Mesh(new THREE.CylinderGeometry(pelvisTopR, pelvisBotR, 0.19, 16), hipMat);
  pelvisBridge.name = 'PelvisBridge';
  pelvisBridge.position.set(0, 0.49, 0);
  pelvisBridge.castShadow = true;
  pelvisBridge.receiveShadow = true;

  const pelvisRoundCap = new THREE.Mesh(new THREE.SphereGeometry(pelvisBotR * 0.99, 14, 10), hipMat);
  pelvisRoundCap.name = 'PelvisCap';
  pelvisRoundCap.scale.set(1.06, 0.56, 0.92);
  pelvisRoundCap.position.set(0, 0.415, 0);
  pelvisRoundCap.castShadow = true;

  const waistBandColor =
    shirtStyle === 'overalls' ? outfitHex : new THREE.Color(hipColor).multiplyScalar(0.74).getStyle();
  const waistBand = new THREE.Mesh(
    new THREE.CylinderGeometry(pelvisTopR + 0.008, pelvisTopR + 0.01, 0.055, 16),
    getStdMat(waistBandColor, 0.72, 0.08)
  );
  waistBand.name = 'WaistConnector';
  waistBand.position.set(0, 0.575, 0);

  const neckConnector = new THREE.Mesh(new THREE.CylinderGeometry(0.082, 0.095, 0.12, 10), getStdMat(resolvedSkin, 0.74, 0.02));
  neckConnector.name = 'NeckConnector';
  neckConnector.position.set(0, 0.975, 0);

  const sleeveColor = shirtStyle === 'none' ? resolvedSkin : shirtStyle === 'overalls' ? '#f8fafc' : outfitHex;
  const sleeveMat = getStdMat(sleeveColor, 0.8, 0.02);
  const shoulderBridge = new THREE.Mesh(
    new THREE.SphereGeometry(isFemale ? 0.186 : 0.226, 14, 10),
    sleeveMat
  );
  shoulderBridge.name = 'ShoulderBridge';
  shoulderBridge.scale.set(isFemale ? 1.24 : 1.32, 0.52, 0.86);
  shoulderBridge.position.set(0, 0.855, 0);
  shoulderBridge.castShadow = true;

  bodyGroup.add(pelvisBridge, pelvisRoundCap, waistBand, neckConnector, shoulderBridge);

  // Hip socket ball-joints + upper thigh connectors inside LeftLeg & RightLeg so leg swing never detaches
  const socketR = isFemale ? 0.1 : 0.118;
  [leftLeg, rightLeg].forEach((leg) => {
    const hipSocket = new THREE.Mesh(new THREE.SphereGeometry(socketR, 12, 10), hipMat);
    hipSocket.name = 'HipSocketCap';
    hipSocket.scale.set(1.0, 1.08, 1.02);
    hipSocket.position.set(0, 0.025, 0);
    hipSocket.castShadow = true;

    const upperThigh = new THREE.Mesh(new THREE.CylinderGeometry(socketR * 0.94, socketR * 0.88, 0.15, 10), hipMat);
    upperThigh.name = 'UpperThighJoin';
    upperThigh.position.set(0, -0.055, 0);
    upperThigh.castShadow = true;

    leg.add(hipSocket, upperThigh);
  });

  // Seamless shoulder socket caps seated directly into the shoulder bridge
  [leftArm, rightArm].forEach((arm, idx) => {
    const shoulderCap = new THREE.Mesh(new THREE.SphereGeometry(isFemale ? 0.084 : 0.104, 10, 8), sleeveMat);
    shoulderCap.name = 'ShoulderCap';
    shoulderCap.position.set(idx === 0 ? 0.015 : -0.015, 0.01, 0);
    arm.add(shoulderCap);
  });

  // Attach procedural 3D facial expression meshes (brows, expressive mouth, blush, eyelids & living eye pupils) to HeadGroup
  const browMat = getStdMat(hairHex, 0.85, 0.02);
  const mouthMat = getStdMat('#7f1d1d', 0.65, 0.02);
  const eyelidMat = getStdMat(resolvedSkin, 0.75, 0.02);
  const pupilMat = getStdMat('#0f172a', 0.25, 0.15);
  const blushMat = new THREE.MeshBasicMaterial({
    color: '#fb7185',
    transparent: true,
    opacity: 0.0,
    depthWrite: false,
  });
  const leftBrow = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.022, 0.018), browMat);
  leftBrow.position.set(-0.1, 0.168, 0.342);
  const rightBrow = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.022, 0.018), browMat);
  rightBrow.position.set(0.1, 0.168, 0.342);
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.085, 0.022, 0.018), mouthMat);
  mouth.position.set(0, -0.058, 0.342);
  const blushLeft = new THREE.Mesh(new THREE.CircleGeometry(0.048, 10), blushMat);
  blushLeft.position.set(-0.175, -0.008, 0.324);
  blushLeft.rotation.y = -0.35;
  const blushRight = new THREE.Mesh(new THREE.CircleGeometry(0.048, 10), blushMat);
  blushRight.position.set(0.175, -0.008, 0.324);
  blushRight.rotation.y = 0.35;

  // Eyelids for automatic natural blinking (scaled vertically to close over eyes)
  const leftEyelid = new THREE.Mesh(new THREE.BoxGeometry(0.105, 0.095, 0.024), eyelidMat);
  leftEyelid.position.set(-0.1, 0.118, 0.348);
  leftEyelid.scale.y = 0.04;
  const rightEyelid = new THREE.Mesh(new THREE.BoxGeometry(0.105, 0.095, 0.024), eyelidMat);
  rightEyelid.position.set(0.1, 0.118, 0.348);
  rightEyelid.scale.y = 0.04;

  // Subtle glossy eye pupils for natural saccades & gaze tracking
  const leftPupil = new THREE.Mesh(new THREE.SphereGeometry(0.022, 8, 8), pupilMat);
  leftPupil.position.set(-0.1, 0.082, 0.343);
  const rightPupil = new THREE.Mesh(new THREE.SphereGeometry(0.022, 8, 8), pupilMat);
  rightPupil.position.set(0.1, 0.082, 0.343);

  headGroup.add(leftBrow, rightBrow, mouth, blushLeft, blushRight, leftEyelid, rightEyelid, leftPupil, rightPupil);

  const faceRig: ChibiFaceRig = {
    leftBrow,
    rightBrow,
    mouth,
    blushLeft,
    blushRight,
    leftEyelid,
    rightEyelid,
    leftPupil,
    rightPupil,
    blinkSeed: Math.random() * 100,
  };

  // Preserve original GLB hip-pivot height (0.44m) so leg IK never drags legs underground!
  leftLeg.visible = true;
  rightLeg.visible = true;
  const baseLeftLegY = leftLeg.position.y > 0.05 ? leftLeg.position.y : 0.44;
  const baseRightLegY = rightLeg.position.y > 0.05 ? rightLeg.position.y : 0.44;
  leftLeg.position.y = baseLeftLegY;
  rightLeg.position.y = baseRightLegY;

  return {
    root,
    bodyGroup,
    headGroup,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    baseLeftLegY,
    baseRightLegY,
    toolMount,
    contactShadow,
    faceRig,
  };
}

/**
 * Updates 3D facial expression meshes (brows, mouth, rosy cheeks) based on emotion & speech state.
 */
export function applyFacialExpression(
  rig: ChibiRig,
  emotion: NpcEmotion = 'neutral',
  isTalking = false,
  time = 0,
  isSleeping = false,
  eyeLookYaw = 0,
  eyeLookPitch = 0
) {
  const f = rig.faceRig;
  if (!f) return;

  let browLY = 0.168;
  let browRY = 0.168;
  let browLZ = 0;
  let browRZ = 0;
  let mouthSX = 1.0;
  let mouthSY = 1.0;
  let mouthY = -0.058;
  let blushAlpha = 0.0;

  if (emotion === 'happy') {
    browLY = 0.182;
    browRY = 0.182;
    browLZ = 0.14;
    browRZ = -0.14;
    mouthSX = 1.35;
    mouthSY = 1.15;
    mouthY = -0.052;
    blushAlpha = 0.38;
  } else if (emotion === 'excited') {
    browLY = 0.194;
    browRY = 0.194;
    browLZ = 0.2;
    browRZ = -0.2;
    mouthSX = 1.42;
    mouthSY = 2.15;
    mouthY = -0.056;
    blushAlpha = 0.52;
  } else if (emotion === 'tired') {
    browLY = 0.152;
    browRY = 0.152;
    browLZ = -0.16;
    browRZ = 0.16;
    mouthSX = 0.78;
    mouthSY = 1.55 + Math.max(0, Math.sin(time * 1.8)) * 0.7;
    mouthY = -0.064;
    blushAlpha = 0.0;
  } else if (emotion === 'sad') {
    browLY = 0.16;
    browRY = 0.16;
    browLZ = -0.3;
    browRZ = 0.3;
    mouthSX = 0.85;
    mouthSY = 0.75;
    mouthY = -0.068;
    blushAlpha = 0.08;
  } else if (emotion === 'angry') {
    browLY = 0.15;
    browRY = 0.15;
    browLZ = 0.36;
    browRZ = -0.36;
    mouthSX = 1.15;
    mouthSY = 0.9;
    mouthY = -0.062;
    blushAlpha = 0.22;
  } else if (emotion === 'nervous') {
    browLY = 0.186;
    browRY = 0.172;
    browLZ = -0.24;
    browRZ = 0.24;
    mouthSX = 0.72;
    mouthSY = 1.15;
    mouthY = -0.06;
    blushAlpha = 0.45;
  }

  if (isTalking) {
    const talkPulse = Math.abs(Math.sin(time * 13.5)) * 0.75 + Math.abs(Math.sin(time * 22.0)) * 0.25;
    mouthSY = Math.max(mouthSY, 1.0 + talkPulse * 1.45);
    mouthSX *= 0.94 + talkPulse * 0.2;
  }

  f.leftBrow.position.y = browLY;
  f.rightBrow.position.y = browRY;
  f.leftBrow.rotation.z = browLZ;
  f.rightBrow.rotation.z = browRZ;
  f.mouth.position.y = mouthY;
  f.mouth.scale.set(mouthSX, mouthSY, 1);

  // Automatic natural eye blinking (every ~3.8s, brief 140ms smooth blink; closed when sleeping)
  let blinkClosed = 0;
  if (isSleeping) {
    blinkClosed = 1.0;
  } else {
    const cycle = (time + f.blinkSeed) % 4.1;
    if (cycle < 0.15) {
      blinkClosed = Math.sin((cycle / 0.15) * Math.PI);
    } else if (emotion === 'tired') {
      blinkClosed = 0.38;
    }
  }
  const lidScaleY = 0.04 + blinkClosed * 0.98;
  const lidPosY = 0.122 - blinkClosed * 0.04;
  f.leftEyelid.scale.y = lidScaleY;
  f.rightEyelid.scale.y = lidScaleY;
  f.leftEyelid.position.y = lidPosY;
  f.rightEyelid.position.y = lidPosY;

  // Natural eye movement (subtle saccades + gaze toward conversation partner)
  if (f.leftPupil && f.rightPupil) {
    const saccadeX = Math.sin(time * 0.85 + f.blinkSeed) * 0.012 + Math.sin(time * 2.3 + f.blinkSeed) * 0.004;
    const saccadeY = Math.cos(time * 0.62 + f.blinkSeed) * 0.007;
    const gazeX = THREE.MathUtils.clamp(eyeLookYaw * 0.025 + saccadeX, -0.024, 0.024);
    const gazeY = THREE.MathUtils.clamp(-eyeLookPitch * 0.018 + saccadeY, -0.015, 0.015);
    f.leftPupil.position.set(-0.1 + gazeX, 0.082 + gazeY, 0.343);
    f.rightPupil.position.set(0.1 + gazeX, 0.082 + gazeY, 0.343);
    const showPupils = blinkClosed < 0.72;
    f.leftPupil.visible = showPupils;
    f.rightPupil.visible = showPupils;
  }

  const bMat = f.blushLeft.material as THREE.MeshBasicMaterial;
  if (bMat) bMat.opacity = blushAlpha;
}

/**
 * Natural Character Locomotion, Motion Matching, Root Motion, Procedural Animation & Analytical IK Solver.
 */
export function animateChibiRig(
  rig: ChibiRig,
  state: 'idle' | 'walk' | 'run' | 'work' | 'talk' | 'eat' | 'sleep' | 'festival' | 'jump' | 'swim',
  time: number,
  dt: number,
  idlePose: NpcIdlePose = 'relaxed',
  idleSpeed = 1.0,
  loco?: LocomotionInput
) {
  // Smooth organic animation blending damping (prevents snappy transitions between Idle/Walk/Run/Stop/Jump/Landing)
  const dampFactor = 1 - Math.exp(-9.5 * dt);
  const fastDamp = 1 - Math.exp(-15.0 * dt);

  // Ground-adaptive contact shadow scaling & opacity
  const heightAboveGround = loco ? Math.max(0, loco.groundHeight) : 0;
  if (rig.contactShadow) {
    const shadowScale = Math.max(0.42, 1 - heightAboveGround * 0.24);
    rig.contactShadow.scale.setScalar(shadowScale);
    rig.contactShadow.position.y = Math.max(0.025, 0.025 - heightAboveGround);
    const mat = rig.contactShadow.material as THREE.MeshBasicMaterial;
    if (mat) {
      mat.opacity = Math.max(0.18, 1 - heightAboveGround * 0.34);
    }
  }

  // Continuous natural breathing + weighted landing squash & stretch recovery
  const breathCycle = Math.sin(time * (state === 'run' ? 4.4 : 2.1) + (rig.faceRig?.blinkSeed ?? 0));
  const breathScaleY = state === 'idle' || state === 'talk' || state === 'sleep' ? breathCycle * 0.018 : breathCycle * 0.01;
  const breathScaleXZ = -breathScaleY * 0.45;
  const squash = loco ? THREE.MathUtils.clamp(loco.landSquash, 0, 1) : 0;
  const targetScaleY = 1 + breathScaleY - squash * 0.16 + (state === 'jump' && loco && loco.verticalVel > 2.0 ? 0.06 : 0);
  const targetScaleXZ = 1 + breathScaleXZ + squash * 0.09 - (state === 'jump' && loco && loco.verticalVel > 2.0 ? 0.03 : 0);
  rig.bodyGroup.scale.x = THREE.MathUtils.lerp(rig.bodyGroup.scale.x, targetScaleXZ, fastDamp);
  rig.bodyGroup.scale.y = THREE.MathUtils.lerp(rig.bodyGroup.scale.y, targetScaleY, fastDamp);
  rig.bodyGroup.scale.z = THREE.MathUtils.lerp(rig.bodyGroup.scale.z, targetScaleXZ, fastDamp);

  // Corner banking & procedural head look-ahead into turns
  const bankRoll = loco ? THREE.MathUtils.clamp(-loco.turnRate * 0.05, -0.18, 0.18) : 0;
  const headLookYaw = loco ? THREE.MathUtils.clamp(loco.turnRate * 0.08, -0.35, 0.35) : 0;

  if (state === 'jump') {
    // Motion-matched jump phases: Ascend -> Apex -> Descend
    const vy = loco ? loco.verticalVel : 0;
    const isAscending = vy > 1.4;
    const isFalling = vy < -1.4;
    const legL = isAscending ? 0.56 : isFalling ? 0.32 : 0.42;
    const legR = isAscending ? -0.44 : isFalling ? -0.18 : -0.3;
    const armLift = isAscending ? -1.85 : isFalling ? -2.25 : -1.55;
    const torsoTilt = isAscending ? -0.1 : isFalling ? 0.12 : 0.02;

    rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, legL, dampFactor);
    rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, legR, dampFactor);
    rig.leftLeg.position.y = THREE.MathUtils.lerp(rig.leftLeg.position.y, rig.baseLeftLegY + (isAscending ? 0.05 : 0.02), dampFactor);
    rig.rightLeg.position.y = THREE.MathUtils.lerp(rig.rightLeg.position.y, rig.baseRightLegY + (isFalling ? 0.04 : 0.01), dampFactor);
    rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, armLift, dampFactor);
    rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, armLift, dampFactor);
    rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, isFalling ? 0.42 : 0.14, dampFactor);
    rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, isFalling ? -0.42 : -0.14, dampFactor);
    rig.bodyGroup.position.y = THREE.MathUtils.lerp(rig.bodyGroup.position.y, 0.04, dampFactor);
    rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, torsoTilt, dampFactor);
    rig.bodyGroup.rotation.z = THREE.MathUtils.lerp(rig.bodyGroup.rotation.z, bankRoll * 0.6, dampFactor);
    rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, isFalling ? 0.12 : -0.08, dampFactor);
    rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, headLookYaw, dampFactor);
  } else if (state === 'walk' || state === 'run') {
    const isRun = state === 'run';
    // Motion Matching: continuous speed blend (0 = slow step, 0.5 = walk, 1.0 = sprint/dash)
    const speedRatio = loco
      ? THREE.MathUtils.clamp(loco.horizontalSpeed / Math.max(1, loco.maxSpeed), 0.12, 1.15)
      : isRun
        ? 1.0
        : 0.55;
    const dashBoost = loco ? loco.dashWeight : 0;

    // Root Motion: drive gait phase directly from physical world displacement when available
    const phase = loco ? loco.gaitPhase : time * (isRun ? 13.5 : 8.2);
    const swingAmp = THREE.MathUtils.lerp(0.32, 0.92, Math.min(1, speedRatio)) + dashBoost * 0.18;
    const sinP = Math.sin(phase);
    const cosP = Math.cos(phase);

    // Analytical 2-Stage Leg IK: stance foot plants firmly while swing foot lifts naturally to clear terrain
    const leftLiftIk = Math.max(0, cosP) * (0.045 + speedRatio * 0.04);
    const rightLiftIk = Math.max(0, -cosP) * (0.045 + speedRatio * 0.04);
    // Hip bob synchronized with double-support stance phase + landing squash compensation
    const hipBob = Math.abs(sinP) * (0.032 + speedRatio * 0.055) - squash * 0.07;

    rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, sinP * swingAmp, fastDamp);
    rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, -sinP * swingAmp, fastDamp);
    rig.leftLeg.position.y = THREE.MathUtils.lerp(rig.leftLeg.position.y, rig.baseLeftLegY + leftLiftIk, fastDamp);
    rig.rightLeg.position.y = THREE.MathUtils.lerp(rig.rightLeg.position.y, rig.baseRightLegY + rightLiftIk, fastDamp);

    // Counter-swing arms + slight forward elbow drive at higher sprint speeds
    const armAmp = swingAmp * (0.82 + speedRatio * 0.22);
    rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -sinP * armAmp - dashBoost * 0.4, fastDamp);
    rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, sinP * armAmp - dashBoost * 0.4, fastDamp);
    rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.05 + speedRatio * 0.06, dampFactor);
    rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, -(0.05 + speedRatio * 0.06), dampFactor);

    // Procedural forward momentum lean + turn banking + upper-body counter-twist
    const forwardLean = THREE.MathUtils.lerp(0.03, 0.19, Math.min(1, speedRatio)) + dashBoost * 0.16;
    rig.bodyGroup.position.y = THREE.MathUtils.lerp(rig.bodyGroup.position.y, hipBob, fastDamp);
    rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, forwardLean, dampFactor);
    rig.bodyGroup.rotation.z = THREE.MathUtils.lerp(rig.bodyGroup.rotation.z, bankRoll, dampFactor);
    rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, sinP * (0.04 + speedRatio * 0.04), dampFactor);

    // Head stabilizes horizon while looking into turn direction
    rig.headGroup.rotation.z = THREE.MathUtils.lerp(rig.headGroup.rotation.z, -bankRoll * 0.45 + sinP * 0.035, dampFactor);
    rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, -forwardLean * 0.45, dampFactor);
    rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, headLookYaw, dampFactor);
  } else if (state === 'swim') {
    const paddle = Math.sin(time * 7.5);
    rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -1.25 + paddle * 0.5, dampFactor);
    rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -1.25 - paddle * 0.5, dampFactor);
    rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, Math.sin(time * 8) * 0.32, dampFactor);
    rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, -Math.sin(time * 8) * 0.32, dampFactor);
    rig.leftLeg.position.y = THREE.MathUtils.lerp(rig.leftLeg.position.y, rig.baseLeftLegY, dampFactor);
    rig.rightLeg.position.y = THREE.MathUtils.lerp(rig.rightLeg.position.y, rig.baseRightLegY, dampFactor);
    rig.bodyGroup.position.y = 0.04 + Math.sin(time * 3.2) * 0.025;
    rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, 0.18, dampFactor);
    rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, 0, dampFactor);
    rig.bodyGroup.rotation.z = THREE.MathUtils.lerp(rig.bodyGroup.rotation.z, bankRoll * 0.5, dampFactor);
    rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, -0.1, dampFactor);
  } else if (state === 'work') {
    const reachOffset = loco?.handIkReach ?? 0;
    const style = loco?.workStyle ?? 'chop';
    const prog = THREE.MathUtils.clamp(loco?.workProgress ?? ((time * 2.4) % 1), 0, 1);

    // Grounded wide athletic stance leg IK for stability during tool work
    rig.leftLeg.position.y = THREE.MathUtils.lerp(rig.leftLeg.position.y, rig.baseLeftLegY, dampFactor);
    rig.rightLeg.position.y = THREE.MathUtils.lerp(rig.rightLeg.position.y, rig.baseRightLegY, dampFactor);

    if (style === 'fish_wait') {
      // Relaxed fishing stance holding rod gently out over the water with subtle breathing sway
      const sway = Math.sin(time * 1.9) * 0.04;
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -1.05 + sway, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, 0.1, dampFactor);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.82 + sway * 0.7, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, -0.18, dampFactor);
      rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, -0.06, dampFactor);
      rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, 0.08, dampFactor);
      rig.bodyGroup.position.y = THREE.MathUtils.lerp(rig.bodyGroup.position.y, Math.sin(time * 1.6) * 0.014, dampFactor);
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, 0.06, dampFactor);
      rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, 0.04, dampFactor);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.14, dampFactor);
    } else if (style === 'fish_cast') {
      // Crisp overhead cast arc: pull back (0..0.42) then whip forward (0.42..1.0)
      const castArc = prog < 0.42 ? -2.45 * (prog / 0.42) : THREE.MathUtils.lerp(-2.45, -0.95, (prog - 0.42) / 0.58);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, castArc, fastDamp);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, -0.08, fastDamp);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, castArc * 0.65, fastDamp);
      rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, -0.14, dampFactor);
      rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, 0.18, dampFactor);
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, prog < 0.42 ? -0.14 : 0.16, fastDamp);
      rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, prog < 0.42 ? -0.22 : 0.15, fastDamp);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, -0.05, dampFactor);
    } else if (style === 'fish_reel') {
      // Intense fish-fighting tug with rapid rod pull-back & braced lean
      const tug = Math.sin(time * 18) * 0.28;
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -1.62 + tug, fastDamp);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, 0.14 + tug * 0.25, fastDamp);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -1.25 - tug * 0.6, fastDamp);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, -0.22, fastDamp);
      rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, -0.24, dampFactor);
      rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, 0.26, dampFactor);
      rig.bodyGroup.position.y = THREE.MathUtils.lerp(rig.bodyGroup.position.y, -0.04, fastDamp);
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, -0.16 + tug * 0.18, fastDamp);
      rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, Math.sin(time * 9) * 0.14, fastDamp);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.1, dampFactor);
    } else if (style === 'water') {
      // Gentle pouring lean: lift watering can forward & tilt wrist
      const pour = Math.sin(prog * Math.PI);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -0.85 - pour * 0.45, fastDamp);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, 0.22 * pour, fastDamp);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.25, dampFactor);
      rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, -0.08, dampFactor);
      rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, 0.1, dampFactor);
      rig.bodyGroup.position.y = THREE.MathUtils.lerp(rig.bodyGroup.position.y, -0.03 * pour, fastDamp);
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, 0.18 * pour, fastDamp);
      rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, -0.1 * pour, fastDamp);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.24 * pour, dampFactor);
    } else if (style === 'dig') {
      // Two-phase hoe plunge: wind up high (0..0.38) -> sharp downward soil strike (0.38..0.72) -> scoop recover
      const armX =
        prog < 0.38
          ? THREE.MathUtils.lerp(-0.4, -2.35, prog / 0.38)
          : prog < 0.72
            ? THREE.MathUtils.lerp(-2.35, -0.35, (prog - 0.38) / 0.34)
            : THREE.MathUtils.lerp(-0.35, -0.75, (prog - 0.72) / 0.28);
      const torsoPitch = prog < 0.38 ? -0.12 : prog < 0.72 ? 0.34 : 0.14;
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, armX - reachOffset * 0.25, fastDamp);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, -0.08, dampFactor);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, armX * 0.72, fastDamp);
      rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, -0.18, dampFactor);
      rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, 0.22, dampFactor);
      rig.bodyGroup.position.y = THREE.MathUtils.lerp(rig.bodyGroup.position.y, prog > 0.38 && prog < 0.76 ? -0.06 : 0.02, fastDamp);
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, torsoPitch, fastDamp);
      rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, prog < 0.38 ? -0.18 : 0.12, fastDamp);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.26, dampFactor);
    } else if (style === 'sickle') {
      // Wide horizontal slash across waist with hip rotation
      const sweep = Math.sin(prog * Math.PI);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -1.05, fastDamp);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, THREE.MathUtils.lerp(-0.75, 0.65, prog), fastDamp);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.45, dampFactor);
      rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, -0.15, dampFactor);
      rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, 0.16, dampFactor);
      rig.bodyGroup.position.y = THREE.MathUtils.lerp(rig.bodyGroup.position.y, -0.04 * sweep, fastDamp);
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, 0.22 * sweep, fastDamp);
      rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, THREE.MathUtils.lerp(-0.48, 0.48, prog), fastDamp);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.2, dampFactor);
    } else if (style === 'gift') {
      // Warm two-handed present gesture forward
      const extend = Math.sin(prog * Math.PI);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -1.15 * extend - 0.3, fastDamp);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -1.05 * extend - 0.2, fastDamp);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, 0.18 * extend, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, -0.18 * extend, dampFactor);
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, 0.14 * extend, dampFactor);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.08 * extend, dampFactor);
    } else if (style === 'carry') {
      // Carrying heavy wood log / ore crate in front while walking or pausing
      const step = Math.sin(time * 7.2);
      const isMoving = (loco?.horizontalSpeed ?? 0) > 0.25;
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -1.18 + (isMoving ? step * 0.06 : 0), fastDamp);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -1.18 - (isMoving ? step * 0.06 : 0), fastDamp);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, 0.22, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, -0.22, dampFactor);
      rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, isMoving ? step * 0.52 : 0, fastDamp);
      rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, isMoving ? -step * 0.52 : 0, fastDamp);
      rig.bodyGroup.position.y = THREE.MathUtils.lerp(rig.bodyGroup.position.y, isMoving ? Math.abs(step) * 0.032 : 0, fastDamp);
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, 0.1, dampFactor);
      rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, 0, dampFactor);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.05, dampFactor);
    } else if (style === 'tidy') {
      // Shopkeeper organizing & wiping shelves
      const wipe = Math.sin(time * 4.4);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -1.05 + Math.cos(time * 4.4) * 0.18, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, -0.15 + wipe * 0.28, dampFactor);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.68, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.14, dampFactor);
      rig.bodyGroup.position.y = THREE.MathUtils.lerp(rig.bodyGroup.position.y, Math.sin(time * 2.2) * 0.018, dampFactor);
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, 0.08, dampFactor);
      rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, wipe * 0.14, dampFactor);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.14, dampFactor);
      rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, wipe * 0.18, dampFactor);
    } else if (style === 'hammer') {
      // Heavy overhead two-handed mining/forging smash with shoulder recoil
      const isWindup = prog < 0.42;
      const isStrike = prog >= 0.42 && prog < 0.7;
      const armX = isWindup
        ? THREE.MathUtils.lerp(-0.4, -2.85, prog / 0.42)
        : isStrike
          ? THREE.MathUtils.lerp(-2.85, -0.15, (prog - 0.42) / 0.28)
          : THREE.MathUtils.lerp(-0.15, -0.58, (prog - 0.7) / 0.3);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, armX - reachOffset * 0.3, fastDamp);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, armX * 0.92, fastDamp);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, 0.12, fastDamp);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, -0.12, fastDamp);
      rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, -0.2, dampFactor);
      rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, 0.24, dampFactor);
      rig.bodyGroup.position.y = THREE.MathUtils.lerp(rig.bodyGroup.position.y, isStrike ? -0.075 : 0.03, fastDamp);
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, isWindup ? -0.2 : isStrike ? 0.34 : 0.1, fastDamp);
      rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, isWindup ? -0.18 : 0.14, fastDamp);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.2, dampFactor);
    } else {
      // 'chop': explosive diagonal axe wind-up -> impact snap -> recoil follow-through!
      const isWindup = prog < 0.35;
      const isImpact = prog >= 0.35 && prog < 0.68;
      const armX = isWindup
        ? THREE.MathUtils.lerp(-0.5, -2.65, prog / 0.35)
        : isImpact
          ? THREE.MathUtils.lerp(-2.65, -0.25, (prog - 0.35) / 0.33)
          : THREE.MathUtils.lerp(-0.25, -0.68, (prog - 0.68) / 0.32);
      const torsoYaw = isWindup ? -0.36 : isImpact ? 0.34 : 0.08;
      const torsoPitch = isWindup ? -0.14 : isImpact ? 0.26 : 0.08;
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, armX - reachOffset * 0.35, fastDamp);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, isWindup ? -0.28 : 0.16, fastDamp);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, armX * 0.68, fastDamp);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.18, dampFactor);
      rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, -0.16, dampFactor);
      rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, 0.2, dampFactor);
      rig.bodyGroup.position.y = THREE.MathUtils.lerp(rig.bodyGroup.position.y, isImpact ? -0.055 : 0.025, fastDamp);
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, torsoPitch, fastDamp);
      rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, torsoYaw, fastDamp);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.16, dampFactor);
    }
  } else if (state === 'talk') {
    rig.rightArm.rotation.x = -0.45 + Math.sin(time * 6) * 0.25;
    rig.leftArm.rotation.x = -0.25 + Math.cos(time * 5) * 0.15;
    rig.headGroup.rotation.y = Math.sin(time * 3) * 0.12;
    rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, 0, dampFactor);
    rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, 0, dampFactor);
    rig.leftLeg.position.y = THREE.MathUtils.lerp(rig.leftLeg.position.y, rig.baseLeftLegY, dampFactor);
    rig.rightLeg.position.y = THREE.MathUtils.lerp(rig.rightLeg.position.y, rig.baseRightLegY, dampFactor);
  } else if (state === 'festival') {
    const phase = rig.root.position.x * 0.4 + rig.root.position.z * 0.3;
    rig.bodyGroup.position.y = Math.abs(Math.sin(time * 5.4 + phase)) * 0.12;
    rig.leftArm.rotation.x = -2.15 + Math.sin(time * 5.4 + phase) * 0.38;
    rig.rightArm.rotation.x = -2.15 - Math.sin(time * 5.4 + phase) * 0.38;
    rig.headGroup.rotation.z = Math.sin(time * 2.7 + phase) * 0.1;
    rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, 0, dampFactor);
    rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, 0, dampFactor);
    rig.leftLeg.position.y = THREE.MathUtils.lerp(rig.leftLeg.position.y, rig.baseLeftLegY, dampFactor);
    rig.rightLeg.position.y = THREE.MathUtils.lerp(rig.rightLeg.position.y, rig.baseRightLegY, dampFactor);
  } else {
    // Grounded Idle with Leg IK foot-planting + landing squash recovery
    rig.leftLeg.position.y = THREE.MathUtils.lerp(rig.leftLeg.position.y, rig.baseLeftLegY, dampFactor);
    rig.rightLeg.position.y = THREE.MathUtils.lerp(rig.rightLeg.position.y, rig.baseRightLegY, dampFactor);
    rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, 0, dampFactor);
    // 6 Distinct Varied Idle Poses for expressive NPCs & player!
    const t = time * Math.max(0.25, idleSpeed);
    const seed = rig.root.position.x * 0.31 + rig.root.position.z * 0.19;
    rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, 0, dampFactor);
    rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, 0, dampFactor);

    if (idlePose === 'confident') {
      // Hands proudly angled out at hips, tall chest, slow proud head scan
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.18, dampFactor);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -0.18, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.38 + Math.sin(t * 1.4 + seed) * 0.04, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, -0.38 - Math.sin(t * 1.4 + seed) * 0.04, dampFactor);
      rig.bodyGroup.position.y = 0.02 + Math.sin(t * 1.8 + seed) * 0.018;
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, -0.04, dampFactor);
      rig.bodyGroup.rotation.z = THREE.MathUtils.lerp(rig.bodyGroup.rotation.z, Math.sin(t * 0.7 + seed) * 0.02, dampFactor);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, -0.05, dampFactor);
      rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, Math.sin(t * 0.55 + seed) * 0.2, dampFactor * 0.4);
      rig.headGroup.rotation.z = THREE.MathUtils.lerp(rig.headGroup.rotation.z, 0, dampFactor);
    } else if (idlePose === 'thoughtful') {
      // Right hand raised near chin, gentle head tilt & pondering nod
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, 0.12, dampFactor);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -0.92 + Math.sin(t * 1.1 + seed) * 0.06, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.06, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, 0.18, dampFactor);
      rig.bodyGroup.position.y = Math.sin(t * 1.3 + seed) * 0.012;
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, 0.03, dampFactor);
      rig.bodyGroup.rotation.z = THREE.MathUtils.lerp(rig.bodyGroup.rotation.z, -0.03, dampFactor);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.08 + Math.sin(t * 0.9 + seed) * 0.05, dampFactor);
      rig.headGroup.rotation.z = THREE.MathUtils.lerp(rig.headGroup.rotation.z, 0.12, dampFactor);
      rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, Math.sin(t * 0.4 + seed) * 0.14, dampFactor * 0.35);
    } else if (idlePose === 'cheerful') {
      // Happy rhythm bounce with periodic friendly wave
      const waveBurst = Math.sin(t * 0.9 + seed) > 0.55;
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.1 + Math.sin(t * 2.6 + seed) * 0.12, dampFactor);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(
        rig.rightArm.rotation.x,
        waveBurst ? -2.05 + Math.sin(t * 9.5) * 0.22 : -0.15 - Math.sin(t * 2.6 + seed) * 0.12,
        dampFactor
      );
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.14, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, waveBurst ? -0.35 : -0.14, dampFactor);
      rig.bodyGroup.position.y = Math.abs(Math.sin(t * 2.6 + seed)) * 0.042;
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, 0, dampFactor);
      rig.bodyGroup.rotation.z = THREE.MathUtils.lerp(rig.bodyGroup.rotation.z, Math.sin(t * 1.3 + seed) * 0.05, dampFactor);
      rig.headGroup.rotation.z = THREE.MathUtils.lerp(rig.headGroup.rotation.z, Math.sin(t * 2.0 + seed) * 0.09, dampFactor);
      rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, Math.sin(t * 0.8 + seed) * 0.18, dampFactor * 0.45);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, -0.03, dampFactor);
    } else if (idlePose === 'energetic') {
      // Peppy boxer/stretching stance, brisk rhythmic toe-bounce
      const hop = Math.abs(Math.sin(t * 3.8 + seed));
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.58 + Math.sin(t * 3.8 + seed) * 0.18, dampFactor);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -0.58 - Math.sin(t * 3.8 + seed) * 0.18, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.22, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, -0.22, dampFactor);
      rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, Math.sin(t * 3.8 + seed) * 0.12, dampFactor);
      rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, -Math.sin(t * 3.8 + seed) * 0.12, dampFactor);
      rig.bodyGroup.position.y = hop * 0.055;
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, 0.06, dampFactor);
      rig.bodyGroup.rotation.z = THREE.MathUtils.lerp(rig.bodyGroup.rotation.z, Math.sin(t * 1.9 + seed) * 0.05, dampFactor);
      rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, Math.sin(t * 1.4 + seed) * 0.22, dampFactor * 0.5);
      rig.headGroup.rotation.z = THREE.MathUtils.lerp(rig.headGroup.rotation.z, 0, dampFactor);
    } else if (idlePose === 'scholar') {
      // Both forearms cradled forward as if holding a ledger/book, gazing down & scanning lines
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.78, dampFactor);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -0.74 + Math.sin(t * 1.4 + seed) * 0.04, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, -0.16, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, 0.16, dampFactor);
      rig.bodyGroup.position.y = Math.sin(t * 1.2 + seed) * 0.012;
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, 0.05, dampFactor);
      rig.bodyGroup.rotation.z = THREE.MathUtils.lerp(rig.bodyGroup.rotation.z, 0, dampFactor);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.2 + Math.sin(t * 0.9 + seed) * 0.03, dampFactor);
      rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, Math.sin(t * 1.1 + seed) * 0.14, dampFactor * 0.4);
      rig.headGroup.rotation.z = THREE.MathUtils.lerp(rig.headGroup.rotation.z, 0.03, dampFactor);
    } else if (idlePose === 'wave') {
      // Friendly raised right-hand wave
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.1, dampFactor);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -2.25, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.12, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, -0.35 + Math.sin(t * 7.5 + seed) * 0.28, dampFactor);
      rig.bodyGroup.position.y = Math.abs(Math.sin(t * 2.2 + seed)) * 0.03;
      rig.headGroup.rotation.z = THREE.MathUtils.lerp(rig.headGroup.rotation.z, Math.sin(t * 2.5 + seed) * 0.08, dampFactor);
      rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, Math.sin(t * 0.9 + seed) * 0.15, dampFactor * 0.4);
    } else if (idlePose === 'stretch') {
      // Relaxing overhead stretch
      const stretchCycle = (Math.sin(t * 1.2 + seed) + 1) * 0.5;
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -2.5 * stretchCycle - 0.15, dampFactor);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -2.5 * stretchCycle - 0.15, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.35 * stretchCycle, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, -0.35 * stretchCycle, dampFactor);
      rig.bodyGroup.position.y = stretchCycle * 0.04;
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, -0.07 * stretchCycle, dampFactor);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, -0.12 * stretchCycle, dampFactor);
    } else if (idlePose === 'ponder') {
      // Curious looking around & gently tapping foot
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.45, dampFactor);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -0.82, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, -0.18, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, 0.24, dampFactor);
      rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, Math.sin(t * 0.85 + seed) * 0.38, dampFactor * 0.45);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.05 + Math.cos(t * 0.6 + seed) * 0.05, dampFactor);
      rig.bodyGroup.position.y = Math.sin(t * 1.4 + seed) * 0.015;
    } else if (idlePose === 'chat') {
      // Expressive conversational gestures
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.45 + Math.sin(t * 4.2 + seed) * 0.22, dampFactor);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -0.55 + Math.cos(t * 4.8 + seed) * 0.26, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.18, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, -0.18, dampFactor);
      rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, Math.sin(t * 2.4 + seed) * 0.16, dampFactor * 0.5);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, Math.sin(t * 3.1 + seed) * 0.08, dampFactor * 0.5);
      rig.bodyGroup.position.y = Math.abs(Math.sin(t * 2.0 + seed)) * 0.022;
    } else if (idlePose === 'yawn') {
      // Sleepy hand raised to mouth with slow tired exhale
      const yCycle = (Math.sin(t * 1.1 + seed) + 1) * 0.5;
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -1.55 * yCycle - 0.15, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, 0.34 * yCycle, dampFactor);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, 0.08, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.05, dampFactor);
      rig.bodyGroup.position.y = -0.015 * yCycle;
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, -0.06 * yCycle, dampFactor);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, -0.14 * yCycle, dampFactor);
      rig.headGroup.rotation.z = THREE.MathUtils.lerp(rig.headGroup.rotation.z, 0.08 * yCycle, dampFactor);
    } else if (idlePose === 'look_around') {
      // Curious scenic head turn left-to-right taking in the village
      const scan = Math.sin(t * 0.95 + seed);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.12, dampFactor);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -0.12, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.1, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, -0.1, dampFactor);
      rig.bodyGroup.position.y = Math.sin(t * 1.4 + seed) * 0.014;
      rig.bodyGroup.rotation.y = THREE.MathUtils.lerp(rig.bodyGroup.rotation.y, scan * 0.18, dampFactor * 0.6);
      rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, scan * 0.52, dampFactor * 0.65);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, -0.06 + Math.cos(t * 0.7 + seed) * 0.06, dampFactor);
    } else if (idlePose === 'sit') {
      // Relaxed seated posture on park bench with swinging feet
      rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, -1.25 + Math.sin(t * 1.6 + seed) * 0.08, dampFactor);
      rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, -1.25 - Math.sin(t * 1.6 + seed) * 0.08, dampFactor);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.45, dampFactor);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -0.45, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.12, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, -0.12, dampFactor);
      rig.bodyGroup.position.y = THREE.MathUtils.lerp(rig.bodyGroup.position.y, -0.24, dampFactor);
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, -0.05, dampFactor);
      rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, Math.sin(t * 0.65 + seed) * 0.25, dampFactor * 0.45);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.04, dampFactor);
    } else if (idlePose === 'whistle') {
      // Jaunty whistling rhythm with gentle head bob & swaying shoulders
      const beat = Math.sin(t * 3.4 + seed);
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.22 + beat * 0.1, dampFactor);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -0.22 - beat * 0.1, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.22, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, -0.22, dampFactor);
      rig.bodyGroup.position.y = Math.abs(beat) * 0.025;
      rig.bodyGroup.rotation.z = THREE.MathUtils.lerp(rig.bodyGroup.rotation.z, beat * 0.06, dampFactor);
      rig.headGroup.rotation.z = THREE.MathUtils.lerp(rig.headGroup.rotation.z, beat * 0.12, dampFactor);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, -0.08 + Math.abs(beat) * 0.06, dampFactor);
    } else {
      // 'relaxed' default: gentle breathing, subtle weight shift, natural head glance
      const breath = Math.sin(t * 1.65) * 0.018;
      const weight = Math.sin(t * 0.72 + seed) * 0.035;
      const glance = Math.sin(t * 0.43 + rig.root.position.z) * 0.12;
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, 0.035 + Math.sin(t * 1.3) * 0.045, dampFactor);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -0.035 - Math.sin(t * 1.3 + 0.7) * 0.045, dampFactor);
      rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArm.rotation.z, 0.025 + weight, dampFactor);
      rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArm.rotation.z, -0.025 - weight, dampFactor);
      rig.bodyGroup.position.y = breath;
      rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(rig.bodyGroup.rotation.x, Math.sin(t * 0.8) * 0.012, dampFactor);
      rig.bodyGroup.rotation.z = THREE.MathUtils.lerp(rig.bodyGroup.rotation.z, weight * 0.45, dampFactor);
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0, dampFactor);
      rig.headGroup.rotation.z = THREE.MathUtils.lerp(rig.headGroup.rotation.z, Math.sin(t * 0.6) * 0.025, dampFactor);
      rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, glance, dampFactor * 0.35);
    }
  }

  // Subtle environmental weather & time-of-day micro-reactions during idle (no unrealistic winter shivering)
  if (state === 'idle' && loco) {
    const w = loco.weather;
    if (w === 'HeavyRain' || w === 'Stormy') {
      // Gently fold arms closer against heavy rain/wind without unnatural body vibration
      rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.32, dampFactor * 0.45);
      rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -0.32, dampFactor * 0.45);
    } else if (typeof loco.hour === 'number' && (loco.hour >= 22 || loco.hour < 5) && idlePose === 'relaxed') {
      // Subtle late-night drowsy head droop
      rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.09 + Math.sin(time * 0.9) * 0.04, dampFactor * 0.5);
    }
  }

  // Sleep state posture (resting peacefully)
  if (state === 'sleep') {
    rig.bodyGroup.position.y = THREE.MathUtils.lerp(rig.bodyGroup.position.y, -0.2, dampFactor);
    rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, 0.24, dampFactor);
    rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -0.3, dampFactor);
    rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -0.3, dampFactor);
  }

  // Head Tracking & Eye Contact override (smoothly rotates head toward nearby player, NPC, or sound source)
  if (loco && typeof loco.headTargetYaw === 'number') {
    const clampedYaw = THREE.MathUtils.clamp(loco.headTargetYaw, -0.78, 0.78);
    rig.headGroup.rotation.y = THREE.MathUtils.lerp(rig.headGroup.rotation.y, clampedYaw, dampFactor * 0.85);
  }
  if (loco && typeof loco.headTargetPitch === 'number') {
    const clampedPitch = THREE.MathUtils.clamp(loco.headTargetPitch, -0.32, 0.32);
    rig.headGroup.rotation.x = THREE.MathUtils.lerp(rig.headGroup.rotation.x, clampedPitch, dampFactor * 0.85);
  }

  // Dynamic 3D Facial Expressions (brows, mouth, blush, auto-blinking eyelids & natural eye gaze)
  if (rig.faceRig) {
    applyFacialExpression(
      rig,
      loco?.emotion ?? (idlePose === 'yawn' || state === 'sleep' ? 'tired' : state === 'festival' ? 'excited' : 'neutral'),
      Boolean(loco?.isTalking || state === 'talk' || idlePose === 'chat'),
      time,
      state === 'sleep',
      loco?.headTargetYaw ?? 0,
      loco?.headTargetPitch ?? 0
    );
  }
}

const _rodVert = new THREE.Vector3();
const _rodMat = new THREE.Matrix4();

/**
 * Computes the exact physical tip vertex of the fishing rod GLB in local rod space
 * by scanning all mesh vertices and locating the farthest point from the handle grip (0,0,0).
 */
export function computeFishingRodTipLocal(rodGroup: THREE.Object3D): THREE.Vector3 | null {
  rodGroup.updateMatrixWorld(true);
  const invRoot = new THREE.Matrix4().copy(rodGroup.matrixWorld).invert();
  let bestDistSq = 0;
  let bestPoint: THREE.Vector3 | null = null;

  rodGroup.traverse((obj) => {
    if (!(obj as THREE.Mesh).isMesh) return;
    const mesh = obj as THREE.Mesh;
    const posAttr = mesh.geometry?.attributes?.position;
    if (!posAttr) return;
    _rodMat.multiplyMatrices(invRoot, mesh.matrixWorld);
    for (let i = 0; i < posAttr.count; i++) {
      _rodVert.fromBufferAttribute(posAttr, i).applyMatrix4(_rodMat);
      const distSq = _rodVert.lengthSq();
      // Prefer points farthest from grip along the rod shaft
      if (distSq > bestDistSq && (_rodVert.y > 0.1 || _rodVert.z > 0.1 || distSq > 0.35)) {
        bestDistSq = distSq;
        if (!bestPoint) bestPoint = new THREE.Vector3();
        bestPoint.copy(_rodVert);
      }
    }
  });

  return bestPoint;
}

export function createToolMesh(toolKind: ToolKind): THREE.Group {
  const mesh = glbAssets.clone(`/assets/glb/tools/tool_${toolKind}.glb`);
  if (toolKind === 'fishing_rod') {
    const tip = new THREE.Object3D();
    tip.name = 'RodTip';
    const computed = computeFishingRodTipLocal(mesh);
    if (computed) {
      tip.position.copy(computed);
      tip.userData.calibrated = true;
    } else {
      tip.position.set(0, 1.32, 0.28);
      tip.userData.calibrated = false;
    }
    mesh.add(tip);
  }
  return mesh;
}

/**
 * Builds a clearly visible 3D handheld mesh for EVERY inventory item (tools, seeds, crops, fish,
 * dishes, ores, materials, animal products, gifts, smartphone) so the player always carries what is equipped.
 */
export function createHeldItemMesh(itemId: string): THREE.Group | null {
  if (!itemId) return null;
  if (itemId.startsWith('tool_')) {
    const tk = itemId.replace('tool_', '') as ToolKind;
    return createToolMesh(tk);
  }

  const g = new THREE.Group();
  g.position.set(0, -0.02, 0.12);

  if (itemId.startsWith('seed_')) {
    // Charming cloth seed pouch with twine tie & leaf badge
    const pouch = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 8), getStdMat('#c7a06c', 0.9, 0.02));
    pouch.scale.set(0.95, 1.15, 0.85);
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.09, 0.08, 8), getStdMat('#b08652', 0.9, 0.02));
    neck.position.y = 0.14;
    const tie = new THREE.Mesh(new THREE.TorusGeometry(0.062, 0.014, 6, 10), getStdMat('#dc2626', 0.75, 0.05));
    tie.rotation.x = Math.PI / 2;
    tie.position.y = 0.12;
    const leaf = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.02), getStdMat('#22c55e', 0.78, 0.02));
    leaf.position.set(0, 0.01, 0.115);
    leaf.rotation.z = 0.45;
    g.add(pouch, neck, tie, leaf);
  } else if (itemId === 'valley_smartphone') {
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.19, 0.022), getStdMat('#1e293b', 0.35, 0.55));
    const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.092, 0.16), getStdMat('#38bdf8', 0.2, 0.1, '#0ea5e9', 0.5));
    screen.position.z = 0.013;
    g.add(body, screen);
  } else if (itemId.includes('fish') || itemId === 'river_trout' || itemId === 'golden_carp' || itemId === 'ocean_snapper' || itemId === 'crimson_tuna' || itemId === 'moon_jelly') {
    const fishHex = itemId.includes('gold') ? '#f59e0b' : itemId.includes('crimson') || itemId.includes('snapper') ? '#ef4444' : '#38bdf8';
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 8), getStdMat(fishHex, 0.38, 0.22));
    body.scale.set(0.65, 0.85, 1.85);
    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.13, 4), getStdMat(fishHex, 0.45, 0.15));
    tail.rotation.x = Math.PI / 2;
    tail.position.z = -0.22;
    g.add(body, tail);
  } else if (itemId.includes('ore') || itemId.includes('gem') || itemId.includes('crystal') || itemId === 'stone' || itemId === 'diamond' || itemId === 'gold_ingot') {
    const oreHex =
      itemId.includes('gold') ? '#eab308' : itemId.includes('copper') ? '#ea580c' : itemId.includes('iron') || itemId === 'stone' ? '#64748b' : itemId.includes('emerald') ? '#10b981' : itemId.includes('ruby') ? '#ef4444' : '#38bdf8';
    const crystal = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.14, 0),
      getStdMat(oreHex, 0.32, 0.45, oreHex, itemId.includes('gem') || itemId.includes('crystal') ? 0.35 : 0.05)
    );
    g.add(crystal);
  } else if (itemId.includes('wood') || itemId === 'hardwood' || itemId === 'lumber' || itemId === 'branch') {
    const log = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.08, 0.34, 8), getStdMat('#7c4a26', 0.9, 0.02));
    log.rotation.z = Math.PI / 2;
    g.add(log);
  } else if (itemId.includes('milk')) {
    const jug = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.1, 0.22, 10), getStdMat('#e2e8f0', 0.55, 0.12));
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.05, 8), getStdMat('#38bdf8', 0.5, 0.1));
    cap.position.y = 0.13;
    g.add(jug, cap);
  } else if (itemId.includes('egg')) {
    const egg = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 8), getStdMat('#ebe3d0', 0.65, 0.02));
    egg.scale.set(0.88, 1.22, 0.88);
    g.add(egg);
  } else if (itemId.includes('cheese')) {
    const wedge = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.1, 3), getStdMat('#facc15', 0.72, 0.02));
    g.add(wedge);
  } else if (itemId.includes('wool')) {
    const puff = new THREE.Mesh(new THREE.DodecahedronGeometry(0.14, 0), getStdMat('#e5e7eb', 0.94, 0));
    g.add(puff);
  } else if (itemId.includes('feather') || itemId.includes('ring') || itemId.includes('bouquet')) {
    const box = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.12, 0.16), getStdMat('#be123c', 0.65, 0.08));
    const ribbon = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.03, 0.17), getStdMat('#facc15', 0.35, 0.5));
    ribbon.position.y = 0.05;
    g.add(box, ribbon);
  } else if (itemId.includes('cake') || itemId.includes('bread') || itemId.includes('soup') || itemId.includes('pie') || itemId.includes('salad') || itemId.includes('dish') || itemId.includes('stew') || itemId.includes('coffee') || itemId.includes('tea')) {
    const plate = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.13, 0.03, 12), getStdMat('#d6d3d1', 0.55, 0.05));
    const food = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 8), getStdMat('#d97706', 0.72, 0.02));
    food.scale.set(1.1, 0.65, 1.1);
    food.position.y = 0.06;
    g.add(plate, food);
  } else {
    // Ripe crop / produce / berry / flower / honey jar
    const cropDef = CROPS[itemId];
    const col = cropDef?.color || (itemId.includes('apple') ? '#dc2626' : itemId.includes('honey') ? '#f59e0b' : itemId.includes('flower') || itemId.includes('rose') ? '#ec4899' : '#22c55e');
    const fruit = new THREE.Mesh(new THREE.SphereGeometry(0.13, 10, 8), getStdMat(col, 0.68, 0.04));
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.022, 0.09, 6), getStdMat('#15803d', 0.85, 0.02));
    stem.position.y = 0.14;
    g.add(fruit, stem);
  }

  g.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      obj.castShadow = true;
    }
  });
  return g;
}

export function createTreeStumpMesh(scale = 1): THREE.Group {
  const g = new THREE.Group();
  const bark = getStdMat('#6b4226', 0.92, 0.01);
  const rings = getStdMat('#c9a26b', 0.88, 0.01);
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.44, 0.48, 10), bark);
  body.position.y = 0.24;
  body.castShadow = true;
  body.receiveShadow = true;
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.305, 0.305, 0.035, 10), rings);
  cap.position.y = 0.48;
  cap.receiveShadow = true;
  // Subtle exposed root flares for realistic grounded silhouette
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2 + 0.35;
    const root = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.14, 0.32), bark);
    root.position.set(Math.cos(a) * 0.34, 0.07, Math.sin(a) * 0.34);
    root.rotation.y = -a + Math.PI / 2;
    g.add(root);
  }
  g.add(body, cap);
  g.scale.setScalar(scale);
  return g;
}

export function createFarmObstacleMesh(obstacle: FarmObstacleType): THREE.Group {
  if (obstacle === 'weed') return glbAssets.clone('/assets/glb/environment/farm_weed.glb');
  if (obstacle === 'root') return glbAssets.clone('/assets/glb/environment/farm_root.glb');
  if (obstacle === 'stump') {
    return createTreeStumpMesh(1.0);
  }
  if (obstacle === 'rock') {
    const r = glbAssets.clone('/assets/glb/environment/mine_rock.glb');
    r.scale.setScalar(0.62);
    return r;
  }
  if (obstacle === 'large_rock') {
    const r = glbAssets.clone('/assets/glb/environment/mine_rock.glb');
    r.scale.setScalar(1.06);
    return r;
  }
  if (obstacle === 'sapling') {
    const s = glbAssets.clone('/assets/glb/environment/farm_sapling.glb');
    s.scale.setScalar(1.05);
    return s;
  }
  if (obstacle === 'large_tree') {
    const { mesh } = createDistinctTreeMesh('oak', '#15803d', 4);
    mesh.scale.setScalar(1.16);
    return mesh;
  }
  const { mesh } = createDistinctTreeMesh('oak', '#22c55e', 4);
  mesh.scale.setScalar(0.76);
  return mesh;
}

export function createCropMesh(cropId: string, stage: 0 | 1 | 2 | 3): THREE.Group {
  const crop = CROPS[cropId];
  let url = '/assets/glb/crops/stage_0.glb';
  if (stage === 1) url = '/assets/glb/crops/stage_1.glb';
  else if (stage === 2) url = '/assets/glb/crops/stage_2.glb';
  else if (stage === 3) {
    if (crop?.shape === 'root') url = '/assets/glb/crops/crop_root.glb';
    else if (crop?.shape === 'tall') url = '/assets/glb/crops/crop_tall.glb';
    else if (crop?.shape === 'flower') url = '/assets/glb/crops/crop_flower.glb';
    else url = '/assets/glb/crops/crop_bush.glb';
  }

  const g = glbAssets.clone(url);
  if (stage === 3 && crop) {
    g.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const m = obj as THREE.Mesh;
        const mat = m.material as THREE.MeshStandardMaterial;
        if (m.name.includes('FruitPart') || mat.name === 'FruitMat') {
          mat.color.set(crop.color);
          if (crop.shape === 'crystal') {
            mat.emissive.set('#38bdf8');
            mat.emissiveIntensity = 0.45;
          }
        }
      }
    });
  }
  return g;
}

export function createAnimalMesh(type: 'cow' | 'chicken' | 'sheep' | 'dog' | 'horse'): THREE.Group {
  const g = glbAssets.clone(`/assets/glb/animals/${type}.glb`);
  g.add(createContactShadow(type === 'chicken' ? 0.35 : 0.65));
  return g;
}
