import { MUSIC_CONFIG } from '../data/gameRuntimeConfig';
import type { AudioSettings, MusicConfig, MusicMoodKey } from '../types';

interface PastoralArrangement {
  bpm: number;
  // Melody MIDI notes (0 = rest)
  melody: number[];
  // Harmony / counter-voice MIDI notes (0 = rest)
  harmony: number[];
  // Fingerpicked acoustic guitar chord root/arpeggio MIDI notes per beat
  guitarChords: number[][];
  // Upright warm bass MIDI notes per measure
  bass: number[];
}

function midiToHz(midi: number): number {
  return 440 * Math.pow(2, (midi - 69) / 12);
}

// Warm, nostalgic Harvest Moon: Back to Nature–inspired pastoral countryside arrangements
const PASTORAL_COMPOSITIONS: Record<MusicMoodKey, PastoralArrangement> = {
  // Spring: Bright, airy sunlit meadow waltz/pastoral (G major)
  Spring: {
    bpm: 106,
    melody: [
      71, 74, 76, 79, 78, 76, 74, 0,
      72, 74, 76, 72, 71, 69, 67, 0,
      69, 71, 72, 76, 74, 72, 71, 67,
      69, 71, 74, 71, 67, 0, 0, 0,
    ],
    harmony: [
      67, 0, 71, 0, 74, 0, 71, 0,
      67, 0, 72, 0, 67, 0, 62, 0,
      64, 0, 69, 0, 69, 0, 67, 0,
      66, 0, 69, 0, 62, 0, 67, 0,
    ],
    guitarChords: [
      [55, 59, 62, 67], // G
      [50, 54, 57, 62], // D
      [48, 52, 55, 60], // C
      [55, 59, 62, 67], // G
      [57, 60, 64, 69], // Am
      [52, 55, 59, 64], // Em
      [50, 54, 57, 62], // D
      [55, 59, 62, 67], // G
    ],
    bass: [43, 50, 48, 43, 45, 40, 50, 43],
  },
  // Summer: Lively, sunlit riverside folk tune (C major)
  Summer: {
    bpm: 118,
    melody: [
      76, 79, 81, 79, 76, 72, 74, 76,
      77, 79, 81, 77, 76, 74, 72, 0,
      74, 76, 77, 79, 81, 79, 77, 74,
      76, 74, 72, 74, 72, 0, 0, 0,
    ],
    harmony: [
      72, 0, 76, 0, 72, 0, 67, 0,
      72, 0, 77, 0, 72, 0, 67, 0,
      69, 0, 74, 0, 74, 0, 71, 0,
      72, 0, 67, 0, 67, 0, 72, 0,
    ],
    guitarChords: [
      [48, 52, 55, 60], // C
      [55, 59, 62, 67], // G
      [53, 57, 60, 65], // F
      [48, 52, 55, 60], // C
      [50, 53, 57, 62], // Dm
      [55, 59, 62, 67], // G
      [53, 57, 60, 65], // F
      [48, 52, 55, 60], // C
    ],
    bass: [48, 43, 41, 48, 50, 43, 41, 48],
  },
  // Autumn: Nostalgic amber sunset breeze (F major / D minor warmth)
  Autumn: {
    bpm: 98,
    melody: [
      74, 77, 79, 81, 79, 77, 74, 0,
      72, 74, 76, 77, 74, 72, 69, 0,
      70, 74, 77, 74, 72, 70, 69, 67,
      69, 72, 74, 72, 69, 0, 0, 0,
    ],
    harmony: [
      69, 0, 74, 0, 72, 0, 69, 0,
      67, 0, 72, 0, 69, 0, 65, 0,
      65, 0, 70, 0, 67, 0, 64, 0,
      65, 0, 69, 0, 65, 0, 69, 0,
    ],
    guitarChords: [
      [50, 53, 57, 62], // Dm
      [48, 52, 55, 60], // C
      [53, 57, 60, 65], // F
      [57, 60, 64, 69], // Am
      [46, 50, 53, 58], // Bb
      [48, 52, 55, 60], // C
      [53, 57, 60, 65], // F
      [50, 53, 57, 62], // Dm
    ],
    bass: [50, 48, 41, 45, 46, 48, 41, 50],
  },
  // Winter: Gentle crystalline snowfall & hearth chime (D major / B minor)
  Winter: {
    bpm: 88,
    melody: [
      78, 76, 74, 71, 74, 76, 78, 0,
      81, 78, 76, 74, 71, 69, 71, 0,
      74, 76, 78, 74, 71, 69, 66, 0,
      69, 71, 74, 76, 74, 0, 0, 0,
    ],
    harmony: [
      71, 0, 69, 0, 66, 0, 71, 0,
      74, 0, 71, 0, 66, 0, 69, 0,
      69, 0, 71, 0, 66, 0, 62, 0,
      64, 0, 67, 0, 69, 0, 66, 0,
    ],
    guitarChords: [
      [50, 54, 57, 62], // D
      [59, 62, 66, 71], // Bm
      [55, 59, 62, 67], // G
      [57, 61, 64, 69], // A
      [50, 54, 57, 62], // D
      [54, 57, 61, 66], // F#m
      [55, 59, 62, 67], // G
      [50, 54, 57, 62], // D
    ],
    bass: [50, 47, 43, 45, 50, 42, 43, 50],
  },
  // Title: Heartwarming homecoming theme
  title: {
    bpm: 96,
    melody: [
      67, 71, 74, 76, 74, 71, 69, 0,
      72, 76, 79, 76, 74, 71, 67, 0,
      69, 72, 76, 74, 71, 67, 69, 71,
      74, 76, 74, 71, 67, 0, 0, 0,
    ],
    harmony: [
      62, 0, 67, 0, 67, 0, 66, 0,
      67, 0, 72, 0, 67, 0, 62, 0,
      64, 0, 69, 0, 67, 0, 62, 0,
      66, 0, 69, 0, 62, 0, 67, 0,
    ],
    guitarChords: [
      [55, 59, 62, 67],
      [50, 54, 57, 62],
      [48, 52, 55, 60],
      [55, 59, 62, 67],
      [57, 60, 64, 69],
      [55, 59, 62, 67],
      [50, 54, 57, 62],
      [55, 59, 62, 67],
    ],
    bass: [43, 50, 48, 43, 45, 43, 50, 43],
  },
  // Festival lowercase key alias
  festival: {
    bpm: 132,
    melody: [
      79, 76, 74, 79, 81, 79, 76, 74,
      76, 79, 81, 83, 81, 79, 76, 0,
      79, 83, 81, 79, 76, 74, 72, 74,
      76, 74, 71, 74, 79, 0, 0, 0,
    ],
    harmony: [
      71, 74, 71, 74, 76, 74, 71, 67,
      72, 76, 76, 79, 76, 74, 72, 0,
      71, 76, 74, 71, 72, 69, 67, 69,
      71, 69, 67, 69, 71, 0, 0, 0,
    ],
    guitarChords: [
      [55, 59, 62, 67],
      [48, 52, 55, 60],
      [50, 54, 57, 62],
      [55, 59, 62, 67],
      [55, 59, 62, 67],
      [48, 52, 55, 60],
      [50, 54, 57, 62],
      [55, 59, 62, 67],
    ],
    bass: [43, 48, 50, 43, 43, 48, 50, 43],
  },
  // Indoor: Cozy hearth & wooden cottage lullaby
  indoor: {
    bpm: 90,
    melody: [
      72, 76, 79, 76, 74, 72, 69, 0,
      71, 74, 76, 74, 72, 67, 0, 0,
      69, 72, 74, 76, 74, 72, 69, 67,
      71, 74, 72, 69, 67, 0, 0, 0,
    ],
    harmony: [
      67, 0, 72, 0, 69, 0, 64, 0,
      67, 0, 71, 0, 67, 0, 62, 0,
      65, 0, 69, 0, 67, 0, 64, 0,
      67, 0, 67, 0, 64, 0, 67, 0,
    ],
    guitarChords: [
      [48, 52, 55, 60],
      [57, 60, 64, 69],
      [55, 59, 62, 67],
      [48, 52, 55, 60],
      [53, 57, 60, 65],
      [48, 52, 55, 60],
      [50, 53, 57, 62],
      [48, 52, 55, 60],
    ],
    bass: [48, 45, 43, 48, 41, 48, 50, 48],
  },
};

class SoundEngine {
  private ctx: AudioContext | null = null;
  private musicGainNode: GainNode | null = null;
  private musicFilterNode: BiquadFilterNode | null = null;
  private muted = false;
  private masterVolume = 0.8;
  private sfxVolume = 0.85;
  private musicVolume = 0.65;

  private musicConfig: MusicConfig = { ...MUSIC_CONFIG };
  private currentMood: MusicMoodKey = 'Spring';
  private bgmPlaying = false;
  private bgmStep = 0;
  private bgmTimer: number | null = null;
  private customAudioEl: HTMLAudioElement | null = null;
  private customAudioSrc = '';

  public isMuted() {
    return this.muted;
  }

  public setMuted(val: boolean) {
    this.muted = val;
    this.syncMusicOutputLevel();
  }

  public setAudioSettings(audio: AudioSettings) {
    this.muted = audio.muted;
    this.masterVolume = Math.max(0, Math.min(1, audio.masterVolume));
    this.sfxVolume = Math.max(0, Math.min(1, audio.sfxVolume));
    this.musicVolume = Math.max(0, Math.min(1, audio.musicVolume));
    this.syncMusicOutputLevel();
  }

  public applyMusicConfig(config: Partial<MusicConfig>) {
    this.musicConfig = {
      ...this.musicConfig,
      ...config,
      customTracks: { ...(this.musicConfig.customTracks || {}), ...(config.customTracks || {}) },
    };
    if (this.bgmPlaying) {
      this.restartBgmScheduler();
    }
  }

  public setMusicMood(mood: MusicMoodKey) {
    if (this.currentMood === mood && this.bgmPlaying) return;
    this.currentMood = mood;
    if (this.bgmPlaying) {
      this.restartBgmScheduler();
    }
  }

  public startBackgroundMusic(mood?: MusicMoodKey) {
    if (mood) this.currentMood = mood;
    if (this.bgmPlaying) {
      this.restartBgmScheduler();
      return;
    }
    this.bgmPlaying = true;
    this.restartBgmScheduler();
  }

  public stopBackgroundMusic() {
    this.bgmPlaying = false;
    if (this.bgmTimer !== null) {
      clearTimeout(this.bgmTimer);
      this.bgmTimer = null;
    }
    if (this.customAudioEl) {
      this.customAudioEl.pause();
    }
  }

  private getEffectiveSfxGain(baseGain: number) {
    if (this.muted) return 0;
    return baseGain * this.masterVolume * this.sfxVolume;
  }

  private getEffectiveMusicGain() {
    if (this.muted) return 0;
    return Math.max(0, Math.min(1, this.masterVolume * this.musicVolume));
  }

  private syncMusicOutputLevel() {
    const level = this.getEffectiveMusicGain();
    if (this.musicGainNode && this.ctx) {
      this.musicGainNode.gain.setTargetAtTime(level * 0.42, this.ctx.currentTime, 0.08);
    }
    if (this.customAudioEl) {
      this.customAudioEl.volume = level;
      this.customAudioEl.muted = this.muted;
    }
  }

  private ensureCtx(): AudioContext | null {
    if (this.muted) return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    if (!this.musicFilterNode || !this.musicGainNode) {
      this.musicFilterNode = this.ctx.createBiquadFilter();
      this.musicFilterNode.type = 'lowpass';
      this.musicFilterNode.frequency.value = 3400;
      this.musicFilterNode.Q.value = 0.6;

      this.musicGainNode = this.ctx.createGain();
      this.musicGainNode.gain.value = this.getEffectiveMusicGain() * 0.42;

      this.musicFilterNode.connect(this.musicGainNode);
      this.musicGainNode.connect(this.ctx.destination);
    }
    return this.ctx;
  }

  private restartBgmScheduler() {
    if (this.bgmTimer !== null) {
      clearTimeout(this.bgmTimer);
      this.bgmTimer = null;
    }

    const customTrackUrl =
      this.musicConfig.mode === 'custom'
        ? this.musicConfig.customTracks?.[this.currentMood] || this.musicConfig.customTracks?.Spring
        : undefined;

    if (customTrackUrl && customTrackUrl.trim()) {
      const safeUrl = customTrackUrl.trim();
      if (!this.customAudioEl) {
        this.customAudioEl = new Audio();
        this.customAudioEl.loop = true;
      }
      if (this.customAudioSrc !== safeUrl) {
        this.customAudioSrc = safeUrl;
        this.customAudioEl.src = safeUrl;
      }
      this.customAudioEl.volume = this.getEffectiveMusicGain();
      this.customAudioEl.muted = this.muted;
      this.customAudioEl.play().catch(() => {
        // Autoplay deferred until first user gesture; fallback cleanly on next interaction
      });
      return;
    }

    // Stop custom audio element if switching back to procedural Harvest Moon synth
    if (this.customAudioEl) {
      this.customAudioEl.pause();
    }

    this.scheduleNextPastoralStep();
  }

  private scheduleNextPastoralStep() {
    if (!this.bgmPlaying) return;
    const comp = PASTORAL_COMPOSITIONS[this.currentMood] || PASTORAL_COMPOSITIONS.Spring;
    const presetFactor =
      this.musicConfig.preset === 'btn_lively'
        ? 1.12
        : this.musicConfig.preset === 'btn_cozy'
          ? 0.88
          : 1.0;
    const tempoScale = Math.max(0.7, Math.min(1.35, Number(this.musicConfig.tempoScale) || 1.0));
    const effectiveBpm = comp.bpm * presetFactor * tempoScale;
    const stepMs = (60 / effectiveBpm) * 500; // Eighth-note pulse

    if (!this.muted && this.getEffectiveMusicGain() > 0.005) {
      this.playPastoralStep(comp, this.bgmStep, stepMs / 1000);
    }

    this.bgmStep = (this.bgmStep + 1) % comp.melody.length;
    this.bgmTimer = window.setTimeout(() => this.scheduleNextPastoralStep(), stepMs);
  }

  private playPastoralStep(comp: PastoralArrangement, step: number, stepSec: number) {
    const ctx = this.ensureCtx();
    if (!ctx || !this.musicFilterNode || ctx.state !== 'running') return;

    const now = ctx.currentTime + 0.015;
    const chordIdx = Math.floor(step / 4) % comp.guitarChords.length;
    const chord = comp.guitarChords[chordIdx];
    const preset = this.musicConfig.preset || 'btn_pastoral';

    // 1. Acoustic Guitar Fingerpicked Arpeggio (warm woody pluck)
    const arpNote = chord[step % chord.length];
    if (arpNote > 0) {
      this.playPluckVoice(ctx, midiToHz(arpNote), now, stepSec * 1.65, 0.16);
    }

    // 2. Soft Upright Bass on measure downbeats
    if (step % 4 === 0) {
      const bassNote = comp.bass[chordIdx];
      if (bassNote > 0) {
        this.playBassVoice(ctx, midiToHz(bassNote), now, stepSec * 3.4, 0.22);
      }
    }

    // 3. Nostalgic Wooden Flute / Ocarina Lead Melody with gentle vibrato
    const melNote = comp.melody[step];
    if (melNote > 0) {
      const melodyType = preset === 'btn_cozy' ? 'bell' : 'flute';
      this.playMelodyVoice(ctx, midiToHz(melNote), now, stepSec * 1.45, 0.24, melodyType);
    }

    // 4. Soft Harp / Marimba Counter-Harmony
    const harmNote = comp.harmony[step];
    if (harmNote > 0) {
      this.playPluckVoice(ctx, midiToHz(harmNote), now + 0.01, stepSec * 1.35, 0.09);
    }
  }

  private playMelodyVoice(
    ctx: AudioContext,
    freq: number,
    startTime: number,
    duration: number,
    peakGain: number,
    style: 'flute' | 'bell'
  ) {
    if (!this.musicFilterNode) return;
    const osc = ctx.createOscillator();
    const overtone = ctx.createOscillator();
    const gain = ctx.createGain();
    const overtoneGain = ctx.createGain();

    osc.type = style === 'bell' ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(freq, startTime);

    overtone.type = 'sine';
    overtone.frequency.setValueAtTime(freq * 2, startTime);
    overtoneGain.gain.value = style === 'bell' ? 0.14 : 0.08;

    // Gentle acoustic vibrato on flute lead
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    lfo.frequency.value = 5.2;
    lfoGain.gain.value = freq * 0.006;
    lfo.connect(lfoGain);
    lfoGain.connect(osc.frequency);

    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.linearRampToValueAtTime(peakGain, startTime + 0.045);
    gain.gain.exponentialRampToValueAtTime(peakGain * 0.65, startTime + duration * 0.55);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    osc.connect(gain);
    overtone.connect(overtoneGain);
    overtoneGain.connect(gain);
    gain.connect(this.musicFilterNode);

    osc.start(startTime);
    overtone.start(startTime);
    lfo.start(startTime);
    osc.stop(startTime + duration + 0.03);
    overtone.stop(startTime + duration + 0.03);
    lfo.stop(startTime + duration + 0.03);
  }

  private playPluckVoice(ctx: AudioContext, freq: number, startTime: number, duration: number, peakGain: number) {
    if (!this.musicFilterNode) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, startTime);

    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.linearRampToValueAtTime(peakGain, startTime + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    osc.connect(gain);
    gain.connect(this.musicFilterNode);
    osc.start(startTime);
    osc.stop(startTime + duration + 0.02);
  }

  private playBassVoice(ctx: AudioContext, freq: number, startTime: number, duration: number, peakGain: number) {
    if (!this.musicFilterNode) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, startTime);

    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.linearRampToValueAtTime(peakGain, startTime + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    osc.connect(gain);
    gain.connect(this.musicFilterNode);
    osc.start(startTime);
    osc.stop(startTime + duration + 0.02);
  }

  private playTone(
    freq: number,
    duration: number,
    type: OscillatorType = 'sine',
    gainPeak = 0.08,
    endFreq?: number,
    delay = 0,
    channel: 'sfx' | 'music' = 'sfx'
  ) {
    const ctx = this.ensureCtx();
    if (!ctx) return;
    const effectiveGain = channel === 'music' ? gainPeak * this.getEffectiveMusicGain() : this.getEffectiveSfxGain(gainPeak);
    if (effectiveGain <= 0.0005) return;
    const now = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    if (endFreq !== undefined) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), now + duration);
    }
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(effectiveGain, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  public playUiClick() {
    this.playTone(620, 0.06, 'triangle', 0.05, 840);
  }

  public playHoe() {
    this.playTone(170, 0.11, 'sawtooth', 0.07, 75);
    this.playTone(120, 0.09, 'triangle', 0.06, 55, 0.03);
  }

  public playWater() {
    this.playTone(460, 0.14, 'sine', 0.06, 780);
    this.playTone(640, 0.16, 'sine', 0.05, 980, 0.06);
  }

  public playPlant() {
    this.playTone(340, 0.08, 'triangle', 0.06, 520);
    this.playTone(520, 0.1, 'sine', 0.05, 680, 0.06);
  }

  public playHarvest() {
    this.playTone(523.25, 0.1, 'triangle', 0.07, undefined, 0);
    this.playTone(659.25, 0.1, 'triangle', 0.07, undefined, 0.07);
    this.playTone(783.99, 0.14, 'triangle', 0.08, undefined, 0.14);
    this.playTone(1046.5, 0.22, 'sine', 0.08, undefined, 0.21);
  }

  public playCoin() {
    this.playTone(987.77, 0.08, 'sine', 0.07, undefined, 0);
    this.playTone(1318.51, 0.18, 'sine', 0.08, undefined, 0.07);
  }

  public playChop() {
    this.playTone(210, 0.08, 'square', 0.05, 90);
    this.playTone(140, 0.12, 'triangle', 0.06, 65, 0.04);
  }

  public playJump() {
    this.playTone(260, 0.14, 'sine', 0.06, 560);
  }

  public playFootstep(isSprint = false) {
    const pitch = isSprint ? 165 + Math.random() * 35 : 125 + Math.random() * 25;
    this.playTone(pitch, isSprint ? 0.055 : 0.045, 'triangle', isSprint ? 0.036 : 0.022, pitch * 0.65);
  }

  public playSplash() {
    this.playTone(320, 0.18, 'sine', 0.07, 150);
    this.playTone(580, 0.14, 'triangle', 0.05, 290, 0.05);
  }

  public playAnimalHappy() {
    this.playTone(440, 0.12, 'sine', 0.07, 587);
    this.playTone(587, 0.18, 'sine', 0.07, 784, 0.1);
  }

  public playDoor() {
    this.playTone(280, 0.12, 'triangle', 0.06, 200);
    this.playTone(360, 0.14, 'sine', 0.05, 420, 0.08);
  }

  public playHeart() {
    this.playTone(587.33, 0.12, 'sine', 0.06, undefined, 0);
    this.playTone(739.99, 0.12, 'sine', 0.06, undefined, 0.09);
    this.playTone(880, 0.22, 'sine', 0.07, undefined, 0.18);
  }

  public playWoodStone() {
    this.playChop();
  }

  public playTill() {
    this.playTone(170, 0.09, 'triangle', 0.07, 95);
    this.playTone(125, 0.11, 'sine', 0.05, 72, 0.04);
  }

  public playFishSplash() {
    this.playSplash();
  }

  public playRing() {
    this.playTone(880, 0.12, 'sine', 0.06, 1174, 0);
    this.playTone(880, 0.12, 'sine', 0.06, 1174, 0.18);
  }

  public playTalkBlip(pitch = 460) {
    const f = Math.max(220, Math.min(920, pitch + (Math.random() - 0.5) * 40));
    this.playTone(f, 0.045, 'triangle', 0.032, f * 1.06);
  }

  public startAmbientMusic() {
    this.startBackgroundMusic(this.currentMood);
  }

  public stopAmbientMusic() {
    this.stopBackgroundMusic();
  }

  public playAmbientMelody() {
    this.startBackgroundMusic(this.currentMood);
  }
}

export const soundEngine = new SoundEngine();
