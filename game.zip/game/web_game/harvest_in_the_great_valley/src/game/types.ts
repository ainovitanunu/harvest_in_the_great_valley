export type Season = 'Spring' | 'Summer' | 'Autumn' | 'Winter';
export type Weather = 'Sunny' | 'Cloudy' | 'LightRain' | 'HeavyRain' | 'Rainy' | 'Stormy' | 'Foggy' | 'Snowy';
export type TimeOfDayPhase = 'dawn' | 'morning' | 'noon' | 'afternoon' | 'dusk' | 'night';
export type Gender = 'male' | 'female';
export type BuildingFacing = 'south' | 'north' | 'east' | 'west';
export type Language = 'en' | 'id';
export type GraphicsQuality = 'low' | 'medium' | 'high' | 'ultra';
export type ThemeMode = 'cozy' | 'light' | 'dark' | 'seasonal' | 'farmhouse' | 'system';
export type DeviceControlMode = 'auto' | 'desktop' | 'mobile';
export type CameraPovMode = 'lock' | 'free';
export type MusicPresetId = 'btn_pastoral' | 'btn_lively' | 'btn_cozy';
export type MusicMoodKey = Season | 'title' | 'festival' | 'indoor';

export interface MusicConfig {
  mode: 'procedural' | 'custom';
  preset: MusicPresetId;
  tempoScale: number; // 0.7..1.35
  customTracks: Partial<Record<MusicMoodKey, string>>;
}

export interface PaymentMethodConfig {
  googlePlayBilling: boolean;
  duitku: boolean;
}

export interface WeatherControlConfig {
  overrideEnabled: boolean;
  weights: Record<Weather, number>;
}

export interface AudioSettings {
  muted: boolean;
  masterVolume: number; // 0..1
  sfxVolume: number; // 0..1
  musicVolume: number; // 0..1
}

export interface GraphicsSettings {
  quality: GraphicsQuality;
  shadows: boolean;
  weatherParticles: boolean;
  renderScale: number; // 0.6..1.0
  realTimeLighting?: boolean;
  dynamicShadows?: boolean;
  globalIllumination?: boolean;
  realTimeGI?: boolean;
  rayTracing?: boolean;
  pathTracing?: boolean;
}

export type MobileControlElementId = 'analog' | 'jump' | 'sprint' | 'action' | 'tool' | 'interact';

export interface MobileControlElementLayout {
  xPct: number; // 2..98 (% of viewport width from left)
  yPct: number; // 2..98 (% of viewport height from top)
  sizePx: number; // px diameter
  opacity: number; // 0.25..1.0
  visible?: boolean;
}

export interface CustomMobileGamepadLayout {
  presetName: string;
  elements: Record<MobileControlElementId, MobileControlElementLayout>;
}

export interface MobileGamepadPreset {
  id: string;
  name: string;
  layout: CustomMobileGamepadLayout;
}

export interface GameSettings {
  language: Language;
  theme?: ThemeMode;
  mobileMode?: boolean;
  deviceControlMode?: DeviceControlMode;
  povMode?: CameraPovMode;
  showSelfCameraInCall?: boolean;
  mobileGamepadLayout?: CustomMobileGamepadLayout;
  mobileGamepadPresets?: MobileGamepadPreset[];
  audio: AudioSettings;
  graphics: GraphicsSettings;
}

export interface VideoCallConfig {
  width: number;
  height: number;
  fps: number;
  bitrateKbps: number;
  showSelfPreviewByDefault: boolean;
}

export interface CameraConfig {
  defaultDistance: number;
  minZoom: number;
  maxZoom: number;
  povMode: CameraPovMode;
  fov: number;
  defaultPitch: number;
  mobileLockOrbitEnabled?: boolean;
  mobileLockAutoReturnDelaySec?: number;
  mobileLockAutoReturnSpeed?: number;
}

export interface MobileControlsConfig {
  joystickBottomPx: number;
  joystickLeftPx: number;
  joystickSizePx: number;
  actionBottomPx: number;
  actionRightPx: number;
  buttonScale: number;
  showTopRightSwitchOnly: boolean;
  minAnalogSizePx?: number;
  maxAnalogSizePx?: number;
  minButtonSizePx?: number;
  maxButtonSizePx?: number;
  defaultLayout?: CustomMobileGamepadLayout;
}

export interface MarketEconomyConfig {
  minMultiplier: number;
  maxMultiplier: number;
  goldDemandFactor: number;
  diamondFloorMultiplier: number;
}

export interface EconomyTaxTier {
  minLevel: number;
  taxPercent: number;
}

export interface EconomyTaxConfig {
  enabled: boolean;
  goldTiers: EconomyTaxTier[];
  diamondTiers: EconomyTaxTier[];
}

export interface NameChangeEconomyConfig {
  basePriceDiamond: number;
  minimumPriceDiamond: number;
}

export interface PerformanceConfig {
  enableLod: boolean;
  enableOcclusionCulling: boolean;
  lowPower4GbMode: boolean;
  maxDprLowPower: number;
  maxAnisotropy: number;
  lod0Distance: number;
  lod1Distance: number;
}

export type SocialProviderId = 'google' | 'steam' | 'apple';

export interface GuestSessionConfig {
  durationMinutes: number; // default 60 (1 hour)
  warningBeforeMinutes: number; // default 5
}

export interface WorldTimeOverrideConfig {
  enabled: boolean;
  hour: number; // 0..23
  minute: number; // 0..59
  day: number; // 1..30
  season: Season;
  year: number;
  timePaused: boolean;
  timeScale: number; // 0.25..20
  weatherOverride: Weather | null;
}

export interface CharacterRosterEntry {
  characterId: string;
  accountId: string;
  provider: SocialProviderId;
  avatarName: string;
  farmName: string;
  gender: Gender;
  birthday: string;
  dogName: string;
  horseName: string;
  avatarConfig: AvatarConfig;
  level: number;
  gold: number;
  diamond: number;
  season: Season;
  day: number;
  year: number;
  createdAt: number;
  lastPlayedAt: number;
  deletionScheduledAt?: number | null;
  deletionExecuteAt?: number | null;
  savePayload?: Record<string, unknown>;
}

export interface AdminInventoryUpdate {
  itemId: string;
  quantity: number;
  mode: 'set' | 'add';
  diamondTradeable?: boolean;
}

export type AnnouncementCategory = 'update' | 'maintenance' | 'event' | 'emergency' | 'promotion';

export type BanType = 'chat_ban' | 'temporary_ban' | 'permanent_ban' | 'account_lock';

export interface PlayerBanRecord {
  id?: string;
  uid: string;
  avatarName?: string;
  playerName?: string;
  banType: BanType;
  reason: string;
  adminNote?: string;
  developerMessage?: string;
  devMessage?: string;
  startedAt?: number;
  issuedAt?: number;
  expiresAt: number | null; // null = permanent
  durationHours?: number | null;
  durationMinutes?: number | null;
  createdBy?: string;
  issuedBy?: string;
  active: boolean;
}

export interface BranchingDialogueChoice {
  id: string;
  label?: Partial<Record<Language, string>>;
  labelByLang?: Partial<Record<Language, string>>;
  replyByLang?: Partial<Record<Language, string>>;
  nextNodeId?: string | null;
  friendshipDelta?: number;
  affectionDelta?: number;
  questId?: string | null;
  rewardGold?: number;
}

export interface BranchingDialogueNode {
  id: string;
  npcId: string;
  title: string;
  trigger: 'greeting' | 'morning' | 'afternoon' | 'evening' | 'rainy' | 'festival' | 'quest' | 'custom';
  emotion?: NpcEmotion;
  text?: Partial<Record<Language, string>>;
  textByLang?: Partial<Record<Language, string>>;
  choices: BranchingDialogueChoice[];
  updatedAt: number;
}

export interface CustomShopProduct {
  id: string;
  name: string;
  shopId?: string;
  itemId: string;
  quantity?: number;
  currency?: 'gold' | 'diamond';
  price?: number;
  goldPrice?: number;
  diamondPrice?: number;
  discountPct?: number;
  discountPercent?: number;
  isBundle: boolean;
  bundleItems?: Array<{ itemId: string; quantity: number }>;
  active: boolean;
  description?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: number;
  actor: string;
  actorProvider?: string;
  category:
    | 'env_config'
    | 'env'
    | 'runtime_config'
    | 'character'
    | 'item'
    | 'currency'
    | 'economy'
    | 'shop'
    | 'dialogue'
    | 'npc_schedule'
    | 'npc'
    | 'ban'
    | 'announcement'
    | 'world'
    | 'auth'
    | 'system';
  action: string;
  target?: string;
  summary: string;
  details?: Record<string, unknown>;
}

export interface PublicGameEnvConfig {
  GAME_VERSION: string;
  GAME_MAINTENANCE_MODE: boolean;
  EXP_RATE_MULTIPLIER: number;
  DROP_RATE_MULTIPLIER: number;
  PLAYER_INITIAL_GOLD: number;
  PLAYER_INITIAL_DIAMOND: number;
  PLAYER_MAX_LEVEL: number;
  CDN_URL: string;
}

export interface NpcScheduleOverride {
  npcId: string;
  rainBehavior?: 'shelter_indoors' | 'carry_umbrella' | 'stay_home';
  schedule: NPCRoutineSlot[];
}

export interface SkyAtmosphereConfig {
  cloudDensity: number; // 0..1
  cloudSpeed: number; // 0.2..3
  starTwinkleIntensity: number; // 0..1
  moonPhaseOverride: number | null; // 0..1 or null for automatic day cycle
  enableWeatherEffects?: boolean;
}

export interface RuntimeGameConfig {
  debugMode: boolean;
  normalStarterGold: number;
  normalStarterDiamond: number;
  paymentMethods: PaymentMethodConfig;
  defaultGlobalTheme: ThemeMode;
  defaultWeather: Weather;
  weatherControl: WeatherControlConfig;
  guestSessionConfig: GuestSessionConfig;
  worldTimeOverride: WorldTimeOverrideConfig;
  skyAtmosphereConfig?: SkyAtmosphereConfig;
  announcementBanner: AnnouncementBannerConfig;
  fishingConfig: FishingConfig;
  caveMiningConfig: CaveMiningConfig;
  globalTreeEcosystem: GlobalTreeEcosystemConfig;
  videoCallConfig: VideoCallConfig;
  cameraConfig: CameraConfig;
  mobileControlsConfig: MobileControlsConfig;
  marketEconomyConfig: MarketEconomyConfig;
  economyTaxConfig: EconomyTaxConfig;
  nameChangeEconomyConfig: NameChangeEconomyConfig;
  performanceConfig: PerformanceConfig;
  itemTradeRates: Record<string, number>;
  publicEnvConfig?: PublicGameEnvConfig;
  customItems?: ItemDef[];
  customShopProducts?: CustomShopProduct[];
  npcScheduleOverrides?: Record<string, NPCRoutineSlot[]>;
  branchingDialogues?: BranchingDialogueNode[];
}

export interface GlobalTreeEcosystemConfig {
  minTrees: number;
  maxTrees: number;
  growthIntervalSec: number;
  growthBatchMin: number;
  growthBatchMax: number;
  carpenterCutIntervalSec: number;
  carpenterCutBatchMin: number;
  carpenterCutBatchMax: number;
}

export interface WorldTreeRecord {
  id: string;
  zone: 'village_square' | 'forest' | 'mountain_mine' | 'river_beach' | 'secret_grove' | 'farm_home';
  scope: 'global' | 'farm';
  model: 'oak' | 'pine' | 'birch';
  level?: 1 | 2 | 3 | 4;
  x: number;
  z: number;
  scale: number;
  rotation: number;
  chopped?: boolean;
  isStump?: boolean;
  plantedAt?: number;
}

export interface FishingConfig {
  luckMin: number;
  luckMax: number;
  waitMinSec: number;
  waitMaxSec: number;
  strikesRequired: number;
  greenZoneWidthPct: number;
}

export interface CaveMiningConfig {
  baseDropMinPct: number;
  baseDropMaxPct: number;
  baseRarityPct: number;
  levelDropStepPct: number;
  levelRarityStepPct: number;
  maxLevel: number;
}

export type NpcEmotion = 'neutral' | 'happy' | 'tired' | 'sad' | 'angry' | 'nervous' | 'excited';

export type NpcProfessionRole = 'miner' | 'lumberjack' | 'shopkeeper' | 'angler' | 'villager';

export interface NpcDialogueCategoryEntry {
  id: string;
  label: string;
  description?: string;
  lines: string[];
}

export interface NpcDialogueDatabase {
  version: number;
  updatedAt: string;
  categories: Record<string, NpcDialogueCategoryEntry>;
}

export interface WorldSpeechBubble {
  id: string;
  anchorId: string; // uid, 'npc:<id>', or 'sign_<id>'
  speakerName: string;
  text: string;
  kind: 'npc' | 'sign' | 'player' | 'private';
  emotion?: NpcEmotion;
  isThought?: boolean;
  createdAt: number;
  expiresAt: number;
}

export interface AnnouncementBannerConfig {
  enabled: boolean;
  category?: AnnouncementCategory;
  title: string;
  message: string;
  durationSec: number;
  sentAt?: number;
}

export interface DevPortalBridgeConfig {
  enabled: boolean;
  authorizedEmailHash: string;
  dashboardUrl: string;
}

export type WorldZoneId =
  | 'farm_home'
  | 'village_square'
  | 'forest'
  | 'river_beach'
  | 'mountain_mine'
  | 'secret_grove'
  | 'int_farmhouse'
  | 'int_barn'
  | 'int_coop'
  | 'int_stable'
  | 'int_general_store'
  | 'int_blacksmith'
  | 'int_flower_shop'
  | 'int_ranch'
  | 'int_clinic'
  | 'int_inn'
  | 'int_bakery'
  | 'int_library'
  | 'int_manor'
  | 'int_cave';

export type NpcIdlePose =
  | 'relaxed'
  | 'confident'
  | 'thoughtful'
  | 'cheerful'
  | 'energetic'
  | 'scholar'
  | 'wave'
  | 'stretch'
  | 'ponder'
  | 'chat'
  | 'yawn'
  | 'look_around'
  | 'sit'
  | 'whistle';

export type HairStyleId =
  | 'none'
  | 'ponytail'
  | 'spiky'
  | 'bob'
  | 'long'
  | 'buns'
  | 'short'
  | 'curly'
  | 'braids'
  | 'mohawk'
  | 'undercut'
  | 'wavy'
  | 'afro'
  // 18 Men's Hairstyles
  | 'soft_mullet'
  | 'textured_crop'
  | 'low_taper_fade'
  | 'bro_flow'
  | 'modern_pompadour'
  | 'buzz_cut'
  | 'curly_undercut'
  | 'mid_fade_slick_back'
  | 'burst_fade'
  | 'french_crop_fade'
  | 'messy_quiff'
  | 'curtain_hair'
  | 'wolf_cut'
  | 'ivy_league'
  | 'crew_cut_textured'
  | 'side_part_clean'
  | 'natural_afro'
  | 'k_inspired'
  // 17 Women's Hairstyles
  | 'ultra_short_bob'
  | 'structured_bob'
  | 'french_bob'
  | 'bixie'
  | 'baby_bob'
  | 'floating_bob'
  | 'butterfly_cut'
  | 'birkin_layers'
  | 'face_framing_layers'
  | 'rebel_layers'
  | 'supermodel_blowout'
  | 'sculptural_updo'
  | 'side_part_woman'
  | 'butterfly_fringe'
  | 'poni_tebal'
  | 'wet_look_90s'
  | 'emo_fringe';

export interface AvatarConfig {
  gender: Gender;
  skinColor?: string;
  eyeColor?: string;
  hairStyle: HairStyleId;
  hairColor: string;
  shirtStyle?:
    | 'none'
    | 'tunic'
    | 'overalls'
    | 'vest'
    | 'sweater'
    | 'hoodie'
    | 'flannel'
    | 'jacket'
    | 'apron'
    | 'kimono'
    | 'polo';
  outfitColor: string;
  pantsStyle?:
    | 'none'
    | 'trousers'
    | 'shorts'
    | 'skirt'
    | 'denim'
    | 'cargos'
    | 'capri'
    | 'pleated_skirt'
    | 'leggings'
    | 'boots_pants';
  pantsColor?: string;
  hatStyle:
    | 'farmer_cap'
    | 'straw_hat'
    | 'flower_clip'
    | 'wizard_hat'
    | 'cowboy_hat'
    | 'beanie'
    | 'beret'
    | 'crown'
    | 'chef_hat'
    | 'sun_visor'
    | 'none';
  accessory: 'bandana' | 'glasses' | 'scarf' | 'bowtie' | 'sunglasses' | 'none';
}

export interface EggIncubatorSlot {
  slotIndex: number;
  eggPlacedDay: number | null;
  daysRemaining: number;
  readyToHatch: boolean;
}

export interface CharacterAnimConfig {
  playerWalkSpeed: number;
  playerRunSpeed: number;
  playerDefaultIdlePose: NpcIdlePose;
  npcIdleSpeed: number;
  defaultPlayerPreset: AvatarConfig;
}

export interface KeyBindings {
  forward: string;
  backward: string;
  left: string;
  right: string;
  sprint: string;
  dash: string;
  jump: string;
  social: string;
  execute: string;
  inventory: string;
  chat: string;
  openMenu?: string;
  openSettings?: string;
  toolSlot1: string;
  toolSlot2: string;
  toolSlot3: string;
  toolSlot4: string;
  toolSlot5: string;
  toolSlot6: string;
}

export interface OutfitDef {
  id: string;
  name: string;
  description: string;
  diamondPrice: number;
  shirtColor: string;
  pantsColor: string;
  accentColor: string;
  hatStyle?: AvatarConfig['hatStyle'];
}

export interface PlayerProfile {
  uid: string;
  avatarName: string;
  farmName: string;
  gender: Gender;
  birthday: string;
  dogName: string;
  horseName: string;
  avatarConfig: AvatarConfig;
  level: number;
  xp: number;
  fun: number;
  gold: number;
  diamond: number;
  theme?: ThemeMode;
  hasPhone?: boolean;
  hasCheeseMaker?: boolean;
  coopIncubators?: EggIncubatorSlot[];
  attendedFestivalKeys?: string[];
  bagUpgrades: number; // 0..11 (+6 slots each -> 24..90)
  houseLevel: number; // 1..3
  barnLevel: number; // 1..3
  coopLevel: number; // 1..3
  houseLocked: boolean;
  barnLocked: boolean;
  coopLocked: boolean;
  stableLocked?: boolean;
  lastResetHomeAt: number;
  barnBuilt: boolean;
  coopBuilt: boolean;
  secretGroveUnlocked: boolean;
  unlockedOutfits: string[];
  equippedOutfitId: string;
  toolShortcuts: string[];
  spouseId: string | null;
  spousePlayerUid: string | null;
  spousePlayerName: string | null;
  weddingDay: string | null;
  version: number;
}

export type ItemCategory = 'Tools' | 'Seeds' | 'Crops' | 'Livestock' | 'Materials' | 'Other';

export type MarketplaceCategory =
  | 'tools'
  | 'medicine'
  | 'food'
  | 'jewelry'
  | 'services'
  | 'crops'
  | 'materials'
  | 'other';

export interface P2PMarketListing {
  id: string;
  sellerUid: string;
  sellerName: string;
  itemId: string;
  itemName: string;
  category: MarketplaceCategory;
  quantity: number;
  diamondPrice: number;
  baseDiamondPrice?: number;
  sellerCharacterId?: string;
  sellerAccountId?: string;
  description: string;
  createdAt: number;
  status: 'active' | 'sold' | 'cancelled';
  buyerUid?: string;
  buyerName?: string;
  soldAt?: number;
}

export interface TransactionRecord {
  id: string;
  type: 'p2p_trade' | 'diamond_shop' | 'iap' | 'npc_trade' | 'job_payout' | 'admin_adjust';
  buyerUid: string;
  buyerName: string;
  sellerUid?: string;
  sellerName?: string;
  itemId?: string;
  itemName?: string;
  quantity?: number;
  currency: 'diamond' | 'gold';
  amount: number;
  taxAmount?: number;
  sellerNetAmount?: number;
  category?: string;
  description?: string;
  timestamp: number;
}

export interface FriendRecord {
  uid: string;
  avatarName: string;
  farmName?: string;
  since: number;
}

export interface FriendRequestRecord {
  id: string;
  fromUid: string;
  fromName: string;
  toUid: string;
  toName: string;
  createdAt: number;
}

export type ToolKind =
  | 'hoe'
  | 'watering_can'
  | 'axe'
  | 'hammer'
  | 'sickle'
  | 'fishing_rod'
  | 'milk_pail'
  | 'brush';

export interface ItemDef {
  id: string;
  name: string;
  category: ItemCategory;
  description: string;
  buyPrice: number;
  sellPrice: number;
  diamondPrice?: number;
  toolKind?: ToolKind;
  cropId?: string;
  staminaRestore?: number;
  isGiftable: boolean;
  isProposalItem?: boolean;
  isFoodStorable?: boolean;
  iconColor: string;
  iconEmoji: string;
}

export interface InventorySlot {
  itemId: string;
  quantity: number;
  toolLevel?: number; // 1=Basic, 2=Copper, 3=Silver, 4=Gold
  durability?: number;
  maxDurability?: number;
  diamondTradeable?: boolean;
}

export interface CropDef {
  id: string;
  name: string;
  seedId: string;
  harvestItemId: string;
  seasons: Season[];
  daysToGrow: number;
  regrowsAfterHarvest?: boolean;
  sellPrice: number;
  color: string;
  shape: 'root' | 'tall' | 'bush' | 'vine' | 'flower' | 'crystal';
}

export type FarmObstacleType =
  | 'weed'
  | 'root'
  | 'stump'
  | 'sapling'
  | 'tree'
  | 'large_tree'
  | 'rock'
  | 'large_rock';

export interface FarmPlotState {
  id: string; // "x_z"
  gx: number;
  gz: number;
  tilled: boolean;
  watered: boolean;
  cropId: string | null;
  growthDays: number;
  readyToHarvest: boolean;
  fertilized: boolean;
  obstacle?: FarmObstacleType | null;
  obstacleDays?: number;
}

export interface AppleTreeState {
  applesReady: number; // 0..3
  lastAppleDay: number;
  honeyReady: boolean;
  lastHoneyDay: number;
}

export type AnimalEmotion = 'happy' | 'relaxed' | 'scared' | 'hungry' | 'sleepy' | 'stressed' | 'sick';

export interface RegistrationNameConfig {
  farmerNames: string[];
  farmNames: string[];
  dogNames: string[];
  horseNames: string[];
  npcRandomNames: string[];
}

export interface AnimalState {
  id: string;
  type: 'cow' | 'chicken' | 'sheep' | 'dog' | 'horse';
  name: string;
  birthday?: string;
  bornYear?: number;
  fedToday: boolean;
  brushedToday: boolean;
  playedToday?: boolean;
  affection: number;
  hunger?: number; // 0..100 (100 = full)
  energy?: number; // 0..100
  happiness?: number; // 0..100
  health?: number; // 0..100
  daysUnfed?: number; // >= 3 triggers isSick = true
  isSick?: boolean;
  emotion?: AnimalEmotion;
  breedVariant?: number; // 0..3 visual breed/coat variety
  sizeScale?: number; // 0.92..1.10 natural body scale variety
  isOutside?: boolean;
  productReady: boolean;
  location: 'barn' | 'coop' | 'stable' | 'doghouse' | 'pasture';
  x: number;
  z: number;
}

export type FarmJobTaskType = 'water_crops' | 'feed_cow' | 'feed_sheep' | 'feed_horse' | 'feed_dog';

export interface FarmJobOffer {
  id: string;
  employerUid: string;
  employerName: string;
  farmName: string;
  wageGold: number;
  tasks: FarmJobTaskType[];
  cropCount?: number;
  animalCount?: number;
  targetCropCount?: number;
  targetAnimalCount?: number;
  totalUnits: number;
  completedTaskIds: string[];
  workerUid: string | null;
  workerName: string | null;
  status: 'open' | 'active' | 'in_progress' | 'completed' | 'cancelled';
  createdAt: number;
}

export interface DailyFunTracker {
  dayKey: string;
  onceKeys: string[];
  diminishingCounts: Record<string, number>;
}

export interface FloatingChatBubble {
  id: string;
  senderId: string;
  senderUid?: string;
  senderName: string;
  text: string;
  channel: ChatMessage['channel'];
  targetId?: string;
  isPrivate?: boolean;
  expiresAt: number;
}

export type FriendshipTier =
  | 'Stranger'
  | 'Acquaintance'
  | 'Friend'
  | 'Close Friend'
  | 'Best Friend';

export type RomanceStage =
  | 'Stranger'
  | 'Acquaintance'
  | 'Friend'
  | 'Close Friend'
  | 'Romantic Interest'
  | 'Partner'
  | 'Married';

export interface NPCRoutineSlot {
  startHour: number;
  endHour: number;
  zone: WorldZoneId;
  x: number;
  z: number;
  activity: 'idle' | 'work' | 'walk' | 'eat' | 'sleep' | 'social' | 'festival';
  label: string;
}

export interface NPCData {
  id: string;
  name: string;
  gender: Gender;
  age: number;
  category: 'Village Elder' | 'Merchant' | 'Specialist' | 'Marriage Candidate' | 'Child' | 'Mysterious';
  profession: string;
  personality: string;
  description: string;
  residence: string;
  homeZone: WorldZoneId;
  workZone: WorldZoneId;
  birthday: { season: Season; day: number };
  isMarriageCandidate: boolean;
  appearance: {
    skinColor: string;
    hairColor: string;
    hairStyle: AvatarConfig['hairStyle'];
    shirtStyle?: AvatarConfig['shirtStyle'];
    outfitColor: string;
    pantsStyle?: AvatarConfig['pantsStyle'];
    pantsColor?: string;
    hatStyle: AvatarConfig['hatStyle'];
    accessory: AvatarConfig['accessory'];
    scale: number;
    idlePose?: NpcIdlePose;
  };
  giftPrefs: {
    loved: string[];
    liked: string[];
    disliked: string[];
    hated: string[];
  };
  familyIds: string[];
  socialPartnerIds: string[];
  schedule: NPCRoutineSlot[];
  rainySchedule?: NPCRoutineSlot[];
  shopInventoryIds?: string[];
  specialService?: 'blacksmith' | 'carpenter' | 'clinic' | 'library' | 'magic' | 'ranch' | 'salon';
  dialogues: {
    greetingMorning: string[];
    greetingAfternoon: string[];
    greetingEvening: string[];
    rainy: string[];
    seasonal: Record<Season, string>;
    highFriendship: string[];
    birthday: string;
    romantic?: string[];
    married?: string[];
  };
}

export interface NPCMemory {
  lastGiftDay: string | null;
  giftsReceivedCount: number;
  favoriteGiftsRemembered: string[];
  completedQuests: string[];
  attendedFestivals: string[];
  talkedToday: boolean;
  giftedToday: boolean;
  lastInteractionNote: string;
}

export interface NPCRelationshipState {
  npcId: string;
  friendshipPoints: number; // 0 - 1000
  affectionPoints: number; // 0 - 1000
  heartLevel: number; // 0 - 10
  romanceStage: RomanceStage;
  eventsSeen: string[];
  memory: NPCMemory;
}

export interface DailyMission {
  id: string;
  title: string;
  description: string;
  type: 'plant' | 'water' | 'harvest' | 'talk_npc' | 'feed_animal' | 'catch_fish' | 'gather';
  target: number;
  progress: number;
  rewardGold: number;
  claimed: boolean;
}

export interface QuestDef {
  id: string;
  npcId: string;
  title: string;
  description: string;
  requiredItemId?: string;
  requiredQty?: number;
  rewardGold: number;
  rewardFriendship: number;
  unlocksFeature?: 'secret_grove' | 'magic_seeds' | 'advanced_farming' | 'rare_rod';
}

export interface AchievementDef {
  id: string;
  title: string;
  description: string;
  rewardGold: number;
  icon: string;
}

export interface FestivalDef {
  id: string;
  name: string;
  season: Season;
  day: number;
  startHour?: number;
  endHour?: number;
  activityLabel?: string;
  rewardGold?: number;
  hostNpcId: string;
  locationZone: WorldZoneId;
  description: string;
}

export interface ChatMessage {
  id: string;
  channel: 'global' | 'local' | 'private' | 'farm_visit' | 'event';
  senderId: string;
  senderName: string;
  targetId?: string;
  zone: WorldZoneId;
  text: string;
  timestamp: number;
}

export interface OnlinePlayerState {
  clientId: string;
  uid: string;
  avatarName: string;
  farmName: string;
  zone: WorldZoneId;
  farmOwnerId?: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  animState: 'idle' | 'walk' | 'run' | 'work' | 'jump' | 'swim';
  avatarConfig: AvatarConfig;
  level: number;
  spousePlayerName?: string | null;
}

export interface LeaderboardRecord {
  uid: string;
  avatarName: string;
  farmName: string;
  totalWealth: number;
  farmingLevel: number;
  cropsHarvested: number;
  animalsCount: number;
  fishCaught: number;
  achievementsCount: number;
  villageReputation: number;
  updatedAt: number;
}

export interface MarketPriceEntry {
  itemId: string;
  buyPrice: number;
  sellPrice: number;
  diamondPrice?: number;
  multiplier: number; // global market factor; may move below or above 1.00
  trend: 'up' | 'down' | 'stable';
  supply: number;
  demand: number;
}

export interface MarketState {
  prices: Record<string, MarketPriceEntry>;
  taxPool: number;
  taxPoolDiamond?: number;
  totalVolumeGold: number;
  updatedAt: number;
}

export interface IAPTransaction {
  transactionId: string;
  uid: string;
  provider: 'google_play' | 'duitku';
  packageId: string;
  diamondAmount: number;
  priceLabel: string;
  status: 'completed';
  timestamp: number;
}

export interface NotificationSettings {
  dailyMissions: boolean;
  achievements: boolean;
  rewards: boolean;
  specialEvents: boolean;
  multiplayer: boolean;
}

export interface SeasonalSalesBucket {
  qty: number;
  revenue: number;
}

export interface SalesStats {
  marketGoldBySeason: Record<Season, SeasonalSalesBucket>;
  marketGoldTotalQty: number;
  marketGoldTotalRevenue: number;
  p2pDiamondBySeason: Record<Season, SeasonalSalesBucket>;
  p2pDiamondTotalQty: number;
  p2pDiamondTotalRevenue: number;
}

export interface GameStats {
  cropsPlanted: number;
  cropsWatered: number;
  cropsHarvested: number;
  fishCaught: number;
  materialsGathered: number;
  totalGoldEarned: number;
  giftsGiven: number;
  festivalsAttended: number;
  salesStats?: SalesStats;
}
