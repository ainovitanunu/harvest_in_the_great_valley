import { auth } from './firebaseService';

import type {
  AdminInventoryUpdate,
  AvatarConfig,
  ChatMessage,
  FarmJobOffer,
  FarmJobTaskType,
  FarmPlotState,
  FriendRecord,
  FriendRequestRecord,
  IAPTransaction,
  LeaderboardRecord,
  MarketplaceCategory,
  MarketState,
  OnlinePlayerState,
  P2PMarketListing,
  PlayerBanRecord,
  RuntimeGameConfig,
  SalesStats,
  ThemeMode,
  TransactionRecord,
  WorldTreeRecord,
  WorldZoneId,
} from '../game/types';
import { getActiveSocialToken } from './nakamaAuthService';

export interface ServerNpcSync {
  id: string;
  zone: WorldZoneId;
  x: number;
  z: number;
  activity: string;
  label: string;
}

export interface MarriageProposalPayload {
  fromUid: string;
  fromName: string;
  fromFarmName: string;
  itemId: string;
}

export interface MarriageCompletedPayload {
  accepted: boolean;
  itemId?: string;
  partnerA?: { uid: string; name: string };
  partnerB?: { uid: string; name: string };
  byName?: string;
}

export interface CallParticipantInfo {
  uid: string;
  avatarName: string;
  mode: 'voice' | 'video';
  micOn: boolean;
  camOn: boolean;
  deviceType: 'mobile' | 'desktop';
}

export interface IncomingCallInvite {
  roomId: string;
  mode: 'voice' | 'video';
  isGroup: boolean;
  fromUid: string;
  fromName: string;
}

export interface JobSettlementPayload {
  jobId: string;
  employerUid: string;
  employerName: string;
  workerUid: string;
  workerName: string;
  farmName: string;
  wageGold: number;
  earnedGold: number;
  ratio: number;
  completionPercent: number;
}

type ListenerMap = {
  connected: (onlineCount: number) => void;
  disconnected: () => void;
  nameTaken: () => void;
  displayNameUpdated: (uid: string, avatarName: string) => void;
  peers: (peers: OnlinePlayerState[]) => void;
  peerMoved: (clientId: string, x: number, y: number, z: number, yaw: number, animState: OnlinePlayerState['animState']) => void;
  peerJoined: (player: OnlinePlayerState) => void;
  peerLeft: (clientId: string) => void;
  farmPlots: (plots: Record<string, FarmPlotState>, farmOwnerId: string) => void;
  plotDelta: (plot: FarmPlotState, farmOwnerId: string, actorName: string) => void;
  npcSync: (serverHour: number, npcStates: ServerNpcSync[]) => void;
  chat: (msg: ChatMessage) => void;
  chatHistory: (msgs: ChatMessage[]) => void;
  zoneDenied: (reason: string) => void;
  ownerLocks: (farmOwnerId: string, houseLocked: boolean, barnLocked: boolean, coopLocked: boolean, stableLocked: boolean) => void;
  marketUpdated: (market: MarketState, taxBuckets: Record<number, number>) => void;
  marriageProposal: (proposal: MarriageProposalPayload) => void;
  marriageCompleted: (res: MarriageCompletedPayload) => void;
  jobsUpdated: (jobs: FarmJobOffer[]) => void;
  jobSettled: (payload: JobSettlementPayload) => void;
  callRoomState: (roomId: string, participants: CallParticipantInfo[]) => void;
  callIncomingInvite: (invite: IncomingCallInvite) => void;
  callSignal: (roomId: string, fromUid: string, fromName: string, signal: unknown) => void;
  callEnded: (payload: { roomId: string; endedByUid: string; endedByName: string; reason: string }) => void;
  callError: (reason: string) => void;
  friendsUpdated: (friends: FriendRecord[], incoming: FriendRequestRecord[], outgoing: FriendRequestRecord[]) => void;
  p2pMarketUpdated: (listings: P2PMarketListing[]) => void;
  p2pItemSold: (payload: { listingId: string; itemName: string; quantity: number; diamondEarned: number; diamondBalance?: number; sellerCharacterId?: string; diamondTax?: number; buyerName: string }) => void;
  globalTreesUpdated: (trees: WorldTreeRecord[]) => void;
  runtimeConfigUpdated: (config: RuntimeGameConfig, triggerAnnouncement?: boolean) => void;
  adminPlayerSync: (override: {
    gold?: number;
    diamond?: number;
    theme?: ThemeMode;
    fun?: number;
    level?: number;
    stamina?: number;
    xp?: number;
    inventoryUpdates?: AdminInventoryUpdate[];
    animalHappiness?: Record<string, number>;
    salesStats?: SalesStats;
    avatarConfig?: Partial<AvatarConfig>;
    equippedItemId?: string;
    skills?: Record<string, number>;
  }) => void;
  guestExpired: (reason: string, durationMinutes: number) => void;
  banUpdated: (ban: PlayerBanRecord | null) => void;
  announcementPush: (announcement: RuntimeGameConfig['announcementBanner']) => void;
};

export class MultiplayerClient {
  private ws: WebSocket | null = null;
  private reconnectTimer: number | null = null;
  private listeners: Partial<{ [K in keyof ListenerMap]: Set<ListenerMap[K]> }> = {};
  private pendingMessages: unknown[] = [];
  private lastJoinPayload: Record<string, unknown> | null = null;
  private tokenProvider: (() => Promise<string>) | null = null;
  private manuallyClosed = false;
  private reconnectAttempts = 0;
  public clientId: string | null = null;
  public isConnected = false;

  on<K extends keyof ListenerMap>(event: K, fn: ListenerMap[K]): () => void {
    let set = this.listeners[event] as Set<ListenerMap[K]> | undefined;
    if (!set) {
      set = new Set<ListenerMap[K]>();
      (this.listeners as Record<keyof ListenerMap, Set<unknown> | undefined>)[event] = set as Set<unknown>;
    }
    set.add(fn);
    return () => {
      set?.delete(fn);
    };
  }

  private emit<K extends keyof ListenerMap>(event: K, ...args: Parameters<ListenerMap[K]>) {
    const set = this.listeners[event] as Set<(...a: Parameters<ListenerMap[K]>) => void> | undefined;
    if (!set) return;
    set.forEach((fn) => fn(...args));
  }

  connect(joinInfo: {
    uid: string;
    avatarName: string;
    farmName: string;
    zone: WorldZoneId;
    farmOwnerId: string;
    x: number;
    y: number;
    z: number;
    yaw: number;
    avatarConfig: AvatarConfig;
    level: number;
    houseLocked?: boolean;
    barnLocked?: boolean;
    coopLocked?: boolean;
    stableLocked?: boolean;
    spousePlayerName?: string | null;
  }, tokenProvider: () => Promise<string>) {
    this.manuallyClosed = false;
    this.lastJoinPayload = { type: 'auth:join', ...joinInfo };
    this.tokenProvider = tokenProvider;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }
    if (!navigator.onLine) {
      this.scheduleReconnect();
      return;
    }

    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${proto}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);
    this.ws = ws;

    ws.onopen = () => {
      void this.sendAuthenticatedJoin(ws);
    };

    ws.onmessage = (ev) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(ev.data);
      } catch {
        return;
      }
      const type = String(msg.type || '');
      if (type === 'auth:welcome') {
        this.isConnected = true;
        this.reconnectAttempts = 0;
        this.clientId = String(msg.clientId || '');
        this.emit('connected', Number(msg.onlineCount || 1));
        while (this.pendingMessages.length > 0 && ws.readyState === WebSocket.OPEN) {
          const queued = this.pendingMessages.shift();
          ws.send(JSON.stringify(queued));
        }
        this.emit('peers', (msg.peers as OnlinePlayerState[]) || []);
        if (msg.ownerLocks && typeof msg.ownerLocks === 'object') {
          const l = msg.ownerLocks as {
            houseLocked?: boolean;
            barnLocked?: boolean;
            coopLocked?: boolean;
            stableLocked?: boolean;
          };
          this.emit(
            'ownerLocks',
            String(this.lastJoinPayload?.farmOwnerId || ''),
            Boolean(l.houseLocked),
            l.barnLocked === undefined ? true : Boolean(l.barnLocked),
            l.coopLocked === undefined ? true : Boolean(l.coopLocked),
            l.stableLocked === undefined ? true : Boolean(l.stableLocked)
          );
        }
        if (msg.market) {
          this.emit('marketUpdated', msg.market as MarketState, (msg.taxBuckets as Record<number, number>) || { 1: 0, 2: 0, 3: 0 });
        }
        if (Array.isArray(msg.recentChat)) {
          this.emit('chatHistory', msg.recentChat as ChatMessage[]);
        }
        if (Array.isArray(msg.jobs)) {
          this.emit('jobsUpdated', msg.jobs as FarmJobOffer[]);
        }
        if (Array.isArray(msg.friends)) {
          this.emit(
            'friendsUpdated',
            msg.friends as FriendRecord[],
            (msg.incomingFriendRequests as FriendRequestRecord[]) || [],
            (msg.outgoingFriendRequests as FriendRequestRecord[]) || []
          );
        }
        if (Array.isArray(msg.p2pListings)) {
          this.emit('p2pMarketUpdated', msg.p2pListings as P2PMarketListing[]);
        }
        if (Array.isArray(msg.globalTrees)) {
          this.emit('globalTreesUpdated', msg.globalTrees as WorldTreeRecord[]);
        }
        if (msg.runtimeConfig && typeof msg.runtimeConfig === 'object') {
          this.emit('runtimeConfigUpdated', msg.runtimeConfig as RuntimeGameConfig, false);
        }
        if (msg.activeBan !== undefined) {
          this.emit('banUpdated', (msg.activeBan as PlayerBanRecord) || null);
        }
      } else if (type === 'zone:synced') {
        this.emit('peers', (msg.peers as OnlinePlayerState[]) || []);
        if (msg.ownerLocks && typeof msg.ownerLocks === 'object') {
          const l = msg.ownerLocks as {
            houseLocked?: boolean;
            barnLocked?: boolean;
            coopLocked?: boolean;
            stableLocked?: boolean;
          };
          this.emit(
            'ownerLocks',
            String(msg.farmOwnerId || ''),
            Boolean(l.houseLocked),
            l.barnLocked === undefined ? true : Boolean(l.barnLocked),
            l.coopLocked === undefined ? true : Boolean(l.coopLocked),
            l.stableLocked === undefined ? true : Boolean(l.stableLocked)
          );
        }
        if (msg.farmPlots) {
          this.emit('farmPlots', msg.farmPlots as Record<string, FarmPlotState>, String(msg.farmOwnerId || ''));
        }
      } else if (type === 'zone:denied') {
        this.emit('zoneDenied', String(msg.reason || 'Room access denied.'));
      } else if (type === 'security:locks_updated') {
        this.emit(
          'ownerLocks',
          String(msg.farmOwnerId || ''),
          Boolean(msg.houseLocked),
          msg.barnLocked === undefined ? true : Boolean(msg.barnLocked),
          msg.coopLocked === undefined ? true : Boolean(msg.coopLocked),
          msg.stableLocked === undefined ? true : Boolean(msg.stableLocked)
        );
      } else if (type === 'market:updated') {
        if (msg.market) {
          this.emit('marketUpdated', msg.market as MarketState, (msg.taxBuckets as Record<number, number>) || { 1: 0, 2: 0, 3: 0 });
        }
      } else if (type === 'marriage:proposal') {
        this.emit('marriageProposal', {
          fromUid: String(msg.fromUid || ''),
          fromName: String(msg.fromName || 'Farmer'),
          fromFarmName: String(msg.fromFarmName || 'Valley Farm'),
          itemId: String(msg.itemId || 'item_golden_ring'),
        });
      } else if (type === 'marriage:completed') {
        this.emit('marriageCompleted', {
          accepted: Boolean(msg.accepted),
          itemId: msg.itemId ? String(msg.itemId) : undefined,
          partnerA: msg.partnerA as { uid: string; name: string } | undefined,
          partnerB: msg.partnerB as { uid: string; name: string } | undefined,
          byName: msg.byName ? String(msg.byName) : undefined,
        });
      } else if (type === 'jobs:updated') {
        this.emit('jobsUpdated', (msg.jobs as FarmJobOffer[]) || []);
      } else if (type === 'job:settled') {
        this.emit('jobSettled', msg as unknown as JobSettlementPayload);
      } else if (type === 'call:room_state') {
        this.emit('callRoomState', String(msg.roomId || ''), (msg.participants as CallParticipantInfo[]) || []);
      } else if (type === 'call:incoming_invite') {
        this.emit('callIncomingInvite', {
          roomId: String(msg.roomId || ''),
          mode: msg.mode === 'video' ? 'video' : 'voice',
          isGroup: Boolean(msg.isGroup),
          fromUid: String(msg.fromUid || ''),
          fromName: String(msg.fromName || 'Farmer'),
        });
      } else if (type === 'call:signal') {
        this.emit('callSignal', String(msg.roomId || ''), String(msg.fromUid || ''), String(msg.fromName || 'Farmer'), msg.signal);
      } else if (type === 'call:ended') {
        this.emit('callEnded', {
          roomId: String(msg.roomId || ''),
          endedByUid: String(msg.endedByUid || ''),
          endedByName: String(msg.endedByName || 'Participant'),
          reason: String(msg.reason || 'hangup'),
        });
      } else if (type === 'call:error') {
        this.emit('callError', String(msg.reason || 'Call could not be started.'));
      } else if (type === 'runtime:config_updated') {
        if (msg.config && typeof msg.config === 'object') {
          this.emit('runtimeConfigUpdated', msg.config as RuntimeGameConfig, Boolean(msg.triggerAnnouncement));
        }
      } else if (type === 'friends:synced') {
        this.emit(
          'friendsUpdated',
          (msg.friends as FriendRecord[]) || [],
          (msg.incoming as FriendRequestRecord[]) || [],
          (msg.outgoing as FriendRequestRecord[]) || []
        );
      } else if (type === 'player:display_name') {
        this.emit('displayNameUpdated', String(msg.uid || ''), String(msg.avatarName || 'Farmer'));
      } else if (type === 'p2p:market_updated') {
        this.emit('p2pMarketUpdated', (msg.listings as P2PMarketListing[]) || []);
      } else if (type === 'p2p:item_sold') {
        this.emit('p2pItemSold', {
          listingId: String(msg.listingId || ''),
          itemName: String(msg.itemName || 'Item'),
          quantity: Number(msg.quantity || 1),
          diamondEarned: Number(msg.diamondEarned || 0),
          diamondBalance: typeof msg.diamondBalance === 'number' ? msg.diamondBalance : undefined,
          sellerCharacterId: msg.sellerCharacterId ? String(msg.sellerCharacterId) : undefined,
          diamondTax: typeof msg.diamondTax === 'number' ? msg.diamondTax : undefined,
          buyerName: String(msg.buyerName || 'Farmer'),
        });
      } else if (type === 'world:global_trees') {
        if (Array.isArray(msg.trees)) {
          this.emit('globalTreesUpdated', msg.trees as WorldTreeRecord[]);
        }
      } else if (type === 'admin:player_sync') {
        this.emit('adminPlayerSync', {
          gold: typeof msg.gold === 'number' ? msg.gold : undefined,
          diamond: typeof msg.diamond === 'number' ? msg.diamond : undefined,
          theme: msg.theme as ThemeMode | undefined,
          fun: typeof msg.fun === 'number' ? msg.fun : undefined,
          level: typeof msg.level === 'number' ? msg.level : undefined,
          stamina: typeof msg.stamina === 'number' ? msg.stamina : undefined,
          xp: typeof msg.xp === 'number' ? msg.xp : undefined,
          inventoryUpdates: Array.isArray(msg.inventoryUpdates)
            ? (msg.inventoryUpdates as AdminInventoryUpdate[])
            : undefined,
          animalHappiness:
            msg.animalHappiness && typeof msg.animalHappiness === 'object'
              ? (msg.animalHappiness as Record<string, number>)
              : undefined,
          salesStats:
            msg.salesStats && typeof msg.salesStats === 'object'
              ? (msg.salesStats as SalesStats)
              : undefined,
          avatarConfig:
            msg.avatarConfig && typeof msg.avatarConfig === 'object'
              ? (msg.avatarConfig as Partial<AvatarConfig>)
              : undefined,
          equippedItemId: typeof msg.equippedItemId === 'string' ? msg.equippedItemId : undefined,
          skills:
            msg.skills && typeof msg.skills === 'object'
              ? (msg.skills as Record<string, number>)
              : undefined,
        });
      } else if (type === 'player:banned') {
        this.emit('banUpdated', (msg.ban as PlayerBanRecord) || null);
      } else if (type === 'player:unbanned') {
        this.emit('banUpdated', null);
      } else if (type === 'announcement:push') {
        if (msg.announcement && typeof msg.announcement === 'object') {
          this.emit('announcementPush', msg.announcement as RuntimeGameConfig['announcementBanner']);
        }
      } else if (type === 'guest:expired') {
        this.emit(
          'guestExpired',
          String(msg.reason || 'Guest session time limit reached.'),
          Number(msg.durationMinutes || 60)
        );
      } else if (type === 'player:join') {
        this.emit('peerJoined', msg.player as OnlinePlayerState);
      } else if (type === 'player:leave') {
        this.emit('peerLeft', String(msg.clientId || ''));
      } else if (type === 'player:move') {
        this.emit(
          'peerMoved',
          String(msg.clientId || ''),
          Number(msg.x || 0),
          Number(msg.y || 0),
          Number(msg.z || 0),
          Number(msg.yaw || 0),
          (msg.animState as OnlinePlayerState['animState']) || 'idle'
        );
      } else if (type === 'farm:plots_updated') {
        this.emit('farmPlots', msg.plots as Record<string, FarmPlotState>, String(msg.farmOwnerId || ''));
      } else if (type === 'farm:plot_delta') {
        this.emit('plotDelta', msg.plot as FarmPlotState, String(msg.farmOwnerId || ''), String(msg.actorName || 'Friend'));
      } else if (type === 'npc:global_sync') {
        this.emit('npcSync', Number(msg.serverHour || 8), (msg.npcStates as ServerNpcSync[]) || []);
      } else if (type === 'chat:message') {
        this.emit('chat', msg.message as ChatMessage);
      }
    };

    ws.onclose = (event) => {
      if (this.ws === ws) this.ws = null;
      this.isConnected = false;
      this.emit('disconnected');
      if (!this.manuallyClosed) {
        console.warn(`[Multiplayer] WebSocket closed: code=${event.code}, reason=${event.reason || '(no reason)'}`);
      }
      if (event.code === 4409) this.emit('nameTaken');
      if (!this.manuallyClosed && event.code !== 4401 && event.code !== 4409) this.scheduleReconnect();
    };

    ws.onerror = () => {
      // Transient transport hiccups (server restart, proxy timeout, or offline mode)
      // trigger onclose right afterward with automatic exponential backoff reconnect.
      if (!this.manuallyClosed && this.reconnectAttempts === 0) {
        console.warn('[Multiplayer] WebSocket connection interrupted; reconnecting automatically...');
      }
    };
  }

  private async sendAuthenticatedJoin(ws: WebSocket) {
    try {
      if (!this.lastJoinPayload || !this.tokenProvider) throw new Error('Missing multiplayer authentication');
      const idToken = await this.tokenProvider();
      if (ws !== this.ws || ws.readyState !== WebSocket.OPEN) return;
      ws.send(JSON.stringify({ ...this.lastJoinPayload, idToken }));
    } catch (error) {
      console.warn('Multiplayer authentication could not complete:', error instanceof Error ? error.message : error);
      if (ws.readyState === WebSocket.OPEN) ws.close(4401, 'Authentication required');
    }
  }

  public resume() {
    if (this.isConnected || this.manuallyClosed || !this.lastJoinPayload || !this.tokenProvider) return;
    this.reconnectAttempts = 0;
    this.scheduleReconnect();
  }

  private scheduleReconnect() {
    if (this.reconnectTimer !== null) return;
    const delayMs = Math.min(20_000, 2000 * Math.pow(2, Math.min(this.reconnectAttempts, 4)));
    this.reconnectAttempts += 1;
    this.reconnectTimer = window.setTimeout(() => {
      this.reconnectTimer = null;
      if (!this.manuallyClosed && this.lastJoinPayload && navigator.onLine) {
        const p = this.lastJoinPayload as unknown as Parameters<MultiplayerClient['connect']>[0];
        if (this.tokenProvider) this.connect(p, this.tokenProvider);
      }
    }, delayMs);
  }

  send(payload: Record<string, unknown>, queueIfOffline = false) {
    if (this.isConnected && this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    } else if (queueIfOffline) {
      this.pendingMessages.push(payload);
    }
  }

  sendMove(x: number, y: number, z: number, yaw: number, animState: OnlinePlayerState['animState']) {
    if (this.isConnected && this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'player:move', x, y, z, yaw, animState }));
    }
  }

  changeZone(zone: WorldZoneId, farmOwnerId: string, x: number, z: number) {
    if (this.lastJoinPayload) {
      this.lastJoinPayload.zone = zone;
      this.lastJoinPayload.farmOwnerId = farmOwnerId;
      this.lastJoinPayload.x = x;
      this.lastJoinPayload.z = z;
    }
    this.send({ type: 'zone:change', zone, farmOwnerId, x, z }, true);
  }

  syncPlots(farmOwnerId: string, plots: Record<string, FarmPlotState>) {
    this.send({ type: 'farm:sync_plots', farmOwnerId, plots }, true);
  }

  sendFarmAction(farmOwnerId: string, plotId: string, gx: number, gz: number, action: string, cropId?: string) {
    this.send({ type: 'farm:action', farmOwnerId, plotId, gx, gz, action, cropId }, true);
  }

  sendChat(channel: ChatMessage['channel'], text: string, targetId?: string) {
    this.send({ type: 'chat:message', channel, text, targetId });
  }

  moderateUser(action: 'mute' | 'unmute' | 'block' | 'unblock', targetUid: string) {
    this.send({ type: 'chat:moderation', action, targetUid });
  }

  sendLockUpdate(houseLocked: boolean, barnLocked: boolean, coopLocked: boolean, stableLocked = true) {
    if (this.lastJoinPayload) {
      this.lastJoinPayload.houseLocked = houseLocked;
      this.lastJoinPayload.barnLocked = barnLocked;
      this.lastJoinPayload.coopLocked = coopLocked;
      this.lastJoinPayload.stableLocked = stableLocked;
    }
    this.send({ type: 'security:lock_update', houseLocked, barnLocked, coopLocked, stableLocked }, true);
  }

  sendMarriageProposal(targetUid: string, itemId: string) {
    this.send({ type: 'marriage:propose', targetUid, itemId });
  }

  sendMarriageResponse(fromUid: string, accepted: boolean, itemId: string) {
    this.send({ type: 'marriage:response', fromUid, accepted, itemId });
  }

  // Farm Jobs API
  createFarmJob(tasks: FarmJobTaskType[], wageGold: number, cropCount: number, animalCount: number) {
    this.send({ type: 'job:create', tasks, wageGold, cropCount, animalCount });
  }

  cancelFarmJob(jobId: string) {
    this.send({ type: 'job:cancel', jobId });
  }

  acceptFarmJob(jobId: string) {
    this.send({ type: 'job:accept', jobId });
  }

  reportJobProgress(jobId: string, taskKey: string) {
    this.send({ type: 'job:progress', jobId, taskKey });
  }

  completeFarmJob(jobId: string) {
    this.send({ type: 'job:complete', jobId });
  }

  // WebRTC Voice / Video / Group Call Signaling API
  joinCallRoom(roomId: string, mode: 'voice' | 'video', micOn: boolean, camOn: boolean, deviceType: 'mobile' | 'desktop') {
    this.send({ type: 'call:join', roomId, mode, micOn, camOn, deviceType });
  }

  leaveCallRoom() {
    this.send({ type: 'call:leave' });
  }

  updateCallMedia(roomId: string, micOn: boolean, camOn: boolean) {
    this.send({ type: 'call:media_state', roomId, micOn, camOn });
  }

  inviteToCall(roomId: string, mode: 'voice' | 'video', isGroup: boolean, targetUids: string[]) {
    this.send({ type: 'call:invite', roomId, mode, isGroup, targetUids });
  }

  sendCallSignal(roomId: string, targetUid: string, signal: unknown) {
    this.send({ type: 'call:signal', roomId, targetUid, signal });
  }

  sendCallPreviewFrame(roomId: string, frameDataUrl: string) {
    this.send({ type: 'call:preview_frame', roomId, frameDataUrl });
  }

  // Friend System (required for Friends-Only cross-zone calls & group calls)
  sendFriendRequest(targetUid: string, targetName: string) {
    this.send({ type: 'friend:request', targetUid, targetName });
  }

  respondFriendRequest(fromUid: string, accept: boolean) {
    this.send({ type: 'friend:respond', fromUid, accept });
  }

  removeFriend(targetUid: string) {
    this.send({ type: 'friend:remove', targetUid });
  }

  // Encrypted Player Snapshot Sync (Gold, Diamonds, Theme, Inventory count, Animals, Sales, Plots)
  syncPlayerSnapshot(snapshot: {
    gold: number;
    diamond: number;
    theme: ThemeMode;
    level: number;
    xp: number;
    fun: number;
    farmName: string;
    avatarName: string;
    inventorySummary: Array<{ itemId: string; quantity: number; diamondTradeable?: boolean }>;
    animalsCount: number;
    animals?: Array<{
      id: string;
      type: string;
      name: string;
      affection: number;
      fedToday: boolean;
      brushedToday: boolean;
      birthday?: string;
    }>;
    salesStats?: SalesStats;
    farmTreesCount?: number;
    cropsCount: number;
    hasPhone: boolean;
    loginType?: 'guest' | 'google' | 'email' | 'dev';
  }) {
    this.send({ type: 'player:snapshot', snapshot });
  }

  disconnect() {
    this.manuallyClosed = true;
    if (this.reconnectTimer !== null) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.isConnected = false;
  }
}

export async function fetchOnlinePlayers(): Promise<Array<{ clientId: string; uid: string; avatarName: string; farmName: string; zone: WorldZoneId; farmOwnerId: string; level: number; spousePlayerName?: string | null }>> {
  const res = await fetch('/api/multiplayer/players');
  if (!res.ok) return [];
  const data = await res.json();
  return data.players || [];
}

export async function fetchOpenFarmJobs(): Promise<FarmJobOffer[]> {
  try {
    const res = await fetch('/api/jobs');
    if (!res.ok) return [];
    const data = await res.json();
    return data.jobs || [];
  } catch {
    return [];
  }
}

export async function fetchGlobalTrees(): Promise<WorldTreeRecord[]> {
  try {
    const res = await fetch('/api/world/global-trees');
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data.trees) ? data.trees : [];
  } catch {
    return [];
  }
}

async function authenticatedHeaders(): Promise<Record<string, string>> {
  const socialToken = getActiveSocialToken();
  if (socialToken) {
    return {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${socialToken}`,
    };
  }
  const user = auth.currentUser;
  if (!user) throw new Error('Authentication required');
  return {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${await user.getIdToken()}`,
  };
}

export async function fetchMarketState(): Promise<{ market: MarketState; taxBuckets: Record<number, number> } | null> {
  try {
    const res = await fetch('/api/economy/market');
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

export async function transactMarketEconomy(
  action: 'buy' | 'sell',
  itemId: string,
  quantity: number,
  characterId?: string | null
): Promise<{
  ok: boolean;
  unitPrice: number;
  grossGold: number;
  taxGold: number;
  taxPercent?: number;
  netGold: number;
  market?: MarketState;
  taxBuckets?: Record<number, number>;
} | null> {
  try {
    const res = await fetch('/api/economy/transact', {
      method: 'POST',
      headers: await authenticatedHeaders(),
      body: JSON.stringify({ action, itemId, quantity, characterId }),
    });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

export async function claimTaxPoolReward(uid: string): Promise<{
  ok: boolean;
  rank?: number;
  claimedGold?: number;
  message?: string;
  error?: string;
  market?: MarketState;
  taxBuckets?: Record<number, number>;
}> {
  const res = await fetch('/api/economy/claim-tax', {
    method: 'POST',
    headers: await authenticatedHeaders(),
    body: JSON.stringify({ uid }),
  });
  return res.json();
}

export async function fetchServerLeaderboard(category: string): Promise<LeaderboardRecord[]> {
  const res = await fetch(`/api/leaderboard?category=${encodeURIComponent(category)}`);
  if (!res.ok) return [];
  const data = await res.json();
  return data.leaderboard || [];
}

export async function submitServerLeaderboard(record: Omit<LeaderboardRecord, 'updatedAt'>): Promise<void> {
  try {
    await fetch('/api/leaderboard/submit', {
      method: 'POST',
      headers: await authenticatedHeaders(),
      body: JSON.stringify(record),
    });
  } catch {
    // offline safe
  }
}

export async function purchaseDiamonds(
  uid: string,
  provider: 'google_play' | 'duitku',
  packageId: string
): Promise<{ ok: boolean; transaction?: IAPTransaction; error?: string }> {
  const idempotencyKey = `${uid}_${packageId}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const res = await fetch('/api/iap/purchase', {
    method: 'POST',
    headers: await authenticatedHeaders(),
    body: JSON.stringify({ uid, provider, packageId, idempotencyKey }),
  });
  return res.json();
}

export async function fetchIAPHistory(uid: string): Promise<IAPTransaction[]> {
  try {
    const res = await fetch(`/api/iap/history/${encodeURIComponent(uid)}`, { headers: await authenticatedHeaders() });
    if (!res.ok) return [];
    const data = await res.json();
    return data.transactions || [];
  } catch {
    return [];
  }
}

export async function reportChatMessage(reporterId: string, targetId: string, messageId: string, reason: string): Promise<void> {
  try {
    await fetch('/api/chat/report', {
      method: 'POST',
      headers: await authenticatedHeaders(),
      body: JSON.stringify({ reporterId, targetId, messageId, reason }),
    });
  } catch {
    // ignore offline
  }
}

// === P2P DIAMOND MARKETPLACE & ENCRYPTED TRANSACTION HISTORY ===
export async function fetchP2PMarketListings(category?: string, search?: string): Promise<P2PMarketListing[]> {
  try {
    const params = new URLSearchParams();
    if (category && category !== 'all') params.set('category', category);
    if (search) params.set('search', search);
    const qs = params.toString();
    const res = await fetch(`/api/p2p-market/listings${qs ? `?${qs}` : ''}`);
    if (!res.ok) return [];
    const data = await res.json();
    return data.listings || [];
  } catch {
    return [];
  }
}

export async function createP2PMarketListing(payload: {
  itemId: string;
  itemName: string;
  category: MarketplaceCategory;
  quantity: number;
  diamondPrice: number;
  description: string;
  sellerName: string;
  sellerCharacterId?: string | null;
}): Promise<{ ok: boolean; listing?: P2PMarketListing; error?: string }> {
  try {
    const res = await fetch('/api/p2p-market/list', {
      method: 'POST',
      headers: await authenticatedHeaders(),
      body: JSON.stringify(payload),
    });
    return res.json();
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : 'Network error' };
  }
}

export async function buyP2PMarketListing(
  listingId: string,
  buyerName: string,
  buyerCharacterId?: string | null
): Promise<{ ok: boolean; listing?: P2PMarketListing; transaction?: TransactionRecord; buyerDiamond?: number; error?: string }> {
  try {
    const res = await fetch('/api/p2p-market/buy', {
      method: 'POST',
      headers: await authenticatedHeaders(),
      body: JSON.stringify({ listingId, buyerName, buyerCharacterId }),
    });
    return res.json();
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : 'Network error' };
  }
}

export async function cancelP2PMarketListing(listingId: string): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch('/api/p2p-market/cancel', {
      method: 'POST',
      headers: await authenticatedHeaders(),
      body: JSON.stringify({ listingId }),
    });
    return res.json();
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : 'Network error' };
  }
}

export async function fetchMyTransactionHistory(): Promise<TransactionRecord[]> {
  try {
    const res = await fetch('/api/transactions/me', { headers: await authenticatedHeaders() });
    if (!res.ok) return [];
    const data = await res.json();
    return data.transactions || [];
  } catch {
    return [];
  }
}

export async function logPlayerTransaction(record: {
  type: TransactionRecord['type'];
  buyerName: string;
  sellerUid?: string;
  sellerName?: string;
  itemId?: string;
  itemName?: string;
  quantity?: number;
  currency: 'diamond' | 'gold';
  amount: number;
  category?: string;
  description?: string;
}): Promise<void> {
  try {
    await fetch('/api/transactions/record', {
      method: 'POST',
      headers: await authenticatedHeaders(),
      body: JSON.stringify(record),
    });
  } catch {
    // offline safe
  }
}
