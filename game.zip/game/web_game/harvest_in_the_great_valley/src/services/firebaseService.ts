import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  OAuthProvider,
  signInWithPopup,
  signInAnonymously,
  linkWithPopup,
  reauthenticateWithPopup,
  deleteUser,
  signOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  setDoc,
  deleteDoc,
  serverTimestamp,
  collection,
  getDocs,
  query,
  orderBy,
  limit,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { DEFAULT_TOOL_SHORTCUTS } from '../game/data/itemsAndCrops';
import type { AvatarConfig, Gender, LeaderboardRecord, PlayerProfile } from '../game/types';

export const DEVICE_ID_KEY = 'hgv_device_id_v1';
export const GUEST_META_KEY = 'hgv_guest_meta_v1';

export function getOrCreateDeviceId(): string {
  try {
    const existing = localStorage.getItem(DEVICE_ID_KEY);
    if (existing && existing.trim().length >= 6) return existing.trim();
    const randomPart =
      typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
        ? crypto.randomUUID().replace(/-/g, '').slice(0, 14)
        : Math.random().toString(36).slice(2, 16);
    const created = `dev_${randomPart}`;
    localStorage.setItem(DEVICE_ID_KEY, created);
    return created;
  } catch {
    return `dev_${Math.random().toString(36).slice(2, 12)}`;
  }
}

export interface GuestRandomIdentity {
  deviceId: string;
  avatarName: string;
  farmName: string;
  gender: Gender;
  birthday: string;
  dogName: string;
  horseName: string;
  avatarConfig: AvatarConfig;
}

/**
 * Generates a fresh randomized ephemeral Guest identity on every entry.
 * Uses a unique per-session random suffix so reloading always produces a clean slate.
 */
export function createGuestRandomizedIdentity(): GuestRandomIdentity {
  const randomPart =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID().replace(/-/g, '').slice(0, 8)
      : Math.random().toString(36).slice(2, 10);
  const deviceId = `guest_${randomPart}`;
  const suffix = randomPart.slice(-4).toUpperCase();
  const genders: Gender[] = ['male', 'female'];
  const gender = genders[Math.floor(Math.random() * genders.length)];
  const firstNames = ['Alden', 'Bram', 'Cora', 'Dahlia', 'Ezra', 'Faye', 'Gideon', 'Hazel', 'Kael', 'Luna', 'Milo', 'Nadia', 'Orin', 'Piper', 'Rowan', 'Sage'];
  const farmPrefixes = ['Sunny', 'Maple', 'Clover', 'Golden', 'Meadow', 'River', 'Pine', 'Oak', 'Honey', 'Star'];
  const farmSuffixes = ['Acres', 'Valley', 'Brook', 'Hollow', 'Orchard', 'Ridge', 'Haven', 'Grove'];
  const dogNames = ['Barnaby', 'Buddy', 'Milo', 'Scout', 'Biscuit', 'Coco', 'Pepper', 'Sunny'];
  const horseNames = ['Epona', 'Spirit', 'Clover', 'Copper', 'Chestnut', 'Willow', 'Comet', 'Starlight'];
  const seasons = ['Spring', 'Summer', 'Autumn', 'Winter'];
  const skinTones = ['#f6d2b6', '#e8b894', '#c98e62', '#8f5a38'];
  const hairStyles: AvatarConfig['hairStyle'][] = ['spiky', 'bob', 'ponytail', 'curly', 'braids', 'short'];
  const hairColors = ['#3b2416', '#78350f', '#1c1917', '#b45309', '#991b1b', '#d97706'];
  const outfitColors = ['#2563eb', '#16a34a', '#dc2626', '#7c3aed', '#d97706', '#0d9488'];
  const pantsColors = ['#1e3a8a', '#334155', '#44403c', '#365314'];
  const hatStyles: AvatarConfig['hatStyle'][] = ['none', 'farmer_cap', 'straw_hat', 'beanie'];
  const accessories: AvatarConfig['accessory'][] = ['none', 'bandana', 'glasses', 'scarf'];
  const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

  return {
    deviceId,
    avatarName: `${pick(firstNames)}_${suffix}`,
    farmName: `${pick(farmPrefixes)} ${pick(farmSuffixes)}`,
    gender,
    birthday: `${pick(seasons)} ${1 + Math.floor(Math.random() * 28)}`,
    dogName: pick(dogNames),
    horseName: pick(horseNames),
    avatarConfig: {
      gender,
      skinColor: pick(skinTones),
      eyeColor: '#292524',
      hairStyle: pick(hairStyles),
      hairColor: pick(hairColors),
      outfitColor: pick(outfitColors),
      pantsColor: pick(pantsColors),
      hatStyle: pick(hatStyles),
      accessory: pick(accessories),
    },
  };
}

export interface SavedSessionSummary {
  hasSession: boolean;
  sessionType: 'social' | 'guest' | 'none';
  uid?: string;
  avatarName?: string;
  farmName?: string;
  level?: number;
  gold?: number;
  diamond?: number;
  season?: string;
  day?: number;
  year?: number;
  email?: string | null;
  avatarConfig?: AvatarConfig;
}

/**
 * Guest accounts are strictly ephemeral and cleared on reload, so only verified
 * social sessions are ever returned as resumable sessions.
 */
export function detectSavedLoginSession(authUser?: User | null): SavedSessionSummary {
  const activeUser = authUser !== undefined ? authUser : auth.currentUser;
  let storedGuestFlag = false;
  try {
    storedGuestFlag = localStorage.getItem(GUEST_META_KEY) === 'guest';
  } catch {
    storedGuestFlag = false;
  }

  // Wipe any leftover guest data immediately so reloads always return to Dashboard cleanly
  if (storedGuestFlag || activeUser?.isAnonymous) {
    clearLocalSave();
    return { hasSession: false, sessionType: 'none' };
  }

  const local = loadLocalSave();
  const hasLocalProfile = Boolean(local && local.profile && local.profile.uid && local.profile.avatarName);

  if (activeUser && !activeUser.isAnonymous && hasLocalProfile && local) {
    return {
      hasSession: true,
      sessionType: 'social',
      uid: local.profile.uid,
      avatarName: local.profile.avatarName,
      farmName: local.profile.farmName,
      level: local.profile.level || 1,
      gold: local.profile.gold || 0,
      diamond: local.profile.diamond || 0,
      season: local.season || 'Spring',
      day: local.day || 1,
      year: local.year || 1,
      email: activeUser.email || null,
      avatarConfig: local.profile.avatarConfig,
    };
  }

  if (activeUser && !activeUser.isAnonymous) {
    return {
      hasSession: true,
      sessionType: 'social',
      uid: activeUser.uid,
      avatarName: activeUser.displayName || activeUser.email?.split('@')[0] || 'Farmer',
      email: activeUser.email || null,
    };
  }

  return { hasSession: false, sessionType: 'none' };
}

export function markLoginSessionType(type: 'guest' | 'social'): void {
  try {
    if (type === 'guest') {
      // Guest sessions must never persist across reloads
      clearLocalSave();
      return;
    }
    localStorage.setItem(GUEST_META_KEY, type);
  } catch {
    // ignore
  }
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firestore is currently offline; offline save queue active.');
      return false;
    }
    // Permission denied on /test/connection still proves server connectivity
    return true;
  }
}

export function subscribeAuth(cb: (user: User | null) => void): () => void {
  return onAuthStateChanged(auth, cb);
}

export async function signInWithGoogle(): Promise<User> {
  // Always sign in cleanly into Google (never link an ephemeral anonymous guest session)
  if (auth.currentUser?.isAnonymous) {
    await signOut(auth).catch(() => {});
  }
  const result = await signInWithPopup(auth, googleProvider);
  markLoginSessionType('social');
  return result.user;
}

export async function signInWithApple(): Promise<User> {
  if (auth.currentUser?.isAnonymous) {
    await signOut(auth).catch(() => {});
  }
  const appleProvider = new OAuthProvider('apple.com');
  appleProvider.addScope('email');
  appleProvider.addScope('name');
  const result = await signInWithPopup(auth, appleProvider);
  markLoginSessionType('social');
  return result.user;
}

export async function signInAsEphemeralGuest(): Promise<User> {
  clearLocalSave();
  if (auth.currentUser && !auth.currentUser.isAnonymous) {
    await signOut(auth).catch(() => {});
  }
  const user = auth.currentUser?.isAnonymous
    ? auth.currentUser
    : (await signInAnonymously(auth)).user;
  markLoginSessionType('guest');
  return user;
}

/** Ensures every multiplayer connection has a verifiable Firebase identity.
 * Guests receive an anonymous Firebase account; cloud saves remain gated by
 * email verification in the existing save pipeline and Firestore rules.
 */
export async function getMultiplayerAuth(): Promise<{ uid: string; idToken: string }> {
  const user = auth.currentUser ?? (await signInAnonymously(auth)).user;
  const idToken = await user.getIdToken(true);
  return { uid: user.uid, idToken };
}

export async function signOutPlayer(): Promise<void> {
  await signOut(auth);
  try {
    localStorage.removeItem(GUEST_META_KEY);
  } catch {
    // ignore
  }
}

export function clearLocalSave(): void {
  try {
    localStorage.removeItem(LOCAL_SAVE_KEY);
    localStorage.removeItem(OFFLINE_QUEUE_KEY);
    localStorage.removeItem(GUEST_META_KEY);
  } catch {
    // ignore storage errors
  }
}

/**
 * Hardened account deletion:
 * 1) Requires exact match with the signed-in account email,
 * 2) Forces live Google re-authentication via popup to prove active account ownership,
 * 3) Purges game server encrypted vault & Firestore documents, clears local save,
 * 4) Permanently deletes the Firebase Auth account.
 */
export async function reauthenticateAndDeleteAccount(confirmEmail: string): Promise<void> {
  const user = auth.currentUser;
  if (!user || user.isAnonymous || !user.email) {
    throw new Error('No signed-in Google account found.');
  }

  const normalizedInput = confirmEmail.trim().toLowerCase();
  const actualEmail = user.email.trim().toLowerCase();
  if (!normalizedInput || normalizedInput !== actualEmail) {
    throw new Error('Entered email does not match your signed-in account email.');
  }

  // Force Google account re-authentication so accidental/unauthorized deletion is impossible
  const reauthProvider = new GoogleAuthProvider();
  reauthProvider.setCustomParameters({ login_hint: user.email, prompt: 'select_account' });
  await reauthenticateWithPopup(user, reauthProvider);

  const uid = user.uid;
  const freshToken = await user.getIdToken(true);

  // 1) Purge server-side encrypted snapshot, P2P listings, friends, jobs
  try {
    await fetch('/api/account/me', {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${freshToken}`,
      },
    });
  } catch {
    // Continue cloud deletion even if multiplayer server is offline
  }

  // 2) Delete Firestore subcollections & user/leaderboard docs
  const safeDelete = async (ref: ReturnType<typeof doc>) => {
    try {
      await deleteDoc(ref);
    } catch {
      // Ignore missing document or offline failure before Auth deletion
    }
  };
  await safeDelete(doc(db, 'users', uid, 'farmSaves', 'main'));
  await safeDelete(doc(db, 'leaderboard', uid));
  await safeDelete(doc(db, 'users', uid));

  // 3) Clear local browser save
  clearLocalSave();

  // 4) Permanently delete Firebase Auth user
  await deleteUser(user);
}

export interface OfflineSaveSnapshot {
  profile: PlayerProfile;
  season: string;
  day: number;
  year: number;
  payload: Record<string, unknown>;
  dirtyProfile: boolean;
  dirtyFarm: boolean;
  queuedAt: number;
  saveRevision?: number;
  offlineSaved?: boolean;
}

interface EncryptedOfflineVaultRecord {
  v: 2;
  uid: string;
  revision: number;
  updatedAt: number;
  iv: string;
  ciphertext: string;
  integrityHash: string;
}

const LOCAL_SAVE_KEY = 'hgv_local_save_v1';
const ENCRYPTED_VAULT_KEY = 'hgv_secure_offline_vault_v2';
const OFFLINE_QUEUE_KEY = 'hgv_offline_queue_v1';
const SAVE_REVISION_KEY = 'hgv_save_revision_v2';

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function base64ToBytes(b64: string): Uint8Array {
  const binary = atob(b64);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

async function deriveOfflineVaultKey(uid: string): Promise<CryptoKey | null> {
  if (typeof crypto === 'undefined' || !crypto.subtle) return null;
  const deviceId = getOrCreateDeviceId();
  const material = new TextEncoder().encode(`HGV-VAULT-V2::${uid}::${deviceId}`);
  const digest = await crypto.subtle.digest('SHA-256', material);
  return crypto.subtle.importKey('raw', digest, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
}

async function computeVaultIntegrityHash(uid: string, revision: number, ivB64: string, cipherB64: string): Promise<string> {
  if (typeof crypto === 'undefined' || !crypto.subtle) return '';
  const deviceId = getOrCreateDeviceId();
  const input = new TextEncoder().encode(`HGV-HMAC-V2::${uid}::${deviceId}::${revision}::${ivB64}::${cipherB64}`);
  const hash = await crypto.subtle.digest('SHA-256', input);
  return Array.from(new Uint8Array(hash))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

export function getNextSaveRevision(): number {
  try {
    const prev = Number(localStorage.getItem(SAVE_REVISION_KEY) || '0') || 0;
    const next = prev + 1;
    localStorage.setItem(SAVE_REVISION_KEY, String(next));
    return next;
  } catch {
    return Date.now();
  }
}

export async function saveEncryptedOfflineVault(snapshot: OfflineSaveSnapshot): Promise<boolean> {
  try {
    const uid = snapshot.profile?.uid || 'local';
    if (uid.startsWith('guest_')) return false; // Never persist ephemeral guest data
    const revision = snapshot.saveRevision ?? getNextSaveRevision();
    const enriched: OfflineSaveSnapshot = {
      ...snapshot,
      saveRevision: revision,
      offlineSaved: !navigator.onLine,
    };
    const key = await deriveOfflineVaultKey(uid);
    if (!key) {
      saveLocalSnapshot(enriched);
      return false;
    }
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const plaintext = new TextEncoder().encode(JSON.stringify(enriched));
    const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, plaintext);
    const ivB64 = bytesToBase64(iv);
    const cipherB64 = bytesToBase64(new Uint8Array(encrypted));
    const integrityHash = await computeVaultIntegrityHash(uid, revision, ivB64, cipherB64);
    const record: EncryptedOfflineVaultRecord = {
      v: 2,
      uid,
      revision,
      updatedAt: Date.now(),
      iv: ivB64,
      ciphertext: cipherB64,
      integrityHash,
    };
    localStorage.setItem(ENCRYPTED_VAULT_KEY, JSON.stringify(record));
    // Also keep backward-compatible local cache mirror for synchronous boot hydration
    localStorage.setItem(LOCAL_SAVE_KEY, JSON.stringify(enriched));
    return true;
  } catch {
    return false;
  }
}

export async function loadEncryptedOfflineVault(
  expectedUid?: string
): Promise<{ snapshot: OfflineSaveSnapshot | null; tampered: boolean; revision: number }> {
  try {
    const raw = localStorage.getItem(ENCRYPTED_VAULT_KEY);
    if (!raw) return { snapshot: loadLocalSave(), tampered: false, revision: 0 };
    const record = JSON.parse(raw) as EncryptedOfflineVaultRecord;
    if (!record || record.v !== 2 || !record.iv || !record.ciphertext) {
      return { snapshot: null, tampered: true, revision: 0 };
    }
    const uid = expectedUid || record.uid;
    if (expectedUid && record.uid !== expectedUid) {
      return { snapshot: null, tampered: false, revision: 0 };
    }
    const expectedHash = await computeVaultIntegrityHash(uid, record.revision, record.iv, record.ciphertext);
    if (!expectedHash || expectedHash !== record.integrityHash) {
      console.warn('[OfflineVault] Tamper detected: integrity hash mismatch. Discarding local offline cache.');
      localStorage.removeItem(ENCRYPTED_VAULT_KEY);
      return { snapshot: null, tampered: true, revision: 0 };
    }
    const key = await deriveOfflineVaultKey(uid);
    if (!key) return { snapshot: loadLocalSave(), tampered: false, revision: record.revision };
    const iv = base64ToBytes(record.iv);
    const cipher = base64ToBytes(record.ciphertext);
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: iv as Uint8Array<ArrayBuffer> },
      key,
      cipher as Uint8Array<ArrayBuffer>
    );
    const parsed = JSON.parse(new TextDecoder().decode(decrypted)) as OfflineSaveSnapshot;
    return { snapshot: parsed, tampered: false, revision: record.revision };
  } catch {
    return { snapshot: null, tampered: true, revision: 0 };
  }
}

export async function syncOfflineVaultToServer(
  snapshot: OfflineSaveSnapshot,
  authToken?: string | null
): Promise<{ accepted: boolean; reason?: string; authoritativeRevision?: number; clampedFields?: string[] }> {
  if (!navigator.onLine) return { accepted: false, reason: 'offline' };
  const uid = snapshot.profile?.uid;
  if (!uid || uid.startsWith('guest_')) return { accepted: false, reason: 'guest_not_synced' };
  try {
    let token = authToken || null;
    if (!token && auth.currentUser && !auth.currentUser.isAnonymous) {
      token = await auth.currentUser.getIdToken(false).catch(() => null);
    }
    if (!token) return { accepted: false, reason: 'unauthenticated' };
    const revision = snapshot.saveRevision ?? getNextSaveRevision();
    const res = await fetch('/api/save/sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        uid,
        saveRevision: revision,
        season: snapshot.season,
        day: snapshot.day,
        year: snapshot.year,
        profile: {
          avatarName: snapshot.profile.avatarName,
          farmName: snapshot.profile.farmName,
          level: snapshot.profile.level,
          xp: snapshot.profile.xp,
          gold: snapshot.profile.gold,
          diamond: snapshot.profile.diamond,
          version: snapshot.profile.version,
        },
        payload: snapshot.payload,
        queuedAt: snapshot.queuedAt,
      }),
    });
    if (!res.ok) {
      const errBody = await res.json().catch(() => ({}));
      return { accepted: false, reason: String((errBody as { error?: string }).error || `HTTP ${res.status}`) };
    }
    const data = (await res.json()) as {
      ok?: boolean;
      authoritativeRevision?: number;
      clampedFields?: string[];
    };
    if (data.ok) {
      clearOfflineSyncQueue();
      return {
        accepted: true,
        authoritativeRevision: data.authoritativeRevision ?? revision,
        clampedFields: data.clampedFields || [],
      };
    }
    return { accepted: false, reason: 'rejected' };
  } catch (err) {
    return { accepted: false, reason: err instanceof Error ? err.message : 'network_error' };
  }
}

export function loadLocalSave(): OfflineSaveSnapshot | null {
  try {
    const raw = localStorage.getItem(LOCAL_SAVE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as OfflineSaveSnapshot;
  } catch {
    return null;
  }
}

export function saveLocalSnapshot(snapshot: OfflineSaveSnapshot): void {
  try {
    const uid = snapshot.profile?.uid || '';
    if (uid.startsWith('guest_')) return;
    localStorage.setItem(LOCAL_SAVE_KEY, JSON.stringify(snapshot));
    void saveEncryptedOfflineVault(snapshot);
  } catch {
    // ignore quota errors
  }
}

export function enqueueOfflineSync(snapshot: OfflineSaveSnapshot): void {
  try {
    const uid = snapshot.profile?.uid || '';
    if (uid.startsWith('guest_')) return;
    localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(snapshot));
    void saveEncryptedOfflineVault(snapshot);
  } catch {
    // ignore
  }
}

export function getQueuedOfflineSync(): OfflineSaveSnapshot | null {
  try {
    const raw = localStorage.getItem(OFFLINE_QUEUE_KEY);
    return raw ? (JSON.parse(raw) as OfflineSaveSnapshot) : null;
  } catch {
    return null;
  }
}

export function clearOfflineSyncQueue(): void {
  try {
    localStorage.removeItem(OFFLINE_QUEUE_KEY);
  } catch {
    // ignore
  }
}

export async function loadCloudSave(uid: string): Promise<{
  profile: PlayerProfile | null;
  farmSave: { version: number; season: string; day: number; year: number; payload: Record<string, unknown> } | null;
}> {
  if (!auth.currentUser || auth.currentUser.uid !== uid) {
    return { profile: null, farmSave: null };
  }
  const userPath = `users/${uid}`;
  const savePath = `users/${uid}/farmSaves/main`;
  let profile: PlayerProfile | null = null;
  let farmSave: { version: number; season: string; day: number; year: number; payload: Record<string, unknown> } | null = null;

  try {
    const userSnap = await getDoc(doc(db, 'users', uid));
    if (userSnap.exists()) {
      const d = userSnap.data();
      profile = {
        uid: String(d.uid),
        avatarName: String(d.avatarName),
        farmName: String(d.farmName),
        gender: d.gender === 'female' ? 'female' : 'male',
        birthday: String(d.birthday),
        dogName: String(d.dogName),
        horseName: String(d.horseName),
        avatarConfig: {
          gender: d.gender === 'female' ? 'female' : 'male',
          skinColor: '#fcd5b5',
          eyeColor: '#292524',
          hairStyle: (d.hairStyle || 'spiky') as PlayerProfile['avatarConfig']['hairStyle'],
          hairColor: String(d.hairColor || '#78350f'),
          outfitColor: String(d.outfitColor || '#2563eb'),
          pantsColor: '#1e3a8a',
          hatStyle: (d.hatStyle || 'farmer_cap') as PlayerProfile['avatarConfig']['hatStyle'],
          accessory: (d.accessory || 'bandana') as PlayerProfile['avatarConfig']['accessory'],
        },
        level: Number(d.level || 1),
        xp: 0,
        fun: 25,
        gold: Number(d.gold || 500),
        diamond: Number(d.diamond || 0),
        bagUpgrades: 0,
        houseLevel: 1,
        barnLevel: 1,
        coopLevel: 1,
        houseLocked: false,
        barnLocked: true,
        coopLocked: true,
        unlockedOutfits: ['outfit_classic'],
        equippedOutfitId: 'outfit_classic',
        toolShortcuts: [...DEFAULT_TOOL_SHORTCUTS],
        lastResetHomeAt: 0,
        barnBuilt: true,
        coopBuilt: true,
        secretGroveUnlocked: false,
        spouseId: null,
        spousePlayerUid: null,
        spousePlayerName: null,
        weddingDay: null,
        version: Number(d.version || 1),
      };
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, userPath);
  }

  try {
    const saveSnap = await getDoc(doc(db, 'users', uid, 'farmSaves', 'main'));
    if (saveSnap.exists()) {
      const s = saveSnap.data();
      farmSave = {
        version: Number(s.version || 1),
        season: String(s.season || 'Spring'),
        day: Number(s.day || 1),
        year: Number(s.year || 1),
        payload: (s.payload || {}) as Record<string, unknown>,
      };
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, savePath);
  }

  return { profile, farmSave };
}

/**
 * Uploads only changed sections (profile / farm / leaderboard) and resolves conflicts safely:
 * if Cloud Save has a newer version than local, offline progress cannot blindly overwrite newer multiplayer/server state.
 */
export async function syncToFirebaseCloud(
  snapshot: OfflineSaveSnapshot,
  stats: {
    cropsHarvested: number;
    animalsCount: number;
    fishCaught: number;
    achievementsCount: number;
    villageReputation: number;
  }
): Promise<{ synced: boolean; conflictResolved: boolean; cloudVersion: number }> {
  const user = auth.currentUser;
  if (!user || !user.emailVerified || !navigator.onLine) {
    enqueueOfflineSync(snapshot);
    return { synced: false, conflictResolved: false, cloudVersion: snapshot.profile.version };
  }

  const uid = user.uid;
  const userPath = `users/${uid}`;
  const savePath = `users/${uid}/farmSaves/main`;
  let nextVersion = Math.max(1, snapshot.profile.version);
  let conflictResolved = false;

  try {
    const existingSnap = await getDoc(doc(db, 'users', uid));
    const existingFarmSnap = await getDoc(doc(db, 'users', uid, 'farmSaves', 'main'));
    const cloudProfileVersion = existingSnap.exists() ? Number(existingSnap.data().version || 0) : 0;
    const cloudFarmVersion = existingFarmSnap.exists() ? Number(existingFarmSnap.data().version || 0) : 0;
    const highestCloudVersion = Math.max(cloudProfileVersion, cloudFarmVersion);
    if (highestCloudVersion >= nextVersion) conflictResolved = true;
    // Firestore rules require every update to strictly advance the existing version.
    nextVersion = Math.max(nextVersion, cloudProfileVersion + 1, cloudFarmVersion + 1);

    if (snapshot.dirtyProfile || !existingSnap.exists()) {
      const p = snapshot.profile;
      await setDoc(
        doc(db, 'users', uid),
        {
          uid,
          avatarName: p.avatarName.slice(0, 32),
          farmName: p.farmName.slice(0, 40),
          gender: p.gender,
          birthday: p.birthday.slice(0, 32),
          dogName: p.dogName.slice(0, 24),
          horseName: p.horseName.slice(0, 24),
          level: Math.max(1, Math.floor(p.level)),
          gold: Math.max(0, Math.floor(p.gold)),
          diamond: Math.max(0, Math.floor(p.diamond)),
          hairStyle: p.avatarConfig.hairStyle.slice(0, 24),
          hairColor: p.avatarConfig.hairColor.slice(0, 16),
          outfitColor: p.avatarConfig.outfitColor.slice(0, 16),
          hatStyle: p.avatarConfig.hatStyle.slice(0, 24),
          accessory: p.avatarConfig.accessory.slice(0, 24),
          version: nextVersion,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
    }
  } catch (error) {
    enqueueOfflineSync(snapshot);
    handleFirestoreError(error, OperationType.WRITE, userPath);
  }

  if (snapshot.dirtyFarm) {
    try {
      await setDoc(
        doc(db, 'users', uid, 'farmSaves', 'main'),
        {
          uid,
          saveId: 'main',
          version: nextVersion,
          season: snapshot.season,
          day: Math.max(1, Math.floor(snapshot.day)),
          year: Math.max(1, Math.floor(snapshot.year)),
          payload: snapshot.payload,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
    } catch (error) {
      enqueueOfflineSync(snapshot);
      handleFirestoreError(error, OperationType.WRITE, savePath);
    }
  }

  try {
    await setDoc(
      doc(db, 'leaderboard', uid),
      {
        uid,
        avatarName: snapshot.profile.avatarName.slice(0, 32),
        farmName: snapshot.profile.farmName.slice(0, 40),
        totalWealth: Math.max(0, Math.floor(snapshot.profile.gold + snapshot.profile.diamond * 50)),
        farmingLevel: Math.max(1, Math.floor(snapshot.profile.level)),
        cropsHarvested: Math.max(0, Math.floor(stats.cropsHarvested)),
        animalsCount: Math.max(0, Math.floor(stats.animalsCount)),
        fishCaught: Math.max(0, Math.floor(stats.fishCaught)),
        achievementsCount: Math.max(0, Math.floor(stats.achievementsCount)),
        villageReputation: Math.max(0, Math.floor(stats.villageReputation)),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `leaderboard/${uid}`);
  }

  clearOfflineSyncQueue();
  return { synced: true, conflictResolved, cloudVersion: nextVersion };
}

export async function fetchFirestoreLeaderboard(): Promise<LeaderboardRecord[]> {
  if (!auth.currentUser) return [];
  const path = 'leaderboard';
  try {
    const q = query(collection(db, path), orderBy('totalWealth', 'desc'), limit(25));
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const data = d.data();
      return {
        uid: String(data.uid),
        avatarName: String(data.avatarName),
        farmName: String(data.farmName),
        totalWealth: Number(data.totalWealth || 0),
        farmingLevel: Number(data.farmingLevel || 1),
        cropsHarvested: Number(data.cropsHarvested || 0),
        animalsCount: Number(data.animalsCount || 0),
        fishCaught: Number(data.fishCaught || 0),
        achievementsCount: Number(data.achievementsCount || 0),
        villageReputation: Number(data.villageReputation || 0),
        updatedAt: Date.now(),
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}
