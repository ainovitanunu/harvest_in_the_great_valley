import { CallParticipantInfo, MultiplayerClient } from './multiplayerClient';
import { VIDEO_CALL_CONFIG } from '../game/data/gameRuntimeConfig';
import type { VideoCallConfig } from '../game/types';

export type DeviceKind = 'mobile' | 'desktop';
export type MediaPermState = 'granted' | 'prompt' | 'denied' | 'unsupported' | 'unknown';

export interface DeviceProfile {
  kind: DeviceKind;
  isPhone: boolean;
  isSmallScreen: boolean;
  hasTouch: boolean;
  coarsePointer: boolean;
  noHover: boolean;
  width: number;
  height: number;
  screenWidth: number;
  screenHeight: number;
  dpr: number;
  orientation: 'portrait' | 'landscape';
  detectionConfidence: 'high' | 'medium' | 'low';
  detectionReason: string;
}

export interface MediaPermissionStatus {
  mic: MediaPermState;
  cam: MediaPermState;
  hasMicHardware: boolean;
  hasCamHardware: boolean;
  needsPermissionPrompt: boolean;
  secureContext: boolean;
}

export interface CallStateSnapshot {
  inCall: boolean;
  roomId: string | null;
  mode: 'voice' | 'video';
  isGroup: boolean;
  deviceType: DeviceKind;
  facingMode: 'user' | 'environment';
  micOn: boolean;
  camOn: boolean;
  localStream: MediaStream | null;
  remoteStreams: Record<string, MediaStream>;
  participants: CallParticipantInfo[];
  speakingUids: string[];
  connectionStates: Record<string, string>;
  error: string | null;
  permissions: MediaPermissionStatus;
  videoConfig: VideoCallConfig;
}

interface PeerEntry {
  pc: RTCPeerConnection;
  polite: boolean;
  makingOffer: boolean;
  ignoreOffer: boolean;
  isSettingRemoteAnswerPending: boolean;
  pendingIce: RTCIceCandidateInit[];
  restartCount: number;
}

interface VadNode {
  source: MediaStreamAudioSourceNode;
  analyser: AnalyserNode;
  data: Uint8Array<ArrayBuffer>;
  streamId: string;
}

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
    { urls: 'stun:stun.cloudflare.com:3478' },
  ],
  iceCandidatePoolSize: 4,
};

/**
 * Strict multi-signal screen-size & hardware device detection.
 * Evaluates Client Hints (userAgentData.mobile), Mobile/Tablet UA, iPadOS desktop-UA spoof,
 * pointer/hover hardware media queries, touch capabilities, and viewport/physical screen geometry.
 */
export function detectDeviceProfile(): DeviceProfile {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') {
    return {
      kind: 'desktop',
      isPhone: false,
      isSmallScreen: false,
      hasTouch: false,
      coarsePointer: false,
      noHover: false,
      width: 1280,
      height: 720,
      screenWidth: 1280,
      screenHeight: 720,
      dpr: 1,
      orientation: 'landscape',
      detectionConfidence: 'low',
      detectionReason: 'ssr_fallback',
    };
  }
  const width = window.innerWidth || document.documentElement.clientWidth || 1280;
  const height = window.innerHeight || document.documentElement.clientHeight || 720;
  const screenWidth = window.screen?.width || width;
  const screenHeight = window.screen?.height || height;
  const dpr = window.devicePixelRatio || 1;
  const minViewport = Math.min(width, height);
  const maxViewport = Math.max(width, height);
  const minScreen = Math.min(screenWidth, screenHeight);

  const ua = navigator.userAgent || '';
  const uaDataMobile = Boolean((navigator as Navigator & { userAgentData?: { mobile?: boolean } }).userAgentData?.mobile);
  const coarsePointer = window.matchMedia?.('(pointer: coarse)').matches ?? false;
  const anyCoarsePointer = window.matchMedia?.('(any-pointer: coarse)').matches ?? false;
  const finePointer = window.matchMedia?.('(pointer: fine)').matches ?? false;
  const noHover = window.matchMedia?.('(hover: none)').matches ?? false;
  const maxTouch = navigator.maxTouchPoints || 0;
  const hasTouch = maxTouch > 0 || 'ontouchstart' in window;

  const mobileUa = /Android|webOS|iPhone|iPod|BlackBerry|Windows Phone|Mobile|Opera Mini|IEMobile|HarmonyOS/i.test(ua);
  const ipadSpoof = navigator.platform === 'MacIntel' && maxTouch > 1;
  const tabletUa = /iPad|Tablet|Silk|Kindle|PlayBook/i.test(ua) || ipadSpoof;

  const touchOnlySmallHardware =
    hasTouch && (coarsePointer || (anyCoarsePointer && noHover)) && !finePointer && minScreen <= 1024;
  const mobileScreenShape = hasTouch && noHover && minViewport <= 640 && maxViewport <= 1024;

  let isPhone = false;
  let detectionConfidence: 'high' | 'medium' | 'low' = 'high';
  let detectionReason = 'desktop_fine_pointer';

  if (uaDataMobile || mobileUa) {
    isPhone = true;
    detectionConfidence = 'high';
    detectionReason = uaDataMobile ? 'client_hints_mobile' : 'mobile_user_agent';
  } else if (tabletUa) {
    isPhone = true;
    detectionConfidence = 'high';
    detectionReason = ipadSpoof ? 'ipados_touch_tablet' : 'tablet_user_agent';
  } else if (touchOnlySmallHardware || mobileScreenShape) {
    isPhone = true;
    detectionConfidence = 'medium';
    detectionReason = 'coarse_touch_screen_geometry';
  } else if (hasTouch && coarsePointer && minViewport <= 820) {
    isPhone = true;
    detectionConfidence = 'medium';
    detectionReason = 'compact_touch_viewport';
  } else if (width < 768 && !finePointer) {
    isPhone = true;
    detectionConfidence = 'low';
    detectionReason = 'narrow_non_mouse_viewport';
  }

  const isSmallScreen = width < 820 || height < 540;
  return {
    kind: isPhone ? 'mobile' : 'desktop',
    isPhone,
    isSmallScreen,
    hasTouch,
    coarsePointer,
    noHover,
    width,
    height,
    screenWidth,
    screenHeight,
    dpr,
    orientation: width >= height ? 'landscape' : 'portrait',
    detectionConfidence,
    detectionReason,
  };
}

export function detectDeviceKind(): DeviceKind {
  return detectDeviceProfile().kind;
}

export async function probeMediaPermissions(): Promise<MediaPermissionStatus> {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices) {
    return {
      mic: 'unsupported',
      cam: 'unsupported',
      hasMicHardware: false,
      hasCamHardware: false,
      needsPermissionPrompt: true,
      secureContext: typeof window !== 'undefined' ? Boolean(window.isSecureContext) : false,
    };
  }

  let mic: MediaPermState = 'prompt';
  let cam: MediaPermState = 'prompt';
  if (navigator.permissions?.query) {
    try {
      const m = await navigator.permissions.query({ name: 'microphone' as PermissionName });
      mic = m.state as MediaPermState;
    } catch {
      mic = 'unknown';
    }
    try {
      const c = await navigator.permissions.query({ name: 'camera' as PermissionName });
      cam = c.state as MediaPermState;
    } catch {
      cam = 'unknown';
    }
  }

  let hasMicHardware = true;
  let hasCamHardware = true;
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    if (devices.length > 0) {
      hasMicHardware = devices.some((d) => d.kind === 'audioinput');
      hasCamHardware = devices.some((d) => d.kind === 'videoinput');
    }
  } catch {
    // Keep optimistic defaults until getUserMedia is invoked
  }

  const needsPermissionPrompt = mic !== 'granted' || cam !== 'granted';
  return {
    mic,
    cam,
    hasMicHardware,
    hasCamHardware,
    needsPermissionPrompt,
    secureContext: Boolean(window.isSecureContext),
  };
}

export class CallManager {
  private mp: MultiplayerClient;
  private localUid: string;
  private peers = new Map<string, PeerEntry>();
  private remoteStreams: Record<string, MediaStream> = {};
  private connectionStates: Record<string, string> = {};
  private localStream: MediaStream | null = null;
  private roomId: string | null = null;
  private mode: 'voice' | 'video' = 'voice';
  private isGroup = false;
  private deviceType: DeviceKind = detectDeviceKind();
  private facingMode: 'user' | 'environment' = 'user';
  private micOn = true;
  private camOn = false;
  private participants: CallParticipantInfo[] = [];
  private speakingUids: string[] = [];
  private error: string | null = null;
  private permissions: MediaPermissionStatus = {
    mic: 'prompt',
    cam: 'prompt',
    hasMicHardware: true,
    hasCamHardware: true,
    needsPermissionPrompt: true,
    secureContext: typeof window !== 'undefined' ? Boolean(window.isSecureContext) : true,
  };
  private listeners = new Set<(snap: CallStateSnapshot) => void>();
  private unsubRoom: (() => void) | null = null;
  private unsubSignal: (() => void) | null = null;
  private unsubCallErr: (() => void) | null = null;
  private unsubCallEnded: (() => void) | null = null;
  private videoConfig: VideoCallConfig = { ...VIDEO_CALL_CONFIG };
  private previewTimer: number | null = null;
  private previewVideoEl: HTMLVideoElement | null = null;
  private previewCanvas: HTMLCanvasElement | null = null;

  // Web Audio Voice Activity Detection (VAD)
  private vadCtx: AudioContext | null = null;
  private vadNodes = new Map<string, VadNode>();
  private vadTimer: number | null = null;

  constructor(mp: MultiplayerClient, localUid: string) {
    this.mp = mp;
    this.localUid = localUid;

    this.unsubRoom = mp.on('callRoomState', (roomId, participants) => {
      if (this.roomId !== roomId) return;
      this.participants = participants;
      this.syncPeerConnections(participants);
      this.emit();
    });

    this.unsubSignal = mp.on('callSignal', (roomId, fromUid, _fromName, signal) => {
      if (this.roomId !== roomId) return;
      void this.handleRemoteSignal(fromUid, signal as Record<string, unknown>);
    });

    this.unsubCallErr = mp.on('callError', (reason) => {
      this.error = reason;
      this.emit();
    });

    this.unsubCallEnded = mp.on('callEnded', (payload) => {
      if (this.roomId && (!payload.roomId || this.roomId === payload.roomId)) {
        this.leaveCall(false);
      }
    });

    void this.refreshPermissions();
  }

  public setVideoConfig(cfg: Partial<VideoCallConfig>) {
    this.videoConfig = {
      width: Math.max(160, Math.min(1280, Math.round(Number(cfg.width ?? this.videoConfig.width)))),
      height: Math.max(120, Math.min(720, Math.round(Number(cfg.height ?? this.videoConfig.height)))),
      fps: Math.max(10, Math.min(60, Math.round(Number(cfg.fps ?? this.videoConfig.fps)))),
      bitrateKbps: Math.max(64, Math.min(2500, Math.round(Number(cfg.bitrateKbps ?? this.videoConfig.bitrateKbps)))),
      showSelfPreviewByDefault:
        typeof cfg.showSelfPreviewByDefault === 'boolean'
          ? cfg.showSelfPreviewByDefault
          : this.videoConfig.showSelfPreviewByDefault,
    };
    if (this.localStream) {
      const vt = this.localStream.getVideoTracks()[0];
      if (vt && typeof vt.applyConstraints === 'function') {
        void vt
          .applyConstraints({
            width: { ideal: this.videoConfig.width },
            height: { ideal: this.videoConfig.height },
            frameRate: { ideal: this.videoConfig.fps },
          })
          .catch(() => {});
      }
    }
    for (const entry of this.peers.values()) {
      void this.applyEncodingParameters(entry.pc);
    }
    this.emit();
  }

  private async applyEncodingParameters(pc: RTCPeerConnection) {
    const senders = pc.getSenders();
    for (const sender of senders) {
      if (sender.track?.kind !== 'video') continue;
      try {
        const params = sender.getParameters();
        if (!params.encodings || params.encodings.length === 0) {
          params.encodings = [{}];
        }
        params.encodings[0].maxBitrate = this.videoConfig.bitrateKbps * 1000;
        params.encodings[0].maxFramerate = this.videoConfig.fps;
        await sender.setParameters(params);
      } catch {
        // Some browsers reject setParameters before ICE/codec settles; ignore safely
      }
    }
  }

  public setLocalUid(uid: string) {
    this.localUid = uid;
  }

  public async refreshPermissions(): Promise<MediaPermissionStatus> {
    this.permissions = await probeMediaPermissions();
    this.emit();
    return this.permissions;
  }

  public async requestMediaPermissions(mode: 'voice' | 'video'): Promise<{ granted: boolean; status: MediaPermissionStatus; error?: string }> {
    if (!navigator.mediaDevices?.getUserMedia) {
      this.error = 'Browser does not support microphone/camera access (requires HTTPS or localhost).';
      await this.refreshPermissions();
      return { granted: false, status: this.permissions, error: this.error };
    }
    try {
      const testStream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: mode === 'video',
      });
      testStream.getTracks().forEach((t) => t.stop());
      this.error = null;
      await this.refreshPermissions();
      return { granted: true, status: this.permissions };
    } catch (err) {
      if (mode === 'video') {
        try {
          const audioTest = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
          audioTest.getTracks().forEach((t) => t.stop());
          this.error = 'Camera unavailable — microphone permission granted for voice call.';
          await this.refreshPermissions();
          return { granted: true, status: this.permissions, error: this.error };
        } catch {
          // continue to error
        }
      }
      const msg = err instanceof Error ? err.message : 'Microphone/Camera permission denied.';
      this.error = msg;
      await this.refreshPermissions();
      return { granted: false, status: this.permissions, error: msg };
    }
  }

  public subscribe(fn: (snap: CallStateSnapshot) => void): () => void {
    this.listeners.add(fn);
    fn(this.getSnapshot());
    return () => {
      this.listeners.delete(fn);
    };
  }

  public getSnapshot(): CallStateSnapshot {
    return {
      inCall: Boolean(this.roomId),
      roomId: this.roomId,
      mode: this.mode,
      isGroup: this.isGroup,
      deviceType: this.deviceType,
      facingMode: this.facingMode,
      micOn: this.micOn,
      camOn: this.camOn,
      localStream: this.localStream,
      remoteStreams: { ...this.remoteStreams },
      participants: [...this.participants],
      speakingUids: [...this.speakingUids],
      connectionStates: { ...this.connectionStates },
      error: this.error,
      permissions: { ...this.permissions },
      videoConfig: { ...this.videoConfig },
    };
  }

  private emit() {
    const snap = this.getSnapshot();
    this.listeners.forEach((fn) => fn(snap));
  }

  /**
   * Cross-device resilient getUserMedia with 4-tier graceful degradation:
   * Tier 1: Ideal mobile/desktop constraints (echoCancellation + facingMode)
   * Tier 2: Bare { audio: true, video: true } (handles OverconstrainedError on older iOS/Android/webcams)
   * Tier 3: Audio-only fallback if camera is unavailable/denied
   * Tier 4: Receive-only listener mode (null stream) so user can still listen/watch call!
   */
  private async acquireMedia(mode: 'voice' | 'video', facing: 'user' | 'environment'): Promise<MediaStream | null> {
    if (!navigator.mediaDevices?.getUserMedia) {
      this.error = 'WebRTC microphone/camera unavailable (listen-only mode active).';
      return null;
    }

    this.deviceType = detectDeviceKind();
    const audioConstraints: MediaTrackConstraints = {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
    };
    const videoConstraints: MediaTrackConstraints | boolean =
      mode === 'video'
        ? this.deviceType === 'mobile'
          ? {
              facingMode: { ideal: facing },
              width: { ideal: this.videoConfig.width },
              height: { ideal: this.videoConfig.height },
              frameRate: { ideal: this.videoConfig.fps },
            }
          : {
              width: { ideal: this.videoConfig.width },
              height: { ideal: this.videoConfig.height },
              frameRate: { ideal: this.videoConfig.fps },
            }
        : false;

    // Tier 1: Ideal constraints
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: audioConstraints,
        video: videoConstraints,
      });
      this.error = null;
      void this.refreshPermissions();
      return stream;
    } catch {
      // Fall through to Tier 2
    }

    // Tier 2: Bare constraints (avoids OverconstrainedError on Safari/Android/older cams)
    if (mode === 'video') {
      try {
        const bareStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
        this.error = null;
        void this.refreshPermissions();
        return bareStream;
      } catch {
        // Fall through to Tier 3
      }
    }

    // Tier 3: Audio-only fallback
    try {
      const audioOnly = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      this.error = mode === 'video' ? 'Camera unavailable — joined with microphone audio only.' : null;
      void this.refreshPermissions();
      return audioOnly;
    } catch (err) {
      // Tier 4: Receive-only mode
      this.error =
        err instanceof Error
          ? `${err.message} (joined in listen-only mode)`
          : 'Microphone/Camera denied — joined in listen-only mode.';
      void this.refreshPermissions();
      return null;
    }
  }

  private ensureVadContext() {
    if (typeof window === 'undefined') return null;
    if (!this.vadCtx) {
      const AudioCtx =
        window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      try {
        this.vadCtx = new AudioCtx();
      } catch {
        return null;
      }
    }
    if (this.vadCtx.state === 'suspended') {
      void this.vadCtx.resume().catch(() => {});
    }
    return this.vadCtx;
  }

  private attachVadStream(uid: string, stream: MediaStream | null) {
    const existing = this.vadNodes.get(uid);
    if (!stream || stream.getAudioTracks().length === 0) {
      if (existing) {
        try {
          existing.source.disconnect();
        } catch {
          // ignore
        }
        this.vadNodes.delete(uid);
      }
      return;
    }
    if (existing && existing.streamId === stream.id) return;
    if (existing) {
      try {
        existing.source.disconnect();
      } catch {
        // ignore
      }
      this.vadNodes.delete(uid);
    }
    const ctx = this.ensureVadContext();
    if (!ctx) return;
    try {
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      analyser.smoothingTimeConstant = 0.65;
      source.connect(analyser);
      const data = new Uint8Array(new ArrayBuffer(analyser.frequencyBinCount));
      this.vadNodes.set(uid, { source, analyser, data, streamId: stream.id });
    } catch {
      // Ignore if browser blocks AudioContext node creation before gesture
    }
  }

  private startVadLoop() {
    this.stopVadLoop();
    if (typeof window === 'undefined') return;
    this.vadTimer = window.setInterval(() => {
      if (!this.roomId) return;
      this.attachVadStream(this.localUid, this.micOn ? this.localStream : null);
      for (const [uid, stream] of Object.entries(this.remoteStreams)) {
        this.attachVadStream(uid, stream);
      }
      const nextSpeaking: string[] = [];
      for (const [uid, node] of this.vadNodes.entries()) {
        if (uid === this.localUid && !this.micOn) continue;
        node.analyser.getByteTimeDomainData(node.data);
        let sumSq = 0;
        for (let i = 0; i < node.data.length; i++) {
          const v = (node.data[i] - 128) / 128;
          sumSq += v * v;
        }
        const rms = Math.sqrt(sumSq / node.data.length);
        if (rms > 0.028) {
          nextSpeaking.push(uid);
        }
      }
      const prevKey = this.speakingUids.slice().sort().join(',');
      const nextKey = nextSpeaking.slice().sort().join(',');
      if (prevKey !== nextKey) {
        this.speakingUids = nextSpeaking;
        this.emit();
      }
    }, 220);
  }

  private stopVadLoop() {
    if (this.vadTimer !== null) {
      clearInterval(this.vadTimer);
      this.vadTimer = null;
    }
    for (const node of this.vadNodes.values()) {
      try {
        node.source.disconnect();
      } catch {
        // ignore
      }
    }
    this.vadNodes.clear();
    this.speakingUids = [];
  }

  private startPreviewSnapshotLoop() {
    this.stopPreviewSnapshotLoop();
    if (typeof document === 'undefined') return;
    this.previewTimer = window.setInterval(() => {
      if (!this.roomId || !this.camOn || !this.localStream) return;
      const track = this.localStream.getVideoTracks()[0];
      if (!track || track.readyState !== 'live') return;
      if (!this.previewVideoEl) {
        this.previewVideoEl = document.createElement('video');
        this.previewVideoEl.muted = true;
        this.previewVideoEl.playsInline = true;
      }
      if (this.previewVideoEl.srcObject !== this.localStream) {
        this.previewVideoEl.srcObject = this.localStream;
        void this.previewVideoEl.play().catch(() => {});
      }
      if (this.previewVideoEl.videoWidth <= 0) return;
      if (!this.previewCanvas) {
        this.previewCanvas = document.createElement('canvas');
        this.previewCanvas.width = 128;
        this.previewCanvas.height = 96;
      }
      const ctx = this.previewCanvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(this.previewVideoEl, 0, 0, 128, 96);
      const dataUrl = this.previewCanvas.toDataURL('image/jpeg', 0.45);
      if (dataUrl.length < 22_000) {
        this.mp.sendCallPreviewFrame(this.roomId, dataUrl);
      }
    }, 2500);
  }

  private stopPreviewSnapshotLoop() {
    if (this.previewTimer !== null) {
      clearInterval(this.previewTimer);
      this.previewTimer = null;
    }
    if (this.previewVideoEl) {
      this.previewVideoEl.srcObject = null;
    }
  }

  public async startOrJoinCall(opts: {
    roomId: string;
    mode: 'voice' | 'video';
    isGroup: boolean;
    inviteTargetUids?: string[];
  }): Promise<boolean> {
    this.leaveCall();
    this.deviceType = detectDeviceKind();
    this.mode = opts.mode;
    this.isGroup = opts.isGroup;
    this.facingMode = 'user';
    this.ensureVadContext();

    const stream = await this.acquireMedia(opts.mode, this.facingMode);
    this.localStream = stream;
    this.micOn = Boolean(stream?.getAudioTracks().some((t) => t.enabled));
    this.camOn = Boolean(opts.mode === 'video' && stream?.getVideoTracks().some((t) => t.enabled));
    this.roomId = opts.roomId;

    this.mp.joinCallRoom(opts.roomId, opts.mode, this.micOn, this.camOn, this.deviceType);
    if (opts.inviteTargetUids && opts.inviteTargetUids.length > 0) {
      this.mp.inviteToCall(opts.roomId, opts.mode, opts.isGroup, opts.inviteTargetUids);
    }
    this.startVadLoop();
    if (this.camOn) {
      this.startPreviewSnapshotLoop();
    }
    this.emit();
    return true;
  }

  public async toggleMic() {
    if (!this.roomId) return;
    // If joined listen-only with no audio track, try acquiring mic now
    if (!this.localStream || this.localStream.getAudioTracks().length === 0) {
      const audioStream = await this.acquireMedia('voice', this.facingMode);
      const audioTrack = audioStream?.getAudioTracks()[0];
      if (!audioTrack) {
        this.emit();
        return;
      }
      if (!this.localStream) {
        this.localStream = new MediaStream([audioTrack]);
      } else {
        this.localStream.addTrack(audioTrack);
      }
      for (const [remoteUid, entry] of this.peers.entries()) {
        const sender = entry.pc.getSenders().find((s) => s.track?.kind === 'audio');
        if (sender) {
          await sender.replaceTrack(audioTrack);
        } else {
          entry.pc.addTrack(audioTrack, this.localStream);
          void this.renegotiatePeer(remoteUid, entry);
        }
      }
      this.micOn = true;
      this.mp.updateCallMedia(this.roomId, this.micOn, this.camOn);
      this.emit();
      return;
    }

    this.micOn = !this.micOn;
    this.localStream.getAudioTracks().forEach((t) => {
      t.enabled = this.micOn;
    });
    this.mp.updateCallMedia(this.roomId, this.micOn, this.camOn);
    this.emit();
  }

  public async toggleCamera() {
    if (!this.roomId) return;
    if (this.localStream && this.localStream.getVideoTracks().length > 0) {
      this.camOn = !this.camOn;
      this.localStream.getVideoTracks().forEach((t) => {
        t.enabled = this.camOn;
      });
      if (this.camOn) this.mode = 'video';
    } else if (!this.camOn) {
      const newStream = await this.acquireMedia('video', this.facingMode);
      if (newStream) {
        const videoTrack = newStream.getVideoTracks()[0];
        if (videoTrack) {
          if (!this.localStream) {
            this.localStream = new MediaStream([videoTrack]);
          } else {
            this.localStream.addTrack(videoTrack);
          }
          for (const [remoteUid, entry] of this.peers.entries()) {
            const sender = entry.pc.getSenders().find((s) => s.track?.kind === 'video');
            if (sender) {
              await sender.replaceTrack(videoTrack);
            } else {
              entry.pc.addTrack(videoTrack, this.localStream);
              void this.renegotiatePeer(remoteUid, entry);
            }
          }
          this.camOn = true;
          this.mode = 'video';
        }
        newStream.getAudioTracks().forEach((t) => t.stop());
      }
    }
    if (this.camOn) this.startPreviewSnapshotLoop();
    else this.stopPreviewSnapshotLoop();
    this.mp.updateCallMedia(this.roomId, this.micOn, this.camOn);
    this.emit();
  }

  public async flipCamera() {
    if (!this.roomId || !this.camOn) return;
    this.facingMode = this.facingMode === 'user' ? 'environment' : 'user';
    const nextStream = await this.acquireMedia('video', this.facingMode);
    if (!nextStream) {
      this.emit();
      return;
    }
    const newVideoTrack = nextStream.getVideoTracks()[0];
    nextStream.getAudioTracks().forEach((t) => t.stop());
    if (!newVideoTrack) return;

    this.localStream?.getVideoTracks().forEach((t) => {
      t.stop();
      this.localStream?.removeTrack(t);
    });
    if (!this.localStream) {
      this.localStream = new MediaStream([newVideoTrack]);
    } else {
      this.localStream.addTrack(newVideoTrack);
    }

    for (const entry of this.peers.values()) {
      const sender = entry.pc.getSenders().find((s) => s.track?.kind === 'video');
      if (sender) {
        await sender.replaceTrack(newVideoTrack);
      }
    }
    this.emit();
  }

  private createPeerEntry(remoteUid: string): PeerEntry {
    const existing = this.peers.get(remoteUid);
    if (existing) return existing;

    const pc = new RTCPeerConnection(RTC_CONFIG);
    // Perfect Negotiation: deterministic polite/impolite roles across every device pair
    const entry: PeerEntry = {
      pc,
      polite: this.localUid > remoteUid,
      makingOffer: false,
      ignoreOffer: false,
      isSettingRemoteAnswerPending: false,
      pendingIce: [],
      restartCount: 0,
    };
    this.peers.set(remoteUid, entry);
    this.connectionStates[remoteUid] = pc.connectionState || 'new';

    if (this.localStream && this.localStream.getTracks().length > 0) {
      for (const track of this.localStream.getTracks()) {
        pc.addTrack(track, this.localStream);
      }
      void this.applyEncodingParameters(pc);
    } else {
      // Receive-only listener still negotiates audio/video reception cleanly
      try {
        pc.addTransceiver('audio', { direction: 'recvonly' });
        if (this.mode === 'video') {
          pc.addTransceiver('video', { direction: 'recvonly' });
        }
      } catch {
        // Fallback for browsers without addTransceiver
      }
    }

    pc.onnegotiationneeded = () => {
      void this.renegotiatePeer(remoteUid, entry);
    };

    pc.onicecandidate = (ev) => {
      if (ev.candidate && this.roomId) {
        this.mp.sendCallSignal(this.roomId, remoteUid, { ice: ev.candidate.toJSON() });
      }
    };

    pc.ontrack = (ev) => {
      // Merge incoming audio + video tracks into a unified MediaStream per peer
      let targetStream = this.remoteStreams[remoteUid];
      if (!targetStream) {
        targetStream = new MediaStream();
      }
      const incomingTracks = ev.streams[0] ? ev.streams[0].getTracks() : [ev.track];
      for (const track of incomingTracks) {
        const alreadyPresent = targetStream.getTracks().some((t) => t.id === track.id);
        if (!alreadyPresent) {
          // Replace ended track of same kind
          for (const old of targetStream.getTracks()) {
            if (old.kind === track.kind && old.readyState === 'ended') {
              targetStream.removeTrack(old);
            }
          }
          targetStream.addTrack(track);
        }
      }
      // Assign fresh MediaStream reference so React effects pick up newly added video/audio tracks
      this.remoteStreams[remoteUid] = new MediaStream(targetStream.getTracks());
      this.attachVadStream(remoteUid, this.remoteStreams[remoteUid]);
      this.emit();
    };

    pc.oniceconnectionstatechange = () => {
      if (pc.iceConnectionState === 'failed' && entry.restartCount < 2) {
        entry.restartCount += 1;
        if (typeof pc.restartIce === 'function') {
          pc.restartIce();
        }
        void this.renegotiatePeer(remoteUid, entry, true);
      }
    };

    pc.onconnectionstatechange = () => {
      this.connectionStates[remoteUid] = pc.connectionState;
      if (pc.connectionState === 'connected') {
        entry.restartCount = 0;
        void this.applyEncodingParameters(pc);
      } else if (pc.connectionState === 'failed' && entry.restartCount < 2) {
        entry.restartCount += 1;
        void this.renegotiatePeer(remoteUid, entry, true);
      } else if (pc.connectionState === 'closed') {
        delete this.remoteStreams[remoteUid];
        delete this.connectionStates[remoteUid];
      }
      this.emit();
    };

    return entry;
  }

  private async renegotiatePeer(remoteUid: string, entry: PeerEntry, iceRestart = false) {
    if (!this.roomId || entry.pc.signalingState === 'closed') return;
    if (entry.makingOffer) return;
    try {
      entry.makingOffer = true;
      const offer = await entry.pc.createOffer(iceRestart ? { iceRestart: true } : undefined);
      if (entry.pc.signalingState !== 'stable') return;
      await entry.pc.setLocalDescription(offer);
      if (this.roomId && entry.pc.localDescription) {
        this.mp.sendCallSignal(this.roomId, remoteUid, { sdp: entry.pc.localDescription.toJSON() });
      }
    } catch {
      // ignore transient negotiation race
    } finally {
      entry.makingOffer = false;
    }
  }

  private async flushPendingIce(entry: PeerEntry) {
    if (!entry.pc.remoteDescription || entry.pendingIce.length === 0) return;
    const queued = entry.pendingIce.splice(0, entry.pendingIce.length);
    for (const candidate of queued) {
      try {
        await entry.pc.addIceCandidate(new RTCIceCandidate(candidate));
      } catch {
        // ignore stale candidate
      }
    }
  }

  private syncPeerConnections(participants: CallParticipantInfo[]) {
    const activeRemoteUids = new Set(participants.map((p) => p.uid).filter((uid) => uid !== this.localUid));
    for (const [uid, entry] of this.peers.entries()) {
      if (!activeRemoteUids.has(uid)) {
        entry.pc.close();
        this.peers.delete(uid);
        delete this.remoteStreams[uid];
        delete this.connectionStates[uid];
        this.attachVadStream(uid, null);
      }
    }
    for (const remoteUid of activeRemoteUids) {
      if (!this.peers.has(remoteUid)) {
        const entry = this.createPeerEntry(remoteUid);
        // Impolite peer (smaller uid) proactively sends the initial offer immediately
        if (!entry.polite) {
          void this.renegotiatePeer(remoteUid, entry);
        }
      }
    }
  }

  private async handleRemoteSignal(fromUid: string, signal: Record<string, unknown>) {
    const entry = this.createPeerEntry(fromUid);
    const { pc } = entry;
    try {
      if (signal.sdp) {
        const descInit = signal.sdp as RTCSessionDescriptionInit;
        const readyForOffer =
          !entry.makingOffer && (pc.signalingState === 'stable' || entry.isSettingRemoteAnswerPending);
        const offerCollision = descInit.type === 'offer' && !readyForOffer;

        entry.ignoreOffer = !entry.polite && offerCollision;
        if (entry.ignoreOffer) return;

        entry.isSettingRemoteAnswerPending = descInit.type === 'answer';
        await pc.setRemoteDescription(new RTCSessionDescription(descInit));
        entry.isSettingRemoteAnswerPending = false;
        await this.flushPendingIce(entry);

        if (descInit.type === 'offer') {
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          if (this.roomId && pc.localDescription) {
            this.mp.sendCallSignal(this.roomId, fromUid, { sdp: pc.localDescription.toJSON() });
          }
        }
      } else if (signal.ice) {
        const candidateInit = signal.ice as RTCIceCandidateInit;
        if (!pc.remoteDescription) {
          entry.pendingIce.push(candidateInit);
        } else {
          try {
            await pc.addIceCandidate(new RTCIceCandidate(candidateInit));
          } catch (err) {
            if (!entry.ignoreOffer) throw err;
          }
        }
      }
    } catch {
      entry.isSettingRemoteAnswerPending = false;
    }
  }

  public leaveCall(notifyServer = true) {
    this.stopPreviewSnapshotLoop();
    this.stopVadLoop();
    if (notifyServer && this.roomId) {
      this.mp.leaveCallRoom();
    }
    for (const entry of this.peers.values()) {
      entry.pc.close();
    }
    this.peers.clear();
    if (this.localStream) {
      this.localStream.getTracks().forEach((t) => t.stop());
      this.localStream = null;
    }
    this.remoteStreams = {};
    this.connectionStates = {};
    this.roomId = null;
    this.participants = [];
    this.speakingUids = [];
    this.camOn = false;
    this.micOn = true;
    this.error = null;
    this.emit();
  }

  public dispose() {
    this.leaveCall();
    if (this.vadCtx) {
      void this.vadCtx.close().catch(() => {});
      this.vadCtx = null;
    }
    this.unsubRoom?.();
    this.unsubSignal?.();
    this.unsubCallErr?.();
    this.unsubCallEnded?.();
    this.listeners.clear();
  }
}
