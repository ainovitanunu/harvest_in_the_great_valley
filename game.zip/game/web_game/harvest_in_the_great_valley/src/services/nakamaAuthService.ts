import type { AvatarConfig, CharacterRosterEntry, SocialProviderId } from '../game/types';
import { auth, signInWithApple, signInWithGoogle, signOutPlayer } from './firebaseService';

export interface NakamaSocialProviderInfo {
  id: SocialProviderId;
  name: string;
  configured: boolean;
  available: boolean;
  detectedOnDevice: boolean;
  protocol: string;
  hint: string;
}

export interface NakamaSocialAccount {
  accountId: string;
  uid: string;
  provider: SocialProviderId;
  email: string;
  displayName: string;
  isDeveloper: boolean;
  isOwner?: boolean;
  role?: 'owner' | 'developer' | 'player';
  developerConfigured: boolean;
}

export interface DevAuthStatus {
  configured: boolean;
  ownerConfigured?: boolean;
  provider: SocialProviderId | null;
  displayName: string | null;
  emailMasked: string | null;
  registeredAt: string | number | null;
  developerCount?: number;
  hasDefaultBackup?: boolean;
  backupCount?: number;
}

// Keep active social bearer tokens strictly in JS memory (never localStorage/sessionStorage)
let activeSocialToken: string | null = null;
let activeSocialAccount: NakamaSocialAccount | null = null;

export function getActiveSocialToken(): string | null {
  return activeSocialToken;
}

export function getActiveSocialAccount(): NakamaSocialAccount | null {
  return activeSocialAccount;
}

export function clearNakamaSocialSession(): void {
  activeSocialToken = null;
  activeSocialAccount = null;
}

export async function getActiveBearerToken(forceRefresh = false): Promise<string | null> {
  if (activeSocialToken) return activeSocialToken;
  const user = auth.currentUser;
  if (user && !user.isAnonymous) {
    return user.getIdToken(forceRefresh);
  }
  return null;
}

export function detectDeviceSocialProviders(): Record<SocialProviderId, { detected: boolean; hint: string }> {
  if (typeof navigator === 'undefined') {
    return {
      google: { detected: true, hint: 'Google OAuth 2.0' },
      steam: { detected: true, hint: 'Steam OpenID 2.0' },
      apple: { detected: true, hint: 'Apple Sign-In' },
    };
  }
  const ua = navigator.userAgent || '';
  const platform = (navigator.platform || '').toLowerCase();
  const isAppleDevice = /mac|iphone|ipad|ipod/i.test(ua) || /mac|iphone|ipad/i.test(platform);
  const isSteamOverlay = /valve steam/i.test(ua);
  const isDesktop = !/android|iphone|ipad|ipod|mobile/i.test(ua);

  return {
    google: {
      detected: true,
      hint: 'Google OAuth 2.0',
    },
    steam: {
      detected: isSteamOverlay || isDesktop,
      hint: isSteamOverlay ? 'Steam Client Detected' : 'Steam OpenID 2.0',
    },
    apple: {
      detected: isAppleDevice,
      hint: isAppleDevice ? 'Apple Device Detected' : 'Apple OIDC Web',
    },
  };
}

export async function fetchNakamaProviders(): Promise<{
  gatewayMode: string;
  nakamaConfigured: boolean;
  graceDeletionDays: number;
  maxCharactersPerAccount: number;
  providers: NakamaSocialProviderInfo[];
}> {
  const localDetect = detectDeviceSocialProviders();
  try {
    const res = await fetch('/api/nakama/auth/providers');
    if (res.ok) {
      const data = await res.json();
      const rawMap = (data.providers || {}) as Record<
        string,
        { id?: SocialProviderId; label?: string; enabled?: boolean; configured?: boolean }
      >;
      const order: SocialProviderId[] = ['google', 'steam', 'apple'];
      const protocolMap: Record<SocialProviderId, string> = {
        google: 'Nakama + Google OAuth',
        steam: 'Nakama + Steam OpenID 2.0',
        apple: 'Nakama + Apple Sign-In',
      };
      const providers: NakamaSocialProviderInfo[] = order.map((id) => {
        const entry = rawMap[id];
        return {
          id,
          name: entry?.label || id.charAt(0).toUpperCase() + id.slice(1),
          configured: entry ? Boolean(entry.configured) : true,
          available: entry ? entry.enabled !== false : true,
          detectedOnDevice: localDetect[id].detected,
          protocol: protocolMap[id],
          hint: localDetect[id].hint,
        };
      });
      return {
        gatewayMode: String(data.gatewayMode || 'built_in_nakama_sync'),
        nakamaConfigured: Boolean(data.nakamaConfigured),
        graceDeletionDays: Number(data.deletionGraceDays || 3),
        maxCharactersPerAccount: Number(data.maxCharactersPerAccount || 5),
        providers,
      };
    }
  } catch {
    // Fallback list if offline
  }

  return {
    gatewayMode: 'built_in_nakama_sync',
    nakamaConfigured: false,
    graceDeletionDays: 3,
    maxCharactersPerAccount: 5,
    providers: [
      { id: 'google', name: 'Google', configured: true, available: true, detectedOnDevice: localDetect.google.detected, protocol: 'Nakama + Google OAuth', hint: localDetect.google.hint },
      { id: 'steam', name: 'Steam', configured: true, available: true, detectedOnDevice: localDetect.steam.detected, protocol: 'Nakama + Steam OpenID 2.0', hint: localDetect.steam.hint },
      { id: 'apple', name: 'Apple', configured: true, available: true, detectedOnDevice: localDetect.apple.detected, protocol: 'Nakama + Apple Sign-In', hint: localDetect.apple.hint },
    ],
  };
}

export async function exchangeTokenWithNakama(
  bearerToken: string
): Promise<{ account: NakamaSocialAccount; characters: CharacterRosterEntry[]; token: string }> {
  const res = await fetch('/api/nakama/auth/authenticate', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${bearerToken}`,
    },
  });
  const data = await res.json();
  if (!res.ok || !data.ok) {
    throw new Error(data.error || 'Failed to authenticate social account via Nakama');
  }
  const sessionToken = String(data.nakamaSessionToken || bearerToken);
  const account: NakamaSocialAccount = {
    accountId: String(data.account.accountId),
    uid: String(data.account.uid),
    provider: data.account.provider as SocialProviderId,
    email: String(data.account.email || ''),
    displayName: String(data.account.displayName || 'Farmer'),
    isDeveloper: Boolean(data.isDeveloper),
    isOwner: Boolean(data.isOwner),
    role: (data.role as 'owner' | 'developer' | 'player') || (data.isOwner ? 'owner' : data.isDeveloper ? 'developer' : 'player'),
    developerConfigured: Boolean(data.developerConfigured),
  };
  activeSocialToken = sessionToken;
  activeSocialAccount = account;
  return {
    account,
    characters: Array.isArray(data.characters) ? (data.characters as CharacterRosterEntry[]) : [],
    token: sessionToken,
  };
}

export async function authenticateWithFirebaseSocial(
  provider: 'google' | 'apple'
): Promise<{ account: NakamaSocialAccount; characters: CharacterRosterEntry[]; token: string }> {
  const user = provider === 'apple' ? await signInWithApple() : await signInWithGoogle();
  const idToken = await user.getIdToken(true);
  return exchangeTokenWithNakama(idToken);
}

/**
 * Listens for the Steam OpenID 2.0 callback result over same-origin BroadcastChannel / postMessage
 * after the user clicks the Steam OpenID link (<a href="/api/nakama/auth/steam/start" target="_blank" rel="noopener noreferrer">).
 */
export function listenForSteamSocialAuth(
  onComplete: (res: { account: NakamaSocialAccount; characters: CharacterRosterEntry[]; token: string }) => void,
  onError: (msg: string) => void
): () => void {
  let settled = false;
  const channel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('hgv_nakama_steam_auth') : null;

  const handlePayload = async (payload: { type?: string; token?: string; error?: string }) => {
    if (settled || !payload || payload.type !== 'hgv_nakama_social_auth') return;
    settled = true;
    cleanup();
    if (payload.error || !payload.token) {
      onError(payload.error || 'Steam authentication was cancelled or failed.');
      return;
    }
    try {
      const exchanged = await exchangeTokenWithNakama(payload.token);
      onComplete(exchanged);
    } catch (err) {
      onError(err instanceof Error ? err.message : 'Steam session verification failed.');
    }
  };

  const onMessage = (ev: MessageEvent) => {
    if (ev.origin !== window.location.origin) return;
    void handlePayload(ev.data);
  };

  const onChannelMessage = (ev: MessageEvent) => {
    void handlePayload(ev.data);
  };

  window.addEventListener('message', onMessage);
  channel?.addEventListener('message', onChannelMessage);

  const timeoutId = window.setTimeout(() => {
    if (!settled) {
      settled = true;
      cleanup();
      onError('Steam authentication timed out. Please try again.');
    }
  }, 180_000);

  const cleanup = () => {
    window.clearTimeout(timeoutId);
    window.removeEventListener('message', onMessage);
    channel?.removeEventListener('message', onChannelMessage);
    channel?.close();
  };

  return cleanup;
}

export async function restoreFirebaseSocialSession(): Promise<{
  account: NakamaSocialAccount;
  characters: CharacterRosterEntry[];
  token: string;
} | null> {
  const user = auth.currentUser;
  if (!user || user.isAnonymous) return null;
  const idToken = await user.getIdToken(false);
  return exchangeTokenWithNakama(idToken);
}

export async function signOutNakamaSocial(): Promise<void> {
  clearNakamaSocialSession();
  try {
    await signOutPlayer();
  } catch {
    // ignore if Steam-only
  }
}

async function socialAuthHeaders(): Promise<Record<string, string>> {
  const token = await getActiveBearerToken(false);
  if (!token) throw new Error('Social authentication required');
  return {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  };
}

export async function fetchCharacterRoster(): Promise<CharacterRosterEntry[]> {
  const res = await fetch('/api/nakama/characters', {
    headers: await socialAuthHeaders(),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to load character roster');
  return Array.isArray(data.characters) ? (data.characters as CharacterRosterEntry[]) : [];
}

export async function createCharacterOnRoster(payload: {
  avatarName: string;
  farmName: string;
  gender: 'male' | 'female';
  birthday: string;
  dogName: string;
  horseName: string;
  avatarConfig: AvatarConfig;
}): Promise<{ character: CharacterRosterEntry; characters: CharacterRosterEntry[] }> {
  const res = await fetch('/api/nakama/characters', {
    method: 'POST',
    headers: await socialAuthHeaders(),
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok || !data.ok) throw new Error(data.error || 'Failed to create character');
  return {
    character: data.character as CharacterRosterEntry,
    characters: Array.isArray(data.characters) ? (data.characters as CharacterRosterEntry[]) : [],
  };
}

export async function saveCharacterToRoster(
  characterId: string,
  payload: {
    avatarName?: string;
    farmName?: string;
    level?: number;
    gold?: number;
    diamond?: number;
    season?: string;
    day?: number;
    year?: number;
    avatarConfig?: AvatarConfig;
    savePayload?: Record<string, unknown>;
  }
): Promise<CharacterRosterEntry | null> {
  try {
    const res = await fetch(`/api/nakama/characters/${encodeURIComponent(characterId)}/save`, {
      method: 'POST',
      headers: await socialAuthHeaders(),
      body: JSON.stringify(payload),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return (data.character as CharacterRosterEntry) || null;
  } catch {
    return null;
  }
}

export async function scheduleCharacterDeletion(
  characterId: string
): Promise<{ character: CharacterRosterEntry; characters: CharacterRosterEntry[]; graceDays: number }> {
  const res = await fetch(`/api/nakama/characters/${encodeURIComponent(characterId)}/schedule-delete`, {
    method: 'POST',
    headers: await socialAuthHeaders(),
  });
  const data = await res.json();
  if (!res.ok || !data.ok) throw new Error(data.error || 'Failed to schedule character deletion');
  return {
    character: data.character as CharacterRosterEntry,
    characters: Array.isArray(data.characters) ? (data.characters as CharacterRosterEntry[]) : [],
    graceDays: Number(data.graceDays || 3),
  };
}

export async function cancelCharacterDeletion(
  characterId: string
): Promise<{ character: CharacterRosterEntry; characters: CharacterRosterEntry[] }> {
  const res = await fetch(`/api/nakama/characters/${encodeURIComponent(characterId)}/cancel-delete`, {
    method: 'POST',
    headers: await socialAuthHeaders(),
  });
  const data = await res.json();
  if (!res.ok || !data.ok) throw new Error(data.error || 'Failed to cancel character deletion');
  return {
    character: data.character as CharacterRosterEntry,
    characters: Array.isArray(data.characters) ? (data.characters as CharacterRosterEntry[]) : [],
  };
}

export async function fetchDevAuthStatus(): Promise<DevAuthStatus> {
  const res = await fetch('/api/dev/auth-status');
  if (!res.ok) throw new Error('Failed to query developer status');
  const data = await res.json();
  return {
    configured: Boolean(data.configured),
    ownerConfigured: Boolean(data.ownerConfigured ?? data.configured),
    provider: (data.provider as SocialProviderId | null) || null,
    displayName: data.displayName ? String(data.displayName) : null,
    emailMasked: data.emailMasked ? String(data.emailMasked) : null,
    registeredAt: data.registeredAt ?? null,
    developerCount: typeof data.developerCount === 'number' ? data.developerCount : 0,
    hasDefaultBackup: Boolean(data.hasDefaultBackup),
    backupCount: typeof data.backupCount === 'number' ? data.backupCount : 0,
  };
}

export async function checkDeveloperRole(tokenOverride?: string): Promise<{
  configured: boolean;
  isDeveloper: boolean;
  isOwner: boolean;
  role: 'owner' | 'developer' | 'player';
  dashboardUrl: string;
}> {
  const token = tokenOverride || (await getActiveBearerToken(false));
  if (!token) throw new Error('Social sign-in required');
  const res = await fetch('/api/dev/check-role', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Developer check failed');
  return {
    configured: Boolean(data.configured),
    isDeveloper: Boolean(data.isDeveloper),
    isOwner: Boolean(data.isOwner),
    role: (data.role as 'owner' | 'developer' | 'player') || (data.isOwner ? 'owner' : data.isDeveloper ? 'developer' : 'player'),
    dashboardUrl: String(data.dashboardUrl || '/dev-panel'),
  };
}

export async function claimDeveloperAccount(tokenOverride?: string): Promise<{
  ok: boolean;
  isDeveloper: boolean;
  isOwner: boolean;
  role: 'owner' | 'developer' | 'player';
  developer: { provider: SocialProviderId; displayName: string; emailMasked: string };
}> {
  const token = tokenOverride || (await getActiveBearerToken(false));
  if (!token) throw new Error('Social sign-in required');
  const res = await fetch('/api/dev/claim-owner', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
  });
  const data = await res.json();
  if (!res.ok || !data.ok) throw new Error(data.error || 'Failed to claim owner account');
  return data;
}

export async function renameCharacterOnRoster(
  characterId: string,
  displayName: string
): Promise<{ character: CharacterRosterEntry; chargedDiamond: number }> {
  const res = await fetch(`/api/nakama/characters/${encodeURIComponent(characterId)}/rename`, {
    method: 'POST',
    headers: await socialAuthHeaders(),
    body: JSON.stringify({ displayName }),
  });
  const data = await res.json();
  if (!res.ok || !data.ok) throw new Error(data.error || 'Failed to change Display Name');
  return {
    character: data.character as CharacterRosterEntry,
    chargedDiamond: Number(data.chargedDiamond || 0),
  };
}

