import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ErrorBoundary } from './components/ErrorBoundary';
import { TitleScreen } from './components/TitleScreen';
import { GameHUD } from './components/GameHUD';
import { InventoryModal } from './components/InventoryModal';
import { NPCDialogueModal } from './components/NPCDialogueModal';
import { ChatPanel } from './components/ChatPanel';
import { TutorialOverlay, TUTORIAL_STEPS } from './components/TutorialOverlay';
import { BukuTab, WorldPanelsModal } from './components/WorldPanelsModal';
import { DoorAccessModal } from './components/DoorAccessModal';
import { SettingsModal } from './components/SettingsModal';
import { AppearanceStudioModal } from './components/AppearanceStudioModal';
import { AnnouncementBanner } from './components/AnnouncementBanner';
import { BanLockdownScreen } from './components/BanLockdownScreen';
import { DraggableWindow } from './components/DraggableWindow';
import { localizationManager, normalizeLanguage } from './game/localizationManager';
import { themeManager } from './game/themeManager';
import {
  FarmhouseStorageModal,
  FarmhouseTVModal,
  FarmhouseWardrobeModal,
  MarriageProposalModal,
} from './components/FarmhouseFacilitiesModal';
import {
  BAG_UPGRADE_DIAMOND_COSTS,
  CROPS,
  DEFAULT_KEYBINDINGS,
  DEFAULT_TOOL_SHORTCUTS,
  INITIAL_INVENTORY,
  ITEMS,
  MAX_BAG_UPGRADES,
  OUTFIT_CATALOG,
  getBagUpgradeGoldCost,
  getMaxBagSlots,
} from './game/data/itemsAndCrops';
import { NPC_MAP, createInitialNpcRelationships, getRomanceStage } from './game/data/npcs';
import { pickContextualNpcLine } from './game/data/npcDialogueDb';
import {
  ANNOUNCEMENT_BANNER_CONFIG,
  CAMERA_CONFIG,
  CAVE_MINING_CONFIG,
  DEBUG_UNLIMITED_CURRENCY,
  DEFAULT_GLOBAL_THEME,
  DEVELOPER_DEBUG_MODE,
  FISHING_CONFIG,
  GLOBAL_TREE_ECOSYSTEM,
  GUEST_SESSION_CONFIG,
  ITEM_TRADE_RATES,
  MARKET_ECONOMY_CONFIG,
  ECONOMY_TAX_CONFIG,
  NAME_CHANGE_ECONOMY_CONFIG,
  MOBILE_CONTROLS_CONFIG,
  NORMAL_STARTER_DIAMOND,
  NORMAL_STARTER_GOLD,
  PAYMENT_METHODS,
  PERFORMANCE_CONFIG,
  VIDEO_CALL_CONFIG,
  WEATHER_CONTROL,
  WORLD_TIME_OVERRIDE,
  createEmptySalesStats,
  rollItemDiamondTradeable,
  rollNextWeather,
} from './game/data/gameRuntimeConfig';
import { t } from './game/i18n';
import {
  ACHIEVEMENTS,
  BUILDING_PORTALS,
  CUSTOMIZATION_DIAMOND_COST,
  DAILY_MISSION_TEMPLATES,
  DAYS_PER_SEASON,
  DEFAULT_WEATHER,
  DOG_FOOD_BOWL_POS,
  FARM_GRID_COLS,
  FARM_GRID_ROWS,
  FARMHOUSE_OUTDOOR_SPAWN,
  FESTIVALS,
  QUESTS,
  SEASONS_ORDER,
  getBarnCapacity,
  getCoopCapacity,
  getDaysInSeason,
  getIncubatorCount,
  getSynchronizedWorldClock,
} from './game/data/worldConfig';
import {
  applyDiminishingFun,
  applyFunProgress,
  applyOncePerDayFun,
  applyProportionalJobFun,
  applyXpProgress,
  createEmptyDailyFunTracker,
} from './game/progression';
import { soundEngine } from './game/audio/SoundEngine';
import { FloatingTag, GameEngine, NearbyPrompt, PlayerHeadAnchor } from './game/three/GameEngine';
import { generateUserFarmTrees, type InteractiveWorldNode } from './game/three/WorldBuilder';
import type {
  AnimalState,
  AnnouncementCategory,
  AppleTreeState,
  AvatarConfig,
  BranchingDialogueChoice,
  CharacterRosterEntry,
  ChatMessage,
  DailyFunTracker,
  DailyMission,
  DeviceControlMode,
  EggIncubatorSlot,
  FarmJobOffer,
  FarmJobTaskType,
  FarmObstacleType,
  FarmPlotState,
  FestivalDef,
  FloatingChatBubble,
  FriendRecord,
  FriendRequestRecord,
  GameSettings,
  GameStats,
  HairStyleId,
  InventorySlot,
  KeyBindings,
  MarketplaceCategory,
  MarketState,
  MusicMoodKey,
  NPCRelationshipState,
  NotificationSettings,
  OnlinePlayerState,
  P2PMarketListing,
  PlayerBanRecord,
  PlayerProfile,
  RuntimeGameConfig,
  SalesStats,
  Season,
  SocialProviderId,
  ThemeMode,
  Weather,
  WorldSpeechBubble,
  WorldTreeRecord,
  WorldZoneId,
} from './game/types';
import {
  GUEST_META_KEY,
  OfflineSaveSnapshot,
  SavedSessionSummary,
  clearLocalSave,
  clearOfflineSyncQueue,
  createGuestRandomizedIdentity,
  detectSavedLoginSession,
  getOrCreateDeviceId,
  getQueuedOfflineSync,
  loadCloudSave,
  loadLocalSave,
  markLoginSessionType,
  reauthenticateAndDeleteAccount,
  saveEncryptedOfflineVault,
  saveLocalSnapshot,
  signInAsEphemeralGuest,
  signInWithGoogle,
  signOutPlayer,
  getMultiplayerAuth,
  subscribeAuth,
  syncOfflineVaultToServer,
  syncToFirebaseCloud,
  testFirestoreConnection,
} from './services/firebaseService';
import {
  authenticateWithFirebaseSocial,
  cancelCharacterDeletion,
  createCharacterOnRoster,
  getActiveSocialAccount,
  getActiveSocialToken,
  listenForSteamSocialAuth,
  restoreFirebaseSocialSession,
  renameCharacterOnRoster,
  saveCharacterToRoster,
  scheduleCharacterDeletion,
  signOutNakamaSocial,
  type NakamaSocialAccount,
} from './services/nakamaAuthService';
import {
  IncomingCallInvite,
  MarriageProposalPayload,
  MultiplayerClient,
  buyP2PMarketListing,
  cancelP2PMarketListing,
  claimTaxPoolReward,
  createP2PMarketListing,
  fetchGlobalTrees,
  fetchMarketState,
  fetchOnlinePlayers,
  fetchOpenFarmJobs,
  fetchP2PMarketListings,
  logPlayerTransaction,
  submitServerLeaderboard,
  transactMarketEconomy,
} from './services/multiplayerClient';
import {
  CallManager,
  CallStateSnapshot,
  DeviceProfile,
  detectDeviceKind,
  detectDeviceProfile,
} from './services/callManager';

interface ProfileMetaPayload {
  xp?: number;
  fun?: number;
  bagUpgrades?: number;
  houseLevel?: number;
  barnLevel?: number;
  coopLevel?: number;
  houseLocked?: boolean;
  barnLocked?: boolean;
  coopLocked?: boolean;
  stableLocked?: boolean;
  hasPhone?: boolean;
  dogName?: string;
  horseName?: string;
  lastResetHomeAt?: number;
  secretGroveUnlocked?: boolean;
  unlockedOutfits?: string[];
  equippedOutfitId?: string;
  toolShortcuts?: string[];
  spouseId?: string | null;
  spousePlayerUid?: string | null;
  spousePlayerName?: string | null;
  weddingDay?: string | null;
  equippedItemId?: string | null;
  skinColor?: string;
  eyeColor?: string;
  pantsColor?: string;
  shirtStyle?: AvatarConfig['shirtStyle'];
  pantsStyle?: AvatarConfig['pantsStyle'];
  hasCheeseMaker?: boolean;
  coopIncubators?: EggIncubatorSlot[];
  attendedFestivalKeys?: string[];
  sleepDayOffset?: number;
  theme?: ThemeMode;
  farmTrees?: WorldTreeRecord[];
}

function normalizeIncubatorSlots(coopLevel: number, existing?: EggIncubatorSlot[]): EggIncubatorSlot[] {
  const count = getIncubatorCount(coopLevel);
  const out: EggIncubatorSlot[] = [];
  for (let i = 0; i < count; i++) {
    const prev = existing?.find((s) => s.slotIndex === i);
    out.push(
      prev
        ? { ...prev, slotIndex: i }
        : { slotIndex: i, eggPlacedDay: null, daysRemaining: 0, readyToHatch: false }
    );
  }
  return out;
}

const SETTINGS_STORAGE_KEY = 'hgv_settings_v1';
const VALID_THEMES: ThemeMode[] = ['system', 'cozy', 'light', 'dark', 'seasonal', 'farmhouse'];
const VALID_CONTROL_MODES: DeviceControlMode[] = ['auto', 'mobile', 'desktop'];

const DEFAULT_GAME_SETTINGS: GameSettings = {
  language: 'id',
  theme: DEFAULT_GLOBAL_THEME,
  mobileMode: false,
  deviceControlMode: 'auto',
  povMode: CAMERA_CONFIG.povMode,
  showSelfCameraInCall: VIDEO_CALL_CONFIG.showSelfPreviewByDefault,
  audio: {
    muted: false,
    masterVolume: 0.8,
    sfxVolume: 0.85,
    musicVolume: 0.65,
  },
  graphics: {
    quality: 'high',
    shadows: true,
    renderScale: 1,
    weatherParticles: true,
    realTimeLighting: true,
    dynamicShadows: true,
    globalIllumination: true,
    realTimeGI: true,
    rayTracing: false,
    pathTracing: false,
  },
};

function loadSavedGameSettings(): GameSettings {
  const initialTheme = themeManager.getTheme();
  const initialLang = localizationManager.getLanguage();
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) {
      return {
        ...DEFAULT_GAME_SETTINGS,
        language: initialLang,
        theme: initialTheme,
      };
    }
    const parsed = JSON.parse(raw) as Partial<GameSettings>;
    const theme = parsed.theme && VALID_THEMES.includes(parsed.theme) ? parsed.theme : initialTheme;
    const deviceControlMode =
      parsed.deviceControlMode && VALID_CONTROL_MODES.includes(parsed.deviceControlMode)
        ? parsed.deviceControlMode
        : parsed.mobileMode
          ? 'mobile'
          : 'auto';
    return {
      language: normalizeLanguage(parsed.language ?? initialLang),
      theme,
      mobileMode: Boolean(parsed.mobileMode),
      deviceControlMode,
      povMode: parsed.povMode === 'free' ? 'free' : parsed.povMode === 'lock' ? 'lock' : CAMERA_CONFIG.povMode,
      showSelfCameraInCall:
        typeof parsed.showSelfCameraInCall === 'boolean'
          ? parsed.showSelfCameraInCall
          : VIDEO_CALL_CONFIG.showSelfPreviewByDefault,
      audio: { ...DEFAULT_GAME_SETTINGS.audio, ...(parsed.audio || {}) },
      graphics: { ...DEFAULT_GAME_SETTINGS.graphics, ...(parsed.graphics || {}) },
    };
  } catch {
    return {
      ...DEFAULT_GAME_SETTINGS,
      language: initialLang,
      theme: initialTheme,
    };
  }
}

function migrateKeyBindings(saved?: Partial<KeyBindings>): KeyBindings {
  const merged: KeyBindings = { ...DEFAULT_KEYBINDINGS, ...(saved || {}) };
  // Upgrade legacy defaults (where R was sprint and Shift was dash) to Shift=Run & R=Dash
  if (saved?.sprint === 'KeyR' && saved?.dash === 'ShiftLeft') {
    merged.sprint = 'ShiftLeft';
    merged.dash = 'KeyR';
  }
  return merged;
}

const EMPTY_CALL_SNAPSHOT: CallStateSnapshot = {
  inCall: false,
  roomId: null,
  mode: 'voice',
  isGroup: false,
  deviceType: detectDeviceKind(),
  facingMode: 'user',
  micOn: false,
  camOn: false,
  localStream: null,
  remoteStreams: {},
  participants: [],
  speakingUids: [],
  connectionStates: {},
  videoConfig: { ...VIDEO_CALL_CONFIG },
  permissions: {
    mic: 'unknown',
    cam: 'unknown',
    hasMicHardware: true,
    hasCamHardware: true,
    needsPermissionPrompt: true,
    secureContext: typeof window !== 'undefined' ? window.isSecureContext : true,
  },
  error: null,
};

function createInitialPlots(): Record<string, FarmPlotState> {
  const plots: Record<string, FarmPlotState> = {};
  for (let gx = 0; gx < FARM_GRID_COLS; gx++) {
    for (let gz = 0; gz < FARM_GRID_ROWS; gz++) {
      const id = `${gx}_${gz}`;
      const starterTilled = (gx === 0 || gx === 1) && gz === 0;
      const inPorchPath = gx >= 9 && gx <= 13 && gz <= 2;

      let obstacle: FarmObstacleType | null = null;
      if (!starterTilled && !inPorchPath) {
        const roll = Math.random();
        if (roll < 0.14) obstacle = 'weed';
        else if (roll < 0.21) obstacle = 'root';
        else if (roll < 0.26) obstacle = 'stump';
        else if (roll < 0.31) obstacle = 'sapling';
        else if (roll < 0.36) obstacle = 'rock';
        else if (roll < 0.41) obstacle = 'tree';
        else if (roll < 0.44) obstacle = 'large_tree';
        else if (roll < 0.47) obstacle = 'large_rock';
      }

      plots[id] = {
        id,
        gx,
        gz,
        tilled: starterTilled,
        watered: false,
        cropId: gx === 0 && gz === 0 ? 'crop_turnip' : null,
        growthDays: gx === 0 && gz === 0 ? 1 : 0,
        readyToHarvest: false,
        fertilized: false,
        obstacle,
        obstacleDays: 0,
      };
    }
  }
  return plots;
}

function createDailyMissions(): DailyMission[] {
  return DAILY_MISSION_TEMPLATES.slice(0, 4).map((t) => ({
    ...t,
    progress: 0,
    claimed: false,
  }));
}

function hasSpringFlowerPlanted(plotsObj: Record<string, FarmPlotState>): boolean {
  return Object.values(plotsObj).some(
    (p) => p.cropId === 'crop_tulip' || p.cropId === 'crop_sunflower'
  );
}

const DEFAULT_AVATAR: AvatarConfig = {
  gender: 'male',
  skinColor: '#fcd5b5',
  eyeColor: '#292524',
  hairStyle: 'none',
  hairColor: '#6b3e1b',
  shirtStyle: 'none',
  pantsStyle: 'none',
  outfitColor: '#3a6b2c',
  pantsColor: '#1e3a8a',
  hatStyle: 'none',
  accessory: 'none',
};

const RESET_HOME_COOLDOWN_MS = 10 * 60 * 1000;

function MainGame() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const mpRef = useRef<MultiplayerClient | null>(null);
  const callManagerRef = useRef<CallManager | null>(null);
  const playerPosRef = useRef<{ x: number; z: number }>({
    x: FARMHOUSE_OUTDOOR_SPAWN.x,
    z: FARMHOUSE_OUTDOOR_SPAWN.z,
  });

  const [started, setStarted] = useState(false);
  const [gameSettings, setGameSettings] = useState<GameSettings>(() => loadSavedGameSettings());
  const [firebaseEmail, setFirebaseEmail] = useState<string | null>(null);
  const [firebaseUid, setFirebaseUid] = useState<string | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isCloudSynced, setIsCloudSynced] = useState(true);
  const [onlineCount, setOnlineCount] = useState(1);

  const [sleepDayOffset, setSleepDayOffset] = useState<number>(() => {
    const meta = (loadLocalSave()?.payload as { meta?: ProfileMetaPayload } | undefined)?.meta;
    return meta?.sleepDayOffset ?? 0;
  });

  const [profile, setProfile] = useState<PlayerProfile>(() => {
    const local = loadLocalSave();
    const meta = (local?.payload as { meta?: ProfileMetaPayload } | undefined)?.meta;
    if (local?.profile) {
      return {
        ...local.profile,
        dogName: meta?.dogName || local.profile.dogName || 'Bobi',
        horseName: meta?.horseName || local.profile.horseName || 'Gale',
        avatarConfig: {
          ...local.profile.avatarConfig,
          skinColor: meta?.skinColor || local.profile.avatarConfig.skinColor || '#fcd5b5',
          eyeColor: meta?.eyeColor || local.profile.avatarConfig.eyeColor || '#292524',
          pantsColor: meta?.pantsColor || local.profile.avatarConfig.pantsColor || '#1e3a8a',
          shirtStyle: meta?.shirtStyle ?? local.profile.avatarConfig.shirtStyle ?? 'tunic',
          pantsStyle: meta?.pantsStyle ?? local.profile.avatarConfig.pantsStyle ?? 'denim',
        },
        xp: meta?.xp ?? local.profile.xp ?? 0,
        fun: meta?.fun ?? local.profile.fun ?? 25,
        bagUpgrades: meta?.bagUpgrades ?? local.profile.bagUpgrades ?? 0,
        houseLevel: meta?.houseLevel ?? local.profile.houseLevel ?? 1,
        barnLevel: meta?.barnLevel ?? local.profile.barnLevel ?? 1,
        coopLevel: meta?.coopLevel ?? local.profile.coopLevel ?? 1,
        hasCheeseMaker: meta?.hasCheeseMaker ?? local.profile.hasCheeseMaker ?? false,
        coopIncubators: normalizeIncubatorSlots(
          meta?.coopLevel ?? local.profile.coopLevel ?? 1,
          meta?.coopIncubators ?? local.profile.coopIncubators
        ),
        attendedFestivalKeys: meta?.attendedFestivalKeys ?? local.profile.attendedFestivalKeys ?? [],
        houseLocked: meta?.houseLocked ?? local.profile.houseLocked ?? false,
        barnLocked: meta?.barnLocked ?? local.profile.barnLocked ?? true,
        coopLocked: meta?.coopLocked ?? local.profile.coopLocked ?? true,
        stableLocked: meta?.stableLocked ?? local.profile.stableLocked ?? true,
        hasPhone: meta?.hasPhone ?? local.profile.hasPhone ?? false,
        lastResetHomeAt: meta?.lastResetHomeAt ?? local.profile.lastResetHomeAt ?? 0,
        secretGroveUnlocked: meta?.secretGroveUnlocked ?? local.profile.secretGroveUnlocked ?? false,
        unlockedOutfits: meta?.unlockedOutfits ?? local.profile.unlockedOutfits ?? ['outfit_classic'],
        equippedOutfitId: meta?.equippedOutfitId ?? local.profile.equippedOutfitId ?? 'outfit_classic',
        toolShortcuts: meta?.toolShortcuts ?? local.profile.toolShortcuts ?? [...DEFAULT_TOOL_SHORTCUTS],
        spouseId: meta?.spouseId ?? local.profile.spouseId ?? null,
        spousePlayerUid: meta?.spousePlayerUid ?? local.profile.spousePlayerUid ?? null,
        spousePlayerName: meta?.spousePlayerName ?? local.profile.spousePlayerName ?? null,
        weddingDay: meta?.weddingDay ?? local.profile.weddingDay ?? null,
      };
    }
    return {
      uid: `guest_${Math.random().toString(36).slice(2, 9)}`,
      avatarName: 'Arthur',
      farmName: 'Great Valley Farm',
      gender: 'male',
      birthday: 'Spring 5',
      dogName: 'Bobi',
      horseName: 'Gale',
      avatarConfig: DEFAULT_AVATAR,
      level: 1,
      xp: 0,
      fun: 25,
      gold: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : NORMAL_STARTER_GOLD,
      diamond: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : NORMAL_STARTER_DIAMOND,
      bagUpgrades: 0,
      houseLevel: 1,
      barnLevel: 1,
      coopLevel: 1,
      hasCheeseMaker: false,
      coopIncubators: normalizeIncubatorSlots(1),
      attendedFestivalKeys: [],
      houseLocked: false,
      barnLocked: true,
      coopLocked: true,
      stableLocked: true,
      hasPhone: false,
      lastResetHomeAt: 0,
      barnBuilt: true,
      coopBuilt: true,
      secretGroveUnlocked: false,
      unlockedOutfits: ['outfit_classic'],
      equippedOutfitId: 'outfit_classic',
      toolShortcuts: [...DEFAULT_TOOL_SHORTCUTS],
      spouseId: null,
      spousePlayerUid: null,
      spousePlayerName: null,
      weddingDay: null,
      version: 1,
    };
  });

  const initialClock = getSynchronizedWorldClock(sleepDayOffset);
  const [season, setSeason] = useState<Season>(initialClock.season);
  const [day, setDay] = useState<number>(initialClock.day);
  const [year, setYear] = useState<number>(initialClock.year);
  const [hour, setHour] = useState<number>(initialClock.hour);
  const [minute, setMinute] = useState<number>(initialClock.minute);
  const lastClockDayKeyRef = useRef<string>(`${initialClock.year}-${initialClock.season}-${initialClock.day}`);
  const [dailyFunTracker, setDailyFunTracker] = useState<DailyFunTracker>(() =>
    createEmptyDailyFunTracker(`${initialClock.year}-${initialClock.season}-${initialClock.day}`)
  );

  const [weather, setWeather] = useState<Weather>(DEFAULT_WEATHER);
  const [stamina, setStamina] = useState(100);
  const maxStamina = 100 + (profile.houseLevel - 1) * 20;

  const [zone, setZone] = useState<WorldZoneId>('farm_home');
  const [visitingFarmOwnerId, setVisitingFarmOwnerId] = useState<string | null>(null);
  const [visitingFarmName, setVisitingFarmName] = useState<string | null>(null);
  const [visitingLocks, setVisitingLocks] = useState<{
    houseLocked: boolean;
    barnLocked: boolean;
    coopLocked: boolean;
    stableLocked: boolean;
  }>({
    houseLocked: false,
    barnLocked: true,
    coopLocked: true,
    stableLocked: true,
  });

  const [inventory, setInventory] = useState<InventorySlot[]>(() => {
    const p = loadLocalSave()?.payload as { inventory?: InventorySlot[] } | undefined;
    return p?.inventory || INITIAL_INVENTORY;
  });
  const [fridgeItems, setFridgeItems] = useState<InventorySlot[]>(() => {
    const p = loadLocalSave()?.payload as { fridgeItems?: InventorySlot[] } | undefined;
    return p?.fridgeItems || [];
  });
  const [toolboxItems, setToolboxItems] = useState<InventorySlot[]>(() => {
    const p = loadLocalSave()?.payload as { toolboxItems?: InventorySlot[] } | undefined;
    return p?.toolboxItems || [];
  });
  const [equippedItemId, setEquippedItemId] = useState<string | null>(() => {
    const meta = (loadLocalSave()?.payload as { meta?: ProfileMetaPayload } | undefined)?.meta;
    return meta?.equippedItemId ?? null;
  });
  const [plots, setPlots] = useState<Record<string, FarmPlotState>>(() => {
    const p = loadLocalSave()?.payload as { plots?: Record<string, FarmPlotState> } | undefined;
    return p?.plots || createInitialPlots();
  });
  const [animals, setAnimals] = useState<AnimalState[]>(() => {
    const p = loadLocalSave()?.payload as { animals?: AnimalState[] } | undefined;
    return p?.animals || [];
  });
  const [appleTree, setAppleTree] = useState<AppleTreeState>(() => {
    const p = loadLocalSave()?.payload as { appleTree?: AppleTreeState } | undefined;
    if (p?.appleTree) return p.appleTree;
    const isAppleSeason = initialClock.season === 'Summer' || initialClock.season === 'Autumn';
    return {
      applesReady: isAppleSeason ? 3 : 0,
      lastAppleDay: initialClock.day,
      honeyReady: initialClock.season === 'Spring',
      lastHoneyDay: initialClock.day,
    };
  });
  const [keybindings, setKeybindings] = useState<KeyBindings>(() => {
    const p = loadLocalSave()?.payload as { keyBindings?: KeyBindings } | undefined;
    return migrateKeyBindings(p?.keyBindings);
  });

  const [npcRels, setNpcRels] = useState<Record<string, NPCRelationshipState>>(() => {
    const p = loadLocalSave()?.payload as { npcRels?: Record<string, NPCRelationshipState> } | undefined;
    return p?.npcRels || createInitialNpcRelationships();
  });
  const [dailyMissions, setDailyMissions] = useState<DailyMission[]>(() => createDailyMissions());
  const [completedQuests, setCompletedQuests] = useState<string[]>(() => {
    const p = loadLocalSave()?.payload as { completedQuests?: string[] } | undefined;
    return p?.completedQuests || [];
  });
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>(() => {
    const p = loadLocalSave()?.payload as { unlockedAchievements?: string[] } | undefined;
    return p?.unlockedAchievements || [];
  });
  const [stats, setStats] = useState<GameStats>(() => {
    const p = loadLocalSave()?.payload as { stats?: GameStats } | undefined;
    return {
      cropsPlanted: 0,
      cropsWatered: 0,
      cropsHarvested: 0,
      fishCaught: 0,
      materialsGathered: 0,
      totalGoldEarned: 0,
      giftsGiven: 0,
      festivalsAttended: 0,
      ...(p?.stats || {}),
      salesStats: p?.stats?.salesStats || createEmptySalesStats(),
    };
  });
  const [farmTrees, setFarmTrees] = useState<WorldTreeRecord[]>(() => {
    const saved = loadLocalSave();
    const meta = (saved?.payload as { meta?: ProfileMetaPayload } | undefined)?.meta;
    if (Array.isArray(meta?.farmTrees) && meta.farmTrees.length > 0) {
      return meta.farmTrees;
    }
    return generateUserFarmTrees(saved?.profile?.uid || 'local_farmer');
  });
  const [isSleeping, setIsSleeping] = useState<boolean>(false);
  const sleepStartedAtRef = useRef<number>(0);

  const [notifSettings, setNotifSettings] = useState<NotificationSettings>({
    dailyMissions: true,
    achievements: true,
    rewards: true,
    specialEvents: true,
    multiplayer: true,
  });
  const [muted, setMuted] = useState(() => gameSettings.audio.muted);

  // Market & Economy State
  const [marketState, setMarketState] = useState<MarketState | null>(null);
  const [taxBuckets, setTaxBuckets] = useState<Record<number, number>>({ 1: 0, 2: 0, 3: 0 });

  // Farm Jobs Board, Head-Tracked Bubbles, Friends, P2P Diamond Market & Device Profile
  const [deviceProfile, setDeviceProfile] = useState<DeviceProfile>(() => detectDeviceProfile());
  const [friends, setFriends] = useState<FriendRecord[]>([]);
  const [incomingFriendRequests, setIncomingFriendRequests] = useState<FriendRequestRecord[]>([]);
  const [outgoingFriendRequests, setOutgoingFriendRequests] = useState<FriendRequestRecord[]>([]);
  const [allOnlinePlayers, setAllOnlinePlayers] = useState<
    Array<{ uid: string; avatarName: string; farmName: string; zone: string; level: number }>
  >([]);
  const [p2pListings, setP2pListings] = useState<P2PMarketListing[]>([]);
  const [farmJobs, setFarmJobs] = useState<FarmJobOffer[]>([]);
  const [headAnchors, setHeadAnchors] = useState<PlayerHeadAnchor[]>([]);
  const [chatBubbles, setChatBubbles] = useState<FloatingChatBubble[]>([]);
  const [callState, setCallState] = useState<CallStateSnapshot>(EMPTY_CALL_SNAPSHOT);
  const [incomingInvite, setIncomingInvite] = useState<IncomingCallInvite | null>(null);

  // Overlays & Draggable Popups
  const [showInventory, setShowInventory] = useState(false);
  const [npcDialogState, setNpcDialogState] = useState<{ npcId: string; tab: 'talk' | 'shop' } | null>(null);
  const [bukuTab, setBukuTab] = useState<BukuTab | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [liveRuntimeConfig, setLiveRuntimeConfig] = useState<RuntimeGameConfig>(() => ({
    debugMode: DEVELOPER_DEBUG_MODE,
    normalStarterGold: NORMAL_STARTER_GOLD,
    normalStarterDiamond: NORMAL_STARTER_DIAMOND,
    paymentMethods: { ...PAYMENT_METHODS },
    defaultGlobalTheme: DEFAULT_GLOBAL_THEME,
    defaultWeather: DEFAULT_WEATHER,
    weatherControl: { ...WEATHER_CONTROL, weights: { ...WEATHER_CONTROL.weights } },
    announcementBanner: { ...ANNOUNCEMENT_BANNER_CONFIG },
    fishingConfig: { ...FISHING_CONFIG },
    caveMiningConfig: { ...CAVE_MINING_CONFIG },
    globalTreeEcosystem: { ...GLOBAL_TREE_ECOSYSTEM },
    videoCallConfig: { ...VIDEO_CALL_CONFIG },
    cameraConfig: { ...CAMERA_CONFIG },
    mobileControlsConfig: { ...MOBILE_CONTROLS_CONFIG },
    marketEconomyConfig: { ...MARKET_ECONOMY_CONFIG },
    economyTaxConfig: { ...ECONOMY_TAX_CONFIG, goldTiers: [...ECONOMY_TAX_CONFIG.goldTiers], diamondTiers: [...ECONOMY_TAX_CONFIG.diamondTiers] },
    nameChangeEconomyConfig: { ...NAME_CHANGE_ECONOMY_CONFIG },
    performanceConfig: { ...PERFORMANCE_CONFIG },
    itemTradeRates: { ...ITEM_TRADE_RATES },
    guestSessionConfig: { ...GUEST_SESSION_CONFIG },
    worldTimeOverride: { ...WORLD_TIME_OVERRIDE },
  }));
  const [socialAccount, setSocialAccount] = useState<NakamaSocialAccount | null>(null);
  const [characterRoster, setCharacterRoster] = useState<CharacterRosterEntry[]>([]);
  const [activeCharacterId, setActiveCharacterId] = useState<string | null>(null);
  const [isGuestSession, setIsGuestSession] = useState<boolean>(false);
  const [guestStartedAt, setGuestStartedAt] = useState<number | null>(null);
  const [guestRemainingSec, setGuestRemainingSec] = useState<number | null>(null);
  const guestWarnedRef = useRef<boolean>(false);
  const steamAuthCleanupRef = useRef<(() => void) | null>(null);
  const isGuestSessionRef = useRef<boolean>(false);
  const activeCharacterIdRef = useRef<string | null>(null);
  const socialAccountRef = useRef<NakamaSocialAccount | null>(null);
  const startedRef = useRef<boolean>(false);
  isGuestSessionRef.current = isGuestSession;
  activeCharacterIdRef.current = activeCharacterId;
  socialAccountRef.current = socialAccount;
  startedRef.current = started;
  const [announcementNonce, setAnnouncementNonce] = useState<number>(1);
  const [mobileSprintActive, setMobileSprintActive] = useState<boolean>(false);
  const [activeBan, setActiveBan] = useState<PlayerBanRecord | null>(null);
  const [activeAnnouncement, setActiveAnnouncement] = useState<{
    title: string;
    message: string;
    category?: AnnouncementCategory;
    durationSec: number;
  } | null>(() =>
    ANNOUNCEMENT_BANNER_CONFIG.enabled
      ? {
          title: ANNOUNCEMENT_BANNER_CONFIG.title,
          message: ANNOUNCEMENT_BANNER_CONFIG.message,
          category: ANNOUNCEMENT_BANNER_CONFIG.category || 'update',
          durationSec: ANNOUNCEMENT_BANNER_CONFIG.durationSec || 10,
        }
      : null
  );
  const resourceHitsRef = useRef<Map<string, { hits: number; lastHitAt: number }>>(new Map());
  const [chatInitialChannel, setChatInitialChannel] = useState<ChatMessage['channel']>('global');
  const [chatPrivateTarget, setChatPrivateTarget] = useState<{ uid: string; name: string } | null>(null);
  const [autoGiveEnabled, setAutoGiveEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem('gv_auto_give') !== '0';
    } catch {
      return true;
    }
  });
  const [worldSpeechBubbles, setWorldSpeechBubbles] = useState<WorldSpeechBubble[]>([]);
  const [npcChoicePopover, setNpcChoicePopover] = useState<{
    npcId: string;
    npcName: string;
    heldItemName: string;
    heldItemEmoji: string;
  } | null>(null);
  const [caveLevel, setCaveLevel] = useState<number>(1);
  const caveHoleCoordRef = useRef<{ gx: number; gz: number }>({ gx: 1, gz: -1 });
  const caveHoleRevealedRef = useRef<boolean>(false);
  const [fishingBar, setFishingBar] = useState<{
    active: boolean;
    phase: 'casting' | 'waiting' | 'bite' | 'reeling';
    cursorPct: number;
    zoneStartPct: number;
    zoneWidthPct: number;
    strikesHit: number;
    strikesRequired: number;
  } | null>(null);
  const fishingSessionRef = useRef<{
    active: boolean;
    phase: 'idle' | 'casting' | 'waiting' | 'bite' | 'reeling';
    spotType: 'river' | 'ocean';
    luckPct: number;
    hasBait: boolean;
    cursorPct: number;
    dir: number;
    zoneStartPct: number;
    zoneWidthPct: number;
    strikesHit: number;
    strikesRequired: number;
    castTimer: number | null;
    biteTimer: number | null;
    rafId: number | null;
    lastTs: number;
  }>({
    active: false,
    phase: 'idle',
    spotType: 'river',
    luckPct: 50,
    hasBait: false,
    cursorPct: 0,
    dir: 1,
    zoneStartPct: 38,
    zoneWidthPct: FISHING_CONFIG.greenZoneWidthPct,
    strikesHit: 0,
    strikesRequired: FISHING_CONFIG.strikesRequired,
    castTimer: null,
    biteTimer: null,
    rafId: null,
    lastTs: 0,
  });
  const [activeFacilityModal, setActiveFacilityModal] = useState<'tv' | 'fridge' | 'toolbox' | 'wardrobe' | null>(null);
  const [showStyleStudio, setShowStyleStudio] = useState(false);
  const [pendingHatchSlotIndex, setPendingHatchSlotIndex] = useState<number | null>(null);
  const [hatchChickName, setHatchChickName] = useState('Peep');
  const [incomingProposal, setIncomingProposal] = useState<MarriageProposalPayload | null>(null);
  const [gamepadStatus, setGamepadStatus] = useState<{ connected: boolean; name?: string }>({ connected: false });

  const [doorPrompt, setDoorPrompt] = useState<{
    buildingKind: 'farmhouse' | 'barn' | 'coop' | 'stable';
    isInside: boolean;
    targetZone: WorldZoneId;
  } | null>(null);
  const [tutorialStep, setTutorialStep] = useState<number>(() => (loadLocalSave() ? -1 : 0));

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  // Local moderation state mirrors the server's per-session mutedIds set.
  const [mutedPlayerIds, setMutedPlayerIds] = useState<Set<string>>(() => new Set());
  const [remotePeers, setRemotePeers] = useState<OnlinePlayerState[]>([]);
  const [nearbyPrompt, setNearbyPrompt] = useState<NearbyPrompt | null>(null);
  const [floatingTags, setFloatingTags] = useState<FloatingTag[]>([]);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  const showToast = useCallback(
    (msg: string, notifCategory?: keyof NotificationSettings) => {
      setToast(msg);
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
      toastTimerRef.current = window.setTimeout(() => setToast(null), 3600);

      if (notifCategory && notifSettings[notifCategory] && 'Notification' in window && Notification.permission === 'granted') {
        new Notification('Harvest in the Great Valley', { body: msg });
      }
    },
    [notifSettings]
  );

  // Fresh refs for engine callbacks & periodic cloud save
  const stateRef = useRef({
    profile,
    season,
    day,
    year,
    hour,
    weather,
    stamina,
    maxStamina,
    inventory,
    fridgeItems,
    toolboxItems,
    appleTree,
    keybindings,
    sleepDayOffset,
    equippedItemId,
    plots,
    animals,
    zone,
    visitingFarmOwnerId,
    visitingLocks,
    npcRels,
    firebaseUid,
    stats,
    unlockedAchievements,
    dailyFunTracker,
    farmJobs,
    gameSettings,
    farmTrees,
    autoGiveEnabled,
    caveLevel,
    liveRuntimeConfig,
  });
  stateRef.current = {
    profile,
    season,
    day,
    year,
    hour,
    weather,
    stamina,
    maxStamina,
    inventory,
    fridgeItems,
    toolboxItems,
    appleTree,
    keybindings,
    sleepDayOffset,
    equippedItemId,
    plots,
    animals,
    zone,
    visitingFarmOwnerId,
    visitingLocks,
    npcRels,
    firebaseUid,
    stats,
    unlockedAchievements,
    dailyFunTracker,
    farmJobs,
    gameSettings,
    farmTrees,
    autoGiveEnabled,
    caveLevel,
    liveRuntimeConfig,
  };

  const pushWorldSpeechBubble = useCallback(
    (
      anchorId: string,
      speakerName: string,
      text: string,
      kind: WorldSpeechBubble['kind'] = 'npc',
      durationMs = 5500,
      extra?: { emotion?: WorldSpeechBubble['emotion']; isThought?: boolean }
    ) => {
      const now = Date.now();
      const id = `${anchorId}_${now}_${Math.random().toString(36).slice(2, 6)}`;
      const bubble: WorldSpeechBubble = {
        id,
        anchorId,
        speakerName,
        text,
        kind,
        emotion: extra?.emotion,
        isThought: extra?.isThought,
        createdAt: now,
        expiresAt: now + durationMs,
      };
      setWorldSpeechBubbles((prev) => [...prev.filter((b) => b.anchorId !== anchorId && b.expiresAt > now), bubble]);
      if (anchorId.startsWith('npc:')) {
        engineRef.current?.triggerNpcSpeechBreath(anchorId.slice(4));
      } else if (anchorId === 'player' || anchorId === stateRef.current.profile.uid) {
        engineRef.current?.triggerPlayerSpeechBreath(2.4);
      }
      window.setTimeout(() => {
        setWorldSpeechBubbles((prev) => prev.filter((b) => b.id !== id));
      }, durationMs + 120);
    },
    []
  );

  const rollCaveHoleCoord = useCallback((): { gx: number; gz: number } => {
    const candidates: Array<{ gx: number; gz: number }> = [];
    for (let gx = -4; gx <= 4; gx++) {
      for (let gz = -3; gz <= 2; gz++) {
        if (gx === 0 && gz === 2) continue;
        candidates.push({ gx, gz });
      }
    }
    return candidates[Math.floor(Math.random() * candidates.length)] || { gx: 1, gz: -1 };
  }, []);

  // Slow stamina regeneration when resting inside own house OR married spouse's house
  useEffect(() => {
    if (!started) return;
    const isOwnOrSpouseHouse =
      zone === 'int_farmhouse' &&
      (!visitingFarmOwnerId ||
        (Boolean(profile.spousePlayerUid) && visitingFarmOwnerId === profile.spousePlayerUid));
    if (!isOwnOrSpouseHouse) return;
    const timer = window.setInterval(() => {
      setStamina((prev) => {
        const cap = stateRef.current.maxStamina;
        if (prev >= cap) return prev;
        return Math.min(cap, prev + 2);
      });
    }, 2500);
    return () => window.clearInterval(timer);
  }, [started, zone, visitingFarmOwnerId, profile.spousePlayerUid]);

  // === APPLY AUDIO, GRAPHICS & PER-USER THEME SETTINGS LIVE ===
  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(gameSettings));
    } catch {
      // Ignore storage quota errors
    }
    soundEngine.setAudioSettings(gameSettings.audio);
    setMuted(gameSettings.audio.muted);
    engineRef.current?.applyGraphicsSettings(gameSettings.graphics);
  }, [gameSettings]);

  // === HARVEST MOON: BACK TO NATURE–STYLE DYNAMIC PASTORAL SOUNDTRACK ===
  useEffect(() => {
    const festivalToday = FESTIVALS.find((f) => f.season === season && f.day === day);
    const isFestivalLive = Boolean(
      started &&
        festivalToday &&
        hour >= (festivalToday.startHour ?? 10) &&
        hour <= (festivalToday.endHour ?? 18) &&
        zone === 'village_square'
    );
    const mood: MusicMoodKey = !started
      ? 'title'
      : isFestivalLive
        ? 'festival'
        : zone.startsWith('int_')
          ? 'indoor'
          : season;
    soundEngine.setMusicMood(mood);
  }, [started, season, day, hour, zone]);

  // Start background music cleanly on the first browser gesture (respects autoplay policy)
  useEffect(() => {
    let unlocked = false;
    const unlockMusic = () => {
      if (unlocked) return;
      unlocked = true;
      soundEngine.startBackgroundMusic();
      window.removeEventListener('pointerdown', unlockMusic);
      window.removeEventListener('keydown', unlockMusic);
    };
    window.addEventListener('pointerdown', unlockMusic, { passive: true });
    window.addEventListener('keydown', unlockMusic, { passive: true });
    return () => {
      window.removeEventListener('pointerdown', unlockMusic);
      window.removeEventListener('keydown', unlockMusic);
    };
  }, []);

  // Theme application is strictly centralized inside themeManager (see unified Theme Manager sync effect below).

  // Strict screen-size & device hardware detection listener
  useEffect(() => {
    const onResize = () => setDeviceProfile(detectDeviceProfile());
    window.addEventListener('resize', onResize);
    window.addEventListener('orientationchange', onResize);
    return () => {
      window.removeEventListener('resize', onResize);
      window.removeEventListener('orientationchange', onResize);
    };
  }, []);

  const effectiveMobileMode =
    gameSettings.deviceControlMode === 'mobile'
      ? true
      : gameSettings.deviceControlMode === 'desktop'
        ? false
        : Boolean(deviceProfile.isPhone || gameSettings.mobileMode);

  // Automatic Mobile Fullscreen Mode + Gesture Fallback
  useEffect(() => {
    const rootEl = document.documentElement;
    if (!started || !effectiveMobileMode) {
      rootEl.classList.remove('mobile-fullscreen-active');
      return;
    }
    rootEl.classList.add('mobile-fullscreen-active');
    const tryEnterFullscreen = () => {
      if (!document.fullscreenElement && rootEl.requestFullscreen) {
        rootEl.requestFullscreen().catch(() => {
          // Ignore browsers requiring explicit gesture; pointerdown below retries cleanly
        });
      }
      const orient = screen.orientation as unknown as { lock?: (mode: string) => Promise<void> } | undefined;
      orient?.lock?.('landscape').catch(() => {
        // Orientation lock is optional and browser-dependent
      });
    };
    tryEnterFullscreen();
    const onFirstTap = () => {
      tryEnterFullscreen();
      window.removeEventListener('pointerdown', onFirstTap);
    };
    window.addEventListener('pointerdown', onFirstTap, { passive: true });
    return () => {
      window.removeEventListener('pointerdown', onFirstTap);
      rootEl.classList.remove('mobile-fullscreen-active');
    };
  }, [started, effectiveMobileMode]);

  const handleExitMobileMode = useCallback(() => {
    document.documentElement.classList.remove('mobile-fullscreen-active');
    if (document.fullscreenElement && document.exitFullscreen) {
      document.exitFullscreen().catch(() => {});
    }
    const orient = screen.orientation as unknown as { unlock?: () => void } | undefined;
    try {
      orient?.unlock?.();
    } catch {
      // ignore unsupported unlock
    }
    setGameSettings((prev) => ({
      ...prev,
      deviceControlMode: 'desktop',
      mobileMode: false,
    }));
  }, []);

  // Sync Global Theme Manager, Season Theme & Localization Manager across entire app (strict single rule)
  useEffect(() => {
    themeManager.setTheme(gameSettings.theme || 'system');
  }, [gameSettings.theme]);

  useEffect(() => {
    themeManager.setSeason(season);
  }, [season]);

  useEffect(() => {
    const safeLang = normalizeLanguage(gameSettings.language);
    localizationManager.setLanguage(safeLang);
    engineRef.current?.setLanguage(safeLang);
  }, [gameSettings.language]);

  useEffect(() => {
    const unsubTheme = themeManager.subscribe(({ theme }) => {
      setGameSettings((prev) => (prev.theme === theme ? prev : { ...prev, theme }));
    });
    const unsubLocale = localizationManager.subscribe((nextLang) => {
      setGameSettings((prev) => (prev.language === nextLang ? prev : { ...prev, language: nextLang }));
    });
    return () => {
      unsubTheme();
      unsubLocale();
    };
  }, []);

  // Poll / check ban status on login & lock engine movement when suspended
  useEffect(() => {
    const uid = profile.uid;
    if (!uid || uid === 'local_player') return;
    let cancelled = false;
    void fetch(`/api/player/ban-status?uid=${encodeURIComponent(uid)}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (!cancelled && data?.ok) {
          setActiveBan((data.ban as PlayerBanRecord) || null);
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [profile.uid, started]);

  useEffect(() => {
    const locked = Boolean(activeBan && activeBan.active && activeBan.banType !== 'chat_ban');
    engineRef.current?.setMovementLocked(locked);
  }, [activeBan]);

  const recordSaleStat = useCallback((kind: 'market_gold' | 'p2p_diamond', saleSeason: Season, qty: number, revenue: number) => {
    setStats((st) => {
      const prevSales: SalesStats = st.salesStats || createEmptySalesStats();
      const nextSales: SalesStats = {
        marketGoldBySeason: { ...prevSales.marketGoldBySeason },
        marketGoldTotalQty: prevSales.marketGoldTotalQty,
        marketGoldTotalRevenue: prevSales.marketGoldTotalRevenue,
        p2pDiamondBySeason: { ...prevSales.p2pDiamondBySeason },
        p2pDiamondTotalQty: prevSales.p2pDiamondTotalQty,
        p2pDiamondTotalRevenue: prevSales.p2pDiamondTotalRevenue,
      };
      if (kind === 'market_gold') {
        const cur = nextSales.marketGoldBySeason[saleSeason] || { qty: 0, revenue: 0 };
        nextSales.marketGoldBySeason[saleSeason] = { qty: cur.qty + qty, revenue: cur.revenue + revenue };
        nextSales.marketGoldTotalQty += qty;
        nextSales.marketGoldTotalRevenue += revenue;
      } else {
        const cur = nextSales.p2pDiamondBySeason[saleSeason] || { qty: 0, revenue: 0 };
        nextSales.p2pDiamondBySeason[saleSeason] = { qty: cur.qty + qty, revenue: cur.revenue + revenue };
        nextSales.p2pDiamondTotalQty += qty;
        nextSales.p2pDiamondTotalRevenue += revenue;
      }
      const nextTotalGold = kind === 'market_gold' ? st.totalGoldEarned + revenue : st.totalGoldEarned;
      return { ...st, totalGoldEarned: nextTotalGold, salesStats: nextSales };
    });
  }, []);

  // === EXPIRE FLOATING HEAD CHAT BUBBLES ===
  useEffect(() => {
    if (chatBubbles.length === 0) return;
    const timer = window.setInterval(() => {
      const now = Date.now();
      setChatBubbles((prev) => prev.filter((b) => b.expiresAt > now));
    }, 1000);
    return () => clearInterval(timer);
  }, [chatBubbles.length]);

  // === SAVE SNAPSHOT BUILDER ===
  const buildLocalSnapshot = useCallback((): OfflineSaveSnapshot => {
    const s = stateRef.current;
    const meta: ProfileMetaPayload = {
      xp: s.profile.xp,
      fun: s.profile.fun,
      bagUpgrades: s.profile.bagUpgrades,
      houseLevel: s.profile.houseLevel,
      barnLevel: s.profile.barnLevel,
      coopLevel: s.profile.coopLevel,
      houseLocked: s.profile.houseLocked,
      barnLocked: s.profile.barnLocked,
      coopLocked: s.profile.coopLocked,
      stableLocked: s.profile.stableLocked ?? true,
      hasPhone: Boolean(s.profile.hasPhone),
      dogName: s.profile.dogName,
      horseName: s.profile.horseName,
      lastResetHomeAt: s.profile.lastResetHomeAt,
      secretGroveUnlocked: s.profile.secretGroveUnlocked,
      unlockedOutfits: s.profile.unlockedOutfits,
      equippedOutfitId: s.profile.equippedOutfitId,
      toolShortcuts: s.profile.toolShortcuts,
      spouseId: s.profile.spouseId,
      spousePlayerUid: s.profile.spousePlayerUid,
      spousePlayerName: s.profile.spousePlayerName,
      weddingDay: s.profile.weddingDay,
      equippedItemId: s.equippedItemId,
      skinColor: s.profile.avatarConfig.skinColor || '#fcd5b5',
      eyeColor: s.profile.avatarConfig.eyeColor || '#292524',
      pantsColor: s.profile.avatarConfig.pantsColor || '#1e3a8a',
      shirtStyle: s.profile.avatarConfig.shirtStyle,
      pantsStyle: s.profile.avatarConfig.pantsStyle,
      hasCheeseMaker: Boolean(s.profile.hasCheeseMaker),
      coopIncubators: s.profile.coopIncubators,
      attendedFestivalKeys: s.profile.attendedFestivalKeys,
      sleepDayOffset: s.sleepDayOffset,
      theme: s.gameSettings.theme,
      farmTrees: s.farmTrees,
    };
    return {
      profile: { ...s.profile, version: s.profile.version + 1 },
      season: s.season,
      day: s.day,
      year: s.year,
      payload: {
        plots: s.visitingFarmOwnerId ? undefined : s.plots,
        inventory: s.inventory,
        fridgeItems: s.fridgeItems,
        toolboxItems: s.toolboxItems,
        animals: s.animals,
        appleTree: s.appleTree,
        keyBindings: s.keybindings,
        npcRels: s.npcRels,
        completedQuests,
        unlockedAchievements: s.unlockedAchievements,
        stats: s.stats,
        meta,
      },
      dirtyProfile: true,
      dirtyFarm: !s.visitingFarmOwnerId,
      queuedAt: Date.now(),
    };
  }, [completedQuests]);

  // === PROGRESSION HELPERS (WITH ANTI-SPAM JOY TRACKING) ===
  const rewardProgress = useCallback(
    (baseXp: number, baseFun: number) => {
      let leveledUpTo: number | null = null;
      setProfile((p) => {
        const xpRes = applyXpProgress(p.level, p.xp, baseXp);
        const funRes = applyFunProgress(p.fun, baseFun);
        if (xpRes.leveledUp) leveledUpTo = xpRes.level;
        return {
          ...p,
          level: xpRes.level,
          xp: xpRes.xp,
          fun: funRes.fun,
        };
      });
      if (leveledUpTo !== null) {
        soundEngine.playHeart();
        showToast(`🌟 Congratulations! You reached Level ${leveledUpTo}!`);
      }
    },
    [showToast]
  );

  const rewardOncePerDayJoy = useCallback(
    (actionKey: string, baseXp: number, baseFun: number): number => {
      const s = stateRef.current;
      const res = applyOncePerDayFun(s.dailyFunTracker, actionKey, baseFun, s.profile.fun);
      stateRef.current.dailyFunTracker = res.tracker;
      setDailyFunTracker(res.tracker);
      if (res.funAdded > 0 || baseXp > 0) {
        let leveledUpTo: number | null = null;
        setProfile((p) => {
          const xpRes = baseXp > 0 ? applyXpProgress(p.level, p.xp, baseXp) : { level: p.level, xp: p.xp, leveledUp: false };
          if (xpRes.leveledUp) leveledUpTo = xpRes.level;
          return { ...p, level: xpRes.level, xp: xpRes.xp, fun: res.fun };
        });
        if (leveledUpTo !== null) {
          soundEngine.playHeart();
          showToast(`🌟 Congratulations! You reached Level ${leveledUpTo}!`);
        }
      }
      return res.funAdded;
    },
    [showToast]
  );

  const rewardDiminishingJoy = useCallback(
    (actionKey: string, baseXp: number, baseFun: number): { added: number; nextAmount: number } => {
      const s = stateRef.current;
      const res = applyDiminishingFun(s.dailyFunTracker, actionKey, baseFun, s.profile.fun);
      stateRef.current.dailyFunTracker = res.tracker;
      setDailyFunTracker(res.tracker);
      let leveledUpTo: number | null = null;
      setProfile((p) => {
        const xpRes = baseXp > 0 ? applyXpProgress(p.level, p.xp, baseXp) : { level: p.level, xp: p.xp, leveledUp: false };
        if (xpRes.leveledUp) leveledUpTo = xpRes.level;
        return { ...p, level: xpRes.level, xp: xpRes.xp, fun: res.fun };
      });
      if (leveledUpTo !== null) {
        soundEngine.playHeart();
        showToast(`🌟 Congratulations! You reached Level ${leveledUpTo}!`);
      }
      const nextCount = res.tracker.diminishingCounts[actionKey] || 0;
      return { added: res.funAdded, nextAmount: Number((baseFun * Math.pow(0.5, nextCount)).toFixed(2)) };
    },
    [showToast]
  );

  // === MASTER HAND SLOT SYNC ===
  const setMasterHandItem = useCallback((itemId: string | null) => {
    setEquippedItemId(itemId);
    const toolKind = itemId ? ITEMS[itemId]?.toolKind : undefined;
    engineRef.current?.setEquippedTool(toolKind);
    engineRef.current?.setActiveHeldItem(itemId);
    soundEngine.playUiClick();
  }, []);

  useEffect(() => {
    engineRef.current?.setActiveHeldItem(equippedItemId);
  }, [equippedItemId]);

  // === INVENTORY HELPERS (Respecting 24 -> 90 Bag Slot Capacity + Separate Diamond vs Normal Stacks) ===
  const addInventoryItem = useCallback(
    (itemId: string, qty = 1, extra?: Partial<InventorySlot>): boolean => {
      const prev = stateRef.current.inventory;
      const maxSlots = getMaxBagSlots(stateRef.current.profile.bagUpgrades);
      const itemDef = ITEMS[itemId];
      const isTool = itemDef?.category === 'Tools';
      const rolledTradeable = isTool
        ? false
        : extra?.diamondTradeable !== undefined
          ? Boolean(extra.diamondTradeable)
          : rollItemDiamondTradeable(itemId);
      const idx = prev.findIndex((s) =>
        isTool
          ? s.itemId === itemId
          : s.itemId === itemId && Boolean(s.diamondTradeable) === rolledTradeable
      );
      const next = [...prev];
      if (idx >= 0) {
        next[idx] = {
          ...next[idx],
          quantity: next[idx].quantity + qty,
          diamondTradeable: rolledTradeable,
        };
      } else {
        if (next.length >= maxSlots) {
          showToast(
            `🎒 Bag is full (${next.length}/${maxSlots})! Store items in your Fridge/Toolbox or upgrade your bag.`
          );
          return false;
        }
        next.push({ itemId, quantity: qty, ...extra, diamondTradeable: rolledTradeable });
      }
      stateRef.current.inventory = next;
      setInventory(next);
      return true;
    },
    [showToast]
  );

  const consumeInventoryItem = useCallback(
    (itemId: string, qty = 1, allowZeroToolRemoval = false, onlyDiamondTradeable = false): boolean => {
      const prev = stateRef.current.inventory;
      // Prefer normal (non-diamond) stack first unless onlyDiamondTradeable is requested
      let idx = -1;
      if (onlyDiamondTradeable) {
        idx = prev.findIndex((s) => s.itemId === itemId && Boolean(s.diamondTradeable) && s.quantity >= qty);
      } else {
        idx = prev.findIndex((s) => s.itemId === itemId && !s.diamondTradeable && s.quantity >= qty);
        if (idx < 0) {
          idx = prev.findIndex((s) => s.itemId === itemId && s.quantity >= qty);
        }
      }
      if (idx < 0) return false;
      const copy = [...prev];
      const nextQty = copy[idx].quantity - qty;
      let emptied = false;
      if (nextQty <= 0 && (ITEMS[itemId]?.category !== 'Tools' || allowZeroToolRemoval)) {
        copy.splice(idx, 1);
        emptied = true;
      } else {
        copy[idx] = { ...copy[idx], quantity: nextQty };
      }
      stateRef.current.inventory = copy;
      setInventory(copy);
      if (emptied && stateRef.current.equippedItemId === itemId && !copy.some((s) => s.itemId === itemId)) {
        setEquippedItemId(null);
        engineRef.current?.setEquippedTool(undefined);
        engineRef.current?.setActiveHeldItem(null);
      }
      return true;
    },
    []
  );

  // 10-second multi-hit resource tracker for 4-level trees & rocks
  const stepResourceHits = useCallback((resourceKey: string, hitsNeeded: number) => {
    const now = Date.now();
    const prev = resourceHitsRef.current.get(resourceKey);
    const expired = Boolean(prev && now - prev.lastHitAt > 10_000);
    const current = expired ? 1 : (prev?.hits || 0) + 1;
    if (current >= hitsNeeded) {
      resourceHitsRef.current.delete(resourceKey);
      return { done: true, current, expired };
    }
    resourceHitsRef.current.set(resourceKey, { hits: current, lastHitAt: now });
    return { done: false, current, expired };
  }, []);

  const advanceMission = useCallback((type: DailyMission['type'], amount = 1) => {
    setDailyMissions((prev) =>
      prev.map((m) => (m.type === type && !m.claimed ? { ...m, progress: Math.min(m.target, m.progress + amount) } : m))
    );
  }, []);

  const unlockAchievement = useCallback(
    (achId: string) => {
      setUnlockedAchievements((prev) => {
        if (prev.includes(achId)) return prev;
        const ach = ACHIEVEMENTS.find((a) => a.id === achId);
        if (ach) {
          setProfile((p) => ({ ...p, gold: p.gold + ach.rewardGold, version: p.version + 1 }));
          soundEngine.playHeart();
          showToast(`🏆 Achievement Unlocked: ${ach.title} (+${ach.rewardGold} G)`, 'achievements');
        }
        return [...prev, achId];
      });
    },
    [showToast]
  );

  // === QUICK-SWAP TOOL SHORTCUTS (1..6) ===
  const handleTriggerToolSlot = useCallback(
    (slotNum: number) => {
      const s = stateRef.current;
      const shortcutList = s.profile.toolShortcuts || DEFAULT_TOOL_SHORTCUTS;
      const targetId = shortcutList[slotNum - 1];
      if (!targetId) return;
      const owned = s.inventory.some((slot) => slot.itemId === targetId && slot.quantity > 0);
      if (!owned) {
        showToast(`You don't have ${ITEMS[targetId]?.name || 'that tool'} in your Bag right now.`);
        return;
      }
      if (s.equippedItemId === targetId) {
        setMasterHandItem(null);
      } else {
        setMasterHandItem(targetId);
      }
    },
    [setMasterHandItem, showToast]
  );

  // === FARM PLOT INTERACTION (F - Close-range, including Natural Obstacle Clearing) ===
  const handleInteractPlot = useCallback(
    (gx: number, gz: number) => {
      const s = stateRef.current;
      const plotId = `${gx}_${gz}`;
      const plot = s.plots[plotId] || {
        id: plotId,
        gx,
        gz,
        tilled: false,
        watered: false,
        cropId: null,
        growthDays: 0,
        readyToHarvest: false,
        fertilized: false,
        obstacle: null,
        obstacleDays: 0,
      };
      const slot = s.equippedItemId ? s.inventory.find((x) => x.itemId === s.equippedItemId) : null;
      const itemDef = slot ? ITEMS[slot.itemId] : null;
      const ownerId = s.visitingFarmOwnerId || s.profile.uid;
      const isSpouseFarm = Boolean(
        s.visitingFarmOwnerId && s.profile.spousePlayerUid && s.visitingFarmOwnerId === s.profile.spousePlayerUid
      );
      const canManageFarm = !s.visitingFarmOwnerId || isSpouseFarm;

      // 1. Overgrown 4-Level Farm Obstacles (Lv.1 Weed, Lv.2 Root/Stump/Sapling, Lv.3 Tree/Rock, Lv.4 Large Tree/Large Rock)
      if (plot.obstacle) {
        if (!canManageFarm) {
          showToast('Only the farm owner or spouse can clear field obstacles here.');
          return;
        }
        const toolLv = slot?.toolLevel || 1;
        const curLang = s.gameSettings.language;

        if (plot.obstacle === 'weed') {
          if (itemDef?.toolKind !== 'sickle') {
            showToast('🌿 Equip your Sickle in the Master Slot to cut overgrown weeds!');
            return;
          }
          if (s.stamina < 1) {
            showToast('⚡ Out of stamina! Eat food or rest in your Farmhouse bed.');
            return;
          }
          soundEngine.playHarvest();
          engineRef.current?.playWorkAnimation('sickle', 0.34);
          engineRef.current?.triggerPlotHitReaction(gx, gz, 'leaf');
          setStamina((v) => Math.max(0, v - 1));
          setPlots((prev) => ({
            ...prev,
            [plotId]: { ...plot, obstacle: null, obstacleDays: 0 },
          }));
          mpRef.current?.sendFarmAction(ownerId, plotId, gx, gz, 'clear_obstacle');
          rewardProgress(4, 2);
          return;
        }

        if (
          plot.obstacle === 'root' ||
          plot.obstacle === 'stump' ||
          plot.obstacle === 'sapling' ||
          plot.obstacle === 'tree' ||
          plot.obstacle === 'large_tree'
        ) {
          if (itemDef?.toolKind !== 'axe') {
            showToast(`🪓 Equip your Axe to chop this ${plot.obstacle.replace('_', ' ')}!`);
            return;
          }
          const isLv4 = plot.obstacle === 'large_tree';
          const isLv3 = plot.obstacle === 'tree';
          const isStumpPlot = plot.obstacle === 'stump';
          if (isLv4 && toolLv < 2) {
            showToast(t(curLang, 'tree.needLv2Axe'));
            return;
          }
          const baseStam = isLv4 ? 4 : isLv3 ? 4 : 2;
          const stamCost = isLv4
            ? toolLv === 2
              ? baseStam * 4
              : toolLv === 3
                ? 8
                : toolLv === 4
                  ? 5
                  : 4
            : isLv3
              ? toolLv >= 3
                ? 3
                : 4
              : 2;
          // 2x chop hit count across all tree levels & stumps
          const hitsNeeded = isStumpPlot
            ? toolLv >= 2
              ? 2
              : 4
            : isLv4
              ? toolLv === 2
                ? 12
                : toolLv === 3
                  ? 8
                  : toolLv === 4
                    ? 6
                    : 4
              : isLv3
                ? toolLv === 1
                  ? 8
                  : toolLv === 2
                    ? 4
                    : 2
                : toolLv >= 2
                  ? 2
                  : 4;
          if (s.stamina < stamCost) {
            showToast(`⚡ Need ${stamCost} Stamina! Eat food or sleep in your Farmhouse bed.`);
            return;
          }
          soundEngine.playWoodStone();
          engineRef.current?.playWorkAnimation('chop', 0.42);
          engineRef.current?.triggerPlotHitReaction(gx, gz, 'wood');
          setStamina((v) => Math.max(0, v - stamCost));
          const hit = stepResourceHits(`plot_${plotId}`, hitsNeeded);
          if (!hit.done) {
            return;
          }
          const woodYield = isLv4 ? 6 : isLv3 ? 3 : 2;
          if (!addInventoryItem('mat_wood', woodYield)) return;
          // Lv.3 & Lv.4 trees fall into a solid stump that must be chopped again!
          const becomesStump = isLv3 || isLv4;
          setPlots((prev) => ({
            ...prev,
            [plotId]: {
              ...plot,
              obstacle: becomesStump ? 'stump' : null,
              obstacleDays: becomesStump ? 1 : 0,
            },
          }));
          setStats((st) => ({ ...st, materialsGathered: st.materialsGathered + woodYield }));
          mpRef.current?.sendFarmAction(ownerId, plotId, gx, gz, 'clear_obstacle');
          rewardProgress(isLv4 ? 22 : isLv3 ? 12 : 6, isLv4 ? 6 : 3);
          advanceMission('gather', 1);
          return;
        }

        if (plot.obstacle === 'rock' || plot.obstacle === 'large_rock') {
          if (itemDef?.toolKind !== 'hammer') {
            showToast('🔨 Equip your Hammer to break field rocks!');
            return;
          }
          const isLv4 = plot.obstacle === 'large_rock';
          if (isLv4 && toolLv < 2) {
            showToast(t(curLang, 'tree.needLv2Hammer'));
            return;
          }
          const baseStam = 3;
          const stamCost = isLv4
            ? toolLv === 2
              ? baseStam * 4
              : toolLv === 3
                ? 6
                : toolLv === 4
                  ? 4
                  : 3
            : toolLv >= 3
              ? 2
              : 3;
          const hitsNeeded = isLv4
            ? toolLv === 2
              ? 6
              : toolLv === 3
                ? 4
                : toolLv === 4
                  ? 3
                  : 2
            : toolLv === 1
              ? 3
              : toolLv === 2
                ? 2
                : 1;
          if (s.stamina < stamCost) {
            showToast(`⚡ Need ${stamCost} Stamina! Eat food or sleep in your Farmhouse bed.`);
            return;
          }
          soundEngine.playWoodStone();
          engineRef.current?.playWorkAnimation('hammer', 0.42);
          engineRef.current?.triggerPlotHitReaction(gx, gz, 'stone');
          setStamina((v) => Math.max(0, v - stamCost));
          const hit = stepResourceHits(`plot_${plotId}`, hitsNeeded);
          if (!hit.done) {
            return;
          }
          const stoneYield = isLv4 ? 5 : 2;
          if (!addInventoryItem('mat_stone', stoneYield)) return;
          if (isLv4) addInventoryItem('mat_iron', 1);
          setPlots((prev) => ({
            ...prev,
            [plotId]: { ...plot, obstacle: null, obstacleDays: 0 },
          }));
          setStats((st) => ({ ...st, materialsGathered: st.materialsGathered + stoneYield }));
          mpRef.current?.sendFarmAction(ownerId, plotId, gx, gz, 'clear_obstacle');
          rewardProgress(isLv4 ? 20 : 8, isLv4 ? 6 : 3);
          advanceMission('gather', 1);
          return;
        }
      }

      // 2. Harvest Ripe Crops
      if (plot.readyToHarvest && plot.cropId) {
        if (!canManageFarm) {
          showToast('You are visiting a friend’s farm! Water their crops to lend a hand.');
          return;
        }
        const crop = CROPS[plot.cropId];
        if (crop) {
          if (!addInventoryItem(crop.harvestItemId, 1)) return;
          soundEngine.playHarvest();
          engineRef.current?.playWorkAnimation('gift', 0.36);
          engineRef.current?.triggerPlotHitReaction(gx, gz, 'leaf');
          setPlots((prev) => {
            const nextPlot: FarmPlotState = crop.regrowsAfterHarvest
              ? { ...plot, growthDays: Math.max(1, crop.daysToGrow - 2), readyToHarvest: false }
              : { ...plot, cropId: null, growthDays: 0, readyToHarvest: false };
            const updated = { ...prev, [plotId]: nextPlot };
            mpRef.current?.sendFarmAction(ownerId, plotId, gx, gz, 'harvest');
            return updated;
          });
          setStats((st) => {
            const nextHarvest = st.cropsHarvested + 1;
            if (nextHarvest === 1) unlockAchievement('ach_first_harvest');
            if (nextHarvest >= 15) unlockAchievement('ach_green_thumb');
            return { ...st, cropsHarvested: nextHarvest };
          });
          rewardProgress(14, 5);
          advanceMission('harvest', 1);
        }
        return;
      }

      if (!itemDef) {
        return;
      }

      if (s.stamina < 2) {
        showToast('⚡ Stamina depleted! Eat food from your Bag/Fridge or sleep in your Farmhouse bed.');
        return;
      }

      // 3. Till Soil
      if (itemDef.toolKind === 'hoe' && !plot.tilled && canManageFarm) {
        soundEngine.playTill();
        engineRef.current?.playWorkAnimation('dig', 0.38);
        engineRef.current?.triggerPlotHitReaction(gx, gz, 'dirt');
        setStamina((v) => Math.max(0, v - 2));
        setPlots((prev) => ({ ...prev, [plotId]: { ...plot, tilled: true } }));
        rewardProgress(5, 2);
        mpRef.current?.sendFarmAction(ownerId, plotId, gx, gz, 'till');
        return;
      }

      // 4. Water Tilled Soil (also tracks active Multiplayer Farm Job progress!)
      if (itemDef.toolKind === 'watering_can' && plot.tilled && !plot.watered) {
        soundEngine.playWater();
        engineRef.current?.playWorkAnimation('water', 0.4);
        engineRef.current?.triggerPlotHitReaction(gx, gz, 'water');
        setStamina((v) => Math.max(0, v - 1));
        setPlots((prev) => ({ ...prev, [plotId]: { ...plot, watered: true } }));
        setStats((st) => ({ ...st, cropsWatered: st.cropsWatered + 1 }));
        rewardProgress(4, 1);
        advanceMission('water', 1);
        mpRef.current?.sendFarmAction(ownerId, plotId, gx, gz, 'water');
        if (s.visitingFarmOwnerId) {
          const activeJob = s.farmJobs.find(
            (j) =>
              j.workerUid === s.profile.uid &&
              j.employerUid === s.visitingFarmOwnerId &&
              j.status === 'in_progress' &&
              j.tasks.includes('water_crops')
          );
          if (activeJob) {
            mpRef.current?.reportJobProgress(activeJob.id, `water_${plotId}`);
          }
        }
        return;
      }

      // 5. Plant Seeds
      if (itemDef.category === 'Seeds' && itemDef.cropId && canManageFarm) {
        if (!plot.tilled) {
          showToast('Till the soil first with your Hoe!');
          return;
        }
        if (plot.cropId) {
          return;
        }
        const cropDef = CROPS[itemDef.cropId];
        if (cropDef && !cropDef.seasons.includes(s.season)) {
          showToast(`${cropDef.name} seeds only grow in: ${cropDef.seasons.join(', ')}`);
          return;
        }
        if (consumeInventoryItem(itemDef.id, 1)) {
          soundEngine.playPlant();
          engineRef.current?.playWorkAnimation('gift', 0.34);
          engineRef.current?.triggerPlotHitReaction(gx, gz, 'dirt');
          setPlots((prev) => ({
            ...prev,
            [plotId]: { ...plot, cropId: itemDef.cropId!, growthDays: 0, readyToHarvest: false },
          }));
          setStats((st) => ({ ...st, cropsPlanted: st.cropsPlanted + 1 }));
          rewardProgress(6, 3);
          advanceMission('plant', 1);
          mpRef.current?.sendFarmAction(ownerId, plotId, gx, gz, 'plant', itemDef.cropId);
        }
        return;
      }

      // 6. Fertilizers
      if (itemDef.id === 'item_fertilizer' && plot.cropId && !plot.readyToHarvest && canManageFarm) {
        if (consumeInventoryItem('item_fertilizer', 1)) {
          const cropDef = CROPS[plot.cropId];
          const nextDays = plot.growthDays + 1;
          const ready = cropDef ? nextDays >= cropDef.daysToGrow : false;
          setPlots((prev) => ({
            ...prev,
            [plotId]: { ...plot, growthDays: nextDays, readyToHarvest: ready, fertilized: true },
          }));
          soundEngine.playPlant();
          engineRef.current?.playWorkAnimation('gift', 0.34);
          engineRef.current?.triggerPlotHitReaction(gx, gz, 'leaf');
          rewardProgress(6, 3);
        }
        return;
      }

      if (itemDef.id === 'item_miracle_fertilizer' && plot.cropId && !plot.readyToHarvest && canManageFarm) {
        if (consumeInventoryItem('item_miracle_fertilizer', 1)) {
          const cropDef = CROPS[plot.cropId];
          setPlots((prev) => ({
            ...prev,
            [plotId]: {
              ...plot,
              growthDays: cropDef ? cropDef.daysToGrow : plot.growthDays + 10,
              readyToHarvest: true,
              fertilized: true,
            },
          }));
          soundEngine.playHarvest();
          engineRef.current?.playWorkAnimation('gift', 0.36);
          engineRef.current?.triggerPlotHitReaction(gx, gz, 'leaf');
          rewardProgress(12, 6);
        }
      }
    },
    [addInventoryItem, advanceMission, consumeInventoryItem, rewardProgress, showToast, stepResourceHits, unlockAchievement]
  );

  // === OUTDOOR 4-LEVEL TREE CHOPPING (2x hits, Lv.3 & Lv.4 fall into solid stump first, zero noisy progress toasts!) ===
  const handleChopTree = useCallback(
    (treeId: string, scope: 'global' | 'farm' = 'farm', treeLevel: 1 | 2 | 3 | 4 = 3, isStump = false) => {
      const s = stateRef.current;
      const curLang = s.gameSettings.language;
      if (scope === 'global') {
        showToast(t(curLang, 'tree.protectedGlobal'));
        return;
      }
      const isSpouseFarm = Boolean(
        s.visitingFarmOwnerId && s.profile.spousePlayerUid && s.visitingFarmOwnerId === s.profile.spousePlayerUid
      );
      if (s.visitingFarmOwnerId && !isSpouseFarm) {
        return;
      }
      const slot = s.equippedItemId ? s.inventory.find((x) => x.itemId === s.equippedItemId) : null;
      const def = slot ? ITEMS[slot.itemId] : null;
      const toolLv = slot?.toolLevel || 1;

      if (def?.toolKind !== 'axe') {
        showToast('🪓 Equip your Axe in the Master Slot to chop Farm trees!');
        return;
      }
      if (!isStump && treeLevel >= 4 && toolLv < 2) {
        showToast(t(curLang, 'tree.needLv2Axe'));
        return;
      }

      const baseStam = 4;
      const stamCost = isStump
        ? 2
        : treeLevel >= 4
          ? toolLv === 2
            ? baseStam * 4
            : toolLv === 3
              ? 8
              : toolLv === 4
                ? 5
                : 4
          : treeLevel === 3
            ? toolLv >= 3
              ? 3
              : 4
            : 2;

      // 2x chop count across all tree levels & stumps
      const hitsNeeded = isStump
        ? toolLv >= 2
          ? 2
          : 4
        : treeLevel >= 4
          ? toolLv === 2
            ? 12
            : toolLv === 3
              ? 8
              : toolLv === 4
                ? 6
                : 4
          : treeLevel === 3
            ? toolLv === 1
              ? 8
              : toolLv === 2
                ? 4
                : 2
            : toolLv >= 2
              ? 2
              : 4;

      if (s.stamina < stamCost) {
        showToast(`⚡ Need ${stamCost} Stamina! Eat food or sleep in your Farmhouse bed.`);
        return;
      }

      soundEngine.playWoodStone();
      engineRef.current?.playWorkAnimation('chop', 0.44);
      engineRef.current?.triggerTreeHitReaction(treeId);
      setStamina((v) => Math.max(0, v - stamCost));

      const hitKey = isStump ? `stump_${treeId}` : `tree_${treeId}`;
      const hit = stepResourceHits(hitKey, hitsNeeded);
      if (!hit.done) {
        return;
      }

      // Lv.3 and Lv.4 trees fall physically into a solid stump that must be chopped again!
      if (!isStump && treeLevel >= 3) {
        const woodYield = treeLevel >= 4 ? 5 : 3;
        if (!addInventoryItem('mat_wood', woodYield)) return;
        engineRef.current?.markTreeFelledToStump(treeId);
        setFarmTrees((prev) => prev.map((tr) => (tr.id === treeId ? { ...tr, isStump: true, chopped: false } : tr)));
        setStats((st) => ({ ...st, materialsGathered: st.materialsGathered + woodYield }));
        rewardProgress(treeLevel >= 4 ? 18 : 10, treeLevel >= 4 ? 5 : 3);
        advanceMission('gather', 1);
        return;
      }

      const woodYield = isStump ? 2 : 2;
      if (!addInventoryItem('mat_wood', woodYield)) return;

      engineRef.current?.markTreeChopped(treeId, true);
      setFarmTrees((prev) => prev.map((tr) => (tr.id === treeId ? { ...tr, chopped: true, isStump: false } : tr)));
      setStats((st) => ({ ...st, materialsGathered: st.materialsGathered + woodYield }));
      rewardProgress(isStump ? 8 : 6, 3);
      advanceMission('gather', 1);
    },
    [addInventoryItem, advanceMission, rewardProgress, showToast, stepResourceHits]
  );

  // === MULTI-LEVEL CAVE FLOOR HOE DIGGING (Random Descent Hole + Scalable Drop & Rarity per Floor) ===
  const handleDigCaveTile = useCallback(
    (gx: number, gz: number) => {
      const s = stateRef.current;
      const curLang = s.gameSettings.language;
      const slot = s.equippedItemId ? s.inventory.find((x) => x.itemId === s.equippedItemId) : null;
      const def = slot ? ITEMS[slot.itemId] : null;
      const hoeLv = slot?.toolLevel || 1;

      if (def?.toolKind !== 'hoe') {
        showToast(t(curLang, 'cave.digHint'));
        return;
      }
      const stamCost = hoeLv >= 4 ? 2 : 3;
      if (s.stamina < stamCost) {
        showToast('⚡ Out of stamina! Eat food or rest in your Farmhouse bed.');
        return;
      }

      soundEngine.playTill();
      engineRef.current?.playWorkAnimation('dig', 0.38);
      engineRef.current?.markCaveTileDug(gx, gz);
      setStamina((v) => Math.max(0, v - stamCost));

      // Check for randomly hidden ladder/hole to next cave floor!
      if (
        !caveHoleRevealedRef.current &&
        s.caveLevel < CAVE_MINING_CONFIG.maxLevel &&
        gx === caveHoleCoordRef.current.gx &&
        gz === caveHoleCoordRef.current.gz
      ) {
        caveHoleRevealedRef.current = true;
        engineRef.current?.revealCaveDescentHole(gx, gz);
        soundEngine.playHarvest();
        pushWorldSpeechBubble(
          s.profile.uid,
          s.profile.avatarName,
          curLang === 'id'
            ? `🪜 Menemukan lubang tangga ke Lantai ${s.caveLevel + 1}!`
            : `🪜 Discovered a ladder down to Cave Floor ${s.caveLevel + 1}!`,
          'player',
          5000
        );
      }

      // Configurable multi-floor drop & rarity formula (+levelDropStepPct & +levelRarityStepPct per floor)
      // Example: Lv.1 = 5-30% drop & 5% rarity -> Lv.2 = 8-38% drop & 8% rarity
      const lv = Math.max(1, s.caveLevel);
      const dropMin = CAVE_MINING_CONFIG.baseDropMinPct + (lv - 1) * CAVE_MINING_CONFIG.levelDropStepPct;
      const dropMax = Math.min(
        95,
        CAVE_MINING_CONFIG.baseDropMaxPct + (lv - 1) * (CAVE_MINING_CONFIG.levelDropStepPct + 5)
      );
      const rarityPct = Math.min(
        95,
        CAVE_MINING_CONFIG.baseRarityPct + (lv - 1) * CAVE_MINING_CONFIG.levelRarityStepPct
      );
      const hoeBonusPct = (hoeLv - 1) * 2.5;
      const effectiveDropProb = Math.min(0.95, (dropMin + Math.random() * Math.max(0, dropMax - dropMin) + hoeBonusPct) / 100);
      if (Math.random() > effectiveDropProb) {
        return;
      }

      const isRareRoll = Math.random() * 100 < rarityPct + (hoeLv - 1) * 1.2;
      let dropId = 'mat_stone';
      const r = Math.random();
      if (isRareRoll) {
        if (r < 0.14 + Math.min(0.18, (lv - 1) * 0.015)) dropId = 'mat_mythril_star';
        else if (r < 0.34) dropId = 'mat_ancient_relic';
        else if (r < 0.58) dropId = 'mat_emerald';
        else if (r < 0.80) dropId = 'mat_crystal';
        else dropId = 'mat_gold_ore';
      } else {
        if (r < 0.18) dropId = 'mat_silver';
        else if (r < 0.44) dropId = 'mat_iron';
        else if (r < 0.72) dropId = 'mat_copper';
        else dropId = 'mat_stone';
      }

      if (!addInventoryItem(dropId, 1)) return;
      soundEngine.playWoodStone();
      setStats((st) => ({ ...st, materialsGathered: st.materialsGathered + 1 }));
      rewardProgress(dropId === 'mat_mythril_star' ? 32 : 10, dropId === 'mat_mythril_star' ? 10 : 3);
      advanceMission('gather', 1);
      const itemInfo = ITEMS[dropId];
      pushWorldSpeechBubble(
        s.profile.uid,
        s.profile.avatarName,
        `⛏️ +1 ${itemInfo?.iconEmoji || '🪨'} ${itemInfo?.name || dropId}`,
        'player',
        3200
      );
    },
    [addInventoryItem, advanceMission, pushWorldSpeechBubble, rewardProgress, showToast]
  );

  // === DAY ADVANCE (Triggered on Sleep OR Synchronized Real-Time Clock Rollover) ===
  const applyNewDayProgression = useCallback(
    (nextYear: number, nextSeason: Season, nextDay: number, resetMorningHour: boolean) => {
      const s = stateRef.current;
      const nextWeather: Weather = rollNextWeather(nextSeason, s.liveRuntimeConfig.weatherControl);
      const isWetWeather = nextWeather === 'Rainy' || nextWeather === 'Stormy';

      setPlots((prev) => {
        const next: Record<string, FarmPlotState> = {};
        for (const [k, plot] of Object.entries(prev)) {
          if (plot.cropId) {
            const crop = CROPS[plot.cropId];
            const seasonOk = crop?.seasons.includes(nextSeason);
            if (!seasonOk) {
              next[k] = { ...plot, cropId: null, growthDays: 0, readyToHarvest: false, watered: false };
            } else {
              const grew = plot.watered || isWetWeather ? plot.growthDays + 1 : plot.growthDays;
              const ready = crop ? grew >= crop.daysToGrow : false;
              next[k] = {
                ...plot,
                growthDays: grew,
                readyToHarvest: ready,
                watered: isWetWeather,
              };
            }
          } else if (plot.obstacle) {
            // Natural weed -> sapling -> tree succession when left unattended!
            const nextDays = (plot.obstacleDays || 0) + 1;
            let nextObs: FarmObstacleType = plot.obstacle;
            if (plot.obstacle === 'weed' && nextDays >= 6) {
              nextObs = 'tree';
            } else if (plot.obstacle === 'weed' && nextDays >= 3) {
              nextObs = 'sapling';
            } else if (plot.obstacle === 'sapling' && nextDays >= 6) {
              nextObs = 'tree';
            }
            next[k] = { ...plot, obstacle: nextObs, obstacleDays: nextDays, watered: isWetWeather };
          } else {
            const inPorchPath = plot.gx >= 9 && plot.gx <= 13 && plot.gz <= 2;
            const sproutWeed = !plot.tilled && !inPorchPath && Math.random() < 0.04;
            next[k] = {
              ...plot,
              obstacle: sproutWeed ? 'weed' : null,
              obstacleDays: 0,
              watered: isWetWeather,
            };
          }
        }
        return next;
      });

      engineRef.current?.regrowOutdoorTrees();

      setAppleTree({
        applesReady: nextSeason === 'Summer' || nextSeason === 'Autumn' ? 3 : 0,
        lastAppleDay: nextDay,
        honeyReady: nextSeason === 'Spring' && hasSpringFlowerPlanted(s.plots),
        lastHoneyDay: nextDay,
      });

      const isId = s.gameSettings.language === 'id';
      const newlySickNames: string[] = [];
      setAnimals((prev) =>
        prev.map((a) => {
          const wasFed = Boolean(a.fedToday);
          const nextDaysUnfed = wasFed ? 0 : (a.daysUnfed ?? 0) + 1;
          const becomesSick = a.isSick || nextDaysUnfed >= 3;
          if (!a.isSick && nextDaysUnfed >= 3) {
            newlySickNames.push(a.name);
          }
          const curHealth = a.health ?? 100;
          const curHappiness = a.happiness ?? 75;
          const nextHealth = becomesSick
            ? Math.max(15, curHealth - (nextDaysUnfed >= 3 ? 35 : 12))
            : wasFed
              ? Math.min(100, curHealth + 12)
              : Math.max(45, curHealth - 10);
          const nextHappiness = becomesSick
            ? Math.max(5, curHappiness - 45)
            : wasFed
              ? Math.min(100, curHappiness + 8)
              : Math.max(20, curHappiness - 18);
          const nextAffection = becomesSick
            ? Math.max(0, a.affection - 60)
            : wasFed
              ? a.affection
              : Math.max(0, a.affection - 12);
          const nextHunger = wasFed ? 65 : Math.max(5, (a.hunger ?? 60) - 35);
          const nextEmotion = becomesSick ? 'sick' : nextDaysUnfed >= 1 ? 'hungry' : 'happy';
          return {
            ...a,
            fedToday: false,
            brushedToday: false,
            playedToday: false,
            daysUnfed: nextDaysUnfed,
            isSick: becomesSick,
            health: nextHealth,
            happiness: nextHappiness,
            hunger: nextHunger,
            energy: becomesSick ? 30 : 100,
            affection: nextAffection,
            emotion: nextEmotion,
            productReady: !becomesSick && (a.type === 'cow' || a.type === 'chicken' || a.type === 'sheep'),
          };
        })
      );
      setNpcRels((prev) => {
        const copy: Record<string, NPCRelationshipState> = {};
        for (const [id, r] of Object.entries(prev)) {
          copy[id] = { ...r, memory: { ...r.memory, talkedToday: false, giftedToday: false } };
        }
        return copy;
      });

      setDailyMissions(createDailyMissions());
      const nextDayKey = `${nextYear}-${nextSeason}-${nextDay}`;
      const freshTracker = createEmptyDailyFunTracker(nextDayKey);
      stateRef.current.dailyFunTracker = freshTracker;
      setDailyFunTracker(freshTracker);
      setDay(nextDay);
      setSeason(nextSeason);
      setYear(nextYear);
      if (resetMorningHour) {
        setHour(6);
        setMinute(0);
      }
      setWeather(nextWeather);
      setStamina(s.maxStamina);
      let hatchedReadyCount = 0;
      setProfile((p) => {
        const nextIncubators = normalizeIncubatorSlots(p.coopLevel || 1, p.coopIncubators).map((slot) => {
          if (slot.eggPlacedDay === null) return slot;
          if (slot.readyToHatch) {
            hatchedReadyCount += 1;
            return slot;
          }
          const nextRemaining = Math.max(0, slot.daysRemaining - 1);
          const nowReady = nextRemaining <= 0;
          if (nowReady) hatchedReadyCount += 1;
          return { ...slot, daysRemaining: nextRemaining, readyToHatch: nowReady };
        });
        return {
          ...p,
          fun: applyFunProgress(p.fun, 6).fun,
          coopIncubators: nextIncubators,
        };
      });
      soundEngine.playHarvest();

      const fest = FESTIVALS.find((f) => f.season === nextSeason && f.day === nextDay);
      if (newlySickNames.length > 0) {
        showToast(
          isId
            ? `🤒 Peringatan! ${newlySickNames.join(', ')} jatuh sakit karena 3 hari tidak diberi makan! Beli Obat Hewan di Peternakan Felix atau Klinik.`
            : `🤒 Warning! ${newlySickNames.join(', ')} fell sick after 3 days unfed! Buy Animal Medicine at Felix’s Ranch or the Clinic.`
        );
      } else if (fest) {
        showToast(
          isId
            ? `🎪 Festival Hari Ini: ${fest.name}! Semua warga berkumpul di Alun-Alun Kota (10:00–19:00)!`
            : `🎪 Today’s Festival: ${fest.name}! All villagers gather in Town Square (10:00–19:00)!`,
          'specialEvents'
        );
      } else if (hatchedReadyCount > 0) {
        showToast(
          isId
            ? `🐣 ${hatchedReadyCount} telur di Inkubator Kandang Ayam siap menetas & diberi nama!`
            : `🐣 ${hatchedReadyCount} egg(s) in your Chicken Coop Incubator are ready to hatch & name!`
        );
      } else {
        const seasonMaxDays = getDaysInSeason(nextSeason);
        showToast(
          isId
            ? `☀️ Hari Baru: ${nextSeason} Hari ${nextDay}/${seasonMaxDays} (Cuaca: ${nextWeather})`
            : `☀️ New Day: ${nextSeason} Day ${nextDay}/${seasonMaxDays} (Weather: ${nextWeather})`
        );
      }
    },
    [showToast]
  );

  // Real-time rest in Farmhouse bed: NEVER advances global valley hour or day (shared global clock).
  // Shows a cozy sleep overlay while gradually restoring stamina tick-by-tick until player wakes up.
  const wakeUpFromBed = useCallback(() => {
    setIsSleeping(false);
    engineRef.current?.setPlayerSleeping(false);
    soundEngine.playUiClick();
    const isId = stateRef.current.gameSettings.language === 'id';
    showToast(
      isId
        ? '☀️ Kamu terbangun segar kembali! Waktu global desa tetap berjalan normal.'
        : '☀️ You woke up feeling refreshed! Global valley time continues naturally.'
    );
  }, [showToast]);

  const startBedSleep = useCallback(() => {
    sleepStartedAtRef.current = Date.now();
    setIsSleeping(true);
    engineRef.current?.setPlayerSleeping(true);
    soundEngine.playUiClick();
  }, []);

  // Gradual real-time stamina recovery & wake-on-any-key/tap while resting in bed
  useEffect(() => {
    if (!isSleeping) return;
    const recoverTimer = window.setInterval(() => {
      setStamina((prev) => {
        const cap = stateRef.current.maxStamina;
        if (prev >= cap) return cap;
        return Math.min(cap, prev + 3);
      });
    }, 450);

    const handleWakeInput = (e: Event) => {
      // Ignore the initial interaction key/tap that entered sleep for 350ms
      if (Date.now() - sleepStartedAtRef.current < 350) return;
      e.preventDefault();
      wakeUpFromBed();
    };
    window.addEventListener('keydown', handleWakeInput, { capture: true });
    window.addEventListener('pointerdown', handleWakeInput, { capture: true });
    return () => {
      window.clearInterval(recoverTimer);
      window.removeEventListener('keydown', handleWakeInput, { capture: true });
      window.removeEventListener('pointerdown', handleWakeInput, { capture: true });
    };
  }, [isSleeping, wakeUpFromBed]);

  // === IN-WORLD LIVE FISHING (No Info Popup, Secret Dev Luck/Wait, 3-Strike Green Zone, 1 Miss = Escape!) ===
  const cancelInWorldFishing = useCallback(() => {
    const sess = fishingSessionRef.current;
    if (sess.castTimer) {
      window.clearTimeout(sess.castTimer);
      sess.castTimer = null;
    }
    if (sess.biteTimer) {
      window.clearTimeout(sess.biteTimer);
      sess.biteTimer = null;
    }
    if (sess.rafId) {
      window.cancelAnimationFrame(sess.rafId);
      sess.rafId = null;
    }
    sess.active = false;
    sess.phase = 'idle';
    engineRef.current?.setFishingVisualState('idle');
    setFishingBar(null);
  }, []);

  const startInWorldFishing = useCallback(
    (spotType: 'river' | 'ocean') => {
      const s = stateRef.current;
      const curLang = s.gameSettings.language;
      const slot = s.equippedItemId ? s.inventory.find((x) => x.itemId === s.equippedItemId) : null;
      const def = slot ? ITEMS[slot.itemId] : null;
      if (def?.toolKind !== 'fishing_rod') {
        showToast('🎣 Equip your Fishing Rod in the Master Slot to fish!');
        return;
      }
      if (s.stamina < 2) {
        showToast('⚡ Out of stamina! Eat food or rest in your Farmhouse bed.');
        return;
      }
      if (fishingSessionRef.current.active) {
        cancelInWorldFishing();
        return;
      }

      setStamina((v) => Math.max(0, v - 2));
      const hasBait = s.inventory.some((x) => x.itemId === 'item_fish_bait' && x.quantity > 0);
      const minLuck = Math.max(0, Math.min(100, FISHING_CONFIG.luckMin));
      const maxLuck = Math.max(minLuck, Math.min(100, FISHING_CONFIG.luckMax));
      const rawLuck = minLuck + Math.random() * (maxLuck - minLuck);
      const luckPct = Math.min(100, Math.round(rawLuck + (hasBait ? 14 : 0)));

      const minWait = Math.max(1, FISHING_CONFIG.waitMinSec);
      const maxWait = Math.max(minWait, FISHING_CONFIG.waitMaxSec);
      // Natural weighted wait within [minWait, maxWait] (secret — never shown to players)
      const u = Math.random();
      const shaped = hasBait ? Math.pow(u, 2.4) : Math.pow(u, 1.9);
      const waitSec = Math.max(minWait, Math.min(maxWait, minWait + shaped * (maxWait - minWait)));

      const zoneWidthPct = Math.max(10, Math.min(45, FISHING_CONFIG.greenZoneWidthPct + (hasBait ? 3 : 0)));
      const strikesRequired = Math.max(1, Math.min(5, FISHING_CONFIG.strikesRequired));

      const sess = fishingSessionRef.current;
      sess.active = true;
      sess.phase = 'casting';
      sess.spotType = spotType;
      sess.luckPct = luckPct;
      sess.hasBait = hasBait;
      sess.cursorPct = 0;
      sess.dir = 1;
      sess.zoneWidthPct = zoneWidthPct;
      sess.zoneStartPct = 18 + Math.random() * Math.max(8, 64 - zoneWidthPct);
      sess.strikesHit = 0;
      sess.strikesRequired = strikesRequired;

      soundEngine.playWater();
      engineRef.current?.playWorkAnimation('fish_cast', 0.45);
      engineRef.current?.setFishingVisualState('casting', spotType);
      setFishingBar({
        active: true,
        phase: 'casting',
        cursorPct: 0,
        zoneStartPct: sess.zoneStartPct,
        zoneWidthPct,
        strikesHit: 0,
        strikesRequired,
      });

      sess.castTimer = window.setTimeout(() => {
        if (!sess.active) return;
        sess.phase = 'waiting';
        engineRef.current?.setFishingVisualState('waiting', spotType);
        setFishingBar((prev) => (prev ? { ...prev, phase: 'waiting' } : null));

        sess.biteTimer = window.setTimeout(() => {
          if (!sess.active) return;
          if (sess.luckPct <= 0) {
            soundEngine.playFishSplash();
            cancelInWorldFishing();
            pushWorldSpeechBubble(
              s.profile.uid,
              s.profile.avatarName,
              curLang === 'id' ? '💨 Ikan hanya menyenggol umpan lalu kabur!' : '💨 A fish nibbled and slipped away!',
              'player',
              3200
            );
            return;
          }

          sess.phase = 'reeling';
          sess.cursorPct = 8;
          sess.dir = 1;
          sess.lastTs = performance.now();
          soundEngine.playFishSplash();
          engineRef.current?.setFishingVisualState('reeling', spotType);

          const stepBar = (now: number) => {
            if (!sess.active || (sess.phase !== 'bite' && sess.phase !== 'reeling')) return;
            const dt = Math.min(0.05, Math.max(0.001, (now - sess.lastTs) / 1000));
            sess.lastTs = now;
            // Faster tension sweep on higher strikes & ocean fish
            const speed = (spotType === 'ocean' ? 92 : 78) + sess.strikesHit * 18;
            sess.cursorPct += sess.dir * speed * dt;
            if (sess.cursorPct >= 100) {
              sess.cursorPct = 100;
              sess.dir = -1;
            } else if (sess.cursorPct <= 0) {
              sess.cursorPct = 0;
              sess.dir = 1;
            }
            setFishingBar({
              active: true,
              phase: 'reeling',
              cursorPct: sess.cursorPct,
              zoneStartPct: sess.zoneStartPct,
              zoneWidthPct: sess.zoneWidthPct,
              strikesHit: sess.strikesHit,
              strikesRequired: sess.strikesRequired,
            });
            sess.rafId = window.requestAnimationFrame(stepBar);
          };
          sess.rafId = window.requestAnimationFrame(stepBar);
        }, Math.round(waitSec * 1000));
      }, 450);
    },
    [cancelInWorldFishing, pushWorldSpeechBubble, showToast]
  );

  const handleFishingSpacePress = useCallback(() => {
    const sess = fishingSessionRef.current;
    if (!sess.active) return;
    const s = stateRef.current;
    const curLang = s.gameSettings.language;

    if (sess.phase === 'casting' || sess.phase === 'waiting') {
      cancelInWorldFishing();
      pushWorldSpeechBubble(
        s.profile.uid,
        s.profile.avatarName,
        curLang === 'id' ? '🎣 Menarik kail lebih awal...' : '🎣 Reeled the line back in early...',
        'player',
        2600
      );
      return;
    }

    if (sess.phase === 'bite' || sess.phase === 'reeling') {
      const inGreen = sess.cursorPct >= sess.zoneStartPct && sess.cursorPct <= sess.zoneStartPct + sess.zoneWidthPct;
      if (!inGreen) {
        // 1 miss = fish escapes immediately!
        soundEngine.playFishSplash();
        cancelInWorldFishing();
        pushWorldSpeechBubble(
          s.profile.uid,
          s.profile.avatarName,
          curLang === 'id' ? '💨 Meleset! Ikan terlepas!' : '💨 Missed! The fish escaped!',
          'player',
          3400
        );
        return;
      }

      sess.strikesHit += 1;
      engineRef.current?.playWorkAnimation('fish_reel', 0.25);

      if (sess.strikesHit >= sess.strikesRequired) {
        // Landed the fish!
        const isOcean = sess.spotType === 'ocean';
        const luckFactor = sess.luckPct / 100;
        let fishId = 'fish_river_trout';
        if (isOcean) {
          const roll = Math.random() * 0.65 + luckFactor * 0.35;
          if (roll > 0.78) fishId = 'fish_midnight_squid';
          else if (roll > 0.48) fishId = 'fish_ocean_tuna';
          else fishId = 'fish_coral_snapper';
        } else {
          const isRare = luckFactor > 0.72 || (sess.hasBait && Math.random() < 0.35);
          fishId = isRare ? 'fish_golden_koi' : 'fish_river_trout';
        }
        if (sess.hasBait) consumeInventoryItem('item_fish_bait', 1);
        cancelInWorldFishing();
        if (!addInventoryItem(fishId, 1)) return;
        soundEngine.playHarvest();
        rewardProgress(12, 6);
        advanceMission('catch_fish', 1);
        setStats((st) => {
          const next = st.fishCaught + 1;
          if (next >= 5) unlockAchievement('ach_master_angler');
          return { ...st, fishCaught: next };
        });
        const fishItem = ITEMS[fishId];
        pushWorldSpeechBubble(
          s.profile.uid,
          s.profile.avatarName,
          curLang === 'id'
            ? `🐟 Dapat ${fishItem?.name || fishId}!`
            : `🐟 Caught ${fishItem?.name || fishId}!`,
          'player',
          4200
        );
      } else {
        // Shift green zone for next strike
        soundEngine.playUiClick();
        sess.zoneStartPct = 14 + Math.random() * Math.max(10, 72 - sess.zoneWidthPct);
        setFishingBar({
          active: true,
          phase: 'reeling',
          cursorPct: sess.cursorPct,
          zoneStartPct: sess.zoneStartPct,
          zoneWidthPct: sess.zoneWidthPct,
          strikesHit: sess.strikesHit,
          strikesRequired: sess.strikesRequired,
        });
      }
    }
  }, [addInventoryItem, advanceMission, cancelInWorldFishing, consumeInventoryItem, pushWorldSpeechBubble, rewardProgress, unlockAchievement]);

  const startInWorldFishingRef = useRef(startInWorldFishing);
  startInWorldFishingRef.current = startInWorldFishing;
  const handleFishingSpacePressRef = useRef(handleFishingSpacePress);
  handleFishingSpacePressRef.current = handleFishingSpacePress;
  const cancelInWorldFishingRef = useRef(cancelInWorldFishing);
  cancelInWorldFishingRef.current = cancelInWorldFishing;

  // === ENTER OR EXIT BUILDING / CAVE ===
  const executeZoneTransition = useCallback((targetZone: WorldZoneId, portalId?: string) => {
    const s = stateRef.current;
    cancelInWorldFishingRef.current();
    setNpcChoicePopover(null);
    soundEngine.playDoor();
    if (targetZone.startsWith('int_')) {
      engineRef.current?.enterZone(targetZone);
      setZone(targetZone);
      if (targetZone === 'int_cave') {
        setCaveLevel(1);
        caveHoleCoordRef.current = rollCaveHoleCoord();
        caveHoleRevealedRef.current = false;
        engineRef.current?.resetCaveFloorForLevel(1);
      }
      mpRef.current?.changeZone(targetZone, s.visitingFarmOwnerId || s.profile.uid, 0, 2);
    } else {
      const portal =
        BUILDING_PORTALS.find((p) => p.interiorZone === s.zone) ||
        BUILDING_PORTALS.find((p) => p.id === portalId);
      const outZone = portal?.outdoorZone || targetZone;
      engineRef.current?.enterZone(outZone, portal?.exitSpawnX, portal?.exitSpawnZ);
      setZone(outZone);
      mpRef.current?.changeZone(outZone, s.visitingFarmOwnerId || s.profile.uid, portal?.exitSpawnX || 0, portal?.exitSpawnZ || 0);
    }
  }, [rollCaveHoleCoord]);

  // === WORLD INTERACTIVES (F - Doors, TV/Fridge/Toolbox/Wardrobe/Bed, Apple/Honey, Shipping Bin, Cave/Mine, Forest, Fishing) ===
  const handleInteractWorld = useCallback(
    async (node: InteractiveWorldNode) => {
      const s = stateRef.current;
      const slot = s.equippedItemId ? s.inventory.find((x) => x.itemId === s.equippedItemId) : null;
      const def = slot ? ITEMS[slot.itemId] : null;
      const isSpouseFarm = Boolean(
        s.visitingFarmOwnerId && s.profile.spousePlayerUid && s.visitingFarmOwnerId === s.profile.spousePlayerUid
      );
      const canManageFarm = !s.visitingFarmOwnerId || isSpouseFarm;

      if (node.kind === 'cave_ladder_down') {
        const nextLv = Math.min(CAVE_MINING_CONFIG.maxLevel, s.caveLevel + 1);
        setCaveLevel(nextLv);
        caveHoleCoordRef.current = rollCaveHoleCoord();
        caveHoleRevealedRef.current = false;
        engineRef.current?.resetCaveFloorForLevel(nextLv);
        soundEngine.playDoor();
        pushWorldSpeechBubble(
          s.profile.uid,
          s.profile.avatarName,
          s.gameSettings.language === 'id' ? `⛰️ Turun ke Goa Lantai ${nextLv}` : `⛰️ Descended to Cave Floor ${nextLv}`,
          'player',
          3800
        );
        return;
      }

      if (node.kind === 'door' && node.targetZone) {
        if (
          node.targetZone === 'int_farmhouse' ||
          node.targetZone === 'int_barn' ||
          node.targetZone === 'int_coop' ||
          node.targetZone === 'int_stable'
        ) {
          setDoorPrompt({
            buildingKind:
              node.targetZone === 'int_farmhouse'
                ? 'farmhouse'
                : node.targetZone === 'int_coop'
                  ? 'coop'
                  : node.targetZone === 'int_stable'
                    ? 'stable'
                    : 'barn',
            isInside: false,
            targetZone: node.targetZone,
          });
          return;
        }
        executeZoneTransition(node.targetZone, node.portalId);
        return;
      }

      if (node.kind === 'exit_door') {
        if (
          s.zone === 'int_farmhouse' ||
          s.zone === 'int_barn' ||
          s.zone === 'int_coop' ||
          s.zone === 'int_stable'
        ) {
          setDoorPrompt({
            buildingKind:
              s.zone === 'int_farmhouse'
                ? 'farmhouse'
                : s.zone === 'int_coop'
                  ? 'coop'
                  : s.zone === 'int_stable'
                    ? 'stable'
                    : 'barn',
            isInside: true,
            targetZone: 'farm_home',
          });
          return;
        }
        const portal = BUILDING_PORTALS.find((p) => p.interiorZone === s.zone);
        executeZoneTransition(portal?.outdoorZone || 'village_square', portal?.id);
        return;
      }

      if (node.kind === 'dog_bowl') {
        if (def?.id !== 'animal_feed') {
          showToast('🦴 Equip Animal Fodder in the Master Slot to fill the outdoor Dog Food Bowl!');
          return;
        }
        if (!canManageFarm) {
          const activeJob = s.farmJobs.find(
            (j) =>
              j.workerUid === s.profile.uid &&
              j.employerUid === s.visitingFarmOwnerId &&
              j.status === 'in_progress' &&
              j.tasks.includes('feed_dog')
          );
          if (!activeJob) {
            showToast('🦴 This outdoor dog bowl belongs to your friend’s dog.');
            return;
          }
          if (consumeInventoryItem('animal_feed', 1)) {
            mpRef.current?.reportJobProgress(activeJob.id, 'feed_dog_bowl');
            soundEngine.playHeart();
            showToast('🦴 Filled your employer’s outdoor Dog Food Bowl!');
          }
          return;
        }
        const dog = s.animals.find((a) => a.type === 'dog');
        if (!dog) {
          showToast('🐕 Adopt a dog at Felix’s Ranch! Its small doghouse is ready right beside this bowl.');
          return;
        }
        const isId = s.gameSettings.language === 'id';
        if (dog.fedToday) {
          showToast(
            isId
              ? `🦴 Mangkuk makan ${dog.name} sudah terisi hari ini!`
              : `🦴 ${dog.name}’s bowl is already filled for today!`
          );
          return;
        }
        if (consumeInventoryItem('animal_feed', 1)) {
          setAnimals((prev) =>
            prev.map((a) =>
              a.type === 'dog'
                ? {
                    ...a,
                    fedToday: true,
                    hunger: 100,
                    daysUnfed: 0,
                    happiness: Math.min(100, (a.happiness ?? 75) + 16),
                    emotion: a.isSick ? 'sick' : 'happy',
                    affection: Math.min(255, a.affection + 15),
                  }
                : a
            )
          );
          soundEngine.playHeart();
          engineRef.current?.triggerAnimalInteractionFx(dog.id);
          rewardOncePerDayJoy(`feed_dog_${dog.id}`, 9, 5);
          advanceMission('feed_animal', 1);
          showToast(
            isId
              ? `🦴 Mangkuk luar ruangan untuk ${dog.name} telah diisi!`
              : `🦴 Filled the outdoor Dog Bowl for ${dog.name}!`
          );
        }
        return;
      }

      if (node.kind === 'egg_incubator') {
        if (!canManageFarm) {
          showToast('🥚 This Egg Incubator belongs to your friend’s Chicken Coop.');
          return;
        }
        const slotIdx = node.slotIndex ?? 0;
        const slots = normalizeIncubatorSlots(s.profile.coopLevel || 1, s.profile.coopIncubators);
        const curSlot = slots[slotIdx];
        if (!curSlot) return;

        if (curSlot.readyToHatch) {
          const chickensCount = s.animals.filter((a) => a.type === 'chicken').length;
          const coopCap = getCoopCapacity(s.profile.coopLevel || 1);
          if (chickensCount >= coopCap) {
            showToast(`🐔 Chicken Coop is full (${chickensCount}/${coopCap})! Upgrade your Coop before hatching.`);
            return;
          }
          setHatchChickName(`Chick #${chickensCount + 1}`);
          setPendingHatchSlotIndex(slotIdx);
          soundEngine.playHeart();
          return;
        }

        if (curSlot.eggPlacedDay !== null) {
          showToast(`🥚 Incubator #${slotIdx + 1}: Egg is warming! ${curSlot.daysRemaining} day(s) until hatch.`);
          return;
        }

        const hasEggInBag = s.inventory.some((x) => x.itemId === 'egg_fresh' && x.quantity > 0);
        if (!hasEggInBag) {
          showToast('🥚 Bring a Fresh Egg (egg_fresh) in your bag to place in the Egg Incubator!');
          return;
        }
        if (consumeInventoryItem('egg_fresh', 1)) {
          setProfile((p) => {
            const updated = normalizeIncubatorSlots(p.coopLevel || 1, p.coopIncubators).map((sl) =>
              sl.slotIndex === slotIdx
                ? { slotIndex: slotIdx, eggPlacedDay: s.day, daysRemaining: 3, readyToHatch: false }
                : sl
            );
            return { ...p, coopIncubators: updated, version: p.version + 1 };
          });
          soundEngine.playHarvest();
          showToast(`🥚 Placed a Fresh Egg in Incubator #${slotIdx + 1}! It will hatch in 3 days.`);
        }
        return;
      }

      if (node.kind === 'cheese_maker') {
        if (!canManageFarm) {
          showToast('🧀 This Artisan Cheese Maker belongs to your friend’s Lv.3 Barn.');
          return;
        }
        if ((s.profile.barnLevel || 1) < 3 || !s.profile.hasCheeseMaker) {
          showToast('🧀 Upgrade your Barn to Lv.3 and purchase the Artisan Cheese Maker from Felix’s Ranch!');
          return;
        }
        const hasMilk = s.inventory.some((x) => x.itemId === 'milk_fresh' && x.quantity > 0);
        if (!hasMilk) {
          showToast('🥛 Bring Fresh Cow Milk in your bag to press Artisan Valley Cheese!');
          return;
        }
        if (consumeInventoryItem('milk_fresh', 1)) {
          if (!addInventoryItem('food_cheese', 1)) return;
          soundEngine.playHarvest();
          engineRef.current?.playWorkAnimation();
          rewardProgress(15, 6);
          showToast('🧀 Pressed Fresh Cow Milk into Artisan Valley Cheese!');
        }
        return;
      }

      if (node.kind === 'sleep_bed') {
        startBedSleep();
        return;
      }

      if (node.kind === 'use_tv') {
        soundEngine.playUiClick();
        setActiveFacilityModal('tv');
        return;
      }

      if (node.kind === 'use_fridge') {
        soundEngine.playUiClick();
        setActiveFacilityModal('fridge');
        return;
      }

      if (node.kind === 'use_toolbox') {
        soundEngine.playUiClick();
        setActiveFacilityModal('toolbox');
        return;
      }

      if (node.kind === 'use_wardrobe') {
        soundEngine.playUiClick();
        setActiveFacilityModal('wardrobe');
        return;
      }

      if (node.kind === 'harvest_apple_honey') {
        if (!canManageFarm) {
          showToast('This belongs to your friend’s homestead apple tree & beehive.');
          return;
        }
        if (s.season === 'Summer' || s.season === 'Autumn') {
          if (s.appleTree.applesReady > 0) {
            if (!addInventoryItem('food_apple', 1)) return;
            setAppleTree((prev) => ({ ...prev, applesReady: Math.max(0, prev.applesReady - 1) }));
            soundEngine.playHarvest();
            engineRef.current?.playWorkAnimation('gift', 0.36);
            rewardProgress(10, 5);
          } else {
            showToast('🌳 Today’s apples have all been picked. New fruit ripens tomorrow.');
          }
        } else if (s.season === 'Spring') {
          if (!hasSpringFlowerPlanted(s.plots)) {
            showToast('🐝 Plant at least 1 Spring flower (Tulip or Sunflower) on your farm to attract bees!');
          } else if (s.appleTree.honeyReady) {
            if (!addInventoryItem('food_honey', 1)) return;
            setAppleTree((prev) => ({ ...prev, honeyReady: false }));
            soundEngine.playHarvest();
            engineRef.current?.playWorkAnimation('gift', 0.36);
            rewardProgress(12, 6);
          } else {
            showToast('🐝 Bees are busy gathering nectar. Check back tomorrow morning!');
          }
        } else {
          showToast('❄️ Winter season: Apples bear fruit in Summer/Autumn; bees make honey in Spring.');
        }
        return;
      }

      if (node.kind === 'shipping_bin') {
        if (!canManageFarm) {
          showToast('This Shipping Bin belongs to your friend’s farm.');
          return;
        }
        if (def && slot && def.sellPrice > 0) {
          const qty = slot.quantity;
          const econ = await transactMarketEconomy('sell', def.id, qty, activeCharacterId);
          const earned = econ?.ok ? econ.netGold : def.sellPrice * qty;
          const taxPaid = econ?.taxGold || 0;
          if (econ?.market) setMarketState(econ.market);
          if (econ?.taxBuckets) setTaxBuckets(econ.taxBuckets);

          consumeInventoryItem(def.id, qty, true);
          setProfile((p) => ({ ...p, gold: p.gold + earned, version: p.version + 1 }));
          recordSaleStat('market_gold', s.season, qty, earned);
          if (s.stats.totalGoldEarned + earned >= 3000) unlockAchievement('ach_wealthy_farmer');
          rewardProgress(8, 4);
          soundEngine.playCoin();
          showToast(
            `💰 Shipped ${qty}x ${def.name} → +${earned.toLocaleString()} G${taxPaid > 0 ? ` (${econ?.taxPercent ?? 0}% Valley Tax: ${taxPaid} G)` : ''}!`
          );
        } else {
          showToast('Equip crops, eggs, milk, fish, materials, or spare tools in the Master Slot, then press F at the Shipping Bin.');
        }
        return;
      }

      if (node.kind === 'cave_ore' || node.kind === 'mine_rock') {
        if (def?.toolKind !== 'hammer') {
          showToast('🔨 Equip your Hammer in the Master Slot to mine ore veins and boulders!');
          return;
        }
        if (s.stamina < 4) {
          showToast('⚡ Not enough stamina! Eat food or rest in your Farmhouse bed.');
          return;
        }
        soundEngine.playWoodStone();
        engineRef.current?.playWorkAnimation();
        setStamina((v) => Math.max(0, v - 4));
        const r = Math.random();
        let dropId = 'mat_stone';
        if (node.kind === 'cave_ore') {
          if (r < 0.06) dropId = 'mat_emerald';
          else if (r < 0.16) dropId = 'mat_ancient_relic';
          else if (r < 0.28) dropId = 'mat_gold_ore';
          else if (r < 0.43) dropId = 'mat_crystal';
          else if (r < 0.60) dropId = 'mat_silver';
          else if (r < 0.80) dropId = 'mat_iron';
          else if (r < 0.93) dropId = 'mat_copper';
          else dropId = 'mat_stone';
        } else {
          if (r < 0.08) dropId = 'mat_ancient_relic';
          else if (r < 0.22) dropId = 'mat_crystal';
          else if (r < 0.44) dropId = 'mat_copper';
          else if (r < 0.70) dropId = 'mat_iron';
          else dropId = 'mat_stone';
        }
        if (!addInventoryItem(dropId, 1)) return;
        setStats((st) => ({ ...st, materialsGathered: st.materialsGathered + 1 }));
        rewardProgress(node.kind === 'cave_ore' ? 12 : 8, 4);
        advanceMission('gather', 1);
        showToast(`⛏️ Mined ${ITEMS[dropId]?.name || dropId}!`);
        return;
      }

      if (node.kind === 'forest_log') {
        if (def?.toolKind !== 'axe') {
          showToast('🪓 Equip your Axe in the Master Slot to chop fallen forest timber!');
          return;
        }
        if (s.stamina < 3) {
          showToast('⚡ Not enough stamina!');
          return;
        }
        soundEngine.playWoodStone();
        engineRef.current?.playWorkAnimation();
        setStamina((v) => Math.max(0, v - 3));
        const dropId = Math.random() < 0.22 ? 'food_honey' : 'mat_wood';
        if (!addInventoryItem(dropId, 1)) return;
        setStats((st) => ({ ...st, materialsGathered: st.materialsGathered + 1 }));
        rewardProgress(8, 3);
        advanceMission('gather', 1);
        showToast(`🪓 Gathered ${ITEMS[dropId]?.name || dropId}!`);
        return;
      }

      if (node.kind === 'fishing_spot') {
        if (def?.toolKind !== 'fishing_rod') {
          showToast('🎣 Equip your Fishing Rod in the Master Slot to fish from the dock or pier!');
          return;
        }
        startInWorldFishingRef.current(node.spotType === 'ocean' ? 'ocean' : 'river');
        return;
      }

      if (node.kind === 'secret_gate') {
        if (s.profile.secretGroveUnlocked) {
          showToast('✨ The Ancient Secret Grove welcomes you! Speak with Nyra & gather Blue Crystals.');
        } else {
          showToast('🔒 Gate sealed. Mine an Ancient Valley Relic in Mountain Cave and deliver it to Elian!');
        }
      }
    },
    [
      addInventoryItem,
      advanceMission,
      consumeInventoryItem,
      executeZoneTransition,
      startBedSleep,
      pushWorldSpeechBubble,
      rewardOncePerDayJoy,
      rewardProgress,
      rollCaveHoleCoord,
      showToast,
      unlockAchievement,
    ]
  );

  // === ANIMAL CARE (F — Medicine, Feed, Brush, Harvest, Play + Full Language Support) ===
  const handleInteractAnimal = useCallback(
    (animalId: string) => {
      const s = stateRef.current;
      const isId = s.gameSettings.language === 'id';
      const slot = s.equippedItemId ? s.inventory.find((x) => x.itemId === s.equippedItemId) : null;
      const def = slot ? ITEMS[slot.itemId] : null;
      const animal = s.animals.find((a) => a.id === animalId);
      if (!animal) return;

      // 1. Animal Medicine — cure sick animals (3+ unfed days)
      if (def?.id === 'item_animal_medicine') {
        if (!animal.isSick) {
          showToast(
            isId
              ? `💊 ${animal.name} sedang sehat dan tidak membutuhkan obat saat ini.`
              : `💊 ${animal.name} is already healthy and doesn’t need medicine right now.`
          );
          return;
        }
        if (consumeInventoryItem('item_animal_medicine', 1)) {
          setAnimals((prev) =>
            prev.map((a) =>
              a.id === animalId
                ? {
                    ...a,
                    isSick: false,
                    health: 100,
                    daysUnfed: 0,
                    happiness: Math.min(100, (a.happiness ?? 30) + 35),
                    affection: Math.min(255, a.affection + 25),
                    emotion: 'happy',
                  }
                : a
            )
          );
          soundEngine.playHeart();
          engineRef.current?.triggerAnimalInteractionFx(animalId);
          pushWorldSpeechBubble(
            `animal:${animalId}`,
            animal.name,
            isId ? '✨ Sudah sembuh & ceria lagi!' : '✨ Feeling healthy and bright again!',
            'npc',
            4500
          );
          showToast(
            isId
              ? `💊 ${animal.name} telah sembuh dengan Obat Hewan! Kesehatan pulih 100%.`
              : `💊 ${animal.name} was cured with Animal Medicine! Health restored to 100%.`
          );
        }
        return;
      }

      // 2. Feed Animal
      if (def?.id === 'animal_feed' && !animal.fedToday) {
        if (consumeInventoryItem('animal_feed', 1)) {
          setAnimals((prev) =>
            prev.map((a) =>
              a.id === animalId
                ? {
                    ...a,
                    fedToday: true,
                    hunger: 100,
                    daysUnfed: 0,
                    happiness: Math.min(100, (a.happiness ?? 75) + 15),
                    emotion: a.isSick ? 'sick' : 'happy',
                    affection: Math.min(255, a.affection + 15),
                  }
                : a
            )
          );
          soundEngine.playHeart();
          engineRef.current?.triggerAnimalInteractionFx(animalId);
          rewardOncePerDayJoy(`feed_animal_${animalId}`, 9, 5);
          advanceMission('feed_animal', 1);

          if (s.visitingFarmOwnerId) {
            const taskType: FarmJobTaskType | null =
              animal.type === 'cow'
                ? 'feed_cow'
                : animal.type === 'sheep'
                  ? 'feed_sheep'
                  : animal.type === 'horse'
                    ? 'feed_horse'
                    : animal.type === 'dog'
                      ? 'feed_dog'
                      : null;
            if (taskType) {
              const activeJob = s.farmJobs.find(
                (j) =>
                  j.workerUid === s.profile.uid &&
                  j.employerUid === s.visitingFarmOwnerId &&
                  j.status === 'in_progress' &&
                  j.tasks.includes(taskType)
              );
              if (activeJob) {
                mpRef.current?.reportJobProgress(activeJob.id, `feed_${animal.type}_${animal.id}`);
              }
            }
          }

          showToast(
            isId
              ? `🌾 ${animal.name} makan Pakan Ternak dengan lahap!${animal.isSick ? ' (Masih sakit — beri Obat Hewan!)' : ''}`
              : `🌾 ${animal.name} happily ate the Animal Fodder!${animal.isSick ? ' (Still sick — use Animal Medicine!)' : ''}`
          );
        }
        return;
      }

      // 3. Groom / Brush Animal
      if (def?.toolKind === 'brush' && !animal.brushedToday) {
        setAnimals((prev) =>
          prev.map((a) =>
            a.id === animalId
              ? {
                  ...a,
                  brushedToday: true,
                  happiness: Math.min(100, (a.happiness ?? 75) + 15),
                  emotion: a.isSick ? 'sick' : 'happy',
                  affection: Math.min(255, a.affection + 15),
                }
              : a
          )
        );
        soundEngine.playHeart();
        engineRef.current?.playWorkAnimation();
        engineRef.current?.triggerAnimalInteractionFx(animalId);
        rewardOncePerDayJoy(`brush_animal_${animalId}`, 9, 5);
        showToast(
          isId
            ? `🪥 ${animal.name} baru saja disikat dan terlihat sangat senang!`
            : `🪥 ${animal.name} is freshly groomed and beaming!`
        );
        return;
      }

      // Block product harvest if animal is sick
      if (
        animal.isSick &&
        ((animal.type === 'cow' && def?.toolKind === 'milk_pail') ||
          animal.type === 'chicken' ||
          (animal.type === 'sheep' && def?.toolKind === 'sickle'))
      ) {
        showToast(
          isId
            ? `🤒 ${animal.name} sedang sakit! Beli Obat Hewan di Peternakan Felix atau Klinik dan gunakan pada ${animal.name}.`
            : `🤒 ${animal.name} is sick! Buy Animal Medicine from Felix’s Ranch or the Clinic and use it on ${animal.name}.`
        );
        return;
      }

      if (animal.type === 'cow' && def?.toolKind === 'milk_pail' && animal.productReady) {
        if (!addInventoryItem('milk_fresh', 1)) return;
        setAnimals((prev) => prev.map((a) => (a.id === animalId ? { ...a, productReady: false } : a)));
        soundEngine.playHarvest();
        engineRef.current?.triggerAnimalInteractionFx(animalId);
        rewardProgress(10, 4);
        showToast(
          isId
            ? `🥛 Berhasil memerah Susu Sapi Segar dari ${animal.name}!`
            : `🥛 Collected Fresh Cow Milk from ${animal.name}!`
        );
        return;
      }

      if (animal.type === 'chicken' && animal.productReady) {
        if (!addInventoryItem('egg_fresh', 1)) return;
        setAnimals((prev) => prev.map((a) => (a.id === animalId ? { ...a, productReady: false } : a)));
        soundEngine.playHarvest();
        engineRef.current?.triggerAnimalInteractionFx(animalId);
        rewardProgress(8, 4);
        showToast(
          isId
            ? `🥚 Berhasil mengambil Telur Segar dari ${animal.name}!`
            : `🥚 Gathered a Fresh Egg from ${animal.name}!`
        );
        return;
      }

      if (animal.type === 'sheep' && def?.toolKind === 'sickle' && animal.productReady) {
        if (!addInventoryItem('wool_soft', 1)) return;
        setAnimals((prev) => prev.map((a) => (a.id === animalId ? { ...a, productReady: false } : a)));
        soundEngine.playHarvest();
        engineRef.current?.triggerAnimalInteractionFx(animalId);
        rewardProgress(10, 4);
        showToast(
          isId
            ? `🧶 Berhasil mencukur Wol Domba Lembut dari ${animal.name}!`
            : `🧶 Sheared Soft Sheep Wool from ${animal.name}!`
        );
        return;
      }

      // 4. Pet / Play interaction (updates happiness & affection)
      setAnimals((prev) =>
        prev.map((a) =>
          a.id === animalId
            ? {
                ...a,
                playedToday: true,
                happiness: Math.min(100, (a.happiness ?? 75) + (a.playedToday ? 2 : 12)),
                affection: Math.min(255, a.affection + (a.playedToday ? 1 : 6)),
                emotion: a.isSick ? 'sick' : 'happy',
              }
            : a
        )
      );
      soundEngine.playHeart();
      engineRef.current?.triggerAnimalInteractionFx(animalId);
      const joyAdded = rewardOncePerDayJoy(`pet_animal_${animalId}`, 4, 4);
      if (animal.isSick) {
        showToast(
          isId
            ? `🤒 ${animal.name} lemas dan sakit! Segera berikan Obat Hewan (beli di Peternakan Felix / Klinik).`
            : `🤒 ${animal.name} feels weak and sick! Give Animal Medicine (buy at Felix’s Ranch / Clinic).`
        );
      } else {
        showToast(
          isId
            ? joyAdded > 0
              ? `💛 ${animal.name} mengelus manja dengan bahagia! (+${joyAdded} Joy)`
              : `💛 ${animal.name} tersenyum hangat padamu!`
            : joyAdded > 0
              ? `💛 ${animal.name} nuzzles up against you happily! (+${joyAdded} Joy)`
              : `💛 ${animal.name} smiles warmly! (Daily Joy already earned)`
        );
      }
    },
    [addInventoryItem, advanceMission, consumeInventoryItem, pushWorldSpeechBubble, rewardOncePerDayJoy, rewardProgress, showToast]
  );

  const handleGiveGift = useCallback(
    (npcId: string, itemId: string, silentToast = false): string => {
      const npc = NPC_MAP[npcId];
      const item = ITEMS[itemId];
      if (!npc || !item) return 'Thank you very much.';
      consumeInventoryItem(itemId, 1);

      const isBday = npc.birthday.season === season && npc.birthday.day === day;
      const mult = isBday ? 2 : 1;
      let fpDelta = 12;
      let apDelta = 10;
      let reaction = `Thank you for the ${item.name}!`;

      if (npc.giftPrefs.loved.includes(itemId)) {
        fpDelta = 60 * mult;
        apDelta = 65 * mult;
        reaction = isBday
          ? `Oh!! ${item.name} on my birthday?! This is the most wonderful gift ever!`
          : `Oh! I truly love ${item.name}! Thank you so much!`;
        soundEngine.playHeart();
      } else if (npc.giftPrefs.liked.includes(itemId)) {
        fpDelta = 30 * mult;
        apDelta = 30 * mult;
        reaction = `${item.name}! I really like this—thank you!`;
        soundEngine.playHeart();
      } else if (npc.giftPrefs.hated.includes(itemId)) {
        fpDelta = -35;
        apDelta = -35;
        reaction = `Ugh... sorry, I really can't stand ${item.name}.`;
      } else if (npc.giftPrefs.disliked.includes(itemId)) {
        fpDelta = -15;
        apDelta = -15;
        reaction = `Hmm, ${item.name} isn't really my cup of tea...`;
      }

      const alreadyGiftedToday = Boolean(stateRef.current.npcRels[npcId]?.memory.giftedToday);
      setStats((st) => ({ ...st, giftsGiven: st.giftsGiven + 1 }));
      const joyRes = rewardDiminishingJoy('gift', alreadyGiftedToday ? 4 : 14, 10);
      if (!silentToast) {
        showToast(`🎁 Gift given! +${joyRes.added} Joy`);
      }

      setNpcRels((prev) => {
        const cur = prev[npcId];
        const appliedFp = alreadyGiftedToday ? 0 : fpDelta;
        const appliedAp = alreadyGiftedToday ? 0 : apDelta;
        const nextFp = Math.max(0, Math.min(1000, cur.friendshipPoints + appliedFp));
        const nextAp = npc.isMarriageCandidate ? Math.max(0, Math.min(1000, cur.affectionPoints + appliedAp)) : 0;
        const nextHeart = Math.floor(nextAp / 100);
        const updated: Record<string, NPCRelationshipState> = {
          ...prev,
          [npcId]: {
            ...cur,
            friendshipPoints: nextFp,
            affectionPoints: nextAp,
            heartLevel: nextHeart,
            romanceStage: getRomanceStage(nextFp, nextAp, profile.spouseId === npcId),
            memory: {
              ...cur.memory,
              giftedToday: true,
              lastGiftDay: `${season} ${day}`,
              giftsReceivedCount: cur.memory.giftsReceivedCount + 1,
              favoriteGiftsRemembered:
                fpDelta >= 30 && !cur.memory.favoriteGiftsRemembered.includes(item.name)
                  ? [...cur.memory.favoriteGiftsRemembered, item.name].slice(-4)
                  : cur.memory.favoriteGiftsRemembered,
            },
          },
        };
        const friendCount = Object.values(updated).filter((r) => r.friendshipPoints >= 250).length;
        if (friendCount >= 3) unlockAchievement('ach_friend_village');
        return updated;
      });
      return reaction;
    },
    [consumeInventoryItem, day, profile.spouseId, rewardDiminishingJoy, season, showToast, unlockAchievement]
  );

  // Pick contextual NPC line & render as overhead 3D Speech Bubble above NPC head!
  const performNpcOverheadTalk = useCallback(
    (npcId: string) => {
      const s = stateRef.current;
      const npc = NPC_MAP[npcId];
      if (!npc) return;
      setNpcChoicePopover(null);
      const rel = s.npcRels[npcId];
      const alreadyTalked = rel?.memory.talkedToday;
      if (!alreadyTalked) {
        setNpcRels((prev) => {
          const cur = prev[npcId];
          if (!cur || cur.memory.talkedToday) return prev;
          const nextFp = Math.min(1000, cur.friendshipPoints + 12);
          advanceMission('talk_npc', 1);
          return {
            ...prev,
            [npcId]: {
              ...cur,
              friendshipPoints: nextFp,
              memory: { ...cur.memory, talkedToday: true },
            },
          };
        });
      }
      rewardOncePerDayJoy(`talk_npc_${npcId}`, alreadyTalked ? 0 : 8, 6);
      soundEngine.playUiClick();

      const d = npc.dialogues;
      const isBday = npc.birthday.season === s.season && npc.birthday.day === s.day;
      const isFestivalToday = FESTIVALS.some((f) => f.season === s.season && f.day === s.day);
      const liveEmotion = engineRef.current?.getNpcEmotion(npcId) ?? 'neutral';
      const lastGiftName = rel?.memory.favoriteGiftsRemembered[0]
        ? ITEMS[rel.memory.favoriteGiftsRemembered[0]]?.name || rel.memory.favoriteGiftsRemembered[0]
        : undefined;

      const line =
        isBday && d.birthday
          ? d.birthday
          : pickContextualNpcLine({
              npc,
              relationship: rel,
              playerName: s.profile.avatarName,
              farmName: s.profile.farmName,
              season: s.season,
              weather: s.weather,
              hour: s.hour,
              isFestivalToday,
              emotion: liveEmotion,
              cropsHarvestedTotal: s.stats.cropsHarvested,
              lastGiftName,
              language: s.gameSettings.language,
            });
      pushWorldSpeechBubble(`npc:${npcId}`, npc.name, line, 'npc', 6200, { emotion: liveEmotion });
    },
    [advanceMission, pushWorldSpeechBubble, rewardOncePerDayJoy]
  );

  const performNpcOverheadGift = useCallback(
    (npcId: string, itemId: string) => {
      const npc = NPC_MAP[npcId];
      if (!npc) return;
      setNpcChoicePopover(null);
      engineRef.current?.playWorkAnimation('gift', 0.42);
      const reaction = handleGiveGift(npcId, itemId, true);
      pushWorldSpeechBubble(`npc:${npcId}`, npc.name, reaction, 'npc', 6200);
    },
    [handleGiveGift, pushWorldSpeechBubble]
  );

  // === NPC INTERACTIONS (E = overhead talk or auto-give/choice; F = shop/services modal) ===
  const handleOpenNpc = useCallback(
    (npcId: string, mode: 'talk' | 'shop') => {
      const s = stateRef.current;
      const npc = NPC_MAP[npcId];
      if (!npc) return;

      if (mode === 'shop') {
        setNpcChoicePopover(null);
        setNpcDialogState({ npcId, tab: 'shop' });
        return;
      }

      // Talk mode (E): check if player is holding a non-tool item in Master Hand Slot
      const heldId = s.equippedItemId;
      const heldSlot = heldId ? s.inventory.find((x) => x.itemId === heldId && x.quantity > 0) : null;
      const heldDef = heldSlot ? ITEMS[heldSlot.itemId] : null;
      const isGiftableHeld = Boolean(heldDef && !heldDef.toolKind);

      if (isGiftableHeld && heldDef) {
        if (s.autoGiveEnabled) {
          performNpcOverheadGift(npcId, heldDef.id);
        } else {
          soundEngine.playUiClick();
          setNpcChoicePopover({
            npcId,
            npcName: npc.name,
            heldItemName: heldDef.name,
            heldItemEmoji: heldDef.iconEmoji || '🎁',
          });
        }
        return;
      }

      performNpcOverheadTalk(npcId);
    },
    [performNpcOverheadGift, performNpcOverheadTalk]
  );

  // === MOUNT THREE.JS ENGINE ONCE ===
  useEffect(() => {
    const el = canvasMountRef.current;
    if (!el) return;

    const initialTool = equippedItemId ? ITEMS[equippedItemId]?.toolKind : undefined;
    const engine = new GameEngine(el, profile.avatarConfig, {
      onMoveSync: (x, y, z, yaw, animState) => {
        playerPosRef.current = { x, z };
        mpRef.current?.sendMove(x, y, z, yaw, animState);
      },
      onPromptChange: setNearbyPrompt,
      onInteractWorld: (node) => void handleInteractWorld(node),
      onChopTree: (treeId, scope, treeLevel, isStump) => handleChopTree(treeId, scope, treeLevel, isStump),
      onInteractNpc: (npcId, mode) => handleOpenNpc(npcId, mode),
      onPrivateChatPlayer: (player) => {
        setChatInitialChannel('private');
        setChatPrivateTarget({ uid: player.uid, name: player.avatarName });
        setShowChat(true);
      },
      onInteractPlot: (gx, gz) => handleInteractPlot(gx, gz),
      onDigCaveTile: (gx, gz) => handleDigCaveTile(gx, gz),
      onCastFishingWater: (spotType) => startInWorldFishingRef.current(spotType),
      onFishingSpacePress: () => handleFishingSpacePressRef.current(),
      onFishingCancel: () => cancelInWorldFishingRef.current(),
      onPlayerJump: () => setStamina((v) => Math.max(0, v - 1)),
      onReadSignboard: (signId, title, text) => {
        soundEngine.playUiClick();
        pushWorldSpeechBubble(signId, title, text, 'sign', 6500);
      },
      onInteractAnimal: (id) => handleInteractAnimal(id),
      onZoneAutoDetect: (detected) => {
        setZone(detected);
        mpRef.current?.changeZone(detected, stateRef.current.visitingFarmOwnerId || stateRef.current.profile.uid, 0, 0);
      },
      onTagsUpdate: setFloatingTags,
      onHeadAnchorsUpdate: setHeadAnchors,
      onToggleInventory: () => setShowInventory((v) => !v),
      onToggleChat: () => {
        setChatInitialChannel('global');
        setShowChat((v) => !v);
      },
      onToggleMenu: () => setBukuTab((prev) => (prev === null ? 'profile' : null)),
      onToggleSettings: () => setSettingsOpen((v) => !v),
      onTriggerToolSlot: (slotNum) => handleTriggerToolSlot(slotNum),
      onGamepadChange: (connected, name) => setGamepadStatus({ connected, name }),
      onNpcAmbientBubble: (npcId, npcName, text, emotion, isThought) => {
        pushWorldSpeechBubble(`npc:${npcId}`, npcName, text, 'npc', isThought ? 4200 : 5000, {
          emotion,
          isThought,
        });
      },
      onAnimalAmbientBubble: (animalId, animalName, text, isThought) => {
        pushWorldSpeechBubble(`animal:${animalId}`, animalName, text, 'npc', 4200, {
          isThought,
        });
      },
    });
    if (initialTool) engine.setEquippedTool(initialTool);
    engine.setActiveHeldItem(equippedItemId);
    engine.setKeyBindings(keybindings);
    engine.setLanguage(gameSettings.language);
    engine.setLocalIdentity(profile.uid, profile.avatarName);
    engine.applyGraphicsSettings(gameSettings.graphics);
    engine.setCameraConfig(liveRuntimeConfig.cameraConfig);
    engine.setPovMode(gameSettings.povMode || liveRuntimeConfig.cameraConfig.povMode || 'lock');
    engine.setPerformanceConfig(liveRuntimeConfig.performanceConfig);
    engine.regenerateFarmTrees(profile.uid, stateRef.current.farmTrees);
    void fetchGlobalTrees().then((trees) => {
      if (trees.length > 0) engine.setGlobalTrees(trees);
    });
    engineRef.current = engine;
    engine.syncFarmPlots(plots);
    engine.syncAnimals(
      animals,
      visitingFarmOwnerId ? visitingLocks.barnLocked : profile.barnLocked,
      visitingFarmOwnerId ? visitingLocks.coopLocked : profile.coopLocked,
      visitingFarmOwnerId ? visitingLocks.stableLocked : (profile.stableLocked ?? true)
    );
    engine.syncAppleTree(appleTree.applesReady, season === 'Spring' && hasSpringFlowerPlanted(plots));
    engine.setFarmBuildingState(
      profile.coopLevel || 1,
      profile.barnLevel || 1,
      Boolean(profile.hasCheeseMaker),
      normalizeIncubatorSlots(profile.coopLevel || 1, profile.coopIncubators)
    );

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    engineRef.current?.setLanguage(gameSettings.language);
  }, [gameSettings.language]);

  useEffect(() => {
    engineRef.current?.setKeyBindings(keybindings);
  }, [keybindings]);

  useEffect(() => {
    engineRef.current?.syncFarmPlots(plots);
  }, [plots]);

  useEffect(() => {
    const hasBees = season === 'Spring' && hasSpringFlowerPlanted(plots);
    engineRef.current?.syncAppleTree(appleTree.applesReady, hasBees);
  }, [appleTree.applesReady, season, plots]);

  useEffect(() => {
    engineRef.current?.setFarmBuildingState(
      profile.coopLevel || 1,
      profile.barnLevel || 1,
      Boolean(profile.hasCheeseMaker),
      normalizeIncubatorSlots(profile.coopLevel || 1, profile.coopIncubators)
    );
  }, [profile.coopLevel, profile.barnLevel, profile.hasCheeseMaker, profile.coopIncubators]);

  const effectiveBarnLocked = visitingFarmOwnerId ? visitingLocks.barnLocked : profile.barnLocked;
  const effectiveHouseLocked = visitingFarmOwnerId ? visitingLocks.houseLocked : profile.houseLocked;
  const effectiveCoopLocked = visitingFarmOwnerId ? visitingLocks.coopLocked : profile.coopLocked;
  const effectiveStableLocked = visitingFarmOwnerId ? visitingLocks.stableLocked : (profile.stableLocked ?? true);

  useEffect(() => {
    engineRef.current?.syncAnimals(animals, effectiveBarnLocked, effectiveCoopLocked, effectiveStableLocked);
  }, [animals, effectiveBarnLocked, effectiveCoopLocked, effectiveStableLocked]);

  useEffect(() => {
    engineRef.current?.setWorldCondition(season, weather, hour, day, profile.spouseId, profile.secretGroveUnlocked);
  }, [season, weather, hour, day, profile.spouseId, profile.secretGroveUnlocked]);

  useEffect(() => {
    engineRef.current?.setPovMode(gameSettings.povMode || 'lock');
  }, [gameSettings.povMode]);

  const applyLiveRuntimeConfig = useCallback((cfg: RuntimeGameConfig, triggerAnnouncement = false) => {
    const prevCfg = stateRef.current.liveRuntimeConfig;
    setLiveRuntimeConfig(cfg);
    if (cfg.cameraConfig) {
      engineRef.current?.setCameraConfig(cfg.cameraConfig);
      if (cfg.cameraConfig.povMode && cfg.cameraConfig.povMode !== prevCfg.cameraConfig.povMode) {
        setGameSettings((prev) => ({ ...prev, povMode: cfg.cameraConfig.povMode }));
      }
    }
    if (cfg.performanceConfig) {
      engineRef.current?.setPerformanceConfig(cfg.performanceConfig);
    }
    if (cfg.skyAtmosphereConfig) {
      engineRef.current?.setSkyAtmosphereConfig(cfg.skyAtmosphereConfig);
    }
    if (cfg.npcScheduleOverrides) {
      const mappedSchedules: Record<string, import('./game/types').NPCRoutineSlot[]> = {};
      for (const [k, v] of Object.entries(cfg.npcScheduleOverrides)) {
        if (Array.isArray(v)) {
          mappedSchedules[k] = v;
        } else if (v && typeof v === 'object' && Array.isArray((v as { schedule?: import('./game/types').NPCRoutineSlot[] }).schedule)) {
          mappedSchedules[k] = (v as { schedule: import('./game/types').NPCRoutineSlot[] }).schedule;
        }
      }
      engineRef.current?.setNpcScheduleOverrides(mappedSchedules);
    }
    if (cfg.videoCallConfig) {
      callManagerRef.current?.setVideoConfig(cfg.videoCallConfig);
      if (
        typeof cfg.videoCallConfig.showSelfPreviewByDefault === 'boolean' &&
        cfg.videoCallConfig.showSelfPreviewByDefault !== prevCfg.videoCallConfig.showSelfPreviewByDefault
      ) {
        setGameSettings((prev) => ({ ...prev, showSelfCameraInCall: cfg.videoCallConfig.showSelfPreviewByDefault }));
      }
    }
    if (cfg.defaultGlobalTheme && VALID_THEMES.includes(cfg.defaultGlobalTheme) && cfg.defaultGlobalTheme !== prevCfg.defaultGlobalTheme) {
      setGameSettings((prev) => ({ ...prev, theme: cfg.defaultGlobalTheme }));
    }
    if (cfg.defaultWeather && cfg.defaultWeather !== prevCfg.defaultWeather) {
      setWeather(cfg.defaultWeather);
    }
    if (cfg.worldTimeOverride) {
      const wt = cfg.worldTimeOverride;
      if (wt.weatherOverride) {
        setWeather(wt.weatherOverride);
      }
      if (wt.enabled) {
        setHour(wt.hour);
        setMinute(wt.minute);
        setDay(wt.day);
        setSeason(wt.season);
        setYear(wt.year);
      }
    }
    if (cfg.announcementBanner) {
      if (!cfg.announcementBanner.enabled) {
        setActiveAnnouncement(null);
      } else if (triggerAnnouncement && cfg.announcementBanner.message) {
        setActiveAnnouncement({
          title: cfg.announcementBanner.title,
          message: cfg.announcementBanner.message,
          category: cfg.announcementBanner.category || 'update',
          durationSec: cfg.announcementBanner.durationSec || 10,
        });
        setAnnouncementNonce((n) => n + 1);
      }
    }
  }, []);

  // === INITIAL MARKET, JOBS & FIREBASE CLOUD LOAD ===
  useEffect(() => {
    // Ephemeral Guest Policy: always clear any leftover guest data on page load/reload
    try {
      if (localStorage.getItem(GUEST_META_KEY) === 'guest') {
        clearLocalSave();
      }
    } catch {
      // ignore storage errors
    }

    fetch('/api/runtime-config')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data?.ok && data.config) {
          applyLiveRuntimeConfig(data.config as RuntimeGameConfig, Boolean(data.config.announcementBanner?.enabled));
        }
      })
      .catch(() => {});

    fetchMarketState().then((res) => {
      if (res) {
        setMarketState(res.market);
        setTaxBuckets(res.taxBuckets);
      }
    });
    fetchOpenFarmJobs().then((jobs) => setFarmJobs(jobs));
    testFirestoreConnection();

    const unsubAuth = subscribeAuth(async (user) => {
      if (user) {
        if (user.isAnonymous) {
          // If the page was reloaded while anonymous (guest) and game has not started yet,
          // clear temporary guest state and return cleanly to Title Dashboard.
          if (!startedRef.current && !isGuestSessionRef.current) {
            clearLocalSave();
            await signOutPlayer().catch(() => {});
          }
          return;
        }
        setFirebaseEmail(user.email);
        setFirebaseUid(user.uid);
        markLoginSessionType('social');
        // Restore Nakama Social session + character roster + developer verification
        try {
          const restored = await restoreFirebaseSocialSession();
          if (restored) {
            setSocialAccount(restored.account);
            setCharacterRoster(restored.characters);
          }
        } catch {
          // fallback if offline
        }
        if (!user.emailVerified) return;
        const cloud = await loadCloudSave(user.uid);
        const cloudMeta = (cloud.farmSave?.payload as { meta?: ProfileMetaPayload } | undefined)?.meta;

        if (cloud.profile && cloud.profile.version >= profile.version) {
          const mergedProfile: PlayerProfile = {
            ...cloud.profile,
            dogName: cloudMeta?.dogName || cloud.profile.dogName || 'Bobi',
            horseName: cloudMeta?.horseName || cloud.profile.horseName || 'Gale',
            avatarConfig: {
              ...cloud.profile.avatarConfig,
              skinColor: cloudMeta?.skinColor || cloud.profile.avatarConfig.skinColor || '#fcd5b5',
              eyeColor: cloudMeta?.eyeColor || cloud.profile.avatarConfig.eyeColor || '#292524',
              pantsColor: cloudMeta?.pantsColor || cloud.profile.avatarConfig.pantsColor || '#1e3a8a',
              shirtStyle: cloudMeta?.shirtStyle ?? cloud.profile.avatarConfig.shirtStyle ?? 'tunic',
              pantsStyle: cloudMeta?.pantsStyle ?? cloud.profile.avatarConfig.pantsStyle ?? 'denim',
            },
            xp: cloudMeta?.xp ?? 0,
            fun: cloudMeta?.fun ?? 25,
            bagUpgrades: cloudMeta?.bagUpgrades ?? 0,
            houseLevel: cloudMeta?.houseLevel ?? 1,
            barnLevel: cloudMeta?.barnLevel ?? 1,
            coopLevel: cloudMeta?.coopLevel ?? 1,
            hasCheeseMaker: cloudMeta?.hasCheeseMaker ?? false,
            coopIncubators: normalizeIncubatorSlots(cloudMeta?.coopLevel ?? 1, cloudMeta?.coopIncubators),
            attendedFestivalKeys: cloudMeta?.attendedFestivalKeys ?? [],
            houseLocked: cloudMeta?.houseLocked ?? false,
            barnLocked: cloudMeta?.barnLocked ?? true,
            coopLocked: cloudMeta?.coopLocked ?? true,
            stableLocked: cloudMeta?.stableLocked ?? true,
            hasPhone: cloudMeta?.hasPhone ?? false,
            lastResetHomeAt: cloudMeta?.lastResetHomeAt ?? 0,
            secretGroveUnlocked: cloudMeta?.secretGroveUnlocked ?? false,
            unlockedOutfits: cloudMeta?.unlockedOutfits ?? ['outfit_classic'],
            equippedOutfitId: cloudMeta?.equippedOutfitId ?? 'outfit_classic',
            toolShortcuts: cloudMeta?.toolShortcuts ?? [...DEFAULT_TOOL_SHORTCUTS],
            spouseId: cloudMeta?.spouseId ?? null,
            spousePlayerUid: cloudMeta?.spousePlayerUid ?? null,
            spousePlayerName: cloudMeta?.spousePlayerName ?? null,
            weddingDay: cloudMeta?.weddingDay ?? null,
          };
          setProfile(mergedProfile);
          engineRef.current?.updateAvatar(mergedProfile.avatarConfig);
        }
        if (cloud.farmSave && cloud.farmSave.version >= profile.version) {
          const p = cloud.farmSave.payload as {
            plots?: Record<string, FarmPlotState>;
            inventory?: InventorySlot[];
            fridgeItems?: InventorySlot[];
            toolboxItems?: InventorySlot[];
            animals?: AnimalState[];
            appleTree?: AppleTreeState;
            keyBindings?: KeyBindings;
            npcRels?: Record<string, NPCRelationshipState>;
            completedQuests?: string[];
            unlockedAchievements?: string[];
            stats?: GameStats;
            meta?: ProfileMetaPayload;
          };
          if (p.plots) setPlots(p.plots);
          if (p.inventory) setInventory(p.inventory);
          if (p.fridgeItems) setFridgeItems(p.fridgeItems);
          if (p.toolboxItems) setToolboxItems(p.toolboxItems);
          if (p.animals) setAnimals(p.animals);
          if (p.appleTree) setAppleTree(p.appleTree);
          if (p.keyBindings) setKeybindings(migrateKeyBindings(p.keyBindings));
          if (p.npcRels) setNpcRels(p.npcRels);
          if (p.completedQuests) setCompletedQuests(p.completedQuests);
          if (p.unlockedAchievements) setUnlockedAchievements(p.unlockedAchievements);
          if (p.stats) setStats({ ...p.stats, salesStats: p.stats.salesStats || createEmptySalesStats() });
          if (p.meta?.farmTrees && Array.isArray(p.meta.farmTrees) && p.meta.farmTrees.length > 0) {
            setFarmTrees(p.meta.farmTrees);
            engineRef.current?.regenerateFarmTrees(user.uid, p.meta.farmTrees);
          }
          if (p.meta?.equippedItemId !== undefined) setMasterHandItem(p.meta.equippedItemId);
          if (p.meta?.sleepDayOffset !== undefined) setSleepDayOffset(p.meta.sleepDayOffset);
          showToast('☁️ Farm progress loaded from Firebase Cloud Save!');
        }
      } else {
        setFirebaseEmail(null);
        setFirebaseUid(null);
      }
    });

    const onOnline = async () => {
      setIsOnline(true);
      const queued = getQueuedOfflineSync();
      const s = stateRef.current;
      if (queued && s.firebaseUid) {
        try {
          const result = await syncToFirebaseCloud(queued, {
            cropsHarvested: s.stats.cropsHarvested,
            animalsCount: s.animals.length,
            fishCaught: s.stats.fishCaught,
            achievementsCount: s.unlockedAchievements.length,
            villageReputation: Object.values(s.npcRels).reduce((acc, r) => acc + r.friendshipPoints, 0),
          });
          if (result.synced) {
            clearOfflineSyncQueue();
            setIsCloudSynced(true);
            showToast('🔄 Offline data synced to Cloud!');
          } else {
            setIsCloudSynced(false);
            showToast('⚠️ Offline progress is still queued; cloud sync needs attention.');
          }
          // Also push hardened AES-GCM offline vault for authoritative server validation
          const latestSnap = loadLocalSave();
          if (latestSnap) void syncOfflineVaultToServer(latestSnap);
        } catch (error) {
          console.error('Offline cloud sync failed; preserving queued progress:', error);
          setIsCloudSynced(false);
          showToast('⚠️ Cloud sync failed. Your offline progress remains saved.');
        }
      } else if (stateRef.current.profile.uid && !isGuestSessionRef.current) {
        const latestSnap = loadLocalSave();
        if (latestSnap) void syncOfflineVaultToServer(latestSnap);
      }
    };
    const onOffline = () => {
      setIsOnline(false);
      setIsCloudSynced(false);
      // Persist an encrypted local vault immediately when dropping offline
      const latestSnap = loadLocalSave();
      if (latestSnap && !isGuestSessionRef.current) {
        void saveEncryptedOfflineVault(latestSnap);
      }
      showToast('📴 Connection lost — Encrypted Offline Save Mode active!');
    };
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);

    return () => {
      unsubAuth();
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!started) return;
    let wakeLock: { release: () => Promise<void> } | null = null;
    let cancelled = false;
    const requestWakeLock = async () => {
      try {
        const api = (navigator as Navigator & { wakeLock?: { request: (type: 'screen') => Promise<{ release: () => Promise<void> }> } }).wakeLock;
        if (api && !cancelled && document.visibilityState === 'visible') wakeLock = await api.request('screen');
      } catch {
        // Wake Lock is optional; game state still autosaves and reconnects on resume.
      }
    };
    void requestWakeLock();
    const onVisible = () => { if (document.visibilityState === 'visible') void requestWakeLock(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      cancelled = true;
      document.removeEventListener('visibilitychange', onVisible);
      if (wakeLock) void wakeLock.release();
    };
  }, [started]);

  // Mobile browsers may suspend tabs when the screen locks. Preserve the session
  // and ask the multiplayer client to recover when the page becomes visible again.
  useEffect(() => {
    const onVisibility = () => {
      if (document.visibilityState === 'visible' && started) {
        mpRef.current?.resume();
      }
    };
    const onPageShow = () => mpRef.current?.resume();
    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('pageshow', onPageShow);
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('pageshow', onPageShow);
    };
  }, [started]);

  // === CONNECT WEBSOCKET ONCE STARTED ===
  useEffect(() => {
    if (!started) return;
    const mp = new MultiplayerClient();
    mpRef.current = mp;

    const unsubs = [
      mp.on('connected', (count) => setOnlineCount(count)),
      mp.on('nameTaken', () => showToast('Nama karakter sudah digunakan pemain lain. Silakan pilih nama berbeda.', 'multiplayer')),
      mp.on('peers', (peers) => {
        setRemotePeers(peers);
        engineRef.current?.syncRemotePlayers(peers);
      }),
      mp.on('displayNameUpdated', (uid, avatarName) => {
        setRemotePeers((prev) => {
          const next = prev.map((peer) => peer.uid === uid ? { ...peer, avatarName } : peer);
          engineRef.current?.syncRemotePlayers(next);
          return next;
        });
      }),
      mp.on('peerJoined', (p) => {
        setRemotePeers((prev) => [...prev.filter((x) => x.clientId !== p.clientId), p]);
        engineRef.current?.addOrUpdateRemotePlayer(p);
        showToast(`👋 ${p.avatarName} entered the area`, 'multiplayer');
      }),
      mp.on('peerMoved', (cid, x, y, z, yaw, anim) => {
        setRemotePeers((prev) =>
          prev.map((p) => (p.clientId === cid ? { ...p, x, y, z, yaw, animState: anim } : p))
        );
        engineRef.current?.moveRemotePlayer(cid, x, y, z, yaw, anim);
      }),
      mp.on('peerLeft', (cid) => {
        setRemotePeers((prev) => prev.filter((x) => x.clientId !== cid));
        engineRef.current?.removeRemotePlayer(cid);
      }),
      mp.on('farmPlots', (remotePlots) => {
        if (stateRef.current.visitingFarmOwnerId) {
          setPlots(remotePlots);
        }
      }),
      mp.on('plotDelta', (plot, ownerId, actorName) => {
        if (ownerId === (stateRef.current.visitingFarmOwnerId || stateRef.current.profile.uid)) {
          setPlots((prev) => ({ ...prev, [plot.id]: plot }));
          if (actorName !== stateRef.current.profile.avatarName) {
            showToast(`💧 ${actorName} helped tend the farm!`, 'multiplayer');
          }
        }
      }),
      mp.on('ownerLocks', (farmOwnerId, houseLocked, barnLocked, coopLocked, stableLocked) => {
        if (farmOwnerId === stateRef.current.visitingFarmOwnerId) {
          setVisitingLocks({ houseLocked, barnLocked, coopLocked, stableLocked });
        }
      }),
      mp.on('zoneDenied', (reason) => {
        showToast(reason, 'multiplayer');
      }),
      mp.on('npcSync', (_serverHour, npcStates) => {
        if (!stateRef.current.visitingFarmOwnerId) {
          engineRef.current?.applyServerNpcSync(npcStates);
        }
      }),
      mp.on('marketUpdated', (market, buckets) => {
        setMarketState(market);
        setTaxBuckets(buckets);
      }),
      mp.on('jobsUpdated', (jobs) => {
        setFarmJobs(jobs);
      }),
      mp.on('jobSettled', (payload) => {
        const myUid = stateRef.current.profile.uid;
        if (payload.workerUid === myUid) {
          setProfile((p) => ({
            ...p,
            gold: p.gold + payload.earnedGold,
            fun: applyProportionalJobFun(p.fun, payload.ratio).fun,
            version: p.version + 1,
          }));
          soundEngine.playCoin();
          showToast(
            `💼 Job complete (${payload.completionPercent}%)! Earned +${payload.earnedGold.toLocaleString()} G & +${payload.completionPercent}% Joy!`,
            'rewards'
          );
        } else if (payload.employerUid === myUid) {
          setProfile((p) => ({
            ...p,
            gold: Math.max(0, p.gold - payload.earnedGold),
            fun: applyProportionalJobFun(p.fun, payload.ratio).fun,
            version: p.version + 1,
          }));
          soundEngine.playHeart();
          showToast(
            `💼 ${payload.workerName} finished ${payload.completionPercent}% of your job (-${payload.earnedGold.toLocaleString()} G, +${payload.completionPercent}% Joy)!`,
            'multiplayer'
          );
        }
      }),
      mp.on('friendsUpdated', (friendList, incoming, outgoing) => {
        setFriends(friendList || []);
        setIncomingFriendRequests(incoming || []);
        setOutgoingFriendRequests(outgoing || []);
      }),
      mp.on('callError', (message) => {
        showToast(`📞 ${message}`, 'multiplayer');
      }),
      mp.on('p2pMarketUpdated', (listings) => {
        setP2pListings(listings || []);
      }),
      mp.on('p2pItemSold', (payload) => {
        if (payload.sellerCharacterId && payload.sellerCharacterId !== activeCharacterIdRef.current) return;
        setProfile((p) => ({
          ...p,
          diamond: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : (typeof payload.diamondBalance === 'number' ? payload.diamondBalance : p.diamond + payload.diamondEarned),
          version: p.version + 1,
        }));
        recordSaleStat('p2p_diamond', stateRef.current.season, payload.quantity, payload.diamondEarned);
        soundEngine.playCoin();
        showToast(
          `💎 Sold ${payload.quantity}x ${payload.itemName} to ${payload.buyerName} (+${payload.diamondEarned} 💎 net${payload.diamondTax ? ` · ${payload.diamondTax} tax` : ''})!`,
          'rewards'
        );
      }),
      mp.on('globalTreesUpdated', (trees) => {
        if (Array.isArray(trees) && trees.length > 0) {
          engineRef.current?.setGlobalTrees(trees);
        }
      }),
      mp.on('adminPlayerSync', (override) => {
        if (
          typeof override.gold === 'number' ||
          typeof override.diamond === 'number' ||
          typeof override.fun === 'number' ||
          typeof override.level === 'number' ||
          typeof override.xp === 'number'
        ) {
          setProfile((p) => ({
            ...p,
            gold: typeof override.gold === 'number' ? override.gold : p.gold,
            diamond: typeof override.diamond === 'number' ? override.diamond : p.diamond,
            fun: typeof override.fun === 'number' ? override.fun : p.fun,
            level: typeof override.level === 'number' ? override.level : p.level,
            xp: typeof override.xp === 'number' ? override.xp : p.xp,
            version: p.version + 1,
          }));
        }
        if (typeof override.stamina === 'number') {
          setStamina(Math.max(0, Math.min(maxStamina, Math.floor(override.stamina))));
        }
        if (Array.isArray(override.inventoryUpdates) && override.inventoryUpdates.length > 0) {
          setInventory((prev) => {
            const next = prev.map((sl) => ({ ...sl }));
            for (const upd of override.inventoryUpdates!) {
              if (!upd.itemId || !ITEMS[upd.itemId]) continue;
              const idx = next.findIndex((sl) => sl.itemId === upd.itemId);
              if (idx >= 0) {
                const newQty =
                  upd.mode === 'set'
                    ? Math.max(0, Math.floor(upd.quantity))
                    : Math.max(0, next[idx].quantity + Math.floor(upd.quantity));
                if (newQty <= 0) {
                  next.splice(idx, 1);
                } else {
                  next[idx].quantity = newQty;
                  if (typeof upd.diamondTradeable === 'boolean') {
                    next[idx].diamondTradeable = upd.diamondTradeable;
                  }
                }
              } else {
                const addQty = Math.max(0, Math.floor(upd.quantity));
                if (addQty > 0) {
                  next.push({
                    itemId: upd.itemId,
                    quantity: addQty,
                    diamondTradeable: Boolean(upd.diamondTradeable),
                  });
                }
              }
            }
            return next;
          });
        }
        if (override.animalHappiness) {
          const hap = override.animalHappiness;
          setAnimals((prev) =>
            prev.map((a) => {
              const nextVal = typeof hap[a.id] === 'number' ? hap[a.id] : typeof hap[a.type] === 'number' ? hap[a.type] : undefined;
              return nextVal !== undefined ? { ...a, affection: Math.max(0, Math.min(100, nextVal)) } : a;
            })
          );
        }
        if (override.salesStats) {
          setStats((st) => ({ ...st, salesStats: override.salesStats }));
        }
        if (override.theme && VALID_THEMES.includes(override.theme)) {
          setGameSettings((prev) => ({ ...prev, theme: override.theme! }));
        }
        showToast('🛠️ Live parameters updated by Developer Dashboard.');
      }),
      mp.on('guestExpired', (reason) => {
        if (isGuestSessionRef.current) {
          void handleGuestAutoLogoutRef.current?.(reason);
        }
      }),
      mp.on('runtimeConfigUpdated', (cfg, triggerAnnouncement) => {
        applyLiveRuntimeConfig(cfg, Boolean(triggerAnnouncement));
      }),
      mp.on('banUpdated', (ban) => {
        setActiveBan(ban);
        if (ban && ban.active) {
          showToast(
            stateRef.current.gameSettings.language === 'id'
              ? `⛔ Pembatasan akun aktif: ${ban.reason}`
              : `⛔ Account restriction active: ${ban.reason}`
          );
        } else {
          showToast(
            stateRef.current.gameSettings.language === 'id'
              ? '✅ Pembatasan akun telah dicabut.'
              : '✅ Account restriction lifted.'
          );
        }
      }),
      mp.on('announcementPush', (ann) => {
        if (ann && ann.enabled && ann.message) {
          setActiveAnnouncement({
            title: ann.title,
            message: ann.message,
            category: ann.category || 'update',
            durationSec: ann.durationSec || 12,
          });
          setAnnouncementNonce((n) => n + 1);
        }
      }),
      mp.on('callEnded', ({ endedByName, reason }) => {
        callManagerRef.current?.leaveCall(false);
        const isId = stateRef.current.gameSettings.language === 'id';
        const msg =
          reason === 'disconnect'
            ? isId
              ? `📵 Panggilan diakhiri karena ${endedByName} terputus.`
              : `📵 Call ended because ${endedByName} disconnected.`
            : isId
              ? `📵 ${endedByName} menutup panggilan.`
              : `📵 ${endedByName} ended the call.`;
        showToast(msg, 'multiplayer');
      }),
      mp.on('callIncomingInvite', (invite) => {
        setIncomingInvite(invite);
        soundEngine.playRing();
        showToast(`📞 Incoming ${invite.mode === 'video' ? 'Video' : 'Voice'} Call from ${invite.fromName}!`, 'multiplayer');
      }),
      mp.on('marriageProposal', (proposal) => {
        setIncomingProposal(proposal);
        soundEngine.playHeart();
      }),
      mp.on('marriageCompleted', (res) => {
        const myUid = stateRef.current.profile.uid;
        if (!res.accepted) {
          showToast(`💔 ${res.byName || 'Player'} declined your marriage proposal.`);
          return;
        }
        const a = res.partnerA;
        const b = res.partnerB;
        if (!a || !b) return;
        const spouse = a.uid === myUid ? b : b.uid === myUid ? a : null;
        if (spouse) {
          if (a.uid === myUid && res.itemId) {
            consumeInventoryItem(res.itemId, 1);
          }
          setProfile((p) => ({
            ...p,
            spousePlayerUid: spouse.uid,
            spousePlayerName: spouse.name,
            weddingDay: `${stateRef.current.season} ${stateRef.current.day}`,
          }));
          unlockAchievement('ach_true_love');
          soundEngine.playHeart();
          showToast(`💍 Congratulations! You are officially married to ${spouse.name}!`);
        }
      }),
      mp.on('chatHistory', (hist) => setChatMessages(hist)),
      mp.on('chat', (msg) => {
        setChatMessages((prev) => [...prev.slice(-49), msg]);
        // Push head-tracked floating speech bubble (Global = visible to all; Private = sender & target only)
        setChatBubbles((prev) => [
          ...prev.filter((b) => b.senderId !== msg.senderId),
          {
            id: msg.id,
            senderId: msg.senderId,
            senderUid: msg.senderId,
            senderName: msg.senderName,
            text: msg.text,
            channel: msg.channel,
            targetId: msg.targetId,
            isPrivate: msg.channel === 'private',
            expiresAt: Date.now() + 7000,
          },
        ]);
        if (msg.channel === 'private' && msg.targetId === stateRef.current.profile.uid && msg.senderId !== stateRef.current.profile.uid) {
          showToast(`💬 Private from ${msg.senderName}: ${msg.text}`, 'multiplayer');
        }
      }),
    ];

    const callManager = new CallManager(mp, stateRef.current.profile.uid);
    callManager.setVideoConfig(stateRef.current.liveRuntimeConfig.videoCallConfig);
    callManagerRef.current = callManager;
    const unsubCall = callManager.subscribe((snap) => setCallState(snap));

    let cancelled = false;
    const resolveAuthForMultiplayer = async (): Promise<{ uid: string; idToken: string }> => {
      const socialTok = getActiveSocialToken();
      const socialAcc = getActiveSocialAccount();
      if (socialTok && socialAcc && !isGuestSessionRef.current) {
        return { uid: socialAcc.uid, idToken: socialTok };
      }
      return getMultiplayerAuth();
    };
    void resolveAuthForMultiplayer().then(({ uid }) => {
      if (cancelled) return;
      // Use the verified social or Firebase identity that the server will independently verify.
      setProfile((current) => ({ ...current, uid }));
      if (!isGuestSessionRef.current) {
        setFirebaseUid(uid);
      }
      callManager.setLocalUid(uid);
      engineRef.current?.setLocalIdentity(uid, stateRef.current.profile.avatarName);
      engineRef.current?.regenerateFarmTrees(uid, stateRef.current.farmTrees);
      mp.connect({
        uid,
        avatarName: profile.avatarName,
        farmName: profile.farmName,
        zone,
        farmOwnerId: uid,
        x: FARMHOUSE_OUTDOOR_SPAWN.x,
        y: 0,
        z: FARMHOUSE_OUTDOOR_SPAWN.z,
        yaw: Math.PI,
        avatarConfig: profile.avatarConfig,
        level: profile.level,
        houseLocked: profile.houseLocked,
        barnLocked: profile.barnLocked,
        coopLocked: profile.coopLocked,
        stableLocked: profile.stableLocked ?? true,
        spousePlayerName: profile.spousePlayerName,
      }, async () => (await resolveAuthForMultiplayer()).idToken);
      mp.syncPlots(uid, plots);
      mp.syncPlayerSnapshot({
        avatarName: profile.avatarName,
        farmName: profile.farmName,
        gold: profile.gold,
        diamond: profile.diamond,
        level: profile.level,
        xp: profile.xp,
        fun: profile.fun,
        theme: stateRef.current.gameSettings.theme || DEFAULT_GLOBAL_THEME,
        inventorySummary: inventory.map((sl) => ({
          itemId: sl.itemId,
          quantity: sl.quantity,
          diamondTradeable: sl.diamondTradeable,
        })),
        animalsCount: animals.length,
        animals: animals.map((a) => ({
          id: a.id,
          type: a.type,
          name: a.name,
          affection: a.affection,
          fedToday: a.fedToday,
          brushedToday: a.brushedToday,
          birthday: a.birthday,
        })),
        salesStats: stateRef.current.stats.salesStats || createEmptySalesStats(),
        farmTreesCount: stateRef.current.farmTrees.filter((tr) => !tr.chopped).length,
        cropsCount: Object.values(plots).filter((pl) => Boolean(pl.cropId)).length,
        hasPhone: Boolean(profile.hasPhone),
        loginType: firebaseEmail ? 'google' : 'guest',
      });
      fetchOpenFarmJobs().then((jobs) => setFarmJobs(jobs));
      fetchP2PMarketListings().then((list) => setP2pListings(list));
      fetchOnlinePlayers().then((players) => setAllOnlinePlayers(players));
      fetchGlobalTrees().then((trees) => {
        if (trees.length > 0) engineRef.current?.setGlobalTrees(trees);
      });
    }).catch((error) => {
      console.error('Unable to establish secure multiplayer identity:', error);
      showToast('Multiplayer unavailable: sign-in could not be verified. Your local game remains available.');
    });

    return () => {
      cancelled = true;
      unsubCall();
      callManager.dispose();
      callManagerRef.current = null;
      setCallState(EMPTY_CALL_SNAPSHOT);
      setIncomingInvite(null);
      unsubs.forEach((u) => u());
      mp.disconnect();
      mpRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [started]);

  // === SYNCHRONIZED GAME CLOCK (with real-time Developer Dashboard World Time & Weather Override) ===
  useEffect(() => {
    if (!started) return;
    const syncClock = () => {
      const wt = stateRef.current.liveRuntimeConfig.worldTimeOverride;
      if (wt?.weatherOverride) {
        setWeather(wt.weatherOverride);
      }
      if (wt?.enabled) {
        if (!wt.timePaused) {
          // Advance smoothly by timeScale relative to 5s tick (1 real min = ~2 in-game min at 1x)
          const stepMin = Math.max(0, Math.round((wt.timeScale || 1) * 1));
          setMinute((prevMin) => {
            const totalMin = prevMin + stepMin;
            if (totalMin >= 60) {
              setHour((prevH) => (prevH + Math.floor(totalMin / 60)) % 24);
              return totalMin % 60;
            }
            return totalMin;
          });
        }
        return;
      }
      const clk = getSynchronizedWorldClock(stateRef.current.sleepDayOffset);
      setHour(clk.hour);
      setMinute(clk.minute);
      const dayKey = `${clk.year}-${clk.season}-${clk.day}`;
      if (dayKey !== lastClockDayKeyRef.current) {
        lastClockDayKeyRef.current = dayKey;
        applyNewDayProgression(clk.year, clk.season, clk.day, false);
      }
    };
    syncClock();
    const id = window.setInterval(syncClock, 5000);
    return () => clearInterval(id);
  }, [started, applyNewDayProgression]);

  // === EPHEMERAL GUEST SESSION AUTO-LOGOUT TIMER (DEFAULT 1 HOUR, CONFIGURABLE VIA DEV DASHBOARD) ===
  const handleGuestAutoLogoutRef = useRef<((reason?: string) => Promise<void>) | null>(null);
  const handleGuestAutoLogout = useCallback(async (reason?: string) => {
    callManagerRef.current?.dispose();
    callManagerRef.current = null;
    setCallState(EMPTY_CALL_SNAPSHOT);
    setIncomingInvite(null);
    mpRef.current?.disconnect();
    mpRef.current = null;
    clearLocalSave();
    await signOutPlayer().catch(() => {});
    setIsGuestSession(false);
    setGuestStartedAt(null);
    setGuestRemainingSec(null);
    guestWarnedRef.current = false;
    setActiveCharacterId(null);
    setVisitingFarmOwnerId(null);
    setVisitingFarmName(null);
    setSettingsOpen(false);
    setBukuTab(null);
    setShowInventory(false);
    setShowChat(false);
    setNpcDialogState(null);
    setActiveFacilityModal(null);
    setDoorPrompt(null);
    if (engineRef.current) {
      engineRef.current.isTitleMode = true;
    }
    setStarted(false);
    const isId = stateRef.current.gameSettings.language === 'id';
    showToast(
      reason ||
        (isId
          ? '⏳ Sesi Guest sementara telah berakhir dan data dihapus. Masuk dengan Sosial Media untuk menyimpan permanen.'
          : '⏳ Temporary Guest session expired and data was cleared. Sign in with Social Media to save permanently.')
    );
  }, [showToast]);
  handleGuestAutoLogoutRef.current = handleGuestAutoLogout;

  useEffect(() => {
    if (!started || !isGuestSession || !guestStartedAt) {
      setGuestRemainingSec(null);
      return;
    }
    const tick = () => {
      const cfg = stateRef.current.liveRuntimeConfig.guestSessionConfig;
      const limitSec = Math.max(60, Math.round((cfg?.durationMinutes ?? 60) * 60));
      const warnSec = Math.max(30, Math.round((cfg?.warningBeforeMinutes ?? 5) * 60));
      const elapsedSec = Math.floor((Date.now() - guestStartedAt) / 1000);
      const remaining = Math.max(0, limitSec - elapsedSec);
      setGuestRemainingSec(remaining);
      if (remaining <= warnSec && remaining > 0 && !guestWarnedRef.current) {
        guestWarnedRef.current = true;
        const minsLeft = Math.max(1, Math.ceil(remaining / 60));
        const isId = stateRef.current.gameSettings.language === 'id';
        showToast(
          isId
            ? `⏳ Sesi Guest akan berakhir dalam ${minsLeft} menit!`
            : `⏳ Guest session expires in ${minsLeft} minute(s)!`
        );
      }
      if (remaining <= 0) {
        void handleGuestAutoLogout();
      }
    };
    tick();
    const id = window.setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [started, isGuestSession, guestStartedAt, handleGuestAutoLogout, showToast]);

  // === PERIODIC LOCAL + FIREBASE CLOUD + NAKAMA CHARACTER ROSTER SAVE (12s) ===
  useEffect(() => {
    if (!started) return;
    const id = window.setInterval(() => {
      const s = stateRef.current;
      const guestActive = isGuestSessionRef.current;
      const snap = buildLocalSnapshot();
      // Ephemeral Guest sessions MUST NOT persist to localStorage or Cloud Save
      if (!guestActive) {
        saveLocalSnapshot(snap);
      }

      const rep = Object.values(s.npcRels).reduce((acc, r) => acc + r.friendshipPoints, 0);
      submitServerLeaderboard({
        uid: s.profile.uid,
        avatarName: s.profile.avatarName,
        farmName: s.profile.farmName,
        totalWealth: s.profile.gold + s.profile.diamond * 50,
        farmingLevel: s.profile.level,
        cropsHarvested: stats.cropsHarvested,
        animalsCount: s.animals.length,
        fishCaught: stats.fishCaught,
        achievementsCount: unlockedAchievements.length,
        villageReputation: rep,
      });

      mpRef.current?.syncPlayerSnapshot({
        avatarName: s.profile.avatarName,
        farmName: s.profile.farmName,
        gold: s.profile.gold,
        diamond: s.profile.diamond,
        level: s.profile.level,
        xp: s.profile.xp,
        fun: s.profile.fun,
        theme: s.gameSettings.theme || DEFAULT_GLOBAL_THEME,
        inventorySummary: s.inventory.map((sl) => ({
          itemId: sl.itemId,
          quantity: sl.quantity,
          diamondTradeable: sl.diamondTradeable,
        })),
        animalsCount: s.animals.length,
        animals: s.animals.map((a) => ({
          id: a.id,
          type: a.type,
          name: a.name,
          affection: a.affection,
          fedToday: a.fedToday,
          brushedToday: a.brushedToday,
          birthday: a.birthday,
        })),
        salesStats: s.stats.salesStats || createEmptySalesStats(),
        farmTreesCount: s.farmTrees.filter((tr) => !tr.chopped).length,
        cropsCount: Object.values(s.plots).filter((pl) => Boolean(pl.cropId)).length,
        hasPhone: Boolean(s.profile.hasPhone),
        loginType: guestActive ? 'guest' : socialAccountRef.current?.isDeveloper ? 'dev' : 'google',
      });
      fetchOnlinePlayers().then((players) => setAllOnlinePlayers(players));

      if (!guestActive && activeCharacterIdRef.current && socialAccountRef.current) {
        void saveCharacterToRoster(activeCharacterIdRef.current, {
          avatarName: s.profile.avatarName,
          farmName: s.profile.farmName,
          level: s.profile.level,
          gold: s.profile.gold,
          diamond: s.profile.diamond,
          season: s.season,
          day: s.day,
          year: s.year,
          avatarConfig: s.profile.avatarConfig,
          savePayload: snap.payload,
        });
      }

      if (!guestActive && firebaseUid) {
        syncToFirebaseCloud(snap, {
          cropsHarvested: stats.cropsHarvested,
          animalsCount: s.animals.length,
          fishCaught: stats.fishCaught,
          achievementsCount: unlockedAchievements.length,
          villageReputation: rep,
        })
          .then((res) => setIsCloudSynced(res.synced))
          .catch(() => setIsCloudSynced(false));
      }
    }, 12000);
    return () => clearInterval(id);
  }, [started, firebaseUid, unlockedAchievements, stats, buildLocalSnapshot]);

  // === KEYBOARD SHORTCUTS (M/N/Escape; Inventory, Chat, Jump & 1-6 handled via GameEngine keyBindings) ===
  useEffect(() => {
    if (!started) return;
    const onKey = (e: KeyboardEvent) => {
      const tag = (document.activeElement?.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
      if (e.code === 'KeyM') {
        setSettingsOpen(false);
        setBukuTab((t) => (t === 'calendar' ? null : 'calendar'));
      } else if (e.code === 'KeyN') {
        setSettingsOpen(false);
        setBukuTab((t) => (t === 'npcs' ? null : 'npcs'));
      } else if (e.code === 'Escape') {
        if (incomingProposal) setIncomingProposal(null);
        else if (activeFacilityModal) setActiveFacilityModal(null);
        else if (doorPrompt) setDoorPrompt(null);
        else if (showInventory) setShowInventory(false);
        else if (npcChoicePopover) setNpcChoicePopover(null);
        else if (npcDialogState) setNpcDialogState(null);
        else if (fishingBar?.active) cancelInWorldFishing();
        else if (showChat) setShowChat(false);
        else if (bukuTab) setBukuTab(null);
        else setSettingsOpen((v) => !v);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [started, incomingProposal, activeFacilityModal, doorPrompt, showInventory, npcChoicePopover, npcDialogState, fishingBar, cancelInWorldFishing, showChat, bukuTab]);

  const handleRenameDisplayName = async (nextName: string): Promise<void> => {
    if (!activeCharacterId || !socialAccount || isGuestSession) {
      showToast(lang === 'id' ? 'Login diperlukan untuk mengganti nama.' : 'Sign in is required to change your name.');
      return;
    }
    const result = await renameCharacterOnRoster(activeCharacterId, nextName);
    setProfile((prev) => ({ ...prev, avatarName: result.character.avatarName, diamond: result.character.diamond, version: prev.version + 1 }));
    setCharacterRoster((prev) => prev.map((entry) => entry.characterId === result.character.characterId ? result.character : entry));
    engineRef.current?.setLocalIdentity(profile.uid, result.character.avatarName);
    showToast(lang === 'id' ? `Nama berhasil diganti. Biaya ${result.chargedDiamond} 💎.` : `Display Name updated. Cost: ${result.chargedDiamond} 💎.`);
  };

  // === START / CHARACTER CREATION & EPHEMERAL GUEST QUICK PLAY ===
  const handleStartGame = (data: {
    isNewGame: boolean;
    avatarName: string;
    farmName: string;
    birthday: string;
    dogName: string;
    horseName: string;
    avatarConfig: AvatarConfig;
    overrideUid?: string;
    isGuestQuickPlay?: boolean;
    characterId?: string;
  }) => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
    const isGuest = Boolean(data.isGuestQuickPlay);
    const uid = data.overrideUid || socialAccountRef.current?.uid || firebaseUid || profile.uid;
    markLoginSessionType(isGuest ? 'guest' : 'social');
    setIsGuestSession(isGuest);
    if (isGuest) {
      clearLocalSave();
      setGuestStartedAt(Date.now());
      guestWarnedRef.current = false;
      setActiveCharacterId(null);
      void signInAsEphemeralGuest().catch(() => {});
    } else {
      setGuestStartedAt(null);
      setGuestRemainingSec(null);
      guestWarnedRef.current = false;
      if (data.characterId) {
        setActiveCharacterId(data.characterId);
      }
    }

    const rt = stateRef.current.liveRuntimeConfig;
    const isDebug = rt.debugMode ?? DEVELOPER_DEBUG_MODE;
    if (data.isNewGame) {
      const freshClock = getSynchronizedWorldClock(0);
      const freshDayKey = `${freshClock.year}-${freshClock.season}-${freshClock.day}`;
      const freshProfile: PlayerProfile = {
        uid,
        avatarName: data.avatarName,
        farmName: data.farmName,
        gender: data.avatarConfig.gender,
        birthday: data.birthday,
        dogName: data.dogName || 'Bobi',
        horseName: data.horseName || 'Gale',
        avatarConfig: data.avatarConfig,
        level: 1,
        xp: 0,
        fun: 25,
        gold: isDebug ? DEBUG_UNLIMITED_CURRENCY : rt.normalStarterGold,
        diamond: isDebug ? DEBUG_UNLIMITED_CURRENCY : rt.normalStarterDiamond,
        bagUpgrades: 0,
        houseLevel: 1,
        barnLevel: 1,
        coopLevel: 1,
        hasCheeseMaker: false,
        coopIncubators: normalizeIncubatorSlots(1),
        attendedFestivalKeys: [],
        houseLocked: false,
        barnLocked: true,
        coopLocked: true,
        stableLocked: true,
        hasPhone: false,
        lastResetHomeAt: 0,
        barnBuilt: true,
        coopBuilt: true,
        secretGroveUnlocked: false,
        unlockedOutfits: ['outfit_classic'],
        equippedOutfitId: 'outfit_classic',
        toolShortcuts: [...DEFAULT_TOOL_SHORTCUTS],
        spouseId: null,
        spousePlayerUid: null,
        spousePlayerName: null,
        weddingDay: null,
        version: 1,
      };
      setProfile(freshProfile);
      setSleepDayOffset(0);
      setSeason(rt.worldTimeOverride?.enabled ? rt.worldTimeOverride.season : freshClock.season);
      setDay(rt.worldTimeOverride?.enabled ? rt.worldTimeOverride.day : freshClock.day);
      setYear(rt.worldTimeOverride?.enabled ? rt.worldTimeOverride.year : freshClock.year);
      setHour(rt.worldTimeOverride?.enabled ? rt.worldTimeOverride.hour : freshClock.hour);
      setMinute(rt.worldTimeOverride?.enabled ? rt.worldTimeOverride.minute : freshClock.minute);
      setWeather(rt.worldTimeOverride?.weatherOverride || rt.defaultWeather || DEFAULT_WEATHER);
      lastClockDayKeyRef.current = freshDayKey;
      const freshTracker = createEmptyDailyFunTracker(freshDayKey);
      stateRef.current.dailyFunTracker = freshTracker;
      setDailyFunTracker(freshTracker);
      const freshPlots = createInitialPlots();
      const freshFarmSeed = `${uid}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const freshFarmTrees = generateUserFarmTrees(freshFarmSeed);
      const freshStats: GameStats = {
        cropsPlanted: 0,
        cropsWatered: 0,
        cropsHarvested: 0,
        fishCaught: 0,
        materialsGathered: 0,
        totalGoldEarned: 0,
        giftsGiven: 0,
        festivalsAttended: 0,
        salesStats: createEmptySalesStats(),
      };
      stateRef.current.farmTrees = freshFarmTrees;
      stateRef.current.plots = freshPlots;
      stateRef.current.stats = freshStats;
      setPlots(freshPlots);
      setFarmTrees(freshFarmTrees);
      setStats(freshStats);
      setInventory(INITIAL_INVENTORY);
      setFridgeItems([]);
      setToolboxItems([]);
      const freshAppleTree: AppleTreeState = {
        applesReady: freshClock.season === 'Summer' || freshClock.season === 'Autumn' ? 3 : 0,
        lastAppleDay: freshClock.day,
        honeyReady: freshClock.season === 'Spring',
        lastHoneyDay: freshClock.day,
      };
      setAppleTree(freshAppleTree);
      setEquippedItemId(null);
      setAnimals([]);
      const freshNpcRels = createInitialNpcRelationships();
      setNpcRels(freshNpcRels);
      setCompletedQuests([]);
      setUnlockedAchievements([]);
      setTutorialStep(isGuest ? -1 : 0);

      // Register newly created character on Nakama Social Roster (non-guest only)
      if (!isGuest && socialAccountRef.current && !data.characterId) {
        void createCharacterOnRoster({
          avatarName: freshProfile.avatarName,
          farmName: freshProfile.farmName,
          gender: freshProfile.gender,
          birthday: freshProfile.birthday,
          dogName: freshProfile.dogName,
          horseName: freshProfile.horseName,
          avatarConfig: freshProfile.avatarConfig,
        })
          .then((res) => {
            setActiveCharacterId(res.character.characterId);
            setCharacterRoster(res.characters);
          })
          .catch(() => {});
      }

      if (!isGuest) {
        saveLocalSnapshot({
          profile: freshProfile,
          season: freshClock.season,
          day: freshClock.day,
          year: freshClock.year,
          payload: {
            plots: freshPlots,
            inventory: INITIAL_INVENTORY,
            fridgeItems: [],
            toolboxItems: [],
            animals: [],
            appleTree: freshAppleTree,
            keyBindings: keybindings,
            npcRels: freshNpcRels,
            completedQuests: [],
            unlockedAchievements: [],
            stats: freshStats,
            meta: {
              dogName: freshProfile.dogName,
              horseName: freshProfile.horseName,
              farmTrees: freshFarmTrees,
              theme: gameSettings.theme,
            },
          },
          dirtyProfile: true,
          dirtyFarm: true,
          queuedAt: Date.now(),
        });
      }

      engineRef.current?.setCreationPreviewMode(false);
      engineRef.current?.setLocalIdentity(uid, data.avatarName);
      engineRef.current?.regenerateFarmTrees(freshFarmSeed, freshFarmTrees);
      engineRef.current?.syncFarmPlots(freshPlots);
      engineRef.current?.updateAvatar(data.avatarConfig, undefined);
      engineRef.current?.enterZone('farm_home', FARMHOUSE_OUTDOOR_SPAWN.x, FARMHOUSE_OUTDOOR_SPAWN.z);
    } else {
      setProfile((p) => ({ ...p, uid }));
      setTutorialStep(-1);
      const activeToolId = equippedItemId;
      engineRef.current?.setCreationPreviewMode(false);
      engineRef.current?.setLocalIdentity(uid, data.avatarName);
      engineRef.current?.regenerateFarmTrees(uid, stateRef.current.farmTrees);
      engineRef.current?.syncFarmPlots(stateRef.current.plots);
      engineRef.current?.updateAvatar(data.avatarConfig, activeToolId ? ITEMS[activeToolId]?.toolKind : undefined);
      engineRef.current?.enterZone('farm_home', FARMHOUSE_OUTDOOR_SPAWN.x, FARMHOUSE_OUTDOOR_SPAWN.z);
    }

    setZone('farm_home');
    setSettingsOpen(false);
    if (engineRef.current) {
      engineRef.current.isTitleMode = false;
      engineRef.current.setPovMode(gameSettings.povMode || 'lock');
    }
    setStarted(true);
    soundEngine.startBackgroundMusic(season);
    soundEngine.playDoor();
  };

  const handleGuestQuickPlay = () => {
    const guestIdentity = createGuestRandomizedIdentity();
    handleStartGame({
      isNewGame: true,
      isGuestQuickPlay: true,
      overrideUid: guestIdentity.deviceId,
      avatarName: guestIdentity.avatarName,
      farmName: guestIdentity.farmName,
      birthday: guestIdentity.birthday,
      dogName: guestIdentity.dogName,
      horseName: guestIdentity.horseName,
      avatarConfig: guestIdentity.avatarConfig,
    });
  };

  // === NAKAMA SOCIAL AUTH (GOOGLE / STEAM / APPLE) & CHARACTER ROSTER ===
  const handleSignInSocialProvider = async (provider: SocialProviderId) => {
    if (provider === 'steam') {
      steamAuthCleanupRef.current?.();
      steamAuthCleanupRef.current = listenForSteamSocialAuth(
        (res) => {
          setSocialAccount(res.account);
          setCharacterRoster(res.characters);
          setIsGuestSession(false);
          setGuestStartedAt(null);
          setGuestRemainingSec(null);
          showToast(
            lang === 'id'
              ? `🎮 Masuk via Steam (${res.account.displayName}). Pilih atau buat karakter!`
              : `🎮 Signed in via Steam (${res.account.displayName}). Select or create a character!`
          );
        },
        (errMsg) => {
          showToast(`⚠️ ${errMsg}`);
        }
      );
      return;
    }

    const res = await authenticateWithFirebaseSocial(provider);
    setSocialAccount(res.account);
    setCharacterRoster(res.characters);
    setIsGuestSession(false);
    setGuestStartedAt(null);
    setGuestRemainingSec(null);
    showToast(
      lang === 'id'
        ? `✅ Masuk via ${provider.toUpperCase()} (${res.account.displayName}).`
        : `✅ Signed in via ${provider.toUpperCase()} (${res.account.displayName}).`
    );
  };

  const handleSelectCharacter = (char: CharacterRosterEntry) => {
    if (char.deletionExecuteAt && char.deletionExecuteAt > Date.now()) {
      showToast(
        lang === 'id'
          ? 'Karakter sedang dalam jadwal hapus 3 hari. Batalkan penghapusan dulu untuk bermain.'
          : 'Character is scheduled for deletion. Cancel deletion first to play.'
      );
      return;
    }
    const uid = socialAccountRef.current?.uid || firebaseUid || profile.uid;
    const saved = (char.savePayload || {}) as {
      plots?: Record<string, FarmPlotState>;
      inventory?: InventorySlot[];
      fridgeItems?: InventorySlot[];
      toolboxItems?: InventorySlot[];
      animals?: AnimalState[];
      appleTree?: AppleTreeState;
      npcRels?: Record<string, NPCRelationshipState>;
      completedQuests?: string[];
      unlockedAchievements?: string[];
      stats?: GameStats;
      meta?: ProfileMetaPayload;
    };

    const hydratedProfile: PlayerProfile = {
      ...profile,
      uid,
      avatarName: char.avatarName,
      farmName: char.farmName,
      gender: char.gender,
      birthday: char.birthday,
      dogName: char.dogName || 'Biscuit',
      horseName: char.horseName || 'Maple',
      avatarConfig: char.avatarConfig,
      level: char.level || 1,
      gold: char.gold,
      diamond: char.diamond,
      xp: saved.meta?.xp ?? 0,
      fun: saved.meta?.fun ?? 25,
      bagUpgrades: saved.meta?.bagUpgrades ?? 0,
      houseLevel: saved.meta?.houseLevel ?? 1,
      barnLevel: saved.meta?.barnLevel ?? 1,
      coopLevel: saved.meta?.coopLevel ?? 1,
      hasCheeseMaker: saved.meta?.hasCheeseMaker ?? false,
      coopIncubators: normalizeIncubatorSlots(saved.meta?.coopLevel ?? 1, saved.meta?.coopIncubators),
      attendedFestivalKeys: saved.meta?.attendedFestivalKeys ?? [],
      houseLocked: saved.meta?.houseLocked ?? false,
      barnLocked: saved.meta?.barnLocked ?? true,
      coopLocked: saved.meta?.coopLocked ?? true,
      stableLocked: saved.meta?.stableLocked ?? true,
      hasPhone: saved.meta?.hasPhone ?? false,
      secretGroveUnlocked: saved.meta?.secretGroveUnlocked ?? false,
      unlockedOutfits: saved.meta?.unlockedOutfits ?? ['outfit_classic'],
      equippedOutfitId: saved.meta?.equippedOutfitId ?? 'outfit_classic',
      toolShortcuts: saved.meta?.toolShortcuts ?? [...DEFAULT_TOOL_SHORTCUTS],
      spouseId: saved.meta?.spouseId ?? null,
      spousePlayerUid: saved.meta?.spousePlayerUid ?? null,
      spousePlayerName: saved.meta?.spousePlayerName ?? null,
      weddingDay: saved.meta?.weddingDay ?? null,
      version: Math.max(1, profile.version + 1),
    };
    setProfile(hydratedProfile);
    if (saved.plots) {
      stateRef.current.plots = saved.plots;
      setPlots(saved.plots);
    }
    if (saved.inventory) setInventory(saved.inventory);
    if (saved.fridgeItems) setFridgeItems(saved.fridgeItems);
    if (saved.toolboxItems) setToolboxItems(saved.toolboxItems);
    if (saved.animals) setAnimals(saved.animals);
    if (saved.appleTree) setAppleTree(saved.appleTree);
    if (saved.npcRels) setNpcRels(saved.npcRels);
    if (saved.completedQuests) setCompletedQuests(saved.completedQuests);
    if (saved.unlockedAchievements) setUnlockedAchievements(saved.unlockedAchievements);
    if (saved.stats) setStats({ ...saved.stats, salesStats: saved.stats.salesStats || createEmptySalesStats() });
    if (saved.meta?.farmTrees && saved.meta.farmTrees.length > 0) {
      stateRef.current.farmTrees = saved.meta.farmTrees;
      setFarmTrees(saved.meta.farmTrees);
    }
    const wt = stateRef.current.liveRuntimeConfig.worldTimeOverride;
    setSeason(wt?.enabled ? wt.season : char.season || 'Spring');
    setDay(wt?.enabled ? wt.day : char.day || 1);
    setYear(wt?.enabled ? wt.year : char.year || 1);

    handleStartGame({
      isNewGame: false,
      isGuestQuickPlay: false,
      characterId: char.characterId,
      overrideUid: uid,
      avatarName: char.avatarName,
      farmName: char.farmName,
      birthday: char.birthday,
      dogName: char.dogName || 'Biscuit',
      horseName: char.horseName || 'Maple',
      avatarConfig: char.avatarConfig,
    });
  };

  const handleScheduleDeleteCharacter = async (characterId: string) => {
    const res = await scheduleCharacterDeletion(characterId);
    setCharacterRoster(res.characters);
    showToast(
      lang === 'id'
        ? `⏳ Karakter dijadwalkan terhapus dalam ${res.graceDays} hari. Anda bisa membatalkannya kapan saja sebelum waktu habis.`
        : `⏳ Character scheduled for permanent deletion in ${res.graceDays} days. You can cancel anytime before then.`
    );
  };

  const handleCancelDeleteCharacter = async (characterId: string) => {
    const res = await cancelCharacterDeletion(characterId);
    setCharacterRoster(res.characters);
    showToast(
      lang === 'id'
        ? '✅ Penghapusan karakter berhasil dibatalkan!'
        : '✅ Character deletion cancelled!'
    );
  };

  // === EXIT GAME TO TITLE SCREEN ===
  const handleExitGame = () => {
    const guestActive = isGuestSessionRef.current;
    if (!guestActive) {
      const snap = buildLocalSnapshot();
      saveLocalSnapshot(snap);
      if (activeCharacterIdRef.current && socialAccountRef.current) {
        const s = stateRef.current;
        void saveCharacterToRoster(activeCharacterIdRef.current, {
          avatarName: s.profile.avatarName,
          farmName: s.profile.farmName,
          level: s.profile.level,
          gold: s.profile.gold,
          diamond: s.profile.diamond,
          season: s.season,
          day: s.day,
          year: s.year,
          avatarConfig: s.profile.avatarConfig,
          savePayload: snap.payload,
        }).then((updated) => {
          if (updated) {
            setCharacterRoster((prev) => prev.map((c) => (c.characterId === updated.characterId ? updated : c)));
          }
        });
      }
      if (firebaseUid) {
        const rep = Object.values(stateRef.current.npcRels).reduce((acc, r) => acc + r.friendshipPoints, 0);
        syncToFirebaseCloud(snap, {
          cropsHarvested: stats.cropsHarvested,
          animalsCount: animals.length,
          fishCaught: stats.fishCaught,
          achievementsCount: unlockedAchievements.length,
          villageReputation: rep,
        }).catch(() => {});
      }
    } else {
      clearLocalSave();
      void signOutPlayer().catch(() => {});
      setIsGuestSession(false);
      setGuestStartedAt(null);
      setGuestRemainingSec(null);
    }
    callManagerRef.current?.dispose();
    callManagerRef.current = null;
    setCallState(EMPTY_CALL_SNAPSHOT);
    setIncomingInvite(null);
    mpRef.current?.disconnect();
    mpRef.current = null;
    setVisitingFarmOwnerId(null);
    setVisitingFarmName(null);
    setSettingsOpen(false);
    setBukuTab(null);
    setShowInventory(false);
    setShowChat(false);
    setNpcDialogState(null);
    setActiveFacilityModal(null);
    setDoorPrompt(null);
    cancelInWorldFishing();
    setNpcChoicePopover(null);
    setIncomingProposal(null);
    if (engineRef.current) {
      engineRef.current.isTitleMode = true;
    }
    setStarted(false);
    soundEngine.playDoor();
    showToast(
      guestActive
        ? lang === 'id'
          ? '⏳ Sesi Guest sementara diakhiri dan data dibersihkan.'
          : '⏳ Temporary Guest session ended and data cleared.'
        : '💾 Progress saved. Returned to Title Screen.'
    );
  };

  // === SIGN OUT (LOGOUT) ===
  const handleLogout = async () => {
    const guestActive = isGuestSessionRef.current;
    if (started && !guestActive) {
      const snap = buildLocalSnapshot();
      saveLocalSnapshot(snap);
      if (activeCharacterIdRef.current && socialAccountRef.current) {
        const s = stateRef.current;
        await saveCharacterToRoster(activeCharacterIdRef.current, {
          avatarName: s.profile.avatarName,
          farmName: s.profile.farmName,
          level: s.profile.level,
          gold: s.profile.gold,
          diamond: s.profile.diamond,
          season: s.season,
          day: s.day,
          year: s.year,
          avatarConfig: s.profile.avatarConfig,
          savePayload: snap.payload,
        });
      }
      if (firebaseUid) {
        const rep = Object.values(stateRef.current.npcRels).reduce((acc, r) => acc + r.friendshipPoints, 0);
        await syncToFirebaseCloud(snap, {
          cropsHarvested: stats.cropsHarvested,
          animalsCount: animals.length,
          fishCaught: stats.fishCaught,
          achievementsCount: unlockedAchievements.length,
          villageReputation: rep,
        }).catch(() => {});
      }
    }
    callManagerRef.current?.dispose();
    callManagerRef.current = null;
    setCallState(EMPTY_CALL_SNAPSHOT);
    setIncomingInvite(null);
    mpRef.current?.disconnect();
    mpRef.current = null;
    await signOutNakamaSocial();
    clearLocalSave();
    setSocialAccount(null);
    setCharacterRoster([]);
    setActiveCharacterId(null);
    setIsGuestSession(false);
    setGuestStartedAt(null);
    setGuestRemainingSec(null);
    setIsSleeping(false);
    engineRef.current?.setPlayerSleeping(false);
    setFirebaseEmail(null);
    setFirebaseUid(null);
    setVisitingFarmOwnerId(null);
    setVisitingFarmName(null);
    setSettingsOpen(false);
    setBukuTab(null);
    setShowInventory(false);
    setShowChat(false);
    setNpcDialogState(null);
    setActiveFacilityModal(null);
    setDoorPrompt(null);
    cancelInWorldFishing();
    setNpcChoicePopover(null);
    setIncomingProposal(null);
    if (engineRef.current) {
      engineRef.current.isTitleMode = true;
    }
    setStarted(false);
    soundEngine.playUiClick();
    showToast(lang === 'id' ? '👋 Berhasil keluar dari akun.' : '👋 Signed out successfully.');
  };

  const handleSwitchAccount = async () => {
    await handleLogout();
    clearLocalSave();
    showToast(lang === 'id' ? '🔄 Sesi dibersihkan. Silakan pilih atau masuk ke akun lain.' : '🔄 Session cleared. Please sign in or choose another account.');
  };

  // === HARDENED PERMANENT ACCOUNT DELETION ===
  const handleDeleteAccount = async (confirmEmail: string) => {
    callManagerRef.current?.dispose();
    callManagerRef.current = null;
    setCallState(EMPTY_CALL_SNAPSHOT);
    setIncomingInvite(null);
    mpRef.current?.disconnect();
    mpRef.current = null;

    await reauthenticateAndDeleteAccount(confirmEmail);
    clearLocalSave();

    const freshSeed = `guest_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const freshTrees = generateUserFarmTrees(freshSeed);
    const freshPlots = createInitialPlots();
    const freshStats: GameStats = {
      cropsPlanted: 0,
      cropsWatered: 0,
      cropsHarvested: 0,
      fishCaught: 0,
      materialsGathered: 0,
      totalGoldEarned: 0,
      giftsGiven: 0,
      festivalsAttended: 0,
      salesStats: createEmptySalesStats(),
    };
    setIsSleeping(false);
    engineRef.current?.setPlayerSleeping(false);
    setFirebaseEmail(null);
    setFirebaseUid(null);
    setPlots(freshPlots);
    setFarmTrees(freshTrees);
    setStats(freshStats);
    setAnimals([]);
    setInventory(INITIAL_INVENTORY);
    setVisitingFarmOwnerId(null);
    setVisitingFarmName(null);
    setSettingsOpen(false);
    setBukuTab(null);
    setShowInventory(false);
    setShowChat(false);
    setNpcDialogState(null);
    setActiveFacilityModal(null);
    setDoorPrompt(null);
    cancelInWorldFishing();
    setNpcChoicePopover(null);
    setIncomingProposal(null);
    if (engineRef.current) {
      engineRef.current.regenerateFarmTrees(freshSeed, freshTrees);
      engineRef.current.syncFarmPlots(freshPlots);
      engineRef.current.isTitleMode = true;
    }
    setStarted(false);
    showToast(
      lang === 'id'
        ? '🗑️ Akun dan seluruh data permainan telah dihapus permanen.'
        : '🗑️ Your account and all game data have been permanently deleted.'
    );
  };

  const handleUseConsumable = (idx: number) => {
    const slot = inventory[idx];
    if (!slot) return;
    const def = ITEMS[slot.itemId];
    if (!def || !def.staminaRestore) return;
    if (consumeInventoryItem(def.id, 1)) {
      setStamina((s) => Math.min(maxStamina, s + def.staminaRestore!));
      const funGain = def.id === 'item_royal_elixir' ? 35 : 5;
      rewardProgress(4, funGain);
      soundEngine.playHarvest();
      showToast(`🍽️ Ate ${def.name} (+${def.staminaRestore} Stamina)`);
    }
  };

  // === RESET TO HOME (Teleports INSIDE Private Farmhouse!) ===
  const handleResetToHome = () => {
    const now = Date.now();
    if (now - (profile.lastResetHomeAt || 0) < RESET_HOME_COOLDOWN_MS) {
      showToast('⏳ Reset to Home can only be used once every 10 minutes.');
      return;
    }
    if (visitingFarmOwnerId) {
      const local = loadLocalSave();
      const savedPlots = (local?.payload as { plots?: Record<string, FarmPlotState> } | undefined)?.plots;
      if (savedPlots) setPlots(savedPlots);
      setVisitingFarmOwnerId(null);
      setVisitingFarmName(null);
      engineRef.current?.regenerateFarmTrees(profile.uid);
    }
    setProfile((p) => ({ ...p, lastResetHomeAt: now }));
    engineRef.current?.enterZone('int_farmhouse', 0, 1.0);
    setZone('int_farmhouse');
    mpRef.current?.changeZone('int_farmhouse', profile.uid, 0, 1.0);
    soundEngine.playDoor();
    showToast('🏡 Reset to Home: Moved directly inside your private Farmhouse!');
  };

  // === FRIDGE & TOOLBOX STORAGE TRANSFER ===
  const handleStorageDeposit = (kind: 'fridge' | 'toolbox', itemId: string) => {
    const slot = inventory.find((s) => s.itemId === itemId);
    if (!slot) return;
    const setter = kind === 'fridge' ? setFridgeItems : setToolboxItems;
    if (!consumeInventoryItem(itemId, 1, true)) return;
    setter((prev) => {
      const idx = prev.findIndex((s) => s.itemId === itemId);
      if (idx >= 0) {
        return prev.map((s, i) => (i === idx ? { ...s, quantity: s.quantity + 1 } : s));
      }
      return [...prev, { ...slot, quantity: 1 }];
    });
    soundEngine.playUiClick();
  };

  const handleStorageWithdraw = (kind: 'fridge' | 'toolbox', itemId: string) => {
    const list = kind === 'fridge' ? fridgeItems : toolboxItems;
    const target = list.find((s) => s.itemId === itemId);
    if (!target) return;
    if (
      !addInventoryItem(itemId, 1, {
        toolLevel: target.toolLevel,
        durability: target.durability,
        maxDurability: target.maxDurability,
      })
    ) {
      return;
    }
    const setter = kind === 'fridge' ? setFridgeItems : setToolboxItems;
    setter((prev) => {
      const idx = prev.findIndex((s) => s.itemId === itemId);
      if (idx < 0) return prev;
      if (prev[idx].quantity <= 1) return prev.filter((_, i) => i !== idx);
      return prev.map((s, i) => (i === idx ? { ...s, quantity: s.quantity - 1 } : s));
    });
    soundEngine.playUiClick();
  };

  // === OUTFIT / WARDROBE HELPERS ===
  const handleEquipOutfit = (outfitId: string) => {
    const outfit = OUTFIT_CATALOG.find((o) => o.id === outfitId);
    if (!outfit) return;
    const nextAvatar: AvatarConfig = {
      ...profile.avatarConfig,
      outfitColor: outfit.shirtColor,
      pantsColor: outfit.pantsColor,
    };
    setProfile((p) => ({
      ...p,
      equippedOutfitId: outfit.id,
      avatarConfig: nextAvatar,
      version: p.version + 1,
    }));
    const toolKind = equippedItemId ? ITEMS[equippedItemId]?.toolKind : undefined;
    engineRef.current?.updateAvatar(nextAvatar, toolKind);
    soundEngine.playUiClick();
    showToast(`👕 Equipped ${outfit.name}!`);
  };

  const handleUnlockOutfit = (outfitId: string) => {
    const outfit = OUTFIT_CATALOG.find((o) => o.id === outfitId);
    if (!outfit) return;
    if (outfit.diamondPrice === 0 || (profile.unlockedOutfits || []).includes(outfitId)) {
      handleEquipOutfit(outfitId);
      return;
    }
    if (!DEVELOPER_DEBUG_MODE && profile.diamond < outfit.diamondPrice) {
      showToast(`💎 Not enough Diamonds (requires ${outfit.diamondPrice} 💎)!`);
      return;
    }
    const nextAvatar: AvatarConfig = {
      ...profile.avatarConfig,
      outfitColor: outfit.shirtColor,
      pantsColor: outfit.pantsColor,
    };
    setProfile((p) => ({
      ...p,
      diamond: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : p.diamond - outfit.diamondPrice,
      unlockedOutfits: Array.from(new Set([...(p.unlockedOutfits || ['outfit_classic']), outfitId])),
      equippedOutfitId: outfitId,
      avatarConfig: nextAvatar,
      version: p.version + 1,
    }));
    const toolKind = equippedItemId ? ITEMS[equippedItemId]?.toolKind : undefined;
    engineRef.current?.updateAvatar(nextAvatar, toolKind);
    soundEngine.playCoin();
    showToast(`✨ Unlocked & equipped ${outfit.name}!`);
  };

  // === BAG UPGRADES (DIAMOND & GOLD MARKET-SCALED) & PERKS ===
  const bagUpgrades = profile.bagUpgrades || 0;
  const maxBagSlots = getMaxBagSlots(bagUpgrades);
  const nextBagUpgradeCost = bagUpgrades < MAX_BAG_UPGRADES ? BAG_UPGRADE_DIAMOND_COSTS[bagUpgrades] : null;
  const bagUpgradeMarketMult = marketState?.prices?.item_bag_upgrade?.multiplier ?? 1;
  const nextBagUpgradeGoldCost =
    bagUpgrades < MAX_BAG_UPGRADES ? getBagUpgradeGoldCost(bagUpgrades, bagUpgradeMarketMult) : null;

  const handleBuyBagUpgrade = () => {
    const level = profile.bagUpgrades || 0;
    if (level >= MAX_BAG_UPGRADES) {
      showToast('🎒 Bag capacity is already at maximum (90 Slots)!');
      return;
    }
    const cost = BAG_UPGRADE_DIAMOND_COSTS[level];
    if (!DEVELOPER_DEBUG_MODE && profile.diamond < cost) {
      showToast(`💎 Requires ${cost} Diamonds to unlock +6 Bag Slots!`);
      return;
    }
    setProfile((p) => ({
      ...p,
      diamond: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : p.diamond - cost,
      bagUpgrades: (p.bagUpgrades || 0) + 1,
      version: p.version + 1,
    }));
    void logPlayerTransaction({
      type: 'diamond_shop',
      buyerName: profile.avatarName,
      currency: 'diamond',
      amount: cost,
      itemName: 'Bag Capacity (+6 Slots)',
      description: `Upgraded to ${getMaxBagSlots(level + 1)} slots`,
    });
    soundEngine.playHarvest();
    showToast(`🎒 Bag capacity expanded to ${getMaxBagSlots(level + 1)} Slots!`);
  };

  const handleBuyBagUpgradeGold = async () => {
    const level = profile.bagUpgrades || 0;
    if (level >= MAX_BAG_UPGRADES) {
      showToast('🎒 Bag capacity is already at maximum (90 Slots)!');
      return;
    }
    const mult = marketState?.prices?.item_bag_upgrade?.multiplier ?? 1;
    const cost = getBagUpgradeGoldCost(level, mult);
    if (!DEVELOPER_DEBUG_MODE && profile.gold < cost) {
      showToast(`💰 Not enough Gold! Need ${cost.toLocaleString()} G (market rate).`);
      return;
    }
    setProfile((p) => ({
      ...p,
      gold: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : p.gold - cost,
      bagUpgrades: (p.bagUpgrades || 0) + 1,
      version: p.version + 1,
    }));
    const econ = await transactMarketEconomy('buy', 'item_bag_upgrade', 1, activeCharacterId);
    if (econ?.market) setMarketState(econ.market);
    if (econ?.taxBuckets) setTaxBuckets(econ.taxBuckets);
    soundEngine.playHarvest();
    showToast(`🎒 Bag expanded to ${getMaxBagSlots(level + 1)} Slots for ${cost.toLocaleString()} G!`);
  };

  const handleBuyDiamondItem = (itemId: string) => {
    const def = ITEMS[itemId];
    if (!def || !def.diamondPrice) return;
    const isDebug = liveRuntimeConfig.debugMode ?? DEVELOPER_DEBUG_MODE;
    const liveDiamondPrice = Math.max(
      def.diamondPrice,
      marketState?.prices?.[itemId]?.diamondPrice ?? def.diamondPrice
    );
    if (itemId === 'item_valley_phone' && hasPhone) {
      showToast('📱 You already own the Valley Smartphone!');
      return;
    }
    if (!isDebug && profile.diamond < liveDiamondPrice) {
      showToast(`💎 Not enough Diamonds (requires ${liveDiamondPrice} 💎)!`);
      return;
    }
    if (itemId === 'item_valley_phone') {
      addInventoryItem(itemId, 1);
      setProfile((p) => ({
        ...p,
        diamond: isDebug ? DEBUG_UNLIMITED_CURRENCY : p.diamond - liveDiamondPrice,
        hasPhone: true,
        version: p.version + 1,
      }));
      void transactMarketEconomy('buy', itemId, 1, activeCharacterId).then((econ) => {
        if (econ?.market) setMarketState(econ.market);
        if (econ?.taxBuckets) setTaxBuckets(econ.taxBuckets);
      });
      void logPlayerTransaction({
        type: 'diamond_shop',
        buyerName: profile.avatarName,
        currency: 'diamond',
        amount: liveDiamondPrice,
        itemId,
        itemName: def.name,
        description: 'Unlocked Valley Smartphone (Voice/Video/Group Calls)',
      });
      soundEngine.playCoin();
      showToast(`📱 Valley Smartphone unlocked (${liveDiamondPrice} 💎)! Voice, Video & Group Call are now active in Chat!`);
      return;
    }
    if (!addInventoryItem(itemId, 1)) return;
    setProfile((p) => ({
      ...p,
      diamond: isDebug ? DEBUG_UNLIMITED_CURRENCY : p.diamond - liveDiamondPrice,
      version: p.version + 1,
    }));
    void transactMarketEconomy('buy', itemId, 1, activeCharacterId).then((econ) => {
      if (econ?.market) setMarketState(econ.market);
      if (econ?.taxBuckets) setTaxBuckets(econ.taxBuckets);
    });
    void logPlayerTransaction({
      type: 'diamond_shop',
      buyerName: profile.avatarName,
      currency: 'diamond',
      amount: liveDiamondPrice,
      itemId,
      itemName: def.name,
    });
    soundEngine.playCoin();
    showToast(`💎 Exchanged ${liveDiamondPrice} Diamonds for ${def.name}!`);
  };

  const handleApplyCustomAppearance = (nextAvatar: AvatarConfig) => {
    if (!DEVELOPER_DEBUG_MODE && profile.diamond < CUSTOMIZATION_DIAMOND_COST) {
      showToast(`💎 Need ${CUSTOMIZATION_DIAMOND_COST} Diamonds to customize your appearance!`);
      return;
    }
    setProfile((p) => ({
      ...p,
      diamond: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : p.diamond - CUSTOMIZATION_DIAMOND_COST,
      gender: nextAvatar.gender,
      avatarConfig: nextAvatar,
      version: p.version + 1,
    }));
    const activeToolKind = equippedItemId ? ITEMS[equippedItemId]?.toolKind : undefined;
    engineRef.current?.updateAvatar(nextAvatar, activeToolKind);
    setShowStyleStudio(false);
    void logPlayerTransaction({
      type: 'diamond_shop',
      buyerName: profile.avatarName,
      currency: 'diamond',
      amount: CUSTOMIZATION_DIAMOND_COST,
      itemName: 'Style Studio Makeover',
    });
    soundEngine.playHarvest();
    showToast(`✨ Makeover complete! (-${CUSTOMIZATION_DIAMOND_COST} 💎)`);
  };

  const handleApplyHaircut = (hairStyle: HairStyleId, hairColor: string, goldCost: number) => {
    if (!DEVELOPER_DEBUG_MODE && profile.gold < goldCost) {
      showToast(`💰 Need ${goldCost.toLocaleString()} G for this haircut at Celia’s Salon!`);
      return;
    }
    const nextAvatar: AvatarConfig = {
      ...profile.avatarConfig,
      hairStyle,
      hairColor,
    };
    setProfile((p) => ({
      ...p,
      gold: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : p.gold - goldCost,
      avatarConfig: nextAvatar,
      version: p.version + 1,
    }));
    const activeToolKind = equippedItemId ? ITEMS[equippedItemId]?.toolKind : undefined;
    engineRef.current?.updateAvatar(nextAvatar, activeToolKind);
    void logPlayerTransaction({
      type: 'npc_trade',
      buyerName: profile.avatarName,
      sellerName: 'Celia (Village Salon)',
      currency: 'gold',
      amount: goldCost,
      itemName: `Salon Haircut (${hairStyle})`,
      description: `Color ${hairColor}`,
    });
    soundEngine.playHarvest();
    showToast(`✂️ Fresh salon cut applied at Celia’s Village Salon!`);
  };

  const handleCreateP2PListing = async (payload: {
    slotIndex?: number;
    itemId: string;
    itemName: string;
    category: MarketplaceCategory;
    quantity: number;
    diamondPrice: number;
    description: string;
  }): Promise<boolean> => {
    const isService = payload.category === 'services';
    if (!isService) {
      const slot =
        typeof payload.slotIndex === 'number'
          ? inventory[payload.slotIndex]
          : inventory.find((s) => s.itemId === payload.itemId);
      if (!slot || !slot.diamondTradeable || slot.quantity < payload.quantity) {
        showToast('💎 Item must be Diamond-tradeable with sufficient quantity.');
        return false;
      }
      if (!consumeInventoryItem(slot.itemId, payload.quantity, true, true)) return false;
    }
    const res = await createP2PMarketListing({
      sellerName: profile.avatarName,
      itemId: payload.itemId,
      itemName: payload.itemName,
      category: payload.category,
      quantity: payload.quantity,
      diamondPrice: payload.diamondPrice,
      sellerCharacterId: activeCharacterId,
      description: payload.description,
    });
    if (!res.ok) {
      if (!isService) {
        addInventoryItem(payload.itemId, payload.quantity, { diamondTradeable: true });
      }
      showToast(res.error || 'Could not publish P2P Diamond listing.');
      return false;
    }
    const updated = await fetchP2PMarketListings();
    setP2pListings(updated);
    soundEngine.playCoin();
    showToast(`💎 Listed ${payload.quantity}x ${payload.itemName}. Base price ${payload.diamondPrice} 💎; market price updates with Supply & Demand.`);
    return true;
  };

  const handleBuyP2PListing = async (listing: P2PMarketListing): Promise<boolean> => {
    if (listing.sellerUid === profile.uid) {
      showToast('You cannot buy your own listing.');
      return false;
    }
    if (!DEVELOPER_DEBUG_MODE && profile.diamond < listing.diamondPrice) {
      showToast(`💎 Not enough Diamonds (requires ${listing.diamondPrice} 💎)!`);
      return false;
    }
    const res = await buyP2PMarketListing(listing.id, profile.avatarName, activeCharacterId);
    if (!res.ok) {
      showToast(res.error || 'Purchase failed.');
      return false;
    }
    if (listing.category !== 'services' && ITEMS[listing.itemId]) {
      addInventoryItem(listing.itemId, listing.quantity, { diamondTradeable: true });
    }
    setProfile((p) => ({
      ...p,
      diamond: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : (typeof res.buyerDiamond === 'number' ? res.buyerDiamond : Math.max(0, p.diamond - listing.diamondPrice)),
      version: p.version + 1,
    }));
    const updated = await fetchP2PMarketListings();
    setP2pListings(updated);
    soundEngine.playCoin();
    showToast(`💎 Bought ${listing.quantity}x ${listing.itemName} from ${listing.sellerName}!`);
    return true;
  };

  const handleCancelP2PListing = async (listing: P2PMarketListing): Promise<boolean> => {
    const res = await cancelP2PMarketListing(listing.id);
    if (!res.ok) {
      showToast(res.error || 'Could not cancel listing.');
      return false;
    }
    if (listing.category !== 'services' && ITEMS[listing.itemId]) {
      addInventoryItem(listing.itemId, listing.quantity, { diamondTradeable: true });
    }
    const updated = await fetchP2PMarketListings();
    setP2pListings(updated);
    showToast(`🗑️ Cancelled listing for ${listing.itemName}.`);
    return true;
  };

  const handleConfirmHatchChick = () => {
    if (pendingHatchSlotIndex === null) return;
    const cleanName = hatchChickName.trim();
    if (!cleanName) {
      showToast('🐣 Please enter a name for your newly hatched chick!');
      return;
    }
    const chickensCount = animals.filter((a) => a.type === 'chicken').length;
    const coopCap = getCoopCapacity(profile.coopLevel || 1);
    if (chickensCount >= coopCap) {
      showToast(`🐔 Chicken Coop is full (${chickensCount}/${coopCap})!`);
      setPendingHatchSlotIndex(null);
      return;
    }
    const newChick: AnimalState = {
      id: `chicken_${Date.now()}`,
      type: 'chicken',
      name: cleanName.slice(0, 20),
      birthday: `${season} ${day}`,
      bornYear: year,
      fedToday: false,
      brushedToday: false,
      affection: 80,
      productReady: false,
      location: 'coop',
      x: -3.2 + (chickensCount % 5) * 1.6,
      z: -1.4 + Math.floor(chickensCount / 5) * 1.5,
    };
    setAnimals((prev) => [...prev, newChick]);
    setProfile((p) => {
      const updated = normalizeIncubatorSlots(p.coopLevel || 1, p.coopIncubators).map((sl) =>
        sl.slotIndex === pendingHatchSlotIndex
          ? { slotIndex: pendingHatchSlotIndex, eggPlacedDay: null, daysRemaining: 0, readyToHatch: false }
          : sl
      );
      return { ...p, coopIncubators: updated, version: p.version + 1 };
    });
    setPendingHatchSlotIndex(null);
    rewardProgress(20, 12);
    soundEngine.playHeart();
    showToast(`🐣 Welcome ${newChick.name}! Hatched on ${newChick.birthday} (Year ${year})!`);
  };

  const handleJoinFestival = (festival: FestivalDef) => {
    const festKey = `${year}_${festival.id}`;
    if ((profile.attendedFestivalKeys || []).includes(festKey)) {
      showToast(`🎪 You already celebrated ${festival.name} today!`);
      return;
    }
    const rewardGold = festival.rewardGold ?? 500;
    setProfile((p) => ({
      ...p,
      gold: p.gold + rewardGold,
      fun: 100,
      attendedFestivalKeys: [...(p.attendedFestivalKeys || []), festKey],
      version: p.version + 1,
    }));
    setNpcRels((prev) => {
      const next: Record<string, NPCRelationshipState> = {};
      for (const [id, rel] of Object.entries(prev)) {
        const nextFp = Math.min(1000, rel.friendshipPoints + 40);
        const hearts = Math.min(10, Math.floor(nextFp / 100));
        next[id] = {
          ...rel,
          friendshipPoints: nextFp,
          heartLevel: hearts,
          romanceStage: getRomanceStage(nextFp, rel.affectionPoints, profile.spouseId === id),
        };
      }
      return next;
    });
    setStats((st) => ({
      ...st,
      festivalsAttended: st.festivalsAttended + 1,
      totalGoldEarned: st.totalGoldEarned + rewardGold,
    }));
    rewardProgress(40, 20);
    soundEngine.playHarvest();
    showToast(
      `🎉 Celebrated ${festival.name} with all 25 villagers! +${rewardGold} G, +40 Friendship with everyone, & 100% Joy!`,
      'specialEvents'
    );
  };

  // === BUILDING UPGRADES (HOUSE, BARN, COOP Lv.1..3) ===
  const handleUpgradeHouse = () => {
    const cur = profile.houseLevel || 1;
    if (cur >= 3) {
      showToast('🏡 Your Farmhouse is already at Max Level (Lv.3)!');
      return;
    }
    const goldCost = cur * 1200;
    const woodReq = cur * 10;
    const stoneReq = cur * 5;
    const wood = inventory.find((s) => s.itemId === 'mat_wood')?.quantity || 0;
    const stone = inventory.find((s) => s.itemId === 'mat_stone')?.quantity || 0;
    if ((!DEVELOPER_DEBUG_MODE && profile.gold < goldCost) || wood < woodReq || stone < stoneReq) {
      showToast(`Need ${goldCost.toLocaleString()} G, ${woodReq} Timber, and ${stoneReq} Stone!`);
      return;
    }
    consumeInventoryItem('mat_wood', woodReq);
    consumeInventoryItem('mat_stone', stoneReq);
    setProfile((p) => ({
      ...p,
      gold: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : p.gold - goldCost,
      houseLevel: cur + 1,
      version: p.version + 1,
    }));
    rewardProgress(28, 10);
    soundEngine.playHarvest();
    showToast(`🏡 Farmhouse upgraded to Lv.${cur + 1}! (+20 Max Stamina)`);
  };

  const handleUpgradeBarn = () => {
    const cur = profile.barnLevel || 1;
    if (cur >= 3) {
      showToast('🐄 Your Livestock Barn is already at Max Level (Lv.3)!');
      return;
    }
    const goldCost = cur * 1000;
    const woodReq = cur * 8;
    const stoneReq = cur * 4;
    const wood = inventory.find((s) => s.itemId === 'mat_wood')?.quantity || 0;
    const stone = inventory.find((s) => s.itemId === 'mat_stone')?.quantity || 0;
    if ((!DEVELOPER_DEBUG_MODE && profile.gold < goldCost) || wood < woodReq || stone < stoneReq) {
      showToast(`Need ${goldCost.toLocaleString()} G, ${woodReq} Timber, and ${stoneReq} Stone!`);
      return;
    }
    consumeInventoryItem('mat_wood', woodReq);
    consumeInventoryItem('mat_stone', stoneReq);
    const nextLv = cur + 1;
    setProfile((p) => ({
      ...p,
      gold: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : p.gold - goldCost,
      barnLevel: nextLv,
      version: p.version + 1,
    }));
    rewardProgress(25, 9);
    soundEngine.playHarvest();
    showToast(
      nextLv === 3
        ? `🐄 Livestock Barn upgraded to Lv.3 (20 feeding troughs)! Artisan Cheese Maker is now unlocked at Felix’s Ranch!`
        : `🐄 Livestock Barn upgraded to Lv.${nextLv} (${getBarnCapacity(nextLv)} feeding troughs)!`
    );
  };

  const handleUpgradeCoop = () => {
    const cur = profile.coopLevel || 1;
    if (cur >= 3) {
      showToast('🐔 Your Chicken Coop is already at Max Level (Lv.3)!');
      return;
    }
    const goldCost = cur * 800;
    const woodReq = cur * 6;
    const stoneReq = cur * 3;
    const wood = inventory.find((s) => s.itemId === 'mat_wood')?.quantity || 0;
    const stone = inventory.find((s) => s.itemId === 'mat_stone')?.quantity || 0;
    if ((!DEVELOPER_DEBUG_MODE && profile.gold < goldCost) || wood < woodReq || stone < stoneReq) {
      showToast(`Need ${goldCost.toLocaleString()} G, ${woodReq} Timber, and ${stoneReq} Stone!`);
      return;
    }
    consumeInventoryItem('mat_wood', woodReq);
    consumeInventoryItem('mat_stone', stoneReq);
    const nextLv = cur + 1;
    setProfile((p) => ({
      ...p,
      gold: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : p.gold - goldCost,
      coopLevel: nextLv,
      coopIncubators: normalizeIncubatorSlots(nextLv, p.coopIncubators),
      version: p.version + 1,
    }));
    rewardProgress(22, 8);
    soundEngine.playHarvest();
    showToast(
      nextLv === 3
        ? `🐔 Chicken Coop upgraded to Lv.3 (20 troughs & 2 Egg Incubators)!`
        : `🐔 Chicken Coop upgraded to Lv.${nextLv} (${getCoopCapacity(nextLv)} troughs & 1 Egg Incubator)!`
    );
  };

  const handleSellItemAtShop = async (slotIdx: number) => {
    const slot = inventory[slotIdx];
    if (!slot) return;
    const def = ITEMS[slot.itemId];
    if (!def || def.sellPrice <= 0) return;

    const econ = await transactMarketEconomy('sell', def.id, 1, activeCharacterId);
    const earned = econ?.ok ? econ.netGold : def.sellPrice;
    const taxPaid = econ?.taxGold || 0;
    if (econ?.market) setMarketState(econ.market);
    if (econ?.taxBuckets) setTaxBuckets(econ.taxBuckets);

    consumeInventoryItem(def.id, 1, true);
    setProfile((p) => ({ ...p, gold: p.gold + earned, version: p.version + 1 }));
    recordSaleStat('market_gold', season, 1, earned);
    if (stats.totalGoldEarned + earned >= 3000) unlockAchievement('ach_wealthy_farmer');
    soundEngine.playCoin();
    showToast(
      `💰 Sold 1x ${def.name} → +${earned.toLocaleString()} G${taxPaid > 0 ? ` (${econ?.taxPercent ?? 0}% Tax: ${taxPaid} G)` : ''}`
    );
  };

  const nearbyPlayers = remotePeers.filter((p) => {
    const dist = Math.hypot(p.x - playerPosRef.current.x, p.z - playerPosRef.current.z);
    return dist <= 2.65;
  });

  const proposalItemSlot = inventory.find(
    (s) => s.itemId === 'item_golden_ring' && s.quantity > 0
  );
  const canProposeBuildingsReady =
    profile.houseLevel >= 3 && (profile.barnLevel || 1) >= 3 && (profile.coopLevel || 1) >= 3;
  const marriageReqLabel = `Requires House Lv.${profile.houseLevel}/3, Barn Lv.${profile.barnLevel || 1}/3, Coop Lv.${profile.coopLevel || 1}/3 & Unity Wedding Ring (Diamond Shop)`;

  const activeNpc = npcDialogState ? NPC_MAP[npcDialogState.npcId] : null;
  const [bSeasonStr, bDayStr] = profile.birthday.split(' ');
  const lang = gameSettings.language;
  const hasPhone = Boolean(profile.hasPhone || inventory.some((s) => s.itemId === 'item_valley_phone' && s.quantity > 0));
  const activeFestival = FESTIVALS.find((f) => f.season === season && f.day === day) || null;
  const festivalAttendedToday = Boolean(
    activeFestival && (profile.attendedFestivalKeys || []).includes(`${year}_${activeFestival.id}`)
  );
  const activeWorkJob =
    farmJobs.find((j) => j.workerUid === profile.uid && j.status === 'in_progress') || null;
  const isHiredOnVisitedFarm = Boolean(
    visitingFarmOwnerId && activeWorkJob && activeWorkJob.employerUid === visitingFarmOwnerId
  );
  const nextGiftJoyAmount = Number((10 * Math.pow(0.5, dailyFunTracker.diminishingCounts.gift || 0)).toFixed(2));

  const startPhoneCall = (
    mode: 'voice' | 'video',
    isGroup: boolean,
    targetUid?: string,
    groupTargetUids?: string[]
  ) => {
    if (!hasPhone) {
      showToast('📱 Purchase the Valley Smartphone (50 Diamonds) at Theo’s Store or the Diamond Shop first!');
      return;
    }
    const friendUids = new Set(friends.map((f) => f.uid));
    if (friendUids.size === 0) {
      showToast('👥 Add mutual friends in Chat → Friends first! Calls work across all zones with friends only.');
      return;
    }

    let inviteUids: string[] = [];
    if (isGroup) {
      const requested = groupTargetUids && groupTargetUids.length > 0 ? groupTargetUids : friends.map((f) => f.uid);
      inviteUids = requested.filter((uid) => friendUids.has(uid));
      if (inviteUids.length === 0) {
        showToast('👥 Select at least one Friend to invite to the Group Call!');
        return;
      }
    } else if (targetUid) {
      if (!friendUids.has(targetUid)) {
        showToast('🔒 Only mutual Friends on your Friend List can be called!');
        return;
      }
      inviteUids = [targetUid];
    } else {
      inviteUids = friends.map((f) => f.uid);
    }

    const roomId = isGroup
      ? `group_${profile.uid}_${Date.now().toString(36)}`
      : `direct_${[profile.uid, inviteUids[0]].sort().join('_')}`;

    void callManagerRef.current?.startOrJoinCall({
      roomId,
      mode,
      isGroup,
      inviteTargetUids: inviteUids,
    });
    showToast(
      isGroup
        ? `📞 Started Group ${mode === 'video' ? 'Video' : 'Voice'} Call with ${inviteUids.length} friend(s)!`
        : `📞 Calling friend across the valley via ${mode === 'video' ? 'Video' : 'Voice'}...`
    );
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#7eb88c]">
      {/* Isolated 3D WebGL Viewport */}
      <div ref={canvasMountRef} className="fixed inset-0 z-0" />

      {/* Real-Time Sleep Overlay: gradually restores stamina without shifting shared global time */}
      {isSleeping && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-[90] flex flex-col items-center justify-center p-6 select-none cursor-pointer"
          style={{
            background: 'var(--hv-title-scrim)',
            color: 'var(--hv-text)',
          }}
        >
          <div className="gv-title-card w-full max-w-md rounded-3xl p-7 text-center shadow-2xl space-y-4">
            <div className="mx-auto w-16 h-16 rounded-2xl flex items-center justify-center text-3xl animate-pulse" style={{ background: 'var(--hv-surface-2)', border: '1px solid var(--hv-border)' }}>
              🌙
            </div>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.2em]" style={{ color: 'var(--hv-text-muted)' }}>
                {lang === 'id' ? 'Sedang Beristirahat...' : 'Resting in Bed...'}
              </p>
              <h2 className="text-2xl font-black mt-1" style={{ fontFamily: 'var(--hv-font-display)' }}>
                {lang === 'id' ? 'Tidur & Memulihkan Stamina' : 'Sleeping & Recovering Stamina'}
              </h2>
            </div>

            <div className="space-y-1.5 pt-1">
              <div className="flex items-center justify-between text-xs font-extrabold">
                <span>⚡ {lang === 'id' ? 'Pemulihan Stamina' : 'Stamina Recovery'}</span>
                <span className="tabular-nums">
                  {Math.round(stamina)} / {maxStamina}
                </span>
              </div>
              <div className="w-full h-3.5 rounded-full overflow-hidden" style={{ background: 'var(--hv-surface-2)', border: '1px solid var(--hv-border)' }}>
                <div
                  className="h-full rounded-full transition-all duration-300"
                  style={{
                    width: `${Math.min(100, Math.round((stamina / Math.max(1, maxStamina)) * 100))}%`,
                    background: 'var(--hv-accent)',
                  }}
                />
              </div>
              <p className="text-[11px]" style={{ color: 'var(--hv-text-muted)' }}>
                {stamina >= maxStamina
                  ? lang === 'id'
                    ? '✨ Stamina sudah pulih penuh!'
                    : '✨ Stamina is fully recovered!'
                  : lang === 'id'
                    ? 'Stamina pulih sedikit demi sedikit. Jam & hari global tetap berjalan normal.'
                    : 'Stamina recovers gradually. Shared global valley hour & day continue normally.'}
              </p>
            </div>

            <div className="pt-2">
              <div
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black tracking-wide animate-pulse"
                style={{
                  background: 'var(--hv-pill-bg)',
                  color: 'var(--hv-pill-text)',
                  border: '1px solid var(--hv-pill-border)',
                }}
              >
                <span>✨</span>
                <span>
                  {lang === 'id'
                    ? 'Tekan tombol apa saja untuk bangun'
                    : 'Press any key or tap anywhere to wake up'}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeBan && activeBan.active && activeBan.banType !== 'chat_ban' && (
        <BanLockdownScreen
          ban={activeBan}
          language={lang}
          onSignOut={() => {
            void handleLogout();
          }}
        />
      )}

      {!started && (
        <TitleScreen
          hasExistingSave={Boolean(loadLocalSave() || firebaseUid)}
          savedSession={detectSavedLoginSession()}
          firebaseUserEmail={firebaseEmail}
          socialAccount={socialAccount}
          characterRoster={characterRoster}
          guestDurationMinutes={liveRuntimeConfig.guestSessionConfig?.durationMinutes ?? 60}
          isOnline={isOnline}
          language={lang}
          initialAvatar={profile.avatarConfig}
          initialProfile={{
            avatarName: profile.avatarName,
            farmName: profile.farmName,
            birthdaySeason: SEASONS_ORDER.includes(bSeasonStr as Season) ? (bSeasonStr as Season) : 'Spring',
            birthdayDay: Number(bDayStr) || 5,
            dogName: profile.dogName || 'Bobi',
            horseName: profile.horseName || 'Gale',
          }}
          onSignInGoogle={async () => {
            await handleSignInSocialProvider('google');
          }}
          onSignInSocialProvider={handleSignInSocialProvider}
          onGuestQuickPlay={handleGuestQuickPlay}
          onSelectCharacter={handleSelectCharacter}
          onScheduleDeleteCharacter={handleScheduleDeleteCharacter}
          onCancelDeleteCharacter={handleCancelDeleteCharacter}
          onSwitchAccount={handleSwitchAccount}
          onLogout={handleLogout}
          onDeleteAccount={handleDeleteAccount}
          onOpenSettings={() => setSettingsOpen(true)}
          onQuickLanguageToggle={() =>
            setGameSettings((prev) => ({ ...prev, language: prev.language === 'en' ? 'id' : 'en' }))
          }
          onAvatarPreviewChange={(av) => engineRef.current?.updateAvatar(av)}
          onCreationPreviewMode={(enabled) => engineRef.current?.setCreationPreviewMode(enabled)}
          onStartGame={handleStartGame}
        />
      )}

      {!started && settingsOpen && (
        <SettingsModal
          settings={gameSettings}
          keyBindings={keybindings}
          gamepadStatus={gamepadStatus}
          deviceProfile={deviceProfile}
          mobileControlsConfig={liveRuntimeConfig.mobileControlsConfig}
          firebaseUserEmail={firebaseEmail}
          isInGame={false}
          onUpdateSettings={(next) => setGameSettings(next)}
          onUpdateKeyBindings={(next) => setKeybindings(next)}
          onLogout={handleLogout}
          onDeleteAccount={handleDeleteAccount}
          onClose={() => setSettingsOpen(false)}
        />
      )}

      {started && (
        <>
          <GameHUD
            language={lang}
            season={season}
            day={day}
            year={year}
            hour={hour}
            minute={minute}
            weather={weather}
            gold={profile.gold}
            diamond={profile.diamond}
            debugMode={liveRuntimeConfig.debugMode}
            guestRemainingSec={isGuestSession ? guestRemainingSec : null}
            stamina={stamina}
            maxStamina={maxStamina}
            fun={profile.fun}
            level={profile.level}
            xp={profile.xp}
            zone={zone}
            visitingFarmName={visitingFarmName}
            onlineCount={onlineCount}
            isCloudSynced={isCloudSynced}
            isOnline={isOnline}
            equippedItemId={equippedItemId}
            nearbyPrompt={nearbyPrompt}
            floatingTags={floatingTags}
            headAnchors={headAnchors}
            chatBubbles={chatBubbles}
            callState={callState}
            activeJob={activeWorkJob}
            activeFestival={activeFestival}
            currentUid={profile.uid}
            toastMessage={toast}
            keyBindings={keybindings}
            deviceProfile={deviceProfile}
            mobileMode={effectiveMobileMode}
            mobileControlsConfig={liveRuntimeConfig.mobileControlsConfig}
            customGamepadLayout={gameSettings.mobileGamepadLayout}
            mobileSprintActive={mobileSprintActive}
            showSelfCameraInCall={Boolean(gameSettings.showSelfCameraInCall)}
            videoCallConfig={liveRuntimeConfig.videoCallConfig}
            profile={profile}
            renameDisplayNameCost={Math.max(250, marketState?.prices?.service_display_name_rename?.diamondPrice || liveRuntimeConfig.nameChangeEconomyConfig?.basePriceDiamond || 250)}
            onRenameDisplayName={handleRenameDisplayName}
            canRenameDisplayName={!isGuestSession && Boolean(activeCharacterId && socialAccount)}
            animals={animals}
            stats={stats}
            onToggleMobileMode={() =>
              setGameSettings((prev) => ({
                ...prev,
                deviceControlMode: effectiveMobileMode ? 'desktop' : 'mobile',
                mobileMode: !effectiveMobileMode,
              }))
            }
            onExitMobileMode={handleExitMobileMode}
            onOpenInventory={() => setShowInventory((v) => !v)}
            onOpenBuku={() => {
              setSettingsOpen(false);
              setBukuTab((t) => (t ? null : 'calendar'));
            }}
            onOpenSettings={() => {
              setBukuTab(null);
              setSettingsOpen((v) => !v);
            }}
            onOpenDiamondShop={() => {
              setSettingsOpen(false);
              setBukuTab('iap');
            }}
            onToggleChat={() => {
              setChatInitialChannel('global');
              setShowChat((v) => !v);
            }}
            onToggleMic={() => callManagerRef.current?.toggleMic()}
            onToggleCam={() => void callManagerRef.current?.toggleCamera()}
            onFlipCam={() => void callManagerRef.current?.flipCamera()}
            onLeaveCall={() => callManagerRef.current?.leaveCall()}
            onCompleteActiveJob={(jobId) => mpRef.current?.completeFarmJob(jobId)}
            onTriggerAction={(mode) => engineRef.current?.triggerContextualAction(mode)}
            onJump={() => engineRef.current?.triggerJump()}
            onJumpRelease={() => engineRef.current?.releaseJump()}
            onDash={() => engineRef.current?.triggerDash()}
            onSprintToggle={() => {
              setMobileSprintActive((prev) => {
                const next = !prev;
                engineRef.current?.setMobileSprint(next);
                return next;
              });
            }}
            onTouchMove={(x, y) => {
              if (engineRef.current) {
                engineRef.current.touchMove.x = x;
                engineRef.current.touchMove.y = y;
              }
            }}
            worldSpeechBubbles={worldSpeechBubbles}
            npcChoicePopover={npcChoicePopover}
            onNpcChoiceTalk={(npcId) => performNpcOverheadTalk(npcId)}
            onNpcChoiceGive={(npcId) => {
              const heldId = stateRef.current.equippedItemId;
              if (heldId) performNpcOverheadGift(npcId, heldId);
            }}
            onCloseNpcChoice={() => setNpcChoicePopover(null)}
            fishingBar={fishingBar}
            onFishingStrike={handleFishingSpacePress}
            onFishingCancel={cancelInWorldFishing}
            caveLevel={caveLevel}
          />

          {tutorialStep >= 0 && tutorialStep < TUTORIAL_STEPS.length && (
            <TutorialOverlay
              step={tutorialStep}
              onNext={() => {
                if (tutorialStep >= TUTORIAL_STEPS.length - 1) setTutorialStep(-1);
                else setTutorialStep((s) => s + 1);
              }}
              onSkip={() => setTutorialStep(-1)}
            />
          )}

          {showInventory && (
            <InventoryModal
              slots={inventory}
              maxSlots={maxBagSlots}
              bagUpgrades={bagUpgrades}
              nextUpgradeCost={nextBagUpgradeCost}
              nextUpgradeGoldCost={nextBagUpgradeGoldCost}
              gold={profile.gold}
              diamond={profile.diamond}
              debugMode={DEVELOPER_DEBUG_MODE}
              equippedItemId={equippedItemId}
              toolShortcuts={profile.toolShortcuts || DEFAULT_TOOL_SHORTCUTS}
              keyBindings={keybindings}
              autoGiveEnabled={autoGiveEnabled}
              onToggleAutoGive={() => {
                setAutoGiveEnabled((prev) => {
                  const next = !prev;
                  try {
                    localStorage.setItem('gv_auto_give', next ? '1' : '0');
                  } catch {
                    // Ignore storage errors
                  }
                  return next;
                });
              }}
              onSetEquippedItem={setMasterHandItem}
              onSetToolShortcut={(slotIdx, itemId) => {
                setProfile((p) => {
                  const next = [...(p.toolShortcuts || DEFAULT_TOOL_SHORTCUTS)];
                  next[slotIdx] = itemId;
                  return { ...p, toolShortcuts: next };
                });
                soundEngine.playUiClick();
                showToast(`⌨️ Quick-Swap Slot #${slotIdx + 1} bound to ${ITEMS[itemId]?.name || itemId}!`);
              }}
              onUseConsumable={handleUseConsumable}
              onReorderSlots={(fromIdx, toIdx) => {
                setInventory((prev) => {
                  if (fromIdx < 0 || fromIdx >= prev.length) return prev;
                  const copy = [...prev];
                  const [moved] = copy.splice(fromIdx, 1);
                  const boundedTo = Math.max(0, Math.min(copy.length, toIdx));
                  copy.splice(boundedTo, 0, moved);
                  return copy;
                });
              }}
              onDiscard={(idx) => {
                setInventory((prev) => {
                  const target = prev[idx];
                  if (target && target.itemId === equippedItemId) {
                    setMasterHandItem(null);
                  }
                  return prev.filter((_, i) => i !== idx);
                });
              }}
              onUpgradeBag={handleBuyBagUpgrade}
              onUpgradeBagGold={() => void handleBuyBagUpgradeGold()}
              onClose={() => setShowInventory(false)}
            />
          )}

          {doorPrompt && (
            <DoorAccessModal
              buildingKind={doorPrompt.buildingKind}
              isInside={doorPrompt.isInside}
              isOwner={!visitingFarmOwnerId}
              isHiredWorker={isHiredOnVisitedFarm}
              isLocked={
                doorPrompt.buildingKind === 'farmhouse'
                  ? effectiveHouseLocked
                  : doorPrompt.buildingKind === 'coop'
                    ? effectiveCoopLocked
                    : doorPrompt.buildingKind === 'stable'
                      ? effectiveStableLocked
                      : effectiveBarnLocked
              }
              animalsCount={
                doorPrompt.buildingKind === 'coop'
                  ? animals.filter((a) => a.type === 'chicken').length
                  : doorPrompt.buildingKind === 'stable'
                    ? animals.filter((a) => a.type === 'horse').length
                    : animals.filter((a) => a.type === 'cow' || a.type === 'sheep').length
              }
              pastureAnimalsCount={
                doorPrompt.buildingKind === 'coop'
                  ? animals.filter((a) => a.type === 'chicken' && a.location === 'pasture').length
                  : doorPrompt.buildingKind === 'stable'
                    ? animals.filter((a) => a.type === 'horse' && a.location === 'pasture').length
                    : animals.filter((a) => (a.type === 'cow' || a.type === 'sheep') && a.location === 'pasture').length
              }
              onEnterOrExit={() => {
                if (visitingFarmOwnerId) {
                  const locked =
                    doorPrompt.buildingKind === 'farmhouse'
                      ? effectiveHouseLocked
                      : doorPrompt.buildingKind === 'coop'
                        ? effectiveCoopLocked
                        : doorPrompt.buildingKind === 'stable'
                          ? effectiveStableLocked
                          : effectiveBarnLocked;
                  const isSpouseFarm = Boolean(profile.spousePlayerUid && visitingFarmOwnerId === profile.spousePlayerUid);
                  const workerBypass = isHiredOnVisitedFarm && doorPrompt.buildingKind !== 'farmhouse';
                  if (locked && !workerBypass && !isSpouseFarm) {
                    showToast('🔒 This door is auto-locked by the farm owner.');
                    return;
                  }
                }
                executeZoneTransition(doorPrompt.targetZone);
              }}
              onToggleLock={(nextLocked) => {
                if (visitingFarmOwnerId) return;
                setProfile((p) => {
                  const nextHouse = doorPrompt.buildingKind === 'farmhouse' ? nextLocked : p.houseLocked;
                  const nextBarn = doorPrompt.buildingKind === 'barn' ? nextLocked : p.barnLocked;
                  const nextCoop = doorPrompt.buildingKind === 'coop' ? nextLocked : p.coopLocked;
                  const nextStable = doorPrompt.buildingKind === 'stable' ? nextLocked : (p.stableLocked ?? true);
                  mpRef.current?.sendLockUpdate(nextHouse, nextBarn, nextCoop, nextStable);
                  return {
                    ...p,
                    houseLocked: nextHouse,
                    barnLocked: nextBarn,
                    coopLocked: nextCoop,
                    stableLocked: nextStable,
                  };
                });
                if (doorPrompt.buildingKind === 'barn' && nextLocked) {
                  setAnimals((prev) =>
                    prev.map((a) => (a.type === 'cow' || a.type === 'sheep' ? { ...a, location: 'barn' } : a))
                  );
                } else if (doorPrompt.buildingKind === 'coop' && nextLocked) {
                  setAnimals((prev) => prev.map((a) => (a.type === 'chicken' ? { ...a, location: 'coop' } : a)));
                } else if (doorPrompt.buildingKind === 'stable' && nextLocked) {
                  setAnimals((prev) => prev.map((a) => (a.type === 'horse' ? { ...a, location: 'stable' } : a)));
                }
                soundEngine.playUiClick();
                const bLabel =
                  doorPrompt.buildingKind === 'farmhouse'
                    ? 'Farmhouse'
                    : doorPrompt.buildingKind === 'coop'
                      ? 'Chicken Coop'
                      : doorPrompt.buildingKind === 'stable'
                        ? 'Horse Stable'
                        : 'Livestock Barn';
                showToast(nextLocked ? `🔒 Auto-lock enabled for ${bLabel}.` : `🔓 Unlocked ${bLabel} door.`);
              }}
              onMoveAnimalsLocation={(loc) => {
                const kind = doorPrompt.buildingKind;
                setAnimals((prev) =>
                  prev.map((a, idx) => {
                    const matches =
                      kind === 'coop'
                        ? a.type === 'chicken'
                        : kind === 'stable'
                          ? a.type === 'horse'
                          : a.type === 'cow' || a.type === 'sheep';
                    if (!matches) return a;
                    return {
                      ...a,
                      location: loc,
                      x:
                        loc === 'pasture'
                          ? -94 + (idx % 4) * 2.4
                          : kind === 'coop'
                            ? -3.0 + (idx % 3) * 3.0
                            : kind === 'stable'
                              ? -2.8 + (idx % 3) * 2.8
                              : -4.0 + (idx % 4) * 2.6,
                      z:
                        loc === 'pasture'
                          ? -14 + Math.floor(idx / 4) * 2.2
                          : kind === 'coop'
                            ? -1.2 + Math.floor(idx / 3) * 2.0
                            : kind === 'stable'
                              ? -1.0 + Math.floor(idx / 3) * 2.2
                              : -1.4 + Math.floor(idx / 4) * 2.4,
                    };
                  })
                );
                showToast(
                  loc === 'pasture'
                    ? '🌿 Animals moved out to the outdoor pasture!'
                    : kind === 'coop'
                      ? '🐔 Chickens moved back inside the Chicken Coop!'
                      : kind === 'stable'
                        ? '🐴 Horses moved back inside the Horse Stable!'
                        : '🐄 Cows & sheep moved back inside the Barn!'
                );
              }}
              onClose={() => setDoorPrompt(null)}
            />
          )}

          {activeFacilityModal === 'tv' && (
            <FarmhouseTVModal
              season={season}
              day={day}
              weather={weather}
              marketState={marketState}
              onClose={() => setActiveFacilityModal(null)}
            />
          )}

          {(activeFacilityModal === 'fridge' || activeFacilityModal === 'toolbox') && (
            <FarmhouseStorageModal
              kind={activeFacilityModal}
              inventory={inventory}
              storageItems={activeFacilityModal === 'fridge' ? fridgeItems : toolboxItems}
              maxBagSlots={maxBagSlots}
              onDeposit={(itemId) => handleStorageDeposit(activeFacilityModal, itemId)}
              onWithdraw={(itemId) => handleStorageWithdraw(activeFacilityModal, itemId)}
              onClose={() => setActiveFacilityModal(null)}
            />
          )}

          {activeFacilityModal === 'wardrobe' && (
            <FarmhouseWardrobeModal
              unlockedOutfits={profile.unlockedOutfits || ['outfit_classic']}
              equippedOutfitId={profile.equippedOutfitId || 'outfit_classic'}
              diamonds={profile.diamond}
              onEquipOutfit={handleEquipOutfit}
              onUnlockOutfit={handleUnlockOutfit}
              onOpenStyleStudio={() => {
                setActiveFacilityModal(null);
                setShowStyleStudio(true);
              }}
              onClose={() => setActiveFacilityModal(null)}
            />
          )}

          {incomingProposal && (
            <MarriageProposalModal
              proposal={incomingProposal}
              onRespond={(accepted) => {
                mpRef.current?.sendMarriageResponse(incomingProposal.fromUid, accepted, incomingProposal.itemId);
                setIncomingProposal(null);
              }}
            />
          )}

          {activeNpc && npcDialogState && (
            <NPCDialogueModal
              language={lang}
              npc={activeNpc}
              initialTab={npcDialogState.tab}
              nextGiftJoyAmount={nextGiftJoyAmount}
              relationship={npcRels[activeNpc.id]}
              season={season}
              weather={weather}
              day={day}
              hour={hour}
              isRainy={weather === 'Rainy' || weather === 'LightRain' || weather === 'HeavyRain' || weather === 'Stormy'}
              isMarriedToPlayer={profile.spouseId === activeNpc.id}
              playerGold={profile.gold}
              playerDiamond={profile.diamond}
              currentAvatar={profile.avatarConfig}
              houseLevel={profile.houseLevel}
              barnLevel={profile.barnLevel || 1}
              coopLevel={profile.coopLevel || 1}
              hasCheeseMaker={Boolean(profile.hasCheeseMaker)}
              hasPhone={hasPhone}
              animals={animals}
              defaultDogName={profile.dogName || 'Bobi'}
              defaultHorseName={profile.horseName || 'Gale'}
              activeFestival={activeFestival}
              festivalAttendedToday={festivalAttendedToday}
              inventory={inventory}
              completedQuestIds={completedQuests}
              marketPrices={marketState?.prices}
              branchingDialogues={liveRuntimeConfig.branchingDialogues || []}
              onDialogueChoiceEffect={(npcId: string, choice: BranchingDialogueChoice) => {
                if (choice.friendshipDelta) {
                  setNpcRels((prev) => {
                    const cur = prev[npcId];
                    if (!cur) return prev;
                    return {
                      ...prev,
                      [npcId]: {
                        ...cur,
                        friendshipPoints: Math.max(0, cur.friendshipPoints + (choice.friendshipDelta || 0)),
                      },
                    };
                  });
                }
                if (choice.rewardGold && choice.rewardGold > 0) {
                  setProfile((p) => ({ ...p, gold: p.gold + (choice.rewardGold || 0) }));
                  showToast(`🪙 +${choice.rewardGold} G`);
                }
              }}
              onGiveGift={handleGiveGift}
              onJoinFestival={handleJoinFestival}
              onApplyHaircut={handleApplyHaircut}
              onBuyItem={async (itemId) => {
                const def = ITEMS[itemId];
                if (!def) return;

                // Diamond-priced items (e.g. Valley Smartphone = 50 Diamonds)
                if (def.diamondPrice && def.buyPrice === 0) {
                  handleBuyDiamondItem(itemId);
                  return;
                }

                // Artisan Cheese Maker (requires Barn Lv.3, installed directly in Barn)
                if (itemId === 'item_cheese_maker') {
                  if ((profile.barnLevel || 1) < 3) {
                    showToast('🧀 Upgrade your Livestock Barn to Lv.3 before purchasing the Artisan Cheese Maker!');
                    return;
                  }
                  if (profile.hasCheeseMaker) {
                    showToast('🧀 You already installed an Artisan Cheese Maker in your Barn!');
                    return;
                  }
                  const cost = def.buyPrice;
                  if (!DEVELOPER_DEBUG_MODE && profile.gold < cost) {
                    showToast(`💰 Not enough Gold! Need ${cost.toLocaleString()} G.`);
                    return;
                  }
                  setProfile((p) => ({
                    ...p,
                    gold: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : p.gold - cost,
                    hasCheeseMaker: true,
                    version: p.version + 1,
                  }));
                  void logPlayerTransaction({
                    type: 'npc_trade',
                    buyerName: profile.avatarName,
                    sellerName: activeNpc.name,
                    currency: 'gold',
                    amount: cost,
                    itemId,
                    itemName: def.name,
                  });
                  rewardProgress(25, 10);
                  soundEngine.playHarvest();
                  showToast('🧀 Purchased & installed the Artisan Cheese Maker inside your Lv.3 Barn!');
                  return;
                }

                const livePrice = marketState?.prices[itemId]?.buyPrice ?? def.buyPrice;
                if (!DEVELOPER_DEBUG_MODE && profile.gold < livePrice) {
                  showToast('💰 Not enough Gold!');
                  return;
                }
                if (!addInventoryItem(itemId, 1)) return;
                const econ = await transactMarketEconomy('buy', itemId, 1, activeCharacterId);
                if (econ?.market) setMarketState(econ.market);
                if (econ?.taxBuckets) setTaxBuckets(econ.taxBuckets);
                const finalCost = econ?.ok ? econ.grossGold : livePrice;
                setProfile((p) => ({
                  ...p,
                  gold: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : Math.max(0, p.gold - finalCost),
                }));
                void logPlayerTransaction({
                  type: 'npc_trade',
                  buyerName: profile.avatarName,
                  sellerName: activeNpc.name,
                  currency: 'gold',
                  amount: finalCost,
                  itemId,
                  itemName: def.name,
                });
                soundEngine.playCoin();
                showToast(`🛒 Purchased ${def.name} (${finalCost.toLocaleString()} G)!`);
              }}
              onSellItem={(slotIdx) => void handleSellItemAtShop(slotIdx)}
              onUpgradeTool={(slotIdx) => {
                const slot = inventory[slotIdx];
                if (!slot) return;
                const curLv = slot.toolLevel || 1;
                if (curLv >= 5) {
                  showToast(`⚒️ ${ITEMS[slot.itemId].name} is already at Max Master Level (Lv.5)!`);
                  return;
                }
                const tierReq: Record<number, { gold: number; matId: string; matName: string; qty: number }> = {
                  1: { gold: 500, matId: 'mat_iron', matName: 'Iron Ore', qty: 2 },
                  2: { gold: 1200, matId: 'mat_silver', matName: 'Silver Ore', qty: 2 },
                  3: { gold: 2500, matId: 'mat_gold_ore', matName: 'Gold Ore', qty: 2 },
                  4: { gold: 5000, matId: 'mat_mythril_star', matName: 'Mythril Starstone', qty: 2 },
                };
                const req = tierReq[curLv] || tierReq[1];
                const totalMat = inventory
                  .filter((s) => s.itemId === req.matId)
                  .reduce((sum, s) => sum + s.quantity, 0);
                if ((!DEVELOPER_DEBUG_MODE && profile.gold < req.gold) || totalMat < req.qty) {
                  showToast(`⚒️ Need ${req.gold.toLocaleString()} G and ${req.qty} ${req.matName} to upgrade to Lv.${curLv + 1}!`);
                  return;
                }
                consumeInventoryItem(req.matId, req.qty);
                setProfile((p) => ({
                  ...p,
                  gold: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : p.gold - req.gold,
                }));
                setInventory((prev) =>
                  prev.map((s, i) => (i === slotIdx ? { ...s, toolLevel: curLv + 1, durability: 100 } : s))
                );
                rewardProgress(curLv >= 4 ? 35 : 15, curLv >= 4 ? 12 : 6);
                soundEngine.playWoodStone();
                showToast(`⚒️ ${ITEMS[slot.itemId].name} forged to Lv.${curLv + 1}!`);
              }}
              onUpgradeHouse={handleUpgradeHouse}
              onUpgradeBarn={handleUpgradeBarn}
              onUpgradeCoop={handleUpgradeCoop}
              onBuyAnimal={(type, enteredName) => {
                const isId = lang === 'id';
                const priceMap: Record<'chicken' | 'sheep' | 'cow' | 'dog' | 'horse', number> = {
                  chicken: 350,
                  sheep: 700,
                  cow: 1000,
                  dog: 800,
                  horse: 1500,
                };
                const cleanName = enteredName.trim().slice(0, 20);
                if (!cleanName) {
                  showToast(
                    isId ? '🐾 Silakan masukkan nama untuk hewan barumu!' : '🐾 Please enter a name for your new animal!'
                  );
                  return;
                }
                if (type === 'dog') {
                  const dogsNow = animals.filter((a) => a.type === 'dog').length;
                  if (dogsNow >= 1) {
                    showToast(
                      isId
                        ? '🐕 Batas kepemilikan tercapai! Setiap pemain hanya boleh memiliki maksimal 1 Anjing.'
                        : '🐕 Ownership limit reached! Each player may only own 1 Dog.'
                    );
                    return;
                  }
                } else if (type === 'horse') {
                  const horsesNow = animals.filter((a) => a.type === 'horse').length;
                  if (horsesNow >= 1) {
                    showToast(
                      isId
                        ? '🐴 Batas kepemilikan tercapai! Setiap pemain hanya boleh memiliki maksimal 1 Kuda.'
                        : '🐴 Ownership limit reached! Each player may only own 1 Horse.'
                    );
                    return;
                  }
                } else if (type === 'chicken') {
                  const chickensNow = animals.filter((a) => a.type === 'chicken').length;
                  const coopCap = getCoopCapacity(profile.coopLevel || 1);
                  if (chickensNow >= coopCap) {
                    showToast(
                      isId
                        ? `🐔 Kandang Ayam penuh (${chickensNow}/${coopCap})! Upgrade kandang di Bengkel Tukang Kayu.`
                        : `🐔 Chicken Coop is full (${chickensNow}/${coopCap})! Upgrade your Coop at Marcus’s Workshop.`
                    );
                    return;
                  }
                } else if (type === 'cow' || type === 'sheep') {
                  const barnNow = animals.filter((a) => a.type === 'cow' || a.type === 'sheep').length;
                  const barnCap = getBarnCapacity(profile.barnLevel || 1);
                  if (barnNow >= barnCap) {
                    showToast(
                      isId
                        ? `🐄 Kandang Sapi & Domba penuh (${barnNow}/${barnCap})! Upgrade kandang di Bengkel Tukang Kayu.`
                        : `🐄 Livestock Barn is full (${barnNow}/${barnCap})! Upgrade your Barn at Marcus’s Workshop.`
                    );
                    return;
                  }
                }

                const price = priceMap[type];
                if (!DEVELOPER_DEBUG_MODE && profile.gold < price) {
                  showToast(isId ? '💰 Gold tidak cukup!' : '💰 Not enough Gold!');
                  return;
                }
                setProfile((p) => ({
                  ...p,
                  gold: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : p.gold - price,
                }));
                const sameTypeCount = animals.filter((a) => a.type === type).length;

                const location: AnimalState['location'] =
                  type === 'chicken'
                    ? 'coop'
                    : type === 'horse'
                      ? 'stable'
                      : type === 'dog'
                        ? 'doghouse'
                        : 'barn';

                const spawnX =
                  type === 'chicken'
                    ? -3.2 + (sameTypeCount % 5) * 1.6
                    : type === 'horse'
                      ? -2.8 + (sameTypeCount % 3) * 2.8
                      : type === 'dog'
                        ? DOG_FOOD_BOWL_POS.x + 0.6
                        : -4.2 + (sameTypeCount % 5) * 2.1;
                const spawnZ =
                  type === 'chicken'
                    ? -1.4 + Math.floor(sameTypeCount / 5) * 1.5
                    : type === 'horse'
                      ? -1.0 + Math.floor(sameTypeCount / 3) * 2.2
                      : type === 'dog'
                        ? DOG_FOOD_BOWL_POS.z + 0.8
                        : -1.6 + Math.floor(sameTypeCount / 5) * 1.8;

                const birthdayLabel = `${season} ${day}`;
                const newAnimal: AnimalState = {
                  id: `${type}_${Date.now()}`,
                  type,
                  name: cleanName,
                  birthday: birthdayLabel,
                  bornYear: year,
                  fedToday: false,
                  brushedToday: false,
                  playedToday: false,
                  affection: 50,
                  hunger: 100,
                  energy: 100,
                  happiness: 80,
                  health: 100,
                  daysUnfed: 0,
                  isSick: false,
                  emotion: 'happy',
                  breedVariant: Math.floor(Math.random() * 4),
                  sizeScale: Number((0.92 + Math.random() * 0.16).toFixed(2)),
                  productReady: type === 'cow' || type === 'sheep' || type === 'chicken',
                  location,
                  x: spawnX,
                  z: spawnZ,
                };
                setAnimals((prev) => [...prev, newAnimal]);
                rewardProgress(12, 8);
                soundEngine.playCoin();
                showToast(
                  isId
                    ? type === 'chicken'
                      ? `🚚 ${newAnimal.name} (🎂 ${birthdayLabel}) dikirim ke Kandang Ayam!`
                      : type === 'horse'
                        ? `🐴 ${newAnimal.name} (🎂 ${birthdayLabel}) dikirim ke Kandang Kuda!`
                        : type === 'dog'
                          ? `🐕 ${newAnimal.name} (🎂 ${birthdayLabel}) menempati Rumah Anjing!`
                          : `🐄 ${newAnimal.name} (🎂 ${birthdayLabel}) dikirim ke Kandang Ternak!`
                    : type === 'chicken'
                      ? `🚚 ${newAnimal.name} (🎂 ${birthdayLabel}) delivered to your Chicken Coop!`
                      : type === 'horse'
                        ? `🐴 ${newAnimal.name} (🎂 ${birthdayLabel}) delivered to your dedicated Horse Stable!`
                        : type === 'dog'
                          ? `🐕 ${newAnimal.name} (🎂 ${birthdayLabel}) moved into the small Doghouse!`
                          : `🐄 ${newAnimal.name} (🎂 ${birthdayLabel}) delivered to your Livestock Barn!`
                );
              }}
              onCompleteQuest={(questId) => {
                const q = QUESTS.find((item) => item.id === questId);
                if (!q) return;
                if (q.requiredItemId) {
                  consumeInventoryItem(q.requiredItemId, q.requiredQty || 1);
                }
                setCompletedQuests((prev) => [...prev, questId]);
                setProfile((p) => ({
                  ...p,
                  gold: p.gold + q.rewardGold,
                  secretGroveUnlocked: q.unlocksFeature === 'secret_grove' ? true : p.secretGroveUnlocked,
                }));
                if (q.unlocksFeature === 'secret_grove') unlockAchievement('ach_secret_finder');
                setNpcRels((prev) => ({
                  ...prev,
                  [q.npcId]: {
                    ...prev[q.npcId],
                    friendshipPoints: Math.min(1000, prev[q.npcId].friendshipPoints + q.rewardFriendship),
                    memory: {
                      ...prev[q.npcId].memory,
                      completedQuests: [...prev[q.npcId].memory.completedQuests, q.title],
                    },
                  },
                }));
                rewardProgress(35, 12);
                soundEngine.playHarvest();
                showToast(`📜 Quest "${q.title}" completed! +${q.rewardGold} G`);
              }}
              onPropose={(npcId) => {
                if (!canProposeBuildingsReady) {
                  showToast('💍 Requires Farmhouse Lv.3, Barn Lv.3, and Chicken Coop Lv.3 before proposing!');
                  return;
                }
                if ((npcRels[npcId]?.heartLevel ?? 0) < 10) {
                  showToast('❤️ Reach Max 10/10 Hearts before proposing marriage!');
                  return;
                }
                if (!proposalItemSlot) {
                  showToast('💍 You need a Unity Wedding Ring (Diamond Shop) in your bag!');
                  return;
                }
                consumeInventoryItem(proposalItemSlot.itemId, 1);
                setProfile((p) => ({ ...p, spouseId: npcId, weddingDay: `${season} ${day}` }));
                setNpcRels((prev) => ({
                  ...prev,
                  [npcId]: { ...prev[npcId], romanceStage: 'Married' },
                }));
                unlockAchievement('ach_true_love');
                rewardProgress(50, 20);
                soundEngine.playHeart();
                showToast(`💍 Congratulations! You are officially married to ${NPC_MAP[npcId]?.name}!`);
              }}
              onClose={() => setNpcDialogState(null)}
            />
          )}

          {showChat && (
            <ChatPanel
              language={lang}
              messages={chatMessages}
              currentUid={profile.uid}
              initialChannel={chatInitialChannel}
              initialPrivateTarget={chatPrivateTarget}
              nearbyPlayers={nearbyPlayers}
              allOnlinePlayers={allOnlinePlayers}
              friends={friends}
              incomingFriendRequests={incomingFriendRequests}
              outgoingFriendRequests={outgoingFriendRequests}
              alreadyMarried={Boolean(profile.spousePlayerUid || profile.spouseId)}
              hasProposalItemId={proposalItemSlot?.itemId || null}
              canProposeMarriage={canProposeBuildingsReady && Boolean(proposalItemSlot)}
              marriageRequirementsLabel={marriageReqLabel}
              hasPhone={hasPhone}
              callState={callState}
              incomingInvite={incomingInvite}
              onStartVoiceCall={(targetUid) => startPhoneCall('voice', false, targetUid)}
              onStartVideoCall={(targetUid) => startPhoneCall('video', false, targetUid)}
              onStartGroupCall={(mode, targetUids) => startPhoneCall(mode, true, undefined, targetUids)}
              onRequestMediaPermission={async () => {
                const res = await callManagerRef.current?.requestMediaPermissions('video');
                if (res?.granted) showToast('🎤📷 Microphone & Camera access granted!');
                else if (res?.error) showToast(`⚠️ ${res.error}`);
              }}
              onSendFriendRequest={(targetUid) => {
                const target = allOnlinePlayers.find((p) => p.uid === targetUid);
                mpRef.current?.sendFriendRequest(targetUid, target?.avatarName || 'Farmer');
                showToast('👥 Friend request sent!');
              }}
              onRespondFriendRequest={(fromUid, accept) => {
                mpRef.current?.respondFriendRequest(fromUid, accept);
                showToast(accept ? '🤝 Friend added to your Friend List!' : 'Friend request declined.');
              }}
              onRemoveFriend={(friendUid) => {
                mpRef.current?.removeFriend(friendUid);
                showToast('Removed from Friend List.');
              }}
              onAcceptCallInvite={() => {
                if (!incomingInvite) return;
                if (!hasPhone) {
                  showToast('📱 Buy the Valley Smartphone (50 Diamonds) at Theo’s Store or the Diamond Shop to answer calls!');
                  setIncomingInvite(null);
                  return;
                }
                const inv = incomingInvite;
                setIncomingInvite(null);
                void callManagerRef.current?.startOrJoinCall({
                  roomId: inv.roomId,
                  mode: inv.mode,
                  isGroup: inv.isGroup,
                });
              }}
              onDeclineCallInvite={() => setIncomingInvite(null)}
              onToggleMic={() => callManagerRef.current?.toggleMic()}
              onToggleCam={() => void callManagerRef.current?.toggleCamera()}
              onFlipCam={() => void callManagerRef.current?.flipCamera()}
              onLeaveCall={() => callManagerRef.current?.leaveCall()}
              onProposePlayer={(targetUid, targetName, itemId) => {
                if (!canProposeBuildingsReady) {
                  showToast('💍 Upgrade Farmhouse, Barn, and Chicken Coop to Lv.3 before proposing!');
                  return;
                }
                mpRef.current?.sendMarriageProposal(targetUid, itemId);
                showToast(`💌 Marriage proposal sent to ${targetName}! Waiting for their reply...`);
              }}
              onSend={(ch, text, targetId) => {
                mpRef.current?.sendChat(ch, text, targetId);
                engineRef.current?.triggerPlayerSpeechBreath(2.6);
              }}
              mutedPlayerIds={Array.from(mutedPlayerIds)}
              onMute={(uid, shouldMute) => {
                setMutedPlayerIds((prev) => {
                  const next = new Set(prev);
                  if (shouldMute) next.add(uid);
                  else next.delete(uid);
                  return next;
                });
                mpRef.current?.moderateUser(shouldMute ? 'mute' : 'unmute', uid);
                showToast(shouldMute ? '🔇 Player muted.' : '🔊 Player unmuted.');
              }}
              onBlock={(uid) => {
                mpRef.current?.moderateUser('block', uid);
                showToast('🚫 Player blocked.');
              }}
              onReport={(msg) => {
                fetch('/api/chat/report', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    reporterId: profile.uid,
                    targetId: msg.senderId,
                    messageId: msg.id,
                    reason: 'Inappropriate chat message',
                  }),
                }).catch(() => {});
                showToast('🚩 Chat report submitted to server moderators.');
              }}
              onClose={() => setShowChat(false)}
            />
          )}

          {activeAnnouncement && (
            <AnnouncementBanner
              title={activeAnnouncement.title}
              message={activeAnnouncement.message}
              category={activeAnnouncement.category || 'update'}
              durationSec={activeAnnouncement.durationSec}
              bannerKey={announcementNonce}
              language={lang}
              onClose={() => setActiveAnnouncement(null)}
            />
          )}

          {settingsOpen && (
            <SettingsModal
              settings={gameSettings}
              keyBindings={keybindings}
              gamepadStatus={gamepadStatus}
              deviceProfile={deviceProfile}
              mobileControlsConfig={liveRuntimeConfig.mobileControlsConfig}
              firebaseUserEmail={firebaseEmail}
              isInGame={true}
              notifSettings={notifSettings}
              lastResetHomeAt={profile.lastResetHomeAt}
              onUpdateSettings={(next) => setGameSettings(next)}
              onUpdateKeyBindings={(next) => {
                setKeybindings(next);
                showToast('⌨️ Keyboard controls updated!');
              }}
              onToggleNotif={(k) => setNotifSettings((prev) => ({ ...prev, [k]: !prev[k] }))}
              onResetToHome={handleResetToHome}
              onExitGame={handleExitGame}
              onLogout={handleLogout}
              onDeleteAccount={handleDeleteAccount}
              onClose={() => setSettingsOpen(false)}
            />
          )}

          {bukuTab !== null && (
            <WorldPanelsModal
              mode="buku"
              language={lang}
              initialTab={bukuTab}
              profile={profile}
              animalsCount={animals.length}
              animals={animals}
              inventory={inventory}
              p2pListings={p2pListings}
              farmPlots={plots}
              farmJobs={farmJobs}
              season={season}
              day={day}
              year={year}
              hour={hour}
              isRainy={weather === 'Rainy' || weather === 'Stormy'}
              stats={stats}
              unlockedAchievements={unlockedAchievements}
              dailyMissions={dailyMissions}
              completedQuests={completedQuests}
              npcRelationships={npcRels}
              currentZone={zone}
              visitingFarmOwnerId={visitingFarmOwnerId}
              notifSettings={notifSettings}
              muted={muted}
              keyBindings={keybindings}
              gamepadStatus={gamepadStatus}
              marketState={marketState}
              taxBuckets={taxBuckets}
              paymentMethods={liveRuntimeConfig.paymentMethods}
              liveDebugMode={liveRuntimeConfig.debugMode}
              onClaimTaxReward={async () => {
                const res = await claimTaxPoolReward(profile.uid);
                if (res.market) setMarketState(res.market);
                if (res.taxBuckets) setTaxBuckets(res.taxBuckets);
                if (res.ok && res.claimedGold) {
                  setProfile((p) => ({ ...p, gold: p.gold + res.claimedGold!, version: p.version + 1 }));
                  soundEngine.playCoin();
                  showToast(res.message || `🏆 Claimed Top #${res.rank} Tax Dividend: +${res.claimedGold} G!`, 'rewards');
                } else {
                  showToast(res.error || 'No market tax dividend available to claim yet.');
                }
              }}
              onBuyBagUpgrade={handleBuyBagUpgrade}
              onBuyBagUpgradeGold={() => void handleBuyBagUpgradeGold()}
              onBuyDiamondItem={handleBuyDiamondItem}
              onBuyOutfit={handleUnlockOutfit}
              onCreateP2PListing={handleCreateP2PListing}
              onBuyP2PListing={handleBuyP2PListing}
              onCancelP2PListing={handleCancelP2PListing}
              onOpenStyleStudio={() => {
                setBukuTab(null);
                setShowStyleStudio(true);
              }}
              onUpdateKeyBindings={(next) => {
                setKeybindings(next);
                showToast('⌨️ Keyboard controls updated!');
              }}
              onClaimMission={(mId) => {
                const m = dailyMissions.find((x) => x.id === mId);
                if (!m || m.claimed || m.progress < m.target) return;
                setDailyMissions((prev) => prev.map((x) => (x.id === mId ? { ...x, claimed: true } : x)));
                setProfile((p) => ({
                  ...p,
                  gold: p.gold + m.rewardGold,
                }));
                rewardProgress(18, 8);
                soundEngine.playCoin();
                showToast(`🎁 Claimed daily mission: +${m.rewardGold} G`, 'rewards');
              }}
              onCreateFarmJob={(tasks, wageGold, cropCount, animalCount) => {
                if (!DEVELOPER_DEBUG_MODE && profile.gold < wageGold) {
                  showToast('💰 Not enough Gold to post this job wage!');
                  return;
                }
                mpRef.current?.createFarmJob(tasks, wageGold, cropCount, animalCount);
                soundEngine.playUiClick();
                showToast(`💼 Posted Farm Job (${wageGold.toLocaleString()} G, ${cropCount + animalCount} units)!`);
              }}
              onAcceptFarmJob={(job) => {
                mpRef.current?.acceptFarmJob(job.id);
                setVisitingFarmOwnerId(job.employerUid);
                setVisitingFarmName(job.employerName);
                engineRef.current?.regenerateFarmTrees(job.employerUid);
                engineRef.current?.enterZone('farm_home', FARMHOUSE_OUTDOOR_SPAWN.x, FARMHOUSE_OUTDOOR_SPAWN.z);
                setZone('farm_home');
                mpRef.current?.changeZone('farm_home', job.employerUid, FARMHOUSE_OUTDOOR_SPAWN.x, FARMHOUSE_OUTDOOR_SPAWN.z);
                setBukuTab(null);
                soundEngine.playDoor();
                showToast(`💼 Accepted ${job.employerName}’s Farm Job! Complete chores and claim your pay.`);
              }}
              onCancelFarmJob={(jobId) => {
                mpRef.current?.cancelFarmJob(jobId);
                showToast('🗑️ Cancelled your posted Farm Job.');
              }}
              onCompleteFarmJob={(jobId) => {
                mpRef.current?.completeFarmJob(jobId);
              }}
              onVisitFarm={(ownerUid, ownerName) => {
                setVisitingFarmOwnerId(ownerUid);
                setVisitingFarmName(ownerName);
                engineRef.current?.regenerateFarmTrees(ownerUid);
                engineRef.current?.enterZone('farm_home', FARMHOUSE_OUTDOOR_SPAWN.x, FARMHOUSE_OUTDOOR_SPAWN.z);
                setZone('farm_home');
                mpRef.current?.changeZone('farm_home', ownerUid, FARMHOUSE_OUTDOOR_SPAWN.x, FARMHOUSE_OUTDOOR_SPAWN.z);
                showToast(`🏡 Visiting ${ownerName}’s Farm!`, 'multiplayer');
              }}
              onReturnHome={() => {
                const local = loadLocalSave();
                const savedPlots = (local?.payload as { plots?: Record<string, FarmPlotState> } | undefined)?.plots;
                if (savedPlots) setPlots(savedPlots);
                setVisitingFarmOwnerId(null);
                setVisitingFarmName(null);
                engineRef.current?.regenerateFarmTrees(profile.uid);
                engineRef.current?.enterZone('farm_home', FARMHOUSE_OUTDOOR_SPAWN.x, FARMHOUSE_OUTDOOR_SPAWN.z);
                setZone('farm_home');
                mpRef.current?.changeZone('farm_home', profile.uid, FARMHOUSE_OUTDOOR_SPAWN.x, FARMHOUSE_OUTDOOR_SPAWN.z);
                showToast('🏡 Returned to your own Homestead.');
              }}
              onResetToHome={handleResetToHome}
              onExitGame={handleExitGame}
              onDiamondDelta={(delta) => {
                setProfile((p) => ({
                  ...p,
                  diamond: DEVELOPER_DEBUG_MODE ? DEBUG_UNLIMITED_CURRENCY : Math.max(0, p.diamond + delta),
                  version: p.version + 1,
                }));
                soundEngine.playCoin();
              }}
              onToggleNotif={(k) => setNotifSettings((prev) => ({ ...prev, [k]: !prev[k] }))}
              onToggleMute={() => {
                setGameSettings((prev) => ({
                  ...prev,
                  audio: { ...prev.audio, muted: !prev.audio.muted },
                }));
              }}
              onCaptureScreenshot={() => engineRef.current?.captureScreenshotDataUrl() || ''}
              onClose={() => {
                setBukuTab(null);
                setSettingsOpen(false);
              }}
            />
          )}

          {showStyleStudio && (
            <AppearanceStudioModal
              language={lang}
              currentAvatar={profile.avatarConfig}
              diamonds={profile.diamond}
              debugMode={DEVELOPER_DEBUG_MODE}
              onApplyCustomAppearance={handleApplyCustomAppearance}
              onClose={() => setShowStyleStudio(false)}
            />
          )}

          {pendingHatchSlotIndex !== null && (
            <DraggableWindow
              windowId="egg_hatch_naming"
              title={lang === 'id' ? '🐣 Telur Menetas! Beri Nama Anak Ayam' : '🐣 Egg Hatched! Name Your Baby Chick'}
              widthClass="w-[min(92vw,380px)]"
              headerAccent="moss"
              onClose={() => setPendingHatchSlotIndex(null)}
            >
              <div className="p-4 space-y-3 text-[#2b1a0e]">
                <p className="text-xs font-semibold text-[#5c3c22]">
                  {lang === 'id'
                    ? `Anak ayam baru menetas hari ini (${season} ${day}, Tahun ${year})! Hari ulang tahunnya akan otomatis tercatat sebagai ${season} ${day}.`
                    : `A baby chick hatched today (${season} ${day}, Year ${year})! Its birthday will automatically be recorded as ${season} ${day}.`}
                </p>
                <input
                  type="text"
                  maxLength={20}
                  value={hatchChickName}
                  onChange={(e) => setHatchChickName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleConfirmHatchChick();
                  }}
                  placeholder={lang === 'id' ? 'Nama anak ayam...' : 'Baby chick name...'}
                  className="w-full rounded-xl border-2 border-[#bfa070] bg-[#fffaf0] px-3 py-2 text-sm font-bold text-[#2b1a0e]"
                />
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setPendingHatchSlotIndex(null)}
                    className="px-3 py-2 rounded-xl border border-[#bfa070] bg-[#efe2c6] text-xs font-bold text-[#4a2f18] cursor-pointer"
                  >
                    {lang === 'id' ? 'Nanti' : 'Later'}
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirmHatchChick}
                    disabled={!hatchChickName.trim()}
                    className="px-4 py-2 rounded-xl border-2 border-[#2a4d20] bg-[#4c8c38] hover:bg-[#3f772e] disabled:opacity-45 text-xs font-extrabold text-white cursor-pointer"
                  >
                    {lang === 'id' ? 'Sambut Anak Ayam!' : 'Welcome Chick!'}
                  </button>
                </div>
              </div>
            </DraggableWindow>
          )}
        </>
      )}
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <MainGame />
    </ErrorBoundary>
  );
}
