import fs from 'fs';
import path from 'path';
import * as THREE from 'three';

// Polyfill FileReader for GLTFExporter binary export in Node.js
if (typeof globalThis.FileReader === 'undefined') {
  (globalThis as Record<string, unknown>).FileReader = class NodeFileReader {
    result: ArrayBuffer | null = null;
    onloadend: (() => void) | null = null;
    onerror: ((err: unknown) => void) | null = null;
    readAsArrayBuffer(blob: Blob) {
      blob
        .arrayBuffer()
        .then((buf) => {
          this.result = buf;
          this.onloadend?.();
        })
        .catch((err) => this.onerror?.(err));
    }
  };
}

import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';

const OUT_DIR = path.resolve(process.cwd(), 'public/assets/glb');

function mat(
  color: number | string,
  roughness = 0.75,
  metalness = 0.04,
  name = 'mat',
  emissive?: number | string,
  emissiveIntensity = 0
) {
  return new THREE.MeshStandardMaterial({
    name,
    color,
    roughness,
    metalness,
    emissive: emissive !== undefined ? new THREE.Color(emissive) : new THREE.Color(0x000000),
    emissiveIntensity,
  });
}

async function exportGLB(root: THREE.Object3D, relPath: string): Promise<void> {
  const fullPath = path.join(OUT_DIR, relPath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  const exporter = new GLTFExporter();
  const buffer = await new Promise<ArrayBuffer>((resolve, reject) => {
    exporter.parse(
      root,
      (res) => {
        if (res instanceof ArrayBuffer) resolve(res);
        else resolve(Buffer.from(JSON.stringify(res)).buffer);
      },
      reject,
      { binary: true }
    );
  });
  fs.writeFileSync(fullPath, Buffer.from(buffer));
}

function buildChibiCharacterGLB(gender: 'male' | 'female'): THREE.Group {
  const isFemale = gender === 'female';
  const root = new THREE.Group();
  root.name = isFemale ? 'ChibiFemaleRoot' : 'ChibiMaleRoot';

  const bodyGroup = new THREE.Group();
  bodyGroup.name = 'BodyGroup';
  root.add(bodyGroup);

  const skinMat = mat('#fcd5b5', 0.78, 0.02, 'SkinMat');
  const hairMat = mat('#6b3e1b', 0.85, 0.02, 'HairMat');
  const shirtMat = mat('#f5ead8', 0.85, 0.02, 'ShirtMat');
  const overallMat = mat('#2563eb', 0.75, 0.05, 'OutfitMat');
  const goldMat = mat('#f59e0b', 0.25, 0.85, 'GoldMat');
  const gloveMat = mat('#7c4a2d', 0.8, 0.05, 'GloveMat');
  const bootMat = mat('#6d3f22', 0.65, 0.08, 'BootMat');
  const soleMat = mat('#b08256', 0.85, 0.02, 'SoleMat');
  const cuffMat = mat('#cbd5e1', 0.85, 0.0, 'CuffMat');
  const eyeWhiteMat = mat('#ffffff', 0.3, 0.0, 'EyeWhiteMat');
  const eyeIrisMat = mat('#2d1810', 0.2, 0.1, 'EyeIrisMat');
  const blushMat = mat(isFemale ? '#fb7185' : '#f9a8a8', 0.8, 0.0, 'BlushMat');

  // Distinct, anatomically unified posture: zero gaps between shoulders, arms, waist, pelvis, and thighs
  const legSpread = isFemale ? 0.105 : 0.135;
  const legRadius = isFemale ? 0.092 : 0.112;
  const pantsMat = isFemale ? mat('#475569', 0.8, 0.04, 'PantsMat') : overallMat;

  const makeLeg = (name: string, xOff: number) => {
    const leg = new THREE.Group();
    leg.name = name;
    leg.position.set(xOff, 0.45, 0);
    const hipBall = new THREE.Mesh(new THREE.SphereGeometry(legRadius * 1.08, 12, 10), pantsMat);
    hipBall.name = 'PantsPart';
    hipBall.position.y = 0.025;
    const pants = new THREE.Mesh(
      new THREE.CapsuleGeometry(legRadius, 0.17, 4, 10),
      pantsMat
    );
    pants.name = 'PantsPart';
    pants.position.y = -0.095;
    const cuff = new THREE.Mesh(new THREE.CylinderGeometry(legRadius + 0.01, legRadius + 0.01, 0.06, 10), cuffMat);
    cuff.position.y = -0.23;
    const boot = new THREE.Mesh(
      new THREE.BoxGeometry(isFemale ? 0.18 : 0.22, 0.17, isFemale ? 0.24 : 0.28),
      bootMat
    );
    boot.position.set(0, -0.35, 0.03);
    const sole = new THREE.Mesh(
      new THREE.BoxGeometry(isFemale ? 0.19 : 0.23, 0.05, isFemale ? 0.26 : 0.3),
      soleMat
    );
    sole.position.set(0, -0.42, 0.03);
    leg.add(hipBall, pants, cuff, boot, sole);
    return leg;
  };
  bodyGroup.add(makeLeg('LeftLeg', -legSpread), makeLeg('RightLeg', legSpread));

  if (isFemale) {
    // Unified Female Silhouette: rounded shoulders, sculpted torso, continuous pelvis/hips under belt
    const upperTorso = new THREE.Mesh(new THREE.CylinderGeometry(0.188, 0.168, 0.34, 16), shirtMat);
    upperTorso.name = 'ShirtPart';
    upperTorso.position.y = 0.74;

    const shoulderYoke = new THREE.Mesh(new THREE.SphereGeometry(0.185, 14, 10), shirtMat);
    shoulderYoke.name = 'ShirtPart';
    shoulderYoke.scale.set(1.22, 0.52, 0.86);
    shoulderYoke.position.y = 0.855;

    const pelvisBlock = new THREE.Mesh(new THREE.CylinderGeometry(0.174, 0.198, 0.19, 16), pantsMat);
    pelvisBlock.name = 'PantsPart';
    pelvisBlock.position.y = 0.49;

    const pelvisCap = new THREE.Mesh(new THREE.SphereGeometry(0.196, 14, 10), pantsMat);
    pelvisCap.name = 'PantsPart';
    pelvisCap.scale.set(1.06, 0.56, 0.92);
    pelvisCap.position.y = 0.415;

    const dressApron = new THREE.Mesh(new THREE.CylinderGeometry(0.175, 0.225, 0.22, 14), overallMat);
    dressApron.name = 'OutfitPart';
    dressApron.position.y = 0.67;

    const flaredSkirt = new THREE.Mesh(new THREE.CylinderGeometry(0.205, 0.33, 0.24, 16), overallMat);
    flaredSkirt.name = 'OutfitPart';
    flaredSkirt.position.y = 0.48;

    const belt = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.186, 0.058, 16), goldMat);
    belt.position.y = 0.585;

    bodyGroup.add(upperTorso, shoulderYoke, pelvisBlock, pelvisCap, dressApron, flaredSkirt, belt);
  } else {
    // Unified Male Silhouette: rounded sturdy shoulders, sculpted torso, continuous pelvis/hips
    const shirtTorso = new THREE.Mesh(new THREE.CylinderGeometry(0.248, 0.222, 0.4, 14), shirtMat);
    shirtTorso.name = 'ShirtPart';
    shirtTorso.position.y = 0.72;

    const shoulderYoke = new THREE.Mesh(new THREE.SphereGeometry(0.225, 14, 10), shirtMat);
    shoulderYoke.name = 'ShirtPart';
    shoulderYoke.scale.set(1.32, 0.54, 0.86);
    shoulderYoke.position.y = 0.855;

    const pelvisBlock = new THREE.Mesh(new THREE.CylinderGeometry(0.226, 0.238, 0.2, 14), pantsMat);
    pelvisBlock.name = 'PantsPart';
    pelvisBlock.position.y = 0.485;

    const pelvisCap = new THREE.Mesh(new THREE.SphereGeometry(0.236, 14, 10), pantsMat);
    pelvisCap.name = 'PantsPart';
    pelvisCap.scale.set(1.05, 0.54, 0.92);
    pelvisCap.position.y = 0.405;

    const bib = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.32, 0.35), overallMat);
    bib.name = 'OutfitPart';
    bib.position.set(0, 0.64, 0.02);

    const strapL = new THREE.Mesh(new THREE.BoxGeometry(0.068, 0.22, 0.33), overallMat);
    strapL.name = 'OutfitPart';
    strapL.position.set(-0.115, 0.82, 0.01);
    const strapR = strapL.clone();
    strapR.name = 'OutfitPart';
    strapR.position.x = 0.115;

    const btnL = new THREE.Mesh(new THREE.SphereGeometry(0.038, 10, 10), goldMat);
    btnL.position.set(-0.115, 0.77, 0.2);
    const btnR = btnL.clone();
    btnR.position.x = 0.115;
    bodyGroup.add(shirtTorso, shoulderYoke, pelvisBlock, pelvisCap, bib, strapL, strapR, btnL, btnR);
  }

  // Accessories (Neck Bandana & Scarf)
  const makeNeckAcc = (name: string, color: string) => {
    const g = new THREE.Group();
    g.name = name;
    const m = mat(color, 0.8, 0.02, name);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(isFemale ? 0.155 : 0.195, 0.042, 8, 16), m);
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 0.9;
    const knot = new THREE.Mesh(new THREE.ConeGeometry(0.075, 0.14, 6), m);
    knot.rotation.x = Math.PI;
    knot.position.set(0, 0.83, 0.19);
    g.add(ring, knot);
    return g;
  };
  bodyGroup.add(makeNeckAcc('Acc_bandana', '#dc2626'), makeNeckAcc('Acc_scarf', '#f59e0b'));

  // Arms & ToolMount: tightly seated into shoulder sockets with rounded deltoid caps (zero gap)
  const armX = isFemale ? 0.205 : 0.285;
  const makeArm = (name: string, xOff: number, sign: number) => {
    const arm = new THREE.Group();
    arm.name = name;
    arm.position.set(xOff, 0.84, 0);
    arm.rotation.z = sign * (isFemale ? 0.075 : 0.055);
    const shoulderCap = new THREE.Mesh(
      new THREE.SphereGeometry(isFemale ? 0.082 : 0.102, 10, 8),
      shirtMat
    );
    shoulderCap.name = 'ShirtPart';
    shoulderCap.position.y = 0.01;
    const sleeve = new THREE.Mesh(
      new THREE.CylinderGeometry(isFemale ? 0.076 : 0.098, isFemale ? 0.08 : 0.1, 0.16, 12),
      shirtMat
    );
    sleeve.name = 'ShirtPart';
    sleeve.position.y = -0.07;
    const forearm = new THREE.Mesh(
      new THREE.CylinderGeometry(isFemale ? 0.058 : 0.074, isFemale ? 0.052 : 0.068, 0.16, 10),
      skinMat
    );
    forearm.name = 'SkinPart';
    forearm.position.y = -0.2;
    const glove = new THREE.Mesh(new THREE.SphereGeometry(isFemale ? 0.074 : 0.092, 10, 10), gloveMat);
    glove.position.y = -0.31;
    arm.add(shoulderCap, sleeve, forearm, glove);
    return arm;
  };
  const leftArm = makeArm('LeftArm', -armX, -1);
  const rightArm = makeArm('RightArm', armX, 1);
  const toolMount = new THREE.Group();
  toolMount.name = 'ToolMount';
  toolMount.position.set(0, -0.33, 0.08);
  rightArm.add(toolMount);
  bodyGroup.add(leftArm, rightArm);

  // Head Group
  const headGroup = new THREE.Group();
  headGroup.name = 'HeadGroup';
  headGroup.position.set(0, 1.24, 0);
  bodyGroup.add(headGroup);

  const headSphere = new THREE.Mesh(new THREE.SphereGeometry(0.355, 20, 18), skinMat);
  headSphere.name = 'SkinPart';
  headSphere.scale.set(isFemale ? 1.0 : 1.05, isFemale ? 0.96 : 0.97, 0.98);
  const earL = new THREE.Mesh(new THREE.SphereGeometry(0.075, 10, 10), skinMat);
  earL.name = 'SkinPart';
  earL.position.set(-0.345, -0.02, 0);
  const earR = earL.clone();
  earR.position.x = 0.345;
  headGroup.add(headSphere, earL, earR);

  const makeEye = (xOff: number) => {
    const eye = new THREE.Group();
    eye.position.set(xOff, -0.01, 0.315);
    const sclera = new THREE.Mesh(new THREE.SphereGeometry(0.068, 12, 12), eyeWhiteMat);
    sclera.scale.set(0.9, isFemale ? 1.32 : 1.18, 0.45);
    const iris = new THREE.Mesh(new THREE.SphereGeometry(0.052, 12, 12), eyeIrisMat);
    iris.name = 'EyeIrisPart';
    iris.scale.set(0.85, isFemale ? 1.26 : 1.15, 0.45);
    iris.position.set(0, 0, 0.018);
    const catchlight = new THREE.Mesh(new THREE.SphereGeometry(0.018, 8, 8), eyeWhiteMat);
    catchlight.position.set(0.018, 0.025, 0.036);
    eye.add(sclera, iris, catchlight);
    if (isFemale) {
      const lash = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.02, 0.02), hairMat);
      lash.position.set(xOff < 0 ? -0.01 : 0.01, 0.075, 0.025);
      lash.rotation.z = xOff < 0 ? 0.15 : -0.15;
      eye.add(lash);
    }
    return eye;
  };
  headGroup.add(makeEye(-0.135), makeEye(0.135));

  const blushL = new THREE.Mesh(new THREE.SphereGeometry(isFemale ? 0.056 : 0.044, 8, 8), blushMat);
  blushL.scale.set(1.3, 0.65, 0.3);
  blushL.position.set(-0.21, -0.1, 0.29);
  const blushR = blushL.clone();
  blushR.position.x = 0.21;
  headGroup.add(blushL, blushR);

  // Glasses
  const glasses = new THREE.Group();
  glasses.name = 'Acc_glasses';
  const frameMat = mat('#334155', 0.3, 0.8, 'GlassesMat');
  const rimL = new THREE.Mesh(new THREE.TorusGeometry(0.085, 0.012, 6, 16), frameMat);
  rimL.position.set(-0.135, -0.01, 0.355);
  const rimR = rimL.clone();
  rimR.position.x = 0.135;
  const bridge = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.015, 0.015), frameMat);
  bridge.position.set(0, -0.01, 0.355);
  glasses.add(rimL, rimR, bridge);
  headGroup.add(glasses);

  // Helper to create a clean base crown cap inside each individual Hair_* variant
  const makeCrownCap = (radius = 0.378, arc = Math.PI * 0.62) => {
    const cap = new THREE.Mesh(
      new THREE.SphereGeometry(radius, 18, 14, 0, Math.PI * 2, 0, arc),
      hairMat
    );
    cap.name = 'HairPart';
    cap.rotation.x = -0.26;
    cap.position.y = 0.035;
    return cap;
  };

  // 1. Hair_ponytail: Asymmetric side-swept fringe + sleek side locks + high back ponytail
  const hairPonytail = new THREE.Group();
  hairPonytail.name = 'Hair_ponytail';
  hairPonytail.add(makeCrownCap());
  const sweepLeft = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 10), hairMat);
  sweepLeft.name = 'HairPart';
  sweepLeft.scale.set(1.4, 0.65, 0.55);
  sweepLeft.position.set(-0.11, 0.21, 0.27);
  sweepLeft.rotation.z = 0.32;
  const sweepRight = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 10), hairMat);
  sweepRight.name = 'HairPart';
  sweepRight.scale.set(1.2, 0.6, 0.5);
  sweepRight.position.set(0.16, 0.19, 0.28);
  sweepRight.rotation.z = -0.35;
  const cheekL = new THREE.Mesh(new THREE.ConeGeometry(0.065, 0.3, 8), hairMat);
  cheekL.name = 'HairPart';
  cheekL.position.set(-0.31, -0.02, 0.16);
  cheekL.rotation.x = Math.PI;
  const cheekR = cheekL.clone();
  cheekR.name = 'HairPart';
  cheekR.position.x = 0.31;
  const tail = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.48, 10), hairMat);
  tail.name = 'HairPart';
  tail.position.set(0.12, -0.04, -0.36);
  tail.rotation.set(-0.55, 0, -0.28);
  const tie = new THREE.Mesh(new THREE.TorusGeometry(0.065, 0.022, 6, 12), mat('#dc2626', 0.7, 0, 'TieMat'));
  tie.position.set(0.08, 0.08, -0.31);
  hairPonytail.add(sweepLeft, sweepRight, cheekL, cheekR, tail, tie);
  headGroup.add(hairPonytail);

  // 2. Hair_buns: Center-parted playful curls across forehead + twin top buns
  const hairBuns = new THREE.Group();
  hairBuns.name = 'Hair_buns';
  hairBuns.add(makeCrownCap());
  const curlL = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 10), hairMat);
  curlL.name = 'HairPart';
  curlL.scale.set(1.15, 0.85, 0.55);
  curlL.position.set(-0.15, 0.2, 0.3);
  const curlR = curlL.clone();
  curlR.name = 'HairPart';
  curlR.position.x = 0.15;
  const bunL = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 12), hairMat);
  bunL.name = 'HairPart';
  bunL.position.set(-0.33, 0.27, -0.06);
  const bunR = bunL.clone();
  bunR.name = 'HairPart';
  bunR.position.x = 0.33;
  const bunRingL = new THREE.Mesh(new THREE.TorusGeometry(0.11, 0.022, 6, 12), mat('#f43f5e', 0.6, 0, 'BunBandL'));
  bunRingL.position.set(-0.27, 0.22, -0.05);
  bunRingL.rotation.y = Math.PI / 2;
  const bunRingR = bunRingL.clone();
  bunRingR.position.x = 0.27;
  hairBuns.add(curlL, curlR, bunL, bunR, bunRingL, bunRingR);
  headGroup.add(hairBuns);

  // 3. Hair_long: Soft curtain bangs framing forehead + flowing long waist back hair
  const hairLong = new THREE.Group();
  hairLong.name = 'Hair_long';
  hairLong.add(makeCrownCap(0.385, Math.PI * 0.64));
  const curtainL = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.34, 0.1), hairMat);
  curtainL.name = 'HairPart';
  curtainL.position.set(-0.22, 0.05, 0.27);
  curtainL.rotation.z = -0.18;
  const curtainR = curtainL.clone();
  curtainR.name = 'HairPart';
  curtainR.position.x = 0.22;
  curtainR.rotation.z = 0.18;
  const sideFlowL = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 0.52, 8), hairMat);
  sideFlowL.name = 'HairPart';
  sideFlowL.position.set(-0.32, -0.14, 0.08);
  const sideFlowR = sideFlowL.clone();
  sideFlowR.name = 'HairPart';
  sideFlowR.position.x = 0.32;
  const backHair = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.42, 0.62, 14), hairMat);
  backHair.name = 'HairPart';
  backHair.position.set(0, -0.22, -0.13);
  hairLong.add(curtainL, curtainR, sideFlowL, sideFlowR, backHair);
  headGroup.add(hairLong);

  // 4. Hair_spiky: Dynamic layered spiky front bangs, crown spikes, and spiky back
  const hairSpiky = new THREE.Group();
  hairSpiky.name = 'Hair_spiky';
  hairSpiky.add(makeCrownCap(0.382, Math.PI * 0.58));
  for (let i = -2; i <= 2; i++) {
    const frontSpike = new THREE.Mesh(new THREE.ConeGeometry(0.085, 0.24, 6), hairMat);
    frontSpike.name = 'HairPart';
    frontSpike.position.set(i * 0.1, 0.21 - Math.abs(i) * 0.015, 0.32);
    frontSpike.rotation.x = Math.PI * 0.78;
    frontSpike.rotation.z = i * -0.24;
    hairSpiky.add(frontSpike);

    const topSpike = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.26, 6), hairMat);
    topSpike.name = 'HairPart';
    topSpike.position.set(i * 0.11, 0.38 - Math.abs(i) * 0.03, 0.02);
    topSpike.rotation.z = -i * 0.42;
    topSpike.rotation.x = 0.2;
    hairSpiky.add(topSpike);

    const backSpike = new THREE.Mesh(new THREE.ConeGeometry(0.085, 0.24, 6), hairMat);
    backSpike.name = 'HairPart';
    backSpike.position.set(i * 0.14, 0.08, -0.25);
    backSpike.rotation.x = -Math.PI * 0.62;
    backSpike.rotation.z = -i * 0.35;
    hairSpiky.add(backSpike);
  }
  headGroup.add(hairSpiky);

  // 5. Hair_bob: Straight neat full fringe across brow + smooth rounded chin-length bob
  const hairBob = new THREE.Group();
  hairBob.name = 'Hair_bob';
  hairBob.add(makeCrownCap(0.388, Math.PI * 0.64));
  const straightFringe = new THREE.Mesh(
    new THREE.CylinderGeometry(0.37, 0.38, 0.16, 16, 1, false, -Math.PI * 0.36, Math.PI * 0.72),
    hairMat
  );
  straightFringe.name = 'HairPart';
  straightFringe.position.set(0, 0.17, 0.02);
  const bobBack = new THREE.Mesh(new THREE.SphereGeometry(0.4, 16, 12), hairMat);
  bobBack.name = 'HairPart';
  bobBack.scale.set(1.06, 0.94, 0.88);
  bobBack.position.set(0, -0.05, -0.08);
  hairBob.add(straightFringe, bobBack);
  headGroup.add(hairBob);

  // 6. Hair_short: Clean short crop with parted brow & tapered sideburns
  const hairShort = new THREE.Group();
  hairShort.name = 'Hair_short';
  hairShort.add(makeCrownCap(0.376, Math.PI * 0.6));
  const shortFore = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.1, 0.16), hairMat);
  shortFore.name = 'HairPart';
  shortFore.position.set(0, 0.23, 0.27);
  shortFore.rotation.x = 0.25;
  const sideburnL = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.16, 0.1), hairMat);
  sideburnL.name = 'HairPart';
  sideburnL.position.set(-0.33, 0.05, 0.06);
  const sideburnR = sideburnL.clone();
  sideburnR.name = 'HairPart';
  sideburnR.position.x = 0.33;
  const shortBack = new THREE.Mesh(new THREE.SphereGeometry(0.365, 12, 10), hairMat);
  shortBack.name = 'HairPart';
  shortBack.position.set(0, 0.01, -0.06);
  hairShort.add(shortFore, sideburnL, sideburnR, shortBack);
  headGroup.add(hairShort);

  // Hats
  const hatCap = new THREE.Group();
  hatCap.name = 'Hat_farmer_cap';
  const capMat = mat('#2563eb', 0.7, 0.05, 'CapMat');
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.395, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.52), capMat);
  dome.name = 'OutfitPart';
  dome.position.y = 0.07;
  const patch = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.18, 0.06, 12), mat('#f8fafc', 0.85, 0, 'PatchMat'));
  patch.rotation.x = Math.PI / 2 - 0.3;
  patch.position.set(0, 0.22, 0.32);
  const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.41, 0.42, 0.05, 16, 1, false, -Math.PI * 0.35, Math.PI * 0.7), capMat);
  brim.name = 'OutfitPart';
  brim.position.set(0, 0.08, 0.15);
  brim.rotation.x = 0.12;
  const topBtn = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), capMat);
  topBtn.name = 'OutfitPart';
  topBtn.position.y = 0.46;
  hatCap.add(dome, patch, brim, topBtn);
  headGroup.add(hatCap);

  const hatStraw = new THREE.Group();
  hatStraw.name = 'Hat_straw_hat';
  const strawMat = mat('#eab308', 0.9, 0, 'StrawMat');
  const sBrim = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.65, 0.05, 18), strawMat);
  sBrim.position.y = 0.22;
  const sCrown = new THREE.Mesh(new THREE.CylinderGeometry(0.33, 0.38, 0.24, 16), strawMat);
  sCrown.position.y = 0.35;
  const sRibbon = new THREE.Mesh(new THREE.CylinderGeometry(0.385, 0.39, 0.07, 16), mat('#dc2626', 0.7, 0, 'RibbonMat'));
  sRibbon.position.y = 0.28;
  hatStraw.add(sBrim, sCrown, sRibbon);
  headGroup.add(hatStraw);

  const hatWizard = new THREE.Group();
  hatWizard.name = 'Hat_wizard_hat';
  const wizMat = mat('#6b21a8', 0.7, 0.1, 'WizMat');
  const wBrim = new THREE.Mesh(new THREE.CylinderGeometry(0.58, 0.6, 0.04, 16), wizMat);
  wBrim.position.y = 0.24;
  const wCone = new THREE.Mesh(new THREE.ConeGeometry(0.34, 0.68, 14), wizMat);
  wCone.position.y = 0.58;
  wCone.rotation.z = -0.1;
  const wBand = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.03, 8, 16), goldMat);
  wBand.rotation.x = Math.PI / 2;
  wBand.position.y = 0.27;
  hatWizard.add(wBrim, wCone, wBand);
  headGroup.add(hatWizard);

  const hatFlower = new THREE.Group();
  hatFlower.name = 'Hat_flower_clip';
  hatFlower.position.set(0.28, 0.24, 0.18);
  const fCenter = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), mat('#facc15', 0.6, 0, 'FlowerCenter'));
  hatFlower.add(fCenter);
  const petalMat = mat('#f43f5e', 0.6, 0, 'PetalMat');
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2;
    const p = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), petalMat);
    p.position.set(Math.cos(a) * 0.06, Math.sin(a) * 0.06, 0);
    hatFlower.add(p);
  }
  headGroup.add(hatFlower);

  return root;
}

function buildToolGLB(kind: string): THREE.Group {
  const g = new THREE.Group();
  g.name = `Tool_${kind}`;
  const woodMat = mat('#b45309', 0.8, 0.05, 'WoodMat');
  const metalMat = mat('#94a3b8', 0.25, 0.85, 'MetalMat');
  const waterBlue = mat('#38bdf8', 0.4, 0.1, 'WaterCanMat');

  if (kind === 'watering_can') {
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.16, 0.22, 12), waterBlue);
    body.position.set(0, 0, 0.12);
    const spout = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.05, 0.22, 8), waterBlue);
    spout.rotation.x = Math.PI / 3;
    spout.position.set(0, 0.05, 0.28);
    const handle = new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.02, 6, 12, Math.PI), waterBlue);
    handle.position.set(0, 0.12, 0.1);
    g.add(body, spout, handle);
    return g;
  }

  if (kind === 'milk_pail') {
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.12, 0.24, 12), metalMat);
    body.position.set(0, -0.05, 0.1);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.14, 0.018, 6, 14), metalMat);
    rim.rotation.x = Math.PI / 2;
    rim.position.set(0, 0.07, 0.1);
    g.add(body, rim);
    return g;
  }

  if (kind === 'brush') {
    const base = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.06, 0.24), woodMat);
    base.position.set(0, 0, 0.15);
    const bristles = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.06, 0.22), mat('#fef3c7', 0.95, 0, 'BristleMat'));
    bristles.position.set(0, -0.05, 0.15);
    g.add(base, bristles);
    return g;
  }

  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.55, 8), woodMat);
  handle.rotation.x = Math.PI / 2;
  handle.position.z = 0.22;
  g.add(handle);

  if (kind === 'hoe' || kind === 'axe') {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.2, 0.14), metalMat);
    blade.position.set(0, -0.07, 0.45);
    g.add(blade);
  } else if (kind === 'hammer') {
    const head = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.22, 10), metalMat);
    head.position.set(0, 0, 0.46);
    g.add(head);
  } else if (kind === 'sickle') {
    const blade = new THREE.Mesh(new THREE.TorusGeometry(0.14, 0.025, 6, 12, Math.PI * 1.15), metalMat);
    blade.rotation.x = Math.PI / 2;
    blade.position.set(0.04, 0, 0.5);
    g.add(blade);
  } else if (kind === 'fishing_rod') {
    handle.scale.set(0.8, 2.2, 0.8);
    const bobber = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), mat('#ef4444', 0.4, 0.1, 'BobberMat'));
    bobber.position.set(0, -0.15, 0.9);
    g.add(bobber);
  }
  return g;
}

function buildAnimalGLB(type: 'cow' | 'chicken' | 'sheep' | 'dog' | 'horse'): THREE.Group {
  const g = new THREE.Group();
  g.name = `Animal_${type}`;

  if (type === 'chicken') {
    const white = mat('#fefce8', 0.8, 0.02, 'ChickenBody');
    const comb = mat('#ef4444', 0.6, 0.02, 'Comb');
    const beak = mat('#f59e0b', 0.5, 0.05, 'Beak');
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.25, 12, 12), white);
    body.scale.set(1, 0.9, 1.2);
    body.position.y = 0.28;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 10), white);
    head.position.set(0, 0.48, 0.22);
    const crest = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.09, 0.1), comb);
    crest.position.set(0, 0.62, 0.22);
    const bill = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.1, 6), beak);
    bill.rotation.x = Math.PI / 2;
    bill.position.set(0, 0.47, 0.38);
    g.add(body, head, crest, bill);
    return g;
  }

  const isHorse = type === 'horse';
  const isCow = type === 'cow';
  const isSheep = type === 'sheep';
  const bodyColor = isCow ? '#f8fafc' : isSheep ? '#fef3c7' : isHorse ? '#92400e' : '#d97706';
  const bodyMat = mat(bodyColor, 0.85, 0.02, 'AnimalBody');
  const darkMat = mat('#1e293b', 0.7, 0.05, 'AnimalDark');

  const torso = new THREE.Mesh(
    new THREE.CapsuleGeometry(isHorse ? 0.36 : isCow ? 0.38 : 0.32, isHorse ? 0.65 : 0.5, 6, 12),
    bodyMat
  );
  torso.rotation.x = Math.PI / 2;
  torso.position.y = isHorse ? 0.82 : 0.6;
  const head = new THREE.Mesh(new THREE.SphereGeometry(isHorse ? 0.24 : 0.26, 12, 12), bodyMat);
  head.position.set(0, isHorse ? 1.15 : 0.8, isHorse ? 0.62 : 0.48);
  g.add(torso, head);

  if (isCow) {
    const spot = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 8), darkMat);
    spot.scale.set(1.05, 0.7, 0.8);
    spot.position.set(0.22, 0.68, 0);
    const snout = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.16, 0.18), mat('#fbcfe8', 0.7, 0, 'Snout'));
    snout.position.set(0, 0.74, 0.68);
    g.add(spot, snout);
  } else if (type === 'dog') {
    const earL = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.18, 6), darkMat);
    earL.position.set(-0.15, 1.02, 0.45);
    const earR = earL.clone();
    earR.position.x = 0.15;
    const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.35, 6), bodyMat);
    tail.rotation.x = -0.6;
    tail.position.set(0, 0.78, -0.45);
    g.add(earL, earR, tail);
  }

  const legH = isHorse ? 0.62 : 0.38;
  const legGeo = new THREE.CylinderGeometry(0.07, 0.06, legH, 8);
  [
    [-0.18, 0.28],
    [0.18, 0.28],
    [-0.18, -0.28],
    [0.18, -0.28],
  ].forEach(([lx, lz]) => {
    const leg = new THREE.Mesh(legGeo, isCow || isSheep ? darkMat : bodyMat);
    leg.position.set(lx, legH / 2, lz);
    g.add(leg);
  });
  return g;
}

function buildCropGLB(variant: string): THREE.Group {
  const g = new THREE.Group();
  g.name = `Crop_${variant}`;
  const leafMat = mat('#22c55e', 0.78, 0.02, 'LeafMat');
  const darkLeafMat = mat('#15803d', 0.8, 0.02, 'DarkLeafMat');
  const fruitMat = mat('#f97316', 0.45, 0.05, 'FruitMat');

  if (variant === 'stage_0') {
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 0.14, 6), leafMat);
    stem.position.y = 0.07;
    const leaf1 = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), leafMat);
    leaf1.scale.set(1.4, 0.4, 0.8);
    leaf1.position.set(-0.07, 0.14, 0);
    const leaf2 = leaf1.clone();
    leaf2.position.x = 0.07;
    g.add(stem, leaf1, leaf2);
  } else if (variant === 'stage_1') {
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2;
      const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.28, 6), leafMat);
      leaf.position.set(Math.cos(a) * 0.07, 0.18, Math.sin(a) * 0.07);
      leaf.rotation.z = -Math.cos(a) * 0.55;
      leaf.rotation.x = Math.sin(a) * 0.55;
      g.add(leaf);
    }
  } else if (variant === 'stage_2') {
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.38, 6), darkLeafMat);
      leaf.position.set(Math.cos(a) * 0.11, 0.24, Math.sin(a) * 0.11);
      leaf.rotation.z = -Math.cos(a) * 0.65;
      leaf.rotation.x = Math.sin(a) * 0.65;
      g.add(leaf);
    }
    const bud = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), mat('#fef08a', 0.5, 0, 'BudMat'));
    bud.position.y = 0.36;
    g.add(bud);
  } else if (variant === 'crop_root') {
    const root = new THREE.Mesh(new THREE.SphereGeometry(0.2, 12, 12), fruitMat);
    root.name = 'FruitPart';
    root.scale.set(0.95, 1.15, 0.95);
    root.position.y = 0.16;
    g.add(root);
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      const topLeaf = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.38, 6), leafMat);
      topLeaf.position.set(Math.cos(a) * 0.08, 0.42, Math.sin(a) * 0.08);
      topLeaf.rotation.z = -Math.cos(a) * 0.45;
      topLeaf.rotation.x = Math.sin(a) * 0.45;
      g.add(topLeaf);
    }
  } else if (variant === 'crop_tall') {
    const stalk = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 0.9, 8), darkLeafMat);
    stalk.position.y = 0.45;
    const cob = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.22, 4, 8), fruitMat);
    cob.name = 'FruitPart';
    cob.position.set(0.11, 0.52, 0);
    cob.rotation.z = -0.35;
    g.add(stalk, cob);
  } else if (variant === 'crop_flower') {
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.52, 8), darkLeafMat);
    stem.position.y = 0.26;
    const head = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.14, 0.14, 10), fruitMat);
    head.name = 'FruitPart';
    head.position.y = 0.55;
    head.rotation.x = 0.3;
    const core = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 10), mat('#78350f', 0.8, 0, 'CoreMat'));
    core.position.set(0, 0.56, 0.06);
    g.add(stem, head, core);
  } else {
    const bush = new THREE.Mesh(new THREE.DodecahedronGeometry(0.28, 1), darkLeafMat);
    bush.position.y = 0.26;
    g.add(bush);
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2;
      const berry = new THREE.Mesh(new THREE.SphereGeometry(0.095, 10, 10), fruitMat);
      berry.name = 'FruitPart';
      berry.position.set(Math.cos(a) * 0.22, 0.28 + (i % 2) * 0.08, Math.sin(a) * 0.22);
      g.add(berry);
    }
  }
  return g;
}

function buildBuildingBaseGLB(): THREE.Group {
  const g = new THREE.Group();
  g.name = 'BuildingCottageBase';
  const wallMat = mat('#fef3c7', 0.82, 0.02, 'WallMat');
  const roofMat = mat('#dc2626', 0.72, 0.06, 'RoofMat');
  const woodMat = mat('#7c4a2d', 0.85, 0.04, 'WoodMat');
  const stoneMat = mat('#94a3b8', 0.88, 0.02, 'StoneMat');
  const winMat = mat('#fef08a', 0.2, 0.0, 'WindowMat', '#f59e0b', 0.25);

  const plinth = new THREE.Mesh(new THREE.BoxGeometry(1.06, 0.35, 1.06), stoneMat);
  plinth.position.y = 0.175;
  const body = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.0, 1.0), wallMat);
  body.name = 'WallPart';
  body.position.y = 0.85;

  const roofShape = new THREE.Shape();
  roofShape.moveTo(-0.6, 0);
  roofShape.lineTo(0.6, 0);
  roofShape.lineTo(0, 0.55);
  roofShape.closePath();
  const roofGeo = new THREE.ExtrudeGeometry(roofShape, {
    depth: 1.14,
    bevelEnabled: true,
    bevelThickness: 0.02,
    bevelSize: 0.02,
    bevelSegments: 2,
  });
  roofGeo.translate(0, 0, -0.57);
  const roof = new THREE.Mesh(roofGeo, roofMat);
  roof.name = 'RoofPart';
  roof.position.y = 1.35;

  const chimney = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.45, 0.11), mat('#b91c1c', 0.88, 0.02, 'ChimneyMat'));
  chimney.name = 'ChimneyPart';
  chimney.position.set(0.28, 1.65, -0.2);

  const door = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.55, 0.05), woodMat);
  door.position.set(0, 0.625, 0.51);
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.02, 8, 8), mat('#fbbf24', 0.25, 0.85, 'BrassKnob'));
  knob.position.set(0.06, 0.6, 0.54);

  const porchAwning = new THREE.Mesh(new THREE.BoxGeometry(0.54, 0.06, 0.24), roofMat);
  porchAwning.name = 'RoofPart';
  porchAwning.position.set(0, 0.98, 0.6);

  const winL = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.25, 0.04), winMat);
  winL.name = 'WindowPart';
  winL.position.set(-0.28, 0.88, 0.51);
  const winR = winL.clone();
  winR.name = 'WindowPart';
  winR.position.x = 0.28;

  const doorstep = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.04, 0.22), mat('#d97706', 0.9, 0, 'Doormat'));
  doorstep.position.set(0, 0.03, 0.62);

  g.add(plinth, body, roof, chimney, door, knob, porchAwning, winL, winR, doorstep);
  return g;
}

function buildEnvironmentAssets(): Array<[string, THREE.Group]> {
  const assets: Array<[string, THREE.Group]> = [];

  // 1. Shipping bin
  const bin = new THREE.Group();
  const binBox = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.1, 1.3), mat('#b45309', 0.8, 0.04, 'BinWood'));
  binBox.position.y = 0.55;
  const binLid = new THREE.Mesh(new THREE.BoxGeometry(1.92, 0.18, 1.42), mat('#d97706', 0.72, 0.05, 'BinLid'));
  binLid.position.y = 1.15;
  bin.add(binBox, binLid);
  assets.push(['environment/shipping_bin.glb', bin]);

  // 2. Fountain
  const fountain = new THREE.Group();
  const fBase = new THREE.Mesh(new THREE.CylinderGeometry(2.8, 3.1, 0.6, 18), mat('#cbd5e1', 0.78, 0.05, 'StoneMat'));
  fBase.position.y = 0.3;
  const fWater = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.4, 0.48, 18), mat('#38bdf8', 0.15, 0.1, 'WaterMat'));
  fWater.position.y = 0.38;
  const fPillar = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.7, 1.8, 12), mat('#e2e8f0', 0.7, 0.05, 'PillarMat'));
  fPillar.position.y = 1.1;
  const fTop = new THREE.Mesh(new THREE.SphereGeometry(0.42, 12, 12), mat('#38bdf8', 0.2, 0.2, 'OrbMat'));
  fTop.position.y = 2.15;
  fountain.add(fBase, fWater, fPillar, fTop);
  assets.push(['environment/fountain.glb', fountain]);

  // 3. Oak Tree
  const tree = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.42, 2.2, 8), mat('#7c4a2d', 0.9, 0.02, 'BarkMat'));
  trunk.name = 'TreeTrunk';
  trunk.position.y = 1.1;
  const crown = new THREE.Mesh(new THREE.DodecahedronGeometry(1.55, 1), mat('#22c55e', 0.85, 0.0, 'FoliageMat'));
  crown.name = 'TreeCrown';
  crown.position.y = 3.1;
  tree.add(trunk, crown);
  assets.push(['environment/tree_oak.glb', tree]);

  // 3b. Farmhouse Apple Tree (.glb)
  const appleTree = new THREE.Group();
  appleTree.name = 'AppleTreeRoot';
  const aTrunk = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.48, 2.4, 10), mat('#7c4a2d', 0.9, 0.02, 'AppleBark'));
  aTrunk.position.y = 1.2;
  const aCrown = new THREE.Mesh(new THREE.DodecahedronGeometry(1.9, 1), mat('#22c55e', 0.85, 0, 'AppleFoliage'));
  aCrown.name = 'AppleFoliage';
  aCrown.position.y = 3.35;
  appleTree.add(aTrunk, aCrown);
  const appleFruitMat = mat('#dc2626', 0.35, 0.05, 'AppleFruit');
  const appleOffsets: [number, number, number][] = [
    [-1.1, 3.0, 1.0],
    [0.9, 3.4, 1.15],
    [0.1, 2.75, 1.45],
    [-0.75, 3.85, -0.8],
    [1.15, 2.9, -0.75],
    [0.0, 4.1, 0.7],
  ];
  appleOffsets.forEach(([ax, ay, az], idx) => {
    const fruit = new THREE.Mesh(new THREE.SphereGeometry(0.19, 10, 10), appleFruitMat);
    fruit.name = `AppleFruit_${idx}`;
    fruit.position.set(ax, ay, az);
    appleTree.add(fruit);
  });
  assets.push(['environment/apple_tree.glb', appleTree]);

  // 3c. Spring Beehive (.glb)
  const beehive = new THREE.Group();
  beehive.name = 'BeehiveRoot';
  const hiveMat = mat('#eab308', 0.78, 0.04, 'HiveMat');
  const stripeMat = mat('#92400e', 0.85, 0.02, 'HiveBand');
  const hiveBody = new THREE.Mesh(new THREE.SphereGeometry(0.32, 12, 12), hiveMat);
  hiveBody.scale.set(0.95, 1.2, 0.95);
  const ring1 = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.035, 6, 14), stripeMat);
  ring1.rotation.x = Math.PI / 2;
  ring1.position.y = -0.1;
  const ring2 = ring1.clone();
  ring2.position.y = 0.1;
  const hole = new THREE.Mesh(new THREE.SphereGeometry(0.075, 8, 8), mat('#1e293b', 0.9, 0, 'HiveHole'));
  hole.position.set(0, -0.02, 0.28);
  beehive.add(hiveBody, ring1, ring2, hole);
  assets.push(['environment/beehive.glb', beehive]);

  // 4. Grass Tuft
  const grass = new THREE.Group();
  const bladeGeo = new THREE.ConeGeometry(0.06, 0.38, 3);
  bladeGeo.translate(0, 0.19, 0);
  const gMat = mat('#4ade80', 0.85, 0.0, 'GrassBladeMat');
  for (let i = 0; i < 3; i++) {
    const b = new THREE.Mesh(bladeGeo, gMat);
    b.rotation.y = (i / 3) * Math.PI * 2;
    b.rotation.z = 0.18;
    b.position.set(Math.cos(b.rotation.y) * 0.06, 0, Math.sin(b.rotation.y) * 0.06);
    grass.add(b);
  }
  assets.push(['environment/grass_tuft.glb', grass]);

  // 5. Mine Rock
  const rockG = new THREE.Group();
  const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(0.75, 0), mat('#64748b', 0.85, 0.15, 'RockMat'));
  rock.position.y = 0.45;
  rock.scale.set(1.2, 0.8, 1.0);
  rockG.add(rock);
  assets.push(['environment/mine_rock.glb', rockG]);

  // 6. Forest Log
  const logG = new THREE.Group();
  const log = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.35, 1.6, 8), mat('#7c4a2d', 0.88, 0.02, 'BarkMat'));
  log.rotation.z = Math.PI / 2;
  log.position.y = 0.3;
  logG.add(log);
  assets.push(['environment/forest_log.glb', logG]);

  // 7. Wooden Dock
  const dockG = new THREE.Group();
  const deck = new THREE.Mesh(new THREE.BoxGeometry(5.5, 0.25, 3.2), mat('#92400e', 0.82, 0.03, 'DockWood'));
  deck.position.y = 0.16;
  dockG.add(deck);
  assets.push(['environment/wooden_dock.glb', dockG]);

  // 8. Fence Post & Double-Rail 3D Wooden Fence Segment (Jumpable!)
  const fenceG = new THREE.Group();
  const fenceWood = mat('#9a5f26', 0.84, 0.03, 'FenceWood');
  const fenceCapMat = mat('#784518', 0.8, 0.04, 'FenceCap');
  const fencePostL = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.96, 0.22), fenceWood);
  fencePostL.position.set(0, 0.48, 0);
  const fenceCapL = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.08, 0.26), fenceCapMat);
  fenceCapL.position.set(0, 0.98, 0);
  const railTop = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.11, 0.09), fenceWood);
  railTop.position.set(1.5, 0.74, 0);
  const railBot = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.11, 0.09), fenceWood);
  railBot.position.set(1.5, 0.36, 0);
  const midPicket = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.84, 0.1), fenceWood);
  midPicket.position.set(1.5, 0.44, 0);
  fenceG.add(fencePostL, fenceCapL, railTop, railBot, midPicket);
  assets.push(['environment/fence_post.glb', fenceG]);

  // 8b. Alpine Pine Tree (.glb)
  const pineTree = new THREE.Group();
  const pineTrunk = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.34, 2.2, 8), mat('#5c3a21', 0.92, 0.02, 'PineBark'));
  pineTrunk.name = 'TreeTrunk';
  pineTrunk.position.y = 1.1;
  pineTree.add(pineTrunk);
  const pineLeafMat = mat('#256037', 0.86, 0.01, 'PineLeaf');
  [
    [1.72, 1.55, 2.05],
    [1.38, 1.45, 3.0],
    [1.02, 1.32, 3.85],
    [0.62, 1.05, 4.62],
  ].forEach(([r, h, y], idx) => {
    const cone = new THREE.Mesh(new THREE.ConeGeometry(r, h, 8), pineLeafMat);
    cone.name = `TreeCrown_${idx}`;
    cone.position.y = y;
    cone.rotation.y = idx * 0.45;
    pineTree.add(cone);
  });
  assets.push(['environment/tree_pine.glb', pineTree]);

  // 8c. Golden Birch Tree (.glb)
  const birchTree = new THREE.Group();
  const birchBarkMat = mat('#e7e5e4', 0.84, 0.02, 'BirchBark');
  const birchTrunk = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.24, 3.1, 8), birchBarkMat);
  birchTrunk.name = 'TreeTrunk';
  birchTrunk.position.y = 1.55;
  const birchBranch = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.1, 1.05, 6), birchBarkMat);
  birchBranch.name = 'TreeTrunkBranch';
  birchBranch.position.set(0.32, 2.55, 0.12);
  birchBranch.rotation.z = -0.55;
  birchTree.add(birchTrunk, birchBranch);
  const birchLeafMat = mat('#7ac143', 0.86, 0.01, 'BirchLeaf');
  [
    [0, 3.7, 0, 1.18, 1.42],
    [0.62, 3.25, 0.24, 0.82, 0.95],
    [-0.58, 3.32, -0.22, 0.86, 0.96],
    [0.12, 4.48, -0.1, 0.78, 0.92],
  ].forEach(([x, y, z, rx, ry], idx) => {
    const puff = new THREE.Mesh(new THREE.DodecahedronGeometry(rx, 1), birchLeafMat);
    puff.name = `TreeCrown_${idx}`;
    puff.scale.set(1, ry / rx, 1);
    puff.position.set(x, y, z);
    birchTree.add(puff);
  });
  assets.push(['environment/tree_birch.glb', birchTree]);

  // 8d. Cozy Wooden Doghouse (.glb)
  const doghouseG = new THREE.Group();
  const dhWallMat = mat('#b47b47', 0.86, 0.02, 'DoghouseWood');
  const dhRoofMat = mat('#b91c1c', 0.74, 0.05, 'DoghouseRoof');
  const dhBody = new THREE.Mesh(new THREE.BoxGeometry(1.26, 0.86, 1.36), dhWallMat);
  dhBody.position.y = 0.43;
  const dhDoorVoid = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.54, 0.08), mat('#1c1917', 0.98, 0, 'DoghouseDoor'));
  dhDoorVoid.position.set(0, 0.27, 0.66);
  const dhRoofGeo = new THREE.ConeGeometry(1.16, 0.62, 4);
  dhRoofGeo.rotateY(Math.PI / 4);
  const dhRoof = new THREE.Mesh(dhRoofGeo, dhRoofMat);
  dhRoof.scale.set(1.04, 1.0, 1.14);
  dhRoof.position.y = 1.12;
  const dhSign = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.14, 0.06), mat('#fef3c7', 0.7, 0.05, 'DoghouseSign'));
  dhSign.position.set(0, 0.72, 0.69);
  doghouseG.add(dhBody, dhDoorVoid, dhRoof, dhSign);
  assets.push(['environment/doghouse.glb', doghouseG]);

  // 8e. Outdoor Dog Food Bowl (.glb)
  const dogBowlG = new THREE.Group();
  const bowlRim = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.35, 0.16, 16), mat('#dc2626', 0.42, 0.15, 'DogBowlRim'));
  bowlRim.position.y = 0.08;
  const kibble = new THREE.Mesh(new THREE.SphereGeometry(0.21, 10, 8), mat('#78350f', 0.92, 0.02, 'DogKibble'));
  kibble.scale.set(1, 0.45, 1);
  kibble.position.y = 0.15;
  dogBowlG.add(bowlRim, kibble);
  assets.push(['environment/dog_bowl.glb', dogBowlG]);

  // 8f. Lush Flowering Bush / Hedge (.glb)
  const bushG = new THREE.Group();
  const bushLeaf = mat('#2f6e2b', 0.9, 0.01, 'BushLeaf');
  const bushLeaf2 = mat('#3f8a36', 0.88, 0.01, 'BushLeafHighlight');
  const b1 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.95, 1), bushLeaf);
  b1.scale.set(1.25, 0.85, 1.15);
  b1.position.y = 0.62;
  const b2 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.72, 1), bushLeaf2);
  b2.position.set(0.55, 0.54, 0.22);
  const b3 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.68, 1), bushLeaf2);
  b3.position.set(-0.52, 0.5, -0.18);
  bushG.add(b1, b2, b3);
  assets.push(['environment/bush_hedge.glb', bushG]);

  // 8g. Artisan Cheese Maker (.glb)
  const cheeseMakerG = new THREE.Group();
  const cmWood = mat('#8b5a2b', 0.82, 0.05, 'CheesePressWood');
  const cmMetal = mat('#cbd5e1', 0.35, 0.78, 'CheesePressSteel');
  const cmVat = new THREE.Mesh(new THREE.CylinderGeometry(0.58, 0.64, 0.78, 16), cmMetal);
  cmVat.position.y = 0.39;
  const cmBand = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.045, 8, 20), cmWood);
  cmBand.rotation.x = Math.PI / 2;
  cmBand.position.y = 0.56;
  const cmWheel = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.22, 16), mat('#facc15', 0.68, 0.04, 'CheeseWheel'));
  cmWheel.position.y = 0.88;
  const cmScrew = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.65, 8), cmMetal);
  cmScrew.position.y = 1.25;
  const cmHandle = new THREE.Mesh(new THREE.BoxGeometry(0.66, 0.08, 0.08), cmWood);
  cmHandle.position.y = 1.54;
  cheeseMakerG.add(cmVat, cmBand, cmWheel, cmScrew, cmHandle);
  assets.push(['environment/cheese_maker.glb', cheeseMakerG]);

  // 8h. Egg Incubator Box (.glb)
  const incG = new THREE.Group();
  const incWood = mat('#9a6230', 0.84, 0.04, 'IncubatorWood');
  const incBase = new THREE.Mesh(new THREE.BoxGeometry(1.12, 0.72, 0.96), incWood);
  incBase.position.y = 0.36;
  const incStraw = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.44, 0.14, 12), mat('#eab308', 0.92, 0.0, 'IncubatorStraw'));
  incStraw.position.y = 0.76;
  const incLamp = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 10), mat('#fef08a', 0.25, 0.1, 'IncubatorLamp', '#f59e0b', 0.95));
  incLamp.position.set(0.34, 0.96, -0.22);
  incG.add(incBase, incStraw, incLamp);
  assets.push(['environment/egg_incubator.glb', incG]);

  // 9. Secret Shrine
  const shrine = new THREE.Group();
  const sMat = mat('#64748b', 0.9, 0.05, 'ShrineStone');
  const pL = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.5, 3.2, 8), sMat);
  pL.position.set(-1.8, 1.6, 0);
  const pR = pL.clone();
  pR.position.x = 1.8;
  const rune = new THREE.Mesh(new THREE.OctahedronGeometry(0.55, 0), mat('#a855f7', 0.25, 0.3, 'RuneCrystal', '#a855f7', 0.5));
  rune.name = 'RunePart';
  rune.position.set(0, 2.8, 0);
  shrine.add(pL, pR, rune);
  assets.push(['environment/secret_shrine.glb', shrine]);

  // 10. Farm Tile (organic rounded earth mound, not a rigid square grid block)
  const tileG = new THREE.Group();
  const tile = new THREE.Mesh(new THREE.CylinderGeometry(0.74, 0.86, 0.09, 14), mat('#6b4423', 0.94, 0, 'SoilMat'));
  tile.name = 'SoilMesh';
  tile.scale.set(1.04, 1.0, 0.96);
  tile.position.y = 0.035;
  tileG.add(tile);
  assets.push(['environment/farm_tile.glb', tileG]);

  // 10b. Farm Yard Natural Obstacles: Weed, Tree Root/Stump, Young Sapling
  const weedG = new THREE.Group();
  const weedMat = mat('#3f7f2b', 0.92, 0.0, 'WeedLeaf');
  for (let i = 0; i < 6; i++) {
    const blade = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.52 + (i % 2) * 0.14, 5), weedMat);
    const a = (i / 6) * Math.PI * 2;
    blade.position.set(Math.cos(a) * 0.18, 0.24, Math.sin(a) * 0.18);
    blade.rotation.z = Math.cos(a) * 0.35;
    blade.rotation.x = Math.sin(a) * 0.35;
    weedG.add(blade);
  }
  assets.push(['environment/farm_weed.glb', weedG]);

  const rootG = new THREE.Group();
  const rootWood = mat('#6e4726', 0.92, 0.02, 'RootWood');
  const stump = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.42, 0.5, 8), rootWood);
  stump.position.y = 0.25;
  rootG.add(stump);
  for (let i = 0; i < 4; i++) {
    const flare = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.16, 0.18), rootWood);
    const a = (i / 4) * Math.PI * 2 + 0.4;
    flare.position.set(Math.cos(a) * 0.36, 0.09, Math.sin(a) * 0.36);
    flare.rotation.y = -a;
    flare.rotation.z = -0.22;
    rootG.add(flare);
  }
  assets.push(['environment/farm_root.glb', rootG]);

  const saplingG = new THREE.Group();
  const sapTrunk = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.13, 0.95, 7), mat('#784c2a', 0.9, 0.02, 'SaplingWood'));
  sapTrunk.position.y = 0.47;
  const sapCrown1 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.45, 0), mat('#4ca638', 0.88, 0, 'SaplingLeaf'));
  sapCrown1.position.y = 1.05;
  const sapCrown2 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.32, 0), mat('#62bd49', 0.88, 0, 'SaplingLeaf2'));
  sapCrown2.position.set(0.16, 1.32, 0.1);
  saplingG.add(sapTrunk, sapCrown1, sapCrown2);
  assets.push(['environment/farm_sapling.glb', saplingG]);

  // 10c. Mountain Cave Entrance & Glowing Ore Vein
  const caveG = new THREE.Group();
  const caveStone = mat('#475569', 0.92, 0.06, 'CaveRock');
  const caveDark = mat('#0f172a', 0.98, 0.0, 'CaveVoid');
  const archL = new THREE.Mesh(new THREE.DodecahedronGeometry(2.1, 1), caveStone);
  archL.position.set(-2.3, 1.8, 0);
  archL.scale.set(0.95, 1.4, 1.1);
  const archR = archL.clone();
  archR.position.set(2.3, 1.8, 0);
  const archTop = new THREE.Mesh(new THREE.DodecahedronGeometry(2.5, 1), caveStone);
  archTop.position.set(0, 3.6, -0.2);
  archTop.scale.set(1.6, 0.85, 1.1);
  const voidPortal = new THREE.Mesh(new THREE.CylinderGeometry(1.7, 1.8, 0.3, 16), caveDark);
  voidPortal.rotation.x = Math.PI / 2;
  voidPortal.position.set(0, 1.7, 0.2);
  const torchMat = mat('#fbbf24', 0.3, 0.1, 'CaveTorch', '#f59e0b', 1.2);
  const lanternL = new THREE.Mesh(new THREE.OctahedronGeometry(0.28, 0), torchMat);
  lanternL.position.set(-2.0, 2.2, 1.3);
  const lanternR = lanternL.clone();
  lanternR.position.x = 2.0;
  caveG.add(archL, archR, archTop, voidPortal, lanternL, lanternR);
  assets.push(['environment/cave_entrance.glb', caveG]);

  const oreG = new THREE.Group();
  const oreBase = new THREE.Mesh(new THREE.DodecahedronGeometry(0.75, 0), mat('#475569', 0.9, 0.08, 'OreRock'));
  oreBase.position.y = 0.5;
  oreBase.scale.set(1.1, 0.85, 1.0);
  const oreCrystalMat = mat('#38bdf8', 0.25, 0.35, 'OreCrystal', '#0284c7', 0.65);
  const cr1 = new THREE.Mesh(new THREE.OctahedronGeometry(0.26, 0), oreCrystalMat);
  cr1.position.set(0.22, 0.88, 0.15);
  cr1.rotation.z = -0.3;
  const cr2 = new THREE.Mesh(new THREE.OctahedronGeometry(0.2, 0), oreCrystalMat);
  cr2.position.set(-0.24, 0.78, -0.1);
  cr2.rotation.z = 0.4;
  oreG.add(oreBase, cr1, cr2);
  assets.push(['environment/ore_vein.glb', oreG]);

  // 11. Interior Farmhouse & Town Furniture (.glb)
  const woodM = mat('#7c4a2d', 0.8, 0.05, 'BedWood');

  const bed = new THREE.Group();
  const bedFrame = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.55, 2.8), woodM);
  bedFrame.position.y = 0.28;
  const blanket = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.2, 2.0), mat('#3a6b2c', 0.85, 0, 'Blanket'));
  blanket.position.set(0, 0.62, 0.4);
  const pillow = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.22, 0.6), mat('#ffffff', 0.8, 0, 'Pillow'));
  pillow.position.set(0, 0.66, -0.9);
  bed.add(bedFrame, blanket, pillow);
  assets.push(['environment/interior_bed.glb', bed]);

  const table = new THREE.Group();
  const tTop = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.14, 1.4), woodM);
  tTop.position.y = 0.78;
  table.add(tTop);
  [
    [-0.9, -0.55],
    [0.9, -0.55],
    [-0.9, 0.55],
    [0.9, 0.55],
  ].forEach(([lx, lz]) => {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.76, 0.14), woodM);
    leg.position.set(lx, 0.38, lz);
    table.add(leg);
  });
  assets.push(['environment/interior_table.glb', table]);

  const chair = new THREE.Group();
  const seat = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.1, 0.7), woodM);
  seat.position.y = 0.45;
  const backrest = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.65, 0.1), woodM);
  backrest.position.set(0, 0.8, -0.3);
  chair.add(seat, backrest);
  [
    [-0.26, -0.26],
    [0.26, -0.26],
    [-0.26, 0.26],
    [0.26, 0.26],
  ].forEach(([lx, lz]) => {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.44, 0.1), woodM);
    leg.position.set(lx, 0.22, lz);
    chair.add(leg);
  });
  assets.push(['environment/interior_chair.glb', chair]);

  // TV Stand & CRT/Vintage Farmhouse TV
  const tv = new THREE.Group();
  const tvStand = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.65, 0.75), woodM);
  tvStand.position.y = 0.325;
  const tvBox = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.85, 0.65), mat('#334155', 0.5, 0.2, 'TvCase'));
  tvBox.position.y = 1.08;
  const tvScreen = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.62, 0.06), mat('#38bdf8', 0.2, 0.1, 'TvScreen', '#7dd3fc', 0.45));
  tvScreen.position.set(0, 1.08, 0.32);
  const antL = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.45, 6), mat('#cbd5e1', 0.3, 0.8, 'Antenna'));
  antL.position.set(-0.2, 1.68, 0);
  antL.rotation.z = 0.4;
  const antR = antL.clone();
  antR.position.x = 0.2;
  antR.rotation.z = -0.4;
  tv.add(tvStand, tvBox, tvScreen, antL, antR);
  assets.push(['environment/interior_tv.glb', tv]);

  // Farmhouse Fridge / Kulkas
  const fridge = new THREE.Group();
  const fUpper = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.35, 0.95), mat('#f1f5f9', 0.35, 0.15, 'FridgeBody'));
  fUpper.position.y = 0.7;
  const freezerTop = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.6, 0.95), mat('#e2e8f0', 0.35, 0.15, 'FreezerBody'));
  freezerTop.position.y = 1.7;
  const fHandle1 = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.45, 0.08), mat('#64748b', 0.3, 0.8, 'FridgeHandle'));
  fHandle1.position.set(0.38, 1.0, 0.5);
  const fHandle2 = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.28, 0.08), mat('#64748b', 0.3, 0.8, 'FridgeHandle'));
  fHandle2.position.set(0.38, 1.7, 0.5);
  fridge.add(fUpper, freezerTop, fHandle1, fHandle2);
  assets.push(['environment/interior_fridge.glb', fridge]);

  // Farmhouse Toolbox Chest
  const toolbox = new THREE.Group();
  const chest = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.75, 0.8), mat('#b45309', 0.75, 0.1, 'ChestWood'));
  chest.position.y = 0.375;
  const lid = new THREE.Mesh(new THREE.BoxGeometry(1.36, 0.18, 0.86), mat('#9e3b24', 0.6, 0.2, 'ChestLid'));
  lid.position.y = 0.84;
  const latch = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.18, 0.08), mat('#f59e0b', 0.25, 0.85, 'ChestLatch'));
  latch.position.set(0, 0.76, 0.43);
  toolbox.add(chest, lid, latch);
  assets.push(['environment/interior_toolbox.glb', toolbox]);

  // Farmhouse Wardrobe (Closet for switching outfits)
  const wardrobe = new THREE.Group();
  const wBody = new THREE.Mesh(new THREE.BoxGeometry(1.65, 2.35, 0.85), woodM);
  wBody.position.y = 1.175;
  const wDoorLine = new THREE.Mesh(new THREE.BoxGeometry(0.04, 2.0, 0.05), mat('#451a03', 0.85, 0.05, 'WardrobeTrim'));
  wDoorLine.position.set(0, 1.15, 0.43);
  const wKnobL = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), mat('#f59e0b', 0.25, 0.85, 'WardrobeKnob'));
  wKnobL.position.set(-0.18, 1.15, 0.46);
  const wKnobR = wKnobL.clone();
  wKnobR.position.x = 0.18;
  const wTopTrim = new THREE.Mesh(new THREE.BoxGeometry(1.78, 0.14, 0.94), mat('#653a20', 0.8, 0.05, 'WardrobeCrown'));
  wTopTrim.position.y = 2.4;
  wardrobe.add(wBody, wDoorLine, wKnobL, wKnobR, wTopTrim);
  assets.push(['environment/interior_wardrobe.glb', wardrobe]);

  const counter = new THREE.Group();
  const cMesh = new THREE.Mesh(new THREE.BoxGeometry(4.4, 1.0, 1.1), woodM);
  cMesh.position.y = 0.5;
  counter.add(cMesh);
  assets.push(['environment/interior_counter.glb', counter]);

  const shelf = new THREE.Group();
  const shMesh = new THREE.Mesh(new THREE.BoxGeometry(1.2, 2.6, 3.2), woodM);
  shMesh.position.y = 1.3;
  shelf.add(shMesh);
  assets.push(['environment/interior_shelf.glb', shelf]);

  const anvil = new THREE.Group();
  const aMesh = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.85, 0.7), mat('#334155', 0.35, 0.85, 'AnvilMetal'));
  aMesh.position.y = 0.425;
  anvil.add(aMesh);
  assets.push(['environment/interior_anvil.glb', anvil]);

  const forge = new THREE.Group();
  const fBody = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.8, 1.4), mat('#1e293b', 0.8, 0.2, 'ForgeStone'));
  fBody.position.y = 0.9;
  const ember = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.5, 0.6), mat('#f97316', 0.4, 0, 'Ember', '#ef4444', 1.4));
  ember.position.set(0, 0.7, 0.6);
  forge.add(fBody, ember);
  assets.push(['environment/interior_forge.glb', forge]);

  assets.push(['environment/building_cottage.glb', buildBuildingBaseGLB()]);

  // 12. Hill Mound & Mountain Peak
  const hillG = new THREE.Group();
  const hillMesh = new THREE.Mesh(new THREE.SphereGeometry(12, 14, 10), mat('#4d9e38', 0.94, 0, 'HillMat'));
  hillMesh.scale.set(1.3, 0.55, 1.3);
  hillG.add(hillMesh);
  assets.push(['environment/hill_mound.glb', hillG]);

  const peakG = new THREE.Group();
  const peakMesh = new THREE.Mesh(new THREE.ConeGeometry(12, 18, 8), mat('#64748b', 0.9, 0.05, 'CliffMat'));
  peakMesh.position.y = 9;
  peakG.add(peakMesh);
  assets.push(['environment/mountain_peak.glb', peakG]);

  // 13. Barn Stall & Cow/Sheep Hay Trough
  const stallG = new THREE.Group();
  const stallWood = mat('#8b5a2b', 0.85, 0.03, 'StallWood');
  const hayMat = mat('#eab308', 0.95, 0.0, 'HayMat');
  const postL = new THREE.Mesh(new THREE.BoxGeometry(0.22, 1.4, 0.22), stallWood);
  postL.position.set(-1.3, 0.7, 0);
  const postR = postL.clone();
  postR.position.x = 1.3;
  const topRail = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.16, 0.16), stallWood);
  topRail.position.set(0, 1.25, 0);
  const trough = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.45, 0.75), stallWood);
  trough.position.set(0, 0.225, 0.45);
  const hay = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.25, 0.55), hayMat);
  hay.position.set(0, 0.48, 0.45);
  stallG.add(postL, postR, topRail, trough, hay);
  assets.push(['environment/interior_barn_stall.glb', stallG]);

  // 14. Chicken Coop Nesting Box & Chicken Grain Feeder
  const nestG = new THREE.Group();
  const nestWood = mat('#a16207', 0.85, 0.03, 'CoopWood');
  const nestBox = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.85, 0.9), nestWood);
  nestBox.position.y = 0.425;
  const straw1 = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.35, 0.16, 10), hayMat);
  straw1.position.set(-0.6, 0.88, 0);
  const straw2 = straw1.clone();
  straw2.position.x = 0.6;
  nestG.add(nestBox, straw1, straw2);
  assets.push(['environment/interior_coop_nest.glb', nestG]);

  const feederG = new THREE.Group();
  const tray = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.25, 0.6), mat('#94a3b8', 0.4, 0.6, 'FeederMetal'));
  tray.position.y = 0.125;
  const grain = new THREE.Mesh(new THREE.BoxGeometry(1.55, 0.14, 0.42), mat('#facc15', 0.9, 0, 'GrainMat'));
  grain.position.y = 0.24;
  feederG.add(tray, grain);
  assets.push(['environment/interior_chicken_feeder.glb', feederG]);

  // 15. Town Square (Alun-Alun) Props: Market Stall, Festival Stage, Park Bench
  const marketStall = new THREE.Group();
  const stCounter = new THREE.Mesh(new THREE.BoxGeometry(2.8, 1.0, 1.3), woodM);
  stCounter.position.y = 0.5;
  const stPostL = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2.4, 8), woodM);
  stPostL.position.set(-1.3, 1.2, -0.5);
  const stPostR = stPostL.clone();
  stPostR.position.x = 1.3;
  const stAwning = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.25, 1.8), mat('#b91c1c', 0.78, 0.03, 'StallAwning'));
  stAwning.position.set(0, 2.4, 0.1);
  stAwning.rotation.x = 0.18;
  marketStall.add(stCounter, stPostL, stPostR, stAwning);
  assets.push(['environment/market_stall.glb', marketStall]);

  const festStage = new THREE.Group();
  const stageDeck = new THREE.Mesh(new THREE.BoxGeometry(9.0, 0.7, 5.5), woodM);
  stageDeck.position.y = 0.35;
  const stageRoof = new THREE.Mesh(new THREE.ConeGeometry(5.6, 2.2, 4), mat('#d97706', 0.7, 0.05, 'PavilionRoof'));
  stageRoof.rotation.y = Math.PI / 4;
  stageRoof.position.y = 4.5;
  festStage.add(stageDeck, stageRoof);
  [
    [-3.8, -2.2],
    [3.8, -2.2],
    [-3.8, 2.2],
    [3.8, 2.2],
  ].forEach(([px, pz]) => {
    const col = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.2, 3.3, 8), woodM);
    col.position.set(px, 2.0, pz);
    festStage.add(col);
  });
  assets.push(['environment/festival_stage.glb', festStage]);

  const bench = new THREE.Group();
  const bSeat = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.14, 0.65), woodM);
  bSeat.position.y = 0.45;
  const bBack = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.55, 0.12), woodM);
  bBack.position.set(0, 0.8, -0.26);
  const bLegL = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.45, 0.6), mat('#334155', 0.5, 0.6, 'BenchIron'));
  bLegL.position.set(-0.85, 0.225, 0);
  const bLegR = bLegL.clone();
  bLegR.position.x = 0.85;
  bench.add(bSeat, bBack, bLegL, bLegR);
  assets.push(['environment/park_bench.glb', bench]);

  return assets;
}

async function main() {
  console.log('Generating binary .glb assets in public/assets/glb/ ...');
  await exportGLB(buildChibiCharacterGLB('male'), 'characters/chibi_male.glb');
  await exportGLB(buildChibiCharacterGLB('female'), 'characters/chibi_female.glb');
  // Keep chibi_character.glb updated as male fallback compatibility
  await exportGLB(buildChibiCharacterGLB('male'), 'characters/chibi_character.glb');

  for (const kind of ['hoe', 'watering_can', 'axe', 'hammer', 'sickle', 'fishing_rod', 'milk_pail', 'brush']) {
    await exportGLB(buildToolGLB(kind), `tools/tool_${kind}.glb`);
  }

  for (const animal of ['cow', 'chicken', 'sheep', 'dog', 'horse'] as const) {
    await exportGLB(buildAnimalGLB(animal), `animals/${animal}.glb`);
  }

  for (const crop of ['stage_0', 'stage_1', 'stage_2', 'crop_root', 'crop_tall', 'crop_bush', 'crop_flower']) {
    await exportGLB(buildCropGLB(crop), `crops/${crop}.glb`);
  }

  for (const [relPath, group] of buildEnvironmentAssets()) {
    await exportGLB(group, relPath);
  }

  console.log('All .glb binary assets successfully created!');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
