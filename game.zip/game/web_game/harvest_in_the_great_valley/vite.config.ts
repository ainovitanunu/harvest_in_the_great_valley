import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';

const projectDir = path.dirname(fileURLToPath(import.meta.url));
const runtimeBaseDir = process.env.HARVEST_RUNTIME_DIR
  ? path.resolve(process.env.HARVEST_RUNTIME_DIR)
  : null;
const runtimeBuildDir = runtimeBaseDir
  ? path.join(runtimeBaseDir, 'data_game', 'build')
  : path.join(projectDir, 'dist');
const runtimeCacheDir = runtimeBaseDir
  ? path.join(runtimeBaseDir, 'data_game', 'vite_cache')
  : undefined;

// Resolve nearest node_modules (supports standalone Windows Bun install AND monorepo/AI Studio host)
function findNearestNodeModules(startDir: string): string {
  let dir = path.resolve(startDir);
  while (true) {
    const candidate = path.join(dir, 'node_modules');
    if (fs.existsSync(path.join(candidate, 'react', 'package.json'))) return candidate;
    const parent = path.dirname(dir);
    if (parent === dir) return path.join(process.cwd(), 'node_modules');
    dir = parent;
  }
}

const nodeModulesDir = findNearestNodeModules(projectDir);
const webGameRoot = path.resolve(projectDir, '..');
const siblingDevPanelPath = path.resolve(webGameRoot, 'dev_panel', 'src', 'DevPanel.tsx');
const localDevPanelPath = path.resolve(projectDir, 'src', 'components', 'DevPanel.tsx');
const resolvedDevPanelPath = fs.existsSync(siblingDevPanelPath)
  ? siblingDevPanelPath
  : localDevPanelPath;

export default defineConfig({
  root: projectDir,
  cacheDir: runtimeCacheDir,
  plugins: [
    react(),
    tailwindcss(),
    {
      name: 'copy-unbundled-src-assets',
      apply: 'build',
      closeBundle(error?: Error) {
        if (error) return;
        const srcAssets = path.join(projectDir, 'src', 'assets');
        const outputAssets = path.join(runtimeBuildDir, 'src', 'assets');
        if (fs.existsSync(srcAssets)) {
          fs.mkdirSync(path.dirname(outputAssets), { recursive: true });
          fs.cpSync(srcAssets, outputAssets, { recursive: true, force: true });
        }
      },
    },
  ],
  build: {
    outDir: runtimeBuildDir,
    emptyOutDir: true,
  },
  resolve: {
    alias: {
      '@': projectDir,
      '@dev-panel/DevPanel': resolvedDevPanelPath,
      react: path.join(nodeModulesDir, 'react'),
      'react-dom': path.join(nodeModulesDir, 'react-dom'),
      'lucide-react': path.join(nodeModulesDir, 'lucide-react'),
    },
    dedupe: ['react', 'react-dom'],
  },
  server: {
    host: '0.0.0.0',
    port: 3000,
    allowedHosts: true,
    fs: {
      allow: [projectDir, webGameRoot, nodeModulesDir],
    },
    hmr: process.env.DISABLE_HMR !== 'true',
    watch: process.env.DISABLE_HMR === 'true' ? null : {},
  },
});
