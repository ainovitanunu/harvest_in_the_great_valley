import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import http from 'http';
import https from 'https';
import path from 'path';
import crypto from 'crypto';
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, unlinkSync, writeFileSync } from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { WebSocketServer, WebSocket } from 'ws';
import { applicationDefault, cert, getApps, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
import { ITEMS, CROPS } from './src/game/data/itemsAndCrops.js';
import { ALL_VALID_HAIRSTYLE_IDS } from './src/game/data/hairstyles.js';
import {
  ANNOUNCEMENT_BANNER_CONFIG,
  CAMERA_CONFIG,
  CAVE_MINING_CONFIG,
  DEFAULT_GLOBAL_THEME,
  DEFAULT_MOBILE_GAMEPAD_LAYOUT,
  DEVELOPER_DEBUG_MODE,
  FISHING_CONFIG,
  GLOBAL_TREE_ECOSYSTEM,
  GUEST_SESSION_CONFIG,
  ITEM_TRADE_RATES,
  MARKET_ECONOMY_CONFIG,
  ECONOMY_TAX_CONFIG,
  NAME_CHANGE_ECONOMY_CONFIG,
  MOBILE_CONTROLS_CONFIG,
  NORMAL_STARTER_DIAMOND,
  NORMAL_STARTER_GOLD,
  PAYMENT_METHODS,
  PERFORMANCE_CONFIG,
  PUBLIC_GAME_ENV_DEFAULTS,
  SKY_ATMOSPHERE_CONFIG,
  VIDEO_CALL_CONFIG,
  WEATHER_CONTROL,
  WORLD_TIME_OVERRIDE,
  createEmptySalesStats,
} from './src/game/data/gameRuntimeConfig.js';
import {
  BUILDING_PORTALS,
  DEFAULT_WEATHER,
  DIAMOND_PACKAGES,
  FESTIVALS,
  SEASON_DAYS,
  TOTAL_DAYS_PER_YEAR,
  dayOfYearToSeasonDay,
  getDaysInSeason,
  getSynchronizedWorldClock,
} from './src/game/data/worldConfig.js';
import { NPCS, getNpcRoutineSlot } from './src/game/data/npcs.js';
import type {
  AdminInventoryUpdate,
  AnnouncementCategory,
  AuditLogEntry,
  AvatarConfig,
  BanType,
  BranchingDialogueNode,
  CharacterRosterEntry,
  ChatMessage,
  CustomShopProduct,
  FarmJobOffer,
  FarmJobTaskType,
  FarmPlotState,
  FriendRecord,
  FriendRequestRecord,
  GlobalTreeEcosystemConfig,
  GuestSessionConfig,
  IAPTransaction,
  ItemDef,
  LeaderboardRecord,
  MarketplaceCategory,
  MarketPriceEntry,
  MarketState,
  NPCRoutineSlot,
  NpcScheduleOverride,
  OnlinePlayerState,
  P2PMarketListing,
  PlayerBanRecord,
  PublicGameEnvConfig,
  RuntimeGameConfig,
  SalesStats,
  Season,
  SkyAtmosphereConfig,
  SocialProviderId,
  ThemeMode,
  TransactionRecord,
  Weather,
  WorldTimeOverrideConfig,
  WorldTreeRecord,
  WorldZoneId,
} from './src/game/types.js';

dotenv.config({ path: process.env.GAME_ENV_FILE || path.resolve(process.cwd(), '.env') });

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Firebase Admin credentials:
// 1) FIREBASE_SERVICE_ACCOUNT_JSON (explicit JSON string), or
// 2) GOOGLE_APPLICATION_CREDENTIALS (standard Google ADC path), or
// 3) ./web_game/data/data_game/game_secrets/firebase-admin.json (or ../data/data_game/game_secrets/ when repacked).
const RESOLVED_WEB_GAME_DIR = process.env.WEB_GAME_DIR
  ? path.resolve(process.env.WEB_GAME_DIR)
  : path.basename(__dirname) === 'harvest_in_the_great_valley'
    ? path.resolve(__dirname, '..')
    : path.resolve(__dirname, 'web_game');
const gameSecretsFirebasePath = path.resolve(RESOLVED_WEB_GAME_DIR, 'data', 'data_game', 'game_secrets', 'firebase-admin.json');
const legacyServiceAccountPath = path.resolve(__dirname, 'secrets', 'firebase-admin.json');
const localServiceAccountPath = existsSync(gameSecretsFirebasePath) ? gameSecretsFirebasePath : legacyServiceAccountPath;
const adcServiceAccountPath = process.env.GOOGLE_APPLICATION_CREDENTIALS;
const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;

const isValidFirebaseProjectId = (value: unknown): value is string => {
  if (typeof value !== 'string') return false;
  const trimmed = value.trim();
  if (!trimmed) return false;
  if (/^(value_|MY_|remixed-|your-|placeholder)/i.test(trimmed)) return false;
  return /^[a-z][a-z0-9-]{4,29}$/.test(trimmed);
};

let appletConfigProjectId: string | null = null;
const appletConfigPath = path.resolve(__dirname, 'firebase-applet-config.json');
if (existsSync(appletConfigPath)) {
  try {
    const parsedAppletConfig = JSON.parse(readFileSync(appletConfigPath, 'utf8')) as { projectId?: string };
    if (isValidFirebaseProjectId(parsedAppletConfig?.projectId)) {
      appletConfigProjectId = parsedAppletConfig.projectId.trim();
    }
  } catch {
    console.warn('[Firebase Admin] Ignoring unreadable firebase-applet-config.json.');
  }
}

const envFirebaseProjectId = isValidFirebaseProjectId(process.env.FIREBASE_PROJECT_ID)
  ? process.env.FIREBASE_PROJECT_ID!.trim()
  : null;

let firebaseAdminCredential: ReturnType<typeof applicationDefault> | null = null;
let firebaseProjectId = envFirebaseProjectId || appletConfigProjectId || 'harvest-great-valley';
let firebaseAdminCredentialSource = 'public-jwks-only';
let loadedExplicitServiceAccount = false;

if (serviceAccountJson && serviceAccountJson.trim().startsWith('{')) {
  try {
    const serviceAccount = JSON.parse(serviceAccountJson);
    if (serviceAccount?.project_id && serviceAccount?.client_email && serviceAccount?.private_key) {
      firebaseAdminCredential = cert(serviceAccount);
      firebaseProjectId =
        envFirebaseProjectId ||
        (isValidFirebaseProjectId(serviceAccount.project_id) ? serviceAccount.project_id : null) ||
        appletConfigProjectId ||
        firebaseProjectId;
      firebaseAdminCredentialSource = 'FIREBASE_SERVICE_ACCOUNT_JSON';
      loadedExplicitServiceAccount = true;
    } else {
      console.warn('[Firebase Admin] Ignoring incomplete FIREBASE_SERVICE_ACCOUNT_JSON; falling back to local file or public JWKS token verification.');
    }
  } catch {
    console.warn('[Firebase Admin] Ignoring invalid/placeholder FIREBASE_SERVICE_ACCOUNT_JSON; falling back to local file or public JWKS token verification.');
  }
}

if (!loadedExplicitServiceAccount) {
  const configuredCredentialPath = adcServiceAccountPath
    ? path.resolve(process.cwd(), adcServiceAccountPath)
    : '';
  const credentialPath = (configuredCredentialPath && existsSync(configuredCredentialPath))
    ? configuredCredentialPath
    : localServiceAccountPath;

  if (existsSync(credentialPath)) {
    try {
      const serviceAccount = JSON.parse(readFileSync(credentialPath, 'utf8'));
      if (serviceAccount?.project_id && serviceAccount?.client_email && serviceAccount?.private_key) {
        firebaseAdminCredential = cert(serviceAccount);
        firebaseProjectId =
          envFirebaseProjectId ||
          (isValidFirebaseProjectId(serviceAccount.project_id) ? serviceAccount.project_id : null) ||
          appletConfigProjectId ||
          firebaseProjectId;
        firebaseAdminCredentialSource = credentialPath;
        loadedExplicitServiceAccount = true;
        console.log(`[Firebase Admin] Credentials loaded from ${credentialPath}`);
        console.log(`[Firebase Admin] Service account project: ${firebaseProjectId}`);
      } else {
        console.warn(`[Firebase Admin] Ignoring incomplete service-account file at ${credentialPath}; using projectId-only ID token verification (${firebaseProjectId}).`);
      }
    } catch {
      console.warn(`[Firebase Admin] Ignoring non-JSON placeholder file at ${credentialPath}; using projectId-only ID token verification (${firebaseProjectId}).`);
    }
  } else {
    console.log(`[Firebase Admin] Using projectId-only ID token verification (${firebaseProjectId}).`);
  }
}

const firebaseAdminApp = getApps()[0] ?? initializeApp(
  loadedExplicitServiceAccount && firebaseAdminCredential
    ? { credential: firebaseAdminCredential, projectId: firebaseProjectId }
    : { projectId: firebaseProjectId }
);
const firebaseAdminAuth = getAuth(firebaseAdminApp);
const firebaseAdminDb = loadedExplicitServiceAccount ? getFirestore(firebaseAdminApp) : null;

async function verifyFirebaseIdToken(idToken: string) {
  if (loadedExplicitServiceAccount) {
    try {
      return await firebaseAdminAuth.verifyIdToken(idToken, true);
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      if (msg.includes('PERMISSION_DENIED') || msg.includes('insufficient permission')) {
        return await firebaseAdminAuth.verifyIdToken(idToken, false);
      }
      throw error;
    }
  }
  return await firebaseAdminAuth.verifyIdToken(idToken, false);
}

const isProduction = process.env.NODE_ENV === 'production';
const nginxPort = Number(process.env.NGINX_PORT || 0);
const candidatePort = Number(process.env.APP_PORT || process.env.PORT || 0);
const PORT = candidatePort && candidatePort !== nginxPort
  ? candidatePort
  : Number(process.env.DEFAULT_APP_PORT || 3000);

interface ClientSession {
  ws: WebSocket;
  player: OnlinePlayerState;
  mutedIds: Set<string>;
  blockedIds: Set<string>;
  lastChatAt: number;
  isGuest?: boolean;
  guestStartedAt?: number;
}

const sessions = new Map<string, ClientSession>();
const farmPlotsStore = new Map<string, Record<string, FarmPlotState>>();
const ownerLocks = new Map<string, { houseLocked: boolean; barnLocked: boolean; coopLocked: boolean; stableLocked: boolean }>();
const jobsStore = new Map<string, FarmJobOffer>();
// === STRICT AES-256-GCM ENCRYPTION FOR SENSITIVE USER DATA ===
// Uses process.env.DATA_ENCRYPTION_KEY (hashed to 256 bits) or an ephemeral 256-bit runtime key.
const DATA_CIPHER_KEY: Buffer = process.env.DATA_ENCRYPTION_KEY && process.env.DATA_ENCRYPTION_KEY.trim().length >= 8
  ? crypto.createHash('sha256').update(process.env.DATA_ENCRYPTION_KEY.trim()).digest()
  : crypto.randomBytes(32);

interface EncryptedEnvelope {
  alg: 'aes-256-gcm';
  iv: string;
  tag: string;
  data: string;
}

function encryptSensitive<T>(payload: T): EncryptedEnvelope {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', DATA_CIPHER_KEY, iv);
  const plaintext = Buffer.from(JSON.stringify(payload), 'utf8');
  const encrypted = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const tag = cipher.getAuthTag();
  return {
    alg: 'aes-256-gcm',
    iv: iv.toString('base64'),
    tag: tag.toString('base64'),
    data: encrypted.toString('base64'),
  };
}

function decryptSensitive<T>(env: EncryptedEnvelope): T | null {
  try {
    const decipher = crypto.createDecipheriv('aes-256-gcm', DATA_CIPHER_KEY, Buffer.from(env.iv, 'base64'));
    decipher.setAuthTag(Buffer.from(env.tag, 'base64'));
    const decrypted = Buffer.concat([decipher.update(Buffer.from(env.data, 'base64')), decipher.final()]);
    return JSON.parse(decrypted.toString('utf8')) as T;
  } catch {
    return null;
  }
}

interface StoredAnimalSummary {
  id: string;
  type: string;
  name: string;
  affection: number;
  fedToday: boolean;
  brushedToday: boolean;
  birthday?: string;
}

interface StoredPlayerSnapshot {
  uid: string;
  avatarName: string;
  farmName: string;
  email?: string;
  isDeveloper?: boolean;
  gold: number;
  diamond: number;
  theme: ThemeMode;
  level: number;
  xp: number;
  fun: number;
  zone: WorldZoneId;
  hasPhone: boolean;
  animalsCount: number;
  animals?: StoredAnimalSummary[];
  salesStats?: SalesStats;
  farmTreesCount?: number;
  cropsCount: number;
  inventorySummary: Array<{ itemId: string; quantity: number; diamondTradeable?: boolean }>;
  createdAt?: number;
  lastOnlineAt?: number;
  loginType?: 'guest' | 'google' | 'email' | 'dev';
  updatedAt: number;
}

// Clean folder segregation: generated game & dev_panel runtime files stay under web_game/data/
// while secrets stay strictly inside game_secrets/ and dev_panel_secrets/ (blocked from File Explorer & Git).
const WEB_GAME_DIR = RESOLVED_WEB_GAME_DIR;
const RUNTIME_BASE_DIR = process.env.HARVEST_RUNTIME_DIR
  ? path.resolve(process.env.HARVEST_RUNTIME_DIR)
  : path.join(WEB_GAME_DIR, 'data');
const GAME_DATA_DIR = path.join(RUNTIME_BASE_DIR, 'data_game');
const GAME_SECRETS_DIR = path.join(GAME_DATA_DIR, 'game_secrets');
const DEV_PANEL_DATA_DIR = path.join(RUNTIME_BASE_DIR, 'data_dev_panel');
const DEV_PANEL_SECRETS_DIR = path.join(DEV_PANEL_DATA_DIR, 'dev_panel_secrets');
const DEV_PANEL_BACKUP_DIR = path.join(DEV_PANEL_DATA_DIR, 'backup');

const PLAYERS_REGISTRY_FILE = path.join(GAME_DATA_DIR, 'players_registry.json');
const RUNTIME_OVERRIDE_FILE = path.join(DEV_PANEL_DATA_DIR, 'runtime_config_override.json');
const NAKAMA_CHARACTERS_FILE = path.join(GAME_DATA_DIR, 'nakama_characters.json');
const DEVELOPER_TEAM_FILE = path.join(DEV_PANEL_SECRETS_DIR, 'owner_developers.json');
const LEGACY_DEVELOPER_SOCIAL_FILE = path.resolve(__dirname, 'data', 'developer_social.json');

const CHARACTER_DELETION_GRACE_MS = 3 * 24 * 60 * 60 * 1000; // 3 days (72 hours)
const MAX_CHARACTERS_PER_ACCOUNT = 5;
const NAKAMA_SESSION_SECRET =
  (process.env.NAKAMA_SESSION_SECRET && process.env.NAKAMA_SESSION_SECRET.trim().length >= 16
    ? process.env.NAKAMA_SESSION_SECRET.trim()
    : crypto.randomBytes(32).toString('hex'));

interface VerifiedSocialIdentity {
  accountId: string;
  uid: string;
  provider: SocialProviderId;
  email: string;
  displayName: string;
  isAnonymous: boolean;
}

interface DeveloperSocialRecord {
  accountId: string;
  uid: string;
  provider: SocialProviderId;
  emailHash: string;
  emailMasked: string;
  displayName: string;
  registeredAt: string;
}

interface DeveloperTeamMember {
  uid: string;
  accountId?: string;
  displayName: string;
  addedBy: string;
  addedAt: string;
  sessionRevokedAt?: number;
}

interface OwnerDeveloperStore {
  owner: DeveloperSocialRecord | null;
  developers: DeveloperTeamMember[];
  revokedTokensBefore: Record<string, number>;
}

function maskEmailAddress(email: string): string {
  const [local = '', domain = ''] = email.split('@');
  if (!domain) return email.slice(0, 4) + '***';
  return `${local.slice(0, Math.min(2, local.length))}***@${domain}`;
}

function sha256String(value: string): string {
  return crypto.createHash('sha256').update(value.trim().toLowerCase()).digest('hex');
}

function readOwnerDeveloperStore(): OwnerDeveloperStore {
  ensureGameDataDir();
  try {
    if (existsSync(DEVELOPER_TEAM_FILE)) {
      const raw = JSON.parse(readFileSync(DEVELOPER_TEAM_FILE, 'utf8')) as Partial<OwnerDeveloperStore>;
      return {
        owner: raw.owner && raw.owner.accountId && raw.owner.emailHash ? raw.owner : null,
        developers: Array.isArray(raw.developers) ? raw.developers : [],
        revokedTokensBefore:
          raw.revokedTokensBefore && typeof raw.revokedTokensBefore === 'object' ? raw.revokedTokensBefore : {},
      };
    }
    // Seamless one-time migration from legacy developer_social.json if present
    if (existsSync(LEGACY_DEVELOPER_SOCIAL_FILE)) {
      const raw = JSON.parse(readFileSync(LEGACY_DEVELOPER_SOCIAL_FILE, 'utf8')) as Partial<DeveloperSocialRecord>;
      if (raw.accountId && raw.emailHash) {
        const migrated: OwnerDeveloperStore = {
          owner: {
            accountId: String(raw.accountId),
            uid: String(raw.uid || raw.accountId),
            provider: raw.provider === 'steam' || raw.provider === 'apple' ? raw.provider : 'google',
            emailHash: String(raw.emailHash),
            emailMasked: String(raw.emailMasked || '***'),
            displayName: String(raw.displayName || 'Valley Owner'),
            registeredAt: String(raw.registeredAt || new Date().toISOString()),
          },
          developers: [],
          revokedTokensBefore: {},
        };
        writeOwnerDeveloperStore(migrated);
        return migrated;
      }
    }
  } catch {
    // fallback empty store
  }
  return { owner: null, developers: [], revokedTokensBefore: {} };
}

function writeOwnerDeveloperStore(store: OwnerDeveloperStore): void {
  ensureGameDataDir();
  writeFileSync(DEVELOPER_TEAM_FILE, JSON.stringify(store, null, 2), { encoding: 'utf8', mode: 0o600 });
}

function readDeveloperSocialRecord(): DeveloperSocialRecord | null {
  return readOwnerDeveloperStore().owner;
}

function writeDeveloperSocialRecord(record: DeveloperSocialRecord): void {
  const store = readOwnerDeveloperStore();
  store.owner = record;
  writeOwnerDeveloperStore(store);
}

function isIdentityOwner(identity: VerifiedSocialIdentity | null): boolean {
  if (!identity || identity.isAnonymous) return false;
  const owner = readOwnerDeveloperStore().owner;
  if (!owner) return false;
  if (identity.accountId === owner.accountId || identity.uid === owner.uid) return true;
  if (identity.email) {
    const hash = sha256String(identity.email);
    if (hash.length === owner.emailHash.length) {
      try {
        return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(owner.emailHash, 'hex'));
      } catch {
        return false;
      }
    }
  }
  return false;
}

function isIdentityTeamDeveloper(identity: VerifiedSocialIdentity | null): boolean {
  if (!identity || identity.isAnonymous) return false;
  const store = readOwnerDeveloperStore();
  return store.developers.some(
    (d) =>
      d.uid === identity.uid ||
      d.uid === identity.accountId ||
      (d.accountId && (d.accountId === identity.accountId || d.accountId === identity.uid))
  );
}

function isIdentityRegisteredDeveloper(identity: VerifiedSocialIdentity | null): boolean {
  return isIdentityOwner(identity) || isIdentityTeamDeveloper(identity);
}

function signNakamaSessionToken(identity: Omit<VerifiedSocialIdentity, 'isAnonymous'>): string {
  const payload = Buffer.from(
    JSON.stringify({
      ...identity,
      exp: Date.now() + 24 * 60 * 60 * 1000,
    })
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', NAKAMA_SESSION_SECRET).update(payload).digest('base64url');
  return `nkm_${payload}.${sig}`;
}

function verifyNakamaSessionToken(token: string): VerifiedSocialIdentity | null {
  if (!token.startsWith('nkm_') || !token.includes('.')) return null;
  const raw = token.slice(4);
  const [payload, sig] = raw.split('.');
  if (!payload || !sig) return null;
  const expected = crypto.createHmac('sha256', NAKAMA_SESSION_SECRET).update(payload).digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as Partial<VerifiedSocialIdentity> & { exp?: number };
    if (!parsed.accountId || typeof parsed.exp !== 'number' || parsed.exp <= Date.now()) return null;
    return {
      accountId: String(parsed.accountId),
      uid: String(parsed.uid || parsed.accountId),
      provider: parsed.provider === 'steam' || parsed.provider === 'apple' ? parsed.provider : 'google',
      email: String(parsed.email || ''),
      displayName: String(parsed.displayName || 'Farmer'),
      isAnonymous: false,
    };
  } catch {
    return null;
  }
}

async function verifySocialOrFirebaseToken(token: string): Promise<VerifiedSocialIdentity | null> {
  if (!token || token.length > 8192) return null;
  if (token.startsWith('nkm_')) {
    return verifyNakamaSessionToken(token);
  }
  try {
    const decoded = await verifyFirebaseIdToken(token);
    const signInProvider = String(decoded.firebase?.sign_in_provider || '');
    const isAnonymous = signInProvider === 'anonymous' || (!decoded.email && signInProvider !== 'apple.com');
    const provider: SocialProviderId = signInProvider === 'apple.com' ? 'apple' : 'google';
    return {
      accountId: `fb_${decoded.uid}`,
      uid: decoded.uid,
      provider,
      email: String(decoded.email || '').trim().toLowerCase(),
      displayName: String(decoded.name || decoded.email?.split('@')[0] || 'Farmer').slice(0, 40),
      isAnonymous,
    };
  } catch {
    return null;
  }
}

const nakamaCharacterRosterStore = new Map<string, CharacterRosterEntry[]>();

function loadNakamaCharacterRoster(): void {
  try {
    ensureGameDataDir();
    if (!existsSync(NAKAMA_CHARACTERS_FILE)) return;
    const raw = JSON.parse(readFileSync(NAKAMA_CHARACTERS_FILE, 'utf8')) as Record<string, CharacterRosterEntry[]>;
    for (const [accountId, entries] of Object.entries(raw)) {
      if (Array.isArray(entries)) {
        nakamaCharacterRosterStore.set(accountId, entries);
      }
    }
    purgeExpiredCharacterDeletions();
  } catch (err) {
    console.warn('[Nakama Roster] Failed to load character roster:', err instanceof Error ? err.message : err);
  }
}

function persistNakamaCharacterRoster(): void {
  try {
    ensureGameDataDir();
    const out: Record<string, CharacterRosterEntry[]> = {};
    for (const [accountId, entries] of nakamaCharacterRosterStore.entries()) {
      out[accountId] = entries;
    }
    writeFileSync(NAKAMA_CHARACTERS_FILE, JSON.stringify(out, null, 2), { encoding: 'utf8', mode: 0o600 });
  } catch (err) {
    console.warn('[Nakama Roster] Failed to persist character roster:', err instanceof Error ? err.message : err);
  }
}

function purgeExpiredCharacterDeletions(): boolean {
  const now = Date.now();
  let changed = false;
  for (const [accountId, entries] of nakamaCharacterRosterStore.entries()) {
    const kept = entries.filter((ch) => {
      if (ch.deletionExecuteAt && now >= ch.deletionExecuteAt) {
        farmPlotsStore.delete(ch.characterId);
        ownerLocks.delete(ch.characterId);
        changed = true;
        return false;
      }
      return true;
    });
    if (kept.length !== entries.length) {
      nakamaCharacterRosterStore.set(accountId, kept);
    }
  }
  if (changed) {
    persistNakamaCharacterRoster();
  }
  return changed;
}

function ensureGameDataDir(): void {
  for (const dir of [
    GAME_DATA_DIR,
    GAME_SECRETS_DIR,
    DEV_PANEL_DATA_DIR,
    DEV_PANEL_SECRETS_DIR,
    DEV_PANEL_BACKUP_DIR,
  ]) {
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true });
    }
  }
}

const liveRuntimeConfig: RuntimeGameConfig = {
  debugMode: DEVELOPER_DEBUG_MODE,
  normalStarterGold: NORMAL_STARTER_GOLD,
  normalStarterDiamond: NORMAL_STARTER_DIAMOND,
  paymentMethods: { ...PAYMENT_METHODS },
  defaultGlobalTheme: DEFAULT_GLOBAL_THEME,
  defaultWeather: DEFAULT_WEATHER,
  weatherControl: {
    overrideEnabled: WEATHER_CONTROL.overrideEnabled,
    weights: { ...WEATHER_CONTROL.weights },
  },
  guestSessionConfig: { ...GUEST_SESSION_CONFIG },
  worldTimeOverride: { ...WORLD_TIME_OVERRIDE },
  announcementBanner: { ...ANNOUNCEMENT_BANNER_CONFIG },
  fishingConfig: { ...FISHING_CONFIG },
  caveMiningConfig: { ...CAVE_MINING_CONFIG },
  globalTreeEcosystem: { ...GLOBAL_TREE_ECOSYSTEM },
  videoCallConfig: { ...VIDEO_CALL_CONFIG },
  cameraConfig: { ...CAMERA_CONFIG },
  mobileControlsConfig: { ...MOBILE_CONTROLS_CONFIG },
  marketEconomyConfig: { ...MARKET_ECONOMY_CONFIG },
  economyTaxConfig: { ...ECONOMY_TAX_CONFIG, goldTiers: [...ECONOMY_TAX_CONFIG.goldTiers], diamondTiers: [...ECONOMY_TAX_CONFIG.diamondTiers] },
  nameChangeEconomyConfig: { ...NAME_CHANGE_ECONOMY_CONFIG },
  performanceConfig: { ...PERFORMANCE_CONFIG },
  itemTradeRates: { ...ITEM_TRADE_RATES },
  skyAtmosphereConfig: { ...SKY_ATMOSPHERE_CONFIG },
  publicEnvConfig: { ...PUBLIC_GAME_ENV_DEFAULTS },
  npcScheduleOverrides: {},
  branchingDialogues: [],
  customItems: [],
  customShopProducts: [],
};

let worldTimeOverrideSetAtMs = Date.now();

// ============================================================================
// LIVE ENV CONFIG INJECTION, BANS, AUDIT LOG, HISTORY, DIALOGUES, ITEMS & SHOP
// Organized cleanly inside web_game/data/data_dev_panel/ & dev_panel_secrets/
// ============================================================================
const ENV_LIVE_CONFIG_FILE = path.join(DEV_PANEL_SECRETS_DIR, 'env_live_config.json');
const BANS_FILE = path.join(DEV_PANEL_DATA_DIR, 'bans.json');
const AUDIT_LOGS_FILE = path.join(DEV_PANEL_DATA_DIR, 'audit_logs.json');
const HISTORY_LOGS_FILE = path.join(GAME_DATA_DIR, 'history_logs.json');
const DIALOGUES_FILE = path.join(DEV_PANEL_DATA_DIR, 'dialogues_branching.json');
const CUSTOM_ITEMS_FILE = path.join(DEV_PANEL_DATA_DIR, 'custom_items.json');
const CUSTOM_SHOP_FILE = path.join(DEV_PANEL_DATA_DIR, 'custom_shop.json');
const NPC_SCHEDULES_FILE = path.join(DEV_PANEL_DATA_DIR, 'npc_schedules.json');
const OFFLINE_REVISIONS_FILE = path.join(GAME_DATA_DIR, 'offline_sync_revisions.json');

interface EnvVarMeta {
  key: string;
  group: 'Server & Runtime' | 'Nakama' | 'Social OAuth' | 'Payment & Firebase' | 'Security & SMTP' | 'Gameplay & Rates';
  isSecret: boolean;
  defaultValue: string;
}

const MANAGED_ENV_VARS: EnvVarMeta[] = [
  { key: 'APP_PORT', group: 'Server & Runtime', isSecret: false, defaultValue: '3000' },
  { key: 'DEFAULT_APP_PORT', group: 'Server & Runtime', isSecret: false, defaultValue: '3000' },
  { key: 'NGINX_PORT', group: 'Server & Runtime', isSecret: false, defaultValue: '8080' },
  { key: 'HARVEST_RUNTIME_DIR', group: 'Server & Runtime', isSecret: false, defaultValue: './data' },
  { key: 'DISABLE_HMR', group: 'Server & Runtime', isSecret: false, defaultValue: 'false' },
  { key: 'CDN_URL', group: 'Server & Runtime', isSecret: false, defaultValue: '' },
  { key: 'NAKAMA_HOST', group: 'Nakama', isSecret: false, defaultValue: '127.0.0.1' },
  { key: 'NAKAMA_PORT', group: 'Nakama', isSecret: false, defaultValue: '7350' },
  { key: 'NAKAMA_SERVER_KEY', group: 'Nakama', isSecret: true, defaultValue: '' },
  { key: 'NAKAMA_USE_SSL', group: 'Nakama', isSecret: false, defaultValue: 'false' },
  { key: 'GOOGLE_CLIENT_ID', group: 'Social OAuth', isSecret: false, defaultValue: '' },
  { key: 'GOOGLE_CLIENT_SECRET', group: 'Social OAuth', isSecret: true, defaultValue: '' },
  { key: 'STEAM_API_KEY', group: 'Social OAuth', isSecret: true, defaultValue: '' },
  { key: 'APPLE_SERVICE_ID', group: 'Social OAuth', isSecret: false, defaultValue: '' },
  { key: 'DISCORD_CLIENT_ID', group: 'Social OAuth', isSecret: false, defaultValue: '' },
  { key: 'DISCORD_CLIENT_SECRET', group: 'Social OAuth', isSecret: true, defaultValue: '' },
  { key: 'FACEBOOK_APP_ID', group: 'Social OAuth', isSecret: false, defaultValue: '' },
  { key: 'FACEBOOK_APP_SECRET', group: 'Social OAuth', isSecret: true, defaultValue: '' },
  { key: 'DUITKU_MERCHANT_CODE', group: 'Payment & Firebase', isSecret: false, defaultValue: '' },
  { key: 'DUITKU_API_KEY', group: 'Payment & Firebase', isSecret: true, defaultValue: '' },
  { key: 'FIREBASE_PROJECT_ID', group: 'Payment & Firebase', isSecret: false, defaultValue: '' },
  { key: 'GOOGLE_APPLICATION_CREDENTIALS', group: 'Payment & Firebase', isSecret: false, defaultValue: '' },
  { key: 'FIREBASE_SERVICE_ACCOUNT_JSON', group: 'Payment & Firebase', isSecret: true, defaultValue: '' },
  { key: 'DATA_ENCRYPTION_KEY', group: 'Security & SMTP', isSecret: true, defaultValue: '' },
  { key: 'ADMIN_MONITOR_TOKEN', group: 'Security & SMTP', isSecret: true, defaultValue: '' },
  { key: 'JWT_SECRET', group: 'Security & SMTP', isSecret: true, defaultValue: '' },
  { key: 'JWT_EXPIRATION', group: 'Security & SMTP', isSecret: false, defaultValue: '7d' },
  { key: 'SMTP_HOST', group: 'Security & SMTP', isSecret: false, defaultValue: '' },
  { key: 'SMTP_PORT', group: 'Security & SMTP', isSecret: false, defaultValue: '587' },
  { key: 'SMTP_USER', group: 'Security & SMTP', isSecret: false, defaultValue: '' },
  { key: 'SMTP_PASSWORD', group: 'Security & SMTP', isSecret: true, defaultValue: '' },
  { key: 'GAME_VERSION', group: 'Gameplay & Rates', isSecret: false, defaultValue: '2.5.0' },
  { key: 'GAME_MAINTENANCE_MODE', group: 'Gameplay & Rates', isSecret: false, defaultValue: 'false' },
  { key: 'EXP_RATE_MULTIPLIER', group: 'Gameplay & Rates', isSecret: false, defaultValue: '1' },
  { key: 'DROP_RATE_MULTIPLIER', group: 'Gameplay & Rates', isSecret: false, defaultValue: '1' },
  { key: 'PLAYER_INITIAL_GOLD', group: 'Gameplay & Rates', isSecret: false, defaultValue: '500' },
  { key: 'PLAYER_INITIAL_DIAMOND', group: 'Gameplay & Rates', isSecret: false, defaultValue: '10' },
  { key: 'PLAYER_MAX_LEVEL', group: 'Gameplay & Rates', isSecret: false, defaultValue: '100' },
];

const MANAGED_ENV_MAP = new Map<string, EnvVarMeta>(MANAGED_ENV_VARS.map((m) => [m.key, m]));
const liveEnvOverrides = new Map<string, string>();
const bansStore = new Map<string, PlayerBanRecord>();
const auditLogsStore: AuditLogEntry[] = [];

interface HistoryLogEntry {
  id: string;
  timestamp: number;
  category: 'gold_spend' | 'diamond_spend' | 'item' | 'trading' | 'mail' | 'login';
  uid: string;
  playerName: string;
  amount?: number;
  currency?: 'gold' | 'diamond';
  itemName?: string;
  summary: string;
}
const historyLogsStore: HistoryLogEntry[] = [];

function readJsonFileSafe<T>(filePath: string, fallback: T): T {
  try {
    ensureGameDataDir();
    if (!existsSync(filePath)) return fallback;
    return JSON.parse(readFileSync(filePath, 'utf8')) as T;
  } catch {
    return fallback;
  }
}

function writeJsonFileSafe(filePath: string, data: unknown, restricted = false): void {
  try {
    ensureGameDataDir();
    writeFileSync(
      filePath,
      JSON.stringify(data, null, 2),
      restricted ? { encoding: 'utf8', mode: 0o600 } : 'utf8'
    );
  } catch (err) {
    console.warn(`[Persist] Failed writing ${path.basename(filePath)}:`, err instanceof Error ? err.message : err);
  }
}

function syncPublicEnvToRuntimeConfig(): void {
  const getVal = (k: string, fallback: string) =>
    (liveEnvOverrides.get(k) ?? process.env[k] ?? fallback).trim();
  const expMult = Math.max(0.1, Math.min(50, Number(getVal('EXP_RATE_MULTIPLIER', '1')) || 1));
  const dropMult = Math.max(0.1, Math.min(50, Number(getVal('DROP_RATE_MULTIPLIER', '1')) || 1));
  const initGold = Math.max(0, Math.min(999_999_999, Math.floor(Number(getVal('PLAYER_INITIAL_GOLD', String(liveRuntimeConfig.normalStarterGold))) || liveRuntimeConfig.normalStarterGold)));
  const initDiamond = Math.max(0, Math.min(999_999_999, Math.floor(Number(getVal('PLAYER_INITIAL_DIAMOND', String(liveRuntimeConfig.normalStarterDiamond))) || liveRuntimeConfig.normalStarterDiamond)));
  const maxLvl = Math.max(10, Math.min(999, Math.floor(Number(getVal('PLAYER_MAX_LEVEL', '100')) || 100)));
  const maint = getVal('GAME_MAINTENANCE_MODE', 'false').toLowerCase() === 'true';

  liveRuntimeConfig.publicEnvConfig = {
    GAME_VERSION: getVal('GAME_VERSION', PUBLIC_GAME_ENV_DEFAULTS.GAME_VERSION),
    GAME_MAINTENANCE_MODE: maint,
    EXP_RATE_MULTIPLIER: expMult,
    DROP_RATE_MULTIPLIER: dropMult,
    PLAYER_INITIAL_GOLD: initGold,
    PLAYER_INITIAL_DIAMOND: initDiamond,
    PLAYER_MAX_LEVEL: maxLvl,
    CDN_URL: getVal('CDN_URL', ''),
  };
  liveRuntimeConfig.normalStarterGold = initGold;
  liveRuntimeConfig.normalStarterDiamond = initDiamond;
}

function appendAuditLog(
  actor: string,
  category: AuditLogEntry['category'],
  action: string,
  summary: string,
  targetId?: string
): AuditLogEntry {
  const entry: AuditLogEntry = {
    id: `aud_${crypto.randomUUID().slice(0, 10)}`,
    timestamp: Date.now(),
    actor: String(actor || 'Developer').slice(0, 64),
    category,
    action: String(action || 'update').slice(0, 64),
    target: targetId ? String(targetId).slice(0, 80) : undefined,
    summary: String(summary || '').slice(0, 320),
  };
  auditLogsStore.unshift(entry);
  if (auditLogsStore.length > 1000) auditLogsStore.length = 1000;
  writeJsonFileSafe(AUDIT_LOGS_FILE, auditLogsStore);
  return entry;
}

function appendHistoryLog(entry: Omit<HistoryLogEntry, 'id' | 'timestamp'>): void {
  historyLogsStore.unshift({
    id: `his_${crypto.randomUUID().slice(0, 10)}`,
    timestamp: Date.now(),
    ...entry,
  });
  if (historyLogsStore.length > 1500) historyLogsStore.length = 1500;
  writeJsonFileSafe(HISTORY_LOGS_FILE, historyLogsStore);
}

function getActiveBanForUid(uid: string): PlayerBanRecord | null {
  const rec = bansStore.get(uid);
  if (!rec || !rec.active) return null;
  if (rec.expiresAt && Date.now() >= rec.expiresAt) {
    rec.active = false;
    bansStore.set(uid, rec);
    writeJsonFileSafe(BANS_FILE, Array.from(bansStore.values()));
    return null;
  }
  return rec;
}

function isFullBanActive(uid: string): boolean {
  const ban = getActiveBanForUid(uid);
  return Boolean(ban && ban.banType !== 'chat_ban');
}

function broadcastBanUpdateToUid(uid: string, ban: PlayerBanRecord | null): void {
  const payload = JSON.stringify(
    ban
      ? { type: 'player:banned', uid, ban }
      : { type: 'player:unbanned', uid }
  );
  for (const s of sessions.values()) {
    if (s.player.uid === uid && s.ws.readyState === WebSocket.OPEN) {
      s.ws.send(payload);
    }
  }
}

function broadcastRuntimeConfigNow(triggerAnnouncement = false): void {
  const wsPayload = JSON.stringify({
    type: 'runtime:config_updated',
    config: liveRuntimeConfig,
    triggerAnnouncement,
  });
  for (const s of sessions.values()) {
    if (s.ws.readyState === WebSocket.OPEN) {
      s.ws.send(wsPayload);
    }
  }
}

function loadLiveDevStores(): void {
  const envMap = readJsonFileSafe<Record<string, string>>(ENV_LIVE_CONFIG_FILE, {});
  for (const [k, v] of Object.entries(envMap)) {
    if (MANAGED_ENV_MAP.has(k) && typeof v === 'string') {
      liveEnvOverrides.set(k, v);
      process.env[k] = v;
    }
  }
  syncPublicEnvToRuntimeConfig();

  const savedBans = readJsonFileSafe<PlayerBanRecord[]>(BANS_FILE, []);
  for (const b of savedBans) {
    if (b && b.uid) bansStore.set(b.uid, b);
  }
  const savedAudit = readJsonFileSafe<AuditLogEntry[]>(AUDIT_LOGS_FILE, []);
  if (Array.isArray(savedAudit)) auditLogsStore.push(...savedAudit.slice(0, 1000));

  const savedHist = readJsonFileSafe<HistoryLogEntry[]>(HISTORY_LOGS_FILE, []);
  if (Array.isArray(savedHist)) historyLogsStore.push(...savedHist.slice(0, 1500));

  const savedDialogues = readJsonFileSafe<BranchingDialogueNode[]>(DIALOGUES_FILE, []);
  if (Array.isArray(savedDialogues)) liveRuntimeConfig.branchingDialogues = savedDialogues;

  const savedCustomItems = readJsonFileSafe<ItemDef[]>(CUSTOM_ITEMS_FILE, []);
  if (Array.isArray(savedCustomItems)) {
    liveRuntimeConfig.customItems = savedCustomItems;
    for (const it of savedCustomItems) {
      if (it && it.id) ITEMS[it.id] = it;
    }
  }

  const savedShop = readJsonFileSafe<CustomShopProduct[]>(CUSTOM_SHOP_FILE, []);
  if (Array.isArray(savedShop)) liveRuntimeConfig.customShopProducts = savedShop;

  const savedNpcSched = readJsonFileSafe<Record<string, NPCRoutineSlot[] | NpcScheduleOverride>>(NPC_SCHEDULES_FILE, {});
  if (savedNpcSched && typeof savedNpcSched === 'object') {
    const normalized: Record<string, NPCRoutineSlot[]> = {};
    for (const [k, v] of Object.entries(savedNpcSched)) {
      if (Array.isArray(v)) normalized[k] = v;
      else if (v && Array.isArray(v.schedule)) normalized[k] = v.schedule;
    }
    liveRuntimeConfig.npcScheduleOverrides = normalized;
  }
}

function loadPersistedRuntimeOverride(): void {
  try {
    ensureGameDataDir();
    if (!existsSync(RUNTIME_OVERRIDE_FILE)) return;
    const raw = JSON.parse(readFileSync(RUNTIME_OVERRIDE_FILE, 'utf8')) as Partial<RuntimeGameConfig>;
    if (typeof raw.debugMode === 'boolean') liveRuntimeConfig.debugMode = raw.debugMode;
    if (typeof raw.normalStarterGold === 'number') liveRuntimeConfig.normalStarterGold = raw.normalStarterGold;
    if (typeof raw.normalStarterDiamond === 'number') liveRuntimeConfig.normalStarterDiamond = raw.normalStarterDiamond;
    if (raw.paymentMethods) liveRuntimeConfig.paymentMethods = { ...liveRuntimeConfig.paymentMethods, ...raw.paymentMethods };
    if (raw.defaultGlobalTheme) liveRuntimeConfig.defaultGlobalTheme = raw.defaultGlobalTheme;
    if (raw.defaultWeather) liveRuntimeConfig.defaultWeather = raw.defaultWeather;
    if (raw.weatherControl) {
      liveRuntimeConfig.weatherControl = {
        overrideEnabled: Boolean(raw.weatherControl.overrideEnabled),
        weights: { ...liveRuntimeConfig.weatherControl.weights, ...(raw.weatherControl.weights || {}) },
      };
    }
    if (raw.guestSessionConfig) {
      liveRuntimeConfig.guestSessionConfig = {
        durationMinutes: Math.max(1, Math.min(1440, Math.round(Number(raw.guestSessionConfig.durationMinutes) || 60))),
        warningBeforeMinutes: Math.max(1, Math.min(60, Math.round(Number(raw.guestSessionConfig.warningBeforeMinutes) || 5))),
      };
    }
    if (raw.worldTimeOverride) {
      liveRuntimeConfig.worldTimeOverride = {
        ...liveRuntimeConfig.worldTimeOverride,
        ...raw.worldTimeOverride,
      };
      worldTimeOverrideSetAtMs = Date.now();
    }
    if (raw.announcementBanner) liveRuntimeConfig.announcementBanner = { ...liveRuntimeConfig.announcementBanner, ...raw.announcementBanner };
    if (raw.fishingConfig) liveRuntimeConfig.fishingConfig = { ...liveRuntimeConfig.fishingConfig, ...raw.fishingConfig };
    if (raw.caveMiningConfig) liveRuntimeConfig.caveMiningConfig = { ...liveRuntimeConfig.caveMiningConfig, ...raw.caveMiningConfig };
    if (raw.globalTreeEcosystem) liveRuntimeConfig.globalTreeEcosystem = { ...liveRuntimeConfig.globalTreeEcosystem, ...raw.globalTreeEcosystem };
    if (raw.videoCallConfig) liveRuntimeConfig.videoCallConfig = { ...liveRuntimeConfig.videoCallConfig, ...raw.videoCallConfig };
    if (raw.cameraConfig) liveRuntimeConfig.cameraConfig = { ...liveRuntimeConfig.cameraConfig, ...raw.cameraConfig };
    if (raw.mobileControlsConfig) liveRuntimeConfig.mobileControlsConfig = { ...liveRuntimeConfig.mobileControlsConfig, ...raw.mobileControlsConfig };
    if (raw.marketEconomyConfig) liveRuntimeConfig.marketEconomyConfig = { ...liveRuntimeConfig.marketEconomyConfig, ...raw.marketEconomyConfig };
    if (raw.economyTaxConfig) liveRuntimeConfig.economyTaxConfig = { ...liveRuntimeConfig.economyTaxConfig, ...raw.economyTaxConfig };
    if (raw.nameChangeEconomyConfig) liveRuntimeConfig.nameChangeEconomyConfig = { ...liveRuntimeConfig.nameChangeEconomyConfig, ...raw.nameChangeEconomyConfig, minimumPriceDiamond: 250 };
    if (raw.performanceConfig) liveRuntimeConfig.performanceConfig = { ...liveRuntimeConfig.performanceConfig, ...raw.performanceConfig };
    if (raw.itemTradeRates) liveRuntimeConfig.itemTradeRates = { ...liveRuntimeConfig.itemTradeRates, ...raw.itemTradeRates };
    if (raw.skyAtmosphereConfig) liveRuntimeConfig.skyAtmosphereConfig = { ...liveRuntimeConfig.skyAtmosphereConfig, ...raw.skyAtmosphereConfig };
  } catch (err) {
    console.warn('[RuntimeConfig] Could not load persisted override:', err instanceof Error ? err.message : err);
  }
}

function savePersistedRuntimeOverride(): void {
  try {
    ensureGameDataDir();
    writeFileSync(RUNTIME_OVERRIDE_FILE, JSON.stringify(liveRuntimeConfig, null, 2), 'utf8');
  } catch (err) {
    console.warn('[RuntimeConfig] Could not persist override:', err instanceof Error ? err.message : err);
  }
}

loadPersistedRuntimeOverride();
loadLiveDevStores();
loadNakamaCharacterRoster();

interface CallParticipant {
  uid: string;
  avatarName: string;
  mode: 'voice' | 'video';
  micOn: boolean;
  camOn: boolean;
  deviceType: 'mobile' | 'desktop';
  previewFrame?: string;
  lastFrameAt?: number;
}
const callRooms = new Map<string, Map<string, CallParticipant>>();
const callRoomHosts = new Map<string, string>();
const callRoomInvites = new Map<string, Set<string>>();
const leaderboardStore = new Map<string, LeaderboardRecord>();
const iapLedger = new Map<string, IAPTransaction>();
const processedIdempotencyKeys = new Set<string>();
const chatReports: Array<{ reporterId: string; targetId: string; messageId: string; reason: string; timestamp: number }> = [];
const recentGlobalChat: ChatMessage[] = [];
const economyLastActionAt = new Map<string, number>();

// Encrypted sensitive user vaults (unreadable without server AES-256-GCM key)
const encryptedPlayerSnapshots = new Map<string, EncryptedEnvelope>();
const encryptedPrivateChatLog: EncryptedEnvelope[] = [];
const encryptedTransactionLedger: EncryptedEnvelope[] = [];
const encryptedFriendMap = new Map<string, EncryptedEnvelope>();
const friendRequestsStore = new Map<string, FriendRequestRecord>();
const p2pMarketStore = new Map<string, P2PMarketListing>();

function getFriendsForUid(uid: string): FriendRecord[] {
  const env = encryptedFriendMap.get(uid);
  if (!env) return [];
  return decryptSensitive<FriendRecord[]>(env) || [];
}

function saveFriendsForUid(uid: string, list: FriendRecord[]): void {
  encryptedFriendMap.set(uid, encryptSensitive(list));
}

function areMutualFriends(uidA: string, uidB: string): boolean {
  if (!uidA || !uidB || uidA === uidB) return false;
  return getFriendsForUid(uidA).some((f) => f.uid === uidB);
}

function recordEncryptedTransaction(tx: TransactionRecord): void {
  encryptedTransactionLedger.push(encryptSensitive(tx));
  if (encryptedTransactionLedger.length > 2000) {
    encryptedTransactionLedger.shift();
  }
}

const persistedPlayerRegistry = new Map<string, StoredPlayerSnapshot>();

function persistPlayerRegistryToDisk(): void {
  try {
    ensureGameDataDir();
    const list = Array.from(persistedPlayerRegistry.values());
    writeFileSync(PLAYERS_REGISTRY_FILE, JSON.stringify({ version: 1, players: list }, null, 2), 'utf8');
  } catch (err) {
    console.warn('[Registry] Failed to persist players_registry.json:', err instanceof Error ? err.message : err);
  }
}

function loadPlayerRegistryFromDisk(): void {
  try {
    ensureGameDataDir();
    if (!existsSync(PLAYERS_REGISTRY_FILE)) return;
    const raw = JSON.parse(readFileSync(PLAYERS_REGISTRY_FILE, 'utf8')) as { players?: StoredPlayerSnapshot[] };
    if (Array.isArray(raw?.players)) {
      for (const p of raw.players) {
        if (p && p.uid) {
          persistedPlayerRegistry.set(p.uid, p);
          encryptedPlayerSnapshots.set(p.uid, encryptSensitive(p));
        }
      }
    }
  } catch (err) {
    console.warn('[Registry] Failed to load players_registry.json:', err instanceof Error ? err.message : err);
  }
}

loadPlayerRegistryFromDisk();

function getPlayerSnapshot(uid: string): StoredPlayerSnapshot | null {
  const env = encryptedPlayerSnapshots.get(uid);
  return (env ? decryptSensitive<StoredPlayerSnapshot>(env) : null) || persistedPlayerRegistry.get(uid) || null;
}

function savePlayerSnapshot(snap: StoredPlayerSnapshot): void {
  const prev = getPlayerSnapshot(snap.uid);
  const now = Date.now();
  const normalized: StoredPlayerSnapshot = {
    ...snap,
    createdAt: snap.createdAt ?? prev?.createdAt ?? now,
    lastOnlineAt: snap.lastOnlineAt ?? prev?.lastOnlineAt ?? now,
    loginType: snap.loginType ?? prev?.loginType,
  };
  encryptedPlayerSnapshots.set(normalized.uid, encryptSensitive(normalized));
  persistedPlayerRegistry.set(normalized.uid, normalized);
  persistPlayerRegistryToDisk();
}

function broadcastP2PMarketUpdate(): void {
  refreshP2PListingPrices();
  const listings = Array.from(p2pMarketStore.values())
    .filter((l) => l.status === 'active')
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 120);
  const payload = JSON.stringify({ type: 'p2p:market_updated', listings });
  for (const s of sessions.values()) {
    if (s.ws.readyState === WebSocket.OPEN) {
      s.ws.send(payload);
    }
  }
}

function sendFriendSyncToUid(uid: string): void {
  const friends = getFriendsForUid(uid);
  const incoming = Array.from(friendRequestsStore.values()).filter((r) => r.toUid === uid);
  const outgoing = Array.from(friendRequestsStore.values()).filter((r) => r.fromUid === uid);
  for (const s of sessions.values()) {
    if (s.player.uid === uid) {
      sendJson(s.ws, { type: 'friends:synced', friends, incoming, outgoing });
    }
  }
}

// === GLOBAL PROTECTED TREE ECOSYSTEM (200-500 DYNAMIC TREES, CARPENTER ORIN ONLY) ===
const liveTreeEcosystemConfig: GlobalTreeEcosystemConfig = { ...liveRuntimeConfig.globalTreeEcosystem };
const globalTreeRecords: WorldTreeRecord[] = [];
const globalTreeEcosystemLog: Array<{ timestamp: number; event: 'sprout' | 'carpenter_cut' | 'config'; delta: number; totalAfter: number; note: string }> = [];
let globalTreeNextSeq = 1;
let lastGlobalGrowthAt = Date.now();
let lastCarpenterCutAt = Date.now();
let ecosystemWavePhase = Math.random() * Math.PI * 2;

function isBlockedGlobalTreeSpotServer(tx: number, tz: number): boolean {
  if (tx < -58.5 || tx > 34.5 || tz < -66.0 || tz > 52.5) return true;
  if (Math.hypot(tx - 4, tz) < 20.0) return true;
  if (Math.abs(tz) < 4.2 && tx >= -62 && tx <= 42) return true;
  if (Math.abs(tx - 4) < 4.2 && tz >= -55 && tz <= 48) return true;
  if (Math.abs(tz + 52) < 4.0 && tx >= -52 && tx <= 8) return true;
  if (Math.abs(tx + 48) < 4.4 && tz >= -66 && tz <= -48) return true;
  if (tx >= -3.5 && tx <= 11.5 && tz >= -18.5 && tz <= -7.5) return true;
  if (Math.hypot(tx + 22, tz - 42) < 5.2) return true;
  if (Math.hypot(tx + 48, tz + 60) < 8.5) return true; // Relocated Far-Corner Cave
  if (Math.hypot(tx - 6, tz + 37) < 5.8) return true;  // Smithy
  const reserved: Array<[number, number, number]> = [
    [12, -36, 3.0],
    [17, -33, 3.0],
    [21, -29, 3.0],
    [-41, -59, 3.2],
    [-54, -58, 3.2],
    [-43, -53, 3.2],
    [-34, -55, 3.2],
    [-16, 33, 3.0],
    [-7, 36, 3.0],
    [-18, 38, 3.0],
    [9, 34, 3.0],
  ];
  for (const [rx, rz, rr] of reserved) {
    if (Math.hypot(tx - rx, tz - rz) < rr) return true;
  }
  for (const p of BUILDING_PORTALS) {
    if (p.outdoorZone === 'farm_home') continue;
    const swapped = p.facing === 'east' || p.facing === 'west';
    const halfW = (swapped ? p.depth : p.width) * 0.5 + 3.2;
    const halfD = (swapped ? p.width : p.depth) * 0.5 + 3.2;
    let cx = p.doorX;
    let cz = p.doorZ - (p.depth * 0.5 + 0.65);
    if (p.facing === 'north') cz = p.doorZ + (p.depth * 0.5 + 0.65);
    else if (p.facing === 'east') { cx = p.doorX - (p.depth * 0.5 + 0.65); cz = p.doorZ; }
    else if (p.facing === 'west') { cx = p.doorX + (p.depth * 0.5 + 0.65); cz = p.doorZ; }
    if (Math.abs(tx - cx) < halfW && Math.abs(tz - cz) < halfD) return true;
    if (Math.hypot(tx - p.doorX, tz - p.doorZ) < 4.5) return true;
    if (Math.hypot(tx - p.exitSpawnX, tz - p.exitSpawnZ) < 4.5) return true;
  }
  return false;
}

const GLOBAL_TREE_ZONES: Array<{ zone: WorldTreeRecord['zone']; minX: number; maxX: number; minZ: number; maxZ: number; weight: number }> = [
  { zone: 'forest', minX: -56, maxX: 33, minZ: 27, maxZ: 51, weight: 0.36 },
  { zone: 'mountain_mine', minX: -56, maxX: 33, minZ: -64, maxZ: -27, weight: 0.30 },
  { zone: 'village_square', minX: -56, maxX: 32, minZ: -26, maxZ: 26, weight: 0.24 },
  { zone: 'river_beach', minX: 22, maxX: 34, minZ: -44, maxZ: 44, weight: 0.1 },
];

function spawnRandomGlobalTrees(count: number): number {
  const models: Array<'oak' | 'pine' | 'birch'> = ['oak', 'pine', 'birch'];
  let added = 0;
  const maxAllowed = Math.max(50, Math.min(750, liveTreeEcosystemConfig.maxTrees));
  let attempts = 0;
  while (added < count && globalTreeRecords.length < maxAllowed && attempts < count * 40) {
    attempts++;
    let roll = Math.random();
    let picked = GLOBAL_TREE_ZONES[0];
    for (const z of GLOBAL_TREE_ZONES) {
      roll -= z.weight;
      if (roll <= 0) {
        picked = z;
        break;
      }
    }
    const tx = Number((picked.minX + Math.random() * (picked.maxX - picked.minX)).toFixed(2));
    const tz = Number((picked.minZ + Math.random() * (picked.maxZ - picked.minZ)).toFixed(2));
    if (isBlockedGlobalTreeSpotServer(tx, tz)) continue;
    const minSpace = picked.zone === 'village_square' ? 3.4 : 2.75;
    if (globalTreeRecords.some((t) => Math.hypot(t.x - tx, t.z - tz) < minSpace)) continue;
    globalTreeRecords.push({
      id: `gtree_${globalTreeNextSeq++}`,
      zone: picked.zone,
      scope: 'global',
      model: models[Math.floor(Math.random() * models.length)],
      x: tx,
      z: tz,
      scale: Number((0.78 + Math.random() * 0.48).toFixed(2)),
      rotation: Number((Math.random() * Math.PI * 2).toFixed(2)),
      chopped: false,
      plantedAt: Date.now(),
    });
    added++;
  }
  return added;
}

function carpenterOrinCutTrees(count: number): number {
  const minAllowed = Math.max(40, Math.min(liveTreeEcosystemConfig.maxTrees - 10, liveTreeEcosystemConfig.minTrees));
  const removable = Math.max(0, Math.min(count, globalTreeRecords.length - minAllowed));
  if (removable <= 0) return 0;
  for (let i = 0; i < removable; i++) {
    const idx = Math.floor(Math.random() * globalTreeRecords.length);
    globalTreeRecords.splice(idx, 1);
  }
  return removable;
}

function logTreeEcosystemEvent(event: 'sprout' | 'carpenter_cut' | 'config', delta: number, note: string) {
  globalTreeEcosystemLog.unshift({
    timestamp: Date.now(),
    event,
    delta,
    totalAfter: globalTreeRecords.length,
    note,
  });
  if (globalTreeEcosystemLog.length > 40) globalTreeEcosystemLog.pop();
}

function broadcastGlobalTrees(): void {
  const payload = JSON.stringify({ type: 'world:global_trees', trees: globalTreeRecords });
  for (const s of sessions.values()) {
    if (s.ws.readyState === WebSocket.OPEN) {
      s.ws.send(payload);
    }
  }
}

function getGlobalTreeStats() {
  const byZone: Record<string, number> = { village_square: 0, forest: 0, mountain_mine: 0, river_beach: 0 };
  const byModel: Record<string, number> = { oak: 0, pine: 0, birch: 0 };
  for (const t of globalTreeRecords) {
    byZone[t.zone] = (byZone[t.zone] || 0) + 1;
    byModel[t.model] = (byModel[t.model] || 0) + 1;
  }
  return {
    total: globalTreeRecords.length,
    minTrees: liveTreeEcosystemConfig.minTrees,
    maxTrees: liveTreeEcosystemConfig.maxTrees,
    byZone,
    byModel,
  };
}

// Seed initial global forest across Town Square, Woods, Cave/Mountain, Coast (middle of 200-500 range)
const initialGlobalTarget = Math.round((liveTreeEcosystemConfig.minTrees + liveTreeEcosystemConfig.maxTrees) * 0.48);
spawnRandomGlobalTrees(initialGlobalTarget);
logTreeEcosystemEvent('sprout', globalTreeRecords.length, 'Initial Valley protected forest seeded across all global zones.');

// === DYNAMIC SUPPLY & DEMAND MARKET + 5% TAX POOL (50% / 30% / 20% to Top 1/2/3) ===
const taxRankBuckets: Record<1 | 2 | 3, number> = { 1: 500, 2: 300, 3: 200 };
const initialMarketPrices: Record<string, MarketPriceEntry> = {
  service_display_name_rename: {
    itemId: 'service_display_name_rename',
    buyPrice: 0,
    sellPrice: 0,
    diamondPrice: Math.max(250, liveRuntimeConfig.nameChangeEconomyConfig.basePriceDiamond),
    multiplier: 1.0,
    trend: 'stable',
    supply: 50,
    demand: 50,
  },
  item_bag_upgrade: {
    itemId: 'item_bag_upgrade',
    buyPrice: 10000,
    sellPrice: 0,
    multiplier: 1.0,
    trend: 'stable',
    supply: 50,
    demand: 50,
  },
};
for (const item of Object.values(ITEMS)) {
  if (item.buyPrice > 0 || item.sellPrice > 0 || (item.diamondPrice && item.diamondPrice > 0)) {
    const baseSell =
      item.category === 'Tools' || item.category === 'Materials'
        ? Math.max(1, Math.round(item.buyPrice * 0.5))
        : item.sellPrice;
    initialMarketPrices[item.id] = {
      itemId: item.id,
      buyPrice: item.buyPrice,
      sellPrice: baseSell,
      diamondPrice: item.diamondPrice,
      multiplier: Math.max(1.0, liveRuntimeConfig.marketEconomyConfig.minMultiplier || 1.0),
      trend: 'stable',
      supply: 50,
      demand: 50,
    };
  }
}
const marketState: MarketState = {
  prices: initialMarketPrices,
  taxPool: taxRankBuckets[1] + taxRankBuckets[2] + taxRankBuckets[3],
  taxPoolDiamond: 0,
  totalVolumeGold: 0,
  updatedAt: Date.now(),
};

function recalcMarketEntry(itemId: string): void {
  const item = ITEMS[itemId];
  const entry = marketState.prices[itemId];
  const isNameChangeService = itemId === 'service_display_name_rename';
  if ((!item && itemId !== 'item_bag_upgrade' && !isNameChangeService) || !entry) return;
  const prevMult = entry.multiplier;
  const minMult = Math.max(0.1, Number(liveRuntimeConfig.marketEconomyConfig.minMultiplier) || 0.5);
  const maxMult = Math.max(minMult, Number(liveRuntimeConfig.marketEconomyConfig.maxMultiplier) || 2.6);
  const demandFactor = Math.max(0.2, Number(liveRuntimeConfig.marketEconomyConfig.goldDemandFactor) || 1.0);
  const pressure = (entry.demand - entry.supply) / Math.max(10, entry.supply);
  const rawMult = Number((1 + pressure * 0.45 * demandFactor).toFixed(2));
  const mult = Math.max(minMult, Math.min(maxMult, rawMult));
  entry.multiplier = mult;
  entry.trend = mult > prevMult + 0.02 ? 'up' : mult < prevMult - 0.02 ? 'down' : 'stable';

  if (isNameChangeService) {
    const base = Math.max(250, Math.floor(Number(liveRuntimeConfig.nameChangeEconomyConfig.basePriceDiamond) || 250));
    entry.diamondPrice = Math.max(250, Math.round(base * mult));
    entry.buyPrice = 0;
    entry.sellPrice = 0;
    return;
  }

  if (itemId === 'item_bag_upgrade') {
    entry.buyPrice = Math.max(1, Math.round(10000 * mult));
    entry.sellPrice = 0;
    return;
  }

  entry.buyPrice = item!.buyPrice > 0 ? Math.max(1, Math.round(item!.buyPrice * mult)) : 0;
  if (item!.category === 'Tools' || item!.category === 'Materials') {
    const baseSell = item!.buyPrice > 0 ? Math.max(1, Math.round(item!.buyPrice * 0.5)) : 0;
    entry.sellPrice = baseSell > 0 ? Math.max(1, Math.round(baseSell * mult)) : 0;
  } else {
    entry.sellPrice = item!.sellPrice > 0 ? Math.max(1, Math.round(item!.sellPrice * mult)) : 0;
  }
  if (item!.diamondPrice && item!.diamondPrice > 0) {
    const diamondMinMult = Math.max(0.1, Number(liveRuntimeConfig.marketEconomyConfig.diamondFloorMultiplier) || minMult);
    const diamondMult = Math.max(diamondMinMult, Math.min(maxMult, mult));
    entry.diamondPrice = Math.max(1, Math.round(item!.diamondPrice * diamondMult));
  }
}


function getProgressiveTaxPercent(level: number, currency: 'gold' | 'diamond'): number {
  const cfg = liveRuntimeConfig.economyTaxConfig;
  if (!cfg?.enabled) return 0;
  const tiers = (currency === 'gold' ? cfg.goldTiers : cfg.diamondTiers) || [];
  const normalized = tiers
    .filter((tier) => Number.isFinite(tier.minLevel) && Number.isFinite(tier.taxPercent))
    .sort((a, b) => a.minLevel - b.minLevel);
  if (normalized.length === 0) return 25;
  const playerLevel = Math.max(1, Math.floor(level || 1));
  let selected = normalized[0];
  for (const tier of normalized) {
    if (playerLevel >= tier.minLevel) selected = tier;
  }
  return Math.max(0, Math.min(100, Number(selected.taxPercent) || 0));
}

function getRosterCharacter(accountId: string, characterId: string): CharacterRosterEntry | null {
  if (!accountId || !characterId) return null;
  return (nakamaCharacterRosterStore.get(accountId) || []).find((c) => c.characterId === characterId) || null;
}

function getListingMarketMultiplier(itemId: string): number {
  const direct = marketState.prices[itemId]?.multiplier;
  if (typeof direct === 'number' && Number.isFinite(direct)) return direct;
  const values = Object.values(marketState.prices).filter((entry) => entry.itemId !== 'service_display_name_rename').map((entry) => entry.multiplier);
  return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 1;
}

function refreshP2PListingPrices(): void {
  for (const listing of p2pMarketStore.values()) {
    if (listing.status !== 'active') continue;
    const basePrice = Math.max(1, Math.floor(listing.baseDiamondPrice ?? listing.diamondPrice));
    listing.baseDiamondPrice = basePrice;
    listing.diamondPrice = Math.max(1, Math.round(basePrice * getListingMarketMultiplier(listing.itemId)));
  }
}

function broadcastMarketUpdate(): void {
  marketState.taxPool = taxRankBuckets[1] + taxRankBuckets[2] + taxRankBuckets[3];
  refreshP2PListingPrices();
  broadcastP2PMarketUpdate();
  marketState.updatedAt = Date.now();
  const payload = JSON.stringify({
    type: 'market:updated',
    market: marketState,
    taxBuckets: taxRankBuckets,
  });
  for (const s of sessions.values()) {
    if (s.ws.readyState === WebSocket.OPEN) {
      s.ws.send(payload);
    }
  }
}

// Seed starter valley leaderboard pioneers so the valley feels alive on first launch
const starterLeaders: LeaderboardRecord[] = [
  {
    uid: 'pioneer_daren',
    avatarName: 'Daren',
    farmName: 'Valley Heritage Farm',
    totalWealth: 4850,
    farmingLevel: 8,
    cropsHarvested: 142,
    animalsCount: 6,
    fishCaught: 28,
    achievementsCount: 5,
    villageReputation: 820,
    updatedAt: Date.now() - 3600_000,
  },
  {
    uid: 'pioneer_felix',
    avatarName: 'Felix',
    farmName: 'Green Pastures Ranch',
    totalWealth: 3920,
    farmingLevel: 6,
    cropsHarvested: 78,
    animalsCount: 11,
    fishCaught: 15,
    achievementsCount: 4,
    villageReputation: 740,
    updatedAt: Date.now() - 7200_000,
  },
  {
    uid: 'pioneer_rowan',
    avatarName: 'Rowan',
    farmName: 'Eastpier Fisheries',
    totalWealth: 3150,
    farmingLevel: 5,
    cropsHarvested: 54,
    animalsCount: 2,
    fishCaught: 96,
    achievementsCount: 4,
    villageReputation: 690,
    updatedAt: Date.now() - 5400_000,
  },
];
for (const rec of starterLeaders) {
  leaderboardStore.set(rec.uid, rec);
}

// Profanity / spam sanitization filter
const BLOCKED_WORDS = ['anjing', 'babi', 'bangsat', 'tolol', 'fuck', 'shit', 'bitch'];
function sanitizeChatText(input: string): string {
  let clean = String(input || '').trim().slice(0, 220);
  for (const word of BLOCKED_WORDS) {
    const regex = new RegExp(`\\b${word}\\b`, 'gi');
    clean = clean.replace(regex, '***');
  }
  return clean;
}

function getAuthoritativeWorldTime(): { hour: number; minute: number; season: Season; day: number; year: number; isFestival: boolean; festivalZone?: WorldZoneId } {
  const ov = liveRuntimeConfig.worldTimeOverride;
  if (ov?.enabled) {
    const baseMin = ov.hour * 60 + ov.minute;
    const elapsedRealSec = ov.timePaused ? 0 : Math.max(0, (Date.now() - worldTimeOverrideSetAtMs) / 1000);
    const scale = Math.max(0.25, Math.min(20, Number(ov.timeScale) || 1));
    const addedGameMin = Math.floor((elapsedRealSec * scale) / 28);
    const totalMin = baseMin + addedGameMin;
    const modMin = ((totalMin % 1440) + 1440) % 1440;
    const extraDays = Math.floor(totalMin / 1440);
    const seasonsOrder: Season[] = ['Spring', 'Summer', 'Autumn', 'Winter'];
    let seasonStartDay = 0;
    for (const s of seasonsOrder) {
      if (s === ov.season) break;
      seasonStartDay += SEASON_DAYS[s];
    }
    const clampedBaseDay = Math.max(1, Math.min(getDaysInSeason(ov.season), ov.day));
    const totalDayIdx = (ov.year - 1) * TOTAL_DAYS_PER_YEAR + seasonStartDay + (clampedBaseDay - 1) + extraDays;
    const year = Math.floor(totalDayIdx / TOTAL_DAYS_PER_YEAR) + 1;
    const { season, day } = dayOfYearToSeasonDay(totalDayIdx % TOTAL_DAYS_PER_YEAR);
    const hour = Math.floor(modMin / 60);
    const minute = modMin % 60;
    const fest = FESTIVALS.find((f) => f.season === season && f.day === day);
    return { hour, minute, season, day, year, isFestival: Boolean(fest), festivalZone: fest?.locationZone };
  }
  const clock = getSynchronizedWorldClock(0);
  const fest = FESTIVALS.find((f) => f.season === clock.season && f.day === clock.day);
  return {
    hour: clock.hour,
    minute: clock.minute,
    season: clock.season,
    day: clock.day,
    year: clock.year,
    isFestival: Boolean(fest),
    festivalZone: fest?.locationZone,
  };
}

function isFarmScopedZone(zone: WorldZoneId): boolean {
  return (
    zone === 'farm_home' ||
    zone === 'int_farmhouse' ||
    zone === 'int_barn' ||
    zone === 'int_coop' ||
    zone === 'int_stable'
  );
}

const VALID_WORLD_ZONES = new Set<WorldZoneId>([
  'farm_home', 'village_square', 'forest', 'river_beach', 'mountain_mine',
  'secret_grove', 'int_farmhouse', 'int_barn', 'int_coop', 'int_stable',
  'int_general_store', 'int_blacksmith', 'int_flower_shop', 'int_ranch',
  'int_clinic', 'int_inn', 'int_bakery', 'int_library', 'int_manor', 'int_cave',
]);

function hasActiveJobOnFarm(workerUid: string, employerUid: string): FarmJobOffer | undefined {
  for (const job of jobsStore.values()) {
    if (job.status === 'in_progress' && job.workerUid === workerUid && job.employerUid === employerUid) {
      return job;
    }
  }
  return undefined;
}

function broadcastJobsList(): void {
  const jobs = Array.from(jobsStore.values())
    .filter((j) => j.status === 'open' || j.status === 'in_progress')
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 60);
  const payload = JSON.stringify({ type: 'jobs:updated', jobs });
  for (const s of sessions.values()) {
    if (s.ws.readyState === WebSocket.OPEN) {
      s.ws.send(payload);
    }
  }
}

function broadcastCallRoomState(roomId: string): void {
  const room = callRooms.get(roomId);
  const participants = room ? Array.from(room.values()) : [];
  const payload = { type: 'call:room_state', roomId, participants };
  for (const s of sessions.values()) {
    if (room?.has(s.player.uid)) {
      sendJson(s.ws, payload);
    }
  }
}

function removeUidFromAllCallRooms(uid: string, reason: 'hangup' | 'disconnect' = 'hangup'): void {
  for (const [roomId, room] of callRooms.entries()) {
    const leavingParticipant = room.get(uid);
    const invitedSet = callRoomInvites.get(roomId);
    const wasInvitedOnly = Boolean(!leavingParticipant && invitedSet?.has(uid));

    if (leavingParticipant || wasInvitedOnly) {
      const hostUid = callRoomHosts.get(roomId);
      const actorName = leavingParticipant?.avatarName || getPlayerSnapshot(uid)?.avatarName || 'Participant';
      const isDirectOrHost = room.size <= 2 || hostUid === uid || roomId.startsWith('direct_');

      if (leavingParticipant) {
        room.delete(uid);
      }
      if (invitedSet) {
        invitedSet.delete(uid);
      }

      if (isDirectOrHost || room.size === 0) {
        const endPayload = {
          type: 'call:ended',
          roomId,
          endedByUid: uid,
          endedByName: actorName,
          reason,
        };
        for (const s of sessions.values()) {
          if (s.player.uid !== uid && (room.has(s.player.uid) || invitedSet?.has(s.player.uid))) {
            sendJson(s.ws, endPayload);
          }
        }
        callRooms.delete(roomId);
        callRoomHosts.delete(roomId);
        callRoomInvites.delete(roomId);
      } else {
        broadcastCallRoomState(roomId);
      }
    }
  }
}

function finiteNumber(value: unknown, fallback: number, min: number, max: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(min, Math.min(max, parsed)) : fallback;
}

function sanitizeFarmPlots(input: Record<string, unknown>): Record<string, FarmPlotState> {
  const sanitized: Record<string, FarmPlotState> = Object.create(null);
  const validObstacles = new Set(['weed', 'root', 'rock', 'sapling', 'tree']);
  for (const [key, value] of Object.entries(input).slice(0, 400)) {
    if (!/^[0-9]{1,2}_[0-9]{1,2}$/.test(key) || !value || typeof value !== 'object' || Array.isArray(value)) continue;
    const raw = value as Record<string, unknown>;
    const gx = finiteNumber(raw.gx, Number(key.split('_')[0]), 0, 99);
    const gz = finiteNumber(raw.gz, Number(key.split('_')[1]), 0, 99);
    const tilled = Boolean(raw.tilled);
    const cropIdValue = raw.cropId == null ? null : String(raw.cropId);
    const cropId = cropIdValue && CROPS[cropIdValue] ? cropIdValue : null;
    const growthDays = Math.floor(finiteNumber(raw.growthDays, 0, 0, 999));
    const crop = cropId ? CROPS[cropId] : null;
    const obstacleValue = raw.obstacle == null ? null : String(raw.obstacle);
    sanitized[key] = {
      id: key,
      gx,
      gz,
      tilled,
      watered: tilled && Boolean(raw.watered),
      cropId,
      growthDays,
      readyToHarvest: Boolean(raw.readyToHarvest) && Boolean(crop && growthDays >= crop.daysToGrow),
      fertilized: Boolean(raw.fertilized),
      obstacle: obstacleValue && validObstacles.has(obstacleValue) ? obstacleValue as FarmPlotState['obstacle'] : null,
      obstacleDays: Math.floor(finiteNumber(raw.obstacleDays, 0, 0, 999)),
    };
  }
  return sanitized;
}

function sendJson(ws: WebSocket, payload: unknown): void {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(payload));
  }
}

function getZonePeers(session: ClientSession): ClientSession[] {
  const peers: ClientSession[] = [];
  for (const other of sessions.values()) {
    if (other.player.clientId === session.player.clientId) continue;
    if (other.player.zone !== session.player.zone) continue;
    if (isFarmScopedZone(session.player.zone)) {
      if ((other.player.farmOwnerId || other.player.uid) !== (session.player.farmOwnerId || session.player.uid)) {
        continue;
      }
    }
    peers.push(other);
  }
  return peers;
}

function broadcastToZone(zone: WorldZoneId, farmOwnerId: string | undefined, payload: unknown, excludeClientId?: string): void {
  for (const session of sessions.values()) {
    if (session.player.clientId === excludeClientId) continue;
    if (session.player.zone !== zone) continue;
    if (farmOwnerId && (session.player.farmOwnerId || session.player.uid) !== farmOwnerId) continue;
    sendJson(session.ws, payload);
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '512kb' }));

  const requireFirebaseAuth = async (req: Request, res: Response, next: NextFunction) => {
    const authorization = String(req.headers.authorization || '');
    const match = authorization.match(/^Bearer\s+(.+)$/i);
    if (!match || match[1].length > 8192) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }
    try {
      const identity = await verifySocialOrFirebaseToken(match[1].trim());
      if (identity) {
        res.locals.authUid = identity.uid;
        res.locals.authIdentity = identity;
        next();
        return;
      }
      const decoded = await verifyFirebaseIdToken(match[1].trim());
      res.locals.authUid = decoded.uid;
      next();
    } catch (error) {
      console.error('[Auth] Token verification failed:', error instanceof Error ? error.message : error);
      res.status(401).json({ error: 'Invalid or expired authentication token' });
    }
  };

  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      engine: 'great-valley-nakama-sync',
      onlinePlayers: sessions.size,
      nakamaConfigured: Boolean(process.env.NAKAMA_HOST),
      firebaseAdmin: {
        initialized: true,
        projectId: firebaseProjectId,
        credentialSource: firebaseAdminCredentialSource,
        localServiceAccountFileFound: existsSync(localServiceAccountPath),
        expectedFile: 'secrets/firebase-admin.json',
      },
    });
  });

  app.get('/api/multiplayer/players', (_req, res) => {
    const players = Array.from(sessions.values()).map((s) => ({
      clientId: s.player.clientId,
      uid: s.player.uid,
      avatarName: s.player.avatarName,
      farmName: s.player.farmName,
      zone: s.player.zone,
      farmOwnerId: s.player.farmOwnerId || s.player.uid,
      level: s.player.level,
      spousePlayerName: s.player.spousePlayerName || null,
    }));
    res.setHeader('Cache-Control', 'no-store');
    res.json({ count: players.length, players });
  });
  app.get('/api/multiplayer/status', (_req, res) => {
    const players = Array.from(sessions.values()).map((s) => ({
      clientId: s.player.clientId,
      uid: s.player.uid,
      name: s.player.avatarName,
      zone: s.player.zone,
      farmOwnerId: s.player.farmOwnerId || s.player.uid,
    }));
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      websocketClients: sessions.size,
      firebaseProjectId,
      credentialFileFound: existsSync(localServiceAccountPath),
      credentialSource: firebaseAdminCredentialSource,
      players,
    });
  });

  app.get('/api/jobs', (_req, res) => {
    const jobs = Array.from(jobsStore.values())
      .filter((j) => j.status === 'open' || j.status === 'in_progress')
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 60);
    res.setHeader('Cache-Control', 'no-store');
    res.json({ jobs });
  });

  app.get('/api/world/global-trees', (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      trees: globalTreeRecords,
      stats: getGlobalTreeStats(),
    });
  });


  app.get('/api/leaderboard', (req, res) => {
    const category = String(req.query.category || 'totalWealth');
    const validCategories = [
      'totalWealth',
      'farmingLevel',
      'cropsHarvested',
      'animalsCount',
      'fishCaught',
      'achievementsCount',
      'villageReputation',
    ] as const;
    const sortKey = validCategories.includes(category as (typeof validCategories)[number])
      ? (category as keyof LeaderboardRecord)
      : 'totalWealth';

    const list = Array.from(leaderboardStore.values()).sort(
      (a, b) => Number(b[sortKey] || 0) - Number(a[sortKey] || 0)
    );
    res.json({ leaderboard: list.slice(0, 50), category: sortKey });
  });

  app.post('/api/leaderboard/submit', requireFirebaseAuth, (req, res) => {
    const body = req.body || {};
    const uid = String(res.locals.authUid || '').slice(0, 128);
    if (!uid || !/^[a-zA-Z0-9_\-]+$/.test(uid)) {
      res.status(400).json({ error: 'Invalid player UID' });
      return;
    }
    const existing = leaderboardStore.get(uid);
    const boundedInteger = (value: unknown, fallback: number, min: number, max: number) => {
      const parsed = Number(value ?? fallback);
      return Number.isFinite(parsed) ? Math.max(min, Math.min(max, Math.floor(parsed))) : fallback;
    };
    const totalWealth = boundedInteger(body.totalWealth, 0, 0, 999_999_999);
    const farmingLevel = boundedInteger(body.farmingLevel, 1, 1, 999);
    const cropsHarvested = boundedInteger(body.cropsHarvested, 0, 0, 9_999_999);
    const animalsCount = boundedInteger(body.animalsCount, 0, 0, 999);
    const fishCaught = boundedInteger(body.fishCaught, 0, 0, 9_999_999);
    const achievementsCount = boundedInteger(body.achievementsCount, 0, 0, 100);
    const villageReputation = boundedInteger(body.villageReputation, 0, 0, 25_000);

    if (existing && totalWealth - existing.totalWealth > 500_000) {
      res.status(422).json({ error: 'Leaderboard delta rejected by server validation' });
      return;
    }

    const record: LeaderboardRecord = {
      uid,
      avatarName: String(body.avatarName || 'Farmer').slice(0, 32),
      farmName: String(body.farmName || 'Valley Farm').slice(0, 40),
      totalWealth,
      farmingLevel,
      cropsHarvested,
      animalsCount,
      fishCaught,
      achievementsCount,
      villageReputation,
      updatedAt: Date.now(),
    };
    leaderboardStore.set(uid, record);
    res.json({ ok: true, record });
  });

  // Dynamic Supply & Demand Market Endpoints
  app.get('/api/economy/market', (_req, res) => {
    refreshP2PListingPrices();
    res.json({ market: marketState, taxBuckets: taxRankBuckets });
  });

  app.post('/api/economy/transact', requireFirebaseAuth, (req, res) => {
    const { action, itemId, quantity } = req.body || {};
    const uid = String(res.locals.authUid || '');
    if (action !== 'buy' && action !== 'sell') {
      res.status(400).json({ error: 'Invalid economy action' });
      return;
    }
    const parsedQuantity = Number(quantity ?? 1);
    if (!Number.isFinite(parsedQuantity) || !Number.isInteger(parsedQuantity) || parsedQuantity < 1 || parsedQuantity > 999) {
      res.status(400).json({ error: 'Quantity must be an integer between 1 and 999' });
      return;
    }
    const now = Date.now();
    if (now - (economyLastActionAt.get(uid) || 0) < 250) {
      res.status(429).json({ error: 'Please wait before making another market action' });
      return;
    }
    economyLastActionAt.set(uid, now);
    const qty = parsedQuantity;
    const cleanId = String(itemId || '');
    const item = ITEMS[cleanId];
    if (!item && cleanId !== 'item_bag_upgrade') {
      res.status(404).json({ error: 'Unknown item' });
      return;
    }
    const entry = marketState.prices[cleanId];
    const fallbackBuy = cleanId === 'item_bag_upgrade' ? 10000 : item?.buyPrice || 0;
    const fallbackSell = cleanId === 'item_bag_upgrade' ? 0 : item?.sellPrice || 0;
    const unitPrice = action === 'buy' ? (entry?.buyPrice ?? fallbackBuy) : (entry?.sellPrice ?? fallbackSell);
    const grossGold = unitPrice * qty;
    const identity = res.locals.authIdentity as VerifiedSocialIdentity | undefined;
    const characterId = String(req.body?.characterId || '');
    const taxCharacter = identity ? getRosterCharacter(identity.accountId, characterId) : null;
    const taxRate = action === 'sell' ? getProgressiveTaxPercent(taxCharacter?.level || 1, 'gold') : 0;
    const taxGold = grossGold > 0 ? Math.round(grossGold * taxRate / 100) : 0;
    const netGold = action === 'sell' ? Math.max(0, grossGold - taxGold) : grossGold;

    if (entry) {
      if (action === 'buy') {
        entry.demand = Math.min(200, entry.demand + qty * 1.4);
        entry.supply = Math.max(8, entry.supply - qty * 0.7);
      } else if (action === 'sell') {
        entry.supply = Math.min(200, entry.supply + qty * 1.5);
        entry.demand = Math.max(8, entry.demand - qty * 0.5);
      }
      recalcMarketEntry(cleanId);
    }

    marketState.totalVolumeGold += grossGold;
    if (taxGold > 0) {
      const share1 = Math.floor(taxGold * 0.5);
      const share2 = Math.floor(taxGold * 0.3);
      const share3 = Math.max(0, taxGold - share1 - share2);
      taxRankBuckets[1] += share1;
      taxRankBuckets[2] += share2;
      taxRankBuckets[3] += share3;
    }

    broadcastMarketUpdate();
    res.json({
      ok: true,
      action,
      itemId: cleanId,
      quantity: qty,
      unitPrice,
      grossGold,
      taxGold,
      taxPercent: taxRate,
      netGold,
      market: marketState,
      taxBuckets: taxRankBuckets,
    });
  });

  app.post('/api/economy/claim-tax', requireFirebaseAuth, (req, res) => {
    const uid = String(res.locals.authUid || '');
    if (!isValidUid(uid)) {
      res.status(400).json({ error: 'Invalid player UID' });
      return;
    }
    const sorted = Array.from(leaderboardStore.values()).sort((a, b) => b.totalWealth - a.totalWealth);
    const rankIndex = sorted.findIndex((r) => r.uid === uid);
    if (rankIndex < 0 || rankIndex > 2) {
      res.status(403).json({ error: 'Only Top 1, 2, and 3 ranked farmers may claim the 5% market tax dividend.' });
      return;
    }
    const rank = (rankIndex + 1) as 1 | 2 | 3;
    const claimedGold = taxRankBuckets[rank];
    if (claimedGold <= 0) {
      res.json({ ok: false, rank, claimedGold: 0, message: 'The tax dividend pool for this rank is currently empty.' });
      return;
    }
    taxRankBuckets[rank] = 0;
    broadcastMarketUpdate();
    res.json({ ok: true, rank, claimedGold, market: marketState, taxBuckets: taxRankBuckets });
  });

  app.post('/api/economy/quote', (req, res) => {
    const { action, itemId, quantity } = req.body || {};
    if (action !== 'buy' && action !== 'sell') {
      res.status(400).json({ error: 'Invalid economy action' });
      return;
    }
    const parsedQuantity = Number(quantity ?? 1);
    if (!Number.isFinite(parsedQuantity) || !Number.isInteger(parsedQuantity) || parsedQuantity < 1 || parsedQuantity > 999) {
      res.status(400).json({ error: 'Quantity must be an integer between 1 and 999' });
      return;
    }
    const qty = parsedQuantity;
    const cleanId = String(itemId || '');
    const item = ITEMS[cleanId];
    if (!item && cleanId !== 'item_bag_upgrade') {
      res.status(404).json({ error: 'Unknown item' });
      return;
    }
    const entry = marketState.prices[cleanId];
    if (action === 'buy') {
      const baseBuy = cleanId === 'item_bag_upgrade' ? 10000 : item?.buyPrice || 0;
      res.json({
        approved: true,
        itemId: cleanId,
        quantity: qty,
        totalGold: (entry?.buyPrice ?? baseBuy) * qty,
        totalDiamond: (item?.diamondPrice || 0) * qty,
      });
      return;
    }
    if (action === 'sell') {
      res.json({
        approved: true,
        itemId: cleanId,
        quantity: qty,
        totalGold: (entry?.sellPrice ?? item?.sellPrice ?? 0) * qty,
      });
      return;
    }
    res.status(400).json({ error: 'Invalid economy action' });
  });

  function isValidUid(uid: string): boolean {
    return uid.length > 0 && uid.length <= 128 && /^[a-zA-Z0-9_\-]+$/.test(uid);
  }

  app.get('/api/runtime-config', (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, config: liveRuntimeConfig });
  });

  app.post('/api/iap/purchase', requireFirebaseAuth, (req, res) => {
    const { uid, packageId, provider } = req.body || {};
    if (!liveRuntimeConfig.paymentMethods.googlePlayBilling && !liveRuntimeConfig.paymentMethods.duitku) {
      res.status(403).json({ error: 'Payment methods are temporarily disabled.' });
      return;
    }
    if (provider === 'google_play' && !liveRuntimeConfig.paymentMethods.googlePlayBilling) {
      res.status(403).json({ error: 'Google Play Billing is currently disabled.' });
      return;
    }
    if (provider === 'duitku' && !liveRuntimeConfig.paymentMethods.duitku) {
      res.status(403).json({ error: 'Duitku Payment is currently disabled.' });
      return;
    }
    const cleanUid = String(res.locals.authUid || '');
    if (uid && String(uid) !== cleanUid) {
      res.status(403).json({ error: 'Player identity mismatch' });
      return;
    }
    if (!isValidUid(cleanUid)) {
      res.status(400).json({ error: 'Invalid player UID' });
      return;
    }
    const pkg = DIAMOND_PACKAGES.find((p) => p.id === packageId);
    if (!pkg) {
      res.status(404).json({ error: 'Invalid Diamond package' });
      return;
    }
    // Never mark a purchase completed without independently verifying the provider receipt.
    // The provider callback / receipt verifier is not implemented in this project yet.
    res.status(503).json({
      error: 'Payment verification is not configured. No Diamond has been credited.',
      packageId: pkg.id,
    });
  });

  app.get('/api/iap/history/:uid', requireFirebaseAuth, (req, res) => {
    const uid = String(req.params.uid || '');
    if (uid !== String(res.locals.authUid || '')) {
      res.status(403).json({ error: 'You may only view your own transaction history' });
      return;
    }
    if (!isValidUid(uid)) {
      res.status(400).json({ error: 'Invalid player UID' });
      return;
    }
    const history = Array.from(iapLedger.values())
      .filter((t) => t.uid === uid)
      .sort((a, b) => b.timestamp - a.timestamp);
    res.json({ transactions: history });
  });

  app.post('/api/chat/report', requireFirebaseAuth, (req, res) => {
    const { targetId, messageId, reason } = req.body || {};
    const cleanReporter = String(res.locals.authUid || '');
    const cleanTarget = String(targetId || '');
    if (!isValidUid(cleanReporter) || !isValidUid(cleanTarget)) {
      res.status(400).json({ error: 'Invalid reporter or target UID' });
      return;
    }
    chatReports.push({
      reporterId: cleanReporter,
      targetId: cleanTarget,
      messageId: String(messageId || '').slice(0, 64),
      reason: String(reason || 'Spam / Inappropriate').slice(0, 120),
      timestamp: Date.now(),
    });
    res.json({ ok: true, totalReports: chatReports.length });
  });

  // === P2P DIAMOND-ONLY VIRTUAL MARKETPLACE ===
  const VALID_MARKET_CATEGORIES = new Set<MarketplaceCategory>([
    'tools', 'medicine', 'food', 'jewelry', 'services', 'crops', 'materials', 'other',
  ]);

  app.get('/api/p2p-market/listings', (req, res) => {
    refreshP2PListingPrices();
    const category = String(req.query.category || 'all').toLowerCase();
    const search = String(req.query.search || '').trim().toLowerCase();
    let listings = Array.from(p2pMarketStore.values()).filter((l) => l.status === 'active');
    if (category && category !== 'all') {
      listings = listings.filter((l) => l.category === category);
    }
    if (search) {
      listings = listings.filter(
        (l) =>
          l.itemName.toLowerCase().includes(search) ||
          l.description.toLowerCase().includes(search) ||
          l.sellerName.toLowerCase().includes(search)
      );
    }
    listings.sort((a, b) => b.createdAt - a.createdAt);
    res.setHeader('Cache-Control', 'no-store');
    res.json({ listings: listings.slice(0, 120) });
  });

  app.post('/api/p2p-market/list', requireFirebaseAuth, (req, res) => {
    const sellerUid = String(res.locals.authUid || '');
    const { itemId, itemName, category, quantity, diamondPrice, description, sellerName, sellerCharacterId } = req.body || {};
    const cleanItemId = String(itemId || '').trim().slice(0, 64);
    const cleanCategory = String(category || 'other').toLowerCase() as MarketplaceCategory;
    const qty = Math.floor(Number(quantity ?? 1));
    const price = Math.floor(Number(diamondPrice ?? 1));
    if (!cleanItemId || (!ITEMS[cleanItemId] && cleanCategory !== 'services')) {
      res.status(400).json({ ok: false, error: 'Unknown item for marketplace listing' });
      return;
    }
    if (!VALID_MARKET_CATEGORIES.has(cleanCategory)) {
      res.status(400).json({ ok: false, error: 'Invalid marketplace category' });
      return;
    }
    if (!Number.isFinite(qty) || qty < 1 || qty > 999) {
      res.status(400).json({ ok: false, error: 'Quantity must be between 1 and 999' });
      return;
    }
    if (!Number.isFinite(price) || price < 1 || price > 1_000_000) {
      res.status(400).json({ ok: false, error: 'Diamond price must be between 1 and 1,000,000' });
      return;
    }
    const sellerIdentity = res.locals.authIdentity as VerifiedSocialIdentity | undefined;
    const sellerCharId = String(sellerCharacterId || '').trim();
    const sellerCharacter = sellerIdentity ? getRosterCharacter(sellerIdentity.accountId, sellerCharId) : null;
    if (!sellerIdentity || !sellerCharacter) {
      res.status(409).json({ ok: false, error: 'Choose an active saved character before listing an item.' });
      return;
    }
    const cleanDesc = sanitizeChatText(String(description || '').slice(0, 180));
    const listing: P2PMarketListing = {
      id: `p2p_${crypto.randomUUID().slice(0, 10)}`,
      sellerUid,
      sellerName: String(sellerName || 'Farmer').trim().slice(0, 32) || 'Farmer',
      itemId: cleanItemId,
      itemName: String(itemName || ITEMS[cleanItemId]?.name || cleanItemId).trim().slice(0, 48),
      category: cleanCategory,
      quantity: qty,
      diamondPrice: price,
      baseDiamondPrice: price,
      sellerCharacterId: sellerCharId,
      sellerAccountId: sellerIdentity.accountId,
      description: cleanDesc || 'Quality farm goods available for Diamonds.',
      createdAt: Date.now(),
      status: 'active',
    };
    const marketEntry = marketState.prices[cleanItemId];
    if (marketEntry) {
      marketEntry.supply = Math.min(200, marketEntry.supply + qty * 1.2);
      recalcMarketEntry(cleanItemId);
    }
    listing.diamondPrice = Math.max(1, Math.round(price * getListingMarketMultiplier(cleanItemId)));
    p2pMarketStore.set(listing.id, listing);
    broadcastMarketUpdate();
    res.json({ ok: true, listing });
  });

  app.post('/api/p2p-market/buy', requireFirebaseAuth, (req, res) => {
    const buyerUid = String(res.locals.authUid || '');
    const identity = res.locals.authIdentity as VerifiedSocialIdentity | undefined;
    const { listingId, buyerName, buyerCharacterId } = req.body || {};
    const listing = p2pMarketStore.get(String(listingId || ''));
    if (!listing || listing.status !== 'active') {
      res.status(404).json({ ok: false, error: 'Listing is no longer available' });
      return;
    }
    if (listing.sellerUid === buyerUid) {
      res.status(400).json({ ok: false, error: 'You cannot purchase your own listing' });
      return;
    }
    refreshP2PListingPrices();
    const buyerAccountId = identity?.accountId || '';
    const buyerCharacter = getRosterCharacter(buyerAccountId, String(buyerCharacterId || ''));
    const sellerAccountId = listing.sellerAccountId || '';
    const sellerCharacter = getRosterCharacter(sellerAccountId, String(listing.sellerCharacterId || ''));
    if (!buyerCharacter || !sellerCharacter) {
      res.status(409).json({ ok: false, error: 'Player wallet could not be verified. Please reselect your character and try again.' });
      return;
    }
    const grossDiamond = Math.max(1, Math.floor(listing.diamondPrice));
    if (buyerCharacter.diamond < grossDiamond) {
      res.status(400).json({ ok: false, error: `Not enough Diamonds. Required: ${grossDiamond}.`, requiredDiamond: grossDiamond, currentDiamond: buyerCharacter.diamond });
      return;
    }
    const sellerTaxPercent = getProgressiveTaxPercent(sellerCharacter.level, 'diamond');
    const taxDiamond = Math.round(grossDiamond * sellerTaxPercent / 100);
    const netDiamond = Math.max(0, grossDiamond - taxDiamond);
    const cleanBuyerName = String(buyerName || 'Farmer').trim().slice(0, 32) || 'Farmer';

    const buyerList = nakamaCharacterRosterStore.get(buyerAccountId) || [];
    const buyerIdx = buyerList.findIndex((c) => c.characterId === buyerCharacter.characterId);
    const sellerList = nakamaCharacterRosterStore.get(sellerAccountId) || [];
    const sellerIdx = sellerList.findIndex((c) => c.characterId === sellerCharacter.characterId);
    if (buyerIdx < 0 || sellerIdx < 0) {
      res.status(409).json({ ok: false, error: 'Wallet record changed. Refresh the marketplace and try again.' });
      return;
    }
    const updatedBuyer: CharacterRosterEntry = { ...buyerList[buyerIdx], diamond: buyerCharacter.diamond - grossDiamond, lastPlayedAt: Date.now() };
    const updatedSeller: CharacterRosterEntry = { ...sellerList[sellerIdx], diamond: sellerCharacter.diamond + netDiamond, lastPlayedAt: Date.now() };
    buyerList[buyerIdx] = updatedBuyer;
    sellerList[sellerIdx] = updatedSeller;
    nakamaCharacterRosterStore.set(buyerAccountId, buyerList);
    nakamaCharacterRosterStore.set(sellerAccountId, sellerList);
    persistNakamaCharacterRoster();

    const tradedMarketEntry = marketState.prices[listing.itemId];
    if (tradedMarketEntry) {
      tradedMarketEntry.demand = Math.min(200, tradedMarketEntry.demand + listing.quantity * 1.4);
      tradedMarketEntry.supply = Math.max(8, tradedMarketEntry.supply - listing.quantity * 1.2);
      recalcMarketEntry(listing.itemId);
    }
    listing.status = 'sold';
    listing.buyerUid = buyerUid;
    listing.buyerName = cleanBuyerName;
    listing.soldAt = Date.now();

    const tx: TransactionRecord = {
      id: `tx_${crypto.randomUUID().slice(0, 10)}`,
      type: 'p2p_trade',
      buyerUid,
      buyerName: cleanBuyerName,
      sellerUid: listing.sellerUid,
      sellerName: listing.sellerName,
      itemId: listing.itemId,
      itemName: listing.itemName,
      quantity: listing.quantity,
      currency: 'diamond',
      amount: grossDiamond,
      taxAmount: taxDiamond,
      sellerNetAmount: netDiamond,
      category: listing.category,
      description: listing.description,
      timestamp: Date.now(),
    };
    marketState.taxPoolDiamond = (marketState.taxPoolDiamond || 0) + taxDiamond;
    recordEncryptedTransaction(tx);

    for (const session of sessions.values()) {
      if (session.player.uid === listing.sellerUid) {
        sendJson(session.ws, {
          type: 'p2p:item_sold',
          listingId: listing.id,
          itemName: listing.itemName,
          quantity: listing.quantity,
          diamondEarned: netDiamond,
          diamondBalance: updatedSeller.diamond,
          sellerCharacterId: listing.sellerCharacterId,
          diamondTax: taxDiamond,
          buyerName: cleanBuyerName,
        });
      }
    }
    broadcastMarketUpdate();
    res.json({ ok: true, listing, transaction: tx, buyerDiamond: updatedBuyer.diamond, sellerNetDiamond: netDiamond, diamondTax: taxDiamond, taxPercent: sellerTaxPercent });
  });

  app.post('/api/p2p-market/cancel', requireFirebaseAuth, (req, res) => {
    const uid = String(res.locals.authUid || '');
    const listing = p2pMarketStore.get(String(req.body?.listingId || ''));
    if (!listing || listing.status !== 'active') {
      res.status(404).json({ ok: false, error: 'Listing not found' });
      return;
    }
    if (listing.sellerUid !== uid) {
      res.status(403).json({ ok: false, error: 'Only the seller may cancel this listing' });
      return;
    }
    listing.status = 'cancelled';
    const marketEntry = marketState.prices[listing.itemId];
    if (marketEntry) {
      marketEntry.supply = Math.max(8, marketEntry.supply - listing.quantity * 1.2);
      recalcMarketEntry(listing.itemId);
    }
    broadcastMarketUpdate();
    res.json({ ok: true });
  });

  app.get('/api/transactions/me', requireFirebaseAuth, (_req, res) => {
    const uid = String(res.locals.authUid || '');
    const mine: TransactionRecord[] = [];
    for (let i = encryptedTransactionLedger.length - 1; i >= 0; i--) {
      const tx = decryptSensitive<TransactionRecord>(encryptedTransactionLedger[i]);
      if (tx && (tx.buyerUid === uid || tx.sellerUid === uid)) {
        mine.push(tx);
        if (mine.length >= 100) break;
      }
    }
    res.setHeader('Cache-Control', 'no-store');
    res.json({ transactions: mine });
  });

  app.post('/api/transactions/record', requireFirebaseAuth, (req, res) => {
    const uid = String(res.locals.authUid || '');
    const b = req.body || {};
    const validTypes = new Set<TransactionRecord['type']>(['p2p_trade', 'diamond_shop', 'iap', 'npc_trade', 'job_payout', 'admin_adjust']);
    const txType = validTypes.has(b.type) ? (b.type as TransactionRecord['type']) : 'npc_trade';
    const currency = b.currency === 'diamond' ? 'diamond' : 'gold';
    const amount = Math.max(0, Math.min(999_999_999, Math.floor(Number(b.amount || 0))));
    const tx: TransactionRecord = {
      id: `tx_${crypto.randomUUID().slice(0, 10)}`,
      type: txType,
      buyerUid: uid,
      buyerName: String(b.buyerName || 'Farmer').slice(0, 32),
      sellerUid: b.sellerUid ? String(b.sellerUid).slice(0, 128) : undefined,
      sellerName: b.sellerName ? String(b.sellerName).slice(0, 32) : undefined,
      itemId: b.itemId ? String(b.itemId).slice(0, 64) : undefined,
      itemName: b.itemName ? String(b.itemName).slice(0, 48) : undefined,
      quantity: b.quantity ? Math.max(1, Math.min(999, Math.floor(Number(b.quantity)))) : undefined,
      currency,
      amount,
      category: b.category ? String(b.category).slice(0, 32) : undefined,
      description: b.description ? String(b.description).slice(0, 140) : undefined,
      timestamp: Date.now(),
    };
    recordEncryptedTransaction(tx);
    res.json({ ok: true, id: tx.id });
  });

  // === HARDENED ACCOUNT DELETION (Owner-Authenticated Server Data Purge) ===
  app.delete('/api/account/me', requireFirebaseAuth, (req, res) => {
    const uid = String(res.locals.authUid || '');
    if (!uid) {
      res.status(401).json({ ok: false, error: 'Unauthorized' });
      return;
    }

    // Disconnect active WS sessions belonging to this user
    for (const [sid, session] of sessions.entries()) {
      if (session.player.uid === uid) {
        try {
          session.ws.close(4002, 'Account deleted');
        } catch {
          // ignore already closed socket
        }
        sessions.delete(sid);
      }
    }

    // Purge encrypted player vault, farm state, locks, leaderboard, jobs, P2P listings & friendships
    encryptedPlayerSnapshots.delete(uid);
    farmPlotsStore.delete(uid);
    ownerLocks.delete(uid);
    leaderboardStore.delete(uid);
    encryptedFriendMap.delete(uid);

    // Remove user from other players' friend lists
    for (const [otherUid] of encryptedFriendMap.entries()) {
      const list = getFriendsForUid(otherUid);
      const filtered = list.filter((f) => f.uid !== uid);
      if (filtered.length !== list.length) {
        saveFriendsForUid(otherUid, filtered);
      }
    }

    for (const [reqId, fr] of friendRequestsStore.entries()) {
      if (fr.fromUid === uid || fr.toUid === uid) friendRequestsStore.delete(reqId);
    }
    for (const [jobId, job] of jobsStore.entries()) {
      if (job.employerUid === uid || job.workerUid === uid) jobsStore.delete(jobId);
    }
    for (const [listingId, listing] of p2pMarketStore.entries()) {
      if (listing.sellerUid === uid) p2pMarketStore.delete(listingId);
    }
    for (const room of callRooms.values()) {
      room.delete(uid);
    }

    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, deletedUid: uid });
  });

  // === ADMIN MONITOR & PER-USER OVERRIDE ===
  // Accessible from localhost (127.0.0.1 / ::1) OR remotely with matching ADMIN_MONITOR_TOKEN.
  const requireLocalAdmin = (req: Request, res: Response, next: NextFunction) => {
    const ip = String(req.socket.remoteAddress || req.ip || '');
    const isLoopback = ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1';
    const configuredToken = (process.env.ADMIN_MONITOR_TOKEN || '').trim();
    const suppliedToken = String(req.headers['x-admin-token'] || '').trim();
    const hasValidRemoteToken = Boolean(
      configuredToken &&
      suppliedToken.length === configuredToken.length &&
      crypto.timingSafeEqual(Buffer.from(suppliedToken), Buffer.from(configuredToken))
    );
    if (!isLoopback && !hasValidRemoteToken) {
      res.status(403).json({ error: 'Localhost or valid X-Admin-Token access required' });
      return;
    }
    if (isLoopback && configuredToken && !hasValidRemoteToken) {
      res.status(401).json({ error: 'Invalid admin monitor token' });
      return;
    }
    next();
  };

  app.get('/api/admin/monitor', requireLocalAdmin, (req, res) => {
    const playerFilter = String(req.query.player || '').trim().toLowerCase();
    const onlineByUid = new Map<string, OnlinePlayerState>();
    for (const s of sessions.values()) {
      onlineByUid.set(s.player.uid, s.player);
    }

    const allUids = new Set<string>([
      ...onlineByUid.keys(),
      ...encryptedPlayerSnapshots.keys(),
    ]);

    let players = Array.from(allUids).map((uid) => {
      const online = onlineByUid.get(uid);
      const snap = getPlayerSnapshot(uid);
      const friends = getFriendsForUid(uid);
      return {
        uid,
        online: Boolean(online),
        avatarName: online?.avatarName || snap?.avatarName || 'Farmer',
        farmName: online?.farmName || snap?.farmName || 'Valley Farm',
        email: snap?.email,
        isDeveloper: Boolean(snap?.isDeveloper),
        zone: online?.zone || snap?.zone || 'farm_home',
        level: online?.level || snap?.level || 1,
        gold: snap?.gold ?? 0,
        diamond: snap?.diamond ?? 0,
        theme: snap?.theme || 'farmhouse',
        xp: snap?.xp ?? 0,
        fun: snap?.fun ?? 100,
        hasPhone: snap?.hasPhone ?? false,
        animalsCount: snap?.animalsCount ?? (snap?.animals?.length ?? 0),
        animals: snap?.animals || [],
        salesStats: snap?.salesStats || createEmptySalesStats(),
        farmTreesCount: snap?.farmTreesCount ?? 0,
        cropsCount: snap?.cropsCount ?? 0,
        inventorySummary: snap?.inventorySummary || [],
        friendsCount: friends.length,
        friends,
        createdAt: snap?.createdAt || snap?.updatedAt || Date.now(),
        lastOnlineAt: online ? Date.now() : (snap?.lastOnlineAt || snap?.updatedAt || Date.now()),
        loginType: snap?.loginType || (uid.startsWith('dev_') ? 'dev' : uid.startsWith('guest_') ? 'guest' : 'google'),
        updatedAt: snap?.updatedAt || Date.now(),
      };
    });

    if (playerFilter) {
      players = players.filter(
        (p) =>
          p.uid.toLowerCase().includes(playerFilter) ||
          p.avatarName.toLowerCase().includes(playerFilter) ||
          (p.email || '').toLowerCase().includes(playerFilter)
      );
    }

    const privateChats: ChatMessage[] = [];
    for (let i = Math.max(0, encryptedPrivateChatLog.length - 100); i < encryptedPrivateChatLog.length; i++) {
      const m = decryptSensitive<ChatMessage>(encryptedPrivateChatLog[i]);
      if (m) privateChats.push(m);
    }

    let transactions: TransactionRecord[] = [];
    for (let i = encryptedTransactionLedger.length - 1; i >= 0 && transactions.length < 150; i--) {
      const tx = decryptSensitive<TransactionRecord>(encryptedTransactionLedger[i]);
      if (tx) transactions.push(tx);
    }
    if (playerFilter) {
      transactions = transactions.filter(
        (t) =>
          t.buyerUid.toLowerCase().includes(playerFilter) ||
          t.buyerName.toLowerCase().includes(playerFilter) ||
          (t.sellerUid || '').toLowerCase().includes(playerFilter) ||
          (t.sellerName || '').toLowerCase().includes(playerFilter)
      );
    }

    const activeCalls = Array.from(callRooms.entries()).map(([roomId, room]) => ({
      roomId,
      participants: Array.from(room.values()),
    }));

    const p2pListings = Array.from(p2pMarketStore.values())
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 120);

    res.setHeader('Cache-Control', 'no-store');
    res.json({
      timestamp: Date.now(),
      onlineCount: sessions.size,
      encryptionStatus: {
        algorithm: 'AES-256-GCM',
        encryptedSnapshots: encryptedPlayerSnapshots.size,
        encryptedPrivateMessages: encryptedPrivateChatLog.length,
        encryptedTransactions: encryptedTransactionLedger.length,
        encryptedFriendLists: encryptedFriendMap.size,
      },
      paymentMethods: liveRuntimeConfig.paymentMethods,
      runtimeConfig: liveRuntimeConfig,
      globalTreeStats: getGlobalTreeStats(),
      ecosystemConfig: liveTreeEcosystemConfig,
      ecosystemLog: globalTreeEcosystemLog.slice(0, 20),
      players,
      globalChat: recentGlobalChat.slice(-80),
      privateChats,
      activeCalls,
      p2pListings,
      transactions,
    });
  });

  function enforceGuestSessionTimeouts(): void {
    const limitMs = Math.max(60_000, liveRuntimeConfig.guestSessionConfig.durationMinutes * 60_000);
    const now = Date.now();
    for (const [sid, s] of sessions.entries()) {
      if (s.isGuest && s.guestStartedAt && now - s.guestStartedAt >= limitMs) {
        sendJson(s.ws, {
          type: 'guest:expired',
          reason: `Guest session limit (${liveRuntimeConfig.guestSessionConfig.durationMinutes} min) reached.`,
          durationMinutes: liveRuntimeConfig.guestSessionConfig.durationMinutes,
        });
        try {
          s.ws.close(4003, 'Guest session expired');
        } catch {
          // ignore closed socket
        }
        sessions.delete(sid);
      }
    }
  }

  function applyRuntimeConfigPatch(b: Partial<RuntimeGameConfig> & { triggerAnnouncementNow?: boolean }) {
    if (typeof b.debugMode === 'boolean') liveRuntimeConfig.debugMode = b.debugMode;
    if (typeof b.normalStarterGold === 'number' && Number.isFinite(b.normalStarterGold)) {
      liveRuntimeConfig.normalStarterGold = Math.max(0, Math.min(999_999_999, Math.floor(b.normalStarterGold)));
    }
    if (typeof b.normalStarterDiamond === 'number' && Number.isFinite(b.normalStarterDiamond)) {
      liveRuntimeConfig.normalStarterDiamond = Math.max(0, Math.min(999_999_999, Math.floor(b.normalStarterDiamond)));
    }
    if (b.paymentMethods && typeof b.paymentMethods === 'object') {
      if (typeof b.paymentMethods.googlePlayBilling === 'boolean') {
        liveRuntimeConfig.paymentMethods.googlePlayBilling = b.paymentMethods.googlePlayBilling;
      }
      if (typeof b.paymentMethods.duitku === 'boolean') {
        liveRuntimeConfig.paymentMethods.duitku = b.paymentMethods.duitku;
      }
    }
    if (typeof b.defaultGlobalTheme === 'string' && ['cozy', 'farmhouse', 'system', 'light', 'dark', 'seasonal'].includes(b.defaultGlobalTheme)) {
      liveRuntimeConfig.defaultGlobalTheme = b.defaultGlobalTheme as ThemeMode;
    }
    const ALL_WEATHERS: Weather[] = ['Sunny', 'Cloudy', 'LightRain', 'HeavyRain', 'Rainy', 'Stormy', 'Foggy', 'Snowy'];
    if (typeof b.defaultWeather === 'string' && ALL_WEATHERS.includes(b.defaultWeather as Weather)) {
      liveRuntimeConfig.defaultWeather = b.defaultWeather as Weather;
    }
    if (b.weatherControl && typeof b.weatherControl === 'object') {
      if (typeof b.weatherControl.overrideEnabled === 'boolean') {
        liveRuntimeConfig.weatherControl.overrideEnabled = b.weatherControl.overrideEnabled;
      }
      if (b.weatherControl.weights && typeof b.weatherControl.weights === 'object') {
        for (const w of ALL_WEATHERS) {
          const val = Number((b.weatherControl.weights as Record<string, unknown>)[w]);
          if (Number.isFinite(val)) {
            liveRuntimeConfig.weatherControl.weights[w] = Math.max(0, Math.min(100, Math.round(val)));
          }
        }
      }
    }
    if (b.guestSessionConfig && typeof b.guestSessionConfig === 'object') {
      const gc = b.guestSessionConfig as Partial<GuestSessionConfig>;
      const durationMinutes = Math.max(1, Math.min(1440, Math.round(Number(gc.durationMinutes ?? liveRuntimeConfig.guestSessionConfig.durationMinutes))));
      const warningBeforeMinutes = Math.max(1, Math.min(Math.max(1, durationMinutes - 1), Math.round(Number(gc.warningBeforeMinutes ?? liveRuntimeConfig.guestSessionConfig.warningBeforeMinutes))));
      liveRuntimeConfig.guestSessionConfig = { durationMinutes, warningBeforeMinutes };
    }
    if (b.worldTimeOverride && typeof b.worldTimeOverride === 'object') {
      const wt = b.worldTimeOverride as Partial<WorldTimeOverrideConfig>;
      const validSeasons: Season[] = ['Spring', 'Summer', 'Autumn', 'Winter'];
      const targetSeason = validSeasons.includes(wt.season as Season)
        ? (wt.season as Season)
        : liveRuntimeConfig.worldTimeOverride.season;
      const maxDayForSeason = getDaysInSeason(targetSeason);
      liveRuntimeConfig.worldTimeOverride = {
        enabled: Boolean(wt.enabled ?? liveRuntimeConfig.worldTimeOverride.enabled),
        hour: Math.max(0, Math.min(23, Math.floor(Number(wt.hour ?? liveRuntimeConfig.worldTimeOverride.hour)))),
        minute: Math.max(0, Math.min(59, Math.floor(Number(wt.minute ?? liveRuntimeConfig.worldTimeOverride.minute)))),
        day: Math.max(1, Math.min(maxDayForSeason, Math.floor(Number(wt.day ?? liveRuntimeConfig.worldTimeOverride.day)))),
        season: targetSeason,
        year: Math.max(1, Math.min(999, Math.floor(Number(wt.year ?? liveRuntimeConfig.worldTimeOverride.year)))),
        timePaused: Boolean(wt.timePaused ?? liveRuntimeConfig.worldTimeOverride.timePaused),
        timeScale: Math.max(0.25, Math.min(20, Number(wt.timeScale ?? liveRuntimeConfig.worldTimeOverride.timeScale) || 1)),
        weatherOverride:
          wt.weatherOverride === null
            ? null
            : ALL_WEATHERS.includes(wt.weatherOverride as Weather)
              ? (wt.weatherOverride as Weather)
              : liveRuntimeConfig.worldTimeOverride.weatherOverride,
      };
      worldTimeOverrideSetAtMs = Date.now();
    }
    if (b.skyAtmosphereConfig && typeof b.skyAtmosphereConfig === 'object') {
      const sc = b.skyAtmosphereConfig as Partial<SkyAtmosphereConfig>;
      const cur = liveRuntimeConfig.skyAtmosphereConfig || SKY_ATMOSPHERE_CONFIG;
      liveRuntimeConfig.skyAtmosphereConfig = {
        cloudDensity: Math.max(0, Math.min(1, Number(sc.cloudDensity ?? cur.cloudDensity))),
        cloudSpeed: Math.max(0, Math.min(4, Number(sc.cloudSpeed ?? cur.cloudSpeed))),
        starTwinkleIntensity: Math.max(0, Math.min(2, Number(sc.starTwinkleIntensity ?? cur.starTwinkleIntensity))),
        moonPhaseOverride:
          sc.moonPhaseOverride === null
            ? null
            : typeof sc.moonPhaseOverride === 'number' && Number.isFinite(sc.moonPhaseOverride)
              ? Math.max(0, Math.min(7, Math.floor(sc.moonPhaseOverride)))
              : cur.moonPhaseOverride,
        enableWeatherEffects: Boolean(sc.enableWeatherEffects ?? cur.enableWeatherEffects),
      };
    }
    if (b.announcementBanner && typeof b.announcementBanner === 'object') {
      const validCats: AnnouncementCategory[] = ['update', 'maintenance', 'event', 'emergency', 'promotion'];
      const rawCat = String((b.announcementBanner as { category?: string }).category || liveRuntimeConfig.announcementBanner.category || 'update');
      liveRuntimeConfig.announcementBanner = {
        enabled: Boolean(b.announcementBanner.enabled),
        category: validCats.includes(rawCat as AnnouncementCategory) ? (rawCat as AnnouncementCategory) : 'update',
        title: String(b.announcementBanner.title ?? liveRuntimeConfig.announcementBanner.title).slice(0, 80),
        message: String(b.announcementBanner.message ?? liveRuntimeConfig.announcementBanner.message).slice(0, 360),
        durationSec: Math.max(3, Math.min(120, Math.round(Number(b.announcementBanner.durationSec) || liveRuntimeConfig.announcementBanner.durationSec || 10))),
      };
    }
    if (b.fishingConfig && typeof b.fishingConfig === 'object') {
      liveRuntimeConfig.fishingConfig = {
        ...liveRuntimeConfig.fishingConfig,
        ...b.fishingConfig,
      };
    }
    if (b.caveMiningConfig && typeof b.caveMiningConfig === 'object') {
      liveRuntimeConfig.caveMiningConfig = {
        ...liveRuntimeConfig.caveMiningConfig,
        ...b.caveMiningConfig,
      };
    }
    if (b.globalTreeEcosystem && typeof b.globalTreeEcosystem === 'object') {
      liveRuntimeConfig.globalTreeEcosystem = {
        ...liveRuntimeConfig.globalTreeEcosystem,
        ...b.globalTreeEcosystem,
      };
      Object.assign(liveTreeEcosystemConfig, liveRuntimeConfig.globalTreeEcosystem);
    }
    if (b.videoCallConfig && typeof b.videoCallConfig === 'object') {
      const vc = b.videoCallConfig;
      liveRuntimeConfig.videoCallConfig = {
        width: Math.max(160, Math.min(1280, Math.round(Number(vc.width ?? liveRuntimeConfig.videoCallConfig.width)))),
        height: Math.max(120, Math.min(720, Math.round(Number(vc.height ?? liveRuntimeConfig.videoCallConfig.height)))),
        fps: Math.max(10, Math.min(60, Math.round(Number(vc.fps ?? liveRuntimeConfig.videoCallConfig.fps)))),
        bitrateKbps: Math.max(64, Math.min(2500, Math.round(Number(vc.bitrateKbps ?? liveRuntimeConfig.videoCallConfig.bitrateKbps)))),
        showSelfPreviewByDefault: Boolean(vc.showSelfPreviewByDefault ?? liveRuntimeConfig.videoCallConfig.showSelfPreviewByDefault),
      };
    }
    if (b.cameraConfig && typeof b.cameraConfig === 'object') {
      const cc = b.cameraConfig;
      const prevCc = liveRuntimeConfig.cameraConfig;
      liveRuntimeConfig.cameraConfig = {
        defaultDistance: Math.max(4.5, Math.min(16, Number(cc.defaultDistance ?? prevCc.defaultDistance))),
        minZoom: Math.max(3.5, Math.min(10, Number(cc.minZoom ?? prevCc.minZoom))),
        maxZoom: Math.max(8, Math.min(28, Number(cc.maxZoom ?? prevCc.maxZoom))),
        povMode: cc.povMode === 'free' ? 'free' : 'lock',
        fov: Math.max(32, Math.min(68, Number(cc.fov ?? prevCc.fov))),
        defaultPitch: Math.max(0.12, Math.min(0.95, Number(cc.defaultPitch ?? prevCc.defaultPitch))),
        mobileLockOrbitEnabled:
          typeof cc.mobileLockOrbitEnabled === 'boolean'
            ? cc.mobileLockOrbitEnabled
            : prevCc.mobileLockOrbitEnabled ?? true,
        mobileLockAutoReturnDelaySec: Math.max(
          0.5,
          Math.min(15, Number(cc.mobileLockAutoReturnDelaySec ?? prevCc.mobileLockAutoReturnDelaySec ?? 2.5))
        ),
        mobileLockAutoReturnSpeed: Math.max(
          0.5,
          Math.min(10, Number(cc.mobileLockAutoReturnSpeed ?? prevCc.mobileLockAutoReturnSpeed ?? 3.2))
        ),
      };
    }
    if (b.mobileControlsConfig && typeof b.mobileControlsConfig === 'object') {
      const mc = b.mobileControlsConfig;
      const prevMc = liveRuntimeConfig.mobileControlsConfig;
      liveRuntimeConfig.mobileControlsConfig = {
        joystickBottomPx: Math.max(8, Math.min(240, Math.round(Number(mc.joystickBottomPx ?? prevMc.joystickBottomPx)))),
        joystickLeftPx: Math.max(8, Math.min(240, Math.round(Number(mc.joystickLeftPx ?? prevMc.joystickLeftPx)))),
        joystickSizePx: Math.max(84, Math.min(180, Math.round(Number(mc.joystickSizePx ?? prevMc.joystickSizePx)))),
        actionBottomPx: Math.max(8, Math.min(240, Math.round(Number(mc.actionBottomPx ?? prevMc.actionBottomPx)))),
        actionRightPx: Math.max(8, Math.min(240, Math.round(Number(mc.actionRightPx ?? prevMc.actionRightPx)))),
        buttonScale: Math.max(0.75, Math.min(1.4, Number(mc.buttonScale ?? prevMc.buttonScale))),
        showTopRightSwitchOnly: Boolean(mc.showTopRightSwitchOnly ?? true),
        minAnalogSizePx: Math.max(64, Math.min(140, Math.round(Number(mc.minAnalogSizePx ?? prevMc.minAnalogSizePx ?? 88)))),
        maxAnalogSizePx: Math.max(120, Math.min(220, Math.round(Number(mc.maxAnalogSizePx ?? prevMc.maxAnalogSizePx ?? 180)))),
        minButtonSizePx: Math.max(32, Math.min(72, Math.round(Number(mc.minButtonSizePx ?? prevMc.minButtonSizePx ?? 38)))),
        maxButtonSizePx: Math.max(56, Math.min(120, Math.round(Number(mc.maxButtonSizePx ?? prevMc.maxButtonSizePx ?? 96)))),
        defaultLayout: mc.defaultLayout || prevMc.defaultLayout || DEFAULT_MOBILE_GAMEPAD_LAYOUT,
      };
    }
    if (b.marketEconomyConfig && typeof b.marketEconomyConfig === 'object') {
      const me = b.marketEconomyConfig;
      const minMultiplier = Math.max(0.1, Math.min(3.0, Number(me.minMultiplier ?? liveRuntimeConfig.marketEconomyConfig.minMultiplier)));
      const maxMultiplier = Math.max(minMultiplier, Math.min(5.0, Number(me.maxMultiplier ?? liveRuntimeConfig.marketEconomyConfig.maxMultiplier)));
      liveRuntimeConfig.marketEconomyConfig = {
        minMultiplier,
        maxMultiplier,
        goldDemandFactor: Math.max(0.2, Math.min(4.0, Number(me.goldDemandFactor ?? liveRuntimeConfig.marketEconomyConfig.goldDemandFactor))),
        diamondFloorMultiplier: Math.max(0.1, Math.min(3.0, Number(me.diamondFloorMultiplier ?? liveRuntimeConfig.marketEconomyConfig.diamondFloorMultiplier))),
      };
      for (const itemId of Object.keys(marketState.prices)) {
        recalcMarketEntry(itemId);
      }
      broadcastMarketUpdate();
    }
    if (b.economyTaxConfig && typeof b.economyTaxConfig === 'object') {
      const normalizeTiers = (value: unknown, fallback: typeof liveRuntimeConfig.economyTaxConfig.goldTiers) => {
        const raw = Array.isArray(value) ? value : fallback;
        const tiers = raw.map((tier: any) => ({
          minLevel: Math.max(1, Math.min(999, Math.floor(Number(tier?.minLevel) || 1))),
          taxPercent: Math.max(0, Math.min(100, Number(tier?.taxPercent) || 0)),
        })).sort((a, b) => a.minLevel - b.minLevel);
        let previousRate = 100;
        for (const tier of tiers) {
          tier.taxPercent = Math.min(previousRate, tier.taxPercent);
          previousRate = tier.taxPercent;
        }
        return tiers.length ? tiers.slice(0, 20) : fallback;
      };
      liveRuntimeConfig.economyTaxConfig = {
        enabled: Boolean(b.economyTaxConfig.enabled ?? liveRuntimeConfig.economyTaxConfig.enabled),
        goldTiers: normalizeTiers(b.economyTaxConfig.goldTiers, liveRuntimeConfig.economyTaxConfig.goldTiers),
        diamondTiers: normalizeTiers(b.economyTaxConfig.diamondTiers, liveRuntimeConfig.economyTaxConfig.diamondTiers),
      };
    }
    if (b.nameChangeEconomyConfig && typeof b.nameChangeEconomyConfig === 'object') {
      liveRuntimeConfig.nameChangeEconomyConfig = {
        basePriceDiamond: Math.max(250, Math.min(1000000, Math.floor(Number(b.nameChangeEconomyConfig.basePriceDiamond) || 250))),
        minimumPriceDiamond: 250,
      };
      recalcMarketEntry('service_display_name_rename');
    }
    if (b.performanceConfig && typeof b.performanceConfig === 'object') {
      const pc = b.performanceConfig;
      liveRuntimeConfig.performanceConfig = {
        enableLod: Boolean(pc.enableLod ?? liveRuntimeConfig.performanceConfig.enableLod),
        enableOcclusionCulling: Boolean(pc.enableOcclusionCulling ?? liveRuntimeConfig.performanceConfig.enableOcclusionCulling),
        lowPower4GbMode: Boolean(pc.lowPower4GbMode ?? liveRuntimeConfig.performanceConfig.lowPower4GbMode),
        maxDprLowPower: Math.max(0.75, Math.min(2.0, Number(pc.maxDprLowPower ?? liveRuntimeConfig.performanceConfig.maxDprLowPower))),
        maxAnisotropy: Math.max(1, Math.min(8, Math.round(Number(pc.maxAnisotropy ?? liveRuntimeConfig.performanceConfig.maxAnisotropy)))),
        lod0Distance: Math.max(10, Math.min(45, Math.round(Number(pc.lod0Distance ?? liveRuntimeConfig.performanceConfig.lod0Distance)))),
        lod1Distance: Math.max(24, Math.min(90, Math.round(Number(pc.lod1Distance ?? liveRuntimeConfig.performanceConfig.lod1Distance)))),
      };
    }
    if (b.itemTradeRates && typeof b.itemTradeRates === 'object') {
      for (const [k, v] of Object.entries(b.itemTradeRates)) {
        if (/^[a-zA-Z0-9_]+$/.test(k) && Number.isFinite(Number(v))) {
          liveRuntimeConfig.itemTradeRates[k] = Math.max(0, Math.min(100, Math.round(Number(v))));
        }
      }
    }

    savePersistedRuntimeOverride();
    enforceGuestSessionTimeouts();

    const triggerAnnouncement = Boolean(
      (b.announcementBanner && liveRuntimeConfig.announcementBanner.enabled) || b.triggerAnnouncementNow
    );
    const wsPayload = JSON.stringify({
      type: 'runtime:config_updated',
      config: liveRuntimeConfig,
      triggerAnnouncement,
    });
    for (const s of sessions.values()) {
      if (s.ws.readyState === WebSocket.OPEN) {
        s.ws.send(wsPayload);
      }
    }
    return { ok: true, config: liveRuntimeConfig, liveClientsNotified: sessions.size };
  }

  app.post('/api/admin/runtime-config', requireLocalAdmin, (req, res) => {
    const b = (req.body || {}) as Partial<RuntimeGameConfig> & { triggerAnnouncementNow?: boolean };
    res.json(applyRuntimeConfigPatch(b));
  });

  app.delete('/api/admin/users/:uid', requireLocalAdmin, (req, res) => {
    const uid = String(req.params.uid || '').trim();
    if (!uid || !isValidUid(uid)) {
      res.status(400).json({ ok: false, error: 'Invalid player UID' });
      return;
    }

    for (const [sid, s] of sessions.entries()) {
      if (s.player.uid === uid) {
        try {
          s.ws.close(4002, 'Account deleted by administrator');
        } catch {
          // ignore closed socket
        }
        sessions.delete(sid);
      }
    }

    removeUidFromAllCallRooms(uid, 'disconnect');
    encryptedPlayerSnapshots.delete(uid);
    persistedPlayerRegistry.delete(uid);
    persistPlayerRegistryToDisk();
    farmPlotsStore.delete(uid);
    ownerLocks.delete(uid);
    leaderboardStore.delete(uid);
    encryptedFriendMap.delete(uid);

    for (const [otherUid] of encryptedFriendMap.entries()) {
      const list = getFriendsForUid(otherUid);
      const filtered = list.filter((f) => f.uid !== uid);
      if (filtered.length !== list.length) {
        saveFriendsForUid(otherUid, filtered);
        sendFriendSyncToUid(otherUid);
      }
    }
    for (const [reqId, fr] of friendRequestsStore.entries()) {
      if (fr.fromUid === uid || fr.toUid === uid) friendRequestsStore.delete(reqId);
    }
    for (const [jobId, job] of jobsStore.entries()) {
      if (job.employerUid === uid || job.workerUid === uid) jobsStore.delete(jobId);
    }
    for (const [listingId, listing] of p2pMarketStore.entries()) {
      if (listing.sellerUid === uid) p2pMarketStore.delete(listingId);
    }
    broadcastP2PMarketUpdate();
    broadcastJobsList();

    res.json({ ok: true, deletedUid: uid, message: `Deleted registered player ${uid}` });
  });

  app.post('/api/admin/register-dev-player', requireLocalAdmin, (req, res) => {
    const b = req.body || {};
    const email = String(b.email || '').trim().toLowerCase().slice(0, 120);
    const displayName = String(b.displayName || 'Valley Developer').trim().slice(0, 32) || 'Valley Developer';
    const farmName = String(b.farmName || 'Developer Homestead').trim().slice(0, 40) || 'Developer Homestead';
    if (!email || !email.includes('@')) {
      res.status(400).json({ ok: false, error: 'Valid developer email is required' });
      return;
    }
    const uid = `dev_${crypto.createHash('sha256').update(email).digest('hex').slice(0, 16)}`;
    const existing = getPlayerSnapshot(uid);
    const snap: StoredPlayerSnapshot = {
      uid,
      avatarName: displayName,
      farmName,
      email,
      isDeveloper: true,
      gold: existing?.gold ?? 999999,
      diamond: existing?.diamond ?? 999999,
      theme: existing?.theme ?? 'farmhouse',
      level: existing?.level ?? 99,
      xp: existing?.xp ?? 0,
      fun: existing?.fun ?? 100,
      zone: existing?.zone ?? 'farm_home',
      hasPhone: true,
      animalsCount: existing?.animalsCount ?? 0,
      animals: existing?.animals ?? [],
      salesStats: existing?.salesStats ?? createEmptySalesStats(),
      farmTreesCount: existing?.farmTreesCount ?? 34,
      cropsCount: existing?.cropsCount ?? 0,
      inventorySummary: existing?.inventorySummary ?? [],
      updatedAt: Date.now(),
    };
    savePlayerSnapshot(snap);
    res.json({ ok: true, uid, player: snap });
  });

  app.post('/api/admin/tree-ecosystem', requireLocalAdmin, (req, res) => {
    const b = req.body || {};
    const action = String(b.action || 'config');
    if (b.config && typeof b.config === 'object') {
      const c = b.config as Partial<GlobalTreeEcosystemConfig>;
      if (typeof c.minTrees === 'number') liveTreeEcosystemConfig.minTrees = Math.max(50, Math.min(600, Math.floor(c.minTrees)));
      if (typeof c.maxTrees === 'number') liveTreeEcosystemConfig.maxTrees = Math.max(liveTreeEcosystemConfig.minTrees + 20, Math.min(750, Math.floor(c.maxTrees)));
      if (typeof c.growthIntervalSec === 'number') liveTreeEcosystemConfig.growthIntervalSec = Math.max(5, Math.min(600, Math.floor(c.growthIntervalSec)));
      if (typeof c.carpenterCutIntervalSec === 'number') liveTreeEcosystemConfig.carpenterCutIntervalSec = Math.max(5, Math.min(600, Math.floor(c.carpenterCutIntervalSec)));
      if (typeof c.growthBatchMin === 'number') liveTreeEcosystemConfig.growthBatchMin = Math.max(1, Math.min(50, Math.floor(c.growthBatchMin)));
      if (typeof c.growthBatchMax === 'number') liveTreeEcosystemConfig.growthBatchMax = Math.max(liveTreeEcosystemConfig.growthBatchMin, Math.min(80, Math.floor(c.growthBatchMax)));
      if (typeof c.carpenterCutBatchMin === 'number') liveTreeEcosystemConfig.carpenterCutBatchMin = Math.max(1, Math.min(50, Math.floor(c.carpenterCutBatchMin)));
      if (typeof c.carpenterCutBatchMax === 'number') liveTreeEcosystemConfig.carpenterCutBatchMax = Math.max(liveTreeEcosystemConfig.carpenterCutBatchMin, Math.min(80, Math.floor(c.carpenterCutBatchMax)));
      logTreeEcosystemEvent('config', 0, `Bounds ${liveTreeEcosystemConfig.minTrees}-${liveTreeEcosystemConfig.maxTrees}, growth ${liveTreeEcosystemConfig.growthIntervalSec}s, Orin cut ${liveTreeEcosystemConfig.carpenterCutIntervalSec}s`);
    }
    if (action === 'sprout') {
      const amount = Math.max(1, Math.min(80, Math.floor(Number(b.amount ?? 15))));
      const added = spawnRandomGlobalTrees(amount);
      if (added > 0) {
        logTreeEcosystemEvent('sprout', added, `Developer sprouted +${added} protected global trees.`);
        broadcastGlobalTrees();
      }
    } else if (action === 'carpenter_cut') {
      const amount = Math.max(1, Math.min(80, Math.floor(Number(b.amount ?? 15))));
      const removed = carpenterOrinCutTrees(amount);
      if (removed > 0) {
        logTreeEcosystemEvent('carpenter_cut', -removed, `Carpenter Orin harvested -${removed} global trees.`);
        broadcastGlobalTrees();
      }
    }
    res.json({
      ok: true,
      stats: getGlobalTreeStats(),
      config: liveTreeEcosystemConfig,
      log: globalTreeEcosystemLog.slice(0, 20),
    });
  });

  function applyPlayerOverride(body: Record<string, unknown>) {
    const { targetUid, gold, diamond, theme, fun, level, stamina, xp, animalHappiness, salesStats, inventoryUpdates } = body;
    const rawTarget = String(targetUid || '').trim();
    const targetUids: string[] =
      rawTarget === '__ALL__'
        ? Array.from(new Set(Array.from(sessions.values()).map((s) => s.player.uid)))
        : rawTarget && isValidUid(rawTarget)
          ? [rawTarget]
          : [];

    if (targetUids.length === 0) {
      return { ok: false, status: 400, error: 'A specific valid targetUid (or __ALL__ with online players) must be selected first.' };
    }

    const validThemes = new Set<ThemeMode>(['cozy', 'farmhouse', 'system', 'light', 'dark', 'seasonal']);
    const nextGold = typeof gold === 'number' && Number.isFinite(gold) ? Math.max(0, Math.min(999_999_999, Math.floor(gold))) : undefined;
    const nextDiamond = typeof diamond === 'number' && Number.isFinite(diamond) ? Math.max(0, Math.min(999_999_999, Math.floor(diamond))) : undefined;
    const nextTheme = typeof theme === 'string' && validThemes.has(theme as ThemeMode) ? (theme as ThemeMode) : undefined;
    const nextFun = typeof fun === 'number' && Number.isFinite(fun) ? Math.max(0, Math.min(100, Math.floor(fun))) : undefined;
    const nextLevel = typeof level === 'number' && Number.isFinite(level) ? Math.max(1, Math.min(999, Math.floor(level))) : undefined;
    const nextStamina = typeof stamina === 'number' && Number.isFinite(stamina) ? Math.max(0, Math.min(999, Math.floor(stamina))) : undefined;
    const nextXp = typeof xp === 'number' && Number.isFinite(xp) ? Math.max(0, Math.min(999_999_999, Math.floor(xp))) : undefined;
    const nextAvatarConfig = body.avatarConfig && typeof body.avatarConfig === 'object' ? (body.avatarConfig as Partial<AvatarConfig>) : undefined;
    const nextEquipment = typeof body.equippedItemId === 'string' ? body.equippedItemId.slice(0, 64) : undefined;
    const nextSkills = body.skills && typeof body.skills === 'object' ? (body.skills as Record<string, number>) : undefined;

    let cleanInventoryUpdates: AdminInventoryUpdate[] | undefined;
    if (Array.isArray(inventoryUpdates)) {
      cleanInventoryUpdates = [];
      for (const entry of inventoryUpdates.slice(0, 40)) {
        if (!entry || typeof entry !== 'object') continue;
        const rawEntry = entry as Record<string, unknown>;
        const itemId = String(rawEntry.itemId || '').trim();
        if (!itemId || !ITEMS[itemId]) continue;
        const qty = Math.max(0, Math.min(99999, Math.floor(Number(rawEntry.quantity ?? 0))));
        const mode: 'set' | 'add' = rawEntry.mode === 'add' ? 'add' : 'set';
        cleanInventoryUpdates.push({
          itemId,
          quantity: qty,
          mode,
          diamondTradeable: typeof rawEntry.diamondTradeable === 'boolean' ? rawEntry.diamondTradeable : undefined,
        });
      }
      if (cleanInventoryUpdates.length === 0) cleanInventoryUpdates = undefined;
    }

    let cleanAnimalHappiness: Record<string, number> | undefined;
    if (animalHappiness && typeof animalHappiness === 'object' && !Array.isArray(animalHappiness)) {
      cleanAnimalHappiness = {};
      for (const [k, v] of Object.entries(animalHappiness as Record<string, unknown>)) {
        const num = Number(v);
        if (Number.isFinite(num)) {
          cleanAnimalHappiness[String(k).slice(0, 48)] = Math.max(0, Math.min(100, Math.floor(num)));
        }
      }
    }

    const sanitizeSales = (raw: unknown): SalesStats | undefined => {
      if (!raw || typeof raw !== 'object') return undefined;
      const r = raw as Record<string, unknown>;
      const base = createEmptySalesStats();
      const seasons: Season[] = ['Spring', 'Summer', 'Autumn', 'Winter'];
      const mg = (r.marketGoldBySeason && typeof r.marketGoldBySeason === 'object' ? r.marketGoldBySeason : {}) as Record<string, { qty?: unknown; revenue?: unknown }>;
      const pd = (r.p2pDiamondBySeason && typeof r.p2pDiamondBySeason === 'object' ? r.p2pDiamondBySeason : {}) as Record<string, { qty?: unknown; revenue?: unknown }>;
      let mgTotalQty = 0;
      let mgTotalRev = 0;
      let pdTotalQty = 0;
      let pdTotalRev = 0;
      for (const s of seasons) {
        const mq = Math.max(0, Math.min(999_999_999, Math.floor(Number(mg[s]?.qty ?? 0) || 0)));
        const mr = Math.max(0, Math.min(999_999_999, Math.floor(Number(mg[s]?.revenue ?? 0) || 0)));
        const pq = Math.max(0, Math.min(999_999_999, Math.floor(Number(pd[s]?.qty ?? 0) || 0)));
        const pr = Math.max(0, Math.min(999_999_999, Math.floor(Number(pd[s]?.revenue ?? 0) || 0)));
        base.marketGoldBySeason[s] = { qty: mq, revenue: mr };
        base.p2pDiamondBySeason[s] = { qty: pq, revenue: pr };
        mgTotalQty += mq;
        mgTotalRev += mr;
        pdTotalQty += pq;
        pdTotalRev += pr;
      }
      base.marketGoldTotalQty = mgTotalQty;
      base.marketGoldTotalRevenue = mgTotalRev;
      base.p2pDiamondTotalQty = pdTotalQty;
      base.p2pDiamondTotalRevenue = pdTotalRev;
      return base;
    };
    const nextSalesStats = sanitizeSales(salesStats);

    let deliveredCount = 0;
    let lastSnap: StoredPlayerSnapshot | null = null;
    for (const cleanUid of targetUids) {
      const existing = getPlayerSnapshot(cleanUid);
      const online = Array.from(sessions.values()).find((s) => s.player.uid === cleanUid);

      const updatedAnimals = (existing?.animals || []).map((a) => {
        if (!cleanAnimalHappiness) return a;
        const byId = cleanAnimalHappiness[a.id];
        const byType = cleanAnimalHappiness[a.type];
        const overrideVal = typeof byId === 'number' ? byId : typeof byType === 'number' ? byType : undefined;
        return overrideVal !== undefined ? { ...a, affection: overrideVal } : a;
      });

      const updatedInv = [...(existing?.inventorySummary || [])];
      if (cleanInventoryUpdates) {
        for (const u of cleanInventoryUpdates) {
          const idx = updatedInv.findIndex((sl) => sl.itemId === u.itemId && Boolean(sl.diamondTradeable) === Boolean(u.diamondTradeable));
          if (idx >= 0) {
            const nextQty = u.mode === 'add' ? updatedInv[idx].quantity + u.quantity : u.quantity;
            if (nextQty <= 0) updatedInv.splice(idx, 1);
            else updatedInv[idx] = { ...updatedInv[idx], quantity: nextQty };
          } else if (u.quantity > 0) {
            updatedInv.push({ itemId: u.itemId, quantity: u.quantity, diamondTradeable: u.diamondTradeable });
          }
        }
      }

      const updatedSnap: StoredPlayerSnapshot = {
        uid: cleanUid,
        avatarName: online?.player.avatarName || existing?.avatarName || 'Farmer',
        farmName: online?.player.farmName || existing?.farmName || 'Valley Farm',
        email: existing?.email,
        isDeveloper: existing?.isDeveloper,
        gold: nextGold ?? existing?.gold ?? 0,
        diamond: nextDiamond ?? existing?.diamond ?? 0,
        theme: nextTheme ?? existing?.theme ?? 'farmhouse',
        level: nextLevel ?? online?.player.level ?? existing?.level ?? 1,
        xp: nextXp ?? existing?.xp ?? 0,
        fun: nextFun ?? existing?.fun ?? 100,
        zone: online?.player.zone || existing?.zone || 'farm_home',
        hasPhone: existing?.hasPhone ?? false,
        animalsCount: updatedAnimals.length || existing?.animalsCount || 0,
        animals: updatedAnimals,
        salesStats: nextSalesStats ?? existing?.salesStats ?? createEmptySalesStats(),
        farmTreesCount: existing?.farmTreesCount ?? 0,
        cropsCount: existing?.cropsCount ?? 0,
        inventorySummary: updatedInv,
        updatedAt: Date.now(),
      };
      savePlayerSnapshot(updatedSnap);
      lastSnap = updatedSnap;

      if (nextGold !== undefined || nextDiamond !== undefined) {
        recordEncryptedTransaction({
          id: `tx_${crypto.randomUUID().slice(0, 10)}`,
          type: 'admin_adjust',
          buyerUid: cleanUid,
          buyerName: updatedSnap.avatarName,
          currency: nextDiamond !== undefined ? 'diamond' : 'gold',
          amount: nextDiamond !== undefined ? nextDiamond : (nextGold ?? 0),
          description: `Real-time Dev override (Gold=${updatedSnap.gold}, Diamond=${updatedSnap.diamond}, Theme=${updatedSnap.theme})`,
          timestamp: Date.now(),
        });
        appendHistoryLog({
          category: nextDiamond !== undefined ? 'diamond_spend' : 'gold_spend',
          uid: cleanUid,
          playerName: updatedSnap.avatarName,
          currency: nextDiamond !== undefined ? 'diamond' : 'gold',
          amount: nextDiamond !== undefined ? nextDiamond : (nextGold ?? 0),
          summary: `Dev Panel adjusted currency -> Gold: ${updatedSnap.gold}, Diamond: ${updatedSnap.diamond}`,
        });
      }
      if (cleanInventoryUpdates && cleanInventoryUpdates.length > 0) {
        appendHistoryLog({
          category: 'item',
          uid: cleanUid,
          playerName: updatedSnap.avatarName,
          itemName: cleanInventoryUpdates.map((u) => `${u.itemId} (${u.mode} ${u.quantity})`).join(', '),
          summary: `Dev Panel inventory update (${cleanInventoryUpdates.length} item entries)`,
        });
      }

      if (online) {
        deliveredCount++;
        sendJson(online.ws, {
          type: 'admin:player_sync',
          gold: nextGold,
          diamond: nextDiamond,
          theme: nextTheme,
          fun: nextFun,
          level: nextLevel,
          stamina: nextStamina,
          xp: nextXp,
          animalHappiness: cleanAnimalHappiness,
          salesStats: nextSalesStats,
          inventoryUpdates: cleanInventoryUpdates,
          avatarConfig: nextAvatarConfig,
          equippedItemId: nextEquipment,
          skills: nextSkills,
        });
      }
    }

    return { ok: true, status: 200, player: lastSnap, deliveredLive: deliveredCount > 0, deliveredCount };
  }

  app.post('/api/admin/player-override', requireLocalAdmin, (req, res) => {
    const result = applyPlayerOverride((req.body || {}) as Record<string, unknown>);
    if (!result.ok) {
      res.status(result.status || 400).json({ ok: false, error: result.error });
      return;
    }
    res.json(result);
  });

  // ============================================================================
  // NAKAMA SOCIAL AUTH GATEWAY (Google, Steam, Apple) + 3-DAY CHARACTER ROSTER
  // ============================================================================
  const requireSocialAuth = async (req: Request, res: Response, next: NextFunction) => {
    const authorization = String(req.headers.authorization || '');
    const match = authorization.match(/^Bearer\s+(.+)$/i);
    if (!match) {
      res.status(401).json({ ok: false, error: 'Social authentication required' });
      return;
    }
    const identity = await verifySocialOrFirebaseToken(match[1].trim());
    if (!identity || identity.isAnonymous) {
      res.status(401).json({ ok: false, error: 'Valid non-guest social session required' });
      return;
    }
    res.locals.socialIdentity = identity;
    next();
  };

  const requireDeveloperAuth = async (req: Request, res: Response, next: NextFunction) => {
    const authorization = String(req.headers.authorization || '');
    const match = authorization.match(/^Bearer\s+(.+)$/i);
    if (match) {
      const identity = await verifySocialOrFirebaseToken(match[1].trim());
      if (identity && isIdentityRegisteredDeveloper(identity)) {
        // Check if Owner revoked this developer's active session recently
        if (!isIdentityOwner(identity)) {
          const store = readOwnerDeveloperStore();
          const revokedAt = store.revokedTokensBefore[identity.uid] || store.revokedTokensBefore[identity.accountId] || 0;
          if (revokedAt > Date.now() - 5 * 60 * 1000) {
            res.status(401).json({ ok: false, error: 'Developer session was revoked by the Owner. Please sign in again.' });
            return;
          }
        }
        res.locals.socialIdentity = identity;
        res.locals.isOwner = isIdentityOwner(identity);
        res.setHeader('Cache-Control', 'no-store');
        next();
        return;
      }
    }
    const configuredToken = (process.env.ADMIN_MONITOR_TOKEN || '').trim();
    const suppliedToken = String(req.headers['x-admin-token'] || '');
    if (
      configuredToken &&
      suppliedToken.length === configuredToken.length &&
      crypto.timingSafeEqual(Buffer.from(suppliedToken), Buffer.from(configuredToken))
    ) {
      res.locals.isOwner = true;
      res.setHeader('Cache-Control', 'no-store');
      next();
      return;
    }
    res.status(403).json({ ok: false, error: 'Registered Owner or Developer authentication required.' });
  };

  const requireOwnerAuth = async (req: Request, res: Response, next: NextFunction) => {
    const authorization = String(req.headers.authorization || '');
    const match = authorization.match(/^Bearer\s+(.+)$/i);
    if (match) {
      const identity = await verifySocialOrFirebaseToken(match[1].trim());
      if (identity && isIdentityOwner(identity)) {
        res.locals.socialIdentity = identity;
        res.locals.isOwner = true;
        res.setHeader('Cache-Control', 'no-store');
        next();
        return;
      }
    }
    res.status(403).json({ ok: false, error: 'Owner account authentication required.' });
  };

  app.get('/api/nakama/auth/providers', (_req, res) => {
    const nakamaHost = (process.env.NAKAMA_HOST || '').trim();
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ok: true,
      gatewayMode: nakamaHost ? 'external_nakama' : 'built_in_nakama_sync',
      nakamaConfigured: Boolean(nakamaHost),
      deletionGraceDays: 3,
      maxCharactersPerAccount: MAX_CHARACTERS_PER_ACCOUNT,
      providers: {
        google: {
          id: 'google',
          label: 'Google',
          enabled: true,
          configured: true,
        },
        steam: {
          id: 'steam',
          label: 'Steam',
          enabled: true,
          configured: Boolean(process.env.STEAM_API_KEY || true),
          openIdAvailable: true,
          apiKeyConfigured: Boolean(process.env.STEAM_API_KEY),
        },
        apple: {
          id: 'apple',
          label: 'Apple',
          enabled: true,
          configured: Boolean(process.env.APPLE_SERVICE_ID || firebaseProjectId),
          serviceIdConfigured: Boolean(process.env.APPLE_SERVICE_ID),
        },
      },
    });
  });

  app.get('/api/nakama/auth/steam/start', (req, res) => {
    const proto = String(req.headers['x-forwarded-proto'] || req.protocol || 'http').split(',')[0].trim();
    const host = String(req.headers['x-forwarded-host'] || req.get('host') || `localhost:${PORT}`).split(',')[0].trim();
    const origin = `${proto}://${host}`;
    const returnTo = `${origin}/api/nakama/auth/steam/callback`;
    const params = new URLSearchParams({
      'openid.ns': 'http://specs.openid.net/auth/2.0',
      'openid.mode': 'checkid_setup',
      'openid.return_to': returnTo,
      'openid.realm': origin,
      'openid.identity': 'http://specs.openid.net/auth/2.0/identifier_select',
      'openid.claimed_id': 'http://specs.openid.net/auth/2.0/identifier_select',
    });
    res.redirect(`https://steamcommunity.com/openid/login?${params.toString()}`);
  });

  app.get('/api/nakama/auth/steam/callback', async (req, res) => {
    try {
      const q = req.query as Record<string, string>;
      if (q['openid.mode'] !== 'id_res' || !q['openid.claimed_id']) {
        res.status(400).send('Steam OpenID authentication was cancelled or invalid.');
        return;
      }
      // Strictly verify OpenID assertion directly against steamcommunity.com (allowlisted host only)
      const verifyBody = new URLSearchParams();
      for (const [k, v] of Object.entries(q)) {
        if (k.startsWith('openid.')) verifyBody.set(k, String(v));
      }
      verifyBody.set('openid.mode', 'check_authentication');
      const verifyRes = await fetch('https://steamcommunity.com/openid/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: verifyBody.toString(),
      });
      const verifyText = await verifyRes.text();
      if (!verifyText.includes('is_valid:true')) {
        res.status(401).send('Steam OpenID signature verification failed.');
        return;
      }
      const idMatch = String(q['openid.claimed_id']).match(/^https?:\/\/steamcommunity\.com\/openid\/id\/(\d{17})$/);
      if (!idMatch) {
        res.status(400).send('Unable to extract valid SteamID64.');
        return;
      }
      const steamId = idMatch[1];
      let personaName = `Steam_${steamId.slice(-6)}`;
      const steamApiKey = (process.env.STEAM_API_KEY || '').trim();
      if (steamApiKey) {
        try {
          const profRes = await fetch(
            `https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=${encodeURIComponent(steamApiKey)}&steamids=${encodeURIComponent(steamId)}`
          );
          if (profRes.ok) {
            const profJson = (await profRes.json()) as { response?: { players?: Array<{ personaname?: string }> } };
            const foundName = profJson?.response?.players?.[0]?.personaname;
            if (foundName) personaName = String(foundName).slice(0, 32);
          }
        } catch {
          // fallback to Steam_XXXXXX persona
        }
      }
      const identity: Omit<VerifiedSocialIdentity, 'isAnonymous'> = {
        accountId: `steam_${steamId}`,
        uid: `steam_${steamId}`,
        provider: 'steam',
        email: `steam_${steamId}@steam.greatvalley.local`,
        displayName: personaName,
      };
      const sessionToken = signNakamaSessionToken(identity);
      const safePayload = JSON.stringify({
        type: 'hgv_nakama_social_auth',
        provider: 'steam',
        token: sessionToken,
        identity,
      }).replace(/</g, '\\u003c');
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(`<!doctype html><html><body><script>
        try {
          if (typeof BroadcastChannel !== 'undefined') {
            var ch = new BroadcastChannel('hgv_nakama_steam_auth');
            ch.postMessage(${safePayload});
            ch.close();
          }
          if (window.opener) {
            window.opener.postMessage(${safePayload}, window.location.origin);
          }
        } catch (e) {}
        window.close();
      </script><p>Steam authentication complete. You may close this tab and return to Harvest in the Great Valley.</p></body></html>`);
    } catch (err) {
      res.status(500).send(`Steam authentication error: ${err instanceof Error ? err.message : 'Unknown error'}`);
    }
  });

  app.post('/api/nakama/auth/authenticate', requireSocialAuth, (req, res) => {
    const identity = res.locals.socialIdentity as VerifiedSocialIdentity;
    purgeExpiredCharacterDeletions();
    const characters = nakamaCharacterRosterStore.get(identity.accountId) || [];
    const nakamaSessionToken = signNakamaSessionToken({
      accountId: identity.accountId,
      uid: identity.uid,
      provider: identity.provider,
      email: identity.email,
      displayName: identity.displayName,
    });
    const isDeveloper = isIdentityRegisteredDeveloper(identity);
    const devRecord = readDeveloperSocialRecord();
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ok: true,
      account: {
        accountId: identity.accountId,
        uid: identity.uid,
        provider: identity.provider,
        email: identity.email,
        displayName: identity.displayName,
      },
      isDeveloper,
      developerConfigured: Boolean(devRecord),
      nakamaSessionToken,
      characters,
    });
  });

  app.get('/api/nakama/characters', requireSocialAuth, (_req, res) => {
    const identity = res.locals.socialIdentity as VerifiedSocialIdentity;
    purgeExpiredCharacterDeletions();
    const characters = nakamaCharacterRosterStore.get(identity.accountId) || [];
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, accountId: identity.accountId, provider: identity.provider, characters });
  });

  app.post('/api/nakama/characters', requireSocialAuth, (req, res) => {
    const identity = res.locals.socialIdentity as VerifiedSocialIdentity;
    purgeExpiredCharacterDeletions();
    const existing = nakamaCharacterRosterStore.get(identity.accountId) || [];
    if (existing.length >= MAX_CHARACTERS_PER_ACCOUNT) {
      res.status(400).json({ ok: false, error: `Maximum ${MAX_CHARACTERS_PER_ACCOUNT} characters per account reached.` });
      return;
    }
    const b = (req.body || {}) as Partial<CharacterRosterEntry>;
    const avatarName = String(b.avatarName || '').trim().replace(/\s+/g, ' ').slice(0, 32);
    const farmName = String(b.farmName || 'Great Valley Farm').trim().slice(0, 36) || 'Great Valley Farm';
    if (Array.from(avatarName).length < 1) {
      res.status(400).json({ ok: false, error: 'Display Name cannot be empty.' });
      return;
    }
    const starterGold = liveRuntimeConfig.debugMode ? 999_999_999 : liveRuntimeConfig.normalStarterGold;
    const starterDiamond = liveRuntimeConfig.debugMode ? 999_999_999 : liveRuntimeConfig.normalStarterDiamond;
    const now = Date.now();
    const entry: CharacterRosterEntry = {
      characterId: `char_${crypto.randomBytes(6).toString('hex')}`,
      accountId: identity.accountId,
      provider: identity.provider,
      avatarName,
      farmName,
      gender: b.gender === 'female' ? 'female' : 'male',
      birthday: String(b.birthday || 'Spring 5').slice(0, 32),
      dogName: String(b.dogName || 'Biscuit').slice(0, 24),
      horseName: String(b.horseName || 'Maple').slice(0, 24),
      avatarConfig: b.avatarConfig || {
        gender: b.gender === 'female' ? 'female' : 'male',
        skinColor: '#fcd5b5',
        eyeColor: '#292524',
        hairStyle: 'spiky',
        hairColor: '#6b3e1b',
        shirtStyle: 'overalls',
        pantsStyle: 'trousers',
        outfitColor: '#3a6b2c',
        pantsColor: '#1e3a8a',
        hatStyle: 'none',
        accessory: 'none',
      },
      level: 1,
      gold: starterGold,
      diamond: starterDiamond,
      season: 'Spring',
      day: 1,
      year: 1,
      createdAt: now,
      lastPlayedAt: now,
      deletionScheduledAt: null,
      deletionExecuteAt: null,
    };
    const nextList = [...existing, entry];
    nakamaCharacterRosterStore.set(identity.accountId, nextList);
    persistNakamaCharacterRoster();
    res.json({ ok: true, character: entry, characters: nextList });
  });

  app.post('/api/nakama/characters/:characterId/save', requireSocialAuth, (req, res) => {
    const identity = res.locals.socialIdentity as VerifiedSocialIdentity;
    purgeExpiredCharacterDeletions();
    const charId = String(req.params.characterId || '').trim();
    const list = nakamaCharacterRosterStore.get(identity.accountId) || [];
    const idx = list.findIndex((c) => c.characterId === charId);
    if (idx < 0) {
      res.status(404).json({ ok: false, error: 'Character not found in this social account.' });
      return;
    }
    const b = (req.body || {}) as Partial<CharacterRosterEntry>;
    const validSeasons: Season[] = ['Spring', 'Summer', 'Autumn', 'Winter'];
    const current = list[idx];
    const updated: CharacterRosterEntry = {
      ...current,
      avatarName: b.avatarName ? String(b.avatarName).trim().slice(0, 32) : current.avatarName,
      farmName: b.farmName ? String(b.farmName).trim().slice(0, 36) : current.farmName,
      avatarConfig: b.avatarConfig || current.avatarConfig,
      level: typeof b.level === 'number' && Number.isFinite(b.level) ? Math.max(1, Math.floor(b.level)) : current.level,
      gold: typeof b.gold === 'number' && Number.isFinite(b.gold) ? Math.max(0, Math.floor(b.gold)) : current.gold,
      diamond: typeof b.diamond === 'number' && Number.isFinite(b.diamond) ? Math.max(0, Math.floor(b.diamond)) : current.diamond,
      season: validSeasons.includes(b.season as Season) ? (b.season as Season) : current.season,
      day: typeof b.day === 'number' && Number.isFinite(b.day) ? Math.max(1, Math.min(30, Math.floor(b.day))) : current.day,
      year: typeof b.year === 'number' && Number.isFinite(b.year) ? Math.max(1, Math.floor(b.year)) : current.year,
      lastPlayedAt: Date.now(),
      savePayload: b.savePayload && typeof b.savePayload === 'object' ? b.savePayload : current.savePayload,
    };
    list[idx] = updated;
    nakamaCharacterRosterStore.set(identity.accountId, list);
    persistNakamaCharacterRoster();
    res.json({ ok: true, character: updated });
  });

  app.post('/api/nakama/characters/:characterId/rename', requireSocialAuth, (req, res) => {
    const identity = res.locals.socialIdentity as VerifiedSocialIdentity;
    const charId = String(req.params.characterId || '').trim();
    const list = nakamaCharacterRosterStore.get(identity.accountId) || [];
    const idx = list.findIndex((c) => c.characterId === charId);
    if (idx < 0) {
      res.status(404).json({ ok: false, error: 'Character not found in this account.' });
      return;
    }
    const displayName = String(req.body?.displayName || '').trim().replace(/\s+/g, ' ');
    const length = Array.from(displayName).length;
    if (length < 1 || length > 32) {
      res.status(400).json({ ok: false, error: 'Display Name must contain 1–32 characters.' });
      return;
    }
    recalcMarketEntry('service_display_name_rename');
    const fee = Math.max(250, Math.floor(marketState.prices.service_display_name_rename?.diamondPrice || liveRuntimeConfig.nameChangeEconomyConfig.basePriceDiamond));
    const current = list[idx];
    if (current.diamond < fee) {
      res.status(400).json({ ok: false, error: `Not enough Diamonds. Required: ${fee}.`, requiredDiamond: fee, currentDiamond: current.diamond });
      return;
    }
    const updated: CharacterRosterEntry = {
      ...current,
      avatarName: displayName,
      diamond: current.diamond - fee,
      lastPlayedAt: Date.now(),
    };
    list[idx] = updated;
    nakamaCharacterRosterStore.set(identity.accountId, list);
    persistNakamaCharacterRoster();
    for (const session of sessions.values()) {
      if (session.player.uid === identity.uid) session.player.avatarName = displayName;
    }
    const nameUpdatePayload = JSON.stringify({ type: 'player:display_name', uid: identity.uid, avatarName: displayName });
    for (const session of sessions.values()) {
      if (session.ws.readyState === WebSocket.OPEN) session.ws.send(nameUpdatePayload);
    }
    const serviceEntry = marketState.prices.service_display_name_rename;
    if (serviceEntry) {
      serviceEntry.demand = Math.min(200, serviceEntry.demand + 1.5);
      recalcMarketEntry('service_display_name_rename');
      broadcastMarketUpdate();
    }
    res.json({ ok: true, character: updated, chargedDiamond: fee, marketPrice: fee });
  });

  app.post('/api/nakama/characters/:characterId/schedule-delete', requireSocialAuth, (req, res) => {
    const identity = res.locals.socialIdentity as VerifiedSocialIdentity;
    purgeExpiredCharacterDeletions();
    const charId = String(req.params.characterId || '').trim();
    const list = nakamaCharacterRosterStore.get(identity.accountId) || [];
    const idx = list.findIndex((c) => c.characterId === charId);
    if (idx < 0) {
      res.status(404).json({ ok: false, error: 'Character not found in this social account.' });
      return;
    }
    const now = Date.now();
    list[idx] = {
      ...list[idx],
      deletionScheduledAt: now,
      deletionExecuteAt: now + CHARACTER_DELETION_GRACE_MS,
    };
    nakamaCharacterRosterStore.set(identity.accountId, list);
    persistNakamaCharacterRoster();
    res.json({
      ok: true,
      character: list[idx],
      characters: list,
      graceDays: 3,
      message: 'Character scheduled for permanent deletion in 3 days. You can cancel anytime before then.',
    });
  });

  app.post('/api/nakama/characters/:characterId/cancel-delete', requireSocialAuth, (req, res) => {
    const identity = res.locals.socialIdentity as VerifiedSocialIdentity;
    purgeExpiredCharacterDeletions();
    const charId = String(req.params.characterId || '').trim();
    const list = nakamaCharacterRosterStore.get(identity.accountId) || [];
    const idx = list.findIndex((c) => c.characterId === charId);
    if (idx < 0) {
      res.status(404).json({ ok: false, error: 'Character not found (or deletion period already elapsed).' });
      return;
    }
    list[idx] = {
      ...list[idx],
      deletionScheduledAt: null,
      deletionExecuteAt: null,
    };
    nakamaCharacterRosterStore.set(identity.accountId, list);
    persistNakamaCharacterRoster();
    res.json({ ok: true, character: list[idx], characters: list, message: 'Character deletion cancelled.' });
  });

  // ============================================================================
  // ============================================================================
  // DEVELOPER DASHBOARD SINGLE-OWNER + MULTI-DEVELOPER RBAC & LIVE API (/api/dev/*)
  // ============================================================================
  const listBackupFiles = () => {
    ensureGameDataDir();
    try {
      return readdirSync(DEV_PANEL_BACKUP_DIR)
        .filter((f) => f.endsWith('.json') && !f.startsWith('.'))
        .map((fileName) => {
          const full = path.join(DEV_PANEL_BACKUP_DIR, fileName);
          const st = statSync(full);
          return {
            fileName,
            sizeBytes: st.size,
            createdAt: st.mtimeMs,
            isDefault: fileName.startsWith('backup_default_'),
          };
        })
        .sort((a, b) => b.createdAt - a.createdAt);
    } catch {
      return [];
    }
  };

  app.get('/api/dev/auth-status', (_req, res) => {
    const store = readOwnerDeveloperStore();
    const owner = store.owner;
    const backups = listBackupFiles();
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ok: true,
      configured: Boolean(owner),
      ownerConfigured: Boolean(owner),
      provider: owner?.provider || null,
      displayName: owner?.displayName || null,
      emailMasked: owner?.emailMasked || null,
      registeredAt: owner?.registeredAt || null,
      developerCount: store.developers.length,
      hasDefaultBackup: backups.some((b) => b.isDefault),
      backupCount: backups.length,
    });
  });

  app.post('/api/dev/check-role', requireSocialAuth, (_req, res) => {
    const identity = res.locals.socialIdentity as VerifiedSocialIdentity;
    const store = readOwnerDeveloperStore();
    const owner = store.owner;
    const isOwner = isIdentityOwner(identity);
    const isTeamDev = isIdentityTeamDeveloper(identity);
    const isDeveloper = isOwner || isTeamDev;
    const role: 'owner' | 'developer' | 'player' = isOwner ? 'owner' : isTeamDev ? 'developer' : 'player';
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ok: true,
      configured: Boolean(owner),
      ownerConfigured: Boolean(owner),
      isDeveloper,
      isOwner,
      role,
      dashboardUrl: '/dev-panel',
      developer: owner
        ? { provider: owner.provider, displayName: owner.displayName, emailMasked: owner.emailMasked }
        : null,
    });
  });

  // Public Ban Status Check for Client Lockdown Screen
  app.get('/api/player/ban-status', (req, res) => {
    const uid = String(req.query.uid || '').trim();
    res.setHeader('Cache-Control', 'no-store');
    if (!uid || !isValidUid(uid)) {
      res.json({ ok: true, ban: null });
      return;
    }
    res.json({ ok: true, ban: getActiveBanForUid(uid) });
  });

  const handleClaimOwner = (_req: Request, res: Response) => {
    const identity = res.locals.socialIdentity as VerifiedSocialIdentity;
    const store = readOwnerDeveloperStore();
    const existing = store.owner;
    if (existing) {
      if (isIdentityOwner(identity)) {
        res.json({
          ok: true,
          isDeveloper: true,
          isOwner: true,
          role: 'owner',
          alreadyClaimed: true,
          developer: {
            provider: existing.provider,
            displayName: existing.displayName,
            emailMasked: existing.emailMasked,
            registeredAt: existing.registeredAt,
          },
        });
        return;
      }
      if (isIdentityTeamDeveloper(identity)) {
        res.json({
          ok: true,
          isDeveloper: true,
          isOwner: false,
          role: 'developer',
          alreadyClaimed: true,
          developer: {
            provider: identity.provider,
            displayName: identity.displayName,
            emailMasked: maskEmailAddress(identity.email || `${identity.uid}@social.local`),
            registeredAt: existing.registeredAt,
          },
        });
        return;
      }
      res.status(409).json({
        ok: false,
        error: `Owner account is already registered to ${existing.displayName} (${existing.emailMasked}). Ask the Owner to add your Game ID as a Developer.`,
      });
      return;
    }
    const emailSource = identity.email || `${identity.provider}_${identity.uid}@social.local`;
    const record: DeveloperSocialRecord = {
      accountId: identity.accountId,
      uid: identity.uid,
      provider: identity.provider,
      emailHash: sha256String(emailSource),
      emailMasked: maskEmailAddress(emailSource),
      displayName: identity.displayName || 'Valley Owner',
      registeredAt: new Date().toISOString(),
    };
    writeDeveloperSocialRecord(record);
    appendAuditLog(record.displayName, 'auth', 'claim_owner', `Registered Single Owner (${record.provider})`);
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ok: true,
      isDeveloper: true,
      isOwner: true,
      role: 'owner',
      developer: {
        provider: record.provider,
        displayName: record.displayName,
        emailMasked: record.emailMasked,
        registeredAt: record.registeredAt,
      },
      message: 'This account is now permanently registered as the Single Owner of Harvest in the Great Valley!',
    });
  };

  app.post('/api/dev/claim-owner', requireSocialAuth, handleClaimOwner);
  app.post('/api/dev/claim-developer', requireSocialAuth, handleClaimOwner);

  app.get('/api/dev/state', requireDeveloperAuth, (_req, res) => {
    const onlineByUid = new Map<string, OnlinePlayerState>();
    for (const s of sessions.values()) {
      onlineByUid.set(s.player.uid, s.player);
    }
    const allUids = new Set<string>([...onlineByUid.keys(), ...encryptedPlayerSnapshots.keys()]);
    const players = Array.from(allUids).map((uid) => {
      const online = onlineByUid.get(uid);
      const snap = getPlayerSnapshot(uid);
      const sess = Array.from(sessions.values()).find((s) => s.player.uid === uid);
      return {
        uid,
        online: Boolean(online),
        isGuest: Boolean(sess?.isGuest || uid.startsWith('guest_')),
        guestStartedAt: sess?.guestStartedAt || null,
        avatarName: online?.avatarName || snap?.avatarName || 'Farmer',
        farmName: online?.farmName || snap?.farmName || 'Valley Farm',
        zone: online?.zone || snap?.zone || 'farm_home',
        level: online?.level || snap?.level || 1,
        xp: snap?.xp ?? 0,
        fun: snap?.fun ?? 100,
        gold: snap?.gold ?? 0,
        diamond: snap?.diamond ?? 0,
        theme: snap?.theme || 'cozy',
        animalsCount: snap?.animalsCount ?? 0,
        inventorySummary: snap?.inventorySummary || [],
        loginType: snap?.loginType || (sess?.isGuest ? 'guest' : 'google'),
        activeBan: getActiveBanForUid(uid),
        updatedAt: snap?.updatedAt || Date.now(),
      };
    });
    const itemsCatalog = Object.values(ITEMS).map((it) => ({
      id: it.id,
      name: it.name,
      category: it.category,
      iconEmoji: it.iconEmoji,
      buyPrice: it.buyPrice,
      sellPrice: it.sellPrice,
      diamondPrice: it.diamondPrice,
      description: it.description,
    }));
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ok: true,
      timestamp: Date.now(),
      onlineCount: sessions.size,
      worldClock: getAuthoritativeWorldTime(),
      runtimeConfig: liveRuntimeConfig,
      globalTreeStats: getGlobalTreeStats(),
      players,
      itemsCatalog,
      npcs: NPCS.map((n) => ({
        id: n.id,
        name: n.name,
        role: n.profession,
        homeZone: n.homeZone,
        schedule: n.schedule,
      })),
      bans: Array.from(bansStore.values()),
      developer: readDeveloperSocialRecord()
        ? {
            provider: readDeveloperSocialRecord()!.provider,
            displayName: readDeveloperSocialRecord()!.displayName,
            emailMasked: readDeveloperSocialRecord()!.emailMasked,
            registeredAt: readDeveloperSocialRecord()!.registeredAt,
          }
        : null,
    });
  });

  app.post('/api/dev/runtime-config', requireDeveloperAuth, (req, res) => {
    const b = (req.body || {}) as Partial<RuntimeGameConfig> & { triggerAnnouncementNow?: boolean };
    const result = applyRuntimeConfigPatch(b);
    const devName = readDeveloperSocialRecord()?.displayName || 'Developer';
    appendAuditLog(devName, 'world', 'runtime_config_patch', `Updated runtime config keys: ${Object.keys(b).join(', ')}`);
    res.json(result);
  });

  app.post('/api/dev/player-override', requireDeveloperAuth, (req, res) => {
    const body = (req.body || {}) as Record<string, unknown>;
    const result = applyPlayerOverride(body);
    if (!result.ok) {
      res.status(result.status || 400).json({ ok: false, error: result.error });
      return;
    }
    const devName = readDeveloperSocialRecord()?.displayName || 'Developer';
    appendAuditLog(
      devName,
      body.gold !== undefined || body.diamond !== undefined ? 'economy' : 'character',
      'player_override',
      `Applied live player override to ${String(body.targetUid || '')}`,
      String(body.targetUid || '')
    );
    res.json(result);
  });

  app.post('/api/dev/tree-ecosystem', requireDeveloperAuth, (req, res) => {
    const b = req.body || {};
    const action = String(b.action || 'config');
    if (action === 'sprout') {
      const amount = Math.max(1, Math.min(80, Math.floor(Number(b.amount ?? 15))));
      const added = spawnRandomGlobalTrees(amount);
      if (added > 0) {
        logTreeEcosystemEvent('sprout', added, `Developer sprouted +${added} protected global trees.`);
        broadcastGlobalTrees();
      }
    } else if (action === 'carpenter_cut') {
      const amount = Math.max(1, Math.min(80, Math.floor(Number(b.amount ?? 15))));
      const removed = carpenterOrinCutTrees(amount);
      if (removed > 0) {
        logTreeEcosystemEvent('carpenter_cut', -removed, `Carpenter Orin harvested -${removed} global trees.`);
        broadcastGlobalTrees();
      }
    }
    appendAuditLog(readDeveloperSocialRecord()?.displayName || 'Developer', 'world', `tree_${action}`, `Tree ecosystem action: ${action}`);
    res.json({ ok: true, stats: getGlobalTreeStats(), config: liveTreeEcosystemConfig });
  });

  // === LIVE ENVIRONMENT VARIABLE & RUNTIME CONFIG INJECTION (SECRETS STRICTLY MASKED) ===
  app.get('/api/dev/env-config', requireDeveloperAuth, (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const entries = MANAGED_ENV_VARS.map((meta) => {
      const liveVal = liveEnvOverrides.get(meta.key) ?? process.env[meta.key] ?? '';
      const configured = liveVal.trim().length > 0;
      return {
        key: meta.key,
        group: meta.group,
        isSecret: meta.isSecret,
        configured,
        value: meta.isSecret ? '' : (configured ? liveVal : meta.defaultValue),
        preview: meta.isSecret ? (configured ? '••••••••••••' : '(not set)') : (configured ? liveVal : meta.defaultValue),
      };
    });
    res.json({ ok: true, entries, publicEnvConfig: liveRuntimeConfig.publicEnvConfig });
  });

  app.post('/api/dev/env-config', requireDeveloperAuth, (req, res) => {
    const updates = (req.body?.updates || req.body || {}) as Record<string, unknown>;
    const updatedKeys: string[] = [];
    for (const [k, rawVal] of Object.entries(updates)) {
      const meta = MANAGED_ENV_MAP.get(k);
      if (!meta || typeof rawVal !== 'string') continue;
      // Do not overwrite an existing secret with an empty string unless explicitly requested
      if (meta.isSecret && rawVal.trim() === '') continue;
      const cleanVal = rawVal.trim().slice(0, 4096);
      liveEnvOverrides.set(k, cleanVal);
      process.env[k] = cleanVal;
      updatedKeys.push(k);
    }
    const persisted: Record<string, string> = {};
    for (const [k, v] of liveEnvOverrides.entries()) persisted[k] = v;
    writeJsonFileSafe(ENV_LIVE_CONFIG_FILE, persisted, true);
    syncPublicEnvToRuntimeConfig();
    savePersistedRuntimeOverride();
    broadcastRuntimeConfigNow(false);
    appendAuditLog(
      readDeveloperSocialRecord()?.displayName || 'Developer',
      'env',
      'update_env_vars',
      `Updated ${updatedKeys.length} live env vars: ${updatedKeys.join(', ')}`
    );
    res.json({ ok: true, updatedKeys, publicEnvConfig: liveRuntimeConfig.publicEnvConfig });
  });

  // === BAN & MODERATION MANAGER ===
  app.get('/api/dev/bans', requireDeveloperAuth, (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const list = Array.from(bansStore.values()).map((b) => {
      if (b.active && b.expiresAt && Date.now() >= b.expiresAt) {
        b.active = false;
      }
      return b;
    });
    res.json({ ok: true, bans: list });
  });

  app.post('/api/dev/bans', requireDeveloperAuth, (req, res) => {
    const b = req.body || {};
    const uid = String(b.uid || '').trim();
    if (!uid || !isValidUid(uid)) {
      res.status(400).json({ ok: false, error: 'Valid player UID is required.' });
      return;
    }
    const validTypes: BanType[] = ['chat_ban', 'temporary_ban', 'permanent_ban', 'account_lock'];
    const banType: BanType = validTypes.includes(b.banType) ? b.banType : 'temporary_ban';
    const durationMinutes =
      banType === 'permanent_ban' || banType === 'account_lock'
        ? null
        : Math.max(1, Math.min(525600, Math.round(Number(b.durationMinutes) || 60)));
    const now = Date.now();
    const snap = getPlayerSnapshot(uid);
    const devName = readDeveloperSocialRecord()?.displayName || 'Developer';
    const rec: PlayerBanRecord = {
      id: `ban_${crypto.randomUUID().slice(0, 10)}`,
      uid,
      playerName: String(b.playerName || snap?.avatarName || uid).slice(0, 48),
      banType,
      reason: String(b.reason || 'Violation of Great Valley community rules.').slice(0, 240),
      adminNote: String(b.adminNote || '').slice(0, 300),
      devMessage: String(b.devMessage || 'Please contact support if you believe this restriction is an error.').slice(0, 320),
      issuedBy: devName,
      issuedAt: now,
      expiresAt: durationMinutes ? now + durationMinutes * 60_000 : null,
      durationMinutes,
      active: true,
    };
    bansStore.set(uid, rec);
    writeJsonFileSafe(BANS_FILE, Array.from(bansStore.values()));
    broadcastBanUpdateToUid(uid, rec);
    appendAuditLog(devName, 'ban', `issue_${banType}`, `Banned ${rec.playerName} (${uid}) [${banType}]: ${rec.reason}`, uid);
    res.json({ ok: true, ban: rec });
  });

  app.delete('/api/dev/bans/:uid', requireDeveloperAuth, (req, res) => {
    const uid = String(req.params.uid || '').trim();
    const existing = bansStore.get(uid);
    if (existing) {
      existing.active = false;
      bansStore.set(uid, existing);
      writeJsonFileSafe(BANS_FILE, Array.from(bansStore.values()));
    }
    broadcastBanUpdateToUid(uid, null);
    appendAuditLog(readDeveloperSocialRecord()?.displayName || 'Developer', 'ban', 'lift_ban', `Lifted ban for ${uid}`, uid);
    res.json({ ok: true, uid });
  });

  // === GLOBAL ANNOUNCER (5 NOTICE CATEGORIES) ===
  app.post('/api/dev/announcement', requireDeveloperAuth, (req, res) => {
    const b = req.body || {};
    const validCats: AnnouncementCategory[] = ['update', 'maintenance', 'event', 'emergency', 'promotion'];
    const category: AnnouncementCategory = validCats.includes(b.category) ? b.category : 'update';
    const title = String(b.title || 'Valley Notice').trim().slice(0, 80);
    const message = String(b.message || '').trim().slice(0, 360);
    const durationSec = Math.max(3, Math.min(180, Math.round(Number(b.durationSec) || 12)));
    const enabled = b.enabled === undefined ? true : Boolean(b.enabled);

    liveRuntimeConfig.announcementBanner = { enabled, category, title, message, durationSec };
    savePersistedRuntimeOverride();
    const pushPayload = JSON.stringify({
      type: 'announcement:push',
      announcement: liveRuntimeConfig.announcementBanner,
    });
    for (const s of sessions.values()) {
      if (s.ws.readyState === WebSocket.OPEN) {
        s.ws.send(pushPayload);
      }
    }
    broadcastRuntimeConfigNow(enabled);
    appendAuditLog(
      readDeveloperSocialRecord()?.displayName || 'Developer',
      'announcement',
      `broadcast_${category}`,
      `Broadcasted [${category}] "${title}": ${message}`
    );
    res.json({ ok: true, announcement: liveRuntimeConfig.announcementBanner, notified: sessions.size });
  });

  // === DIALOG MANAGEMENT (BRANCHING MULTI-LANGUAGE DIALOGUE EDITOR) ===
  app.get('/api/dev/dialogues', requireDeveloperAuth, (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, dialogues: liveRuntimeConfig.branchingDialogues || [] });
  });

  app.post('/api/dev/dialogues', requireDeveloperAuth, (req, res) => {
    const raw = (req.body || {}) as Partial<BranchingDialogueNode>;
    const npcId = String(raw.npcId || '').trim();
    if (!npcId) {
      res.status(400).json({ ok: false, error: 'npcId is required' });
      return;
    }
    const list = [...(liveRuntimeConfig.branchingDialogues || [])];
    const node: BranchingDialogueNode = {
      id: raw.id && String(raw.id).trim() ? String(raw.id).trim().slice(0, 64) : `dlg_${crypto.randomUUID().slice(0, 10)}`,
      npcId,
      title: String(raw.title || 'Custom Dialogue').slice(0, 80),
      trigger: raw.trigger || 'greeting',
      textByLang: {
        en: String(raw.textByLang?.en || '').slice(0, 400),
        id: String(raw.textByLang?.id || '').slice(0, 400),
      },
      choices: Array.isArray(raw.choices)
        ? raw.choices.slice(0, 6).map((c) => ({
            id: c.id || `ch_${crypto.randomUUID().slice(0, 6)}`,
            labelByLang: {
              en: String(c.labelByLang?.en || 'Continue').slice(0, 120),
              id: String(c.labelByLang?.id || 'Lanjutkan').slice(0, 120),
            },
            replyByLang: {
              en: String(c.replyByLang?.en || 'Thank you!').slice(0, 320),
              id: String(c.replyByLang?.id || 'Terima kasih!').slice(0, 320),
            },
            friendshipDelta: Math.max(-50, Math.min(50, Math.round(Number(c.friendshipDelta) || 0))),
            affectionDelta: Math.max(-50, Math.min(50, Math.round(Number(c.affectionDelta) || 0))),
            questId: c.questId ? String(c.questId).slice(0, 64) : undefined,
            rewardGold: Math.max(0, Math.min(100000, Math.round(Number(c.rewardGold) || 0))),
            nextNodeId: c.nextNodeId ? String(c.nextNodeId).slice(0, 64) : undefined,
          }))
        : [],
      updatedAt: Date.now(),
    };
    const idx = list.findIndex((n) => n.id === node.id);
    if (idx >= 0) list[idx] = node;
    else list.unshift(node);
    liveRuntimeConfig.branchingDialogues = list;
    writeJsonFileSafe(DIALOGUES_FILE, list);
    broadcastRuntimeConfigNow(false);
    appendAuditLog(readDeveloperSocialRecord()?.displayName || 'Developer', 'dialogue', 'save_dialogue', `Saved dialogue "${node.title}" for NPC ${npcId}`, node.id);
    res.json({ ok: true, dialogue: node, dialogues: list });
  });

  app.delete('/api/dev/dialogues/:id', requireDeveloperAuth, (req, res) => {
    const id = String(req.params.id || '');
    const list = (liveRuntimeConfig.branchingDialogues || []).filter((d) => d.id !== id);
    liveRuntimeConfig.branchingDialogues = list;
    writeJsonFileSafe(DIALOGUES_FILE, list);
    broadcastRuntimeConfigNow(false);
    appendAuditLog(readDeveloperSocialRecord()?.displayName || 'Developer', 'dialogue', 'delete_dialogue', `Deleted dialogue ${id}`, id);
    res.json({ ok: true, dialogues: list });
  });

  // === ITEM MANAGEMENT ===
  app.get('/api/dev/items', requireDeveloperAuth, (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ok: true,
      customItems: liveRuntimeConfig.customItems || [],
      allItems: Object.values(ITEMS),
    });
  });

  app.post('/api/dev/items', requireDeveloperAuth, (req, res) => {
    const raw = (req.body || {}) as Partial<ItemDef>;
    const cleanId = String(raw.id || `item_custom_${crypto.randomUUID().slice(0, 6)}`).trim().replace(/[^a-zA-Z0-9_]/g, '_').slice(0, 48);
    if (!cleanId) {
      res.status(400).json({ ok: false, error: 'Valid item ID is required.' });
      return;
    }
    const rawExtra = raw as Partial<ItemDef> & { stackable?: boolean; edible?: boolean; giftValue?: number };
    const item: ItemDef = {
      id: cleanId,
      name: String(raw.name || 'Custom Item').slice(0, 60),
      category: raw.category || 'Materials',
      description: String(raw.description || 'Added via Dev Panel.').slice(0, 240),
      buyPrice: Math.max(0, Math.min(999_999, Math.round(Number(raw.buyPrice) || 0))),
      sellPrice: Math.max(0, Math.min(999_999, Math.round(Number(raw.sellPrice) || 0))),
      diamondPrice: raw.diamondPrice ? Math.max(0, Math.min(99999, Math.round(Number(raw.diamondPrice)))) : undefined,
      iconEmoji: String(raw.iconEmoji || '🎁').slice(0, 8),
      iconColor: String(raw.iconColor || '#f59e0b').slice(0, 24),
      isGiftable: raw.isGiftable !== false,
      staminaRestore: raw.staminaRestore ? Math.round(Number(raw.staminaRestore)) : undefined,
      ...(rawExtra.edible ? { funRestore: 10 } : {}),
    };
    ITEMS[cleanId] = item;
    marketState.prices[cleanId] = {
      itemId: cleanId,
      buyPrice: item.buyPrice,
      sellPrice: item.sellPrice,
      diamondPrice: item.diamondPrice,
      multiplier: 1.0,
      trend: 'stable',
      supply: 50,
      demand: 50,
    };
    const list = [...(liveRuntimeConfig.customItems || [])];
    const idx = list.findIndex((i) => i.id === cleanId);
    if (idx >= 0) list[idx] = item;
    else list.unshift(item);
    liveRuntimeConfig.customItems = list;
    writeJsonFileSafe(CUSTOM_ITEMS_FILE, list);
    broadcastMarketUpdate();
    broadcastRuntimeConfigNow(false);
    appendAuditLog(readDeveloperSocialRecord()?.displayName || 'Developer', 'item', 'save_item', `Saved item ${item.name} (${item.id})`, item.id);
    res.json({ ok: true, item, customItems: list });
  });

  app.delete('/api/dev/items/:id', requireDeveloperAuth, (req, res) => {
    const id = String(req.params.id || '');
    const list = (liveRuntimeConfig.customItems || []).filter((i) => i.id !== id);
    liveRuntimeConfig.customItems = list;
    writeJsonFileSafe(CUSTOM_ITEMS_FILE, list);
    broadcastRuntimeConfigNow(false);
    appendAuditLog(readDeveloperSocialRecord()?.displayName || 'Developer', 'item', 'delete_item', `Removed custom item ${id}`, id);
    res.json({ ok: true, customItems: list });
  });

  // === SHOP MANAGEMENT (PRODUCTS, PRICES, DISCOUNTS, BUNDLES) ===
  app.get('/api/dev/shop', requireDeveloperAuth, (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, products: liveRuntimeConfig.customShopProducts || [] });
  });

  app.post('/api/dev/shop', requireDeveloperAuth, (req, res) => {
    const raw = (req.body || {}) as Partial<CustomShopProduct>;
    const prod: CustomShopProduct = {
      id: raw.id && String(raw.id).trim() ? String(raw.id).trim().slice(0, 48) : `shop_${crypto.randomUUID().slice(0, 8)}`,
      name: String(raw.name || 'Special Bundle').slice(0, 64),
      description: String(raw.description || '').slice(0, 220),
      shopId: raw.shopId || 'general_store',
      itemId: String(raw.itemId || 'crop_turnip').slice(0, 64),
      quantity: Math.max(1, Math.min(999, Math.round(Number(raw.quantity) || 1))),
      goldPrice: Math.max(0, Math.min(999_999, Math.round(Number(raw.goldPrice) || 0))),
      diamondPrice: Math.max(0, Math.min(99_999, Math.round(Number(raw.diamondPrice) || 0))),
      discountPercent: Math.max(0, Math.min(95, Math.round(Number(raw.discountPercent) || 0))),
      isBundle: Boolean(raw.isBundle),
      bundleItems: Array.isArray(raw.bundleItems) ? raw.bundleItems.slice(0, 8) : undefined,
      active: raw.active !== false,
    };
    const list = [...(liveRuntimeConfig.customShopProducts || [])];
    const idx = list.findIndex((p) => p.id === prod.id);
    if (idx >= 0) list[idx] = prod;
    else list.unshift(prod);
    liveRuntimeConfig.customShopProducts = list;
    writeJsonFileSafe(CUSTOM_SHOP_FILE, list);
    broadcastRuntimeConfigNow(false);
    appendAuditLog(readDeveloperSocialRecord()?.displayName || 'Developer', 'shop', 'save_shop_product', `Saved shop product "${prod.name}" (-${prod.discountPercent}%)`, prod.id);
    res.json({ ok: true, product: prod, products: list });
  });

  app.delete('/api/dev/shop/:id', requireDeveloperAuth, (req, res) => {
    const id = String(req.params.id || '');
    const list = (liveRuntimeConfig.customShopProducts || []).filter((p) => p.id !== id);
    liveRuntimeConfig.customShopProducts = list;
    writeJsonFileSafe(CUSTOM_SHOP_FILE, list);
    broadcastRuntimeConfigNow(false);
    appendAuditLog(readDeveloperSocialRecord()?.displayName || 'Developer', 'shop', 'delete_shop_product', `Deleted shop product ${id}`, id);
    res.json({ ok: true, products: list });
  });

  // === NPC SCHEDULE OVERRIDES ===
  app.post('/api/dev/npc-schedules', requireDeveloperAuth, (req, res) => {
    const raw = (req.body || {}) as { npcId?: string; schedule?: NpcScheduleOverride['schedule']; rainBehavior?: NpcScheduleOverride['rainBehavior'] };
    const npcId = String(raw.npcId || '').trim();
    if (!npcId || !Array.isArray(raw.schedule)) {
      res.status(400).json({ ok: false, error: 'npcId and schedule array are required.' });
      return;
    }
    const nextMap = { ...(liveRuntimeConfig.npcScheduleOverrides || {}) };
    nextMap[npcId] = raw.schedule.slice(0, 12);
    liveRuntimeConfig.npcScheduleOverrides = nextMap;
    writeJsonFileSafe(NPC_SCHEDULES_FILE, nextMap);
    broadcastRuntimeConfigNow(false);
    appendAuditLog(readDeveloperSocialRecord()?.displayName || 'Developer', 'npc', 'update_npc_schedule', `Updated live schedule for NPC ${npcId}`, npcId);
    res.json({ ok: true, npcScheduleOverrides: nextMap });
  });

  // === ECONOMY MONITORING DASHBOARD ===
  app.get('/api/dev/economy-monitor', requireDeveloperAuth, (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    let totalServerGold = 0;
    let totalServerDiamond = 0;
    const allSnaps = Array.from(persistedPlayerRegistry.values());
    for (const p of allSnaps) {
      totalServerGold += Number(p.gold || 0);
      totalServerDiamond += Number(p.diamond || 0);
    }
    const spendByUid = new Map<string, { uid: string; playerName: string; goldSpent: number; diamondSpent: number; txCount: number }>();
    for (const h of historyLogsStore) {
      if (h.category === 'gold_spend' || h.category === 'diamond_spend' || h.category === 'trading') {
        const cur = spendByUid.get(h.uid) || { uid: h.uid, playerName: h.playerName, goldSpent: 0, diamondSpent: 0, txCount: 0 };
        if (h.currency === 'diamond') cur.diamondSpent += Number(h.amount || 0);
        else cur.goldSpent += Number(h.amount || 0);
        cur.txCount += 1;
        spendByUid.set(h.uid, cur);
      }
    }
    const topSpenders = Array.from(spendByUid.values())
      .sort((a, b) => (b.diamondSpent * 1000 + b.goldSpent) - (a.diamondSpent * 1000 + a.goldSpent))
      .slice(0, 15);
    res.json({
      ok: true,
      totalServerGold,
      totalServerDiamond,
      totalAccounts: allSnaps.length,
      onlineAccounts: sessions.size,
      marketVolumeGold: marketState.totalVolumeGold,
      taxPoolGold: marketState.taxPool,
      taxPoolDiamond: marketState.taxPoolDiamond || 0,
      activeP2PListings: Array.from(p2pMarketStore.values()).filter((l) => l.status === 'active').length,
      topSpenders,
    });
  });

  // === HISTORY TRACKING & SEARCHABLE AUDIT LOG ===
  app.get('/api/dev/history', requireDeveloperAuth, (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const type = String(req.query.type || 'all');
    const q = String(req.query.q || '').trim().toLowerCase();
    let list = historyLogsStore;
    if (type !== 'all') list = list.filter((h) => h.category === type);
    if (q) {
      list = list.filter(
        (h) =>
          h.playerName.toLowerCase().includes(q) ||
          h.uid.toLowerCase().includes(q) ||
          h.summary.toLowerCase().includes(q)
      );
    }
    res.json({ ok: true, logs: list.slice(0, 200) });
  });

  app.get('/api/dev/audit-logs', requireDeveloperAuth, (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const category = String(req.query.category || 'all');
    const q = String(req.query.q || '').trim().toLowerCase();
    let list = auditLogsStore;
    if (category !== 'all') list = list.filter((a) => a.category === category);
    if (q) {
      list = list.filter(
        (a) =>
          a.actor.toLowerCase().includes(q) ||
          a.action.toLowerCase().includes(q) ||
          a.summary.toLowerCase().includes(q)
      );
    }
    res.json({ ok: true, logs: list.slice(0, 250) });
  });

  // ============================================================================
  // OWNER & DEVELOPER TEAM MANAGEMENT (SINGLE OWNER PINNED TOP)
  // ============================================================================
  app.get('/api/dev/team', requireOwnerAuth, (_req, res) => {
    const store = readOwnerDeveloperStore();
    const onlineUids = new Set(Array.from(sessions.values()).map((s) => s.player.uid));
    const registeredPlayerIds = Array.from(
      new Set<string>([...onlineUids, ...encryptedPlayerSnapshots.keys(), ...Array.from(nakamaCharacterRosterStore.keys())])
    )
      .filter((id) => !id.startsWith('guest_'))
      .map((uid) => {
        const snap = getPlayerSnapshot(uid);
        return {
          uid,
          avatarName: snap?.avatarName || uid,
          online: onlineUids.has(uid),
        };
      });
    res.json({
      ok: true,
      owner: store.owner
        ? {
            uid: store.owner.uid,
            accountId: store.owner.accountId,
            provider: store.owner.provider,
            displayName: store.owner.displayName,
            emailMasked: store.owner.emailMasked,
            registeredAt: store.owner.registeredAt,
            online: onlineUids.has(store.owner.uid),
          }
        : null,
      developers: store.developers.map((d) => ({
        ...d,
        online: onlineUids.has(d.uid),
      })),
      registeredPlayerIds,
    });
  });

  app.post('/api/dev/team/add', requireOwnerAuth, (req, res) => {
    const b = (req.body || {}) as { uid?: string; displayName?: string };
    const targetUid = String(b.uid || '').trim();
    if (!targetUid || targetUid.length < 3 || targetUid.length > 128 || targetUid.startsWith('guest_')) {
      res.status(400).json({ ok: false, error: 'Valid registered non-guest Game Player ID is required.' });
      return;
    }
    const store = readOwnerDeveloperStore();
    if (store.owner && (store.owner.uid === targetUid || store.owner.accountId === targetUid)) {
      res.status(409).json({ ok: false, error: 'This ID already belongs to the Owner account.' });
      return;
    }
    if (store.developers.some((d) => d.uid === targetUid)) {
      res.status(409).json({ ok: false, error: 'This Player ID is already registered as a Developer.' });
      return;
    }
    const snap = getPlayerSnapshot(targetUid);
    const ownerName = store.owner?.displayName || 'Owner';
    const member: DeveloperTeamMember = {
      uid: targetUid,
      displayName: String(b.displayName || snap?.avatarName || targetUid).slice(0, 48),
      addedBy: ownerName,
      addedAt: new Date().toISOString(),
    };
    store.developers.push(member);
    delete store.revokedTokensBefore[targetUid];
    writeOwnerDeveloperStore(store);
    appendAuditLog(ownerName, 'auth', 'add_developer', `Added Developer ID ${targetUid} (${member.displayName})`);
    res.json({ ok: true, developer: member, developers: store.developers });
  });

  app.post('/api/dev/team/revoke-session', requireOwnerAuth, (req, res) => {
    const b = (req.body || {}) as { uid?: string };
    const targetUid = String(b.uid || '').trim();
    if (!targetUid) {
      res.status(400).json({ ok: false, error: 'Developer UID required.' });
      return;
    }
    const store = readOwnerDeveloperStore();
    const dev = store.developers.find((d) => d.uid === targetUid);
    if (!dev) {
      res.status(404).json({ ok: false, error: 'Developer not found.' });
      return;
    }
    const now = Date.now();
    dev.sessionRevokedAt = now;
    store.revokedTokensBefore[targetUid] = now;
    writeOwnerDeveloperStore(store);
    // Immediately kick any live WS sessions belonging to that developer
    for (const s of sessions.values()) {
      if (s.player.uid === targetUid && s.ws.readyState === WebSocket.OPEN) {
        s.ws.close(4003, 'Session revoked by Owner');
      }
    }
    appendAuditLog(store.owner?.displayName || 'Owner', 'auth', 'revoke_dev_session', `Revoked active session for Developer ${targetUid}`);
    res.json({ ok: true, revokedAt: now });
  });

  app.delete('/api/dev/team/developer/:uid', requireOwnerAuth, (req, res) => {
    const targetUid = String(req.params.uid || '').trim();
    const store = readOwnerDeveloperStore();
    const before = store.developers.length;
    store.developers = store.developers.filter((d) => d.uid !== targetUid);
    if (store.developers.length === before) {
      res.status(404).json({ ok: false, error: 'Developer not found.' });
      return;
    }
    store.revokedTokensBefore[targetUid] = Date.now();
    writeOwnerDeveloperStore(store);
    for (const s of sessions.values()) {
      if (s.player.uid === targetUid && s.ws.readyState === WebSocket.OPEN) {
        s.ws.close(4003, 'Developer role removed by Owner');
      }
    }
    appendAuditLog(store.owner?.displayName || 'Owner', 'auth', 'delete_developer', `Removed Developer ${targetUid}`);
    res.json({ ok: true, developers: store.developers });
  });

  app.delete('/api/dev/team/owner', requireOwnerAuth, (req, res) => {
    const b = (req.body || {}) as { confirmText?: string };
    if (String(b.confirmText || '').trim().toUpperCase() !== 'DELETE OWNER') {
      res.status(400).json({ ok: false, error: 'Type DELETE OWNER to confirm resetting the Owner account.' });
      return;
    }
    const store = readOwnerDeveloperStore();
    const oldOwner = store.owner?.displayName || 'Owner';
    store.owner = null;
    writeOwnerDeveloperStore(store);
    appendAuditLog(oldOwner, 'auth', 'delete_owner', `Owner account reset — Dev Panel ready for new first-time Owner registration.`);
    res.json({ ok: true, ownerReset: true });
  });

  // ============================================================================
  // OWNER BACKUP MANAGER (web_game/data/data_dev_panel/backup/)
  // ============================================================================
  app.get('/api/dev/backups', requireDeveloperAuth, (_req, res) => {
    const backups = listBackupFiles();
    res.json({
      ok: true,
      backupDir: 'web_game/data/data_dev_panel/backup',
      hasDefaultBackup: backups.some((b) => b.isDefault),
      backups,
    });
  });

  app.post('/api/dev/backups/create', requireDeveloperAuth, (req, res) => {
    ensureGameDataDir();
    const b = (req.body || {}) as { kind?: 'default' | 'manual'; label?: string };
    const kind = b.kind === 'default' ? 'default' : 'manual';
    const identity = res.locals.socialIdentity as VerifiedSocialIdentity | undefined;
    const ownerSlug = (identity?.displayName || readDeveloperSocialRecord()?.displayName || 'owner')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_|_$/g, '')
      .slice(0, 24) || 'owner';
    const customSlug = b.label
      ? '_' +
        String(b.label)
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '_')
          .replace(/^_|_$/g, '')
          .slice(0, 24)
      : '';
    const d = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const stamp = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
    const fileName = `backup_${kind}_${stamp}_by_${ownerSlug}${customSlug}.json`;
    const fullPath = path.join(DEV_PANEL_BACKUP_DIR, fileName);

    const snapshotData = {
      backupMeta: {
        fileName,
        kind,
        createdAt: d.toISOString(),
        createdBy: identity?.displayName || 'Owner',
        gameVersion: 'Harvest in the Great Valley - Bun/HTTPS Edition',
        calendarScheme: SEASON_DAYS,
      },
      runtimeConfig: liveRuntimeConfig,
      bans: Array.from(bansStore.values()),
      branchingDialogues: liveRuntimeConfig.branchingDialogues || [],
      customItems: liveRuntimeConfig.customItems || [],
      customShopProducts: liveRuntimeConfig.customShopProducts || [],
      npcScheduleOverrides: liveRuntimeConfig.npcScheduleOverrides || {},
      playersCount: encryptedPlayerSnapshots.size,
      nakamaAccountsCount: nakamaCharacterRosterStore.size,
    };
    writeFileSync(fullPath, JSON.stringify(snapshotData, null, 2), 'utf8');
    appendAuditLog(identity?.displayName || 'Owner', 'system', 'create_backup', `Created ${kind} backup: ${fileName}`);
    res.json({
      ok: true,
      fileName,
      backupDir: 'web_game/data/data_dev_panel/backup',
      backups: listBackupFiles(),
    });
  });

  app.post('/api/dev/backups/restore', requireOwnerAuth, (req, res) => {
    const b = (req.body || {}) as { fileName?: string };
    const safeName = path.basename(String(b.fileName || '').trim());
    if (!safeName.endsWith('.json')) {
      res.status(400).json({ ok: false, error: 'Invalid backup file name.' });
      return;
    }
    const targetPath = path.resolve(DEV_PANEL_BACKUP_DIR, safeName);
    if (!targetPath.startsWith(DEV_PANEL_BACKUP_DIR + path.sep) || !existsSync(targetPath)) {
      res.status(404).json({ ok: false, error: 'Backup file not found.' });
      return;
    }
    try {
      const parsed = JSON.parse(readFileSync(targetPath, 'utf8')) as { runtimeConfig?: Partial<RuntimeGameConfig> };
      if (parsed.runtimeConfig) {
        applyRuntimeConfigPatch(parsed.runtimeConfig);
      }
      const identity = res.locals.socialIdentity as VerifiedSocialIdentity | undefined;
      appendAuditLog(identity?.displayName || 'Owner', 'system', 'restore_backup', `Restored backup: ${safeName}`);
      res.json({ ok: true, restored: safeName, config: liveRuntimeConfig });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to parse backup file.' });
    }
  });

  // ============================================================================
  // SAFE DEV PANEL FILE EXPLORER (STRICTLY CONFINED + SECRETS HARD-BLOCKED)
  // ============================================================================
  const WORKSPACE_ROOT =
    path.basename(__dirname) === 'harvest_in_the_great_valley'
      ? WEB_GAME_DIR
      : path.resolve(__dirname);
  const BLOCKED_EXPLORER_SEGMENTS = new Set([
    'node_modules',
    '.git',
    'secrets',
    'game_secrets',
    'dev_panel_secrets',
  ]);
  const isPathForbiddenForExplorer = (relPath: string): boolean => {
    const normalized = relPath.replace(/\\/g, '/').replace(/^\/+/, '');
    if (!normalized) return false;
    const segments = normalized.split('/').filter(Boolean);
    for (const seg of segments) {
      const lower = seg.toLowerCase();
      if (BLOCKED_EXPLORER_SEGMENTS.has(lower)) return true;
      if (lower === '.env' || (lower.startsWith('.env.') && lower !== '.env.example')) return true;
      if (lower.endsWith('.pem') || lower.endsWith('.key') || lower === 'firebase-admin.json' || lower === 'owner_developers.json') {
        return true;
      }
    }
    return false;
  };

  const resolveSafeExplorerPath = (relInput: string): { fullPath: string; relPath: string } | null => {
    const cleanRel = String(relInput || '').replace(/\\/g, '/').replace(/^\/+/, '');
    if (cleanRel.includes('\0') || isPathForbiddenForExplorer(cleanRel)) return null;
    const resolved = path.resolve(WORKSPACE_ROOT, cleanRel || '.');
    if (resolved !== WORKSPACE_ROOT && !resolved.startsWith(WORKSPACE_ROOT + path.sep)) return null;
    const finalRel = path.relative(WORKSPACE_ROOT, resolved).replace(/\\/g, '/');
    if (isPathForbiddenForExplorer(finalRel)) return null;
    return { fullPath: resolved, relPath: finalRel };
  };

  app.get('/api/dev/files/list', requireDeveloperAuth, (req, res) => {
    const target = resolveSafeExplorerPath(String(req.query.path || ''));
    if (!target || !existsSync(target.fullPath)) {
      res.status(403).json({ ok: false, error: 'Path is restricted or does not exist.' });
      return;
    }
    try {
      const st = statSync(target.fullPath);
      if (!st.isDirectory()) {
        res.status(400).json({ ok: false, error: 'Target is not a directory.' });
        return;
      }
      const entries = readdirSync(target.fullPath)
        .map((name) => {
          const childRel = target.relPath ? `${target.relPath}/${name}` : name;
          if (isPathForbiddenForExplorer(childRel)) return null;
          try {
            const cStat = statSync(path.join(target.fullPath, name));
            return {
              name,
              path: childRel,
              isDirectory: cStat.isDirectory(),
              sizeBytes: cStat.isDirectory() ? 0 : cStat.size,
              updatedAt: cStat.mtimeMs,
            };
          } catch {
            return null;
          }
        })
        .filter((e): e is NonNullable<typeof e> => Boolean(e))
        .sort((a, b) => (a.isDirectory === b.isDirectory ? a.name.localeCompare(b.name) : a.isDirectory ? -1 : 1));
      res.json({ ok: true, currentPath: target.relPath, entries });
    } catch {
      res.status(500).json({ ok: false, error: 'Unable to list directory.' });
    }
  });

  app.get('/api/dev/files/read', requireDeveloperAuth, (req, res) => {
    const target = resolveSafeExplorerPath(String(req.query.path || ''));
    if (!target || !target.relPath || !existsSync(target.fullPath)) {
      res.status(403).json({ ok: false, error: 'File is restricted or does not exist.' });
      return;
    }
    try {
      const st = statSync(target.fullPath);
      if (st.isDirectory()) {
        res.status(400).json({ ok: false, error: 'Cannot read a directory.' });
        return;
      }
      if (st.size > 512 * 1024) {
        res.status(413).json({ ok: false, error: 'File exceeds 512 KB editor limit.' });
        return;
      }
      const content = readFileSync(target.fullPath, 'utf8');
      res.json({ ok: true, path: target.relPath, sizeBytes: st.size, content });
    } catch {
      res.status(500).json({ ok: false, error: 'Unable to read file.' });
    }
  });

  app.post('/api/dev/files/write', requireDeveloperAuth, (req, res) => {
    const b = (req.body || {}) as { path?: string; content?: string };
    const target = resolveSafeExplorerPath(String(b.path || ''));
    if (!target || !target.relPath) {
      res.status(403).json({ ok: false, error: 'Target path is protected or invalid.' });
      return;
    }
    const content = String(b.content ?? '');
    if (content.length > 512 * 1024) {
      res.status(413).json({ ok: false, error: 'Content exceeds 512 KB limit.' });
      return;
    }
    try {
      mkdirSync(path.dirname(target.fullPath), { recursive: true });
      writeFileSync(target.fullPath, content, 'utf8');
      const identity = res.locals.socialIdentity as VerifiedSocialIdentity | undefined;
      appendAuditLog(identity?.displayName || 'Developer', 'system', 'file_write', `Edited file: ${target.relPath}`);
      res.json({ ok: true, path: target.relPath, sizeBytes: Buffer.byteLength(content, 'utf8') });
    } catch {
      res.status(500).json({ ok: false, error: 'Unable to save file.' });
    }
  });

  app.delete('/api/dev/files/delete', requireDeveloperAuth, (req, res) => {
    const target = resolveSafeExplorerPath(String(req.query.path || ''));
    const PROTECTED_FILES = new Set(['package.json', 'package-lock.json', 'server.ts', 'metadata.json', 'tsconfig.json']);
    if (!target || !target.relPath || PROTECTED_FILES.has(target.relPath) || !existsSync(target.fullPath)) {
      res.status(403).json({ ok: false, error: 'File is protected, restricted, or does not exist.' });
      return;
    }
    try {
      const st = statSync(target.fullPath);
      if (st.isDirectory()) {
        rmSync(target.fullPath, { recursive: true, force: true });
      } else {
        unlinkSync(target.fullPath);
      }
      const identity = res.locals.socialIdentity as VerifiedSocialIdentity | undefined;
      appendAuditLog(identity?.displayName || 'Developer', 'system', 'file_delete', `Deleted: ${target.relPath}`);
      res.json({ ok: true, deleted: target.relPath });
    } catch {
      res.status(500).json({ ok: false, error: 'Unable to delete target.' });
    }
  });

  // ============================================================================
  // HARDENED ENCRYPTED OFFLINE SAVE -> ONLINE VALIDATED SYNC ROUTE
  // ============================================================================
  const offlineSyncRevisions = new Map<string, number>();
  try {
    ensureGameDataDir();
    if (existsSync(OFFLINE_REVISIONS_FILE)) {
      const parsed = JSON.parse(readFileSync(OFFLINE_REVISIONS_FILE, 'utf8')) as Record<string, number>;
      for (const [k, v] of Object.entries(parsed)) {
        if (typeof v === 'number') offlineSyncRevisions.set(k, v);
      }
    }
  } catch {
    // start fresh
  }

  app.post('/api/save/sync', requireSocialAuth, (req, res) => {
    const identity = res.locals.socialIdentity as VerifiedSocialIdentity;
    const b = (req.body || {}) as {
      uid?: string;
      saveRevision?: number;
      profile?: { avatarName?: string; farmName?: string; level?: number; xp?: number; gold?: number; diamond?: number };
      queuedAt?: number;
    };
    const uid = String(b.uid || identity.uid).trim();
    if (!uid || (uid !== identity.uid && uid !== identity.accountId)) {
      res.status(403).json({ ok: false, error: 'Cannot sync save data for another user.' });
      return;
    }
    const incomingRev = Math.max(1, Math.floor(Number(b.saveRevision) || 1));
    const prevRev = offlineSyncRevisions.get(uid) || 0;
    if (incomingRev < prevRev) {
      res.status(409).json({ ok: false, error: 'Stale offline revision rejected.', authoritativeRevision: prevRev });
      return;
    }

    // Server-side anti-tamper bounds validation against last trusted server snapshot
    const prevSnap = getPlayerSnapshot(uid);
    const clampedFields: string[] = [];
    const reqGold = Math.max(0, Math.floor(Number(b.profile?.gold ?? prevSnap?.gold ?? 0)));
    const reqDiamond = Math.max(0, Math.floor(Number(b.profile?.diamond ?? prevSnap?.diamond ?? 0)));
    const reqLevel = Math.max(1, Math.min(200, Math.floor(Number(b.profile?.level ?? prevSnap?.level ?? 1))));

    const maxOfflineGoldGain = liveRuntimeConfig.debugMode ? 999_999_999 : 250_000;
    const maxOfflineDiamondGain = liveRuntimeConfig.debugMode ? 999_999_999 : 500;
    const maxOfflineLevelGain = liveRuntimeConfig.debugMode ? 100 : 10;

    let validatedGold = reqGold;
    let validatedDiamond = reqDiamond;
    let validatedLevel = reqLevel;
    if (prevSnap) {
      if (reqGold > prevSnap.gold + maxOfflineGoldGain) {
        validatedGold = prevSnap.gold + maxOfflineGoldGain;
        clampedFields.push('gold');
      }
      if (reqDiamond > prevSnap.diamond + maxOfflineDiamondGain) {
        validatedDiamond = prevSnap.diamond + maxOfflineDiamondGain;
        clampedFields.push('diamond');
      }
      if (reqLevel > prevSnap.level + maxOfflineLevelGain) {
        validatedLevel = prevSnap.level + maxOfflineLevelGain;
        clampedFields.push('level');
      }
    }

    const nextSnap: StoredPlayerSnapshot = {
      uid,
      avatarName: String(b.profile?.avatarName || prevSnap?.avatarName || identity.displayName || 'Farmer').slice(0, 32),
      farmName: String(b.profile?.farmName || prevSnap?.farmName || 'Great Valley Farm').slice(0, 40),
      level: validatedLevel,
      xp: Math.max(0, Math.floor(Number(b.profile?.xp ?? prevSnap?.xp ?? 0))),
      fun: prevSnap?.fun ?? 100,
      gold: validatedGold,
      diamond: validatedDiamond,
      zone: prevSnap?.zone || 'farm_home',
      theme: prevSnap?.theme || 'cozy',
      hasPhone: prevSnap?.hasPhone ?? false,
      animalsCount: prevSnap?.animalsCount ?? 0,
      cropsCount: prevSnap?.cropsCount ?? 0,
      inventorySummary: prevSnap?.inventorySummary || [],
      loginType: prevSnap?.loginType || 'google',
      updatedAt: Date.now(),
    };
    savePlayerSnapshot(nextSnap);

    const authoritativeRevision = Math.max(prevRev + 1, incomingRev);
    offlineSyncRevisions.set(uid, authoritativeRevision);
    try {
      ensureGameDataDir();
      writeFileSync(OFFLINE_REVISIONS_FILE, JSON.stringify(Object.fromEntries(offlineSyncRevisions.entries()), null, 2), 'utf8');
    } catch {
      // non-fatal
    }
    if (clampedFields.length > 0) {
      appendAuditLog(uid, 'system', 'offline_sync_clamped', `Clamped suspicious offline deltas: ${clampedFields.join(', ')}`);
    }
    res.json({ ok: true, authoritativeRevision, clampedFields });
  });

  // Local self-signed HTTPS is enabled when REQUIRE_HTTPS=1 or ENABLE_HTTPS=1 (e.g. Bun Windows launcher).
  // Checks web_game/tools/runtime/https/ first, then legacy secrets/https/.
  const runtimeHttpsDir = path.resolve(WEB_GAME_DIR, 'tools', 'runtime', 'https');
  const legacyHttpsDir = path.resolve(__dirname, 'secrets', 'https');
  const defaultHttpsDir = existsSync(path.join(runtimeHttpsDir, 'local-cert.pem')) ? runtimeHttpsDir : legacyHttpsDir;
  const httpsKeyPath = path.resolve(
    process.env.HTTPS_KEY_FILE || process.env.HTTPS_KEY_PATH || path.join(defaultHttpsDir, 'local-key.pem')
  );
  const httpsCertPath = path.resolve(
    process.env.HTTPS_CERT_FILE || process.env.HTTPS_CERT_PATH || path.join(defaultHttpsDir, 'local-cert.pem')
  );
  const wantHttps =
    process.env.REQUIRE_HTTPS === '1' ||
    process.env.REQUIRE_HTTPS === 'true' ||
    process.env.ENABLE_HTTPS === '1' ||
    process.env.ENABLE_HTTPS === 'true';
  const hasHttpsCerts = existsSync(httpsKeyPath) && existsSync(httpsCertPath);
  const httpsEnabled = wantHttps && hasHttpsCerts;
  if (process.env.REQUIRE_HTTPS === '1' && !hasHttpsCerts) {
    throw new Error(
      `[HTTPS] HTTPS is required but the certificate pair is missing.\n` +
      `Expected key: ${httpsKeyPath}\nExpected certificate: ${httpsCertPath}`
    );
  }
  const server = httpsEnabled
    ? https.createServer({
        key: readFileSync(httpsKeyPath),
        cert: readFileSync(httpsCertPath),
      }, app)
    : http.createServer(app);
  server.on('error', (err) => {
    console.error('[HTTP Server] Error:', err);
  });

  if (!isProduction) {
    const disableHmr = process.env.DISABLE_HMR === 'true' || Boolean(process.env.CONTROL_PLANE_PORT);
    let viteMiddlewares: ((req: Request, res: Response, next: NextFunction) => void) | null = null;
    const viteReadyPromise = import('vite')
      .then(({ createServer: createViteServer }) =>
        createViteServer({
          configFile: path.join(__dirname, 'vite.config.ts'),
          root: __dirname,
          server: {
            middlewareMode: true,
            hmr: disableHmr ? false : { server },
            watch: disableHmr
              ? null
              : { ignored: ['**/data/**', '**/dev-editor/data/**', '**/dist/**'] },
          },
          appType: 'spa',
        })
      )
      .then((vite) => {
        viteMiddlewares = vite.middlewares;
      })
      .catch((err) => {
        console.error('[Vite] Failed to initialize dev middleware:', err);
      });

    app.use((req, res, next) => {
      if (viteMiddlewares) {
        viteMiddlewares(req, res, next);
        return;
      }
      viteReadyPromise
        .then(() => {
          if (viteMiddlewares) {
            viteMiddlewares(req, res, next);
          } else {
            next();
          }
        })
        .catch(next);
    });
  } else {
    const buildPath = process.env.HARVEST_RUNTIME_DIR
      ? path.join(path.resolve(process.env.HARVEST_RUNTIME_DIR), 'data_game', 'build')
      : path.resolve(__dirname, 'dist');
    const indexPath = path.join(buildPath, 'index.html');
    if (!existsSync(indexPath)) {
      throw new Error(`[Build] Frontend not found: ${indexPath}. Run npm run build first.`);
    }
    app.use(express.static(buildPath));
    app.get('*', (_req, res) => {
      res.sendFile(indexPath);
    });
  }

  const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 64 * 1024 });
  if (httpsEnabled) {
    console.log(`[HTTPS] Enabled with certificate: ${httpsCertPath}`);
  } else {
    console.log('[HTTP] Server listening over HTTP (TLS handled by reverse proxy if present).');
  }

  wss.on('error', (err) => {
    console.warn('[Multiplayer] WebSocket server error:', err instanceof Error ? err.message : err);
  });

  // Periodic WebSocket keepalive ping (25s) prevents reverse proxies from dropping idle connections.
  const wsKeepaliveTimer = setInterval(() => {
    for (const client of wss.clients) {
      if (client.readyState === WebSocket.OPEN) {
        try {
          client.ping();
        } catch {
          // Ignore broken pipe during shutdown
        }
      }
    }
  }, 25_000);
  wss.on('close', () => clearInterval(wsKeepaliveTimer));

  wss.on('connection', (ws) => {
    const clientId = crypto.randomUUID().slice(0, 12);
    let session: ClientSession | null = null;
    let authPending = false;
    const authTimeout = setTimeout(() => {
      if (!session && ws.readyState === WebSocket.OPEN) ws.close(4401, 'Authentication timeout');
    }, 10_000);

    ws.on('error', (err) => {
      console.warn(`[Multiplayer] Client socket error (${clientId}):`, err instanceof Error ? err.message : err);
    });

    ws.on('message', async (raw) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        return;
      }

      const type = String(msg.type || '');

      if (type === 'auth:join') {
        if (session || authPending) return;
        authPending = true;
        const idToken = String(msg.idToken || '');
        if (!idToken || idToken.length > 8192) {
          ws.close(4401, 'Firebase authentication required');
          return;
        }

        try {
          const verifiedIdentity = await verifySocialOrFirebaseToken(idToken);
          const decoded = verifiedIdentity ? null : await verifyFirebaseIdToken(idToken);
          const uid = verifiedIdentity?.uid || decoded?.uid || '';
          if (!uid || uid.length > 128 || !/^[a-zA-Z0-9_\-]+$/.test(uid)) {
            ws.close(4401, 'Invalid authentication identity');
            return;
          }

          const avatarName = String(msg.avatarName || 'Farmer').trim().replace(/\s+/g, ' ').slice(0, 32) || 'Farmer';
          const normalizedAvatarName = avatarName.normalize('NFKC').toLocaleLowerCase('en-US');
          const nameTaken = Array.from(sessions.values()).some((active) =>
            active.player.uid !== uid &&
            active.player.avatarName.normalize('NFKC').toLocaleLowerCase('en-US') === normalizedAvatarName
          );
          if (nameTaken) {
            ws.close(4409, 'Avatar name is already in use');
            return;
          }
          // Reserve display names in Firestore when server-side Firestore credentials are configured;
          // otherwise rely on live active-session uniqueness without triggering IAM errors.
          let nameClaimed = true;
          if (firebaseAdminDb) {
            const nameKey = crypto.createHash('sha256').update(normalizedAvatarName).digest('hex');
            const nameRef = firebaseAdminDb.collection('playerNames').doc(nameKey);
            try {
              nameClaimed = await firebaseAdminDb.runTransaction(async (tx) => {
                const snap = await tx.get(nameRef);
                const ownerUid = snap.exists ? String(snap.get('uid') || '') : '';
                if (ownerUid && ownerUid !== uid) return false;
                tx.set(nameRef, {
                  uid,
                  displayName: avatarName,
                  normalizedName: normalizedAvatarName,
                  updatedAt: Date.now(),
                }, { merge: true });
                return true;
              });
            } catch (nameStoreError) {
              console.warn('[Multiplayer] Firestore playerNames reservation skipped; using active-session uniqueness:', nameStoreError instanceof Error ? nameStoreError.message : nameStoreError);
              nameClaimed = true;
            }
          }
          if (!nameClaimed) {
            ws.close(4409, 'Avatar name is already in use');
            return;
          }
          const farmName = String(msg.farmName || 'Valley Farm').trim().slice(0, 40) || 'Valley Farm';
          const requestedZone = String(msg.zone || 'farm_home') as WorldZoneId;
          const zone = VALID_WORLD_ZONES.has(requestedZone) ? requestedZone : 'farm_home';
          const requestedOwner = String(msg.farmOwnerId || uid);
          const farmOwnerId = /^[a-zA-Z0-9_\-]{1,128}$/.test(requestedOwner) ? requestedOwner : uid;
          const avatarInput = (msg.avatarConfig && typeof msg.avatarConfig === 'object' ? msg.avatarConfig : {}) as Partial<AvatarConfig>;
          const validHairStyles: AvatarConfig['hairStyle'][] = ALL_VALID_HAIRSTYLE_IDS;
          const validHatStyles: AvatarConfig['hatStyle'][] = [
            'none', 'straw_hat', 'farmer_cap', 'flower_clip', 'wizard_hat',
            'cowboy_hat', 'beanie', 'beret', 'crown', 'chef_hat', 'sun_visor',
          ];
          const validAccessories: AvatarConfig['accessory'][] = [
            'none', 'glasses', 'scarf', 'bandana', 'bowtie', 'sunglasses',
          ];
          const validShirtStyles: NonNullable<AvatarConfig['shirtStyle']>[] = [
            'none', 'tunic', 'overalls', 'vest', 'sweater',
            'hoodie', 'flannel', 'jacket', 'apron', 'kimono', 'polo',
          ];
          const validPantsStyles: NonNullable<AvatarConfig['pantsStyle']>[] = [
            'none', 'trousers', 'shorts', 'skirt', 'denim',
            'cargos', 'capri', 'pleated_skirt', 'leggings', 'boots_pants',
          ];
          const rawHairStyle = String(avatarInput.hairStyle || 'spiky') as AvatarConfig['hairStyle'];
          const rawHatStyle = String(avatarInput.hatStyle || 'none') as AvatarConfig['hatStyle'];
          const rawAccessory = String(avatarInput.accessory || 'none') as AvatarConfig['accessory'];
          const rawShirtStyle = String(avatarInput.shirtStyle || 'overalls') as NonNullable<AvatarConfig['shirtStyle']>;
          const rawPantsStyle = String(avatarInput.pantsStyle || 'trousers') as NonNullable<AvatarConfig['pantsStyle']>;
          const avatarConfig: AvatarConfig = {
            gender: avatarInput.gender === 'female' ? 'female' : 'male',
            skinColor: String(avatarInput.skinColor || '#fcd5b5').slice(0, 16),
            eyeColor: String(avatarInput.eyeColor || '#292524').slice(0, 16),
            hairStyle: validHairStyles.includes(rawHairStyle) ? rawHairStyle : 'spiky',
            hairColor: String(avatarInput.hairColor || '#78350f').slice(0, 16),
            shirtStyle: validShirtStyles.includes(rawShirtStyle) ? rawShirtStyle : 'overalls',
            pantsStyle: validPantsStyles.includes(rawPantsStyle) ? rawPantsStyle : 'trousers',
            outfitColor: String(avatarInput.outfitColor || '#2563eb').slice(0, 16),
            pantsColor: String(avatarInput.pantsColor || '#1e3a8a').slice(0, 16),
            hatStyle: validHatStyles.includes(rawHatStyle) ? rawHatStyle : 'none',
            accessory: validAccessories.includes(rawAccessory) ? rawAccessory : 'none',
          };

          const player: OnlinePlayerState = {
            clientId,
            uid, // Never trust msg.uid: identity comes only from the verified ID token.
            avatarName,
            farmName,
            zone,
            farmOwnerId,
            x: finiteNumber(msg.x, -108, -10000, 10000),
            y: finiteNumber(msg.y, 0, -1000, 1000),
            z: finiteNumber(msg.z, -14.2, -10000, 10000),
            yaw: finiteNumber(msg.yaw, Math.PI, -Math.PI * 100, Math.PI * 100),
            animState: 'idle',
            avatarConfig,
            level: finiteNumber(msg.level, 1, 1, 999),
            spousePlayerName: msg.spousePlayerName ? String(msg.spousePlayerName).slice(0, 32) : null,
          };

          clearTimeout(authTimeout);
          const isGuestSession = verifiedIdentity
            ? verifiedIdentity.isAnonymous
            : String(decoded?.firebase?.sign_in_provider || '') === 'anonymous' ||
              (!decoded?.email && String(decoded?.firebase?.sign_in_provider || '') !== 'apple.com');
          session = {
            ws,
            player,
            mutedIds: new Set(),
            blockedIds: new Set(),
            lastChatAt: 0,
            isGuest: isGuestSession,
            guestStartedAt: isGuestSession ? Date.now() : undefined,
          };
          sessions.set(clientId, session);

          // Only the authenticated owner may initialize their own lock state.
          if (
            farmOwnerId === uid &&
            (msg.houseLocked !== undefined ||
              msg.barnLocked !== undefined ||
              msg.coopLocked !== undefined ||
              msg.stableLocked !== undefined)
          ) {
            ownerLocks.set(uid, {
              houseLocked: Boolean(msg.houseLocked),
              barnLocked: msg.barnLocked === undefined ? true : Boolean(msg.barnLocked),
              coopLocked: msg.coopLocked === undefined ? true : Boolean(msg.coopLocked),
              stableLocked: msg.stableLocked === undefined ? true : Boolean(msg.stableLocked),
            });
          } else if (!ownerLocks.has(uid)) {
            ownerLocks.set(uid, { houseLocked: false, barnLocked: true, coopLocked: true, stableLocked: true });
          }

          const peers = getZonePeers(session).map((p) => p.player);
          const farmPlots = farmPlotsStore.get(farmOwnerId) || {};
          const locks = ownerLocks.get(farmOwnerId) || {
            houseLocked: false,
            barnLocked: true,
            coopLocked: true,
            stableLocked: true,
          };
          const activeJobs = Array.from(jobsStore.values())
            .filter((j) => j.status === 'open' || j.status === 'in_progress')
            .sort((a, b) => b.createdAt - a.createdAt)
            .slice(0, 60);
          const activeP2PListings = Array.from(p2pMarketStore.values())
            .filter((l) => l.status === 'active')
            .sort((a, b) => b.createdAt - a.createdAt)
            .slice(0, 120);
          const myFriends = getFriendsForUid(uid);
          const incomingFriendRequests = Array.from(friendRequestsStore.values()).filter((r) => r.toUid === uid);
          const outgoingFriendRequests = Array.from(friendRequestsStore.values()).filter((r) => r.fromUid === uid);

          // Ensure encrypted snapshot record exists immediately on join
          const existingSnap = getPlayerSnapshot(uid);
          const nowTs = Date.now();
          const detectedLoginType: 'guest' | 'google' | 'email' | 'dev' =
            existingSnap?.loginType ||
            (uid.startsWith('dev_')
              ? 'dev'
              : isGuestSession || uid.startsWith('guest_')
                ? 'guest'
                : 'google');
          const resolvedEmail = verifiedIdentity?.email || (typeof decoded?.email === 'string' ? decoded.email : undefined);
          savePlayerSnapshot({
            uid,
            avatarName,
            farmName,
            email: existingSnap?.email || resolvedEmail,
            isDeveloper: existingSnap?.isDeveloper,
            gold: existingSnap?.gold ?? 0,
            diamond: existingSnap?.diamond ?? 0,
            theme: existingSnap?.theme ?? 'farmhouse',
            level: player.level,
            xp: existingSnap?.xp ?? 0,
            fun: existingSnap?.fun ?? 100,
            zone,
            hasPhone: existingSnap?.hasPhone ?? false,
            animalsCount: existingSnap?.animalsCount ?? 0,
            cropsCount: existingSnap?.cropsCount ?? 0,
            inventorySummary: existingSnap?.inventorySummary || [],
            createdAt: existingSnap?.createdAt ?? nowTs,
            lastOnlineAt: nowTs,
            loginType: detectedLoginType,
            updatedAt: nowTs,
          });

          appendHistoryLog({
            category: 'login',
            uid: player.uid,
            playerName: player.avatarName,
            summary: `Player joined zone ${zone} (${detectedLoginType})`,
          });

          sendJson(ws, {
            type: 'auth:welcome',
            clientId,
            peers,
            farmPlots,
            ownerLocks: locks,
            market: marketState,
            taxBuckets: taxRankBuckets,
            recentChat: recentGlobalChat.slice(-20),
            jobs: activeJobs,
            friends: myFriends,
            incomingFriendRequests,
            outgoingFriendRequests,
            p2pListings: activeP2PListings,
            globalTrees: globalTreeRecords,
            runtimeConfig: liveRuntimeConfig,
            activeBan: getActiveBanForUid(player.uid),
            onlineCount: sessions.size,
          });

          broadcastToZone(
            zone,
            isFarmScopedZone(zone) ? farmOwnerId : undefined,
            { type: 'player:join', player },
            clientId
          );
        } catch (error) {
          console.error('[Multiplayer] Join rejected:', error instanceof Error ? `${error.message}${error.stack ? '\\n' + error.stack : ''}` : error);
          if (ws.readyState === WebSocket.OPEN) ws.close(4401, 'Invalid or expired Firebase token');
        }
        return;
      }

      if (!session) return;

      if (type === 'security:lock_update') {
        if (session.player.farmOwnerId !== session.player.uid) return;
        const nextLocks = {
          houseLocked: Boolean(msg.houseLocked),
          barnLocked: Boolean(msg.barnLocked),
          coopLocked: msg.coopLocked === undefined ? true : Boolean(msg.coopLocked),
          stableLocked: msg.stableLocked === undefined ? true : Boolean(msg.stableLocked),
        };
        ownerLocks.set(session.player.uid, nextLocks);
        const payload = {
          type: 'security:locks_updated',
          farmOwnerId: session.player.uid,
          ...nextLocks,
        };
        broadcastToZone('farm_home', session.player.uid, payload);
        broadcastToZone('int_farmhouse', session.player.uid, payload);
        broadcastToZone('int_barn', session.player.uid, payload);
        broadcastToZone('int_coop', session.player.uid, payload);
        broadcastToZone('int_stable', session.player.uid, payload);
        return;
      }

      if (type === 'player:move') {
        if (isFullBanActive(session.player.uid)) {
          sendJson(ws, { type: 'player:banned', uid: session.player.uid, ban: getActiveBanForUid(session.player.uid) });
          return;
        }
        session.player.x = Number(msg.x || 0);
        session.player.y = Number(msg.y || 0);
        session.player.z = Number(msg.z || 0);
        session.player.yaw = Number(msg.yaw || 0);
        session.player.animState = (msg.animState as OnlinePlayerState['animState']) || 'idle';

        broadcastToZone(
          session.player.zone,
          isFarmScopedZone(session.player.zone) ? session.player.farmOwnerId : undefined,
          {
            type: 'player:move',
            clientId: session.player.clientId,
            x: session.player.x,
            y: session.player.y,
            z: session.player.z,
            yaw: session.player.yaw,
            animState: session.player.animState,
          },
          session.player.clientId
        );
        return;
      }

      if (type === 'zone:change') {
        const oldZone = session.player.zone;
        const oldOwner = session.player.farmOwnerId || session.player.uid;
        const requestedZone = String(msg.zone || 'village_square') as WorldZoneId;
        const newZone = VALID_WORLD_ZONES.has(requestedZone) ? requestedZone : 'village_square';
        const requestedOwner = String(msg.farmOwnerId || session.player.uid);
        const newOwner = /^[a-zA-Z0-9_\-]{1,128}$/.test(requestedOwner) ? requestedOwner : session.player.uid;

        const isHiredOnTarget = Boolean(hasActiveJobOnFarm(session.player.uid, newOwner));

        // Enforce private House, Barn, Coop & Stable Auto-Lock for visitors (hired workers may enter Barn/Coop/Stable!)
        if (session.player.uid !== newOwner) {
          const targetLocks = ownerLocks.get(newOwner) || {
            houseLocked: false,
            barnLocked: true,
            coopLocked: true,
            stableLocked: true,
          };
          if (newZone === 'int_farmhouse' && targetLocks.houseLocked) {
            sendJson(ws, { type: 'zone:denied', reason: '🔒 The owner’s private farmhouse is currently locked!' });
            return;
          }
          if (newZone === 'int_barn' && targetLocks.barnLocked && !isHiredOnTarget) {
            sendJson(ws, { type: 'zone:denied', reason: '🔒 The cattle & sheep barn is currently locked!' });
            return;
          }
          if (newZone === 'int_coop' && targetLocks.coopLocked && !isHiredOnTarget) {
            sendJson(ws, { type: 'zone:denied', reason: '🔒 The chicken coop is currently locked!' });
            return;
          }
          if (newZone === 'int_stable' && targetLocks.stableLocked && !isHiredOnTarget) {
            sendJson(ws, { type: 'zone:denied', reason: '🔒 The horse stable is currently locked!' });
            return;
          }
        }
        if (session.player.uid !== oldOwner) {
          const prevLocks = ownerLocks.get(oldOwner) || {
            houseLocked: false,
            barnLocked: true,
            coopLocked: true,
            stableLocked: true,
          };
          const isHiredOnOld = Boolean(hasActiveJobOnFarm(session.player.uid, oldOwner));
          if (oldZone === 'int_farmhouse' && prevLocks.houseLocked) {
            sendJson(ws, { type: 'zone:denied', reason: '🔒 The farmhouse door was locked by its owner.' });
            return;
          }
          if (oldZone === 'int_barn' && prevLocks.barnLocked && !isHiredOnOld) {
            sendJson(ws, { type: 'zone:denied', reason: '🔒 The barn door was locked by its owner.' });
            return;
          }
          if (oldZone === 'int_coop' && prevLocks.coopLocked && !isHiredOnOld) {
            sendJson(ws, { type: 'zone:denied', reason: '🔒 The chicken coop door was locked by its owner.' });
            return;
          }
          if (oldZone === 'int_stable' && prevLocks.stableLocked && !isHiredOnOld) {
            sendJson(ws, { type: 'zone:denied', reason: '🔒 The horse stable door was locked by its owner.' });
            return;
          }
        }

        broadcastToZone(
          oldZone,
          isFarmScopedZone(oldZone) ? oldOwner : undefined,
          { type: 'player:leave', clientId: session.player.clientId },
          session.player.clientId
        );

        session.player.zone = newZone;
        session.player.farmOwnerId = newOwner;
        session.player.x = Number(msg.x || 0);
        session.player.y = 0;
        session.player.z = Number(msg.z || 0);

        const isNewFarmScoped = isFarmScopedZone(newZone);
        const peers = getZonePeers(session).map((p) => p.player);
        const locks = ownerLocks.get(newOwner) || {
          houseLocked: false,
          barnLocked: true,
          coopLocked: true,
          stableLocked: true,
        };
        sendJson(ws, {
          type: 'zone:synced',
          zone: newZone,
          farmOwnerId: newOwner,
          peers,
          ownerLocks: locks,
          farmPlots: isNewFarmScoped ? farmPlotsStore.get(newOwner) || {} : undefined,
        });

        broadcastToZone(
          newZone,
          isNewFarmScoped ? newOwner : undefined,
          { type: 'player:join', player: session.player },
          session.player.clientId
        );
        return;
      }

      if (type === 'marriage:propose') {
        const targetUid = String(msg.targetUid || '');
        const itemId = String(msg.itemId || 'item_golden_ring');
        if (!targetUid || targetUid === session.player.uid) return;
        for (const target of sessions.values()) {
          if (target.player.uid === targetUid) {
            sendJson(target.ws, {
              type: 'marriage:proposal',
              fromUid: session.player.uid,
              fromName: session.player.avatarName,
              fromFarmName: session.player.farmName,
              itemId,
            });
          }
        }
        return;
      }

      if (type === 'marriage:response') {
        const fromUid = String(msg.fromUid || '');
        const accepted = Boolean(msg.accepted);
        const itemId = String(msg.itemId || 'item_golden_ring');
        let proposerSession: ClientSession | null = null;
        for (const s of sessions.values()) {
          if (s.player.uid === fromUid) {
            proposerSession = s;
            break;
          }
        }
        if (accepted && proposerSession) {
          proposerSession.player.spousePlayerName = session.player.avatarName;
          session.player.spousePlayerName = proposerSession.player.avatarName;
          const payload = {
            type: 'marriage:completed',
            accepted: true,
            itemId,
            partnerA: { uid: proposerSession.player.uid, name: proposerSession.player.avatarName },
            partnerB: { uid: session.player.uid, name: session.player.avatarName },
          };
          sendJson(proposerSession.ws, payload);
          sendJson(session.ws, payload);

          const announce: ChatMessage = {
            id: crypto.randomUUID().slice(0, 10),
            channel: 'event',
            senderId: 'valley_system',
            senderName: 'Great Valley Marriage Hall',
            zone: 'village_square',
            text: `💍 Congratulations! ${proposerSession.player.avatarName} & ${session.player.avatarName} are officially married in Great Valley!`,
            timestamp: Date.now(),
          };
          recentGlobalChat.push(announce);
          for (const s of sessions.values()) {
            sendJson(s.ws, { type: 'chat:message', message: announce });
          }
        } else if (proposerSession) {
          sendJson(proposerSession.ws, {
            type: 'marriage:completed',
            accepted: false,
            byName: session.player.avatarName,
          });
        }
        return;
      }

      if (type === 'farm:sync_plots') {
        const ownerId = session.player.uid;
        if (session.player.farmOwnerId !== ownerId || (msg.farmOwnerId && String(msg.farmOwnerId) !== ownerId)) return;
        const incomingPlots = msg.plots as Record<string, unknown>;
        if (incomingPlots && typeof incomingPlots === 'object' && !Array.isArray(incomingPlots) && Object.keys(incomingPlots).length <= 400) {
          const plots = sanitizeFarmPlots(incomingPlots);
          farmPlotsStore.set(ownerId, plots);
          broadcastToZone(
            'farm_home',
            ownerId,
            { type: 'farm:plots_updated', farmOwnerId: ownerId, plots },
            session.player.clientId
          );
        }
        return;
      }

      if (type === 'farm:action') {
        const targetOwner = String(msg.farmOwnerId || session.player.farmOwnerId || session.player.uid);
        const isOwner = targetOwner === session.player.uid && session.player.farmOwnerId === session.player.uid;
        const activeJob = !isOwner ? hasActiveJobOnFarm(session.player.uid, targetOwner) : undefined;
        const plotId = String(msg.plotId || '');
        const action = String(msg.action || '');
        if (!isOwner && !(activeJob && action === 'water')) return;
        if (!/^[0-9]{1,2}_[0-9]{1,2}$/.test(plotId) || !['clear_obstacle', 'till', 'water', 'plant', 'harvest'].includes(action)) return;
        const ownerId = targetOwner;
        const plots = farmPlotsStore.get(ownerId) || {};
        const existingPlot: FarmPlotState = plots[plotId] || {
          id: plotId,
          gx: finiteNumber(msg.gx, 0, 0, 99),
          gz: finiteNumber(msg.gz, 0, 0, 99),
          tilled: false,
          watered: false,
          cropId: null,
          growthDays: 0,
          readyToHarvest: false,
          fertilized: false,
        };

        if (action === 'clear_obstacle' && isOwner) {
          existingPlot.obstacle = null;
          existingPlot.obstacleDays = 0;
        } else if (action === 'till' && isOwner) {
          existingPlot.tilled = true;
        } else if (action === 'water' && existingPlot.tilled) {
          existingPlot.watered = true;
          if (activeJob && activeJob.tasks.includes('water_crops')) {
            const taskKey = `water_${plotId}`;
            if (!activeJob.completedTaskIds.includes(taskKey)) {
              activeJob.completedTaskIds.push(taskKey);
              broadcastJobsList();
            }
          }
        } else if (action === 'plant' && isOwner && existingPlot.tilled && !existingPlot.cropId) {
          const cropId = String(msg.cropId || '');
          if (CROPS[cropId]) {
            existingPlot.cropId = cropId;
            existingPlot.growthDays = 0;
            existingPlot.readyToHarvest = false;
          }
        } else if (action === 'harvest' && isOwner && existingPlot.readyToHarvest) {
          const crop = existingPlot.cropId ? CROPS[existingPlot.cropId] : null;
          if (crop?.regrowsAfterHarvest) {
            existingPlot.growthDays = Math.max(1, crop.daysToGrow - 2);
            existingPlot.readyToHarvest = false;
          } else {
            existingPlot.cropId = null;
            existingPlot.growthDays = 0;
            existingPlot.readyToHarvest = false;
          }
        }

        plots[plotId] = existingPlot;
        farmPlotsStore.set(ownerId, plots);

        broadcastToZone('farm_home', ownerId, {
          type: 'farm:plot_delta',
          farmOwnerId: ownerId,
          plot: existingPlot,
          actorName: session.player.avatarName,
        });
        return;
      }

      // === MULTIPLAYER FARM JOBS BOARD ===
      if (type === 'job:create') {
        const validTasks: FarmJobTaskType[] = ['water_crops', 'feed_cow', 'feed_sheep', 'feed_horse', 'feed_dog'];
        const rawTasks = Array.isArray(msg.tasks) ? msg.tasks.map(String) : [];
        const tasks = rawTasks.filter((t): t is FarmJobTaskType => validTasks.includes(t as FarmJobTaskType));
        if (tasks.length === 0) return;
        const wageGold = Math.floor(finiteNumber(msg.wageGold, 500, 10, 500_000));
        const cropCount = Math.floor(finiteNumber(msg.cropCount, 0, 0, 400));
        const animalCount = Math.floor(finiteNumber(msg.animalCount, 0, 0, 200));
        const totalUnits = Math.max(1, cropCount + animalCount);
        const job: FarmJobOffer = {
          id: `job_${crypto.randomUUID().slice(0, 8)}`,
          employerUid: session.player.uid,
          employerName: session.player.avatarName,
          farmName: session.player.farmName,
          tasks,
          wageGold,
          cropCount,
          animalCount,
          totalUnits,
          completedTaskIds: [],
          workerUid: null,
          workerName: null,
          status: 'open',
          createdAt: Date.now(),
        };
        jobsStore.set(job.id, job);
        broadcastJobsList();
        return;
      }

      if (type === 'job:cancel') {
        const jobId = String(msg.jobId || '');
        const job = jobsStore.get(jobId);
        if (!job || job.employerUid !== session.player.uid) return;
        job.status = 'cancelled';
        broadcastJobsList();
        return;
      }

      if (type === 'job:accept') {
        const jobId = String(msg.jobId || '');
        const job = jobsStore.get(jobId);
        if (!job || job.status !== 'open' || job.employerUid === session.player.uid) return;
        job.status = 'in_progress';
        job.workerUid = session.player.uid;
        job.workerName = session.player.avatarName;
        broadcastJobsList();
        return;
      }

      if (type === 'job:progress') {
        const jobId = String(msg.jobId || '');
        const taskKey = String(msg.taskKey || '').slice(0, 80);
        const job = jobsStore.get(jobId);
        if (!job || job.status !== 'in_progress' || job.workerUid !== session.player.uid || !taskKey) return;
        if (!job.completedTaskIds.includes(taskKey)) {
          job.completedTaskIds.push(taskKey);
          broadcastJobsList();
        }
        return;
      }

      if (type === 'job:complete') {
        const jobId = String(msg.jobId || '');
        const job = jobsStore.get(jobId);
        if (!job || job.status !== 'in_progress') return;
        if (job.workerUid !== session.player.uid && job.employerUid !== session.player.uid) return;
        job.status = 'completed';
        const ratio = Math.min(1, job.completedTaskIds.length / Math.max(1, job.totalUnits));
        const earnedGold = Math.round(job.wageGold * ratio);
        const completionPercent = Math.round(ratio * 100);
        const settlementPayload = {
          type: 'job:settled',
          jobId: job.id,
          employerUid: job.employerUid,
          employerName: job.employerName,
          workerUid: job.workerUid,
          workerName: job.workerName,
          farmName: job.farmName,
          wageGold: job.wageGold,
          earnedGold,
          ratio,
          completionPercent,
        };
        for (const s of sessions.values()) {
          if (s.player.uid === job.employerUid || s.player.uid === job.workerUid) {
            sendJson(s.ws, settlementPayload);
          }
        }
        broadcastJobsList();
        return;
      }

      // === ENCRYPTED PLAYER SNAPSHOT SYNC ===
      if (type === 'player:snapshot') {
        const raw = (msg.snapshot && typeof msg.snapshot === 'object' ? msg.snapshot : {}) as Record<string, unknown>;
        const validThemes = new Set<ThemeMode>(['farmhouse', 'system', 'light', 'dark']);
        const rawTheme = String(raw.theme || 'farmhouse') as ThemeMode;
        const invRaw = Array.isArray(raw.inventorySummary) ? raw.inventorySummary.slice(0, 90) : [];
        const inventorySummary = invRaw
          .filter((x): x is Record<string, unknown> => Boolean(x && typeof x === 'object'))
          .map((x) => ({
            itemId: String(x.itemId || '').slice(0, 64),
            quantity: Math.floor(finiteNumber(x.quantity, 1, 0, 9999)),
            diamondTradeable: Boolean(x.diamondTradeable),
          }));
        const animalsRaw = Array.isArray(raw.animals) ? raw.animals.slice(0, 80) : [];
        const animals: StoredAnimalSummary[] = animalsRaw
          .filter((a): a is Record<string, unknown> => Boolean(a && typeof a === 'object'))
          .map((a) => ({
            id: String(a.id || '').slice(0, 48),
            type: String(a.type || 'chicken').slice(0, 24),
            name: String(a.name || 'Pet').slice(0, 32),
            affection: Math.floor(finiteNumber(a.affection, 50, 0, 100)),
            fedToday: Boolean(a.fedToday),
            brushedToday: Boolean(a.brushedToday),
            birthday: a.birthday ? String(a.birthday).slice(0, 32) : undefined,
          }));
        const existingSnap = getPlayerSnapshot(session.player.uid);
        const salesStats =
          raw.salesStats && typeof raw.salesStats === 'object'
            ? (raw.salesStats as SalesStats)
            : (existingSnap?.salesStats || createEmptySalesStats());
        savePlayerSnapshot({
          uid: session.player.uid,
          avatarName: session.player.avatarName,
          farmName: session.player.farmName,
          email: existingSnap?.email,
          isDeveloper: existingSnap?.isDeveloper,
          gold: Math.floor(finiteNumber(raw.gold, 0, 0, 999_999_999)),
          diamond: Math.floor(finiteNumber(raw.diamond, 0, 0, 999_999_999)),
          theme: validThemes.has(rawTheme) ? rawTheme : 'farmhouse',
          level: Math.floor(finiteNumber(raw.level, session.player.level, 1, 999)),
          xp: Math.floor(finiteNumber(raw.xp, 0, 0, 99_999_999)),
          fun: Math.floor(finiteNumber(raw.fun, 100, 0, 100)),
          zone: session.player.zone,
          hasPhone: Boolean(raw.hasPhone),
          animalsCount: Math.floor(finiteNumber(raw.animalsCount, animals.length, 0, 500)),
          animals,
          salesStats,
          farmTreesCount: Math.floor(finiteNumber(raw.farmTreesCount, existingSnap?.farmTreesCount ?? 0, 0, 200)),
          cropsCount: Math.floor(finiteNumber(raw.cropsCount, 0, 0, 500)),
          inventorySummary,
          lastOnlineAt: Date.now(),
          updatedAt: Date.now(),
        });
        return;
      }

      // === FRIEND SYSTEM (REQUIRED FOR FRIENDS-ONLY CROSS-ZONE VOICE & VIDEO CALLS) ===
      if (type === 'friend:request') {
        const targetUid = String(msg.targetUid || '').trim();
        if (!targetUid || targetUid === session.player.uid || !isValidUid(targetUid)) return;
        if (areMutualFriends(session.player.uid, targetUid)) {
          sendFriendSyncToUid(session.player.uid);
          return;
        }
        const targetSession = Array.from(sessions.values()).find((s) => s.player.uid === targetUid);
        const targetName = targetSession?.player.avatarName || String(msg.targetName || 'Farmer').slice(0, 32);
        const reqKey = `${session.player.uid}__${targetUid}`;
        if (!friendRequestsStore.has(reqKey)) {
          friendRequestsStore.set(reqKey, {
            id: reqKey,
            fromUid: session.player.uid,
            fromName: session.player.avatarName,
            toUid: targetUid,
            toName: targetName,
            createdAt: Date.now(),
          });
        }
        sendFriendSyncToUid(session.player.uid);
        sendFriendSyncToUid(targetUid);
        return;
      }

      if (type === 'friend:respond') {
        const fromUid = String(msg.fromUid || '').trim();
        const accept = Boolean(msg.accept);
        const reqKey = `${fromUid}__${session.player.uid}`;
        const existingReq = friendRequestsStore.get(reqKey);
        if (!existingReq) return;
        friendRequestsStore.delete(reqKey);
        friendRequestsStore.delete(`${session.player.uid}__${fromUid}`);
        const myUid = session.player.uid;
        if (accept) {
          const now = Date.now();
          const myList = getFriendsForUid(myUid).filter((f) => f.uid !== fromUid);
          myList.push({ uid: fromUid, avatarName: existingReq.fromName, since: now });
          saveFriendsForUid(myUid, myList);

          const otherList = getFriendsForUid(fromUid).filter((f) => f.uid !== myUid);
          otherList.push({ uid: myUid, avatarName: session.player.avatarName, farmName: session.player.farmName, since: now });
          saveFriendsForUid(fromUid, otherList);
        }
        sendFriendSyncToUid(myUid);
        sendFriendSyncToUid(fromUid);
        return;
      }

      if (type === 'friend:remove') {
        const myUid = session.player.uid;
        const targetUid = String(msg.targetUid || '').trim();
        if (!targetUid) return;
        saveFriendsForUid(myUid, getFriendsForUid(myUid).filter((f) => f.uid !== targetUid));
        saveFriendsForUid(targetUid, getFriendsForUid(targetUid).filter((f) => f.uid !== myUid));
        sendFriendSyncToUid(myUid);
        sendFriendSyncToUid(targetUid);
        return;
      }

      // === WEBRTC VOICE / VIDEO / GROUP CALL SIGNALING (FRIENDS-ONLY & CROSS-ZONE) ===
      if (type === 'call:join') {
        const roomId = String(msg.roomId || 'valley_group').slice(0, 64);
        const mode: 'voice' | 'video' = msg.mode === 'video' ? 'video' : 'voice';
        const deviceType: 'mobile' | 'desktop' = msg.deviceType === 'mobile' ? 'mobile' : 'desktop';
        removeUidFromAllCallRooms(session.player.uid, 'hangup');
        let room = callRooms.get(roomId);
        if (!room) {
          room = new Map();
          callRooms.set(roomId, room);
          if (!callRoomHosts.has(roomId)) {
            callRoomHosts.set(roomId, session.player.uid);
          }
        }
        room.set(session.player.uid, {
          uid: session.player.uid,
          avatarName: session.player.avatarName,
          mode,
          micOn: msg.micOn !== false,
          camOn: mode === 'video' && msg.camOn !== false,
          deviceType,
        });
        broadcastCallRoomState(roomId);
        return;
      }

      if (type === 'call:leave') {
        removeUidFromAllCallRooms(session.player.uid, 'hangup');
        return;
      }

      if (type === 'call:media_state') {
        const roomId = String(msg.roomId || '').slice(0, 64);
        const room = callRooms.get(roomId);
        const participant = room?.get(session.player.uid);
        if (participant) {
          if (msg.micOn !== undefined) participant.micOn = Boolean(msg.micOn);
          if (msg.camOn !== undefined) participant.camOn = Boolean(msg.camOn);
          if (!participant.camOn) participant.previewFrame = undefined;
          broadcastCallRoomState(roomId);
        }
        return;
      }

      if (type === 'call:preview_frame') {
        const roomId = String(msg.roomId || '').slice(0, 64);
        const frameDataUrl = String(msg.frameDataUrl || '');
        if (!frameDataUrl.startsWith('data:image/jpeg;base64,') || frameDataUrl.length > 24_000) return;
        const room = callRooms.get(roomId);
        const participant = room?.get(session.player.uid);
        if (participant && participant.camOn) {
          participant.previewFrame = frameDataUrl;
          participant.lastFrameAt = Date.now();
        }
        return;
      }

      if (type === 'call:invite') {
        const roomId = String(msg.roomId || '').slice(0, 64);
        const mode: 'voice' | 'video' = msg.mode === 'video' ? 'video' : 'voice';
        const isGroup = Boolean(msg.isGroup);
        const targetUids = Array.isArray(msg.targetUids) ? msg.targetUids.map(String) : [];
        if (targetUids.length === 0) {
          sendJson(ws, { type: 'call:error', reason: 'Select at least one friend from your Friend List to start a call.' });
          return;
        }
        const myUid = session.player.uid;
        const friendTargets = targetUids.filter((tUid) => areMutualFriends(myUid, tUid));
        if (friendTargets.length === 0) {
          sendJson(ws, { type: 'call:error', reason: 'Voice & Video calls are restricted to players on your Friend List.' });
          return;
        }
        callRoomHosts.set(roomId, myUid);
        callRoomInvites.set(roomId, new Set(friendTargets));
        // Cross-zone delivery: invites reach friends regardless of distance or which zone they are in!
        for (const s of sessions.values()) {
          if (s.player.uid === session.player.uid) continue;
          if (friendTargets.includes(s.player.uid)) {
            sendJson(s.ws, {
              type: 'call:incoming_invite',
              roomId,
              mode,
              isGroup,
              fromUid: session.player.uid,
              fromName: session.player.avatarName,
            });
          }
        }
        return;
      }

      if (type === 'call:signal') {
        const targetUid = String(msg.targetUid || '');
        const roomId = String(msg.roomId || '').slice(0, 64);
        if (!targetUid || !roomId || !msg.signal) return;
        for (const s of sessions.values()) {
          if (s.player.uid === targetUid) {
            sendJson(s.ws, {
              type: 'call:signal',
              roomId,
              fromUid: session.player.uid,
              fromName: session.player.avatarName,
              signal: msg.signal,
            });
          }
        }
        return;
      }

      if (type === 'chat:moderation') {
        const action = String(msg.action || '');
        const targetUid = String(msg.targetUid || '');
        if (!targetUid) return;
        if (action === 'mute') session.mutedIds.add(targetUid);
        if (action === 'unmute') session.mutedIds.delete(targetUid);
        if (action === 'block') session.blockedIds.add(targetUid);
        if (action === 'unblock') session.blockedIds.delete(targetUid);
        return;
      }

      if (type === 'chat:message') {
        const activeBan = getActiveBanForUid(session.player.uid);
        if (activeBan) {
          sendJson(ws, { type: 'player:banned', uid: session.player.uid, ban: activeBan });
          return;
        }
        const now = Date.now();
        if (now - session.lastChatAt < 500) return;
        session.lastChatAt = now;

        const text = sanitizeChatText(String(msg.text || ''));
        if (!text) return;

        const requestedChannel = String(msg.channel || 'global');
        const allowedChannels = new Set(['global', 'local', 'private', 'farm_visit', 'event']);
        if (!allowedChannels.has(requestedChannel)) return;
        const channel = requestedChannel as ChatMessage['channel'];
        const chatMsg: ChatMessage = {
          id: crypto.randomUUID().slice(0, 10),
          channel,
          senderId: session.player.uid,
          senderName: session.player.avatarName,
          targetId: msg.targetId ? String(msg.targetId) : undefined,
          zone: session.player.zone,
          text,
          timestamp: now,
        };

        if (channel === 'global' || channel === 'event') {
          recentGlobalChat.push(chatMsg);
          if (recentGlobalChat.length > 80) recentGlobalChat.shift();
        } else if (channel === 'private') {
          encryptedPrivateChatLog.push(encryptSensitive(chatMsg));
          if (encryptedPrivateChatLog.length > 250) encryptedPrivateChatLog.shift();
        }

        for (const recipient of sessions.values()) {
          if (recipient.blockedIds.has(session.player.uid) || recipient.mutedIds.has(session.player.uid)) {
            continue;
          }
          if (channel === 'private') {
            if (recipient.player.uid !== chatMsg.targetId && recipient.player.uid !== session.player.uid) continue;
          } else if (channel === 'local') {
            if (recipient.player.zone !== session.player.zone) continue;
            const dx = recipient.player.x - session.player.x;
            const dz = recipient.player.z - session.player.z;
            if (dx * dx + dz * dz > 26 * 26) continue;
          } else if (channel === 'farm_visit') {
            if ((recipient.player.farmOwnerId || recipient.player.uid) !== (session.player.farmOwnerId || session.player.uid)) continue;
          }
          sendJson(recipient.ws, { type: 'chat:message', message: chatMsg });
        }
      }
    });

    ws.on('close', () => {
      clearTimeout(authTimeout);
      if (!session) return;
      const existingSnap = getPlayerSnapshot(session.player.uid);
      if (existingSnap) {
        savePlayerSnapshot({
          ...existingSnap,
          lastOnlineAt: Date.now(),
          updatedAt: Date.now(),
        });
      }
      removeUidFromAllCallRooms(session.player.uid, 'disconnect');
      sessions.delete(session.player.clientId);
      broadcastToZone(
        session.player.zone,
        isFarmScopedZone(session.player.zone) ? session.player.farmOwnerId : undefined,
        { type: 'player:leave', clientId: session.player.clientId }
      );
    });
  });

  // Gentle market price mean-reversion every 30s
  setInterval(() => {
    let changed = false;
    for (const entry of Object.values(marketState.prices)) {
      if (Math.abs(entry.supply - 50) > 1 || Math.abs(entry.demand - 50) > 1) {
        entry.supply += (50 - entry.supply) * 0.08;
        entry.demand += (50 - entry.demand) * 0.08;
        recalcMarketEntry(entry.itemId);
        changed = true;
      }
    }
    if (changed && sessions.size > 0) {
      broadcastMarketUpdate();
    }
  }, 30_000);

  // Server-authoritative 25-NPC Global Synchronization Tick (every 2s)
  setInterval(() => {
    if (sessions.size === 0) return;
    const worldTime = getAuthoritativeWorldTime();
    const npcStates = NPCS.map((npc) => {
      const slot = getNpcRoutineSlot(
        npc,
        worldTime.hour,
        false,
        worldTime.isFestival,
        worldTime.festivalZone,
        null
      );
      return {
        id: npc.id,
        zone: slot.zone,
        x: slot.x,
        z: slot.z,
        activity: slot.activity,
        label: slot.label,
      };
    });
    for (const s of sessions.values()) {
      sendJson(s.ws, {
        type: 'npc:global_sync',
        serverHour: worldTime.hour,
        npcStates,
      });
    }
  }, 2000);

  // Asymmetric Global Forest Growth vs. Carpenter Orin Harvesting Scheduler
  // Creates natural organic tree-count waves between minTrees (200) and maxTrees (500).
  setInterval(() => {
    const now = Date.now();
    ecosystemWavePhase += 0.14;
    const waveBias = Math.sin(ecosystemWavePhase); // -1..+1 organic lush/sparse cycles
    let changed = false;

    const growthMs = Math.max(5000, liveTreeEcosystemConfig.growthIntervalSec * 1000);
    if (now - lastGlobalGrowthAt >= growthMs) {
      lastGlobalGrowthAt = now;
      const span = Math.max(1, liveTreeEcosystemConfig.growthBatchMax - liveTreeEcosystemConfig.growthBatchMin);
      const baseBatch = liveTreeEcosystemConfig.growthBatchMin + Math.floor(Math.random() * (span + 1));
      const dynamicBatch = waveBias > 0 ? Math.min(liveTreeEcosystemConfig.growthBatchMax + 3, Math.round(baseBatch * (1 + waveBias * 0.55))) : Math.max(1, Math.round(baseBatch * 0.7));
      const added = spawnRandomGlobalTrees(dynamicBatch);
      if (added > 0) {
        logTreeEcosystemEvent('sprout', added, `Natural valley growth sprouted +${added} protected global trees.`);
        changed = true;
      }
    }

    const cutMs = Math.max(5000, liveTreeEcosystemConfig.carpenterCutIntervalSec * 1000);
    if (now - lastCarpenterCutAt >= cutMs) {
      lastCarpenterCutAt = now;
      const span = Math.max(1, liveTreeEcosystemConfig.carpenterCutBatchMax - liveTreeEcosystemConfig.carpenterCutBatchMin);
      const baseCut = liveTreeEcosystemConfig.carpenterCutBatchMin + Math.floor(Math.random() * (span + 1));
      const dynamicCut = waveBias < 0 ? Math.min(liveTreeEcosystemConfig.carpenterCutBatchMax + 3, Math.round(baseCut * (1 + Math.abs(waveBias) * 0.55))) : Math.max(1, Math.round(baseCut * 0.65));
      const removed = carpenterOrinCutTrees(dynamicCut);
      if (removed > 0) {
        logTreeEcosystemEvent('carpenter_cut', -removed, `Carpenter Orin selectively harvested -${removed} global trees.`);
        changed = true;
      }
    }

    if (changed && sessions.size > 0) {
      broadcastGlobalTrees();
    }
  }, 4000);

  // Enforce configurable ephemeral Guest session timeout & purge expired 3-day character deletions
  setInterval(() => {
    enforceGuestSessionTimeouts();
    purgeExpiredCharacterDeletions();
  }, 15_000);

  server.listen(PORT, '0.0.0.0', () => {
    const protocol = httpsEnabled ? 'https' : 'http';
    console.log(`Harvest in the Great Valley server running on ${protocol}://0.0.0.0:${PORT}`);
    console.log(`WebSocket endpoint: ${httpsEnabled ? 'wss' : 'ws'}://0.0.0.0:${PORT}/ws`);
  });
}

startServer().catch((err) => {
  console.error('Server boot error:', err);
  process.exit(1);
});
