import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Archive,
  Ban,
  BookOpen,
  Calendar,
  CheckCircle2,
  ChevronRight,
  Clock,
  CloudSun,
  Coins,
  Crown,
  Database,
  FileCode2,
  Folder,
  FolderOpen,
  Gamepad2,
  Globe,
  History,
  KeyRound,
  Lock,
  LogOut,
  Megaphone,
  MessageSquare,
  Package,
  Palette,
  RefreshCw,
  RotateCcw,
  Save,
  Search,
  ShieldAlert,
  ShieldCheck,
  ShoppingBag,
  Sliders,
  Trash2,
  Trees,
  Unlock,
  UserMinus,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import {
  CAMERA_CONFIG,
  GUEST_SESSION_CONFIG,
  MOBILE_CONTROLS_CONFIG,
  SKY_ATMOSPHERE_CONFIG,
  WORLD_TIME_OVERRIDE,
} from '@/src/game/data/gameRuntimeConfig';
import { SEASON_DAYS } from '@/src/game/data/worldConfig';
import { localizationManager, SUPPORTED_LANGUAGES } from '@/src/game/localizationManager';
import { GLOBAL_THEMES, themeManager } from '@/src/game/themeManager';
import type {
  AnnouncementCategory,
  AuditLogEntry,
  BanType,
  BranchingDialogueNode,
  CustomShopProduct,
  ItemDef,
  Language,
  PlayerBanRecord,
  RuntimeGameConfig,
  Season,
  SocialProviderId,
  ThemeMode,
  Weather,
} from '@/src/game/types';
import {
  authenticateWithFirebaseSocial,
  checkDeveloperRole,
  claimDeveloperAccount,
  fetchDevAuthStatus,
  getActiveBearerToken,
  listenForSteamSocialAuth,
  restoreFirebaseSocialSession,
  signOutNakamaSocial,
  type DevAuthStatus,
} from '@/src/services/nakamaAuthService';

type DevTabId =
  | 'world'
  | 'dialogues'
  | 'characters'
  | 'items'
  | 'economy'
  | 'shop'
  | 'history'
  | 'moderation'
  | 'controls'
  | 'env'
  | 'files'
  | 'backups'
  | 'team'
  | 'audit';

interface DevPlayerEntry {
  uid: string;
  online: boolean;
  isGuest: boolean;
  avatarName: string;
  farmName: string;
  zone: string;
  level: number;
  xp: number;
  fun: number;
  gold: number;
  diamond: number;
  animalsCount: number;
  loginType: string;
  activeBan: PlayerBanRecord | null;
}

interface DevNpcSummary {
  id: string;
  name: string;
  role: string;
  homeZone: string;
  schedule: Array<{ startHour: number; endHour: number; zone: string; activity: string }>;
}

interface DevStateResponse {
  ok: boolean;
  onlineCount: number;
  worldClock: {
    year: number;
    season: Season;
    day: number;
    hour: number;
    minute: number;
    weather: Weather;
  };
  runtimeConfig: RuntimeGameConfig;
  globalTreeStats: { totalTrees: number; maxTrees: number };
  players: DevPlayerEntry[];
  itemsCatalog: Array<{
    id: string;
    name: string;
    category: string;
    iconEmoji: string;
    buyPrice: number;
    sellPrice: number;
    diamondPrice?: number;
    description: string;
  }>;
  npcs: DevNpcSummary[];
  bans: PlayerBanRecord[];
}

interface EnvVarEntry {
  key: string;
  group: string;
  isSecret: boolean;
  configured: boolean;
  value: string;
  preview: string;
}

interface BackupFileEntry {
  fileName: string;
  sizeBytes: number;
  createdAt: string;
  isDefault: boolean;
}

interface ExplorerEntry {
  name: string;
  path: string;
  isDirectory: boolean;
  sizeBytes: number;
  updatedAt: number;
}

interface TeamStateResponse {
  owner: {
    uid: string;
    accountId: string;
    provider: SocialProviderId;
    displayName: string;
    emailMasked: string;
    registeredAt: string;
    online: boolean;
  } | null;
  developers: Array<{
    uid: string;
    displayName: string;
    addedBy: string;
    addedAt: string;
    sessionRevokedAt?: number;
    online: boolean;
  }>;
  registeredPlayerIds: Array<{ uid: string; avatarName: string; online: boolean }>;
}

interface EconomyMonitorResponse {
  totalServerGold: number;
  totalServerDiamond: number;
  totalAccounts: number;
  onlineAccounts: number;
  marketVolumeGold: number;
  taxPoolGold: number;
  taxPoolDiamond: number;
  activeP2PListings: number;
  topSpenders: Array<{
    uid: string;
    playerName: string;
    goldSpent: number;
    diamondSpent: number;
    txCount: number;
  }>;
}

interface HistoryEntry {
  id: string;
  timestamp: number;
  uid: string;
  playerName: string;
  category: string;
  summary: string;
  amount?: number;
  currency?: string;
}

export interface DevPanelProps {
  onClose?: () => void;
}

const SEASONS: Season[] = ['Spring', 'Summer', 'Autumn', 'Winter'];
const WEATHERS: Weather[] = [
  'Sunny',
  'Cloudy',
  'LightRain',
  'HeavyRain',
  'Rainy',
  'Stormy',
  'Foggy',
  'Snowy',
];

export const DevPanel: React.FC<DevPanelProps> = ({ onClose }) => {
  const [language, setLanguage] = useState<Language>(() => localizationManager.getLanguage());
  const [themeMode, setThemeMode] = useState<ThemeMode>(() => themeManager.getTheme());
  const isId = language === 'id';

  const [authStatus, setAuthStatus] = useState<DevAuthStatus | null>(null);
  const [bearerToken, setBearerToken] = useState<string | null>(null);
  const [role, setRole] = useState<'owner' | 'developer' | 'player' | null>(null);
  const [actorLabel, setActorLabel] = useState<string>('');
  const [authBusy, setAuthBusy] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [steamWaiting, setSteamWaiting] = useState(false);

  const [activeTab, setActiveTab] = useState<DevTabId>('world');
  const [toast, setToast] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  const [loadingState, setLoadingState] = useState(false);

  // Core state
  const [devState, setDevState] = useState<DevStateResponse | null>(null);
  const [runtimeDraft, setRuntimeDraft] = useState<RuntimeGameConfig | null>(null);

  // Owner Auto-Backup Prompt
  const [backups, setBackups] = useState<BackupFileEntry[]>([]);
  const [hasDefaultBackup, setHasDefaultBackup] = useState<boolean>(true);
  const [backupPromptDismissed, setBackupPromptDismissed] = useState(false);
  const [backupLabelInput, setBackupLabelInput] = useState('');
  const [pendingRestoreFile, setPendingRestoreFile] = useState<string | null>(null);

  // Characters
  const [selectedUid, setSelectedUid] = useState<string>('');
  const [playerGoldInput, setPlayerGoldInput] = useState('5000');
  const [playerDiamondInput, setPlayerDiamondInput] = useState('50');
  const [playerLevelInput, setPlayerLevelInput] = useState('5');
  const [playerGrantItemId, setPlayerGrantItemId] = useState('seed_turnip');
  const [playerGrantQty, setPlayerGrantQty] = useState('10');

  // Dialogues
  const [dialogues, setDialogues] = useState<BranchingDialogueNode[]>([]);
  const [dlgNpcId, setDlgNpcId] = useState('elara');
  const [dlgTitle, setDlgTitle] = useState('');
  const [dlgTrigger, setDlgTrigger] = useState<BranchingDialogueNode['trigger']>('greeting');
  const [dlgEn, setDlgEn] = useState('');
  const [dlgIdText, setDlgIdText] = useState('');
  const [dlgChoiceEn, setDlgChoiceEn] = useState('Sure, happy to help!');
  const [dlgChoiceId, setDlgChoiceId] = useState('Tentu, dengan senang hati!');
  const [dlgReplyEn, setDlgReplyEn] = useState('Thank you so much, friend!');
  const [dlgReplyId, setDlgReplyId] = useState('Terima kasih banyak, sahabat!');
  const [dlgRewardGold, setDlgRewardGold] = useState('50');

  // Items
  const [customItems, setCustomItems] = useState<ItemDef[]>([]);
  const [itemSearch, setItemSearch] = useState('');
  const [newItemId, setNewItemId] = useState('');
  const [newItemName, setNewItemName] = useState('');
  const [newItemEmoji, setNewItemEmoji] = useState('✨');
  const [newItemCategory, setNewItemCategory] = useState<ItemDef['category']>('Materials');
  const [newItemBuy, setNewItemBuy] = useState('120');
  const [newItemSell, setNewItemSell] = useState('60');

  // Economy & Shop
  const [economy, setEconomy] = useState<EconomyMonitorResponse | null>(null);
  const [shopProducts, setShopProducts] = useState<CustomShopProduct[]>([]);
  const [shopName, setShopName] = useState('');
  const [shopItemId, setShopItemId] = useState('seed_strawberry');
  const [shopQty, setShopQty] = useState('5');
  const [shopGoldPrice, setShopGoldPrice] = useState('250');
  const [shopDiamondPrice, setShopDiamondPrice] = useState('0');
  const [shopDiscount, setShopDiscount] = useState('15');

  // History & Audit
  const [historyLogs, setHistoryLogs] = useState<HistoryEntry[]>([]);
  const [historyFilter, setHistoryFilter] = useState('all');
  const [historyQuery, setHistoryQuery] = useState('');
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [auditCategory, setAuditCategory] = useState('all');
  const [auditQuery, setAuditQuery] = useState('');

  // Moderation & Announcement
  const [banUid, setBanUid] = useState('');
  const [banType, setBanType] = useState<BanType>('temporary_ban');
  const [banMinutes, setBanMinutes] = useState('60');
  const [banReason, setBanReason] = useState('');
  const [banDevMsg, setBanDevMsg] = useState('');
  const [annCategory, setAnnCategory] = useState<AnnouncementCategory>('event');
  const [annTitle, setAnnTitle] = useState('');
  const [annMessage, setAnnMessage] = useState('');
  const [annDuration, setAnnDuration] = useState('15');

  // Env Vars
  const [envEntries, setEnvEntries] = useState<EnvVarEntry[]>([]);
  const [envEdits, setEnvEdits] = useState<Record<string, string>>({});

  // File Explorer
  const [explorerPath, setExplorerPath] = useState('');
  const [explorerEntries, setExplorerEntries] = useState<ExplorerEntry[]>([]);
  const [openedFilePath, setOpenedFilePath] = useState<string | null>(null);
  const [openedFileContent, setOpenedFileContent] = useState('');
  const [newFilePathInput, setNewFilePathInput] = useState('');
  const [pendingDeletePath, setPendingDeletePath] = useState<string | null>(null);

  // Team (Owner-Only)
  const [teamState, setTeamState] = useState<TeamStateResponse | null>(null);
  const [addDevUid, setAddDevUid] = useState('');
  const [addDevName, setAddDevName] = useState('');
  const [ownerResetConfirm, setOwnerResetConfirm] = useState('');
  const [showOwnerResetBox, setShowOwnerResetBox] = useState(false);

  // NPC Schedule editor
  const [schedNpcId, setSchedNpcId] = useState('elara');
  const [schedRainBehavior, setSchedRainBehavior] = useState<'shelter_indoors' | 'carry_umbrella' | 'stay_home'>('shelter_indoors');
  const [schedZone, setSchedZone] = useState('town_square');
  const [schedActivity, setSchedActivity] = useState('socializing');
  const [schedStartHour, setSchedStartHour] = useState('9');
  const [schedEndHour, setSchedEndHour] = useState('17');

  const isAuthenticated = role === 'owner' || role === 'developer';
  const isOwner = role === 'owner';

  const notify = useCallback((kind: 'ok' | 'err', text: string) => {
    setToast({ kind, text });
    window.setTimeout(() => {
      setToast((prev) => (prev?.text === text ? null : prev));
    }, 4500);
  }, []);

  useEffect(() => {
    const unsubTheme = themeManager.subscribe(({ theme }) => setThemeMode(theme));
    const unsubLocale = localizationManager.subscribe((lang) => setLanguage(lang));
    return () => {
      unsubTheme();
      unsubLocale();
    };
  }, []);

  const authFetch = useCallback(
    async (url: string, init?: RequestInit) => {
      const token = bearerToken || (await getActiveBearerToken(false));
      if (!token) throw new Error('Authentication required');
      const headers = new Headers(init?.headers || {});
      headers.set('Authorization', `Bearer ${token}`);
      if (init?.body && !headers.has('Content-Type')) {
        headers.set('Content-Type', 'application/json');
      }
      const res = await fetch(url, { ...init, headers });
      const data = await res.json().catch(() => ({ ok: false, error: `HTTP ${res.status}` }));
      if (!res.ok) {
        throw new Error(data.error || `Request failed (${res.status})`);
      }
      return data;
    },
    [bearerToken]
  );

  const refreshAuthStatus = useCallback(async () => {
    try {
      const st = await fetchDevAuthStatus();
      setAuthStatus(st);
      setHasDefaultBackup(Boolean(st.hasDefaultBackup));
    } catch {
      // ignore offline
    }
  }, []);

  const refreshAllData = useCallback(async () => {
    if (!isAuthenticated) return;
    setLoadingState(true);
    try {
      const [stateRes, envRes, dlgRes, itemRes, shopRes, ecoRes, histRes, auditRes, bakRes] =
        await Promise.all([
          authFetch('/api/dev/state'),
          authFetch('/api/dev/env-config'),
          authFetch('/api/dev/dialogues'),
          authFetch('/api/dev/items'),
          authFetch('/api/dev/shop'),
          authFetch('/api/dev/economy-monitor'),
          authFetch(`/api/dev/history?type=${encodeURIComponent(historyFilter)}&q=${encodeURIComponent(historyQuery)}`),
          authFetch(`/api/dev/audit-logs?category=${encodeURIComponent(auditCategory)}&q=${encodeURIComponent(auditQuery)}`),
          authFetch('/api/dev/backups'),
        ]);
      setDevState(stateRes);
      setRuntimeDraft(stateRes.runtimeConfig);
      if (!selectedUid && stateRes.players?.length > 0) {
        setSelectedUid(stateRes.players[0].uid);
      }
      setEnvEntries(envRes.entries || []);
      setDialogues(dlgRes.dialogues || []);
      setCustomItems(itemRes.customItems || []);
      setShopProducts(shopRes.products || []);
      setEconomy(ecoRes);
      setHistoryLogs(histRes.logs || []);
      setAuditLogs(auditRes.logs || []);
      setBackups(bakRes.backups || []);
      setHasDefaultBackup(Boolean(bakRes.hasDefaultBackup));

      if (isOwner) {
        const teamRes = await authFetch('/api/dev/team');
        setTeamState(teamRes);
      }
    } catch (err) {
      notify('err', err instanceof Error ? err.message : 'Failed to load Dev Panel data');
    } finally {
      setLoadingState(false);
    }
  }, [authCategorySafe(auditCategory), auditQuery, authFetch, historyFilter, historyQuery, isAuthenticated, isOwner, notify, selectedUid]);

  function authCategorySafe(c: string) {
    return c || 'all';
  }

  const loadExplorerDir = useCallback(
    async (relPath: string) => {
      if (!isAuthenticated) return;
      try {
        const res = await authFetch(`/api/dev/files/list?path=${encodeURIComponent(relPath)}`);
        setExplorerPath(res.currentPath || '');
        setExplorerEntries(res.entries || []);
      } catch (err) {
        notify('err', err instanceof Error ? err.message : 'Cannot open folder');
      }
    },
    [authFetch, isAuthenticated, notify]
  );

  // Initial check + auto-restore Firebase session
  useEffect(() => {
    void refreshAuthStatus();
    let cancelled = false;
    void (async () => {
      try {
        const restored = await restoreFirebaseSocialSession();
        if (!restored || cancelled) return;
        const check = await checkDeveloperRole(restored.token);
        if (check.isDeveloper && !cancelled) {
          setBearerToken(restored.token);
          setRole(check.role);
          setActorLabel(`${restored.account.displayName} (${restored.account.provider})`);
        }
      } catch {
        // user not signed in yet
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [refreshAuthStatus]);

  useEffect(() => {
    if (isAuthenticated) {
      void refreshAllData();
      void loadExplorerDir('');
    }
  }, [isAuthenticated, refreshAllData, loadExplorerDir]);

  const completeSocialGate = useCallback(
    async (token: string, displayName: string, provider: SocialProviderId) => {
      const status = await fetchDevAuthStatus();
      setAuthStatus(status);
      if (!status.configured) {
        const claimed = await claimDeveloperAccount(token);
        setBearerToken(token);
        setRole(claimed.role || 'owner');
        setActorLabel(`${displayName} (${provider})`);
        await refreshAuthStatus();
        notify('ok', isId ? 'Akun ini resmi terdaftar sebagai Owner tunggal!' : 'Account registered as the Single Owner!');
        return;
      }
      const check = await checkDeveloperRole(token);
      if (!check.isDeveloper) {
        setAuthError(
          isId
            ? `Akses ditolak. Akun Owner sudah terdaftar (${status.displayName || 'Owner'}). Minta Owner menambahkan ID Game Anda sebagai Developer.`
            : `Access denied. Owner is already registered (${status.displayName || 'Owner'}). Ask the Owner to add your Game ID as a Developer.`
        );
        return;
      }
      setBearerToken(token);
      setRole(check.role);
      setActorLabel(`${displayName} (${provider})`);
      setHasDefaultBackup(Boolean(status.hasDefaultBackup));
      notify('ok', isId ? `Berhasil masuk sebagai ${check.role.toUpperCase()}` : `Signed in as ${check.role.toUpperCase()}`);
    },
    [isId, notify, refreshAuthStatus]
  );

  const handleSocialLogin = async (provider: 'google' | 'apple') => {
    setAuthBusy(true);
    setAuthError(null);
    try {
      const res = await authenticateWithFirebaseSocial(provider);
      await completeSocialGate(res.token, res.account.displayName, res.account.provider);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Social login failed');
    } finally {
      setAuthBusy(false);
    }
  };

  const handleStartSteamListen = () => {
    setAuthError(null);
    setSteamWaiting(true);
    listenForSteamSocialAuth(
      async (res) => {
        setSteamWaiting(false);
        try {
          await completeSocialGate(res.token, res.account.displayName, res.account.provider);
        } catch (err) {
          setAuthError(err instanceof Error ? err.message : 'Steam auth failed');
        }
      },
      (msg) => {
        setSteamWaiting(false);
        setAuthError(msg);
      }
    );
  };

  const handleSignOut = async () => {
    await signOutNakamaSocial();
    setBearerToken(null);
    setRole(null);
    setActorLabel('');
    setDevState(null);
    setTeamState(null);
    await refreshAuthStatus();
  };

  // === SAVE HANDLERS ===
  const pushRuntimePatch = async (patch: Partial<RuntimeGameConfig>, okMsg: string) => {
    try {
      const res = await authFetch('/api/dev/runtime-config', {
        method: 'POST',
        body: JSON.stringify(patch),
      });
      if (res.config) setRuntimeDraft(res.config);
      notify('ok', okMsg);
      await refreshAllData();
    } catch (err) {
      notify('err', err instanceof Error ? err.message : 'Failed to update config');
    }
  };

  const handleCreateBackup = async (kind: 'default' | 'manual') => {
    try {
      const res = await authFetch('/api/dev/backups/create', {
        method: 'POST',
        body: JSON.stringify({ kind, label: kind === 'manual' ? backupLabelInput : undefined }),
      });
      setBackups(res.backups || []);
      if (kind === 'default') setHasDefaultBackup(true);
      setBackupLabelInput('');
      notify('ok', isId ? `Backup tersimpan: ${res.fileName}` : `Backup saved: ${res.fileName}`);
    } catch (err) {
      notify('err', err instanceof Error ? err.message : 'Backup failed');
    }
  };

  const handleRestoreBackup = async (fileName: string) => {
    try {
      await authFetch('/api/dev/backups/restore', {
        method: 'POST',
        body: JSON.stringify({ fileName }),
      });
      setPendingRestoreFile(null);
      notify('ok', isId ? `Backup dipulihkan: ${fileName}` : `Restored backup: ${fileName}`);
      await refreshAllData();
    } catch (err) {
      notify('err', err instanceof Error ? err.message : 'Restore failed');
    }
  };

  const handleOpenFile = async (relPath: string) => {
    try {
      const res = await authFetch(`/api/dev/files/read?path=${encodeURIComponent(relPath)}`);
      setOpenedFilePath(res.path);
      setOpenedFileContent(res.content || '');
    } catch (err) {
      notify('err', err instanceof Error ? err.message : 'Cannot read file');
    }
  };

  const handleSaveFile = async () => {
    if (!openedFilePath) return;
    try {
      await authFetch('/api/dev/files/write', {
        method: 'POST',
        body: JSON.stringify({ path: openedFilePath, content: openedFileContent }),
      });
      notify('ok', isId ? `File disimpan: ${openedFilePath}` : `Saved file: ${openedFilePath}`);
      await loadExplorerDir(explorerPath);
    } catch (err) {
      notify('err', err instanceof Error ? err.message : 'Save failed');
    }
  };

  const handleCreateNewFile = async () => {
    const clean = newFilePathInput.trim();
    if (!clean) return;
    const fullRel = explorerPath ? `${explorerPath}/${clean}` : clean;
    try {
      await authFetch('/api/dev/files/write', {
        method: 'POST',
        body: JSON.stringify({ path: fullRel, content: '' }),
      });
      setNewFilePathInput('');
      setOpenedFilePath(fullRel);
      setOpenedFileContent('');
      notify('ok', isId ? `File dibuat: ${fullRel}` : `Created file: ${fullRel}`);
      await loadExplorerDir(explorerPath);
    } catch (err) {
      notify('err', err instanceof Error ? err.message : 'Create file failed');
    }
  };

  const handleConfirmDeleteFile = async () => {
    if (!pendingDeletePath) return;
    try {
      await authFetch(`/api/dev/files/delete?path=${encodeURIComponent(pendingDeletePath)}`, {
        method: 'DELETE',
      });
      if (openedFilePath === pendingDeletePath) {
        setOpenedFilePath(null);
        setOpenedFileContent('');
      }
      notify('ok', isId ? `Dihapus: ${pendingDeletePath}` : `Deleted: ${pendingDeletePath}`);
      setPendingDeletePath(null);
      await loadExplorerDir(explorerPath);
    } catch (err) {
      notify('err', err instanceof Error ? err.message : 'Delete failed');
    }
  };

  const navItems = useMemo(
    () => [
      { id: 'world' as DevTabId, icon: CloudSun, label: isId ? 'Dunia, Kalender & NPC' : 'World, Sky & NPCs' },
      { id: 'dialogues' as DevTabId, icon: MessageSquare, label: isId ? 'Dialog Bercabang' : 'Branching Dialogs' },
      { id: 'characters' as DevTabId, icon: Users, label: isId ? 'Pemain & Karakter' : 'Characters & Live Edit' },
      { id: 'items' as DevTabId, icon: Package, label: isId ? 'Manajemen Item' : 'Item Manager' },
      { id: 'economy' as DevTabId, icon: Coins, label: isId ? 'Monitor Ekonomi' : 'Economy Monitor' },
      { id: 'shop' as DevTabId, icon: ShoppingBag, label: isId ? 'Toko & Bundle' : 'Shop & Bundles' },
      { id: 'history' as DevTabId, icon: History, label: isId ? 'Riwayat Transaksi' : 'History Tracking' },
      { id: 'moderation' as DevTabId, icon: Megaphone, label: isId ? 'Ban & Pengumuman' : 'Moderation & Notice' },
      { id: 'controls' as DevTabId, icon: Gamepad2, label: isId ? 'Kamera POV & Mobile' : 'Camera & Mobile Pad' },
      { id: 'env' as DevTabId, icon: Sliders, label: isId ? 'Env & Timer Guest' : 'Live Env & Guest' },
      { id: 'files' as DevTabId, icon: FileCode2, label: isId ? 'File Explorer' : 'File Explorer' },
      { id: 'backups' as DevTabId, icon: Archive, label: isId ? 'Backup Manager' : 'Backup Manager' },
      { id: 'team' as DevTabId, icon: Crown, label: isId ? 'Owner & Tim Dev' : 'Owner & Dev Team', ownerOnly: true },
      { id: 'audit' as DevTabId, icon: Activity, label: isId ? 'Audit Log' : 'Audit Log' },
    ],
    [isId]
  );

  const cameraCfg = runtimeDraft?.cameraConfig || CAMERA_CONFIG;
  const mobileCfg = runtimeDraft?.mobileControlsConfig || MOBILE_CONTROLS_CONFIG;
  const skyCfg = runtimeDraft?.skyAtmosphereConfig || SKY_ATMOSPHERE_CONFIG;
  const worldTimeCfg = runtimeDraft?.worldTimeOverride || WORLD_TIME_OVERRIDE;
  const guestCfg = runtimeDraft?.guestSessionConfig || GUEST_SESSION_CONFIG;

  return (
    <div
      className="min-h-screen w-full flex flex-col font-sans"
      style={{
        backgroundColor: 'var(--hv-bg)',
        color: 'var(--hv-text)',
      }}
    >
      {/* Top Workspace Header */}
      <header
        className="sticky top-0 z-30 border-b px-4 py-3 flex flex-wrap items-center justify-between gap-3"
        style={{
          backgroundColor: 'var(--hv-surface)',
          borderColor: 'var(--hv-border)',
        }}
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-600/15 border border-amber-500/40 flex items-center justify-center text-amber-500">
            <Crown className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-extrabold tracking-tight">
                Harvest in the Great Valley — Dev Panel
              </h1>
              {role && (
                <span
                  className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase tracking-wider ${
                    isOwner ? 'bg-amber-500/20 text-amber-500 border border-amber-500/40' : 'bg-sky-500/20 text-sky-400 border border-sky-500/40'
                  }`}
                >
                  {isOwner ? 'SINGLE OWNER' : 'DEVELOPER'}
                </span>
              )}
            </div>
            <p className="text-xs opacity-70">
              {isAuthenticated
                ? `${actorLabel} · ${devState?.onlineCount ?? 0} ${isId ? 'pemain online' : 'players online'}`
                : isId
                  ? 'Semua menu terkunci hingga akun Owner / Developer terverifikasi.'
                  : 'All controls locked until Owner or Developer social account is verified.'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Global Theme Switcher */}
          <div className="flex items-center gap-1 rounded-lg border px-2 py-1 text-xs" style={{ borderColor: 'var(--hv-border)', backgroundColor: 'var(--hv-surface-2)' }}>
            <Palette className="w-3.5 h-3.5 opacity-70" />
            <select
              value={themeMode}
              onChange={(e) => themeManager.setTheme(e.target.value as ThemeMode)}
              className="bg-transparent outline-none font-semibold cursor-pointer"
              aria-label="Theme"
            >
              {GLOBAL_THEMES.map((th) => (
                <option key={th.id} value={th.id} className="text-slate-900">
                  {th.label[language] || th.label.en}
                </option>
              ))}
            </select>
          </div>

          {/* Global Language Switcher */}
          <div className="flex items-center gap-1 rounded-lg border px-2 py-1 text-xs" style={{ borderColor: 'var(--hv-border)', backgroundColor: 'var(--hv-surface-2)' }}>
            <Globe className="w-3.5 h-3.5 opacity-70" />
            <select
              value={language}
              onChange={(e) => localizationManager.setLanguage(e.target.value as Language)}
              className="bg-transparent outline-none font-semibold cursor-pointer"
              aria-label="Language"
            >
              {SUPPORTED_LANGUAGES.map((opt) => (
                <option key={opt.code} value={opt.code} className="text-slate-900">
                  {opt.flag} {opt.nativeName}
                </option>
              ))}
            </select>
          </div>

          {isAuthenticated && (
            <button
              type="button"
              onClick={() => void refreshAllData()}
              disabled={loadingState}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-bold hover:opacity-90 cursor-pointer"
              style={{ borderColor: 'var(--hv-border)', backgroundColor: 'var(--hv-surface-2)' }}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingState ? 'animate-spin' : ''}`} />
              {isId ? 'Segarkan' : 'Refresh'}
            </button>
          )}

          <a
            href="/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold"
          >
            <BookOpen className="w-3.5 h-3.5" />
            {isId ? 'Buka Game' : 'Open Game'}
          </a>

          {isAuthenticated && (
            <button
              type="button"
              onClick={() => void handleSignOut()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              {isId ? 'Keluar' : 'Sign Out'}
            </button>
          )}

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg border hover:opacity-80 cursor-pointer"
              style={{ borderColor: 'var(--hv-border)' }}
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </header>

      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-4 right-4 z-50 max-w-md">
          <div
            className={`px-4 py-3 rounded-xl shadow-xl border text-xs font-bold flex items-center gap-2 ${
              toast.kind === 'ok'
                ? 'bg-emerald-600 text-white border-emerald-400'
                : 'bg-rose-600 text-white border-rose-400'
            }`}
          >
            {toast.kind === 'ok' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertTriangle className="w-4 h-4 shrink-0" />}
            <span>{toast.text}</span>
          </div>
        </div>
      )}

      {/* Owner Auto-Backup Prompt Banner */}
      {isAuthenticated && isOwner && !hasDefaultBackup && !backupPromptDismissed && (
        <div className="mx-4 mt-4 rounded-xl border-2 border-amber-500 bg-amber-500/10 p-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <Archive className="w-6 h-6 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <h2 className="text-sm font-extrabold">
                {isId
                  ? 'Permintaan Backup Default Owner Terdeteksi'
                  : 'Owner Default Backup Recommended'}
              </h2>
              <p className="text-xs opacity-80 mt-0.5">
                {isId
                  ? 'Akun Owner telah terdeteksi. Buat backup default konfigurasi & database game sekarang ke folder data/data_dev_panel/backup/.'
                  : 'Owner account detected. Create your initial default snapshot into data/data_dev_panel/backup/ now.'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => void handleCreateBackup('default')}
              className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-extrabold cursor-pointer"
            >
              {isId ? 'Buat Backup Default Sekarang' : 'Create Default Backup Now'}
            </button>
            <button
              type="button"
              onClick={() => setBackupPromptDismissed(true)}
              className="px-3 py-2 rounded-lg border text-xs font-bold opacity-80 hover:opacity-100 cursor-pointer"
              style={{ borderColor: 'var(--hv-border)' }}
            >
              {isId ? 'Nanti' : 'Later'}
            </button>
          </div>
        </div>
      )}

      {/* Body Layout: Sidebar + Main Workspace */}
      <div className="flex-1 flex flex-col lg:flex-row min-h-0">
        {/* Sidebar Navigation (Disabled/Locked before login) */}
        <aside
          className="w-full lg:w-64 shrink-0 border-b lg:border-b-0 lg:border-r p-3 space-y-1 overflow-x-auto lg:overflow-y-auto flex lg:flex-col gap-1"
          style={{
            backgroundColor: 'var(--hv-surface)',
            borderColor: 'var(--hv-border)',
          }}
        >
          {navItems.map((item) => {
            const Icon = item.icon;
            const disabled = !isAuthenticated || (item.ownerOnly && !isOwner);
            const active = isAuthenticated && activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                disabled={disabled}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center justify-between gap-2 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-colors ${
                  active
                    ? 'bg-amber-600 text-white shadow-sm'
                    : disabled
                      ? 'opacity-40 cursor-not-allowed'
                      : 'hover:bg-black/10 cursor-pointer'
                }`}
              >
                <span className="flex items-center gap-2">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </span>
                {disabled && <Lock className="w-3.5 h-3.5 shrink-0 opacity-70" />}
              </button>
            );
          })}
        </aside>

        {/* Main Panel Content */}
        <main className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-6">
          {!isAuthenticated ? (
            /* === FIRST-RUN OWNER REGISTRATION / DEVELOPER LOGIN GATE === */
            <div className="max-w-xl mx-auto mt-6 rounded-2xl border p-6 shadow-xl space-y-5" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
              <div className="flex items-start gap-3">
                <div className="p-3 rounded-xl bg-amber-500/15 text-amber-500">
                  {authStatus?.configured ? <ShieldCheck className="w-7 h-7" /> : <KeyRound className="w-7 h-7" />}
                </div>
                <div>
                  <h2 className="text-lg font-extrabold">
                    {authStatus?.configured
                      ? isId
                        ? 'Verifikasi Login Owner / Developer'
                        : 'Owner / Developer Social Verification'
                      : isId
                        ? 'Registrasi Pertama — Klaim Akun Owner Tunggal'
                        : 'First-Time Setup — Claim Single Owner Account'}
                  </h2>
                  <p className="text-xs opacity-75 mt-1 leading-relaxed">
                    {authStatus?.configured
                      ? isId
                        ? `Akun Owner tunggal sudah terdaftar (${authStatus.displayName} · ${authStatus.emailMasked}). Masuk dengan akun Owner atau akun Developer yang telah ditambahkan Owner.`
                        : `Single Owner is already configured (${authStatus.displayName} · ${authStatus.emailMasked}). Sign in with the Owner account or an Owner-approved Developer account.`
                      : isId
                        ? 'Belum ada Owner yang terdaftar. Semua menu Dev Panel dinonaktifkan hingga Anda login dengan akun sosial pertama kali untuk menandai akun tersebut sebagai Owner resmi (hanya ada 1 Owner).'
                        : 'No Owner registered yet. All Dev Panel menus remain disabled until you sign in with a social account to claim the 1 Single Owner role.'}
                  </p>
                </div>
              </div>

              {authError && (
                <div className="rounded-xl border border-rose-500/50 bg-rose-500/10 px-4 py-3 text-xs font-bold text-rose-500">
                  {authError}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  type="button"
                  disabled={authBusy}
                  onClick={() => void handleSocialLogin('google')}
                  className="py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold cursor-pointer disabled:opacity-50"
                >
                  {authBusy ? '...' : 'Google (Nakama)'}
                </button>
                <button
                  type="button"
                  disabled={authBusy}
                  onClick={() => void handleSocialLogin('apple')}
                  className="py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-extrabold cursor-pointer disabled:opacity-50"
                >
                  {authBusy ? '...' : 'Apple Sign-In'}
                </button>
                <a
                  href="/api/nakama/auth/steam/start"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={handleStartSteamListen}
                  className="py-3 px-4 rounded-xl bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-extrabold text-center"
                >
                  {steamWaiting ? (isId ? 'Menunggu Steam...' : 'Waiting Steam...') : 'Steam OpenID'}
                </a>
              </div>

              <div className="rounded-xl border p-3 text-[11px] opacity-80 space-y-1" style={{ borderColor: 'var(--hv-border)', backgroundColor: 'var(--hv-surface-2)' }}>
                <div className="font-bold flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-amber-500" />
                  {isId ? 'Keamanan Role & Secrets Terisolasi' : 'Role Isolation & Secret Segregation'}
                </div>
                <p>
                  {isId
                    ? 'Kredensial Owner & daftar Developer disimpan terisolasi di folder data/data_dev_panel/dev_panel_secrets/. Saat akun Owner atau Developer login ke game dari perangkat manapun, tombol & halaman Dev Panel akan otomatis terbuka.'
                    : 'Owner & Developer credentials are stored strictly inside data/data_dev_panel/dev_panel_secrets/. When Owner or Developer signs into the game from anywhere, Dev Panel access unlocks automatically.'}
                </p>
              </div>
            </div>
          ) : (
            <>
              {/* ============================================================ */}
              {/* TAB 1: WORLD, CALENDAR (31/31/30/28), SKY & NPC SCHEDULES    */}
              {/* ============================================================ */}
              {activeTab === 'world' && runtimeDraft && (
                <div className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                    {(['Spring', 'Summer', 'Autumn', 'Winter'] as Season[]).map((s) => (
                      <div key={s} className="rounded-xl border p-3.5" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                        <div className="text-xs font-bold opacity-70">{s}</div>
                        <div className="text-xl font-extrabold mt-0.5">{SEASON_DAYS[s]} {isId ? 'Hari' : 'Days'}</div>
                        <div className="text-[11px] opacity-65 mt-0.5">
                          {devState?.worldClock.season === s
                            ? `${isId ? 'Musim Aktif · Hari' : 'Active Season · Day'} ${devState.worldClock.day}/${SEASON_DAYS[s]}`
                            : isId
                              ? 'Kalender Resmi 120 Hari/Tahun'
                              : 'Official 120-Day Calendar'}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Weather & Time Override */}
                  <section className="rounded-2xl border p-5 space-y-4" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h2 className="text-sm font-extrabold flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-amber-500" />
                      {isId ? 'Kontrol Waktu, Musim & Cuaca Realtime' : 'Realtime World Clock, Season & Weather'}
                    </h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                      <label className="space-y-1">
                        <span className="font-bold opacity-75">{isId ? 'Cuaca Paksa' : 'Forced Weather'}</span>
                        <select
                          value={worldTimeCfg.weatherOverride || ''}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              worldTimeOverride: {
                                ...worldTimeCfg,
                                weatherOverride: (e.target.value || null) as Weather | null,
                              },
                            })
                          }
                          className="w-full rounded-lg border px-2.5 py-2 bg-transparent font-semibold"
                          style={{ borderColor: 'var(--hv-border)' }}
                        >
                          <option value="" className="text-slate-900">Auto</option>
                          {WEATHERS.map((w) => (
                            <option key={w} value={w} className="text-slate-900">{w}</option>
                          ))}
                        </select>
                      </label>

                      <label className="space-y-1">
                        <span className="font-bold opacity-75">{isId ? 'Musim Paksa' : 'Forced Season'}</span>
                        <select
                          value={worldTimeCfg.season}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              worldTimeOverride: {
                                ...worldTimeCfg,
                                enabled: true,
                                season: e.target.value as Season,
                              },
                            })
                          }
                          className="w-full rounded-lg border px-2.5 py-2 bg-transparent font-semibold"
                          style={{ borderColor: 'var(--hv-border)' }}
                        >
                          {SEASONS.map((s) => (
                            <option key={s} value={s} className="text-slate-900">{s} ({SEASON_DAYS[s]}d)</option>
                          ))}
                        </select>
                      </label>

                      <label className="space-y-1">
                        <span className="font-bold opacity-75">{isId ? 'Jam Paksa (0-23)' : 'Forced Hour (0-23)'}</span>
                        <input
                          type="number"
                          min={0}
                          max={23}
                          value={worldTimeCfg.hour}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              worldTimeOverride: {
                                ...worldTimeCfg,
                                enabled: true,
                                hour: Math.max(0, Math.min(23, Number(e.target.value) || 0)),
                              },
                            })
                          }
                          className="w-full rounded-lg border px-2.5 py-2 bg-transparent font-semibold"
                          style={{ borderColor: 'var(--hv-border)' }}
                        />
                      </label>

                      <label className="space-y-1 flex flex-col justify-end">
                        <span className="font-bold opacity-75">{isId ? 'Aktifkan Override Jam/Musim' : 'Enable Clock Override'}</span>
                        <label className="inline-flex items-center gap-2 py-2 cursor-pointer font-bold">
                          <input
                            type="checkbox"
                            checked={Boolean(worldTimeCfg.enabled)}
                            onChange={(e) =>
                              setRuntimeDraft({
                                ...runtimeDraft,
                                worldTimeOverride: {
                                  ...worldTimeCfg,
                                  enabled: e.target.checked,
                                },
                              })
                            }
                          />
                          <span>{worldTimeCfg.enabled ? (isId ? 'Aktif' : 'Enabled') : 'Auto Sync'}</span>
                        </label>
                      </label>
                    </div>

                    {/* Sky Atmosphere Controls */}
                    <div className="pt-3 border-t grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs" style={{ borderColor: 'var(--hv-border)' }}>
                      <label className="space-y-1">
                        <span className="font-bold">Cloud Density: {skyCfg.cloudDensity.toFixed(2)}</span>
                        <input
                          type="range"
                          min={0}
                          max={1}
                          step={0.05}
                          value={skyCfg.cloudDensity}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              skyAtmosphereConfig: { ...skyCfg, cloudDensity: Number(e.target.value) },
                            })
                          }
                          className="w-full"
                        />
                      </label>
                      <label className="space-y-1">
                        <span className="font-bold">Cloud Speed: {skyCfg.cloudSpeed.toFixed(2)}x</span>
                        <input
                          type="range"
                          min={0.2}
                          max={3}
                          step={0.1}
                          value={skyCfg.cloudSpeed}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              skyAtmosphereConfig: { ...skyCfg, cloudSpeed: Number(e.target.value) },
                            })
                          }
                          className="w-full"
                        />
                      </label>
                      <label className="space-y-1">
                        <span className="font-bold">Star Twinkle: {skyCfg.starTwinkleIntensity.toFixed(2)}</span>
                        <input
                          type="range"
                          min={0}
                          max={1}
                          step={0.05}
                          value={skyCfg.starTwinkleIntensity}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              skyAtmosphereConfig: { ...skyCfg, starTwinkleIntensity: Number(e.target.value) },
                            })
                          }
                          className="w-full"
                        />
                      </label>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          void pushRuntimePatch(
                            {
                              worldTimeOverride: worldTimeCfg,
                              skyAtmosphereConfig: skyCfg,
                            },
                            isId ? 'Konfigurasi dunia & langit diterapkan realtime!' : 'World & sky config applied live!'
                          )
                        }
                        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-extrabold cursor-pointer"
                      >
                        <Save className="w-4 h-4" />
                        {isId ? 'Terapkan Realtime' : 'Apply Realtime'}
                      </button>

                      <button
                        type="button"
                        onClick={async () => {
                          await authFetch('/api/dev/tree-ecosystem', {
                            method: 'POST',
                            body: JSON.stringify({ action: 'sprout', amount: 15 }),
                          });
                          notify('ok', isId ? '+15 pohon global ditanam!' : '+15 global trees sprouted!');
                          await refreshAllData();
                        }}
                        className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer"
                      >
                        <Trees className="w-4 h-4" />
                        +15 Trees ({devState?.globalTreeStats.totalTrees ?? 0})
                      </button>
                    </div>
                  </section>

                  {/* NPC Schedule Live Override */}
                  <section className="rounded-2xl border p-5 space-y-4" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h2 className="text-sm font-extrabold flex items-center gap-2">
                      <Clock className="w-4 h-4 text-emerald-500" />
                      {isId ? 'Jadwal & Reaksi Cuaca NPC (Realtime)' : 'NPC Autonomous Schedule & Weather Reaction'}
                    </h2>
                    <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
                      <select
                        value={schedNpcId}
                        onChange={(e) => setSchedNpcId(e.target.value)}
                        className="rounded-lg border px-2.5 py-2 bg-transparent font-semibold"
                        style={{ borderColor: 'var(--hv-border)' }}
                      >
                        {(devState?.npcs || []).map((n) => (
                          <option key={n.id} value={n.id} className="text-slate-900">
                            {n.name} ({n.role})
                          </option>
                        ))}
                      </select>
                      <select
                        value={schedRainBehavior}
                        onChange={(e) => setSchedRainBehavior(e.target.value as 'shelter_indoors' | 'carry_umbrella' | 'stay_home')}
                        className="rounded-lg border px-2.5 py-2 bg-transparent font-semibold"
                        style={{ borderColor: 'var(--hv-border)' }}
                      >
                        <option value="shelter_indoors" className="text-slate-900">Shelter Indoors</option>
                        <option value="carry_umbrella" className="text-slate-900">Carry Umbrella</option>
                        <option value="stay_home" className="text-slate-900">Stay Home</option>
                      </select>
                      <input
                        value={schedZone}
                        onChange={(e) => setSchedZone(e.target.value)}
                        placeholder="Zone (town_square)"
                        className="rounded-lg border px-2.5 py-2 bg-transparent"
                        style={{ borderColor: 'var(--hv-border)' }}
                      />
                      <input
                        value={schedActivity}
                        onChange={(e) => setSchedActivity(e.target.value)}
                        placeholder="Activity"
                        className="rounded-lg border px-2.5 py-2 bg-transparent"
                        style={{ borderColor: 'var(--hv-border)' }}
                      />
                      <input
                        type="number"
                        value={schedStartHour}
                        onChange={(e) => setSchedStartHour(e.target.value)}
                        placeholder="Start Hr"
                        className="rounded-lg border px-2.5 py-2 bg-transparent"
                        style={{ borderColor: 'var(--hv-border)' }}
                      />
                      <input
                        type="number"
                        value={schedEndHour}
                        onChange={(e) => setSchedEndHour(e.target.value)}
                        placeholder="End Hr"
                        className="rounded-lg border px-2.5 py-2 bg-transparent"
                        style={{ borderColor: 'var(--hv-border)' }}
                      />
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          await authFetch('/api/dev/npc-schedules', {
                            method: 'POST',
                            body: JSON.stringify({
                              npcId: schedNpcId,
                              rainBehavior: schedRainBehavior,
                              schedule: [
                                {
                                  startHour: Number(schedStartHour) || 9,
                                  endHour: Number(schedEndHour) || 17,
                                  zone: schedZone || 'town_square',
                                  activity: schedActivity || 'socializing',
                                  x: 0,
                                  z: 0,
                                },
                              ],
                            }),
                          });
                          notify('ok', isId ? `Jadwal NPC ${schedNpcId} diperbarui!` : `Schedule updated for ${schedNpcId}`);
                          await refreshAllData();
                        } catch (err) {
                          notify('err', err instanceof Error ? err.message : 'Schedule save failed');
                        }
                      }}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold cursor-pointer"
                    >
                      {isId ? 'Simpan Jadwal NPC' : 'Save NPC Schedule'}
                    </button>
                  </section>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 2: BRANCHING DIALOG MANAGEMENT                           */}
              {/* ============================================================ */}
              {activeTab === 'dialogues' && (
                <div className="space-y-5">
                  <section className="rounded-2xl border p-5 space-y-3" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h2 className="text-sm font-extrabold">{isId ? 'Buat / Edit Dialog Bercabang Multi-Bahasa' : 'Create Multi-Language Branching Dialogue'}</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <select value={dlgNpcId} onChange={(e) => setDlgNpcId(e.target.value)} className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }}>
                        {(devState?.npcs || []).map((n) => (
                          <option key={n.id} value={n.id} className="text-slate-900">{n.name}</option>
                        ))}
                      </select>
                      <input value={dlgTitle} onChange={(e) => setDlgTitle(e.target.value)} placeholder={isId ? 'Judul Dialog' : 'Dialogue Title'} className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <select value={dlgTrigger} onChange={(e) => setDlgTrigger(e.target.value as BranchingDialogueNode['trigger'])} className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }}>
                        {['greeting', 'morning', 'afternoon', 'evening', 'rainy', 'festival', 'quest', 'custom'].map((tr) => (
                          <option key={tr} value={tr} className="text-slate-900">{tr}</option>
                        ))}
                      </select>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <textarea rows={2} value={dlgIdText} onChange={(e) => setDlgIdText(e.target.value)} placeholder="Teks NPC (Bahasa Indonesia)" className="rounded-lg border p-2.5 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <textarea rows={2} value={dlgEn} onChange={(e) => setDlgEn(e.target.value)} placeholder="NPC Line (English)" className="rounded-lg border p-2.5 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 text-xs">
                      <input value={dlgChoiceId} onChange={(e) => setDlgChoiceId(e.target.value)} placeholder="Pilihan (ID)" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <input value={dlgChoiceEn} onChange={(e) => setDlgChoiceEn(e.target.value)} placeholder="Choice (EN)" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <input value={dlgReplyId} onChange={(e) => setDlgReplyId(e.target.value)} placeholder="Balasan NPC (ID)" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <input value={dlgReplyEn} onChange={(e) => setDlgReplyEn(e.target.value)} placeholder="NPC Reply (EN)" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <input type="number" value={dlgRewardGold} onChange={(e) => setDlgRewardGold(e.target.value)} placeholder="Gold Reward" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          await authFetch('/api/dev/dialogues', {
                            method: 'POST',
                            body: JSON.stringify({
                              npcId: dlgNpcId,
                              title: dlgTitle || 'Valley Chat',
                              trigger: dlgTrigger,
                              textByLang: { id: dlgIdText, en: dlgEn },
                              choices: [
                                {
                                  labelByLang: { id: dlgChoiceId, en: dlgChoiceEn },
                                  replyByLang: { id: dlgReplyId, en: dlgReplyEn },
                                  friendshipDelta: 15,
                                  rewardGold: Number(dlgRewardGold) || 0,
                                },
                              ],
                            }),
                          });
                          setDlgTitle('');
                          setDlgIdText('');
                          setDlgEn('');
                          notify('ok', isId ? 'Dialog bercabang disimpan realtime!' : 'Branching dialogue saved!');
                          await refreshAllData();
                        } catch (err) {
                          notify('err', err instanceof Error ? err.message : 'Save failed');
                        }
                      }}
                      className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-extrabold cursor-pointer"
                    >
                      {isId ? 'Simpan Dialog' : 'Save Dialogue'}
                    </button>
                  </section>

                  <div className="space-y-2">
                    {dialogues.map((d) => (
                      <div key={d.id} className="rounded-xl border p-3.5 flex items-start justify-between gap-3 text-xs" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                        <div>
                          <div className="font-extrabold">
                            [{d.npcId}] {d.title} <span className="opacity-60">({d.trigger})</span>
                          </div>
                          <div className="mt-1 opacity-85">🇮🇩 {d.textByLang?.id || d.text?.id || '-'}</div>
                          <div className="opacity-75">🇺🇸 {d.textByLang?.en || d.text?.en || '-'}</div>
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            await authFetch(`/api/dev/dialogues/${encodeURIComponent(d.id)}`, { method: 'DELETE' });
                            notify('ok', 'Deleted dialogue');
                            await refreshAllData();
                          }}
                          className="p-2 rounded-lg text-rose-500 hover:bg-rose-500/10 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 3: CHARACTERS & REALTIME PLAYER OVERRIDE                 */}
              {/* ============================================================ */}
              {activeTab === 'characters' && (
                <div className="space-y-5">
                  <section className="rounded-2xl border p-5 space-y-4" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h2 className="text-sm font-extrabold">{isId ? 'Ubah Data Pemain Realtime (Gold, Diamond, Level, Item)' : 'Realtime Player Parameter Control'}</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                      <select
                        value={selectedUid}
                        onChange={(e) => setSelectedUid(e.target.value)}
                        className="rounded-lg border px-2.5 py-2 bg-transparent font-bold"
                        style={{ borderColor: 'var(--hv-border)' }}
                      >
                        <option value="" className="text-slate-900">{isId ? '-- Pilih Pemain --' : '-- Select Player --'}</option>
                        {(devState?.players || []).map((p) => (
                          <option key={p.uid} value={p.uid} className="text-slate-900">
                            {p.online ? '🟢' : '⚪'} {p.avatarName} ({p.uid.slice(0, 12)})
                          </option>
                        ))}
                      </select>
                      <input type="number" value={playerGoldInput} onChange={(e) => setPlayerGoldInput(e.target.value)} placeholder="Gold" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <input type="number" value={playerDiamondInput} onChange={(e) => setPlayerDiamondInput(e.target.value)} placeholder="Diamond" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <input type="number" value={playerLevelInput} onChange={(e) => setPlayerLevelInput(e.target.value)} placeholder="Level" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <select value={playerGrantItemId} onChange={(e) => setPlayerGrantItemId(e.target.value)} className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }}>
                        {(devState?.itemsCatalog || []).map((it) => (
                          <option key={it.id} value={it.id} className="text-slate-900">{it.iconEmoji} {it.name}</option>
                        ))}
                      </select>
                      <input type="number" value={playerGrantQty} onChange={(e) => setPlayerGrantQty(e.target.value)} placeholder="Qty" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <button
                        type="button"
                        disabled={!selectedUid}
                        onClick={async () => {
                          try {
                            await authFetch('/api/dev/player-override', {
                              method: 'POST',
                              body: JSON.stringify({
                                targetUid: selectedUid,
                                gold: Number(playerGoldInput),
                                diamond: Number(playerDiamondInput),
                                level: Number(playerLevelInput),
                                grantItemId: playerGrantItemId,
                                grantItemQty: Number(playerGrantQty) || 0,
                              }),
                            });
                            notify('ok', isId ? 'Parameter pemain diterapkan realtime!' : 'Player override applied live!');
                            await refreshAllData();
                          } catch (err) {
                            notify('err', err instanceof Error ? err.message : 'Override failed');
                          }
                        }}
                        className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-extrabold cursor-pointer disabled:opacity-40"
                      >
                        {isId ? 'Kirim Override ke Pemain' : 'Push Override to Player'}
                      </button>
                    </div>
                  </section>

                  <div className="rounded-2xl border overflow-x-auto" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <table className="w-full text-xs text-left">
                      <thead className="border-b opacity-75" style={{ borderColor: 'var(--hv-border)' }}>
                        <tr>
                          <th className="p-3">Player</th>
                          <th className="p-3">UID</th>
                          <th className="p-3">Lv</th>
                          <th className="p-3">Gold</th>
                          <th className="p-3">Diamond</th>
                          <th className="p-3">Zone</th>
                          <th className="p-3">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(devState?.players || []).map((p) => (
                          <tr key={p.uid} className="border-b last:border-b-0" style={{ borderColor: 'var(--hv-border)' }}>
                            <td className="p-3 font-bold">{p.avatarName} {p.isGuest && <span className="text-amber-500">(Guest)</span>}</td>
                            <td className="p-3 font-mono text-[11px]">{p.uid}</td>
                            <td className="p-3">{p.level}</td>
                            <td className="p-3 font-bold text-amber-500">{p.gold.toLocaleString()} G</td>
                            <td className="p-3 font-bold text-sky-400">{p.diamond.toLocaleString()} 💎</td>
                            <td className="p-3">{p.zone}</td>
                            <td className="p-3">
                              {p.activeBan ? (
                                <span className="text-rose-500 font-bold">BANNED</span>
                              ) : p.online ? (
                                <span className="text-emerald-500 font-bold">Online</span>
                              ) : (
                                <span className="opacity-60">Offline</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 4: ITEM MANAGEMENT                                       */}
              {/* ============================================================ */}
              {activeTab === 'items' && (
                <div className="space-y-5">
                  <section className="rounded-2xl border p-5 space-y-3" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h2 className="text-sm font-extrabold">{isId ? 'Tambah / Edit Item Custom (Realtime)' : 'Create / Edit Custom Item'}</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs">
                      <input value={newItemId} onChange={(e) => setNewItemId(e.target.value)} placeholder="item_id" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <input value={newItemName} onChange={(e) => setNewItemName(e.target.value)} placeholder="Item Name" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <input value={newItemEmoji} onChange={(e) => setNewItemEmoji(e.target.value)} placeholder="Emoji" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <select value={newItemCategory} onChange={(e) => setNewItemCategory(e.target.value as ItemDef['category'])} className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }}>
                        {['Tools', 'Seeds', 'Crops', 'Food', 'AnimalProducts', 'Materials', 'Fish', 'Gifts'].map((c) => (
                          <option key={c} value={c} className="text-slate-900">{c}</option>
                        ))}
                      </select>
                      <input type="number" value={newItemBuy} onChange={(e) => setNewItemBuy(e.target.value)} placeholder="Buy G" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <input type="number" value={newItemSell} onChange={(e) => setNewItemSell(e.target.value)} placeholder="Sell G" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await authFetch('/api/dev/items', {
                          method: 'POST',
                          body: JSON.stringify({
                            id: newItemId || undefined,
                            name: newItemName || 'Valley Relic',
                            iconEmoji: newItemEmoji || '✨',
                            category: newItemCategory,
                            buyPrice: Number(newItemBuy) || 0,
                            sellPrice: Number(newItemSell) || 0,
                          }),
                        });
                        setNewItemId('');
                        setNewItemName('');
                        notify('ok', isId ? 'Item disimpan realtime!' : 'Custom item saved!');
                        await refreshAllData();
                      }}
                      className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-extrabold cursor-pointer"
                    >
                      {isId ? 'Simpan Item' : 'Save Item'}
                    </button>
                  </section>

                  <div className="flex items-center gap-2">
                    <Search className="w-4 h-4 opacity-60" />
                    <input
                      value={itemSearch}
                      onChange={(e) => setItemSearch(e.target.value)}
                      placeholder={isId ? 'Cari item...' : 'Search items...'}
                      className="w-full max-w-sm rounded-lg border px-3 py-1.5 text-xs bg-transparent"
                      style={{ borderColor: 'var(--hv-border)' }}
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 text-xs">
                    {(devState?.itemsCatalog || [])
                      .filter((i) => !itemSearch || i.name.toLowerCase().includes(itemSearch.toLowerCase()) || i.id.toLowerCase().includes(itemSearch.toLowerCase()))
                      .slice(0, 60)
                      .map((it) => {
                        const isCustom = customItems.some((c) => c.id === it.id);
                        return (
                          <div key={it.id} className="rounded-xl border p-3 flex items-center justify-between gap-2" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                            <div>
                              <div className="font-bold">{it.iconEmoji} {it.name}</div>
                              <div className="text-[11px] opacity-70">{it.id} · Buy {it.buyPrice}G / Sell {it.sellPrice}G</div>
                            </div>
                            {isCustom && (
                              <button
                                type="button"
                                onClick={async () => {
                                  await authFetch(`/api/dev/items/${encodeURIComponent(it.id)}`, { method: 'DELETE' });
                                  await refreshAllData();
                                }}
                                className="p-1.5 text-rose-500 hover:bg-rose-500/10 rounded-lg cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        );
                      })}
                  </div>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 5: ECONOMY MONITOR                                       */}
              {/* ============================================================ */}
              {activeTab === 'economy' && economy && (
                <div className="space-y-5">
                  {runtimeDraft && (
                    <section className="rounded-2xl border p-5 space-y-4" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                      <div>
                        <h2 className="text-sm font-extrabold">{isId ? 'Aturan Pasar Global & Pajak' : 'Global Market & Tax Rules'}</h2>
                        <p className="text-[11px] opacity-65 mt-1">{isId ? 'Supply & Demand dapat menaikkan atau menurunkan harga. Pajak berkurang sesuai level pemain.' : 'Supply & Demand can move prices up or down. Tax rates decrease as player levels progress.'}</p>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                        <label className="space-y-1"><span className="font-bold opacity-75">Minimum Market Multiplier</span><input type="number" min="0.1" max="3" step="0.05" value={runtimeDraft.marketEconomyConfig.minMultiplier} onChange={(e) => setRuntimeDraft({ ...runtimeDraft, marketEconomyConfig: { ...runtimeDraft.marketEconomyConfig, minMultiplier: Math.max(0.1, Number(e.target.value) || 0.1) } })} className="w-full rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} /></label>
                        <label className="space-y-1"><span className="font-bold opacity-75">Maximum Market Multiplier</span><input type="number" min="0.1" max="5" step="0.05" value={runtimeDraft.marketEconomyConfig.maxMultiplier} onChange={(e) => setRuntimeDraft({ ...runtimeDraft, marketEconomyConfig: { ...runtimeDraft.marketEconomyConfig, maxMultiplier: Math.max(0.1, Number(e.target.value) || 0.1) } })} className="w-full rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} /></label>
                        <label className="space-y-1"><span className="font-bold opacity-75">Demand Sensitivity</span><input type="number" min="0.2" max="4" step="0.1" value={runtimeDraft.marketEconomyConfig.goldDemandFactor} onChange={(e) => setRuntimeDraft({ ...runtimeDraft, marketEconomyConfig: { ...runtimeDraft.marketEconomyConfig, goldDemandFactor: Math.max(0.2, Number(e.target.value) || 0.2) } })} className="w-full rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} /></label>
                        <label className="space-y-1"><span className="font-bold opacity-75">Name Change Base Price (min 250 💎)</span><input type="number" min="250" max="1000000" step="1" value={runtimeDraft.nameChangeEconomyConfig.basePriceDiamond} onChange={(e) => setRuntimeDraft({ ...runtimeDraft, nameChangeEconomyConfig: { ...runtimeDraft.nameChangeEconomyConfig, basePriceDiamond: Math.max(250, Math.floor(Number(e.target.value) || 250)), minimumPriceDiamond: 250 } })} className="w-full rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} /></label>
                      </div>
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        {(['goldTiers', 'diamondTiers'] as const).map((currencyKey) => (
                          <div key={currencyKey} className="rounded-xl border p-3 space-y-2" style={{ borderColor: 'var(--hv-border)' }}>
                            <h3 className="text-xs font-extrabold">{currencyKey === 'goldTiers' ? 'Gold Tax Progression' : 'Diamond Tax Progression'}</h3>
                            {(runtimeDraft.economyTaxConfig[currencyKey] || []).map((tier, index) => (
                              <div key={`${currencyKey}-${index}`} className="grid grid-cols-2 gap-2 items-center text-[11px]">
                                <label className="space-y-1"><span className="opacity-70">Minimum Level</span><input type="number" min="1" max="999" value={tier.minLevel} onChange={(e) => setRuntimeDraft({ ...runtimeDraft, economyTaxConfig: { ...runtimeDraft.economyTaxConfig, [currencyKey]: runtimeDraft.economyTaxConfig[currencyKey].map((entry, i) => i === index ? { ...entry, minLevel: Math.max(1, Math.floor(Number(e.target.value) || 1)) } : entry) } })} className="w-full rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} /></label>
                                <label className="space-y-1"><span className="opacity-70">Tax %</span><input type="number" min="0" max="100" step="0.5" value={tier.taxPercent} onChange={(e) => setRuntimeDraft({ ...runtimeDraft, economyTaxConfig: { ...runtimeDraft.economyTaxConfig, [currencyKey]: runtimeDraft.economyTaxConfig[currencyKey].map((entry, i) => i === index ? { ...entry, taxPercent: Math.max(0, Math.min(100, Number(e.target.value) || 0)) } : entry) } })} className="w-full rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} /></label>
                              </div>
                            ))}
                          </div>
                        ))}
                      </div>
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <label className="flex items-center gap-2 text-xs font-bold"><input type="checkbox" checked={runtimeDraft.economyTaxConfig.enabled} onChange={(e) => setRuntimeDraft({ ...runtimeDraft, economyTaxConfig: { ...runtimeDraft.economyTaxConfig, enabled: e.target.checked } })} /> {isId ? 'Aktifkan pajak transaksi' : 'Enable transaction tax'}</label>
                        <button type="button" onClick={() => void pushRuntimePatch({ marketEconomyConfig: runtimeDraft.marketEconomyConfig, economyTaxConfig: runtimeDraft.economyTaxConfig, nameChangeEconomyConfig: runtimeDraft.nameChangeEconomyConfig }, isId ? 'Aturan ekonomi disimpan.' : 'Economy rules saved.')} className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-extrabold cursor-pointer">{isId ? 'Simpan Aturan Ekonomi' : 'Save Economy Rules'}</button>
                      </div>
                    </section>
                  )}
                  <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
                    <div className="rounded-xl border p-4" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                      <div className="text-xs opacity-70">Total Server Gold</div>
                      <div className="text-xl font-extrabold text-amber-500 mt-1">{economy.totalServerGold.toLocaleString()} G</div>
                    </div>
                    <div className="rounded-xl border p-4" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                      <div className="text-xs opacity-70">Total Server Diamond</div>
                      <div className="text-xl font-extrabold text-sky-400 mt-1">{economy.totalServerDiamond.toLocaleString()} 💎</div>
                    </div>
                    <div className="rounded-xl border p-4" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                      <div className="text-xs opacity-70">Market Volume</div>
                      <div className="text-xl font-extrabold text-emerald-500 mt-1">{economy.marketVolumeGold.toLocaleString()} G</div>
                    </div>
                    <div className="rounded-xl border p-4" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                      <div className="text-xs opacity-70">Diamond Tax Pool</div>
                      <div className="text-xl font-extrabold text-sky-400 mt-1">{economy.taxPoolDiamond.toLocaleString()} 💎</div>
                    </div>
                    <div className="rounded-xl border p-4" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                      <div className="text-xs opacity-70">Active P2P Listings</div>
                      <div className="text-xl font-extrabold mt-1">{economy.activeP2PListings}</div>
                    </div>
                  </div>

                  <div className="rounded-2xl border p-4" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h3 className="text-sm font-extrabold mb-3">{isId ? 'Top Spenders & Aktivitas Perdagangan' : 'Top Spenders'}</h3>
                    {economy.topSpenders.length === 0 ? (
                      <p className="text-xs opacity-65">{isId ? 'Belum ada transaksi tercatat.' : 'No spending activity recorded yet.'}</p>
                    ) : (
                      <div className="space-y-2 text-xs">
                        {economy.topSpenders.map((sp) => (
                          <div key={sp.uid} className="flex items-center justify-between border-b pb-2 last:border-b-0" style={{ borderColor: 'var(--hv-border)' }}>
                            <span className="font-bold">{sp.playerName} <span className="opacity-60 font-mono">({sp.uid.slice(0, 10)})</span></span>
                            <span>{sp.goldSpent.toLocaleString()} G · {sp.diamondSpent} 💎 · {sp.txCount} tx</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 6: SHOP & BUNDLES                                        */}
              {/* ============================================================ */}
              {activeTab === 'shop' && (
                <div className="space-y-5">
                  <section className="rounded-2xl border p-5 space-y-3" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h2 className="text-sm font-extrabold">{isId ? 'Tambah Produk Toko / Promo Diskon' : 'Create Shop Product / Discount Bundle'}</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs">
                      <input value={shopName} onChange={(e) => setShopName(e.target.value)} placeholder="Product Name" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <select value={shopItemId} onChange={(e) => setShopItemId(e.target.value)} className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }}>
                        {(devState?.itemsCatalog || []).map((i) => (
                          <option key={i.id} value={i.id} className="text-slate-900">{i.iconEmoji} {i.name}</option>
                        ))}
                      </select>
                      <input type="number" value={shopQty} onChange={(e) => setShopQty(e.target.value)} placeholder="Qty" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <input type="number" value={shopGoldPrice} onChange={(e) => setShopGoldPrice(e.target.value)} placeholder="Gold Price" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <input type="number" value={shopDiamondPrice} onChange={(e) => setShopDiamondPrice(e.target.value)} placeholder="Diamond" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                      <input type="number" value={shopDiscount} onChange={(e) => setShopDiscount(e.target.value)} placeholder="Discount %" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await authFetch('/api/dev/shop', {
                          method: 'POST',
                          body: JSON.stringify({
                            name: shopName || 'Harvest Bundle',
                            itemId: shopItemId,
                            quantity: Number(shopQty) || 1,
                            goldPrice: Number(shopGoldPrice) || 0,
                            diamondPrice: Number(shopDiamondPrice) || 0,
                            discountPercent: Number(shopDiscount) || 0,
                            isBundle: Number(shopQty) > 1,
                          }),
                        });
                        setShopName('');
                        notify('ok', isId ? 'Produk toko disimpan!' : 'Shop product saved!');
                        await refreshAllData();
                      }}
                      className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-extrabold cursor-pointer"
                    >
                      {isId ? 'Simpan Produk' : 'Save Product'}
                    </button>
                  </section>

                  <div className="space-y-2 text-xs">
                    {shopProducts.map((p) => (
                      <div key={p.id} className="rounded-xl border p-3 flex items-center justify-between" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                        <div>
                          <div className="font-extrabold">{p.name} <span className="text-emerald-500">-{p.discountPercent ?? p.discountPct ?? 0}%</span></div>
                          <div className="opacity-70">{p.itemId} × {p.quantity || 1} · {p.goldPrice ?? p.price ?? 0}G / {p.diamondPrice ?? 0}💎</div>
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            await authFetch(`/api/dev/shop/${encodeURIComponent(p.id)}`, { method: 'DELETE' });
                            await refreshAllData();
                          }}
                          className="p-2 text-rose-500 hover:bg-rose-500/10 rounded-lg cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 7: HISTORY TRACKING                                      */}
              {/* ============================================================ */}
              {activeTab === 'history' && (
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2 text-xs">
                    <select value={historyFilter} onChange={(e) => setHistoryFilter(e.target.value)} className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }}>
                      <option value="all" className="text-slate-900">All Categories</option>
                      <option value="gold_spend" className="text-slate-900">Gold</option>
                      <option value="diamond_spend" className="text-slate-900">Diamond</option>
                      <option value="trading" className="text-slate-900">Trading</option>
                      <option value="login" className="text-slate-900">Login</option>
                    </select>
                    <input value={historyQuery} onChange={(e) => setHistoryQuery(e.target.value)} placeholder="Filter UID / keyword..." className="rounded-lg border px-3 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    <button type="button" onClick={() => void refreshAllData()} className="px-3 py-2 rounded-lg bg-amber-600 text-white font-bold cursor-pointer">Filter</button>
                  </div>
                  <div className="rounded-2xl border divide-y text-xs" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    {historyLogs.length === 0 ? (
                      <div className="p-4 opacity-65">{isId ? 'Belum ada riwayat.' : 'No history records.'}</div>
                    ) : (
                      historyLogs.map((h) => (
                        <div key={h.id} className="p-3 flex flex-wrap justify-between gap-2">
                          <div>
                            <span className="font-extrabold">[{h.category}]</span> {h.playerName}: {h.summary}
                          </div>
                          <span className="opacity-60">{new Date(h.timestamp).toLocaleString()}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 8: MODERATION (4 BAN TYPES) & GLOBAL ANNOUNCER           */}
              {/* ============================================================ */}
              {activeTab === 'moderation' && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                  <section className="rounded-2xl border p-5 space-y-3 text-xs" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h2 className="text-sm font-extrabold flex items-center gap-2">
                      <Ban className="w-4 h-4 text-rose-500" />
                      {isId ? 'Sistem Ban Pemain (Realtime Lockdown)' : 'Player Ban & Moderation'}
                    </h2>
                    <input value={banUid} onChange={(e) => setBanUid(e.target.value)} placeholder="Target Player UID" className="w-full rounded-lg border px-3 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    <div className="grid grid-cols-2 gap-2">
                      <select value={banType} onChange={(e) => setBanType(e.target.value as BanType)} className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }}>
                        <option value="chat_ban" className="text-slate-900">Chat Ban</option>
                        <option value="temporary_ban" className="text-slate-900">Temporary Ban</option>
                        <option value="permanent_ban" className="text-slate-900">Permanent Ban</option>
                        <option value="account_lock" className="text-slate-900">Account Lock</option>
                      </select>
                      <input type="number" value={banMinutes} onChange={(e) => setBanMinutes(e.target.value)} placeholder="Duration (mins)" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    </div>
                    <input value={banReason} onChange={(e) => setBanReason(e.target.value)} placeholder={isId ? 'Alasan ban...' : 'Ban reason...'} className="w-full rounded-lg border px-3 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    <input value={banDevMsg} onChange={(e) => setBanDevMsg(e.target.value)} placeholder={isId ? 'Pesan developer untuk pemain...' : 'Developer message...'} className="w-full rounded-lg border px-3 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          await authFetch('/api/dev/bans', {
                            method: 'POST',
                            body: JSON.stringify({
                              uid: banUid,
                              banType,
                              durationMinutes: Number(banMinutes) || 60,
                              reason: banReason,
                              devMessage: banDevMsg,
                            }),
                          });
                          notify('ok', isId ? 'Sanksi ban diterapkan realtime!' : 'Ban issued realtime!');
                          await refreshAllData();
                        } catch (err) {
                          notify('err', err instanceof Error ? err.message : 'Ban failed');
                        }
                      }}
                      className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-extrabold cursor-pointer"
                    >
                      {isId ? 'Terapkan Ban Sekarang' : 'Issue Ban Now'}
                    </button>

                    <div className="pt-3 border-t space-y-2" style={{ borderColor: 'var(--hv-border)' }}>
                      <div className="font-bold opacity-75">{isId ? 'Daftar Ban Aktif' : 'Active Bans'}</div>
                      {(devState?.bans || []).filter((b) => b.active).map((b) => (
                        <div key={b.uid} className="rounded-lg border p-2.5 flex items-center justify-between" style={{ borderColor: 'var(--hv-border)' }}>
                          <div>
                            <div className="font-bold">{b.playerName || b.uid} · <span className="text-rose-500">{b.banType}</span></div>
                            <div className="opacity-70">{b.reason}</div>
                          </div>
                          <button
                            type="button"
                            onClick={async () => {
                              await authFetch(`/api/dev/bans/${encodeURIComponent(b.uid)}`, { method: 'DELETE' });
                              notify('ok', `Unbanned ${b.uid}`);
                              await refreshAllData();
                            }}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold cursor-pointer"
                          >
                            Unban
                          </button>
                        </div>
                      ))}
                    </div>
                  </section>

                  <section className="rounded-2xl border p-5 space-y-3 text-xs" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h2 className="text-sm font-extrabold flex items-center gap-2">
                      <Megaphone className="w-4 h-4 text-amber-500" />
                      {isId ? 'Pengumuman Global Realtime' : 'Global Live Announcer'}
                    </h2>
                    <div className="grid grid-cols-2 gap-2">
                      <select value={annCategory} onChange={(e) => setAnnCategory(e.target.value as AnnouncementCategory)} className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }}>
                        <option value="update" className="text-slate-900">Update Notice</option>
                        <option value="maintenance" className="text-slate-900">Maintenance Notice</option>
                        <option value="event" className="text-slate-900">Event Notice</option>
                        <option value="emergency" className="text-slate-900">Emergency Notice</option>
                        <option value="promotion" className="text-slate-900">Promotion Notice</option>
                      </select>
                      <input type="number" value={annDuration} onChange={(e) => setAnnDuration(e.target.value)} placeholder="Duration (sec)" className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    </div>
                    <input value={annTitle} onChange={(e) => setAnnTitle(e.target.value)} placeholder={isId ? 'Judul Pengumuman' : 'Announcement Title'} className="w-full rounded-lg border px-3 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    <textarea rows={4} value={annMessage} onChange={(e) => setAnnMessage(e.target.value)} placeholder={isId ? 'Isi pengumuman untuk semua pemain...' : 'Broadcast message...'} className="w-full rounded-lg border p-3 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    <button
                      type="button"
                      onClick={async () => {
                        const res = await authFetch('/api/dev/announcement', {
                          method: 'POST',
                          body: JSON.stringify({
                            category: annCategory,
                            title: annTitle,
                            message: annMessage,
                            durationSec: Number(annDuration) || 15,
                            enabled: true,
                          }),
                        });
                        notify('ok', isId ? `Pengumuman dikirim ke ${res.notified} pemain!` : `Broadcasted to ${res.notified} players!`);
                      }}
                      className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-extrabold cursor-pointer"
                    >
                      {isId ? 'Kirim Pengumuman ke Semua Pemain' : 'Broadcast Announcement Now'}
                    </button>
                  </section>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 9: MOBILE LOCK POV ORBIT + AUTO-RETURN & GAMEPAD CONFIG  */}
              {/* ============================================================ */}
              {activeTab === 'controls' && runtimeDraft && (
                <div className="space-y-5">
                  <section className="rounded-2xl border p-5 space-y-4 text-xs" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h2 className="text-sm font-extrabold flex items-center gap-2">
                      <Gamepad2 className="w-4 h-4 text-amber-500" />
                      {isId
                        ? 'Pengaturan Kamera Lock POV Mobile (Geser Bebas + Auto-Return ke Depan)'
                        : 'Mobile Lock POV Free-Orbit & Auto-Return Camera Settings'}
                    </h2>
                    <label className="flex items-center gap-2.5 font-bold cursor-pointer">
                      <input
                        type="checkbox"
                        checked={cameraCfg.mobileLockOrbitEnabled !== false}
                        onChange={(e) =>
                          setRuntimeDraft({
                            ...runtimeDraft,
                            cameraConfig: { ...cameraCfg, mobileLockOrbitEnabled: e.target.checked },
                          })
                        }
                      />
                      <span>
                        {isId
                          ? 'Izinkan geser kamera 360° pada Mode Lock POV Mobile lalu kembali otomatis ke belakang karakter'
                          : 'Enable 360° camera drag in Mobile Lock POV with smooth auto-return behind character'}
                      </span>
                    </label>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      <label className="space-y-1">
                        <span className="font-bold">
                          {isId ? 'Jeda Auto-Return (detik)' : 'Auto-Return Delay (sec)'}: {(cameraCfg.mobileLockAutoReturnDelaySec ?? 2.5).toFixed(1)}s
                        </span>
                        <input
                          type="range"
                          min={0.5}
                          max={10}
                          step={0.5}
                          value={cameraCfg.mobileLockAutoReturnDelaySec ?? 2.5}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              cameraConfig: { ...cameraCfg, mobileLockAutoReturnDelaySec: Number(e.target.value) },
                            })
                          }
                          className="w-full"
                        />
                      </label>

                      <label className="space-y-1">
                        <span className="font-bold">
                          {isId ? 'Kecepatan Auto-Return' : 'Auto-Return Speed'}: {(cameraCfg.mobileLockAutoReturnSpeed ?? 3.2).toFixed(1)}
                        </span>
                        <input
                          type="range"
                          min={0.5}
                          max={10}
                          step={0.2}
                          value={cameraCfg.mobileLockAutoReturnSpeed ?? 3.2}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              cameraConfig: { ...cameraCfg, mobileLockAutoReturnSpeed: Number(e.target.value) },
                            })
                          }
                          className="w-full"
                        />
                      </label>

                      <label className="space-y-1">
                        <span className="font-bold">Camera Distance: {cameraCfg.defaultDistance.toFixed(1)}</span>
                        <input
                          type="range"
                          min={4}
                          max={16}
                          step={0.5}
                          value={cameraCfg.defaultDistance}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              cameraConfig: { ...cameraCfg, defaultDistance: Number(e.target.value) },
                            })
                          }
                          className="w-full"
                        />
                      </label>

                      <label className="space-y-1">
                        <span className="font-bold">Camera Pitch: {cameraCfg.defaultPitch.toFixed(2)}</span>
                        <input
                          type="range"
                          min={0.18}
                          max={0.85}
                          step={0.02}
                          value={cameraCfg.defaultPitch}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              cameraConfig: { ...cameraCfg, defaultPitch: Number(e.target.value) },
                            })
                          }
                          className="w-full"
                        />
                      </label>
                    </div>

                    <div className="pt-3 border-t grid grid-cols-1 sm:grid-cols-3 gap-4" style={{ borderColor: 'var(--hv-border)' }}>
                      <label className="space-y-1">
                        <span className="font-bold">Analog Size: {mobileCfg.joystickSizePx}px</span>
                        <input
                          type="range"
                          min={84}
                          max={164}
                          value={mobileCfg.joystickSizePx}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              mobileControlsConfig: { ...mobileCfg, joystickSizePx: Number(e.target.value) },
                            })
                          }
                          className="w-full"
                        />
                      </label>
                      <label className="space-y-1">
                        <span className="font-bold">Button Scale: {mobileCfg.buttonScale.toFixed(2)}x</span>
                        <input
                          type="range"
                          min={0.75}
                          max={1.4}
                          step={0.05}
                          value={mobileCfg.buttonScale}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              mobileControlsConfig: { ...mobileCfg, buttonScale: Number(e.target.value) },
                            })
                          }
                          className="w-full"
                        />
                      </label>
                      <label className="space-y-1">
                        <span className="font-bold">Analog Bottom Offset: {mobileCfg.joystickBottomPx}px</span>
                        <input
                          type="range"
                          min={16}
                          max={120}
                          step={2}
                          value={mobileCfg.joystickBottomPx}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              mobileControlsConfig: { ...mobileCfg, joystickBottomPx: Number(e.target.value) },
                            })
                          }
                          className="w-full"
                        />
                      </label>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        void pushRuntimePatch(
                          {
                            cameraConfig: runtimeDraft.cameraConfig,
                            mobileControlsConfig: runtimeDraft.mobileControlsConfig,
                          },
                          isId
                            ? 'Pengaturan Kamera Lock POV & Mobile Gamepad disimpan realtime!'
                            : 'Camera Lock POV & Mobile Gamepad settings saved live!'
                        )
                      }
                      className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-extrabold cursor-pointer"
                    >
                      {isId ? 'Simpan Pengaturan Kamera & Mobile' : 'Save Camera & Mobile Settings'}
                    </button>
                  </section>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 10: LIVE ENV CONFIG & GUEST SESSION DURATION             */}
              {/* ============================================================ */}
              {activeTab === 'env' && runtimeDraft && (
                <div className="space-y-5">
                  <section className="rounded-2xl border p-5 space-y-3 text-xs" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h2 className="text-sm font-extrabold">{isId ? 'Durasi Sesi Akun Guest & Peringatan Logout' : 'Guest Session Timer & Warning Threshold'}</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <label className="space-y-1">
                        <span className="font-bold">{isId ? 'Durasi Sesi Guest (Menit, default 60)' : 'Guest Session Duration (Minutes)'}</span>
                        <input
                          type="number"
                          min={1}
                          max={1440}
                          value={guestCfg.durationMinutes ?? 60}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              guestSessionConfig: {
                                ...guestCfg,
                                durationMinutes: Math.max(1, Number(e.target.value) || 60),
                              },
                            })
                          }
                          className="w-full rounded-lg border px-3 py-2 bg-transparent"
                          style={{ borderColor: 'var(--hv-border)' }}
                        />
                      </label>
                      <label className="space-y-1">
                        <span className="font-bold">{isId ? 'Peringatan Sebelum Logout (Menit, default 5)' : 'Warning Before Logout (Minutes)'}</span>
                        <input
                          type="number"
                          min={1}
                          max={60}
                          value={guestCfg.warningBeforeMinutes ?? 5}
                          onChange={(e) =>
                            setRuntimeDraft({
                              ...runtimeDraft,
                              guestSessionConfig: {
                                ...guestCfg,
                                warningBeforeMinutes: Math.max(1, Number(e.target.value) || 5),
                              },
                            })
                          }
                          className="w-full rounded-lg border px-3 py-2 bg-transparent"
                          style={{ borderColor: 'var(--hv-border)' }}
                        />
                      </label>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        void pushRuntimePatch(
                          {
                            guestSessionConfig: guestCfg,
                          },
                          isId ? 'Pengaturan sesi Guest disimpan!' : 'Guest timer saved!'
                        )
                      }
                      className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-extrabold cursor-pointer"
                    >
                      {isId ? 'Simpan Timer Guest' : 'Save Guest Timer'}
                    </button>
                  </section>

                  <section className="rounded-2xl border p-5 space-y-3 text-xs" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <div className="flex items-center justify-between">
                      <h2 className="text-sm font-extrabold">{isId ? 'Live Environment Variables (Secrets Ter-mask)' : 'Live Environment Variables (Masked Secrets)'}</h2>
                      <button
                        type="button"
                        onClick={async () => {
                          await authFetch('/api/dev/env-config', {
                            method: 'POST',
                            body: JSON.stringify({ updates: envEdits }),
                          });
                          setEnvEdits({});
                          notify('ok', isId ? 'Variabel Env diterapkan realtime!' : 'Live env variables updated!');
                          await refreshAllData();
                        }}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold cursor-pointer"
                      >
                        {isId ? 'Simpan Perubahan Env' : 'Apply Env Updates'}
                      </button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[520px] overflow-y-auto pr-1">
                      {envEntries.map((ev) => (
                        <div key={ev.key} className="rounded-xl border p-3 space-y-1" style={{ borderColor: 'var(--hv-border)', backgroundColor: 'var(--hv-surface-2)' }}>
                          <div className="flex items-center justify-between">
                            <span className="font-mono font-bold text-[11px]">{ev.key}</span>
                            <span className="text-[10px] opacity-65 uppercase">{ev.group}{ev.isSecret ? ' · SECRET' : ''}</span>
                          </div>
                          <input
                            type={ev.isSecret ? 'password' : 'text'}
                            placeholder={ev.isSecret ? (ev.configured ? '•••••••• (set — leave blank to keep)' : '(not set)') : ev.preview}
                            value={envEdits[ev.key] ?? (ev.isSecret ? '' : ev.value)}
                            onChange={(e) => setEnvEdits((prev) => ({ ...prev, [ev.key]: e.target.value }))}
                            className="w-full rounded-lg border px-2.5 py-1.5 bg-transparent font-mono text-[11px]"
                            style={{ borderColor: 'var(--hv-border)' }}
                          />
                        </div>
                      ))}
                    </div>
                  </section>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 11: SAFE FILE EXPLORER (READ / EDIT / CREATE / DELETE)   */}
              {/* ============================================================ */}
              {activeTab === 'files' && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                  <div className="lg:col-span-5 rounded-2xl border p-4 space-y-3 text-xs" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <div className="flex items-center justify-between gap-2">
                      <div className="font-extrabold flex items-center gap-1.5">
                        <FolderOpen className="w-4 h-4 text-amber-500" />
                        <span>/{explorerPath || ''}</span>
                      </div>
                      {explorerPath && (
                        <button
                          type="button"
                          onClick={() => {
                            const parts = explorerPath.split('/').filter(Boolean);
                            parts.pop();
                            void loadExplorerDir(parts.join('/'));
                          }}
                          className="px-2.5 py-1 rounded-lg border font-bold cursor-pointer"
                          style={{ borderColor: 'var(--hv-border)' }}
                        >
                          .. Up
                        </button>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <input
                        value={newFilePathInput}
                        onChange={(e) => setNewFilePathInput(e.target.value)}
                        placeholder={isId ? 'nama_file_baru.txt' : 'new_file.txt'}
                        className="flex-1 rounded-lg border px-2.5 py-1.5 bg-transparent"
                        style={{ borderColor: 'var(--hv-border)' }}
                      />
                      <button
                        type="button"
                        onClick={() => void handleCreateNewFile()}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold cursor-pointer"
                      >
                        + File
                      </button>
                    </div>

                    {pendingDeletePath && (
                      <div className="rounded-xl border border-rose-500 bg-rose-500/10 p-3 space-y-2">
                        <div className="font-bold text-rose-500">
                          {isId ? `Konfirmasi hapus: ${pendingDeletePath}?` : `Confirm delete: ${pendingDeletePath}?`}
                        </div>
                        <div className="flex gap-2">
                          <button type="button" onClick={() => void handleConfirmDeleteFile()} className="px-3 py-1 rounded-lg bg-rose-600 text-white font-bold cursor-pointer">
                            {isId ? 'Ya, Hapus' : 'Delete'}
                          </button>
                          <button type="button" onClick={() => setPendingDeletePath(null)} className="px-3 py-1 rounded-lg border font-bold cursor-pointer" style={{ borderColor: 'var(--hv-border)' }}>
                            {isId ? 'Batal' : 'Cancel'}
                          </button>
                        </div>
                      </div>
                    )}

                    <div className="divide-y max-h-[500px] overflow-y-auto" style={{ borderColor: 'var(--hv-border)' }}>
                      {explorerEntries.map((ent) => (
                        <div key={ent.path} className="py-2 flex items-center justify-between gap-2">
                          <button
                            type="button"
                            onClick={() => (ent.isDirectory ? void loadExplorerDir(ent.path) : void handleOpenFile(ent.path))}
                            className="flex items-center gap-2 text-left flex-1 hover:text-amber-500 font-semibold cursor-pointer truncate"
                          >
                            {ent.isDirectory ? <Folder className="w-4 h-4 text-amber-500 shrink-0" /> : <FileCode2 className="w-4 h-4 text-sky-400 shrink-0" />}
                            <span className="truncate">{ent.name}</span>
                            {ent.isDirectory && <ChevronRight className="w-3.5 h-3.5 opacity-50 shrink-0" />}
                          </button>
                          <button
                            type="button"
                            onClick={() => setPendingDeletePath(ent.path)}
                            className="p-1 text-rose-500 hover:bg-rose-500/10 rounded cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                    <p className="text-[11px] opacity-65">
                      {isId
                        ? 'Folder secrets (game_secrets, dev_panel_secrets, .env, *.pem, *.key) otomatis diblokir demi keamanan.'
                        : 'Sensitive secret folders (game_secrets, dev_panel_secrets, .env, *.pem, *.key) are hard-blocked.'}
                    </p>
                  </div>

                  <div className="lg:col-span-7 rounded-2xl border p-4 flex flex-col gap-3 text-xs" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold">{openedFilePath || (isId ? 'Pilih file untuk diedit' : 'Select a file to edit')}</span>
                      {openedFilePath && (
                        <button
                          type="button"
                          onClick={() => void handleSaveFile()}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-extrabold cursor-pointer"
                        >
                          <Save className="w-3.5 h-3.5" />
                          {isId ? 'Simpan File' : 'Save File'}
                        </button>
                      )}
                    </div>
                    <textarea
                      value={openedFileContent}
                      onChange={(e) => setOpenedFileContent(e.target.value)}
                      disabled={!openedFilePath}
                      rows={24}
                      spellCheck={false}
                      className="w-full flex-1 rounded-xl border p-3 font-mono text-[12px] bg-transparent resize-y"
                      style={{ borderColor: 'var(--hv-border)' }}
                    />
                  </div>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 12: BACKUP MANAGER (data/data_dev_panel/backup/)         */}
              {/* ============================================================ */}
              {activeTab === 'backups' && (
                <div className="space-y-5 text-xs">
                  <section className="rounded-2xl border p-5 space-y-3" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h2 className="text-sm font-extrabold flex items-center gap-2">
                      <Database className="w-4 h-4 text-amber-500" />
                      {isId ? 'Backup Manager (web_game/data/data_dev_panel/backup/)' : 'Backup Manager'}
                    </h2>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => void handleCreateBackup('default')}
                        className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-extrabold cursor-pointer"
                      >
                        {isId ? 'Buat Backup Default' : 'Create Default Backup'}
                      </button>
                      <input
                        value={backupLabelInput}
                        onChange={(e) => setBackupLabelInput(e.target.value)}
                        placeholder={isId ? 'Label backup manual (opsional)...' : 'Manual backup label...'}
                        className="rounded-xl border px-3 py-2 bg-transparent"
                        style={{ borderColor: 'var(--hv-border)' }}
                      />
                      <button
                        type="button"
                        onClick={() => void handleCreateBackup('manual')}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold cursor-pointer"
                      >
                        {isId ? 'Buat Backup Manual' : 'Create Manual Backup'}
                      </button>
                    </div>
                  </section>

                  {pendingRestoreFile && (
                    <div className="rounded-xl border border-amber-500 bg-amber-500/10 p-4 flex flex-wrap items-center justify-between gap-2">
                      <span className="font-bold">
                        {isId ? `Pulihkan konfigurasi dari ${pendingRestoreFile}?` : `Restore config from ${pendingRestoreFile}?`}
                      </span>
                      <div className="flex gap-2">
                        <button type="button" onClick={() => void handleRestoreBackup(pendingRestoreFile)} className="px-3 py-1.5 rounded-lg bg-amber-600 text-white font-bold cursor-pointer">
                          {isId ? 'Ya, Pulihkan' : 'Confirm Restore'}
                        </button>
                        <button type="button" onClick={() => setPendingRestoreFile(null)} className="px-3 py-1.5 rounded-lg border font-bold cursor-pointer" style={{ borderColor: 'var(--hv-border)' }}>
                          {isId ? 'Batal' : 'Cancel'}
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="rounded-2xl border divide-y" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    {backups.length === 0 ? (
                      <div className="p-4 opacity-65">{isId ? 'Belum ada file backup.' : 'No backup files yet.'}</div>
                    ) : (
                      backups.map((b) => (
                        <div key={b.fileName} className="p-3.5 flex flex-wrap items-center justify-between gap-2">
                          <div>
                            <div className="font-mono font-bold flex items-center gap-2">
                              <span>{b.fileName}</span>
                              {b.isDefault && <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-500 text-[10px] font-extrabold">DEFAULT</span>}
                            </div>
                            <div className="opacity-65 mt-0.5">
                              {(b.sizeBytes / 1024).toFixed(1)} KB · {new Date(b.createdAt).toLocaleString()}
                            </div>
                          </div>
                          {isOwner && (
                            <button
                              type="button"
                              onClick={() => setPendingRestoreFile(b.fileName)}
                              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border font-bold hover:bg-amber-600 hover:text-white cursor-pointer"
                              style={{ borderColor: 'var(--hv-border)' }}
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                              Restore
                            </button>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 13: OWNER-ONLY TEAM MANAGEMENT (SINGLE OWNER PINNED TOP) */}
              {/* ============================================================ */}
              {activeTab === 'team' && isOwner && (
                <div className="space-y-5 text-xs">
                  {/* Pinned Single Owner Card */}
                  <section className="rounded-2xl border-2 border-amber-500/60 p-5 space-y-2" style={{ backgroundColor: 'var(--hv-surface)' }}>
                    <div className="flex items-center justify-between">
                      <span className="inline-flex items-center gap-1.5 text-amber-500 font-extrabold uppercase tracking-wider">
                        <Crown className="w-4 h-4" />
                        {isId ? 'SINGLE OWNER (TERSEMAT DI PALING ATAS — HANYA 1 AKUN)' : 'SINGLE OWNER (PINNED TOP — ONLY 1 ACCOUNT)'}
                      </span>
                      <span className="px-2.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-500 font-bold">ACTIVE OWNER</span>
                    </div>
                    {teamState?.owner && (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2">
                        <div><span className="opacity-65">Name:</span> <span className="font-extrabold">{teamState.owner.displayName}</span></div>
                        <div><span className="opacity-65">Email:</span> <span className="font-mono">{teamState.owner.emailMasked}</span></div>
                        <div><span className="opacity-65">Provider / UID:</span> <span className="font-mono">{teamState.owner.provider} · {teamState.owner.uid}</span></div>
                      </div>
                    )}
                  </section>

                  {/* Add Developer by Registered Game ID */}
                  <section className="rounded-2xl border p-5 space-y-3" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h2 className="text-sm font-extrabold flex items-center gap-2">
                      <UserPlus className="w-4 h-4 text-emerald-500" />
                      {isId ? 'Tambahkan Developer dengan ID Game Terdaftar' : 'Add Developer by Registered Game ID'}
                    </h2>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input
                        value={addDevUid}
                        onChange={(e) => setAddDevUid(e.target.value)}
                        placeholder={isId ? 'Masukkan ID Game / UID pemain...' : 'Enter registered Player UID...'}
                        className="rounded-lg border px-3 py-2 bg-transparent font-mono"
                        style={{ borderColor: 'var(--hv-border)' }}
                      />
                      <input
                        value={addDevName}
                        onChange={(e) => setAddDevName(e.target.value)}
                        placeholder={isId ? 'Nama Label Developer (opsional)' : 'Developer Label (optional)'}
                        className="rounded-lg border px-3 py-2 bg-transparent"
                        style={{ borderColor: 'var(--hv-border)' }}
                      />
                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            await authFetch('/api/dev/team/add', {
                              method: 'POST',
                              body: JSON.stringify({ uid: addDevUid, displayName: addDevName || undefined }),
                            });
                            setAddDevUid('');
                            setAddDevName('');
                            notify('ok', isId ? 'Developer berhasil ditambahkan!' : 'Developer added!');
                            await refreshAllData();
                          } catch (err) {
                            notify('err', err instanceof Error ? err.message : 'Failed to add developer');
                          }
                        }}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold cursor-pointer"
                      >
                        {isId ? '+ Tambah Developer' : '+ Add Developer'}
                      </button>
                    </div>
                    {(teamState?.registeredPlayerIds || []).length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        <span className="opacity-65">{isId ? 'Pilih cepat ID terdaftar:' : 'Quick pick registered ID:'}</span>
                        {teamState!.registeredPlayerIds.slice(0, 12).map((p) => (
                          <button
                            key={p.uid}
                            type="button"
                            onClick={() => {
                              setAddDevUid(p.uid);
                              setAddDevName(p.avatarName);
                            }}
                            className="px-2 py-0.5 rounded-md border font-mono hover:border-amber-500 cursor-pointer"
                            style={{ borderColor: 'var(--hv-border)' }}
                          >
                            {p.avatarName} ({p.uid.slice(0, 10)})
                          </button>
                        ))}
                      </div>
                    )}
                  </section>

                  {/* Developer List with Revoke Session & Delete */}
                  <section className="rounded-2xl border p-5 space-y-3" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    <h2 className="text-sm font-extrabold">{isId ? 'Daftar Akun Developer Aktif' : 'Registered Developers'}</h2>
                    {(teamState?.developers || []).length === 0 ? (
                      <p className="opacity-65">{isId ? 'Belum ada Developer ditambahkan oleh Owner.' : 'No Developers added yet.'}</p>
                    ) : (
                      <div className="divide-y" style={{ borderColor: 'var(--hv-border)' }}>
                        {teamState!.developers.map((d) => (
                          <div key={d.uid} className="py-3 flex flex-wrap items-center justify-between gap-2">
                            <div>
                              <div className="font-extrabold">
                                {d.displayName} <span className="font-mono opacity-70">({d.uid})</span>
                              </div>
                              <div className="opacity-65">
                                Added {new Date(d.addedAt).toLocaleString()} · {d.online ? '🟢 Online' : '⚪ Offline'}
                                {d.sessionRevokedAt ? ` · Revoked ${new Date(d.sessionRevokedAt).toLocaleTimeString()}` : ''}
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={async () => {
                                  await authFetch('/api/dev/team/revoke-session', {
                                    method: 'POST',
                                    body: JSON.stringify({ uid: d.uid }),
                                  });
                                  notify('ok', isId ? `Sesi aktif ${d.displayName} dicabut!` : `Revoked active session for ${d.displayName}`);
                                  await refreshAllData();
                                }}
                                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold cursor-pointer"
                              >
                                <Unlock className="w-3.5 h-3.5" />
                                {isId ? 'Cabut Sesi Aktif' : 'Revoke Session'}
                              </button>
                              <button
                                type="button"
                                onClick={async () => {
                                  await authFetch(`/api/dev/team/developer/${encodeURIComponent(d.uid)}`, { method: 'DELETE' });
                                  notify('ok', isId ? `Developer ${d.displayName} dihapus.` : `Deleted developer ${d.displayName}`);
                                  await refreshAllData();
                                }}
                                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold cursor-pointer"
                              >
                                <UserMinus className="w-3.5 h-3.5" />
                                {isId ? 'Hapus Developer' : 'Delete Developer'}
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </section>

                  {/* Danger Zone: Delete / Reset Own Owner Account */}
                  <section className="rounded-2xl border-2 border-rose-600/60 p-5 space-y-3" style={{ backgroundColor: 'var(--hv-surface)' }}>
                    <h2 className="text-sm font-extrabold text-rose-500 flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4" />
                      {isId ? 'Zona Berbahaya — Hapus / Reset Akun Owner Sendiri' : 'Danger Zone — Delete / Reset Own Owner Account'}
                    </h2>
                    <p className="opacity-80">
                      {isId
                        ? 'Jika akun Owner dihapus, saat halaman Dev Panel dimuat ulang tidak akan ada Owner terdaftar sehingga Anda dapat mendaftarkan akun Owner baru dari awal.'
                        : 'Deleting the Owner account resets Dev Panel ownership so reloading allows registering a fresh Single Owner account.'}
                    </p>
                    {!showOwnerResetBox ? (
                      <button
                        type="button"
                        onClick={() => setShowOwnerResetBox(true)}
                        className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-extrabold cursor-pointer"
                      >
                        {isId ? 'Hapus / Reset Akun Owner' : 'Delete / Reset Owner Account'}
                      </button>
                    ) : (
                      <div className="space-y-2 max-w-md">
                        <input
                          value={ownerResetConfirm}
                          onChange={(e) => setOwnerResetConfirm(e.target.value)}
                          placeholder='Ketik "DELETE OWNER" untuk konfirmasi'
                          className="w-full rounded-lg border border-rose-500 px-3 py-2 bg-transparent font-mono"
                        />
                        <div className="flex gap-2">
                          <button
                            type="button"
                            disabled={ownerResetConfirm.trim().toUpperCase() !== 'DELETE OWNER'}
                            onClick={async () => {
                              try {
                                await authFetch('/api/dev/team/owner', {
                                  method: 'DELETE',
                                  body: JSON.stringify({ confirmText: ownerResetConfirm }),
                                });
                                notify('ok', isId ? 'Akun Owner direset. Silakan daftar Owner baru.' : 'Owner account reset.');
                                setOwnerResetConfirm('');
                                setShowOwnerResetBox(false);
                                await handleSignOut();
                              } catch (err) {
                                notify('err', err instanceof Error ? err.message : 'Reset failed');
                              }
                            }}
                            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-extrabold cursor-pointer disabled:opacity-40"
                          >
                            {isId ? 'Konfirmasi Hapus Owner' : 'Confirm Delete Owner'}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setShowOwnerResetBox(false);
                              setOwnerResetConfirm('');
                            }}
                            className="px-3 py-2 rounded-xl border font-bold cursor-pointer"
                            style={{ borderColor: 'var(--hv-border)' }}
                          >
                            {isId ? 'Batal' : 'Cancel'}
                          </button>
                        </div>
                      </div>
                    )}
                  </section>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 14: SEARCHABLE AUDIT LOG                                 */}
              {/* ============================================================ */}
              {activeTab === 'audit' && (
                <div className="space-y-4 text-xs">
                  <div className="flex flex-wrap gap-2">
                    <select value={auditCategory} onChange={(e) => setAuditCategory(e.target.value)} className="rounded-lg border px-2.5 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }}>
                      <option value="all" className="text-slate-900">All Categories</option>
                      <option value="auth" className="text-slate-900">Auth / Team</option>
                      <option value="world" className="text-slate-900">World</option>
                      <option value="economy" className="text-slate-900">Economy</option>
                      <option value="ban" className="text-slate-900">Moderation</option>
                      <option value="system" className="text-slate-900">System / Files / Backups</option>
                    </select>
                    <input value={auditQuery} onChange={(e) => setAuditQuery(e.target.value)} placeholder="Search audit logs..." className="rounded-lg border px-3 py-2 bg-transparent" style={{ borderColor: 'var(--hv-border)' }} />
                    <button type="button" onClick={() => void refreshAllData()} className="px-3 py-2 rounded-lg bg-amber-600 text-white font-bold cursor-pointer">Search</button>
                  </div>
                  <div className="rounded-2xl border divide-y" style={{ backgroundColor: 'var(--hv-surface)', borderColor: 'var(--hv-border)' }}>
                    {auditLogs.length === 0 ? (
                      <div className="p-4 opacity-65">No audit entries yet.</div>
                    ) : (
                      auditLogs.map((a) => (
                        <div key={a.id} className="p-3 flex flex-wrap justify-between gap-2">
                          <div>
                            <span className="font-extrabold text-amber-500">[{a.category}]</span>{' '}
                            <span className="font-bold">{a.actor}</span> · {a.action} — {a.summary}
                          </div>
                          <span className="opacity-60">{new Date(a.timestamp).toLocaleString()}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
};
