HARVEST IN THE GREAT VALLEY — CLEAN DEV PANEL WORKSPACE
=======================================================
Folder ini adalah workspace independen untuk Developer Panel (/dev-panel).
Seluruh file ter-generate otomatis untuk Dev Panel disimpan terpisah di:
  - web_game\data\data_dev_panel\dev_panel_secrets\  (Akun Owner Tunggal & Daftar Developer — RAHASIA)
  - web_game\data\data_dev_panel\backup\             (Backup default & manual dengan timestamp)
  - web_game\data\data_dev_panel\dev_editor\         (Data editor, akun, dan konfigurasi koneksi)

Aturan Akses:
1. Saat Dev Panel dibuka pertama kali, semua menu terkunci hingga akun Owner didaftarkan via Login Sosial.
2. Hanya ada 1 akun Owner. Owner dapat menambah/mencabut sesi/menghapus akun Developer berdasarkan ID Game.
3. Ketika akun Owner atau Developer login ke game dari perangkat mana pun, akses Dev Panel otomatis terbuka.
