import dotenv from 'dotenv';
import express from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: process.env.GAME_ENV_FILE || path.resolve(__dirname, '..', '..', 'tools', 'runtime', 'config', 'game.env') });
const ROOT_DIR = path.resolve(__dirname, '..', '..', 'harvest_in_the_great_valley');
const WEB_GAME_DIR = path.resolve(ROOT_DIR, '..');
const DATA_DIR = path.resolve(process.env.DEV_PANEL_DATA_DIR || path.join(WEB_GAME_DIR, 'data', 'data_dev_panel', 'dev_editor')); 
const BACKUPS_DIR = path.join(DATA_DIR, 'backups');
const DEV_ACCOUNT_FILE = path.join(DATA_DIR, '.dev-account-fingerprint.json');
const SERVER_CONN_FILE = path.join(DATA_DIR, 'server-connection.json');

// All generated editor state is stored outside source under data/data_dev_panel/dev_editor.
fs.mkdirSync(DATA_DIR, { recursive: true });

const FILE_WORLD_CONFIG = path.join(ROOT_DIR, 'src', 'game', 'data', 'worldConfig.ts');
const FILE_RUNTIME_CONFIG = path.join(ROOT_DIR, 'src', 'game', 'data', 'gameRuntimeConfig.ts');
const FILE_ITEMS_CROPS = path.join(ROOT_DIR, 'src', 'game', 'data', 'itemsAndCrops.ts');
const FILE_NPCS = path.join(ROOT_DIR, 'src', 'game', 'data', 'npcs.ts');
const FILE_HAIRSTYLES = path.join(ROOT_DIR, 'src', 'game', 'data', 'hairstyles.ts');
const FILE_NPC_DIALOGUES = path.join(ROOT_DIR, 'src', 'game', 'data', 'npcDialogueDb.ts');
const FILE_REGISTRATION_NAMES = path.join(ROOT_DIR, 'src', 'game', 'data', 'registrationNames.ts');

const EDITOR_PORT = Number(process.env.DEV_EDITOR_PORT || 3099);
const EDITOR_BIND_HOST = (process.env.DEV_EDITOR_HOST || '0.0.0.0').trim();
const DEFAULT_GAME_SERVER_PORT = Number(process.env.GAME_SERVER_PORT || 3000);
const ADMIN_MONITOR_TOKEN = (process.env.ADMIN_MONITOR_TOKEN || '').trim();
const SESSION_SECRET = (process.env.DEV_EDITOR_SESSION_SECRET || '').trim() || crypto.randomBytes(32).toString('hex');
const TOKEN_TTL_MS = 24 * 60 * 60 * 1000;

interface ServerConnectionConfig {
  mode: 'auto' | 'manual';
  hostOrIp: string;
  port: number;
  customUrl: string;
}

function loadServerConnectionConfig(): ServerConnectionConfig {
  try {
    if (fs.existsSync(SERVER_CONN_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(SERVER_CONN_FILE, 'utf8')) as Partial<ServerConnectionConfig>;
      return {
        mode: parsed.mode === 'manual' ? 'manual' : 'auto',
        hostOrIp: String(parsed.hostOrIp || '127.0.0.1').trim() || '127.0.0.1',
        port: Number.isFinite(Number(parsed.port)) ? Math.max(1, Math.min(65535, Number(parsed.port))) : DEFAULT_GAME_SERVER_PORT,
        customUrl: String(parsed.customUrl || '').trim(),
      };
    }
  } catch {
    // ignore corrupt config
  }
  return {
    mode: 'auto',
    hostOrIp: '127.0.0.1',
    port: DEFAULT_GAME_SERVER_PORT,
    customUrl: '',
  };
}

let serverConnectionConfig: ServerConnectionConfig = loadServerConnectionConfig();

function saveServerConnectionConfig(cfg: ServerConnectionConfig) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(SERVER_CONN_FILE, JSON.stringify(cfg, null, 2), 'utf8');
}

function detectNetworkIps(): {
  preferredIp: string;
  ips: Array<{ iface: string; address: string; url: string; internal: boolean }>;
} {
  const ips: Array<{ iface: string; address: string; url: string; internal: boolean }> = [];
  try {
    const nets = os.networkInterfaces();
    for (const [iface, entries] of Object.entries(nets)) {
      if (!entries) continue;
      for (const entry of entries) {
        if (entry.family === 'IPv4') {
          ips.push({
            iface,
            address: entry.address,
            url: `http://${entry.address}:${serverConnectionConfig.port}`,
            internal: entry.internal,
          });
        }
      }
    }
  } catch {
    // ignore network interface errors
  }
  const external = ips.find((x) => !x.internal);
  const preferredIp = external?.address || '127.0.0.1';
  if (!ips.some((x) => x.address === '127.0.0.1')) {
    ips.push({ iface: 'loopback', address: '127.0.0.1', url: `http://127.0.0.1:${serverConnectionConfig.port}`, internal: true });
  }
  return { preferredIp, ips };
}

function getGameServerUrl(): string {
  if (serverConnectionConfig.mode === 'manual') {
    if (serverConnectionConfig.customUrl) {
      return sanitizeHttpUrl(serverConnectionConfig.customUrl, `http://127.0.0.1:${DEFAULT_GAME_SERVER_PORT}`);
    }
    const cleanHost = serverConnectionConfig.hostOrIp.replace(/^https?:\/\//i, '').replace(/\/.*$/, '').trim() || '127.0.0.1';
    return `http://${cleanHost}:${serverConnectionConfig.port}`;
  }
  if (process.env.GAME_SERVER_URL) {
    return sanitizeHttpUrl(process.env.GAME_SERVER_URL, `http://127.0.0.1:${DEFAULT_GAME_SERVER_PORT}`);
  }
  return `http://127.0.0.1:${serverConnectionConfig.port}`;
}

interface DevAccountRecord {
  emailHash: string;
  emailMasked: string;
  displayName: string;
  farmName: string;
  salt: string;
  passwordHash: string;
  createdAt: string;
}

function sha256Hex(value: string): string {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function maskEmail(email: string): string {
  const [user = '', domain = ''] = email.split('@');
  if (!domain) return '***';
  const visible = user.slice(0, Math.min(2, user.length));
  return `${visible}***@${domain}`;
}

function timingSafeHexEqual(aHex: string, bHex: string): boolean {
  if (!aHex || !bHex || aHex.length !== bHex.length) return false;
  try {
    return crypto.timingSafeEqual(Buffer.from(aHex, 'hex'), Buffer.from(bHex, 'hex'));
  } catch {
    return false;
  }
}

function hashDevPassword(password: string, saltHex: string): string {
  return crypto.scryptSync(password, saltHex, 64).toString('hex');
}

function readDevAccount(): DevAccountRecord | null {
  try {
    if (!fs.existsSync(DEV_ACCOUNT_FILE)) return null;
    const raw = JSON.parse(fs.readFileSync(DEV_ACCOUNT_FILE, 'utf8')) as Partial<DevAccountRecord>;
    if (!raw.emailHash || !raw.salt || !raw.passwordHash) return null;
    return {
      emailHash: String(raw.emailHash),
      emailMasked: String(raw.emailMasked || '***'),
      displayName: String(raw.displayName || 'Valley Developer'),
      farmName: String(raw.farmName || 'Developer Homestead'),
      salt: String(raw.salt),
      passwordHash: String(raw.passwordHash),
      createdAt: String(raw.createdAt || new Date().toISOString()),
    };
  } catch {
    return null;
  }
}

function writeDevAccount(rec: DevAccountRecord): void {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(DEV_ACCOUNT_FILE, JSON.stringify(rec, null, 2), { encoding: 'utf8', mode: 0o600 });
}

function signDevToken(account: DevAccountRecord): { token: string; expiresAt: number } {
  const expiresAt = Date.now() + TOKEN_TTL_MS;
  const payload = Buffer.from(
    JSON.stringify({ emailHash: account.emailHash, displayName: account.displayName, exp: expiresAt })
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  return { token: `${payload}.${sig}`, expiresAt };
}

function verifyDevToken(token: string): { emailHash: string; displayName: string; exp: number } | null {
  if (!token || !token.includes('.')) return null;
  const [payload, sig] = token.split('.');
  if (!payload || !sig) return null;
  const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expectedSig);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as {
      emailHash?: string;
      displayName?: string;
      exp?: number;
    };
    if (!parsed.emailHash || typeof parsed.exp !== 'number' || parsed.exp <= Date.now()) return null;
    const stored = readDevAccount();
    if (!stored || !timingSafeHexEqual(parsed.emailHash, stored.emailHash)) return null;
    return { emailHash: parsed.emailHash, displayName: String(parsed.displayName || stored.displayName), exp: parsed.exp };
  } catch {
    return null;
  }
}

function sanitizeHttpUrl(raw: string, fallback: string): string {
  const trimmed = String(raw || '').trim();
  if (!trimmed) return fallback;
  try {
    const u = new URL(trimmed);
    if (u.protocol === 'http:' || u.protocol === 'https:') {
      return u.toString().replace(/\/+$/, '');
    }
  } catch {
    // invalid URL
  }
  return fallback;
}

const ALLOWED_WEATHERS = new Set(['Sunny', 'Rainy', 'Cloudy', 'Snowy', 'Stormy']);
const ALLOWED_THEMES = new Set(['farmhouse', 'system', 'light', 'dark']);
const ALLOWED_SHAPES = new Set(['root', 'bush', 'tall', 'vine', 'flower', 'crystal']);
const ALLOWED_SEASONS = new Set(['Spring', 'Summer', 'Autumn', 'Winter']);
const ALLOWED_TREE_MODELS = new Set(['oak', 'pine', 'birch']);
const ALLOWED_IDLE_POSES = new Set([
  'relaxed',
  'confident',
  'thoughtful',
  'cheerful',
  'energetic',
  'scholar',
  'wave',
  'stretch',
  'ponder',
  'chat',
  'yawn',
  'look_around',
  'sit',
  'whistle',
]);
const ALLOWED_SHIRT_STYLES = new Set([
  'none', 'tunic', 'overalls', 'vest', 'sweater',
  'hoodie', 'flannel', 'jacket', 'apron', 'kimono', 'polo',
]);
const ALLOWED_PANTS_STYLES = new Set([
  'none', 'trousers', 'shorts', 'skirt', 'denim',
  'cargos', 'capri', 'pleated_skirt', 'leggings', 'boots_pants',
]);
const ALLOWED_HAT_STYLES = new Set([
  'none', 'farmer_cap', 'straw_hat', 'flower_clip', 'wizard_hat',
  'cowboy_hat', 'beanie', 'beret', 'crown', 'chef_hat', 'sun_visor',
]);
const ALLOWED_ACCESSORIES = new Set(['none', 'bandana', 'glasses', 'scarf', 'bowtie', 'sunglasses']);
const ALLOWED_MUSIC_MOODS = new Set(['Spring', 'Summer', 'Autumn', 'Winter', 'title', 'festival', 'indoor']);
const ALLOWED_MUSIC_PRESETS = new Set(['btn_pastoral', 'btn_lively', 'btn_cozy']);
const ALLOWED_AUDIO_EXTS = new Set(['.mp3', '.ogg', '.wav', '.m4a', '.webm']);
const ROOT_REAL = fs.realpathSync(ROOT_DIR);

const BLOCKED_SEGMENTS = new Set([
  '.git',
  'node_modules',
  'secrets',
  '.dev-account-fingerprint.json',
]);

const PROTECTED_TOP_DIRS = new Set(['src', 'dev-editor', 'public']);
const PROTECTED_TOP_FILES = new Set(['package.json', 'server.ts', 'index.html', 'vite.config.ts']);

const TEXT_FILE_EXTS = new Set([
  '.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.json', '.html', '.css', '.scss',
  '.md', '.txt', '.yml', '.yaml', '.xml', '.svg', '.ps1', '.sh', '.rules', '.toml',
  '.gitignore', '.example', '.sql', '.csv',
]);

function isBlockedSegment(seg: string): boolean {
  const lower = seg.toLowerCase();
  if (BLOCKED_SEGMENTS.has(seg) || BLOCKED_SEGMENTS.has(lower)) return true;
  if (lower === '.env' || lower.startsWith('.env.')) {
    // Allow .env.example (public template), block all real .env files
    if (lower !== '.env.example') return true;
  }
  if (lower === 'firebase-admin.json' || lower.endsWith('.pem') || lower.endsWith('.key')) return true;
  return false;
}

function isTextEditableName(name: string): boolean {
  const ext = path.extname(name).toLowerCase();
  if (TEXT_FILE_EXTS.has(ext)) return true;
  if (name === '.env.example' || name === '.gitignore' || name === 'Dockerfile') return true;
  return false;
}

function resolveSafeProjectPath(
  rawRel: string,
  opts: { allowRoot?: boolean } = {}
): { absPath: string; relPath: string } {
  const normalized = String(rawRel || '')
    .replace(/\\/g, '/')
    .replace(/^\/+/, '')
    .replace(/\/+$/, '');
  if (normalized.includes('\0')) {
    throw new Error('Invalid null byte in path.');
  }
  const segments = normalized ? normalized.split('/').filter(Boolean) : [];
  for (const seg of segments) {
    if (seg === '.' || seg === '..') {
      throw new Error('Path traversal is forbidden.');
    }
    if (isBlockedSegment(seg)) {
      throw new Error(`Access to protected path "${seg}" is restricted.`);
    }
  }
  const cleanRel = segments.join('/');
  const absPath = cleanRel ? path.resolve(ROOT_DIR, cleanRel) : ROOT_DIR;
  if (absPath !== ROOT_DIR && !absPath.startsWith(ROOT_DIR + path.sep)) {
    throw new Error('Path escapes project root.');
  }
  if (!opts.allowRoot && absPath === ROOT_DIR) {
    throw new Error('Operation not permitted on root directory.');
  }

  // Symlink containment check: verify existing target or nearest existing ancestor stays inside ROOT_REAL
  let probe = absPath;
  while (!fs.existsSync(probe)) {
    const parent = path.dirname(probe);
    if (parent === probe) break;
    probe = parent;
  }
  if (fs.existsSync(probe)) {
    const realProbe = fs.realpathSync(probe);
    if (realProbe !== ROOT_REAL && !realProbe.startsWith(ROOT_REAL + path.sep)) {
      throw new Error('Symlink points outside project root.');
    }
  }
  return { absPath, relPath: cleanRel };
}

function loadHairStylesCatalog(): {
  styles: Array<{ value: string; en: string; gender: string }>;
  colors: Array<{ hex: string; en: string }>;
  validIds: Set<string>;
} {
  const styles: Array<{ value: string; en: string; gender: string }> = [];
  const colors: Array<{ hex: string; en: string }> = [];
  const validIds = new Set<string>(['none', 'short', 'long', 'bob', 'ponytail', 'buns', 'spiky']);
  try {
    const src = fs.readFileSync(FILE_HAIRSTYLES, 'utf8');
    const styleRegex = /\{\s*value:\s*'([^']+)',\s*en:\s*'([^']+)',\s*id:\s*'[^']+',\s*gender:\s*'([^']+)'/g;
    let m: RegExpExecArray | null;
    while ((m = styleRegex.exec(src)) !== null) {
      styles.push({ value: m[1], en: m[2], gender: m[3] });
      validIds.add(m[1]);
    }
    const colorRegex = /\{\s*hex:\s*'([^']+)',\s*en:\s*'([^']+)',\s*id:\s*'[^']+'\s*\}/g;
    while ((m = colorRegex.exec(src)) !== null) {
      colors.push({ hex: m[1], en: m[2] });
    }
  } catch {
    // fallback defaults
  }
  return { styles, colors, validIds };
}

function ensureBackupsDir() {
  if (!fs.existsSync(BACKUPS_DIR)) {
    fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  }
}

function escapeTsString(value: string): string {
  return value.replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\r?\n/g, ' ').trim();
}

function slugifyId(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 32);
}

function sanitizeHex(hex: string, fallback: string): string {
  return /^#[0-9a-fA-F]{6}$/.test(hex) ? hex.toLowerCase() : fallback;
}

function formatBackupTimestamp(date = new Date()): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}_${pad(date.getHours())}-${pad(date.getMinutes())}-${pad(date.getSeconds())}`;
}

function adminHeaders(): Record<string, string> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (ADMIN_MONITOR_TOKEN) {
    headers['x-admin-token'] = ADMIN_MONITOR_TOKEN;
  }
  return headers;
}

function parseRuntimeConfig() {
  const src = fs.readFileSync(FILE_RUNTIME_CONFIG, 'utf8');
  const debugMode = /export const DEVELOPER_DEBUG_MODE\s*=\s*true/.test(src);
  const normalStarterGold = Number(src.match(/export const NORMAL_STARTER_GOLD\s*=\s*(\d+)/)?.[1] ?? 500);
  const normalStarterDiamond = Number(src.match(/export const NORMAL_STARTER_DIAMOND\s*=\s*(\d+)/)?.[1] ?? 0);
  const googlePlayBilling = /googlePlayBilling:\s*true/.test(src);
  const duitku = /duitku:\s*true/.test(src);
  const defaultGlobalTheme = src.match(/export const DEFAULT_GLOBAL_THEME:\s*ThemeMode\s*=\s*'([^']+)'/)?.[1] || 'farmhouse';
  const weatherOverrideEnabled = /overrideEnabled:\s*true/.test(src);

  const weightsBlock = src.match(/weights:\s*\{([\s\S]*?)\}/)?.[1] || '';
  const weatherWeights = {
    Sunny: Number(weightsBlock.match(/Sunny:\s*(\d+)/)?.[1] ?? 45),
    Rainy: Number(weightsBlock.match(/Rainy:\s*(\d+)/)?.[1] ?? 25),
    Cloudy: Number(weightsBlock.match(/Cloudy:\s*(\d+)/)?.[1] ?? 15),
    Snowy: Number(weightsBlock.match(/Snowy:\s*(\d+)/)?.[1] ?? 10),
    Stormy: Number(weightsBlock.match(/Stormy:\s*(\d+)/)?.[1] ?? 5),
  };

  const ecoBlock = src.match(/export const GLOBAL_TREE_ECOSYSTEM:\s*GlobalTreeEcosystemConfig\s*=\s*\{([\s\S]*?)\n\};/)?.[1] || '';
  const globalTreeEcosystem = {
    minTrees: Number(ecoBlock.match(/minTrees:\s*(\d+)/)?.[1] ?? 200),
    maxTrees: Number(ecoBlock.match(/maxTrees:\s*(\d+)/)?.[1] ?? 500),
    growthIntervalSec: Number(ecoBlock.match(/growthIntervalSec:\s*(\d+)/)?.[1] ?? 18),
    growthBatchMin: Number(ecoBlock.match(/growthBatchMin:\s*(\d+)/)?.[1] ?? 2),
    growthBatchMax: Number(ecoBlock.match(/growthBatchMax:\s*(\d+)/)?.[1] ?? 9),
    carpenterCutIntervalSec: Number(ecoBlock.match(/carpenterCutIntervalSec:\s*(\d+)/)?.[1] ?? 22),
    carpenterCutBatchMin: Number(ecoBlock.match(/carpenterCutBatchMin:\s*(\d+)/)?.[1] ?? 1),
    carpenterCutBatchMax: Number(ecoBlock.match(/carpenterCutBatchMax:\s*(\d+)/)?.[1] ?? 8),
  };

  const bridgeBlock = src.match(/export const DEV_PORTAL_BRIDGE:\s*DevPortalBridgeConfig\s*=\s*\{([\s\S]*?)\n\};/)?.[1] || '';
  const devPortalBridge = {
    enabled: /enabled:\s*true/.test(bridgeBlock),
    authorizedEmailHash: bridgeBlock.match(/authorizedEmailHash:\s*'([^']*)'/)?.[1] || '',
    dashboardUrl: bridgeBlock.match(/dashboardUrl:\s*'([^']*)'/)?.[1] || '',
  };

  const musicBlock = src.match(/export const MUSIC_CONFIG:\s*MusicConfig\s*=\s*\{([\s\S]*?)\n\};/)?.[1] || '';
  const musicMode = /mode:\s*'custom'/.test(musicBlock) ? 'custom' : 'procedural';
  const musicPresetRaw = musicBlock.match(/preset:\s*'([^']+)'/)?.[1] || 'btn_pastoral';
  const musicPreset = ALLOWED_MUSIC_PRESETS.has(musicPresetRaw) ? musicPresetRaw : 'btn_pastoral';
  const tempoScaleRaw = Number(musicBlock.match(/tempoScale:\s*([0-9.]+)/)?.[1] ?? 1.0);
  const tempoScale = Number.isFinite(tempoScaleRaw) ? Math.max(0.7, Math.min(1.4, tempoScaleRaw)) : 1.0;
  const customTracks: Record<string, string> = {};
  const customTracksBlock = musicBlock.match(/customTracks:\s*\{([\s\S]*?)\}/)?.[1] || '';
  const trackRegex = /([a-zA-Z0-9_]+):\s*'([^']*)'/g;
  let tm: RegExpExecArray | null;
  while ((tm = trackRegex.exec(customTracksBlock)) !== null) {
    if (ALLOWED_MUSIC_MOODS.has(tm[1]) && tm[2]) {
      customTracks[tm[1]] = tm[2];
    }
  }
  const musicConfig = {
    mode: musicMode,
    preset: musicPreset,
    tempoScale,
    customTracks,
  };

  const tradeRates: Record<string, number> = {};
  const ratesBlock = src.match(/export const ITEM_TRADE_RATES:\s*Record<string,\s*number>\s*=\s*\{([\s\S]*?)\n\};/)?.[1] || '';
  const rateRegex = /^\s{2}([a-zA-Z0-9_]+):\s*(\d+),?/gm;
  let m: RegExpExecArray | null;
  while ((m = rateRegex.exec(ratesBlock)) !== null) {
    tradeRates[m[1]] = Number(m[2]);
  }

  const announceBlock = src.match(/export const ANNOUNCEMENT_BANNER_CONFIG:\s*AnnouncementBannerConfig\s*=\s*\{([\s\S]*?)\n\};/)?.[1] || '';
  const announcementBanner = {
    enabled: /enabled:\s*true/.test(announceBlock),
    title: announceBlock.match(/title:\s*'([^']*)'/)?.[1] || 'Valley Announcement',
    message: announceBlock.match(/message:\s*'([^']*)'/)?.[1] || '',
    durationSec: Number(announceBlock.match(/durationSec:\s*(\d+)/)?.[1] ?? 10),
  };

  const fishBlock = src.match(/export const FISHING_CONFIG:\s*FishingConfig\s*=\s*\{([\s\S]*?)\n\};/)?.[1] || '';
  const fishingConfig = {
    luckMin: Number(fishBlock.match(/luckMin:\s*(\d+)/)?.[1] ?? 0),
    luckMax: Number(fishBlock.match(/luckMax:\s*(\d+)/)?.[1] ?? 100),
    waitMinSec: Number(fishBlock.match(/waitMinSec:\s*(\d+)/)?.[1] ?? 1),
    waitMaxSec: Number(fishBlock.match(/waitMaxSec:\s*(\d+)/)?.[1] ?? 300),
    strikesRequired: Number(fishBlock.match(/strikesRequired:\s*(\d+)/)?.[1] ?? 3),
    greenZoneWidthPct: Number(fishBlock.match(/greenZoneWidthPct:\s*(\d+)/)?.[1] ?? 22),
  };

  const caveBlock = src.match(/export const CAVE_MINING_CONFIG:\s*CaveMiningConfig\s*=\s*\{([\s\S]*?)\n\};/)?.[1] || '';
  const caveMiningConfig = {
    baseDropMinPct: Number(caveBlock.match(/baseDropMinPct:\s*(\d+)/)?.[1] ?? 5),
    baseDropMaxPct: Number(caveBlock.match(/baseDropMaxPct:\s*(\d+)/)?.[1] ?? 30),
    baseRarityPct: Number(caveBlock.match(/baseRarityPct:\s*(\d+)/)?.[1] ?? 5),
    levelDropStepPct: Number(caveBlock.match(/levelDropStepPct:\s*(\d+)/)?.[1] ?? 3),
    levelRarityStepPct: Number(caveBlock.match(/levelRarityStepPct:\s*(\d+)/)?.[1] ?? 3),
    maxLevel: Number(caveBlock.match(/maxLevel:\s*(\d+)/)?.[1] ?? 20),
  };

  const vcBlock = src.match(/export const VIDEO_CALL_CONFIG:\s*VideoCallConfig\s*=\s*\{([\s\S]*?)\n\};/)?.[1] || '';
  const videoCallConfig = {
    width: Number(vcBlock.match(/width:\s*(\d+)/)?.[1] ?? 320),
    height: Number(vcBlock.match(/height:\s*(\d+)/)?.[1] ?? 240),
    fps: Number(vcBlock.match(/fps:\s*(\d+)/)?.[1] ?? 30),
    bitrateKbps: Number(vcBlock.match(/bitrateKbps:\s*(\d+)/)?.[1] ?? 130),
    showSelfPreviewByDefault: /showSelfPreviewByDefault:\s*true/.test(vcBlock),
  };

  const camBlock = src.match(/export const CAMERA_CONFIG:\s*CameraConfig\s*=\s*\{([\s\S]*?)\n\};/)?.[1] || '';
  const cameraConfig = {
    defaultDistance: Number(camBlock.match(/defaultDistance:\s*([0-9.]+)/)?.[1] ?? 7.2),
    minZoom: Number(camBlock.match(/minZoom:\s*([0-9.]+)/)?.[1] ?? 4.5),
    maxZoom: Number(camBlock.match(/maxZoom:\s*([0-9.]+)/)?.[1] ?? 18),
    povMode: camBlock.match(/povMode:\s*'([^']+)'/)?.[1] === 'free' ? 'free' : 'lock',
    fov: Number(camBlock.match(/fov:\s*(\d+)/)?.[1] ?? 44),
    defaultPitch: Number(camBlock.match(/defaultPitch:\s*([0-9.]+)/)?.[1] ?? 0.44),
  };

  const mobBlock = src.match(/export const MOBILE_CONTROLS_CONFIG:\s*MobileControlsConfig\s*=\s*\{([\s\S]*?)\n\};/)?.[1] || '';
  const mobileControlsConfig = {
    joystickBottomPx: Number(mobBlock.match(/joystickBottomPx:\s*(\d+)/)?.[1] ?? 28),
    joystickLeftPx: Number(mobBlock.match(/joystickLeftPx:\s*(\d+)/)?.[1] ?? 26),
    joystickSizePx: Number(mobBlock.match(/joystickSizePx:\s*(\d+)/)?.[1] ?? 120),
    actionBottomPx: Number(mobBlock.match(/actionBottomPx:\s*(\d+)/)?.[1] ?? 28),
    actionRightPx: Number(mobBlock.match(/actionRightPx:\s*(\d+)/)?.[1] ?? 26),
    buttonScale: Number(mobBlock.match(/buttonScale:\s*([0-9.]+)/)?.[1] ?? 1.0),
    showTopRightSwitchOnly: !/showTopRightSwitchOnly:\s*false/.test(mobBlock),
  };

  const econBlock = src.match(/export const MARKET_ECONOMY_CONFIG:\s*MarketEconomyConfig\s*=\s*\{([\s\S]*?)\n\};/)?.[1] || '';
  const marketEconomyConfig = {
    minMultiplier: Number(econBlock.match(/minMultiplier:\s*([0-9.]+)/)?.[1] ?? 1.0),
    maxMultiplier: Number(econBlock.match(/maxMultiplier:\s*([0-9.]+)/)?.[1] ?? 2.6),
    goldDemandFactor: Number(econBlock.match(/goldDemandFactor:\s*([0-9.]+)/)?.[1] ?? 1.0),
    diamondFloorMultiplier: Number(econBlock.match(/diamondFloorMultiplier:\s*([0-9.]+)/)?.[1] ?? 1.0),
  };

  const perfBlock = src.match(/export const PERFORMANCE_CONFIG:\s*PerformanceConfig\s*=\s*\{([\s\S]*?)\n\};/)?.[1] || '';
  const performanceConfig = {
    enableLod: !/enableLod:\s*false/.test(perfBlock),
    enableOcclusionCulling: !/enableOcclusionCulling:\s*false/.test(perfBlock),
    lowPower4GbMode: !/lowPower4GbMode:\s*false/.test(perfBlock),
    maxDprLowPower: Number(perfBlock.match(/maxDprLowPower:\s*([0-9.]+)/)?.[1] ?? 1.25),
    maxAnisotropy: Number(perfBlock.match(/maxAnisotropy:\s*(\d+)/)?.[1] ?? 4),
    lod0Distance: Number(perfBlock.match(/lod0Distance:\s*(\d+)/)?.[1] ?? 22),
    lod1Distance: Number(perfBlock.match(/lod1Distance:\s*(\d+)/)?.[1] ?? 48),
  };

  return {
    debugMode,
    normalStarterGold,
    normalStarterDiamond,
    paymentMethods: { googlePlayBilling, duitku },
    defaultGlobalTheme,
    globalTreeEcosystem,
    devPortalBridge,
    musicConfig,
    announcementBanner,
    fishingConfig,
    caveMiningConfig,
    videoCallConfig,
    cameraConfig,
    mobileControlsConfig,
    marketEconomyConfig,
    performanceConfig,
    weatherControl: {
      overrideEnabled: weatherOverrideEnabled,
      weights: weatherWeights,
    },
    itemTradeRates: tradeRates,
  };
}

function parseWorldConfig() {
  const src = fs.readFileSync(FILE_WORLD_CONFIG, 'utf8');
  const weatherMatch = src.match(/export const DEFAULT_WEATHER:\s*Weather\s*=\s*'([^']+)'/);
  const goldMatch = src.match(/export const STARTER_GOLD\s*=\s*(\d+)/);
  const diamondMatch = src.match(/export const STARTER_DIAMOND\s*=\s*(\d+)/);

  const trees: Array<{ id: string; name: string; treeModel: string; foliageHex: string; scaleMin: number; scaleMax: number }> = [];
  const treeArrayMatch = src.match(/export const TREE_SPECIES:\s*TreeSpeciesDef\[\]\s*=\s*\[([\s\S]*?)\];/);
  if (treeArrayMatch) {
    const entryRegex = /\{\s*id:\s*'([^']+)',\s*name:\s*'([^']+)',(?:\s*treeModel:\s*'([^']+)',)?\s*foliageHex:\s*'([^']+)',\s*scaleMin:\s*([0-9.]+),\s*scaleMax:\s*([0-9.]+)\s*\}/g;
    let m: RegExpExecArray | null;
    while ((m = entryRegex.exec(treeArrayMatch[1])) !== null) {
      trees.push({
        id: m[1],
        name: m[2],
        treeModel: m[3] || 'oak',
        foliageHex: m[4],
        scaleMin: Number(m[5]),
        scaleMax: Number(m[6]),
      });
    }
  }

  const animBlock = src.match(/export const CHARACTER_ANIM_CONFIG:\s*CharacterAnimConfig\s*=\s*\{([\s\S]*?)\n\};/)?.[1] || '';
  const characterAnim = {
    playerWalkSpeed: Number(animBlock.match(/playerWalkSpeed:\s*([0-9.]+)/)?.[1] ?? 6.2),
    playerRunSpeed: Number(animBlock.match(/playerRunSpeed:\s*([0-9.]+)/)?.[1] ?? 10.6),
    playerDefaultIdlePose: animBlock.match(/playerDefaultIdlePose:\s*'([^']+)'/)?.[1] || 'relaxed',
    npcIdleSpeed: Number(animBlock.match(/npcIdleSpeed:\s*([0-9.]+)/)?.[1] ?? 1.0),
    defaultPlayerPreset: {
      gender: animBlock.match(/gender:\s*'([^']+)'/)?.[1] || 'male',
      skinColor: animBlock.match(/skinColor:\s*'([^']+)'/)?.[1] || '#fcd5b5',
      eyeColor: animBlock.match(/eyeColor:\s*'([^']+)'/)?.[1] || '#292524',
      hairStyle: animBlock.match(/hairStyle:\s*'([^']+)'/)?.[1] || 'none',
      hairColor: animBlock.match(/hairColor:\s*'([^']+)'/)?.[1] || '#6b3e1b',
      shirtStyle: animBlock.match(/shirtStyle:\s*'([^']+)'/)?.[1] || 'none',
      outfitColor: animBlock.match(/outfitColor:\s*'([^']+)'/)?.[1] || '#3a6b2c',
      pantsStyle: animBlock.match(/pantsStyle:\s*'([^']+)'/)?.[1] || 'none',
      pantsColor: animBlock.match(/pantsColor:\s*'([^']+)'/)?.[1] || '#1e3a8a',
      hatStyle: animBlock.match(/hatStyle:\s*'([^']+)'/)?.[1] || 'none',
      accessory: animBlock.match(/accessory:\s*'([^']+)'/)?.[1] || 'none',
    },
  };

  return {
    defaultWeather: weatherMatch ? weatherMatch[1] : 'Sunny',
    starterGold: goldMatch ? Number(goldMatch[1]) : 99999,
    starterDiamond: diamondMatch ? Number(diamondMatch[1]) : 99999,
    trees,
    characterAnim,
  };
}

function parseNpcs() {
  const src = fs.readFileSync(FILE_NPCS, 'utf8');
  const npcs: Array<{
    id: string;
    name: string;
    gender: string;
    age: number;
    profession: string;
    giftPrefs: {
      loved: string[];
      liked: string[];
      disliked: string[];
      hated: string[];
    };
    appearance: {
      skinColor: string;
      hairColor: string;
      hairStyle: string;
      shirtStyle: string;
      outfitColor: string;
      pantsStyle: string;
      pantsColor: string;
      hatStyle: string;
      accessory: string;
      scale: number;
      idlePose: string;
    };
  }> = [];

  const parseArray = (block: string, field: string): string[] => {
    const raw = block.match(new RegExp(`${field}:\\s*\\[([^\\]]*)\\]`))?.[1] || '';
    return raw
      .split(',')
      .map((s) => s.replace(/['"\s]/g, ''))
      .filter(Boolean);
  };

  const npcRegex =
    /id:\s*'([^']+)',\s*\n\s*name:\s*'([^']+)',\s*\n\s*gender:\s*'([^']+)',\s*\n\s*age:\s*(\d+),[\s\S]*?profession:\s*'([^']+)',[\s\S]*?appearance:\s*\{([^\n]+)\},\s*\n\s*giftPrefs:\s*\{([\s\S]*?)\n\s{4}\},/g;
  let m: RegExpExecArray | null;
  while ((m = npcRegex.exec(src)) !== null) {
    const app = m[6];
    const prefs = m[7];
    npcs.push({
      id: m[1],
      name: m[2],
      gender: m[3],
      age: Number(m[4] || 25),
      profession: m[5],
      giftPrefs: {
        loved: parseArray(prefs, 'loved'),
        liked: parseArray(prefs, 'liked'),
        disliked: parseArray(prefs, 'disliked'),
        hated: parseArray(prefs, 'hated'),
      },
      appearance: {
        skinColor: app.match(/skinColor:\s*'([^']+)'/)?.[1] || '#fcd5b5',
        hairColor: app.match(/hairColor:\s*'([^']+)'/)?.[1] || '#6b3e1b',
        hairStyle: app.match(/hairStyle:\s*'([^']+)'/)?.[1] || 'short',
        shirtStyle: app.match(/shirtStyle:\s*'([^']+)'/)?.[1] || 'tunic',
        outfitColor: app.match(/outfitColor:\s*'([^']+)'/)?.[1] || '#3a6b2c',
        pantsStyle: app.match(/pantsStyle:\s*'([^']+)'/)?.[1] || 'trousers',
        pantsColor: app.match(/pantsColor:\s*'([^']+)'/)?.[1] || '#1e3a8a',
        hatStyle: app.match(/hatStyle:\s*'([^']+)'/)?.[1] || 'none',
        accessory: app.match(/accessory:\s*'([^']+)'/)?.[1] || 'none',
        scale: Number(app.match(/scale:\s*([0-9.]+)/)?.[1] ?? 1.0),
        idlePose: app.match(/idlePose:\s*'([^']+)'/)?.[1] || 'relaxed',
      },
    });
  }
  return npcs;
}

function parseItemsAndCrops() {
  const src = fs.readFileSync(FILE_ITEMS_CROPS, 'utf8');
  const itemsBlockMatch = src.match(/export const ITEMS:\s*Record<string,\s*ItemDef>\s*=\s*\{([\s\S]*?)\n\};/);
  const cropsBlockMatch = src.match(/export const CROPS:\s*Record<string,\s*CropDef>\s*=\s*\{([\s\S]*?)\n\};/);

  const items: Array<{
    id: string;
    name: string;
    category: string;
    buyPrice: number;
    sellPrice: number;
    diamondPrice?: number;
    iconEmoji: string;
  }> = [];

  if (itemsBlockMatch) {
    const itemBlockRegex = /^\s{2}([a-zA-Z0-9_]+):\s*\{([\s\S]*?)^\s{2}\},/gm;
    let m: RegExpExecArray | null;
    while ((m = itemBlockRegex.exec(itemsBlockMatch[1])) !== null) {
      const id = m[1];
      const body = m[2];
      const name = body.match(/name:\s*'([^']*)'/)?.[1] || id;
      const category = body.match(/category:\s*'([^']*)'/)?.[1] || 'Other';
      const buyPrice = Number(body.match(/buyPrice:\s*(\d+)/)?.[1] ?? 0);
      const sellPrice = Number(body.match(/sellPrice:\s*(\d+)/)?.[1] ?? 0);
      const dpMatch = body.match(/diamondPrice:\s*(\d+)/);
      const iconEmoji = body.match(/iconEmoji:\s*'([^']*)'/)?.[1] || '📦';
      items.push({
        id,
        name,
        category,
        buyPrice,
        sellPrice,
        diamondPrice: dpMatch ? Number(dpMatch[1]) : undefined,
        iconEmoji,
      });
    }
  }

  const crops: Array<{
    id: string;
    name: string;
    seedId: string;
    seasons: string[];
    daysToGrow: number;
    sellPrice: number;
    color: string;
    shape: string;
  }> = [];

  if (cropsBlockMatch) {
    const cropBlockRegex = /^\s{2}([a-zA-Z0-9_]+):\s*\{([\s\S]*?)^\s{2}\},/gm;
    let m: RegExpExecArray | null;
    while ((m = cropBlockRegex.exec(cropsBlockMatch[1])) !== null) {
      const id = m[1];
      const body = m[2];
      const name = body.match(/name:\s*'([^']*)'/)?.[1] || id;
      const seedId = body.match(/seedId:\s*'([^']*)'/)?.[1] || '';
      const seasonsRaw = body.match(/seasons:\s*\[([^\]]*)\]/)?.[1] || '';
      const seasons = seasonsRaw
        .split(',')
        .map((s) => s.replace(/['"\s]/g, ''))
        .filter(Boolean);
      const daysToGrow = Number(body.match(/daysToGrow:\s*(\d+)/)?.[1] ?? 7);
      const sellPrice = Number(body.match(/sellPrice:\s*(\d+)/)?.[1] ?? 100);
      const color = body.match(/color:\s*'([^']*)'/)?.[1] || '#4ade80';
      const shape = body.match(/shape:\s*'([^']*)'/)?.[1] || 'bush';
      crops.push({ id, name, seedId, seasons, daysToGrow, sellPrice, color, shape });
    }
  }

  return { items, crops };
}

// Optional Firestore Admin helper (strictly isolated inside dev-editor)
let firestoreAdminDb: {
  collection: (name: string) => {
    get: () => Promise<{ docs: Array<{ id: string; data: () => Record<string, unknown> }> }>;
    doc: (id: string) => {
      set: (data: Record<string, unknown>, opts: { merge: boolean }) => Promise<unknown>;
      delete?: () => Promise<unknown>;
    };
  };
} | null = null;

async function initOptionalFirestoreAdmin() {
  try {
    const keyPath = path.join(ROOT_DIR, 'secrets', 'firebase-admin.json');
    if (!fs.existsSync(keyPath)) return;
    const raw = JSON.parse(fs.readFileSync(keyPath, 'utf8'));
    const adminMod = await import('firebase-admin');
    const admin = adminMod.default || adminMod;
    if (!admin.apps.length) {
      admin.initializeApp({ credential: admin.credential.cert(raw) });
    }
    firestoreAdminDb = admin.firestore() as unknown as typeof firestoreAdminDb;
  } catch {
    firestoreAdminDb = null;
  }
}

void initOptionalFirestoreAdmin();

const app = express();
app.use(express.json({ limit: '35mb' }));

// Security headers & strict origin handling (never wildcard '*' on authenticated endpoints)
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'no-referrer');
  const origin = req.headers.origin;
  const host = req.headers.host;
  if (origin && host) {
    try {
      const parsed = new URL(origin);
      const allowedExtra = (process.env.DEV_EDITOR_ALLOWED_ORIGINS || '')
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
      const isSameHost = parsed.host === host;
      if (isSameHost || allowedExtra.includes(origin)) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Vary', 'Origin');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
      }
    } catch {
      // ignore invalid origin header
    }
  }
  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }
  next();
});

function writeDevPortalBridgeBlock(enabled: boolean, authorizedEmailHash: string, dashboardUrl: string) {
  let rtSrc = fs.readFileSync(FILE_RUNTIME_CONFIG, 'utf8');
  const regex = /export const DEV_PORTAL_BRIDGE:\s*DevPortalBridgeConfig\s*=\s*\{[\s\S]*?\n\};/;
  if (!regex.test(rtSrc)) {
    throw new Error('DEV_PORTAL_BRIDGE block not found in gameRuntimeConfig.ts');
  }
  const replacement = enabled
    ? `export const DEV_PORTAL_BRIDGE: DevPortalBridgeConfig = {\n  enabled: true,\n  authorizedEmailHash: '${escapeTsString(authorizedEmailHash)}',\n  dashboardUrl: '${escapeTsString(dashboardUrl)}',\n};`
    : `export const DEV_PORTAL_BRIDGE: DevPortalBridgeConfig = {\n  enabled: false,\n  authorizedEmailHash: '',\n  dashboardUrl: '',\n};`;
  rtSrc = rtSrc.replace(regex, replacement);
  fs.writeFileSync(FILE_RUNTIME_CONFIG, rtSrc, 'utf8');
}

async function syncDevPlayerToGameServer(email: string, displayName: string, farmName: string): Promise<boolean> {
  try {
    const resp = await fetch(`${getGameServerUrl()}/api/admin/register-dev-player`, {
      method: 'POST',
      headers: adminHeaders(),
      body: JSON.stringify({ email, displayName, farmName }),
      signal: AbortSignal.timeout(2500),
    });
    return resp.ok;
  } catch {
    return false;
  }
}

async function pushLiveRuntimeConfigToGameServer(payload: Record<string, unknown>): Promise<{ liveSynced: boolean; liveClientsNotified: number }> {
  try {
    const resp = await fetch(`${getGameServerUrl()}/api/admin/runtime-config`, {
      method: 'POST',
      headers: adminHeaders(),
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(2500),
    });
    if (resp.ok) {
      const data = (await resp.json()) as { liveClientsNotified?: number };
      return { liveSynced: true, liveClientsNotified: Number(data.liveClientsNotified || 0) };
    }
  } catch {
    // game server offline
  }
  return { liveSynced: false, liveClientsNotified: 0 };
}

// Serve standalone Developer Dashboard GUI
app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// === PUBLIC AUTH ENDPOINTS (First-Run Developer Setup & Sign-In) ===
app.get('/api/auth/status', (_req, res) => {
  try {
    const acc = readDevAccount();
    const rt = parseRuntimeConfig();
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ok: true,
      configured: Boolean(acc),
      emailMasked: acc?.emailMasked || '',
      displayName: acc?.displayName || '',
      farmName: acc?.farmName || '',
      bridge: rt.devPortalBridge,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to inspect auth status' });
  }
});

app.post('/api/auth/setup', async (req, res) => {
  try {
    if (readDevAccount()) {
      res.status(409).json({ ok: false, error: 'Developer account is already configured. Please sign in.' });
      return;
    }
    const body = req.body as {
      email?: string;
      displayName?: string;
      farmName?: string;
      password?: string;
      enableBridge?: boolean;
      dashboardUrl?: string;
    };
    const email = String(body.email || '').trim().toLowerCase();
    const displayName = String(body.displayName || '').trim().slice(0, 32);
    const farmName = String(body.farmName || 'Developer Homestead').trim().slice(0, 40) || 'Developer Homestead';
    const password = String(body.password || '');

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      res.status(400).json({ ok: false, error: 'Please provide a valid developer email address.' });
      return;
    }
    if (displayName.length < 2) {
      res.status(400).json({ ok: false, error: 'Developer display name must be at least 2 characters.' });
      return;
    }
    if (password.length < 8) {
      res.status(400).json({ ok: false, error: 'Password must be at least 8 characters long.' });
      return;
    }

    const salt = crypto.randomBytes(16).toString('hex');
    const passwordHash = hashDevPassword(password, salt);
    const emailHash = sha256Hex(email);
    const record: DevAccountRecord = {
      emailHash,
      emailMasked: maskEmail(email),
      displayName,
      farmName,
      salt,
      passwordHash,
      createdAt: new Date().toISOString(),
    };
    writeDevAccount(record);

    const playerSynced = await syncDevPlayerToGameServer(email, displayName, farmName);
    if (body.enableBridge) {
      const hostUrl = sanitizeHttpUrl(
        body.dashboardUrl || `${req.protocol}://${req.get('host') || `127.0.0.1:${EDITOR_PORT}`}`,
        `http://127.0.0.1:${EDITOR_PORT}`
      );
      writeDevPortalBridgeBlock(true, emailHash, hostUrl);
    }

    const { token, expiresAt } = signDevToken(record);
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ok: true,
      token,
      expiresAt,
      playerSynced,
      account: {
        displayName: record.displayName,
        farmName: record.farmName,
        emailMasked: record.emailMasked,
        emailHash: record.emailHash,
      },
      message: playerSynced
        ? 'Developer account created & registered as a player on the game server!'
        : 'Developer account created locally (game server offline; player sync will retry on next login).',
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Developer setup failed' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const stored = readDevAccount();
    if (!stored) {
      res.status(400).json({ ok: false, error: 'No developer account exists yet. Complete first-run setup first.' });
      return;
    }
    const body = req.body as { email?: string; password?: string };
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    const emailHash = sha256Hex(email);
    const computedPassHash = hashDevPassword(password, stored.salt);
    const validEmail = timingSafeHexEqual(emailHash, stored.emailHash);
    const validPass = timingSafeHexEqual(computedPassHash, stored.passwordHash);
    if (!validEmail || !validPass) {
      res.status(401).json({ ok: false, error: 'Invalid developer email or password.' });
      return;
    }

    // Best-effort ensure developer player snapshot exists on game server
    void syncDevPlayerToGameServer(email, stored.displayName, stored.farmName);

    const { token, expiresAt } = signDevToken(stored);
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ok: true,
      token,
      expiresAt,
      account: {
        displayName: stored.displayName,
        farmName: stored.farmName,
        emailMasked: stored.emailMasked,
        emailHash: stored.emailHash,
      },
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Sign-in failed' });
  }
});

// Protect ALL /api/editor/* and /api/dashboard/* routes with Bearer Token auth
const requireDevAuth: express.RequestHandler = (req, res, next) => {
  const authHeader = String(req.headers.authorization || '');
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
  const verified = verifyDevToken(token);
  if (!verified) {
    res.status(401).json({ ok: false, error: 'Developer authentication required. Please sign in.' });
    return;
  }
  res.setHeader('Cache-Control', 'no-store');
  next();
};

app.use('/api/editor', requireDevAuth);
app.use('/api/dashboard', requireDevAuth);
app.use('/api/explorer', requireDevAuth);

// Read full editable game state + runtime config + hair catalog
app.get('/api/editor/state', async (_req, res) => {
  try {
    const world = parseWorldConfig();
    const runtimeConfig = parseRuntimeConfig();
    const { items, crops } = parseItemsAndCrops();
    const npcs = parseNpcs();
    const hairCatalog = loadHairStylesCatalog();

    let gameServerOnline = false;
    let gameServerMonitorAvailable = false;
    let gameServerHealth: Record<string, unknown> | null = null;
    let monitorData: Record<string, unknown> | null = null;

    // The public health endpoint is the source of truth for server availability.
    // Admin monitor authorization is checked separately so a token/permission
    // issue cannot incorrectly label a healthy game server as OFFLINE.
    const serverUrl = getGameServerUrl();
    const detectedNet = detectNetworkIps();
    try {
      const healthResp = await fetch(`${serverUrl}/api/health`, {
        signal: AbortSignal.timeout(3000),
      });
      if (healthResp.ok) {
        gameServerHealth = (await healthResp.json()) as Record<string, unknown>;
        gameServerOnline = true;
      }
    } catch {
      gameServerOnline = false;
    }

    if (gameServerOnline) {
      try {
        const monitorResp = await fetch(`${serverUrl}/api/admin/monitor`, {
          headers: adminHeaders(),
          signal: AbortSignal.timeout(3000),
        });
        if (monitorResp.ok) {
          monitorData = (await monitorResp.json()) as Record<string, unknown>;
          gameServerMonitorAvailable = true;
        }
      } catch {
        // Keep gameServerOnline true: the public health check already passed.
      }
    }

    const firestorePlayers: Array<{ uid: string; avatarName: string; farmName: string; gold: number; diamond: number }> = [];
    if (firestoreAdminDb) {
      try {
        const snap = await firestoreAdminDb.collection('profiles').get();
        for (const doc of snap.docs) {
          const d = doc.data();
          firestorePlayers.push({
            uid: doc.id,
            avatarName: String(d.avatarName || 'Farmer'),
            farmName: String(d.farmName || 'Great Valley Farm'),
            gold: Number(d.gold || 0),
            diamond: Number(d.diamond || 0),
          });
        }
      } catch {
        // Firestore optional
      }
    }

    res.json({
      ok: true,
      gameServerOnline,
      gameServerMonitorAvailable,
      gameServerHealth,
      serverConnection: {
        currentUrl: serverUrl,
        config: serverConnectionConfig,
        preferredIp: detectedNet.preferredIp,
        detectedIps: detectedNet.ips,
      },
      firestoreConnected: Boolean(firestoreAdminDb),
      world,
      runtimeConfig,
      items,
      crops,
      npcs,
      hairStyles: hairCatalog.styles,
      hairColors: hairCatalog.colors,
      monitor: monitorData,
      firestorePlayers,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to read game files' });
  }
});

// Auto-Detect LAN IPv4 / Configure Manual Game Server IP & Probe Health
app.get('/api/dashboard/server-connection', async (_req, res) => {
  const currentUrl = getGameServerUrl();
  const detectedNet = detectNetworkIps();
  let connected = false;
  let health: Record<string, unknown> | null = null;
  try {
    const r = await fetch(`${currentUrl}/api/health`, { signal: AbortSignal.timeout(2200) });
    if (r.ok) {
      connected = true;
      health = (await r.json()) as Record<string, unknown>;
    }
  } catch {
    connected = false;
  }
  res.json({
    ok: true,
    connected,
    currentUrl,
    config: serverConnectionConfig,
    preferredIp: detectedNet.preferredIp,
    detectedIps: detectedNet.ips,
    health,
  });
});

app.post('/api/dashboard/server-connection', async (req, res) => {
  try {
    const body = req.body as Partial<ServerConnectionConfig>;
    const mode = body.mode === 'manual' ? 'manual' : 'auto';
    const port = Number.isFinite(Number(body.port))
      ? Math.max(1, Math.min(65535, Math.floor(Number(body.port))))
      : serverConnectionConfig.port;
    const hostOrIp = String(body.hostOrIp ?? serverConnectionConfig.hostOrIp).trim() || '127.0.0.1';
    const customUrl = body.customUrl !== undefined ? String(body.customUrl || '').trim() : serverConnectionConfig.customUrl;

    serverConnectionConfig = { mode, hostOrIp, port, customUrl };
    saveServerConnectionConfig(serverConnectionConfig);

    const currentUrl = getGameServerUrl();
    const detectedNet = detectNetworkIps();
    let connected = false;
    let health: Record<string, unknown> | null = null;
    try {
      const r = await fetch(`${currentUrl}/api/health`, { signal: AbortSignal.timeout(2500) });
      if (r.ok) {
        connected = true;
        health = (await r.json()) as Record<string, unknown>;
      }
    } catch {
      connected = false;
    }

    res.json({
      ok: true,
      connected,
      currentUrl,
      config: serverConnectionConfig,
      preferredIp: detectedNet.preferredIp,
      detectedIps: detectedNet.ips,
      health,
      message: connected
        ? `Connected to Game Server at ${currentUrl}!`
        : `Saved ${currentUrl}, but health check did not respond yet.`,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Server connection update failed' });
  }
});

// Live Control Room Monitor proxy (decrypted global/private chats, active voice/video calls, live players, P2P market, transactions)
app.get('/api/dashboard/monitor', async (_req, res) => {
  try {
    const serverUrl = getGameServerUrl();
    const resp = await fetch(`${serverUrl}/api/admin/monitor`, {
      headers: adminHeaders(),
      signal: AbortSignal.timeout(2500),
    });
    if (!resp.ok) {
      res.status(resp.status).json({ ok: false, error: `Game server monitor returned HTTP ${resp.status}` });
      return;
    }
    const data = await resp.json();
    res.json({ ok: true, ...data });
  } catch (err) {
    res.status(502).json({
      ok: false,
      error: err instanceof Error ? `Game server offline: ${err.message}` : 'Game server unreachable',
    });
  }
});

// Delete Registered Player Account (Server Registry + Active Sessions + Optional Firestore)
app.delete('/api/dashboard/users/:uid', async (req, res) => {
  try {
    const uid = String(req.params.uid || '').trim();
    if (!uid || !/^[a-zA-Z0-9_.:-]{3,128}$/.test(uid)) {
      res.status(400).json({ ok: false, error: 'Invalid player UID.' });
      return;
    }
    const resp = await fetch(`${getGameServerUrl()}/api/admin/users/${encodeURIComponent(uid)}`, {
      method: 'DELETE',
      headers: adminHeaders(),
      signal: AbortSignal.timeout(3000),
    });
    const data = await resp.json().catch(() => ({}));
    if (firestoreAdminDb) {
      try {
        await firestoreAdminDb.collection('profiles').doc(uid).delete?.();
      } catch {
        // Non-fatal if Firestore doc/DB is absent
      }
    }
    if (!resp.ok) {
      res.status(resp.status).json({ ok: false, error: (data as { error?: string }).error || `HTTP ${resp.status}` });
      return;
    }
    res.json({ ok: true, deletedUid: uid, message: `Deleted user "${uid}" cleanly.` });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to delete user' });
  }
});

// Live Per-User Override (Gold, Diamonds, Independent Theme, Level, Joy/Fun, Animal Happiness, Seasonal Sales Stats)
app.post('/api/dashboard/player-override', async (req, res) => {
  try {
    const { uid, gold, diamond, theme, fun, level, animalHappiness, salesStats } = req.body as {
      uid?: string;
      gold?: number;
      diamond?: number;
      theme?: string;
      fun?: number;
      level?: number;
      animalHappiness?: Record<string, number>;
      salesStats?: Record<string, unknown>;
    };
    if (!uid || typeof uid !== 'string' || !/^[a-zA-Z0-9_-]{3,128}$/.test(uid)) {
      res.status(400).json({ ok: false, error: 'You must select a specific valid player UID first.' });
      return;
    }

    const payload: Record<string, unknown> = { targetUid: uid };
    if (typeof gold === 'number' && Number.isFinite(gold)) {
      payload.gold = Math.max(0, Math.min(999_999_999, Math.floor(gold)));
    }
    if (typeof diamond === 'number' && Number.isFinite(diamond)) {
      payload.diamond = Math.max(0, Math.min(999_999_999, Math.floor(diamond)));
    }
    if (typeof theme === 'string' && ALLOWED_THEMES.has(theme)) {
      payload.theme = theme;
    }
    if (typeof fun === 'number' && Number.isFinite(fun)) {
      payload.fun = Math.max(0, Math.min(100, Math.floor(fun)));
    }
    if (typeof level === 'number' && Number.isFinite(level)) {
      payload.level = Math.max(1, Math.min(999, Math.floor(level)));
    }
    if (animalHappiness && typeof animalHappiness === 'object' && !Array.isArray(animalHappiness)) {
      const cleanHap: Record<string, number> = {};
      for (const [k, v] of Object.entries(animalHappiness)) {
        const num = Number(v);
        if (Number.isFinite(num)) {
          cleanHap[String(k).slice(0, 48)] = Math.max(0, Math.min(100, Math.floor(num)));
        }
      }
      payload.animalHappiness = cleanHap;
    }
    if (salesStats && typeof salesStats === 'object' && !Array.isArray(salesStats)) {
      payload.salesStats = salesStats;
    }

    let serverMessage = '';
    try {
      const resp = await fetch(`${getGameServerUrl()}/api/admin/player-override`, {
        method: 'POST',
        headers: adminHeaders(),
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(2500),
      });
      if (resp.ok) {
        serverMessage = 'Synced live to game server & connected player.';
      } else {
        const errBody = await resp.json().catch(() => ({}));
        serverMessage = `Game server returned HTTP ${resp.status}: ${(errBody as { error?: string }).error || 'override failed'}.`;
      }
    } catch {
      serverMessage = 'Game server offline (live push skipped).';
    }

    if (firestoreAdminDb && (payload.gold !== undefined || payload.diamond !== undefined)) {
      try {
        const updateDoc: Record<string, unknown> = { updatedAt: new Date().toISOString() };
        if (payload.gold !== undefined) updateDoc.gold = payload.gold;
        if (payload.diamond !== undefined) updateDoc.diamond = payload.diamond;
        await firestoreAdminDb.collection('profiles').doc(uid).set(updateDoc, { merge: true });
      } catch (fsErr) {
        // Non-fatal: avoids gRPC "5 NOT_FOUND" failing Gold/Diamond injection when Firestore doc/DB is absent
        console.warn('[dev-editor] Optional Firestore profile sync skipped:', fsErr instanceof Error ? fsErr.message : fsErr);
      }
    }

    res.json({
      ok: true,
      message: `Per-user update applied to ${uid}! ${serverMessage}`,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Player override failed' });
  }
});

// Toggle Zero-Coupling Auto-Open Developer Portal Bridge in gameRuntimeConfig.ts
app.post('/api/dashboard/dev-bridge', (req, res) => {
  try {
    const account = readDevAccount();
    if (!account) {
      res.status(400).json({ ok: false, error: 'Developer account is not configured.' });
      return;
    }
    const body = req.body as { enabled?: boolean; dashboardUrl?: string };
    const enabled = Boolean(body.enabled);
    const defaultUrl = `${req.protocol}://${req.get('host') || `127.0.0.1:${EDITOR_PORT}`}`;
    const safeUrl = sanitizeHttpUrl(body.dashboardUrl || defaultUrl, `http://127.0.0.1:${EDITOR_PORT}`);

    writeDevPortalBridgeBlock(enabled, account.emailHash, safeUrl);
    res.json({
      ok: true,
      bridge: enabled
        ? { enabled: true, authorizedEmailHash: account.emailHash, dashboardUrl: safeUrl }
        : { enabled: false, authorizedEmailHash: '', dashboardUrl: '' },
      message: enabled
        ? `Auto-Open Portal Bridge ENABLED for your developer account (${account.emailMasked}) -> ${safeUrl}`
        : 'Auto-Open Portal Bridge DISABLED & scrubbed cleanly from gameRuntimeConfig.ts (ready for clean release!).',
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to update portal bridge' });
  }
});

// Control Global Protected Tree Ecosystem (Inject gameRuntimeConfig.ts + Live push to Game Server)
app.post('/api/dashboard/tree-ecosystem', async (req, res) => {
  try {
    const body = req.body as {
      action?: 'config' | 'sprout' | 'carpenter_cut';
      amount?: number;
      config?: {
        minTrees?: number;
        maxTrees?: number;
        growthIntervalSec?: number;
        growthBatchMin?: number;
        growthBatchMax?: number;
        carpenterCutIntervalSec?: number;
        carpenterCutBatchMin?: number;
        carpenterCutBatchMax?: number;
      };
    };

    const action = body.action === 'sprout' || body.action === 'carpenter_cut' ? body.action : 'config';
    let cleanConfig: {
      minTrees: number;
      maxTrees: number;
      growthIntervalSec: number;
      growthBatchMin: number;
      growthBatchMax: number;
      carpenterCutIntervalSec: number;
      carpenterCutBatchMin: number;
      carpenterCutBatchMax: number;
    } | undefined;

    if (body.config && typeof body.config === 'object') {
      const prev = parseRuntimeConfig().globalTreeEcosystem;
      const minTrees = Math.max(50, Math.min(600, Math.floor(Number(body.config.minTrees ?? prev.minTrees))));
      const maxTrees = Math.max(minTrees + 20, Math.min(750, Math.floor(Number(body.config.maxTrees ?? prev.maxTrees))));
      const growthIntervalSec = Math.max(5, Math.min(600, Math.floor(Number(body.config.growthIntervalSec ?? prev.growthIntervalSec))));
      const growthBatchMin = Math.max(1, Math.min(50, Math.floor(Number(body.config.growthBatchMin ?? prev.growthBatchMin))));
      const growthBatchMax = Math.max(growthBatchMin, Math.min(80, Math.floor(Number(body.config.growthBatchMax ?? prev.growthBatchMax))));
      const carpenterCutIntervalSec = Math.max(5, Math.min(600, Math.floor(Number(body.config.carpenterCutIntervalSec ?? prev.carpenterCutIntervalSec))));
      const carpenterCutBatchMin = Math.max(1, Math.min(50, Math.floor(Number(body.config.carpenterCutBatchMin ?? prev.carpenterCutBatchMin))));
      const carpenterCutBatchMax = Math.max(carpenterCutBatchMin, Math.min(80, Math.floor(Number(body.config.carpenterCutBatchMax ?? prev.carpenterCutBatchMax))));

      cleanConfig = {
        minTrees,
        maxTrees,
        growthIntervalSec,
        growthBatchMin,
        growthBatchMax,
        carpenterCutIntervalSec,
        carpenterCutBatchMin,
        carpenterCutBatchMax,
      };

      let rtSrc = fs.readFileSync(FILE_RUNTIME_CONFIG, 'utf8');
      const regex = /export const GLOBAL_TREE_ECOSYSTEM:\s*GlobalTreeEcosystemConfig\s*=\s*\{[\s\S]*?\n\};/;
      if (regex.test(rtSrc)) {
        rtSrc = rtSrc.replace(
          regex,
          `export const GLOBAL_TREE_ECOSYSTEM: GlobalTreeEcosystemConfig = {\n  minTrees: ${minTrees},\n  maxTrees: ${maxTrees},\n  growthIntervalSec: ${growthIntervalSec},\n  growthBatchMin: ${growthBatchMin},\n  growthBatchMax: ${growthBatchMax},\n  carpenterCutIntervalSec: ${carpenterCutIntervalSec},\n  carpenterCutBatchMin: ${carpenterCutBatchMin},\n  carpenterCutBatchMax: ${carpenterCutBatchMax},\n};`
        );
        fs.writeFileSync(FILE_RUNTIME_CONFIG, rtSrc, 'utf8');
      }
    }

    let liveResp: Record<string, unknown> | null = null;
    try {
      const resp = await fetch(`${getGameServerUrl()}/api/admin/tree-ecosystem`, {
        method: 'POST',
        headers: adminHeaders(),
        body: JSON.stringify({
          action,
          amount: typeof body.amount === 'number' ? Math.max(1, Math.min(80, Math.floor(body.amount))) : 15,
          config: cleanConfig,
        }),
        signal: AbortSignal.timeout(2500),
      });
      if (resp.ok) {
        liveResp = (await resp.json()) as Record<string, unknown>;
      }
    } catch {
      liveResp = null;
    }

    res.json({
      ok: true,
      liveSynced: Boolean(liveResp),
      stats: liveResp?.stats || null,
      config: liveResp?.config || cleanConfig || parseRuntimeConfig().globalTreeEcosystem,
      log: liveResp?.log || [],
      message:
        action === 'sprout'
          ? 'Sprouted new protected trees across global zones!'
          : action === 'carpenter_cut'
            ? 'Carpenter Orin harvested global trees!'
            : 'Saved Global Tree Ecosystem config to gameRuntimeConfig.ts & pushed live!',
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Tree ecosystem update failed' });
  }
});

// Inject Global Runtime Config (Granular per-section or combined; writes source files + pushes live over WebSocket!)
app.post('/api/dashboard/runtime-config', async (req, res) => {
  try {
    const body = req.body as {
      debugMode?: boolean;
      normalStarterGold?: number;
      normalStarterDiamond?: number;
      googlePlayBilling?: boolean;
      duitku?: boolean;
      paymentMethods?: { googlePlayBilling?: boolean; duitku?: boolean };
      defaultGlobalTheme?: string;
      defaultWeather?: string;
      weatherOverrideEnabled?: boolean;
      weatherWeights?: Partial<Record<'Sunny' | 'Rainy' | 'Cloudy' | 'Snowy' | 'Stormy', number>>;
      weatherControl?: {
        overrideEnabled?: boolean;
        weights?: Partial<Record<'Sunny' | 'Rainy' | 'Cloudy' | 'Snowy' | 'Stormy', number>>;
      };
      announcementBanner?: {
        enabled?: boolean;
        title?: string;
        message?: string;
        durationSec?: number;
      };
      triggerAnnouncementNow?: boolean;
      fishingConfig?: {
        luckMin?: number;
        luckMax?: number;
        waitMinSec?: number;
        waitMaxSec?: number;
        strikesRequired?: number;
        greenZoneWidthPct?: number;
      };
      caveMiningConfig?: {
        baseDropMinPct?: number;
        baseDropMaxPct?: number;
        baseRarityPct?: number;
        levelDropStepPct?: number;
        levelRarityStepPct?: number;
        maxLevel?: number;
      };
      videoCallConfig?: {
        width?: number;
        height?: number;
        fps?: number;
        bitrateKbps?: number;
        showSelfPreviewByDefault?: boolean;
      };
      cameraConfig?: {
        defaultDistance?: number;
        minZoom?: number;
        maxZoom?: number;
        povMode?: 'lock' | 'free';
        fov?: number;
        defaultPitch?: number;
      };
      mobileControlsConfig?: {
        joystickBottomPx?: number;
        joystickLeftPx?: number;
        joystickSizePx?: number;
        actionBottomPx?: number;
        actionRightPx?: number;
        buttonScale?: number;
        showTopRightSwitchOnly?: boolean;
      };
      marketEconomyConfig?: {
        minMultiplier?: number;
        maxMultiplier?: number;
        goldDemandFactor?: number;
        diamondFloorMultiplier?: number;
      };
      performanceConfig?: {
        enableLod?: boolean;
        enableOcclusionCulling?: boolean;
        lowPower4GbMode?: boolean;
        maxDprLowPower?: number;
        maxAnisotropy?: number;
        lod0Distance?: number;
        lod1Distance?: number;
      };
    };

    let rtSrc = fs.readFileSync(FILE_RUNTIME_CONFIG, 'utf8');
    const livePayload: Record<string, unknown> = {};

    if (typeof body.debugMode === 'boolean') {
      rtSrc = rtSrc.replace(
        /export const DEVELOPER_DEBUG_MODE\s*=\s*(?:true|false);/,
        `export const DEVELOPER_DEBUG_MODE = ${body.debugMode};`
      );
      livePayload.debugMode = body.debugMode;
    }
    if (typeof body.normalStarterGold === 'number' && Number.isFinite(body.normalStarterGold)) {
      const v = Math.max(0, Math.min(999_999_999, Math.floor(body.normalStarterGold)));
      rtSrc = rtSrc.replace(/export const NORMAL_STARTER_GOLD\s*=\s*\d+;/, `export const NORMAL_STARTER_GOLD = ${v};`);
      livePayload.normalStarterGold = v;
    }
    if (typeof body.normalStarterDiamond === 'number' && Number.isFinite(body.normalStarterDiamond)) {
      const v = Math.max(0, Math.min(999_999_999, Math.floor(body.normalStarterDiamond)));
      rtSrc = rtSrc.replace(/export const NORMAL_STARTER_DIAMOND\s*=\s*\d+;/, `export const NORMAL_STARTER_DIAMOND = ${v};`);
      livePayload.normalStarterDiamond = v;
    }

    const gpBilling = body.paymentMethods?.googlePlayBilling ?? body.googlePlayBilling;
    const duitkuPay = body.paymentMethods?.duitku ?? body.duitku;
    if (typeof gpBilling === 'boolean') {
      rtSrc = rtSrc.replace(/googlePlayBilling:\s*(?:true|false),/, `googlePlayBilling: ${gpBilling},`);
    }
    if (typeof duitkuPay === 'boolean') {
      rtSrc = rtSrc.replace(/duitku:\s*(?:true|false),/, `duitku: ${duitkuPay},`);
    }
    if (typeof gpBilling === 'boolean' || typeof duitkuPay === 'boolean') {
      livePayload.paymentMethods = {
        ...(typeof gpBilling === 'boolean' ? { googlePlayBilling: gpBilling } : {}),
        ...(typeof duitkuPay === 'boolean' ? { duitku: duitkuPay } : {}),
      };
    }

    if (typeof body.defaultGlobalTheme === 'string' && ALLOWED_THEMES.has(body.defaultGlobalTheme)) {
      rtSrc = rtSrc.replace(
        /export const DEFAULT_GLOBAL_THEME:\s*ThemeMode\s*=\s*'[^']+';/,
        `export const DEFAULT_GLOBAL_THEME: ThemeMode = '${body.defaultGlobalTheme}';`
      );
      livePayload.defaultGlobalTheme = body.defaultGlobalTheme;
    }

    const weatherOverride = body.weatherControl?.overrideEnabled ?? body.weatherOverrideEnabled;
    const rawWeights = body.weatherControl?.weights ?? body.weatherWeights;
    if (typeof weatherOverride === 'boolean') {
      rtSrc = rtSrc.replace(
        /overrideEnabled:\s*(?:true|false),/,
        `overrideEnabled: ${weatherOverride},`
      );
    }
    let cleanWeights: Record<string, number> | undefined;
    if (rawWeights && typeof rawWeights === 'object') {
      const clampW = (val: unknown, fb: number) => {
        const n = Number(val);
        return Number.isFinite(n) ? Math.max(0, Math.min(100, Math.round(n))) : fb;
      };
      const sunny = clampW(rawWeights.Sunny, 45);
      const rainy = clampW(rawWeights.Rainy, 25);
      const cloudy = clampW(rawWeights.Cloudy, 15);
      const snowy = clampW(rawWeights.Snowy, 10);
      const stormy = clampW(rawWeights.Stormy, 5);
      cleanWeights = { Sunny: sunny, Rainy: rainy, Cloudy: cloudy, Snowy: snowy, Stormy: stormy };
      rtSrc = rtSrc.replace(
        /weights:\s*\{[\s\S]*?\},/,
        `weights: {\n    Sunny: ${sunny},\n    Rainy: ${rainy},\n    Cloudy: ${cloudy},\n    Snowy: ${snowy},\n    Stormy: ${stormy},\n  },`
      );
    }
    if (typeof weatherOverride === 'boolean' || cleanWeights) {
      livePayload.weatherControl = {
        ...(typeof weatherOverride === 'boolean' ? { overrideEnabled: weatherOverride } : {}),
        ...(cleanWeights ? { weights: cleanWeights } : {}),
      };
    }

    if (body.announcementBanner && typeof body.announcementBanner === 'object') {
      const esc = (s: unknown, fb: string, maxLen: number) =>
        String(s ?? fb)
          .replace(/\\/g, '\\\\')
          .replace(/'/g, "\\'")
          .replace(/\r?\n/g, ' ')
          .trim()
          .slice(0, maxLen);
      const enabled = Boolean(body.announcementBanner.enabled);
      const title = esc(body.announcementBanner.title, 'Valley Update Announcement', 80);
      const message = esc(body.announcementBanner.message, '', 360);
      const durationSec = Math.max(3, Math.min(120, Math.round(Number(body.announcementBanner.durationSec) || 10)));
      rtSrc = rtSrc.replace(
        /export const ANNOUNCEMENT_BANNER_CONFIG:\s*AnnouncementBannerConfig\s*=\s*\{[\s\S]*?\n\};/,
        `export const ANNOUNCEMENT_BANNER_CONFIG: AnnouncementBannerConfig = {\n  enabled: ${enabled},\n  title: '${title}',\n  message: '${message}',\n  durationSec: ${durationSec},\n};`
      );
      livePayload.announcementBanner = {
        enabled,
        title: String(body.announcementBanner.title ?? 'Valley Update Announcement').slice(0, 80),
        message: String(body.announcementBanner.message ?? '').slice(0, 360),
        durationSec,
      };
      if (enabled || body.triggerAnnouncementNow) {
        livePayload.triggerAnnouncementNow = true;
      }
    }

    if (body.fishingConfig && typeof body.fishingConfig === 'object') {
      const f = body.fishingConfig;
      const luckMin = Math.max(0, Math.min(100, Math.round(Number(f.luckMin ?? 0))));
      const luckMax = Math.max(luckMin, Math.min(100, Math.round(Number(f.luckMax ?? 100))));
      const waitMinSec = Math.max(1, Math.min(600, Math.round(Number(f.waitMinSec ?? 1))));
      const waitMaxSec = Math.max(waitMinSec, Math.min(900, Math.round(Number(f.waitMaxSec ?? 300))));
      const strikesRequired = Math.max(1, Math.min(5, Math.round(Number(f.strikesRequired ?? 3))));
      const greenZoneWidthPct = Math.max(10, Math.min(45, Math.round(Number(f.greenZoneWidthPct ?? 22))));
      rtSrc = rtSrc.replace(
        /export const FISHING_CONFIG:\s*FishingConfig\s*=\s*\{[\s\S]*?\n\};/,
        `export const FISHING_CONFIG: FishingConfig = {\n  luckMin: ${luckMin},\n  luckMax: ${luckMax},\n  waitMinSec: ${waitMinSec},\n  waitMaxSec: ${waitMaxSec},\n  strikesRequired: ${strikesRequired},\n  greenZoneWidthPct: ${greenZoneWidthPct},\n};`
      );
      livePayload.fishingConfig = { luckMin, luckMax, waitMinSec, waitMaxSec, strikesRequired, greenZoneWidthPct };
    }

    if (body.caveMiningConfig && typeof body.caveMiningConfig === 'object') {
      const c = body.caveMiningConfig;
      const baseDropMinPct = Math.max(1, Math.min(90, Math.round(Number(c.baseDropMinPct ?? 5))));
      const baseDropMaxPct = Math.max(baseDropMinPct, Math.min(95, Math.round(Number(c.baseDropMaxPct ?? 30))));
      const baseRarityPct = Math.max(1, Math.min(90, Math.round(Number(c.baseRarityPct ?? 5))));
      const levelDropStepPct = Math.max(0, Math.min(25, Math.round(Number(c.levelDropStepPct ?? 3))));
      const levelRarityStepPct = Math.max(0, Math.min(25, Math.round(Number(c.levelRarityStepPct ?? 3))));
      const maxLevel = Math.max(1, Math.min(100, Math.round(Number(c.maxLevel ?? 20))));
      rtSrc = rtSrc.replace(
        /export const CAVE_MINING_CONFIG:\s*CaveMiningConfig\s*=\s*\{[\s\S]*?\n\};/,
        `export const CAVE_MINING_CONFIG: CaveMiningConfig = {\n  baseDropMinPct: ${baseDropMinPct},\n  baseDropMaxPct: ${baseDropMaxPct},\n  baseRarityPct: ${baseRarityPct},\n  levelDropStepPct: ${levelDropStepPct},\n  levelRarityStepPct: ${levelRarityStepPct},\n  maxLevel: ${maxLevel},\n};`
      );
      livePayload.caveMiningConfig = { baseDropMinPct, baseDropMaxPct, baseRarityPct, levelDropStepPct, levelRarityStepPct, maxLevel };
    }

    if (body.videoCallConfig && typeof body.videoCallConfig === 'object') {
      const vc = body.videoCallConfig;
      const width = Math.max(160, Math.min(1280, Math.round(Number(vc.width ?? 320))));
      const height = Math.max(120, Math.min(720, Math.round(Number(vc.height ?? 240))));
      const fps = Math.max(10, Math.min(60, Math.round(Number(vc.fps ?? 30))));
      const bitrateKbps = Math.max(64, Math.min(2500, Math.round(Number(vc.bitrateKbps ?? 130))));
      const showSelfPreviewByDefault = Boolean(vc.showSelfPreviewByDefault);
      rtSrc = rtSrc.replace(
        /export const VIDEO_CALL_CONFIG:\s*VideoCallConfig\s*=\s*\{[\s\S]*?\n\};/,
        `export const VIDEO_CALL_CONFIG: VideoCallConfig = {\n  width: ${width},\n  height: ${height},\n  fps: ${fps},\n  bitrateKbps: ${bitrateKbps},\n  showSelfPreviewByDefault: ${showSelfPreviewByDefault},\n};`
      );
      livePayload.videoCallConfig = { width, height, fps, bitrateKbps, showSelfPreviewByDefault };
    }

    if (body.cameraConfig && typeof body.cameraConfig === 'object') {
      const cc = body.cameraConfig;
      const defaultDistance = Number(Math.max(4.5, Math.min(16, Number(cc.defaultDistance ?? 7.2))).toFixed(2));
      const minZoom = Number(Math.max(3.5, Math.min(10, Number(cc.minZoom ?? 4.5))).toFixed(2));
      const maxZoom = Number(Math.max(8, Math.min(28, Number(cc.maxZoom ?? 18))).toFixed(2));
      const povMode = cc.povMode === 'free' ? 'free' : 'lock';
      const fov = Math.max(32, Math.min(68, Math.round(Number(cc.fov ?? 44))));
      const defaultPitch = Number(Math.max(0.22, Math.min(0.95, Number(cc.defaultPitch ?? 0.44))).toFixed(2));
      rtSrc = rtSrc.replace(
        /export const CAMERA_CONFIG:\s*CameraConfig\s*=\s*\{[\s\S]*?\n\};/,
        `export const CAMERA_CONFIG: CameraConfig = {\n  defaultDistance: ${defaultDistance},\n  minZoom: ${minZoom},\n  maxZoom: ${maxZoom},\n  povMode: '${povMode}',\n  fov: ${fov},\n  defaultPitch: ${defaultPitch},\n};`
      );
      livePayload.cameraConfig = { defaultDistance, minZoom, maxZoom, povMode, fov, defaultPitch };
    }

    if (body.mobileControlsConfig && typeof body.mobileControlsConfig === 'object') {
      const mc = body.mobileControlsConfig;
      const joystickBottomPx = Math.max(8, Math.min(140, Math.round(Number(mc.joystickBottomPx ?? 28))));
      const joystickLeftPx = Math.max(8, Math.min(140, Math.round(Number(mc.joystickLeftPx ?? 26))));
      const joystickSizePx = Math.max(84, Math.min(170, Math.round(Number(mc.joystickSizePx ?? 120))));
      const actionBottomPx = Math.max(8, Math.min(140, Math.round(Number(mc.actionBottomPx ?? 28))));
      const actionRightPx = Math.max(8, Math.min(140, Math.round(Number(mc.actionRightPx ?? 26))));
      const buttonScale = Number(Math.max(0.75, Math.min(1.4, Number(mc.buttonScale ?? 1.0))).toFixed(2));
      const showTopRightSwitchOnly = Boolean(mc.showTopRightSwitchOnly ?? true);
      rtSrc = rtSrc.replace(
        /export const MOBILE_CONTROLS_CONFIG:\s*MobileControlsConfig\s*=\s*\{[\s\S]*?\n\};/,
        `export const MOBILE_CONTROLS_CONFIG: MobileControlsConfig = {\n  joystickBottomPx: ${joystickBottomPx},\n  joystickLeftPx: ${joystickLeftPx},\n  joystickSizePx: ${joystickSizePx},\n  actionBottomPx: ${actionBottomPx},\n  actionRightPx: ${actionRightPx},\n  buttonScale: ${buttonScale},\n  showTopRightSwitchOnly: ${showTopRightSwitchOnly},\n};`
      );
      livePayload.mobileControlsConfig = {
        joystickBottomPx,
        joystickLeftPx,
        joystickSizePx,
        actionBottomPx,
        actionRightPx,
        buttonScale,
        showTopRightSwitchOnly,
      };
    }

    if (body.marketEconomyConfig && typeof body.marketEconomyConfig === 'object') {
      const me = body.marketEconomyConfig;
      const minMultiplier = Number(Math.max(1.0, Math.min(3.0, Number(me.minMultiplier ?? 1.0))).toFixed(2));
      const maxMultiplier = Number(Math.max(minMultiplier, Math.min(5.0, Number(me.maxMultiplier ?? 2.6))).toFixed(2));
      const goldDemandFactor = Number(Math.max(0.2, Math.min(4.0, Number(me.goldDemandFactor ?? 1.0))).toFixed(2));
      const diamondFloorMultiplier = Number(Math.max(1.0, Math.min(3.0, Number(me.diamondFloorMultiplier ?? 1.0))).toFixed(2));
      rtSrc = rtSrc.replace(
        /export const MARKET_ECONOMY_CONFIG:\s*MarketEconomyConfig\s*=\s*\{[\s\S]*?\n\};/,
        `export const MARKET_ECONOMY_CONFIG: MarketEconomyConfig = {\n  minMultiplier: ${minMultiplier},\n  maxMultiplier: ${maxMultiplier},\n  goldDemandFactor: ${goldDemandFactor},\n  diamondFloorMultiplier: ${diamondFloorMultiplier},\n};`
      );
      livePayload.marketEconomyConfig = { minMultiplier, maxMultiplier, goldDemandFactor, diamondFloorMultiplier };
    }

    if (body.performanceConfig && typeof body.performanceConfig === 'object') {
      const pc = body.performanceConfig;
      const enableLod = Boolean(pc.enableLod ?? true);
      const enableOcclusionCulling = Boolean(pc.enableOcclusionCulling ?? true);
      const lowPower4GbMode = Boolean(pc.lowPower4GbMode ?? true);
      const maxDprLowPower = Number(Math.max(0.75, Math.min(2.0, Number(pc.maxDprLowPower ?? 1.25))).toFixed(2));
      const maxAnisotropy = Math.max(1, Math.min(8, Math.round(Number(pc.maxAnisotropy ?? 4))));
      const lod0Distance = Math.max(10, Math.min(45, Math.round(Number(pc.lod0Distance ?? 22))));
      const lod1Distance = Math.max(lod0Distance + 6, Math.min(90, Math.round(Number(pc.lod1Distance ?? 48))));
      rtSrc = rtSrc.replace(
        /export const PERFORMANCE_CONFIG:\s*PerformanceConfig\s*=\s*\{[\s\S]*?\n\};/,
        `export const PERFORMANCE_CONFIG: PerformanceConfig = {\n  enableLod: ${enableLod},\n  enableOcclusionCulling: ${enableOcclusionCulling},\n  lowPower4GbMode: ${lowPower4GbMode},\n  maxDprLowPower: ${maxDprLowPower},\n  maxAnisotropy: ${maxAnisotropy},\n  lod0Distance: ${lod0Distance},\n  lod1Distance: ${lod1Distance},\n};`
      );
      livePayload.performanceConfig = {
        enableLod,
        enableOcclusionCulling,
        lowPower4GbMode,
        maxDprLowPower,
        maxAnisotropy,
        lod0Distance,
        lod1Distance,
      };
    }

    fs.writeFileSync(FILE_RUNTIME_CONFIG, rtSrc, 'utf8');

    if (typeof body.defaultWeather === 'string' && ALLOWED_WEATHERS.has(body.defaultWeather)) {
      let wcSrc = fs.readFileSync(FILE_WORLD_CONFIG, 'utf8');
      wcSrc = wcSrc.replace(
        /export const DEFAULT_WEATHER:\s*Weather\s*=\s*'[^']+';/,
        `export const DEFAULT_WEATHER: Weather = '${body.defaultWeather}';`
      );
      fs.writeFileSync(FILE_WORLD_CONFIG, wcSrc, 'utf8');
      livePayload.defaultWeather = body.defaultWeather;
    }

    const pushRes = await pushLiveRuntimeConfigToGameServer(livePayload);

    res.json({
      ok: true,
      liveSynced: pushRes.liveSynced,
      liveClientsNotified: pushRes.liveClientsNotified,
      message: pushRes.liveSynced
        ? `Injected & synced live to ${pushRes.liveClientsNotified} connected client(s) in real time!`
        : 'Saved to gameRuntimeConfig.ts / worldConfig.ts (game server offline; will apply on next start).',
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Runtime config update failed' });
  }
});

// Inject Per-Item Diamond Trade Eligibility Rates (0..100%) into gameRuntimeConfig.ts + Live Push
app.post('/api/dashboard/trade-rates', async (req, res) => {
  try {
    const rates = (req.body as { rates?: Record<string, number> }).rates;
    if (!rates || typeof rates !== 'object') {
      res.status(400).json({ ok: false, error: 'Trade rates map is required.' });
      return;
    }

    const cleanRates: Record<string, number> = {};
    const lines: string[] = [];
    for (const [itemId, pct] of Object.entries(rates)) {
      if (!/^[a-zA-Z0-9_]+$/.test(itemId)) continue;
      const clamped = Math.max(0, Math.min(100, Math.round(Number(pct) || 0)));
      cleanRates[itemId] = clamped;
      lines.push(`  ${itemId}: ${clamped},`);
    }

    let src = fs.readFileSync(FILE_RUNTIME_CONFIG, 'utf8');
    const regex = /export const ITEM_TRADE_RATES:\s*Record<string,\s*number>\s*=\s*\{[\s\S]*?\n\};/;
    if (!regex.test(src)) {
      res.status(500).json({ ok: false, error: 'ITEM_TRADE_RATES block not found in gameRuntimeConfig.ts.' });
      return;
    }
    src = src.replace(regex, `export const ITEM_TRADE_RATES: Record<string, number> = {\n${lines.join('\n')}\n};`);
    fs.writeFileSync(FILE_RUNTIME_CONFIG, src, 'utf8');

    const pushRes = await pushLiveRuntimeConfigToGameServer({ itemTradeRates: cleanRates });

    res.json({
      ok: true,
      updatedCount: lines.length,
      liveSynced: pushRes.liveSynced,
      message: `Saved & pushed Diamond Trade Eligibility % for ${lines.length} item(s)!`,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Trade rate update failed' });
  }
});

// Inject item buyPrice / sellPrice updates into itemsAndCrops.ts
app.post('/api/editor/prices', (req, res) => {
  try {
    const updates = (req.body as { updates?: Array<{ id: string; buyPrice: number; sellPrice: number }> }).updates;
    if (!Array.isArray(updates) || updates.length === 0) {
      res.status(400).json({ ok: false, error: 'No price updates provided.' });
      return;
    }

    let src = fs.readFileSync(FILE_ITEMS_CROPS, 'utf8');
    let updatedCount = 0;

    for (const u of updates) {
      if (!u.id || !/^[a-zA-Z0-9_]+$/.test(u.id)) continue;
      const buyPrice = Math.max(0, Math.min(999_999_999, Math.floor(Number(u.buyPrice) || 0)));
      const sellPrice = Math.max(0, Math.min(999_999_999, Math.floor(Number(u.sellPrice) || 0)));

      const itemRegex = new RegExp(`(\\n  ${u.id}: \\{[\\s\\S]*?\\n  \\},)`, 'm');
      const match = src.match(itemRegex);
      if (match) {
        let block = match[1];
        block = block.replace(/buyPrice:\s*\d+/, `buyPrice: ${buyPrice}`);
        block = block.replace(/sellPrice:\s*\d+/, `sellPrice: ${sellPrice}`);
        src = src.replace(match[1], block);
        updatedCount += 1;
      }

      if (u.id.startsWith('crop_')) {
        const cropRegex = new RegExp(`(export const CROPS:[\\s\\S]*?\\n  ${u.id}: \\{[\\s\\S]*?sellPrice:\\s*)(\\d+)`, 'm');
        if (cropRegex.test(src)) {
          src = src.replace(cropRegex, `$1${sellPrice}`);
        }
      }
    }

    fs.writeFileSync(FILE_ITEMS_CROPS, src, 'utf8');
    res.json({
      ok: true,
      updatedCount,
      message: `Updated ${updatedCount} item(s) in itemsAndCrops.ts! Reload game browser to apply.`,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Price update failed' });
  }
});

// Inject a brand-new Crop + Seed into itemsAndCrops.ts AND add Seed to Theo's shop in npcs.ts
app.post('/api/editor/add-crop', (req, res) => {
  try {
    const body = req.body as {
      name?: string;
      emoji?: string;
      color?: string;
      seasons?: string[];
      daysToGrow?: number;
      regrows?: boolean;
      shape?: string;
      seedBuyPrice?: number;
      harvestSellPrice?: number;
      staminaRestore?: number;
    };

    const rawName = String(body.name || '').trim();
    if (!rawName || rawName.length < 2) {
      res.status(400).json({ ok: false, error: 'Crop name must be at least 2 characters.' });
      return;
    }

    const slug = slugifyId(rawName);
    if (!slug) {
      res.status(400).json({ ok: false, error: 'Crop name must contain alphanumeric characters.' });
      return;
    }

    const cropId = `crop_${slug}`;
    const seedId = `seed_${slug}`;
    const safeName = escapeTsString(rawName);
    const emoji = escapeTsString(String(body.emoji || '🌱').slice(0, 4)) || '🌱';
    const color = sanitizeHex(String(body.color || '#4ade80'), '#4ade80');
    const shape = ALLOWED_SHAPES.has(String(body.shape)) ? String(body.shape) : 'bush';
    const seasons = (Array.isArray(body.seasons) ? body.seasons : ['Spring']).filter((s) => ALLOWED_SEASONS.has(s));
    if (seasons.length === 0) seasons.push('Spring');
    const daysToGrow = Math.max(1, Math.min(30, Math.floor(Number(body.daysToGrow) || 7)));
    const regrows = Boolean(body.regrows);
    const seedBuyPrice = Math.max(1, Math.min(999_999, Math.floor(Number(body.seedBuyPrice) || 80)));
    const seedSellPrice = Math.max(1, Math.floor(seedBuyPrice / 2));
    const harvestSellPrice = Math.max(1, Math.min(9_999_999, Math.floor(Number(body.harvestSellPrice) || 220)));
    const harvestBuyPrice = Math.max(harvestSellPrice + 10, Math.floor(harvestSellPrice * 1.15));
    const staminaRestore = Math.max(0, Math.min(120, Math.floor(Number(body.staminaRestore) || 18)));

    let itemsSrc = fs.readFileSync(FILE_ITEMS_CROPS, 'utf8');
    if (itemsSrc.includes(`  ${cropId}: {`) || itemsSrc.includes(`  ${seedId}: {`)) {
      res.status(409).json({ ok: false, error: `Crop/Seed ID "${cropId}" already exists!` });
      return;
    }

    const seasonListLiteral = seasons.map((s) => `'${s}'`).join(', ');
    const seedEntry = `  ${seedId}: {
    id: '${seedId}',
    name: '${safeName} Seeds',
    category: 'Seeds',
    description: 'Plant in ${seasons.join('/')}. Ready to harvest in ${daysToGrow} days.',
    buyPrice: ${seedBuyPrice},
    sellPrice: ${seedSellPrice},
    cropId: '${cropId}',
    isGiftable: false,
    iconColor: '${color}',
    iconEmoji: '🌱',
  },
  ${cropId}: {
    id: '${cropId}',
    name: '${safeName}',
    category: 'Crops',
    description: 'Freshly grown ${safeName} cultivated on your Great Valley farm.',
    buyPrice: ${harvestBuyPrice},
    sellPrice: ${harvestSellPrice},
    staminaRestore: ${staminaRestore},
    isGiftable: true,
    isFoodStorable: true,
    iconColor: '${color}',
    iconEmoji: '${emoji}',
  },
};

export const CROPS: Record<string, CropDef> = {`;

    itemsSrc = itemsSrc.replace(/\n\};\n\nexport const CROPS: Record<string, CropDef> = \{/, `\n${seedEntry}`);

    const cropDefEntry = `  ${cropId}: {
    id: '${cropId}',
    name: '${safeName}',
    seedId: '${seedId}',
    harvestItemId: '${cropId}',
    seasons: [${seasonListLiteral}],
    daysToGrow: ${daysToGrow},${regrows ? '\n    regrowsAfterHarvest: true,' : ''}
    sellPrice: ${harvestSellPrice},
    color: '${color}',
    shape: '${shape}',
  },
};

export const INITIAL_INVENTORY = [`;

    itemsSrc = itemsSrc.replace(/\n\};\n\nexport const INITIAL_INVENTORY = \[/, `\n${cropDefEntry}`);
    fs.writeFileSync(FILE_ITEMS_CROPS, itemsSrc, 'utf8');

    let npcsSrc = fs.readFileSync(FILE_NPCS, 'utf8');
    if (npcsSrc.includes("'item_valley_phone'") && !npcsSrc.includes(`'${seedId}'`)) {
      npcsSrc = npcsSrc.replace("'item_valley_phone'", `'${seedId}', 'item_valley_phone'`);
      fs.writeFileSync(FILE_NPCS, npcsSrc, 'utf8');
    }

    res.json({
      ok: true,
      cropId,
      seedId,
      message: `Injected "${safeName}" (${seedId} + ${cropId}) into itemsAndCrops.ts & Theo's Store! Reload game browser to plant it.`,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to inject crop' });
  }
});

// Inject a new Tree Species into TREE_SPECIES in worldConfig.ts
app.post('/api/editor/add-tree', (req, res) => {
  try {
    const body = req.body as { name?: string; treeModel?: string; foliageHex?: string; scaleMin?: number; scaleMax?: number };
    const rawName = String(body.name || '').trim();
    if (!rawName || rawName.length < 2) {
      res.status(400).json({ ok: false, error: 'Tree species name must be at least 2 characters.' });
      return;
    }
    const slug = slugifyId(rawName);
    const id = `tree_${slug}`;
    const safeName = escapeTsString(rawName);
    const treeModel = ALLOWED_TREE_MODELS.has(String(body.treeModel)) ? String(body.treeModel) : 'oak';
    const foliageHex = sanitizeHex(String(body.foliageHex || '#3d8f44'), '#3d8f44');
    const scaleMin = Math.max(0.5, Math.min(2.0, Number(body.scaleMin) || 0.85));
    const scaleMax = Math.max(scaleMin, Math.min(2.5, Number(body.scaleMax) || 1.25));

    let src = fs.readFileSync(FILE_WORLD_CONFIG, 'utf8');
    if (src.includes(`id: '${id}'`)) {
      res.status(409).json({ ok: false, error: `Tree species "${id}" already exists!` });
      return;
    }

    const line = `  { id: '${id}', name: '${safeName}', treeModel: '${treeModel}', foliageHex: '${foliageHex}', scaleMin: ${scaleMin.toFixed(2)}, scaleMax: ${scaleMax.toFixed(2)} },\n];`;
    src = src.replace(/(export const TREE_SPECIES:\s*TreeSpeciesDef\[\]\s*=\s*\[[\s\S]*?)\];/, `$1${line}`);
    fs.writeFileSync(FILE_WORLD_CONFIG, src, 'utf8');

    res.json({
      ok: true,
      id,
      message: `Injected Tree Species "${safeName}" (${treeModel}) into worldConfig.ts! Reload game browser to apply.`,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to inject tree species' });
  }
});

// Inject Full NPC Profile (Name, Age, Favorite/Loved/Liked Items, Appearance, Idle Pose Animation) into src/game/data/npcs.ts
app.post('/api/editor/npc-full', (req, res) => {
  try {
    const hairCatalog = loadHairStylesCatalog();
    const { items } = parseItemsAndCrops();
    const validItemIds = new Set(items.map((i) => i.id));

    const body = req.body as {
      id?: string;
      name?: string;
      age?: number;
      gender?: string;
      loved?: string[];
      liked?: string[];
      skinColor?: string;
      hairColor?: string;
      hairStyle?: string;
      shirtStyle?: string;
      outfitColor?: string;
      pantsStyle?: string;
      pantsColor?: string;
      hatStyle?: string;
      accessory?: string;
      scale?: number;
      idlePose?: string;
    };

    const id = String(body.id || '').trim();
    if (!id || !/^[a-z0-9_]+$/.test(id)) {
      res.status(400).json({ ok: false, error: 'Valid NPC ID is required.' });
      return;
    }

    const safeName = escapeTsString(String(body.name || '').slice(0, 32));
    if (!safeName) {
      res.status(400).json({ ok: false, error: 'NPC name is required.' });
      return;
    }

    const age = Math.max(5, Math.min(120, Math.floor(Number(body.age) || 25)));
    const gender = body.gender === 'female' ? 'female' : 'male';
    const skinColor = sanitizeHex(String(body.skinColor || '#fcd5b5'), '#fcd5b5');
    const hairColor = sanitizeHex(String(body.hairColor || '#6b3e1b'), '#6b3e1b');
    const hairStyle = hairCatalog.validIds.has(String(body.hairStyle)) ? String(body.hairStyle) : 'short';
    const shirtStyle = ALLOWED_SHIRT_STYLES.has(String(body.shirtStyle)) ? String(body.shirtStyle) : 'tunic';
    const outfitColor = sanitizeHex(String(body.outfitColor || '#3a6b2c'), '#3a6b2c');
    const pantsStyle = ALLOWED_PANTS_STYLES.has(String(body.pantsStyle)) ? String(body.pantsStyle) : 'trousers';
    const pantsColor = sanitizeHex(String(body.pantsColor || '#1e3a8a'), '#1e3a8a');
    const hatStyle = ALLOWED_HAT_STYLES.has(String(body.hatStyle)) ? String(body.hatStyle) : 'none';
    const accessory = ALLOWED_ACCESSORIES.has(String(body.accessory)) ? String(body.accessory) : 'none';
    const scale = Math.max(0.75, Math.min(1.25, Number(body.scale) || 1.0));
    const idlePose = ALLOWED_IDLE_POSES.has(String(body.idlePose)) ? String(body.idlePose) : 'relaxed';

    const cleanItems = (arr?: string[]) =>
      Array.from(new Set((Array.isArray(arr) ? arr : []).filter((itemId) => validItemIds.has(itemId))));

    const lovedItems = cleanItems(body.loved);
    const likedItems = cleanItems(body.liked);

    let src = fs.readFileSync(FILE_NPCS, 'utf8');
    const npcBlockRegex = new RegExp(
      `(id:\\s*'${id}',\\s*\\n\\s*name:\\s*')([^']+)('(?:,\\s*\\n\\s*gender:\\s*')([^']+)('(?:,\\s*\\n\\s*age:\\s*)(\\d+))([\\s\\S]*?appearance:\\s*\\{)([^\\n]+)(\\},\\s*\\n\\s*giftPrefs:\\s*\\{[\\s\\S]*?loved:\\s*\\[)([^\\]]*)(\\],[\\s\\S]*?liked:\\s*\\[)([^\\]]*)(\\]))`,
      'm'
    );

    if (!npcBlockRegex.test(src)) {
      res.status(404).json({ ok: false, error: `NPC "${id}" block could not be matched in npcs.ts.` });
      return;
    }

    const nextAppearance = ` skinColor: '${skinColor}', hairColor: '${hairColor}', hairStyle: '${hairStyle}', shirtStyle: '${shirtStyle}', outfitColor: '${outfitColor}', pantsStyle: '${pantsStyle}', pantsColor: '${pantsColor}', hatStyle: '${hatStyle}', accessory: '${accessory}', scale: ${scale.toFixed(2)}, idlePose: '${idlePose}' `;
    const lovedLiteral = lovedItems.map((x) => `'${x}'`).join(', ');
    const likedLiteral = likedItems.map((x) => `'${x}'`).join(', ');

    src = src.replace(
      npcBlockRegex,
      `$1${safeName}',\n    gender: '${gender}',\n    age: ${age}$7${nextAppearance}$9${lovedLiteral}$11${likedLiteral}$13`
    );
    fs.writeFileSync(FILE_NPCS, src, 'utf8');

    res.json({
      ok: true,
      message: `Injected NPC "${safeName}" (Age ${age}, ${lovedItems.length} loved item(s), pose "${idlePose}") into npcs.ts! Reload game browser to apply.`,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to update NPC' });
  }
});

// === NPC DIALOGUE DATABASE EDITOR (Edit built-in categories & add brand-new dialogue types!) ===
interface DialogueCategoryRecord {
  id: string;
  label: string;
  description?: string;
  lines: string[];
}
interface DialogueDbRecord {
  version: number;
  updatedAt: string;
  categories: Record<string, DialogueCategoryRecord>;
}

function readNpcDialogueDb(): DialogueDbRecord {
  const src = fs.readFileSync(FILE_NPC_DIALOGUES, 'utf8');
  const m = src.match(/\/\/ DEV_DIALOGUE_DB_START\s*export const NPC_DIALOGUE_DATABASE:\s*NpcDialogueDatabase\s*=\s*([\s\S]*?);\s*\/\/ DEV_DIALOGUE_DB_END/);
  if (!m) {
    throw new Error('Could not locate DEV_DIALOGUE_DB markers in src/game/data/npcDialogueDb.ts');
  }
  // Evaluate pure object literal safely with Function (local trusted source file)
  const parsed = new Function(`return (${m[1]});`)() as DialogueDbRecord;
  return parsed;
}

function writeNpcDialogueDb(db: DialogueDbRecord) {
  const src = fs.readFileSync(FILE_NPC_DIALOGUES, 'utf8');
  const nextBlock = `// DEV_DIALOGUE_DB_START\nexport const NPC_DIALOGUE_DATABASE: NpcDialogueDatabase = ${JSON.stringify(db, null, 2)};\n// DEV_DIALOGUE_DB_END`;
  const replaced = src.replace(
    /\/\/ DEV_DIALOGUE_DB_START[\s\S]*?\/\/ DEV_DIALOGUE_DB_END/,
    nextBlock
  );
  if (replaced === src) {
    throw new Error('Failed to write NPC_DIALOGUE_DATABASE markers in npcDialogueDb.ts');
  }
  fs.writeFileSync(FILE_NPC_DIALOGUES, replaced, 'utf8');
}

app.get('/api/dashboard/npc-dialogues', (_req, res) => {
  try {
    const db = readNpcDialogueDb();
    res.json({ ok: true, database: db });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to read NPC dialogue database' });
  }
});

app.post('/api/dashboard/npc-dialogues', (req, res) => {
  try {
    const body = req.body as {
      action?: 'upsert' | 'delete';
      categoryId?: string;
      label?: string;
      description?: string;
      lines?: string[];
    };
    const db = readNpcDialogueDb();
    const rawId = String(body.categoryId || '').trim().toLowerCase().replace(/[^a-z0-9_]/g, '_');
    if (!rawId || rawId.length < 2 || rawId.length > 48) {
      res.status(400).json({ ok: false, error: 'Category ID must be 2–48 lowercase letters, digits, or underscores.' });
      return;
    }

    if (body.action === 'delete') {
      if (!db.categories[rawId]) {
        res.status(404).json({ ok: false, error: `Dialogue category "${rawId}" not found.` });
        return;
      }
      delete db.categories[rawId];
      db.version = (db.version || 1) + 1;
      db.updatedAt = new Date().toISOString();
      writeNpcDialogueDb(db);
      res.json({ ok: true, message: `Deleted dialogue category "${rawId}".`, database: db });
      return;
    }

    const label = String(body.label || rawId).trim().slice(0, 64);
    const description = String(body.description || '').trim().slice(0, 140);
    const lines = Array.isArray(body.lines)
      ? body.lines.map((l) => String(l).trim()).filter((l) => l.length > 0 && l.length <= 240)
      : [];
    if (lines.length === 0) {
      res.status(400).json({ ok: false, error: 'Please provide at least one non-empty dialogue line.' });
      return;
    }

    db.categories[rawId] = {
      id: rawId,
      label,
      description,
      lines,
    };
    db.version = (db.version || 1) + 1;
    db.updatedAt = new Date().toISOString();
    writeNpcDialogueDb(db);

    res.json({
      ok: true,
      message: `Saved dialogue category "${label}" (${lines.length} lines) into npcDialogueDb.ts!`,
      database: db,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to update NPC dialogue database' });
  }
});

// === NEW PLAYER REGISTRATION & NPC NAME POOL EDITOR (Zero-Coupling -> registrationNames.ts) ===
interface RegistrationNameConfigRecord {
  version: number;
  updatedAt: string;
  farmerNames: string[];
  farmNames: string[];
  dogNames: string[];
  horseNames: string[];
  npcRandomNames: string[];
}

function readRegistrationNamesConfig(): RegistrationNameConfigRecord {
  const src = fs.readFileSync(FILE_REGISTRATION_NAMES, 'utf8');
  const m = src.match(
    /\/\/ DEV_REG_NAMES_START\s*export const REGISTRATION_NAME_CONFIG:\s*RegistrationNameConfig\s*=\s*([\s\S]*?);\s*\/\/ DEV_REG_NAMES_END/
  );
  if (!m) {
    throw new Error('Could not locate DEV_REG_NAMES markers in src/game/data/registrationNames.ts');
  }
  return new Function(`return (${m[1]});`)() as RegistrationNameConfigRecord;
}

function writeRegistrationNamesConfig(cfg: RegistrationNameConfigRecord) {
  const src = fs.readFileSync(FILE_REGISTRATION_NAMES, 'utf8');
  const nextBlock = `// DEV_REG_NAMES_START\nexport const REGISTRATION_NAME_CONFIG: RegistrationNameConfig = ${JSON.stringify(cfg, null, 2)};\n// DEV_REG_NAMES_END`;
  const replaced = src.replace(/\/\/ DEV_REG_NAMES_START[\s\S]*?\/\/ DEV_REG_NAMES_END/, nextBlock);
  if (replaced === src) {
    throw new Error('Failed to write REGISTRATION_NAME_CONFIG markers in registrationNames.ts');
  }
  fs.writeFileSync(FILE_REGISTRATION_NAMES, replaced, 'utf8');
}

app.get('/api/dashboard/registration-names', (_req, res) => {
  try {
    const config = readRegistrationNamesConfig();
    res.json({ ok: true, config });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : 'Failed to read registration name config',
    });
  }
});

app.post('/api/dashboard/registration-names', (req, res) => {
  try {
    const body = req.body as Partial<RegistrationNameConfigRecord>;
    const current = readRegistrationNamesConfig();
    const sanitizePool = (arr: unknown, fallback: string[], maxLen = 32): string[] => {
      if (!Array.isArray(arr)) return fallback;
      const seen = new Set<string>();
      const out: string[] = [];
      for (const item of arr) {
        const clean = String(item || '').trim().slice(0, maxLen);
        if (clean.length >= 2 && !seen.has(clean.toLowerCase())) {
          seen.add(clean.toLowerCase());
          out.push(clean);
        }
      }
      return out.length > 0 ? out : fallback;
    };

    const next: RegistrationNameConfigRecord = {
      version: (current.version || 1) + 1,
      updatedAt: new Date().toISOString(),
      farmerNames: sanitizePool(body.farmerNames, current.farmerNames, 24),
      farmNames: sanitizePool(body.farmNames, current.farmNames, 32),
      dogNames: sanitizePool(body.dogNames, current.dogNames, 20),
      horseNames: sanitizePool(body.horseNames, current.horseNames, 20),
      npcRandomNames: sanitizePool(body.npcRandomNames, current.npcRandomNames, 24),
    };
    writeRegistrationNamesConfig(next);
    res.json({
      ok: true,
      message: `Saved Registration Name Pools (v${next.version}) into registrationNames.ts!`,
      config: next,
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : 'Failed to save registration name config',
    });
  }
});

// Inject Player & Character Animation config into CHARACTER_ANIM_CONFIG in worldConfig.ts
app.post('/api/editor/character-anim', (req, res) => {
  try {
    const hairCatalog = loadHairStylesCatalog();
    const body = req.body as {
      playerWalkSpeed?: number;
      playerRunSpeed?: number;
      playerDefaultIdlePose?: string;
      npcIdleSpeed?: number;
      defaultPlayerPreset?: Record<string, string>;
    };

    const walk = Math.max(2.5, Math.min(14, Number(body.playerWalkSpeed) || 6.2));
    const run = Math.max(walk + 1, Math.min(20, Number(body.playerRunSpeed) || 10.6));
    const pose = ALLOWED_IDLE_POSES.has(String(body.playerDefaultIdlePose)) ? String(body.playerDefaultIdlePose) : 'relaxed';
    const npcIdleSpeed = Math.max(0.3, Math.min(3.0, Number(body.npcIdleSpeed) || 1.0));
    const p = body.defaultPlayerPreset || {};
    const gender = p.gender === 'female' ? 'female' : 'male';
    const skinColor = sanitizeHex(String(p.skinColor || '#fcd5b5'), '#fcd5b5');
    const eyeColor = sanitizeHex(String(p.eyeColor || '#292524'), '#292524');
    const hairStyle = hairCatalog.validIds.has(String(p.hairStyle)) ? String(p.hairStyle) : 'none';
    const hairColor = sanitizeHex(String(p.hairColor || '#6b3e1b'), '#6b3e1b');
    const shirtStyle = ALLOWED_SHIRT_STYLES.has(String(p.shirtStyle)) ? String(p.shirtStyle) : 'none';
    const outfitColor = sanitizeHex(String(p.outfitColor || '#3a6b2c'), '#3a6b2c');
    const pantsStyle = ALLOWED_PANTS_STYLES.has(String(p.pantsStyle)) ? String(p.pantsStyle) : 'none';
    const pantsColor = sanitizeHex(String(p.pantsColor || '#1e3a8a'), '#1e3a8a');
    const hatStyle = ALLOWED_HAT_STYLES.has(String(p.hatStyle)) ? String(p.hatStyle) : 'none';
    const accessory = ALLOWED_ACCESSORIES.has(String(p.accessory)) ? String(p.accessory) : 'none';

    const replacement = `export const CHARACTER_ANIM_CONFIG: CharacterAnimConfig = {
  playerWalkSpeed: ${walk.toFixed(1)},
  playerRunSpeed: ${run.toFixed(1)},
  playerDefaultIdlePose: '${pose}',
  npcIdleSpeed: ${npcIdleSpeed.toFixed(2)},
  defaultPlayerPreset: {
    gender: '${gender}',
    skinColor: '${skinColor}',
    eyeColor: '${eyeColor}',
    hairStyle: '${hairStyle}',
    hairColor: '${hairColor}',
    shirtStyle: '${shirtStyle}',
    outfitColor: '${outfitColor}',
    pantsStyle: '${pantsStyle}',
    pantsColor: '${pantsColor}',
    hatStyle: '${hatStyle}',
    accessory: '${accessory}',
  },
};`;

    let src = fs.readFileSync(FILE_WORLD_CONFIG, 'utf8');
    const animRegex = /export const CHARACTER_ANIM_CONFIG:\s*CharacterAnimConfig\s*=\s*\{[\s\S]*?\n\};/;
    if (!animRegex.test(src)) {
      res.status(404).json({ ok: false, error: 'CHARACTER_ANIM_CONFIG block not found in worldConfig.ts.' });
      return;
    }
    src = src.replace(animRegex, replacement);
    fs.writeFileSync(FILE_WORLD_CONFIG, src, 'utf8');

    res.json({
      ok: true,
      message: 'Injected Player & NPC animation parameters into worldConfig.ts! Reload game browser to apply.',
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to update character animation config' });
  }
});

// === BACKUP & RESTORE (Includes gameRuntimeConfig.ts, worldConfig.ts, itemsAndCrops.ts, npcs.ts) ===
app.get('/api/editor/backups', (_req, res) => {
  try {
    ensureBackupsDir();
    const entries = fs
      .readdirSync(BACKUPS_DIR, { withFileTypes: true })
      .filter((d) => d.isDirectory() && d.name.startsWith('backup_'))
      .map((d) => {
        const dirPath = path.join(BACKUPS_DIR, d.name);
        const manifestPath = path.join(dirPath, 'manifest.json');
        let manifest: { createdAt?: string; label?: string; files?: string[] } = {};
        if (fs.existsSync(manifestPath)) {
          try {
            manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
          } catch {
            // ignore corrupt manifest
          }
        }
        return {
          name: d.name,
          createdAt: manifest.createdAt || d.name,
          label: manifest.label || '',
          files: manifest.files || ['worldConfig.ts', 'gameRuntimeConfig.ts', 'itemsAndCrops.ts', 'npcs.ts'],
        };
      })
      .sort((a, b) => b.name.localeCompare(a.name));

    res.json({ ok: true, backups: entries });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to list backups' });
  }
});

app.post('/api/editor/backup', (req, res) => {
  try {
    ensureBackupsDir();
    const rawLabel = String((req.body as { label?: string }).label || 'snapshot').trim();
    const safeLabel = slugifyId(rawLabel) || 'snapshot';
    const ts = formatBackupTimestamp();
    const folderName = `backup_${ts}_${safeLabel}`;
    const targetDir = path.join(BACKUPS_DIR, folderName);
    fs.mkdirSync(targetDir, { recursive: true });

    fs.copyFileSync(FILE_WORLD_CONFIG, path.join(targetDir, 'worldConfig.ts'));
    fs.copyFileSync(FILE_RUNTIME_CONFIG, path.join(targetDir, 'gameRuntimeConfig.ts'));
    fs.copyFileSync(FILE_ITEMS_CROPS, path.join(targetDir, 'itemsAndCrops.ts'));
    fs.copyFileSync(FILE_NPCS, path.join(targetDir, 'npcs.ts'));
    fs.writeFileSync(
      path.join(targetDir, 'manifest.json'),
      JSON.stringify(
        {
          name: folderName,
          label: rawLabel,
          createdAt: new Date().toISOString(),
          files: ['worldConfig.ts', 'gameRuntimeConfig.ts', 'itemsAndCrops.ts', 'npcs.ts'],
        },
        null,
        2
      ),
      'utf8'
    );

    res.json({ ok: true, name: folderName, message: `Created timestamped backup: ${folderName}` });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Backup failed' });
  }
});

app.post('/api/editor/restore', (req, res) => {
  try {
    ensureBackupsDir();
    const backupName = String((req.body as { name?: string }).name || '').trim();
    if (!backupName || !/^backup_[0-9_-]+_[a-z0-9_]+$/.test(backupName)) {
      res.status(400).json({ ok: false, error: 'Invalid backup identifier.' });
      return;
    }
    const sourceDir = path.join(BACKUPS_DIR, backupName);
    if (!fs.existsSync(sourceDir)) {
      res.status(404).json({ ok: false, error: 'Backup not found.' });
      return;
    }

    const wc = path.join(sourceDir, 'worldConfig.ts');
    const rc = path.join(sourceDir, 'gameRuntimeConfig.ts');
    const ic = path.join(sourceDir, 'itemsAndCrops.ts');
    const np = path.join(sourceDir, 'npcs.ts');
    if (fs.existsSync(wc)) fs.copyFileSync(wc, FILE_WORLD_CONFIG);
    if (fs.existsSync(rc)) fs.copyFileSync(rc, FILE_RUNTIME_CONFIG);
    if (fs.existsSync(ic)) fs.copyFileSync(ic, FILE_ITEMS_CROPS);
    if (fs.existsSync(np)) fs.copyFileSync(np, FILE_NPCS);

    res.json({
      ok: true,
      message: `Restored backup "${backupName}"! Reload game browser to see restored data.`,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Restore failed' });
  }
});

// === MUSIC & AUDIO MANAGER (Harvest Moon: Back to Nature Synth + Custom Audio Upload/Replace) ===
function writeMusicConfigBlock(cfg: {
  mode: 'procedural' | 'custom';
  preset: string;
  tempoScale: number;
  customTracks: Record<string, string>;
}) {
  let rtSrc = fs.readFileSync(FILE_RUNTIME_CONFIG, 'utf8');
  const regex = /export const MUSIC_CONFIG:\s*MusicConfig\s*=\s*\{[\s\S]*?\n\};/;
  if (!regex.test(rtSrc)) {
    throw new Error('MUSIC_CONFIG block not found in gameRuntimeConfig.ts');
  }
  const trackEntries = Object.entries(cfg.customTracks)
    .filter(([k, v]) => ALLOWED_MUSIC_MOODS.has(k) && typeof v === 'string' && v.startsWith('/assets/audio/'))
    .map(([k, v]) => `    ${k}: '${escapeTsString(v)}',`);
  const tracksLiteral = trackEntries.length > 0 ? `{\n${trackEntries.join('\n')}\n  }` : '{}';
  const replacement = `export const MUSIC_CONFIG: MusicConfig = {\n  mode: '${cfg.mode}',\n  preset: '${escapeTsString(cfg.preset)}',\n  tempoScale: ${cfg.tempoScale.toFixed(2)},\n  customTracks: ${tracksLiteral},\n};`;
  rtSrc = rtSrc.replace(regex, replacement);
  fs.writeFileSync(FILE_RUNTIME_CONFIG, rtSrc, 'utf8');
}

app.post('/api/dashboard/music-config', (req, res) => {
  try {
    const prev = parseRuntimeConfig().musicConfig;
    const body = req.body as {
      mode?: string;
      preset?: string;
      tempoScale?: number;
      clearMood?: string;
    };
    const nextTracks = { ...prev.customTracks };
    if (body.clearMood && ALLOWED_MUSIC_MOODS.has(body.clearMood)) {
      delete nextTracks[body.clearMood];
    }
    const nextCfg = {
      mode: (body.mode === 'custom' ? 'custom' : body.mode === 'procedural' ? 'procedural' : prev.mode) as
        | 'procedural'
        | 'custom',
      preset: body.preset && ALLOWED_MUSIC_PRESETS.has(body.preset) ? body.preset : prev.preset,
      tempoScale:
        typeof body.tempoScale === 'number' && Number.isFinite(body.tempoScale)
          ? Math.max(0.75, Math.min(1.3, body.tempoScale))
          : prev.tempoScale,
      customTracks: nextTracks,
    };
    writeMusicConfigBlock(nextCfg);
    res.json({
      ok: true,
      musicConfig: nextCfg,
      message: 'Updated MUSIC_CONFIG in gameRuntimeConfig.ts! Reload game browser to hear changes.',
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to update music config' });
  }
});

app.post('/api/dashboard/upload-music', (req, res) => {
  try {
    const body = req.body as {
      mood?: string;
      filename?: string;
      contentBase64?: string;
      autoEnableCustom?: boolean;
    };
    const mood = String(body.mood || '');
    if (!ALLOWED_MUSIC_MOODS.has(mood)) {
      res.status(400).json({ ok: false, error: 'Invalid music mood slot.' });
      return;
    }
    const rawName = path.basename(String(body.filename || '').trim());
    const ext = path.extname(rawName).toLowerCase();
    if (!rawName || !ALLOWED_AUDIO_EXTS.has(ext)) {
      res.status(400).json({ ok: false, error: 'Unsupported audio format. Use .mp3, .ogg, .wav, .m4a, or .webm.' });
      return;
    }
    const safeBase = rawName
      .slice(0, -ext.length)
      .replace(/[^a-zA-Z0-9._-]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 64) || `bgm_${mood.toLowerCase()}`;
    const safeFilename = `${safeBase}${ext}`;
    const b64 = String(body.contentBase64 || '').replace(/^data:[^;]+;base64,/, '');
    if (!b64) {
      res.status(400).json({ ok: false, error: 'Empty audio file payload.' });
      return;
    }
    const buf = Buffer.from(b64, 'base64');
    if (buf.length > 22 * 1024 * 1024) {
      res.status(413).json({ ok: false, error: 'Audio file exceeds 22 MB limit.' });
      return;
    }

    const audioDir = path.join(ROOT_DIR, 'public', 'assets', 'audio');
    fs.mkdirSync(audioDir, { recursive: true });
    const targetPath = path.join(audioDir, safeFilename);
    const replaced = fs.existsSync(targetPath);
    fs.writeFileSync(targetPath, buf);

    const prev = parseRuntimeConfig().musicConfig;
    const nextCfg = {
      mode: (body.autoEnableCustom === false ? prev.mode : 'custom') as 'procedural' | 'custom',
      preset: prev.preset,
      tempoScale: prev.tempoScale,
      customTracks: {
        ...prev.customTracks,
        [mood]: `/assets/audio/${safeFilename}`,
      },
    };
    writeMusicConfigBlock(nextCfg);

    res.json({
      ok: true,
      replaced,
      filename: safeFilename,
      url: `/assets/audio/${safeFilename}`,
      musicConfig: nextCfg,
      message: replaced
        ? `Replaced existing audio "${safeFilename}" and assigned to ${mood}!`
        : `Uploaded "${safeFilename}" and assigned to ${mood}!`,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Audio upload failed' });
  }
});

// === HARDENED REMOTE FILE EXPLORER (/api/explorer/*) ===
app.get('/api/explorer/list', (req, res) => {
  try {
    const dirParam = String(req.query.dir || '');
    const { absPath, relPath } = resolveSafeProjectPath(dirParam, { allowRoot: true });
    if (!fs.existsSync(absPath) || !fs.statSync(absPath).isDirectory()) {
      res.status(404).json({ ok: false, error: 'Directory not found.' });
      return;
    }
    const dirents = fs.readdirSync(absPath, { withFileTypes: true });
    const entries: Array<{
      name: string;
      relPath: string;
      isDir: boolean;
      size: number;
      mtimeMs: number;
      isText: boolean;
    }> = [];
    for (const d of dirents) {
      if (isBlockedSegment(d.name)) continue;
      const childRel = relPath ? `${relPath}/${d.name}` : d.name;
      const childAbs = path.join(absPath, d.name);
      try {
        const real = fs.realpathSync(childAbs);
        if (real !== ROOT_REAL && !real.startsWith(ROOT_REAL + path.sep)) continue;
        const st = fs.statSync(childAbs);
        entries.push({
          name: d.name,
          relPath: childRel,
          isDir: st.isDirectory(),
          size: st.isDirectory() ? 0 : st.size,
          mtimeMs: st.mtimeMs,
          isText: !st.isDirectory() && isTextEditableName(d.name),
        });
      } catch {
        // skip unreadable or dangling symlinks
      }
    }
    entries.sort((a, b) => {
      if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    res.json({ ok: true, dir: relPath, entries });
  } catch (err) {
    res.status(400).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to list directory' });
  }
});

app.get('/api/explorer/read', (req, res) => {
  try {
    const targetParam = String(req.query.path || '');
    const { absPath, relPath } = resolveSafeProjectPath(targetParam);
    if (!fs.existsSync(absPath) || !fs.statSync(absPath).isFile()) {
      res.status(404).json({ ok: false, error: 'File not found.' });
      return;
    }
    const st = fs.statSync(absPath);
    if (st.size > 2 * 1024 * 1024) {
      res.status(413).json({ ok: false, error: 'File is larger than 2 MB and cannot be opened in the code editor.' });
      return;
    }
    const rawBuf = fs.readFileSync(absPath);
    // Reject obvious binary files containing null bytes
    const checkLen = Math.min(rawBuf.length, 4096);
    for (let i = 0; i < checkLen; i++) {
      if (rawBuf[i] === 0) {
        res.status(415).json({ ok: false, error: 'Binary file cannot be edited as text. Use Upload to replace it.' });
        return;
      }
    }
    res.json({
      ok: true,
      path: relPath,
      size: st.size,
      mtimeMs: st.mtimeMs,
      content: rawBuf.toString('utf8'),
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to read file' });
  }
});

app.get('/api/explorer/raw', (req, res) => {
  try {
    const targetParam = String(req.query.path || '');
    const { absPath } = resolveSafeProjectPath(targetParam);
    if (!fs.existsSync(absPath) || !fs.statSync(absPath).isFile()) {
      res.status(404).json({ ok: false, error: 'File not found.' });
      return;
    }
    res.sendFile(absPath);
  } catch (err) {
    res.status(400).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to stream file' });
  }
});

app.post('/api/explorer/write', (req, res) => {
  try {
    const body = req.body as { path?: string; content?: string };
    const { absPath, relPath } = resolveSafeProjectPath(String(body.path || ''));
    const content = typeof body.content === 'string' ? body.content : '';
    if (Buffer.byteLength(content, 'utf8') > 4 * 1024 * 1024) {
      res.status(413).json({ ok: false, error: 'Text content exceeds 4 MB limit.' });
      return;
    }
    fs.mkdirSync(path.dirname(absPath), { recursive: true });
    const replaced = fs.existsSync(absPath);
    fs.writeFileSync(absPath, content, 'utf8');
    res.json({
      ok: true,
      replaced,
      path: relPath,
      size: Buffer.byteLength(content, 'utf8'),
      message: replaced ? `Saved & replaced "${relPath}"!` : `Created new file "${relPath}"!`,
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to write file' });
  }
});

app.post('/api/explorer/upload', (req, res) => {
  try {
    const body = req.body as { dir?: string; filename?: string; contentBase64?: string };
    const cleanFilename = path.basename(String(body.filename || '').trim());
    if (!cleanFilename || cleanFilename === '.' || cleanFilename === '..' || isBlockedSegment(cleanFilename)) {
      res.status(400).json({ ok: false, error: 'Invalid or restricted filename.' });
      return;
    }
    const dirRel = String(body.dir || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
    const targetRel = dirRel ? `${dirRel}/${cleanFilename}` : cleanFilename;
    const { absPath, relPath } = resolveSafeProjectPath(targetRel);

    const b64 = String(body.contentBase64 || '').replace(/^data:[^;]+;base64,/, '');
    const buf = Buffer.from(b64, 'base64');
    if (buf.length > 25 * 1024 * 1024) {
      res.status(413).json({ ok: false, error: 'Uploaded file exceeds 25 MB limit.' });
      return;
    }
    fs.mkdirSync(path.dirname(absPath), { recursive: true });
    const replaced = fs.existsSync(absPath);
    fs.writeFileSync(absPath, buf);
    res.json({
      ok: true,
      replaced,
      path: relPath,
      filename: cleanFilename,
      size: buf.length,
      message: replaced
        ? `Auto-replaced existing file "${relPath}" (${buf.length.toLocaleString()} B)`
        : `Uploaded new file "${relPath}" (${buf.length.toLocaleString()} B)`,
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err instanceof Error ? err.message : 'File upload failed' });
  }
});

app.post('/api/explorer/mkdir', (req, res) => {
  try {
    const body = req.body as { dir?: string; name?: string };
    const folderName = path.basename(String(body.name || '').trim());
    if (!folderName || !/^[a-zA-Z0-9._ -]{1,80}$/.test(folderName) || isBlockedSegment(folderName)) {
      res.status(400).json({ ok: false, error: 'Invalid folder name.' });
      return;
    }
    const dirRel = String(body.dir || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
    const targetRel = dirRel ? `${dirRel}/${folderName}` : folderName;
    const { absPath, relPath } = resolveSafeProjectPath(targetRel);
    fs.mkdirSync(absPath, { recursive: true });
    res.json({ ok: true, path: relPath, message: `Created folder "${relPath}"!` });
  } catch (err) {
    res.status(400).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to create folder' });
  }
});

app.post('/api/explorer/delete', (req, res) => {
  try {
    const body = req.body as { path?: string };
    const { absPath, relPath } = resolveSafeProjectPath(String(body.path || ''));
    if (PROTECTED_TOP_DIRS.has(relPath) || PROTECTED_TOP_FILES.has(relPath)) {
      res.status(403).json({ ok: false, error: `Deleting critical root entry "${relPath}" is protected.` });
      return;
    }
    if (!fs.existsSync(absPath)) {
      res.status(404).json({ ok: false, error: 'Target does not exist.' });
      return;
    }
    fs.rmSync(absPath, { recursive: true, force: true });
    res.json({ ok: true, path: relPath, message: `Deleted "${relPath}"!` });
  } catch (err) {
    res.status(400).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to delete path' });
  }
});

app.listen(EDITOR_PORT, EDITOR_BIND_HOST, () => {
  console.log(`[Harvest Developer Dashboard] Control Room listening on http://${EDITOR_BIND_HOST}:${EDITOR_PORT}`);
  console.log(`[Harvest Developer Dashboard] Remote-ready auth gate + zero-coupling injector -> ${ROOT_DIR}/src/game/data/`);
});
