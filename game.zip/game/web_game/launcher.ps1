﻿# Harvest in the Great Valley — Windows GUI launcher + PowerShell action worker
param(
  [ValidateSet('', 'Start', 'Stop', 'Setup', 'Check', 'TunnelInstall', 'TunnelStart', 'TunnelStop')]
  [string]$Action = ''
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$GameDir = Join-Path $Root 'harvest_in_the_great_valley'
$DevDir = Join-Path $Root 'dev_panel'
$DataDir = Join-Path $Root 'data'
$GameData = Join-Path $DataDir 'data_game'
$DevData = Join-Path $DataDir 'data_dev_panel'
$ToolsDir = Join-Path $Root 'tools'
$BunDir = Join-Path $ToolsDir 'bun'
$RuntimeDir = Join-Path $ToolsDir 'runtime'
$ConfigDir = Join-Path $RuntimeDir 'config'
$CertDir = Join-Path $RuntimeDir 'https'
$LogDir = Join-Path $RuntimeDir 'logs'
$CacheDir = Join-Path $RuntimeDir 'cache'
$PidFile = Join-Path $RuntimeDir 'game-server.pid'
$ServerOut = Join-Path $LogDir 'game-server.out.log'
$ServerErr = Join-Path $LogDir 'game-server.err.log'
$LauncherLog = Join-Path $LogDir 'launcher.log'
$NetworkConfig = Join-Path $ConfigDir 'network.json'
$CloudflaredDir = Join-Path $ToolsDir 'cloudflared'
$CloudflaredExe = Join-Path $CloudflaredDir 'cloudflared.exe'
$CloudflarePidFile = Join-Path $RuntimeDir 'cloudflared.pid'
$CloudflareOut = Join-Path $LogDir 'cloudflared.out.log'
$CloudflareErr = Join-Path $LogDir 'cloudflared.err.log'
$Port = 3000
$IsWindows = $PSVersionTable.Platform -eq 'Win32NT' -or $env:OS -eq 'Windows_NT'
$BunExe = if ($IsWindows) { Join-Path $BunDir 'bun.exe' } else { Join-Path $BunDir 'bun' }

foreach ($dir in @($GameData, $DevData, $BunDir, $RuntimeDir, $ConfigDir, $CertDir, $LogDir, $CacheDir, (Join-Path $DevData 'backup'), (Join-Path $DevData 'dev_panel_secrets'), (Join-Path $GameData 'game_secrets'), $CloudflaredDir)) {
  New-Item -ItemType Directory -Path $dir -Force | Out-Null
}

function Write-Log([string]$Message, [string]$Level = 'INFO') {
  if ((Test-Path $LauncherLog) -and (Get-Item $LauncherLog).Length -gt 2MB) {
    Move-Item $LauncherLog ($LauncherLog + '.1') -Force
  }
  Add-Content -Path $LauncherLog -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [$Level] $Message" -Encoding UTF8
}
function Get-BunPath {
  if (Test-Path $BunExe) { return $BunExe }
  $cmd = Get-Command bun -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  return $null
}
function Get-LocalIPv4 {
  $found = @()
  if ($IsWindows) {
    try { $found += Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop | Where-Object { !$_.IPAddress.StartsWith('127.') -and !$_.IPAddress.StartsWith('169.254.') } | Select-Object -ExpandProperty IPAddress } catch {}
  } else {
    $ipCmd = Get-Command ip -ErrorAction SilentlyContinue
    if ($ipCmd) {
      $lines = & $ipCmd.Source -o -4 addr show scope global 2>$null
      foreach ($line in $lines) { if ($line -match '\binet\s+([0-9.]+)/') { $found += $Matches[1] } }
    }
  }
  return @($found | Sort-Object -Unique)
}
function Get-NetworkConfig {
  if (Test-Path $NetworkConfig) {
    try { return (Get-Content $NetworkConfig -Raw | ConvertFrom-Json) } catch {}
  }
  return [pscustomobject]@{ mode = 'auto'; host = ''; port = 3000 }
}

# Load persisted launcher network settings (IP mode + port).
try {
  if (Test-Path -LiteralPath $NetworkConfig) {
    $savedNetwork = Get-Content -LiteralPath $NetworkConfig -Raw | ConvertFrom-Json
    if ($savedNetwork.port -and [int]$savedNetwork.port -ge 1 -and [int]$savedNetwork.port -le 65535) { $Port = [int]$savedNetwork.port }
  }
} catch { Write-Warning "Konfigurasi jaringan tidak dapat dibaca; memakai port default 3000."; $Port = 3000 }
function Get-PreferredHost {
  $cfg = Get-NetworkConfig
  if ($cfg.mode -eq 'manual' -and $cfg.host) { return [string]$cfg.host }
  $ips = @(Get-LocalIPv4)
  if ($ips.Count -gt 0) { return [string]$ips[0] }
  return '127.0.0.1'
}
function Get-GameUrl {
  $hostName = Get-PreferredHost
  if ($hostName -match ':' -and $hostName -notmatch '^\[') { $hostName = "[$hostName]" }
  return "https://${hostName}:$Port"
}
function Test-PortOpen([string]$HostName = '127.0.0.1', [int]$CheckPort = $Port) {
  $client = [System.Net.Sockets.TcpClient]::new()
  try {
    $task = $client.ConnectAsync($HostName, $CheckPort)
    if (!$task.Wait(700)) { return $false }
    return $client.Connected
  } catch { return $false } finally { $client.Dispose() }
}
function Get-ServerProcess {
  if (!(Test-Path $PidFile)) { return $null }
  try { $record = Get-Content $PidFile -Raw | ConvertFrom-Json } catch { Remove-Item $PidFile -Force -ErrorAction SilentlyContinue; return $null }
  if (!$record.pid -or !$record.startedUtcTicks) { Remove-Item $PidFile -Force -ErrorAction SilentlyContinue; return $null }
  $proc = Get-Process -Id ([int]$record.pid) -ErrorAction SilentlyContinue
  if (!$proc -or $proc.ProcessName -notmatch '^bun(\.exe)?$') { Remove-Item $PidFile -Force -ErrorAction SilentlyContinue; return $null }
  try { if ($proc.StartTime.ToUniversalTime().Ticks -ne [long]$record.startedUtcTicks) { Remove-Item $PidFile -Force -ErrorAction SilentlyContinue; return $null } } catch { Remove-Item $PidFile -Force -ErrorAction SilentlyContinue; return $null }
  return $proc
}
function Test-DirectoryHasChildren([string]$Path) {
  if (!(Test-Path -LiteralPath $Path)) { return $false }
  $first = Get-ChildItem -LiteralPath $Path -Force -ErrorAction SilentlyContinue | Select-Object -First 1
  return ($null -ne $first)
}
function Remove-LinkOnly([string]$Path) {
  if ($IsWindows) {
    # rmdir removes the junction entry itself; it does not recursively delete its target.
    & $env:ComSpec /d /c "rmdir `"$Path`"" | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Tidak dapat melepas junction: $Path" }
  } else {
    Remove-Item -LiteralPath $Path -Force
  }
}
function Merge-MissingModuleFiles([string]$SourcePath, [string]$TargetPath) {
  # Preserve existing target files. Copy only files that are not already present.
  $files = Get-ChildItem -LiteralPath $SourcePath -File -Force -Recurse
  foreach ($file in $files) {
    $relative = $file.FullName.Substring($SourcePath.TrimEnd([IO.Path]::DirectorySeparatorChar).Length).TrimStart([IO.Path]::DirectorySeparatorChar)
    $destination = Join-Path $TargetPath $relative
    if (!(Test-Path -LiteralPath $destination)) {
      $parent = Split-Path -Parent $destination
      if (!(Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
      Copy-Item -LiteralPath $file.FullName -Destination $destination
    }
  }
}
function Ensure-DirectoryLink([string]$LinkPath, [string]$TargetPath) {
  $targetParent = Split-Path -Parent $TargetPath
  if (!(Test-Path -LiteralPath $targetParent)) { New-Item -ItemType Directory -Path $targetParent -Force | Out-Null }

  $linkItem = Get-Item -LiteralPath $LinkPath -Force -ErrorAction SilentlyContinue
  if ($linkItem) {
    $isReparsePoint = ($linkItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0
    if ($isReparsePoint) {
      $targetExists = Test-Path -LiteralPath $TargetPath
      if ($targetExists) {
        $resolvedLink = (Resolve-Path -LiteralPath $LinkPath).Path.TrimEnd([IO.Path]::DirectorySeparatorChar)
        $resolvedTarget = (Resolve-Path -LiteralPath $TargetPath).Path.TrimEnd([IO.Path]::DirectorySeparatorChar)
        if ($resolvedLink -eq $resolvedTarget) { return $true }
      }
      Remove-LinkOnly $LinkPath
    } else {
      # A real node_modules folder may contain the packages just installed by Bun.
      # Move it into data; never recursively delete it.
      if (!(Test-Path -LiteralPath $TargetPath)) {
        Move-Item -LiteralPath $LinkPath -Destination $TargetPath
      } elseif (!(Test-DirectoryHasChildren $TargetPath)) {
        Remove-Item -LiteralPath $TargetPath -Force
        Move-Item -LiteralPath $LinkPath -Destination $TargetPath
      } else {
        $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
        $backupPath = Join-Path (Split-Path -Parent $TargetPath) ("node_modules-migration-backup-" + $stamp)
        Move-Item -LiteralPath $LinkPath -Destination $backupPath
        try {
          Merge-MissingModuleFiles -SourcePath $backupPath -TargetPath $TargetPath
          Write-Host "[AMAN] Modul lama dipindahkan ke backup: $backupPath" -ForegroundColor Yellow
          Write-Host '[AMAN] File yang sudah ada di data dipertahankan; file yang belum ada disalin.' -ForegroundColor Yellow
        } catch {
          if (!(Test-Path -LiteralPath $LinkPath) -and (Test-Path -LiteralPath $backupPath)) {
            Move-Item -LiteralPath $backupPath -Destination $LinkPath
          }
          throw
        }
      }
    }
  }

  if (!(Test-Path -LiteralPath $TargetPath)) { New-Item -ItemType Directory -Path $TargetPath -Force | Out-Null }
  if ($IsWindows) {
    New-Item -ItemType Junction -Path $LinkPath -Target $TargetPath -ErrorAction Stop | Out-Null
  } else {
    $ln = Get-Command ln -ErrorAction SilentlyContinue
    if (!$ln) { throw 'Perintah ln tidak ditemukan untuk membuat symbolic link.' }
    & $ln.Source -s $TargetPath $LinkPath
    if ($LASTEXITCODE -ne 0) { throw "Gagal membuat symbolic link: $LinkPath" }
  }
  return $true
}
function Ensure-Links {
  Write-Host '[MODULE] Memastikan node_modules berada di data/ dan source hanya berisi junction/symlink...' -ForegroundColor Cyan
  $gameLink = Ensure-DirectoryLink (Join-Path $GameDir 'node_modules') (Join-Path $GameData 'node_modules')
  $devLink = Ensure-DirectoryLink (Join-Path $DevDir 'node_modules') (Join-Path $DevData 'node_modules')
  return ($gameLink -and $devLink)
}
function Install-Bun {
  if (Test-Path $BunExe) {
    try { & $BunExe --version; if ($LASTEXITCODE -eq 0) { return $true } } catch {}
  }
  $systemBun = Get-Command bun -ErrorAction SilentlyContinue
  if ($systemBun) { Write-Host "Bun dari PATH tersedia: $($systemBun.Source)" -ForegroundColor Green; return $true }
  $arch = [Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString().ToLowerInvariant()
  if ($IsWindows) {
    if ($arch -match 'arm') { $asset = 'bun-windows-aarch64.zip' } else { $asset = 'bun-windows-x64.zip' }
  } else {
    if ($arch -match 'arm') { $asset = 'bun-linux-aarch64.zip' } else { $asset = 'bun-linux-x64.zip' }
  }
  $download = Join-Path $RuntimeDir $asset
  $extract = Join-Path $RuntimeDir 'bun-extract'
  $url = "https://github.com/oven-sh/bun/releases/latest/download/$asset"
  try {
    Write-Host "Mengunduh Bun portable ($asset)..." -ForegroundColor Cyan
    Invoke-WebRequest -Uri $url -OutFile $download
    if (Test-Path $extract) { Remove-Item $extract -Recurse -Force }
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    [IO.Compression.ZipFile]::ExtractToDirectory($download, $extract)
    $binaryName = if ($IsWindows) { 'bun.exe' } else { 'bun' }
    $binary = Get-ChildItem -Path $extract -Filter $binaryName -Recurse -File | Select-Object -First 1
    if (!$binary) { throw "Binary $binaryName tidak ditemukan dalam arsip Bun." }
    Copy-Item $binary.FullName $BunExe -Force
    if (!$IsWindows) { & chmod +x $BunExe }
    & $BunExe --version
    if ($LASTEXITCODE -ne 0) { throw 'Binary Bun tidak dapat dijalankan.' }
    Write-Log "Bun portable installed: $BunExe"
    return $true
  } catch {
    Write-Host "Gagal memasang Bun: $($_.Exception.Message)" -ForegroundColor Red
    Write-Log "Bun installation failed: $($_.Exception.Message)" 'ERROR'
    return $false
  } finally {
    Remove-Item $download -Force -ErrorAction SilentlyContinue
    Remove-Item $extract -Recurse -Force -ErrorAction SilentlyContinue
  }
}
function Install-Dependencies {
  if (!(Ensure-Links)) { throw 'Junction/symbolic link node_modules tidak dapat disiapkan. Periksa pesan di atas.' }
  $bun = Get-BunPath
  if (!$bun) { if (!(Install-Bun)) { throw 'Bun tidak tersedia.' }; $bun = Get-BunPath }
  $env:BUN_INSTALL_CACHE_DIR = Join-Path $CacheDir 'bun-install'
  foreach ($project in @($GameDir, $DevDir)) {
    Write-Host "Memasang dependensi: $(Split-Path $project -Leaf)" -ForegroundColor Cyan
    Push-Location $project
    try { & $bun install; if ($LASTEXITCODE -ne 0) { throw "bun install gagal pada $project (exit $LASTEXITCODE)." } }
    finally { Pop-Location }
  }
  return $true
}
function Ensure-HttpsCertificate {
  $cert = Join-Path $CertDir 'local-cert.pem'
  $key = Join-Path $CertDir 'local-key.pem'
  $manifest = Join-Path $CertDir 'certificate-hosts.txt'
  $manualHost = [string](Get-NetworkConfig).host
  $hosts = @('localhost', '127.0.0.1') + @(Get-LocalIPv4)
  if ($manualHost) { $hosts += $manualHost }
  $hosts = @($hosts | Where-Object { $_ } | Sort-Object -Unique)
  $hostStamp = $hosts -join "`n"
  $sameHosts = (Test-Path $manifest) -and ((Get-Content $manifest -Raw).Trim() -eq $hostStamp.Trim())
  if ((Test-Path $cert) -and (Test-Path $key) -and $sameHosts) { return $true }
  $generator = Join-Path $RuntimeDir 'generate-https-cert.ps1'
  if (!(Test-Path $generator)) { throw "Generator sertifikat tidak ditemukan: $generator" }
  Remove-Item $cert, $key -Force -ErrorAction SilentlyContinue
  & $generator -ExtraHosts $hosts
  if ($LASTEXITCODE -ne 0 -or !(Test-Path $cert) -or !(Test-Path $key)) { throw 'Pembuatan sertifikat HTTPS lokal gagal.' }
  Set-Content -Path $manifest -Value $hostStamp -Encoding UTF8
  return $true
}
function Check-Installation {
  Write-Host "`n=== PEMERIKSAAN INSTALASI ===" -ForegroundColor Cyan
  foreach ($path in @((Join-Path $GameDir 'server.ts'), (Join-Path $GameDir 'package.json'), (Join-Path $DevDir 'package.json'), (Join-Path $DevDir 'src/DevPanel.tsx'))) {
    if (Test-Path $path) { Write-Host "[OK] $path" -ForegroundColor Green } else { Write-Host "[GAGAL] File tidak ditemukan: $path" -ForegroundColor Red }
  }
  $bun = Get-BunPath
  if ($bun) { Write-Host "[OK] Bun: $bun" -ForegroundColor Green } else { Write-Host '[BELUM ADA] Bun belum tersedia.' -ForegroundColor Yellow }
  foreach ($pair in @(@((Join-Path $GameDir 'node_modules'), (Join-Path $GameData 'node_modules')), @((Join-Path $DevDir 'node_modules'), (Join-Path $DevData 'node_modules')))) {
    $link = $pair[0]; $target = $pair[1]
    if (Test-Path $link) {
      $resolved = (Resolve-Path $link).Path.TrimEnd([IO.Path]::DirectorySeparatorChar)
      $expected = (Resolve-Path $target).Path.TrimEnd([IO.Path]::DirectorySeparatorChar)
      if ($resolved -eq $expected) { Write-Host "[OK] Link $link -> $target" -ForegroundColor Green } else { Write-Host "[SALAH] Link $link tidak menuju $target" -ForegroundColor Red }
    } else { Write-Host "[BELUM ADA] Link $link" -ForegroundColor Yellow }
    if (Test-Path (Join-Path $target '')) { Write-Host "[OK] Folder modul data: $target" -ForegroundColor Green }
  }
  if ((Test-Path (Join-Path $CertDir 'local-cert.pem')) -and (Test-Path (Join-Path $CertDir 'local-key.pem'))) { Write-Host '[OK] Sertifikat HTTPS lokal tersedia.' -ForegroundColor Green } else { Write-Host '[BELUM ADA] Sertifikat HTTPS lokal.' -ForegroundColor Yellow }
  if (Test-PortOpen) { Write-Host "[AKTIF] Port $Port sedang menerima koneksi." -ForegroundColor Yellow } else { Write-Host "[KOSONG] Port $Port tersedia." -ForegroundColor Green }
  $proc = Get-ServerProcess
  if ($proc) { Write-Host "[ONLINE] Game Server PID $($proc.Id)" -ForegroundColor Green } else { Write-Host '[OFFLINE] Game Server tidak berjalan.' -ForegroundColor Gray }
  Write-Host "Data Game : $GameData`nData Dev  : $DevData`nRuntime   : $RuntimeDir"
}
function Setup-Requirements {
  if (!(Install-Bun)) { return }
  Install-Dependencies
  Ensure-HttpsCertificate
  Write-Host "`n[SELESAI] Bun, dependensi, link modul, dan sertifikat HTTPS sudah diperiksa." -ForegroundColor Green
  Write-Log 'Requirements install/repair completed.'
}
function Start-GameServer {
  $existing = Get-ServerProcess
  if ($existing -and (Test-PortOpen)) { Write-Host "Server sudah aktif: $(Get-GameUrl) (PID $($existing.Id))" -ForegroundColor Yellow; return }
  if ($existing -and !(Test-PortOpen)) { Stop-Process -Id $existing.Id -Force -ErrorAction SilentlyContinue; Remove-Item $PidFile -Force -ErrorAction SilentlyContinue }
  if (Test-PortOpen) { Write-Host "Port $Port sudah digunakan proses lain. Server tidak dijalankan agar tidak mengganggu proses tersebut." -ForegroundColor Red; return }
  Write-Host '[SETUP] Memeriksa Bun, runtime, modul proyek, dan HTTPS sebelum server dijalankan...' -ForegroundColor Cyan
  Setup-Requirements
  $bun = Get-BunPath
  if (!$bun) { throw 'Bun tidak tersedia setelah proses instalasi.' }
  $env:PORT = "$Port"
  $env:APP_PORT = "$Port"
  $env:DEFAULT_APP_PORT = "$Port"
  $env:WEB_GAME_DIR = $Root
  $env:HARVEST_RUNTIME_DIR = $DataDir
  $env:DISABLE_HMR = 'true'
  $env:ENABLE_HTTPS = '1'
  $env:REQUIRE_HTTPS = '1'
  $env:HTTPS_CERT_FILE = Join-Path $CertDir 'local-cert.pem'
  $env:HTTPS_KEY_FILE = Join-Path $CertDir 'local-key.pem'
  $env:GAME_ENV_FILE = Join-Path $ConfigDir 'game.env'
  $env:BUN_INSTALL_CACHE_DIR = Join-Path $CacheDir 'bun-install'
  if ((Test-Path $env:GAME_ENV_FILE) -and !(Test-Path (Join-Path $GameDir '.env'))) { Write-Log "Using external env file: $env:GAME_ENV_FILE" }
  foreach ($logPath in @($ServerOut, $ServerErr)) { if ((Test-Path $logPath) -and (Get-Item $logPath).Length -gt 5MB) { Move-Item $logPath ($logPath + '.1') -Force } }
  Write-Host 'Menyalakan Game Server dengan HTTPS...' -ForegroundColor Cyan
  $proc = Start-Process -FilePath $bun -ArgumentList @('run', 'server.ts') -WorkingDirectory $GameDir -RedirectStandardOutput $ServerOut -RedirectStandardError $ServerErr -PassThru
  [pscustomobject]@{ pid = $proc.Id; startedUtcTicks = $proc.StartTime.ToUniversalTime().Ticks } | ConvertTo-Json | Set-Content -Path $PidFile -Encoding ASCII
  $ready = $false
  for ($i = 0; $i -lt 25; $i++) {
    Start-Sleep -Milliseconds 500
    if ($proc.HasExited) { break }
    if (Test-PortOpen) { $ready = $true; break }
  }
  if (!$ready) {
    if (!$proc.HasExited) { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
    Remove-Item $PidFile -Force -ErrorAction SilentlyContinue
    Write-Host '[GAGAL] Server tidak berhasil aktif. Periksa log error.' -ForegroundColor Red
    if (Test-Path $ServerErr) { Get-Content $ServerErr -Tail 25 }
    Write-Log 'Game server failed to become ready.' 'ERROR'
    return
  }
  Write-Host "`n[ONLINE] Game Server aktif (PID $($proc.Id))" -ForegroundColor Green
  Write-Host "HTTPS: $(Get-GameUrl)" -ForegroundColor Cyan
  Write-Host 'Dev Panel: login menggunakan akun Owner/Developer di dalam game, lalu buka menu Dev Panel.' -ForegroundColor Yellow
  Write-Host "LAN IP: $((Get-LocalIPv4) -join ', ')"
  Write-Log "Game server started PID=$($proc.Id) URL=$(Get-GameUrl)"
}

function Get-CloudflareProcess {
  if (!(Test-Path -LiteralPath $CloudflarePidFile)) { return $null }
  try { $record = Get-Content -LiteralPath $CloudflarePidFile -Raw | ConvertFrom-Json } catch {
    Remove-Item -LiteralPath $CloudflarePidFile -Force -ErrorAction SilentlyContinue
    return $null
  }
  if (!$record.pid -or !$record.startedUtcTicks) {
    Remove-Item -LiteralPath $CloudflarePidFile -Force -ErrorAction SilentlyContinue
    return $null
  }
  $proc = Get-Process -Id ([int]$record.pid) -ErrorAction SilentlyContinue
  if (!$proc -or $proc.ProcessName -notmatch '^cloudflared(\.exe)?$') {
    Remove-Item -LiteralPath $CloudflarePidFile -Force -ErrorAction SilentlyContinue
    return $null
  }
  try {
    if ($proc.StartTime.ToUniversalTime().Ticks -ne [long]$record.startedUtcTicks) {
      Remove-Item -LiteralPath $CloudflarePidFile -Force -ErrorAction SilentlyContinue
      return $null
    }
  } catch {
    Remove-Item -LiteralPath $CloudflarePidFile -Force -ErrorAction SilentlyContinue
    return $null
  }
  return $proc
}
function Install-Cloudflared {
  if (Test-Path -LiteralPath $CloudflaredExe) {
    try {
      & $CloudflaredExe --version 2>&1 | Out-Null
      if ($LASTEXITCODE -eq 0) {
        Write-Host "[OK] cloudflared sudah tersedia: $CloudflaredExe" -ForegroundColor Green
        return $true
      }
    } catch {}
  }

  $arch = [Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
  if ($arch -match 'Arm64') {
    $asset = 'cloudflared-windows-arm64.exe'
  } else {
    $asset = 'cloudflared-windows-amd64.exe'
  }
  $downloadPath = Join-Path $RuntimeDir $asset
  $downloadUrl = "https://github.com/cloudflare/cloudflared/releases/latest/download/$asset"
  try {
    Write-Host "Mengunduh cloudflared ($asset)..." -ForegroundColor Cyan
    Invoke-WebRequest -Uri $downloadUrl -OutFile $downloadPath -UseBasicParsing
    if (!(Test-Path -LiteralPath $downloadPath) -or (Get-Item -LiteralPath $downloadPath).Length -lt 1MB) {
      throw 'File cloudflared yang diunduh tidak valid.'
    }
    if (!(Test-Path -LiteralPath $CloudflaredDir)) {
      New-Item -ItemType Directory -Path $CloudflaredDir -Force | Out-Null
    }
    Move-Item -LiteralPath $downloadPath -Destination $CloudflaredExe -Force
    & $CloudflaredExe --version
    if ($LASTEXITCODE -ne 0) { throw 'cloudflared gagal dijalankan setelah instalasi.' }
    Write-Log "cloudflared installed: $CloudflaredExe"
    Write-Host "[OK] cloudflared berhasil dipasang: $CloudflaredExe" -ForegroundColor Green
    return $true
  } catch {
    Remove-Item -LiteralPath $downloadPath -Force -ErrorAction SilentlyContinue
    Write-Log "cloudflared install failed: $($_.Exception.Message)" 'ERROR'
    throw
  }
}
function Get-CloudflareUrl {
  foreach ($logFile in @($CloudflareOut, $CloudflareErr)) {
    if (Test-Path -LiteralPath $logFile) {
      $match = Select-String -LiteralPath $logFile -Pattern 'https://[a-zA-Z0-9-]+\.trycloudflare\.com' |
        Select-Object -Last 1
      if ($match) {
        $urlMatch = [regex]::Match($match.Line, 'https://[a-zA-Z0-9-]+\.trycloudflare\.com')
        if ($urlMatch.Success) { return $urlMatch.Value }
      }
    }
  }
  return ''
}
function Start-CloudflareTunnel {
  if (!(Get-ServerProcess) -or !(Test-PortOpen)) {
    throw 'Game Server harus aktif terlebih dahulu sebelum Cloudflare Tunnel dijalankan.'
  }
  $existingTunnel = Get-CloudflareProcess
  if ($existingTunnel) {
    Write-Host "[AKTIF] Cloudflare Tunnel sudah berjalan (PID $($existingTunnel.Id))." -ForegroundColor Yellow
    $existingUrl = Get-CloudflareUrl
    if ($existingUrl) { Write-Host "URL publik: $existingUrl" -ForegroundColor Green }
    return
  }
  if (!(Test-Path -LiteralPath $CloudflaredExe)) {
    Write-Host '[SETUP] cloudflared belum tersedia. Memasang otomatis sebelum tunnel dimulai...' -ForegroundColor Cyan
    [void](Install-Cloudflared)
  }

  foreach ($logFile in @($CloudflareOut, $CloudflareErr)) {
    if (Test-Path -LiteralPath $logFile) {
      Move-Item -LiteralPath $logFile -Destination ($logFile + '.previous') -Force -ErrorAction SilentlyContinue
    }
  }

  # Local origin is the launcher's self-signed HTTPS server. TLS verification
  # is disabled only for the loopback origin connection; public traffic remains
  # HTTPS at Cloudflare's edge.
  $arguments = @('tunnel', '--url', "https://127.0.0.1:$Port", '--no-tls-verify', '--protocol', 'http2')
  $proc = Start-Process -FilePath $CloudflaredExe -ArgumentList $arguments `
    -WorkingDirectory $Root -RedirectStandardOutput $CloudflareOut `
    -RedirectStandardError $CloudflareErr -PassThru
  [pscustomobject]@{
    pid = $proc.Id
    startedUtcTicks = $proc.StartTime.ToUniversalTime().Ticks
  } | ConvertTo-Json | Set-Content -LiteralPath $CloudflarePidFile -Encoding ASCII

  Write-Log "Cloudflare Quick Tunnel started PID=$($proc.Id) origin=https://127.0.0.1:$Port"
  Write-Host "[START] Cloudflare Quick Tunnel dimulai. Menunggu URL publik..." -ForegroundColor Cyan
  Start-Sleep -Seconds 2
  $url = Get-CloudflareUrl
  if ($url) { Write-Host "URL publik: $url" -ForegroundColor Green }
  else { Write-Host 'Tunnel sedang tersambung. URL akan muncul di log beberapa saat lagi.' -ForegroundColor Yellow }
}
function Stop-CloudflareTunnel {
  $proc = Get-CloudflareProcess
  if ($proc) {
    Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
    Write-Log "Cloudflare Tunnel stopped PID=$($proc.Id)"
    Write-Host 'Cloudflare Tunnel dihentikan.' -ForegroundColor Green
  } else {
    Write-Host 'Cloudflare Tunnel tidak sedang berjalan.' -ForegroundColor Yellow
  }
  Remove-Item -LiteralPath $CloudflarePidFile -Force -ErrorAction SilentlyContinue
}

function Stop-AllServices {
  Stop-CloudflareTunnel
  $proc = Get-ServerProcess
  if ($proc) {
    Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
    Write-Host "Game Server dihentikan (PID $($proc.Id))." -ForegroundColor Green
    Write-Log "Stopped app-owned game server PID=$($proc.Id)"
  } else { Write-Host 'Tidak ada Game Server milik launcher yang aktif.' -ForegroundColor Yellow }
  Remove-Item $PidFile -Force -ErrorAction SilentlyContinue
}
function Open-DevPanel {
  if (!(Get-ServerProcess) -or !(Test-PortOpen)) {
    Write-Host 'Game Server harus aktif terlebih dahulu. Jalankan menu [1].' -ForegroundColor Yellow
    return
  }
  $url = (Get-GameUrl) + '/dev-panel'
  Write-Host ('Membuka {0} - akses Dev Panel tetap memerlukan login akun Owner/Developer di game.' -f $url) -ForegroundColor Cyan
  if ($IsWindows) { Start-Process $url }
  else {
    $opener = Get-Command xdg-open -ErrorAction SilentlyContinue
    if ($opener) { Start-Process -FilePath $opener.Source -ArgumentList $url }
    else { Write-Host "Buka URL ini secara manual: $url" }
  }
}
function Show-Logs {
  Write-Host "`n--- GAME SERVER ERROR ---" -ForegroundColor Red
  if (Test-Path $ServerErr) { Get-Content $ServerErr -Tail 35 } else { Write-Host '(belum ada log)' }
  Write-Host "`n--- GAME SERVER OUTPUT ---" -ForegroundColor Cyan
  if (Test-Path $ServerOut) { Get-Content $ServerOut -Tail 35 } else { Write-Host '(belum ada log)' }
  Write-Host "`n--- LAUNCHER ---" -ForegroundColor Gray
  if (Test-Path $LauncherLog) { Get-Content $LauncherLog -Tail 20 }
}
function Save-NetworkSettings([bool]$AutoMode, [string]$HostName, [int]$SelectedPort) {
  if ($SelectedPort -lt 1 -or $SelectedPort -gt 65535) { throw 'Port harus berupa angka antara 1 sampai 65535.' }
  $cleanHost = ([string]$HostName).Trim()
  if (!$AutoMode) {
    if (!$cleanHost) { throw 'Masukkan IP/hostname atau aktifkan deteksi otomatis.' }
    if ($cleanHost -match '^(?i:https?://)' -or $cleanHost -match '[/\s]' -or $cleanHost -match ':\d+$') {
      throw 'Isi IP/hostname saja, tanpa http(s), port, path, atau spasi.'
    }
  } else { $cleanHost = '' }
  [pscustomobject]@{ mode = $(if ($AutoMode) { 'auto' } else { 'manual' }); host = $cleanHost; port = $SelectedPort } |
    ConvertTo-Json | Set-Content -LiteralPath $NetworkConfig -Encoding UTF8
  $script:Port = $SelectedPort
  Write-Log "Network settings saved: mode=$(if ($AutoMode) {'auto'} else {'manual'}) host=$cleanHost port=$SelectedPort"
}
function Open-Game {
  $url = Get-GameUrl
  if ($IsWindows) { Start-Process $url }
  else { $opener = Get-Command xdg-open -ErrorAction SilentlyContinue; if ($opener) { Start-Process -FilePath $opener.Source -ArgumentList $url } }
}
function Show-LauncherGui {
  if (!$IsWindows) { throw 'Tampilan GUI launcher saat ini tersedia di Windows. Jalankan PowerShell console pada Linux.' }
  Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Xaml
  # Ikuti preferensi tema aplikasi Windows untuk title bar dan dialog launcher.
  if (-not ('LauncherDwmTheme' -as [type])) {
    Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class LauncherDwmTheme {
  [DllImport("dwmapi.dll", PreserveSig=true)] public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);
}
"@
  }
  function Get-LauncherTheme {
    $light = 0
    try { $light = [int](Get-ItemPropertyValue -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name AppsUseLightTheme -ErrorAction Stop) } catch { $light = 0 }
    if ($light -eq 1) {
      return @{ Background='#F3F5F7'; Surface='#FFFFFF'; Foreground='#17212B'; Muted='#526170'; Border='#C8D0D8'; Input='#FFFFFF'; Accent='#DDEFE7'; DarkTitle=0 }
    }
    return @{ Background='#101820'; Surface='#17232D'; Foreground='#EAF2F8'; Muted='#A9BAC5'; Border='#344B58'; Input='#1B2A35'; Accent='#245B4A'; DarkTitle=1 }
  }
  function Set-LauncherTitleBarTheme($TargetWindow, [int]$DarkTitle) {
    $TargetWindow.Add_SourceInitialized({
      try {
        $handle = (New-Object System.Windows.Interop.WindowInteropHelper($TargetWindow)).Handle
        $value = $DarkTitle
        $hr = [LauncherDwmTheme]::DwmSetWindowAttribute($handle, 20, [ref]$value, 4)
        if ($hr -ne 0) { [void][LauncherDwmTheme]::DwmSetWindowAttribute($handle, 19, [ref]$value, 4) }
      } catch {}
    }.GetNewClosure())
  }
  function Show-LauncherDialog([string]$Message, [string]$Title = 'Launcher', [string]$Kind = 'Information') {
    $theme = Get-LauncherTheme
    $dialog = New-Object Windows.Window
    $dialog.Title = $Title; $dialog.Width = 440; $dialog.SizeToContent = 'Height'
    $dialog.MinHeight = 165; $dialog.WindowStartupLocation = 'CenterOwner'
    $dialog.ResizeMode = 'NoResize'; $dialog.Background = [Windows.Media.BrushConverter]::new().ConvertFromString($theme.Background)
    $dialog.Foreground = [Windows.Media.BrushConverter]::new().ConvertFromString($theme.Foreground)
    $dialog.FontFamily = 'Segoe UI'; $dialog.ShowInTaskbar = $false
    if ($script:LauncherMainWindow) { $dialog.Owner = $script:LauncherMainWindow }
    Set-LauncherTitleBarTheme $dialog $theme.DarkTitle
    $root = New-Object Windows.Controls.DockPanel; $root.Margin = '18'
    $button = New-Object Windows.Controls.Button; $button.Content = 'OK'; $button.Width = 88; $button.Height = 34
    $button.HorizontalAlignment = 'Right'; $button.Margin = '0,18,0,0'; $button.IsDefault = $true
    $button.Background = [Windows.Media.BrushConverter]::new().ConvertFromString($(if ($theme.DarkTitle) {'#245B4A'} else {'#DDEFE7'}))
    $button.Foreground = [Windows.Media.BrushConverter]::new().ConvertFromString($theme.Foreground)
    [Windows.Controls.DockPanel]::SetDock($button, 'Bottom'); $root.Children.Add($button) | Out-Null
    $messageText = New-Object Windows.Controls.TextBlock; $messageText.Text = $Message
    $messageText.TextWrapping = 'Wrap'; $messageText.Margin = '0,2,0,0'; $messageText.MaxWidth = 390
    $root.Children.Add($messageText) | Out-Null; $dialog.Content = $root
    $button.Add_Click({ $dialog.Close() }.GetNewClosure())
    [void]$dialog.ShowDialog()
  }
  [xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Harvest in the Great Valley — Launcher" Height="720" Width="900"
        MinHeight="650" MinWidth="820" WindowStartupLocation="CenterScreen"
        Background="#101820" Foreground="#EAF2F8" FontFamily="Segoe UI">
  <Window.Resources>
    <Style TargetType="Button">
      <Setter Property="Foreground" Value="#F7FAFC"/><Setter Property="Background" Value="#245B4A"/>
      <Setter Property="BorderBrush" Value="#3D806A"/><Setter Property="Padding" Value="14,9"/>
      <Setter Property="Margin" Value="4"/><Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Cursor" Value="Hand"/><Setter Property="MinHeight" Value="38"/>
    </Style>
    <Style TargetType="TextBox">
      <Setter Property="Background" Value="#1B2A35"/><Setter Property="Foreground" Value="#F7FAFC"/>
      <Setter Property="BorderBrush" Value="#405665"/><Setter Property="Padding" Value="8"/>
      <Setter Property="Margin" Value="4"/>
    </Style>
    <Style TargetType="GroupBox">
      <Setter Property="Foreground" Value="#B9D8CC"/><Setter Property="BorderBrush" Value="#344B58"/>
      <Setter Property="Padding" Value="10"/><Setter Property="Margin" Value="0,0,0,12"/>
    </Style>
  </Window.Resources>
  <Grid Margin="18">
    <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
    <StackPanel Grid.Row="0" Margin="2,0,2,14">
      <TextBlock Text="HARVEST IN THE GREAT VALLEY" FontSize="23" FontWeight="Bold" Foreground="#8ED7B4"/>
      <TextBlock Text="Development Launcher  •  Server, network, HTTPS, dependencies &amp; Dev Panel" Foreground="#A9BAC5" Margin="0,4,0,0"/>
    </StackPanel>
    <GroupBox Grid.Row="1" Header="KONFIGURASI JARINGAN">
      <Grid>
        <Grid.ColumnDefinitions><ColumnDefinition Width="155"/><ColumnDefinition Width="*"/><ColumnDefinition Width="110"/></Grid.ColumnDefinitions>
        <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <CheckBox x:Name="AutoIpCheck" Grid.Row="0" Grid.Column="0" Grid.ColumnSpan="2" Content="Deteksi IP otomatis (disarankan)" IsChecked="True" Foreground="#EAF2F8" Margin="4,6"/>
        <TextBlock Grid.Row="1" Grid.Column="0" Text="IP / Hostname manual" VerticalAlignment="Center" Margin="4"/>
        <TextBox x:Name="HostInput" Grid.Row="1" Grid.Column="1" IsEnabled="False" ToolTip="Contoh: 192.168.1.20 atau localhost"/>
        <TextBlock Grid.Row="2" Grid.Column="0" Text="Port Game Server" VerticalAlignment="Center" Margin="4"/>
        <TextBox x:Name="PortInput" Grid.Row="2" Grid.Column="1" Width="130" HorizontalAlignment="Left" Text="3000"/>
        <Button x:Name="SaveNetworkButton" Grid.Row="1" Grid.Column="2" Grid.RowSpan="2" Content="Simpan"/>
        <TextBlock x:Name="DetectedIpsText" Grid.Row="3" Grid.Column="0" Grid.ColumnSpan="3" Foreground="#91A8B6" TextWrapping="Wrap" Margin="4,8,4,2"/>
      </Grid>
    </GroupBox>
    <GroupBox Grid.Row="2" Header="STATUS &amp; ALAMAT AKSES">
      <Grid>
        <Grid.ColumnDefinitions><ColumnDefinition Width="120"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
        <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <TextBlock Grid.Row="0" Grid.Column="0" Text="Game Server" Foreground="#A9BAC5" Margin="4"/>
        <TextBlock x:Name="ServerStatusText" Grid.Row="0" Grid.Column="1" Text="Memeriksa..." FontWeight="Bold" Foreground="#F6C85F" Margin="4"/>
        <TextBlock Grid.Row="1" Grid.Column="0" Text="URL utama" Foreground="#A9BAC5" Margin="4"/>
        <TextBlock x:Name="PrimaryUrlText" Grid.Row="1" Grid.Column="1" Text="https://localhost:3000" Foreground="#8ED7B4" FontWeight="SemiBold" Margin="4"/>
        <TextBlock Grid.Row="2" Grid.Column="0" Text="URL lokal" Foreground="#A9BAC5" Margin="4"/>
        <TextBlock x:Name="LocalUrlText" Grid.Row="2" Grid.Column="1" Text="https://localhost:3000" Foreground="#8ED7B4" Margin="4"/>
        <TextBlock Grid.Row="3" Grid.Column="0" Text="Cloudflare" Foreground="#A9BAC5" Margin="4"/>
        <TextBlock x:Name="CloudflareStatusText" Grid.Row="3" Grid.Column="1" Text="OFFLINE" Foreground="#F6C85F" Margin="4"/>
        <TextBlock Grid.Row="4" Grid.Column="0" Text="URL publik" Foreground="#A9BAC5" Margin="4"/>
        <TextBlock x:Name="CloudflareUrlText" Grid.Row="4" Grid.Column="1" Text="Belum tersedia" Foreground="#8ED7B4" TextWrapping="Wrap" Margin="4"/>
      </Grid>
    </GroupBox>
    <Grid Grid.Row="3">
      <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
      <GroupBox Grid.Row="0" Header="KONTROL GAME">
        <UniformGrid Columns="3">
          <Button x:Name="StartButton" Content="▶  Jalankan Game Server" Background="#247A55"/>
          <Button x:Name="StopButton" Content="■  Stop Game Server" Background="#874444"/>
          <Button x:Name="OpenGameButton" Content="🌐  Buka Game" Background="#315B83"/>
          <Button x:Name="DevPanelButton" Content="🛠  Buka Developer Panel" Background="#315B83"/>
          <Button x:Name="CheckButton" Content="✓  Periksa Instalasi"/>
          <Button x:Name="OpenFolderButton" Content="📁  Buka Folder Proyek" Background="#465563"/>
          <Button x:Name="StartCloudflareButton" Content="↗  Start Tunnel (Auto Install)" Background="#247A55"/>
          <Button x:Name="StopCloudflareButton" Content="■  Stop Cloudflare Tunnel" Background="#874444"/>
          <Button x:Name="CopyCloudflareUrlButton" Content="▣  Copy Public URL" Background="#315B83"/>
        </UniformGrid>
      </GroupBox>
      <GroupBox Grid.Row="1" Header="LOG AKTIVITAS">
        <TextBox x:Name="LogOutput" IsReadOnly="True" AcceptsReturn="True" TextWrapping="Wrap" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto" FontFamily="Consolas" FontSize="12"/>
      </GroupBox>
    </Grid>
    <TextBlock Grid.Row="4" Text="Catatan: server bind ke 0.0.0.0 agar dapat diakses melalui localhost maupun IP LAN. HTTPS lokal memakai sertifikat development; perangkat lain mungkin perlu mempercayai sertifikat." Foreground="#91A8B6" TextWrapping="Wrap" Margin="3,10,3,0"/>
  </Grid>
</Window>
'@
  $reader = New-Object System.Xml.XmlNodeReader $xaml
  $window = [Windows.Markup.XamlReader]::Load($reader)
  $script:LauncherMainWindow = $window
  $themeForTitle = Get-LauncherTheme
  Set-LauncherTitleBarTheme $window $themeForTitle.DarkTitle
  $names = @('AutoIpCheck','HostInput','PortInput','SaveNetworkButton','DetectedIpsText','ServerStatusText','PrimaryUrlText','LocalUrlText','StartButton','StopButton','OpenGameButton','DevPanelButton','CheckButton','OpenFolderButton','LogOutput','CloudflareStatusText','CloudflareUrlText','StartCloudflareButton','StopCloudflareButton','CopyCloudflareUrlButton')
  $ui = @{}
  foreach ($name in $names) { $ui[$name] = $window.FindName($name) }
  $cfg = Get-NetworkConfig
  $ui.AutoIpCheck.IsChecked = ($cfg.mode -ne 'manual')
  $ui.HostInput.Text = [string]$cfg.host
  $ui.HostInput.IsEnabled = !$ui.AutoIpCheck.IsChecked
  $ui.PortInput.Text = [string]$(if ($cfg.port) { $cfg.port } else { 3000 })
  $ips = @(Get-LocalIPv4)
  $ui.DetectedIpsText.Text = 'IP terdeteksi: ' + $(if ($ips.Count) { $ips -join '   •   ' } else { 'Belum ada IP LAN terdeteksi; localhost tetap tersedia.' })
  $script:GuiActionProcess = $null
  $script:GuiActionLog = Join-Path $LogDir 'gui-action.log'
  $script:GuiActionErr = Join-Path $LogDir 'gui-action-error.log'
  $script:GuiActionName = ''
  function Update-GuiStatus {
    $proc = Get-ServerProcess
    if ($proc -and (Test-PortOpen)) {
      $ui.ServerStatusText.Text = "ONLINE  •  PID $($proc.Id)  •  Port $script:Port"
      $ui.ServerStatusText.Foreground = [Windows.Media.Brushes]::LightGreen
    } else {
      $ui.ServerStatusText.Text = "OFFLINE  •  Port $script:Port"
      $ui.ServerStatusText.Foreground = [Windows.Media.Brushes]::Salmon
    }
    $hostNow = Get-PreferredHost
    $ui.PrimaryUrlText.Text = "https://${hostNow}:$script:Port"
    $ui.LocalUrlText.Text = "https://localhost:$script:Port"

    $tunnelProc = Get-CloudflareProcess
    $publicUrl = Get-CloudflareUrl
    if ($tunnelProc) {
      $ui.CloudflareStatusText.Text = if ($publicUrl) { "ONLINE  •  PID $($tunnelProc.Id)" } else { "CONNECTING  •  PID $($tunnelProc.Id)" }
      $ui.CloudflareStatusText.Foreground = [Windows.Media.Brushes]::LightGreen
    } else {
      $ui.CloudflareStatusText.Text = 'OFFLINE'
      $ui.CloudflareStatusText.Foreground = [Windows.Media.Brushes]::Salmon
    }
    $ui.CloudflareUrlText.Text = if ($publicUrl) { $publicUrl } else { 'Belum tersedia' }
  }
  function Save-GuiSettings {
    $portNumber = 0
    if (![int]::TryParse($ui.PortInput.Text.Trim(), [ref]$portNumber)) { throw 'Port harus berupa angka.' }
    Save-NetworkSettings ([bool]$ui.AutoIpCheck.IsChecked) $ui.HostInput.Text $portNumber
    $ipsNow = @(Get-LocalIPv4)
    $ui.DetectedIpsText.Text = 'IP terdeteksi: ' + $(if ($ipsNow.Count) { $ipsNow -join '   •   ' } else { 'Belum ada IP LAN terdeteksi; localhost tetap tersedia.' })
    Update-GuiStatus
  }
  function Start-GuiAction([string]$Name) {
    if ($script:GuiActionProcess -and !$script:GuiActionProcess.HasExited) { Show-LauncherDialog 'Tunggu proses sebelumnya selesai.' 'Launcher' 'Information'; return }
    Save-GuiSettings
    Remove-Item $script:GuiActionLog,$script:GuiActionErr -Force -ErrorAction SilentlyContinue
    $hostExe = if ($PSVersionTable.PSEdition -eq 'Core') { Join-Path $PSHOME 'pwsh.exe' } else { Join-Path $PSHOME 'powershell.exe' }
    if (!(Test-Path $hostExe)) { $cmd = Get-Command pwsh,powershell -ErrorAction SilentlyContinue | Select-Object -First 1; if (!$cmd) { throw 'PowerShell executable tidak ditemukan.' }; $hostExe = $cmd.Source }
    $processArgs = @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $PSCommandPath + '"'),'-Action',$Name)
    $script:GuiActionProcess = Start-Process -FilePath $hostExe -ArgumentList $processArgs -WorkingDirectory $Root -WindowStyle Hidden -RedirectStandardOutput $script:GuiActionLog -RedirectStandardError $script:GuiActionErr -PassThru
    $script:GuiActionName = $Name
    $ui.ServerStatusText.Text = "MENJALANKAN: $Name ..."
    $ui.ServerStatusText.Foreground = [Windows.Media.Brushes]::Gold
    $ui.LogOutput.AppendText("`r`n[$(Get-Date -Format 'HH:mm:ss')] Memulai proses $Name ...`r`n")
    $ui.LogOutput.ScrollToEnd()
  }
  $ui.AutoIpCheck.Add_Checked({ $ui.HostInput.IsEnabled = $false })
  $ui.AutoIpCheck.Add_Unchecked({ $ui.HostInput.IsEnabled = $true })
  $ui.SaveNetworkButton.Add_Click({ try { Save-GuiSettings; $ui.LogOutput.AppendText("Pengaturan jaringan tersimpan.`r`n"); } catch { Show-LauncherDialog $_.Exception.Message 'Konfigurasi tidak valid' 'Warning' } })
  $ui.StartButton.Add_Click({ try { Start-GuiAction 'Start' } catch { Show-LauncherDialog $_.Exception.Message 'Launcher' 'Error' } })
  $ui.StopButton.Add_Click({ try { Start-GuiAction 'Stop' } catch { Show-LauncherDialog $_.Exception.Message 'Launcher' 'Error' } })
  $ui.CheckButton.Add_Click({ try { Start-GuiAction 'Check' } catch { Show-LauncherDialog $_.Exception.Message 'Launcher' 'Error' } })
  $ui.OpenGameButton.Add_Click({ try { Save-GuiSettings; if (!(Get-ServerProcess) -or !(Test-PortOpen)) { throw 'Game Server belum aktif. Jalankan server terlebih dahulu.' }; Open-Game } catch { Show-LauncherDialog $_.Exception.Message 'Launcher' 'Warning' } })
  $ui.DevPanelButton.Add_Click({ try { Save-GuiSettings; if (!(Get-ServerProcess) -or !(Test-PortOpen)) { throw 'Game Server belum aktif. Jalankan server terlebih dahulu.' }; Open-DevPanel } catch { Show-LauncherDialog $_.Exception.Message 'Launcher' 'Warning' } })
  $ui.OpenFolderButton.Add_Click({ Start-Process explorer.exe -ArgumentList ('"' + $Root + '"') })
  $ui.StartCloudflareButton.Add_Click({
    try {
      Save-GuiSettings
      if (!(Get-ServerProcess) -or !(Test-PortOpen)) { throw 'Jalankan Game Server terlebih dahulu.' }
      Start-GuiAction 'TunnelStart'
    } catch { Show-LauncherDialog $_.Exception.Message 'Cloudflare Tunnel' 'Warning' }
  })
  $ui.StopCloudflareButton.Add_Click({
    try { Start-GuiAction 'TunnelStop' }
    catch { Show-LauncherDialog $_.Exception.Message 'Cloudflare Tunnel' 'Error' }
  })
  $ui.CopyCloudflareUrlButton.Add_Click({
    try {
      $publicUrl = Get-CloudflareUrl
      if (!$publicUrl) { throw 'URL publik belum tersedia. Mulai tunnel dan tunggu koneksi Cloudflare.' }
      $copied = $false
      for ($attempt = 1; $attempt -le 5 -and !$copied; $attempt++) {
        try { [System.Windows.Clipboard]::SetText($publicUrl); $copied = $true }
        catch { if ($attempt -lt 5) { Start-Sleep -Milliseconds 180 } }
      }
      if (!$copied) { throw 'Clipboard Windows sedang digunakan aplikasi lain atau tidak dapat diakses. Coba klik Copy Public URL sekali lagi.' }
      $ui.LogOutput.AppendText("URL publik disalin: $publicUrl`r`n")
    } catch { Show-LauncherDialog $_.Exception.Message 'Cloudflare Tunnel' 'Information' }
  })
  $timer = New-Object Windows.Threading.DispatcherTimer
  $timer.Interval = [TimeSpan]::FromMilliseconds(650)
  $timer.Add_Tick({
    try {
      if ($script:GuiActionProcess) {
        $combinedOutput = ''
        if (Test-Path $script:GuiActionLog) { $combinedOutput += (Get-Content $script:GuiActionLog -Raw -ErrorAction SilentlyContinue) }
        if (Test-Path $script:GuiActionErr) {
          $errContent = Get-Content $script:GuiActionErr -Raw -ErrorAction SilentlyContinue
          if ($errContent) { $combinedOutput += "`r`n[STDERR]`r`n$errContent" }
        }
        if ($combinedOutput -and $ui.LogOutput.Text -ne $combinedOutput) { $ui.LogOutput.Text = $combinedOutput; $ui.LogOutput.ScrollToEnd() }
        if ($script:GuiActionProcess.HasExited) {
          $exitCode = $script:GuiActionProcess.ExitCode
          $ui.LogOutput.AppendText("`r`n[$(Get-Date -Format 'HH:mm:ss')] Proses $script:GuiActionName selesai (exit $exitCode).`r`n")
          $script:GuiActionProcess = $null
          Update-GuiStatus
        }
      } else { Update-GuiStatus }
    } catch {}
  })
  $window.Add_Closed({ $timer.Stop() })
  Update-GuiStatus
  $timer.Start()
  $null = $window.ShowDialog()
}

if ($Action) {
  try {
    switch ($Action) {
      'Start' { Start-GameServer }
      'Stop'  { Stop-AllServices }
      'Check' { Check-Installation }
      'TunnelStart' { Start-CloudflareTunnel }
      'TunnelStop' { Stop-CloudflareTunnel }
    }
    exit 0
  } catch {
    Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red
    Write-Log $_.Exception.ToString() 'ERROR'
    exit 1
  }
}

try {
  Show-LauncherGui
} catch {
  Write-Host "[ERROR] Launcher GUI gagal dibuka: $($_.Exception.Message)" -ForegroundColor Red
  Write-Log $_.Exception.ToString() 'ERROR'
  if ($IsWindows) { Read-Host 'Tekan Enter untuk keluar' | Out-Null }
  exit 1
}
